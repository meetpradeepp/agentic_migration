/**
 * tree-sitter-powerbuilder — grammar-dw.js
 *
 * DataWindow grammar for .srd files.
 *
 * Translated from ANTLR4:
 *   - PowerScriptDWLexer.g4   (FIX 1-4: tilde-newline strings, FLOAT>NUMBER,
 *                               COLON/BANG/LBRACK/RBRACK legacy symbols, UNKNOWN_CHAR)
 *   - PowerScriptDWParser.g4  (all structural decisions, softKeyword anyIdentifier)
 *
 * This grammar can be used standalone OR embedded via tree-sitter's
 * language injection into the main powerbuilder grammar.
 */

module.exports = grammar({
  name: 'powerbuilder_dw',

  extras: $ => [
    /[ \t\r\n]+/,
    $.line_comment,
    $.block_comment,
  ],

  // Case-insensitive DW keywords are handled inline via regex.
  // The DW lexer is single-mode so no external scanner is needed.

  rules: {

    // ── Entry ──────────────────────────────────────────────────────────────
    compilation_unit: $ => seq(
      optional($.export_header),
      $.release_statement,
      repeat1($.datawindow_block),
    ),

    export_header: $ => repeat1(choice(
      $.pb_export_header,
      $.pb_export_comments,
    )),

    // FIX 2: FLOAT must be matched by release_statement  (e.g. "release 10.5;")
    release_statement: $ => seq(
      /[rR][eE][lL][eE][aA][sS][eE]/,
      choice($.dw_float, $.dw_number),
      ';',
    ),

    // ── DataWindow blocks ──────────────────────────────────────────────────
    // Named blocks + catch-all for compute, group, etc.
    datawindow_block: $ => choice(
      seq(/[dD][aA][tT][aA][wW][iI][nN][dD][oO][wW]/,  '(', optional($.property_list), ')'),
      seq(/[tT][aA][bB][lL][eE]/,                       '(', optional($.table_content), ')'),
      seq(/[tT][eE][xX][tT]/,                            '(', optional($.property_list), ')'),
      // columnProperty disambiguation: COLUMN( is top-level block;
      // COLUMN= is inside TABLE() — handled by table_content rule
      seq(/[cC][oO][lL][uU][mM][nN]/,                   '(', optional($.property_list), ')'),
      seq(/[sS][uU][mM][mM][aA][rR][yY]/,               '(', optional($.property_list), ')'),
      seq(/[hH][eE][aA][dD][eE][rR]/,                   '(', optional($.property_list), ')'),
      seq(/[fF][oO][oO][tT][eE][rR]/,                   '(', optional($.property_list), ')'),
      seq(/[dD][eE][tT][aA][iI][lL]/,                   '(', optional($.property_list), ')'),
      seq(/[hH][tT][mM][lL][tT][aA][bB][lL][eE]/,       '(', optional($.property_list), ')'),
      seq(/[hH][tT][mM][lL][gG][eE][nN]/,               '(', optional($.property_list), ')'),
      seq(/[eE][xX][pP][oO][rR][tT]/, '.', $.any_identifier, '(', optional($.property_list), ')'),
      seq(/[iI][mM][pP][oO][rR][tT]/, '.', $.any_identifier, '(', optional($.property_list), ')'),
      seq($.any_identifier, '(', optional($.property_list), ')'),  // catch-all: compute, group, etc.
    ),

    // ── Table content ──────────────────────────────────────────────────────
    // tableContent separates column=(...) from other properties.
    // FIX: COLUMN token must not be confused with top-level COLUMN (...) block.
    table_content: $ => repeat1(choice(
      $.column_property,
      $.property,
    )),

    // Explicit: column = ( propertyList ) inside TABLE(...)
    column_property: $ => seq(
      /[cC][oO][lL][uU][mM][nN]/, '=', '(', optional($.property_list), ')',
    ),

    // ── Property list ──────────────────────────────────────────────────────
    property_list: $ => repeat1($.property),

    property: $ => choice(
      // RETRIEVE EQUAL must come first — needs special PBSELECT sub-parser
      seq(/[rR][eE][tT][rR][iI][eE][vV][eE]/, '=', $.retrieve_value),
      // UPDATE EQUAL — table name extraction
      seq(/[uU][pP][dD][aA][tT][eE]/, '=', $.dw_value),
      // version(400) / version(10.5) inside PBSELECT
      seq(/[vV][eE][rR][sS][iI][oO][nN]/, '(', choice($.dw_float, $.dw_number), ')'),
      // General: name = value  (handles dotted keys like print.margin.left)
      seq($.dotted_identifier, '=', $.dw_value),
    ),

    dotted_identifier: $ => seq(
      $.any_identifier,
      repeat(seq('.', $.any_identifier)),
    ),

    // ── Retrieve value ─────────────────────────────────────────────────────
    retrieve_value: $ => choice(
      $.pb_select_expression,
      $.dw_string,
    ),

    // pb_select_expression only matches the PBSELECT(...) structure.
    // The plain-string fallback (for malformed PBSELECT) lives in retrieve_value
    // to avoid an ambiguity conflict (dw_string reachable via two paths).
    pb_select_expression: $ => seq(
      /[pP][bB][sS][eE][lL][eE][cC][tT]/,
      '(', repeat1($.pbselect_property), ')',
    ),

    pbselect_property: $ => choice(
      seq(/[vV][eE][rR][sS][iI][oO][nN]/, '(', choice($.dw_float, $.dw_number), ')'),

      seq(/[tT][aA][bB][lL][eE]/, '(',
        /[nN][aA][mM][eE]/, '=', $.quoted_identifier,
        repeat(seq($.any_identifier, '=', $.dw_string)),
        ')'),

      seq(/[cC][oO][lL][uU][mM][nN]/, '(',
        /[nN][aA][mM][eE]/, '=', $.quoted_identifier,
        ')'),

      seq(/[jJ][oO][iI][nN]/, '(',
        /[lL][eE][fF][tT]/,  '=', $.quoted_identifier,
        /[oO][pP]/,           '=', $.quoted_identifier,
        /[rR][iI][gG][hH][tT]/, '=', $.quoted_identifier,
        repeat(seq($.any_identifier, '=', $.quoted_identifier)),
        ')'),

      seq(/[wW][hH][eE][rR][eE]/, '(',
        $.where_expression,
        ')'),

      seq(/[oO][rR][dD][eE][rR]/, '(',
        /[nN][aA][mM][eE]/, '=', $.quoted_identifier,
        /[aA][sS][cC]/,     '=', $.any_identifier,
        ')'),

      seq(/[aA][rR][gG]/, '(',
        /[nN][aA][mM][eE]/, '=', $.quoted_identifier,
        /[tT][yY][pP][eE]/, '=', $.any_identifier,
        ')'),

      // Catch-all for other PBSELECT sub-properties
      seq($.any_identifier, '(', repeat($.property_or_value), ')'),
    ),

    where_expression: $ => repeat1(
      seq($.any_identifier, '=', $.quoted_identifier),
    ),

    property_or_value: $ => choice(
      $.property,
      $.dw_string,
      $.dw_number,
      $.any_identifier,
      $.quoted_identifier,
    ),

    // ── Values ─────────────────────────────────────────────────────────────
    dw_value: $ => choice(
      seq($.dw_literal, repeat(seq($.binary_op, $.dw_literal))),
      $.tuple_block,
    ),

    // Recursive nested parenthesis — catches arguments=(("x", string))
    tuple_block: $ => seq(
      '(', repeat(choice($.dw_value, ',')), ')',
    ),

    dw_literal: $ => choice(
      $.dw_string,
      $.dw_float,
      $.dw_enum,                      // FIX 3: e.g. alignment=2!  (BANG suffix on number)
      $.dw_number,
      $.dw_host_var,                  // FIX 3: e.g. :arg_kodxrisi in PBSELECT WHERE/EXP
      $.dw_identifier_expr,           // dotted (a.b.c), type-cast (decimal(0)), or bare identifier
      $.quoted_identifier,
      // NOTE: nested_property_list removed — tuple_block (via dw_value path 2) handles all
      //       nested-paren structures and avoids a reduce/reduce conflict with tuple_block.
    ),

    // Unified identifier-like value: covers dotted_identifier + type_cast_or_identifier.
    // prec(2) on the dotted/type-cast alternatives forces shift over reduce when
    // the parser sees `ident .` or `ident (` — resolves the shift/reduce conflict
    // with the bare-identifier alternative (default prec 0).
    // optional(seq(',', dw_number)) is split into two alternatives to avoid a separate
    // reduce/reduce between 1-arg and 2-arg type-casts.
    // Dotted segments allow a number as any part after the first ident to handle
    // band values like header.1, trailer.1, detail.1 (group band suffixes).
    dw_identifier_expr: $ => choice(
      prec(2, seq($.any_identifier, repeat1(seq('.', choice($.any_identifier, $.dw_number))))),  // dotted: a.b.c or header.1
      prec(2, seq($.any_identifier, '(', $.dw_number, ',', $.dw_number, ')')),                   // 2-arg: decimal(18,2)
      prec(2, seq($.any_identifier, '(', $.dw_number, ')')),                                     // 1-arg: decimal(0)
      $.any_identifier,                                                                           // bare keyword/id
    ),

    binary_op: $ => choice(
      '+', '-', '*', '/',
      '>=', '<=', '>', '<', '=',
      choice('<>', '!='),  // NOT_EQUAL variants
    ),

    // FIX 3: Enum literal — a number followed by '!' (e.g. alignment=2!, borderstyle=1!)
    dw_enum: _ => /[0-9]+!/,

    // FIX 3: Host variable reference — ':identifier' in PBSELECT WHERE / EXP clauses
    dw_host_var: _ => /:[a-zA-Z_][a-zA-Z0-9_]*/,

    // Tilde-quoted identifiers: ~"tablename~"
    quoted_identifier: $ => seq('~', $.dw_string, '~'),

    nested_property_list: $ => seq('(', optional($.property_list), ')'),

    // ── Terminals ──────────────────────────────────────────────────────────

    // FIX 1: Allow ANY character (including literal \r\n) inside strings — legacy .srd
    //         files embed real newlines inside property strings.
    //         '~' . matches any char after tilde (\n, \r, \", ~~, etc.)
    //         Use [\s\S] instead of . so tree-sitter's regex engine matches newlines too.
    dw_string: _ => token(choice(
      seq('"',  repeat(choice(/[^"~]/, seq('~', /[\s\S]/))), '"'),
      seq("'",  repeat(choice(/[^'~]/, seq('~', /[\s\S]/))), "'"),
    )),

    // FIX 2: dw_float MUST be listed before dw_number in all alternatives
    dw_float:  _ => /[0-9]+\.[0-9]+/,
    dw_number: _ => /[0-9]+/,

    // PB Export headers: optional HA prefix for PB version variants (bare, no quotes)
    pb_export_header:   _ => /(HA)?\$PBExportHeader\$[^\r\n]*/,
    pb_export_comments: _ => /\$PBExportComments\$[^\r\n]*/,

    // FIX 3: IDENTIFIER allows @# for SQL temp tables / system views; $ in body
    // FIX 4: UNKNOWN_CHAR equivalent — tree-sitter ERROR nodes handle unrecognized chars
    //        gracefully (no crash, just an ERROR node in the CST). No explicit rule needed.
    // Soft keywords (RELEASE, TABLE, COLUMN, PBSELECT, VERSION, NAME, WHERE, JOIN,
    // ORDER, ARG, TYPE, EXP1, EXP2, OP, LOGIC, LEFT, RIGHT, ASC, etc.) are all matched
    // by this regex when used in identifier position — mirrors anyIdentifier in ANTLR4.
    any_identifier: _ => /[a-zA-Z_@#][a-zA-Z0-9_@#$]*/,

    line_comment:  _ => token(seq('//', /.*/)),
    block_comment: _ => token(seq('/*', /[^*]*\*+([^/*][^*]*\*+)*/, '/')),
  },
});
