/*
 * src/scanner.c - External scanner for tree-sitter-powerbuilder
 *
 * Handles everything that cannot be expressed in pure grammar.js:
 *
 *  1. Case-insensitive keywords (all ~80 PowerScript keywords)
 *     BOMB 1/2/3/4/5/6 fixes from PowerScriptLexer.g4 are reflected here.
 *
 *  2. DW_MODE - lexer mode for embedded DataWindow blocks in .sru/.srw
 *     Triggered by:  release N;   (mirrors DW_START in PowerScriptLexer.g4)
 *     Ends on:       end datawindow
 *
 *  3. COMMENT_MODE - nested block comments (slash-star ... star-slash)
 *     (mirrors FIX #6 / FIX #7 from PowerScriptLexer.g4)
 *
 *  4. ENUM_LITERAL - identifier! tokens  (BOMB 2 FIX)
 *     Must be scanned before IDENTIFIER to win on same-length match.
 *
 *  5. CONTINUATION - & at end of line  (FIX #8 from PowerScriptLexer.g4)
 *
 *  6. PB_EXPORT_HEADER / PB_EXPORT_COMMENTS tokens
 */

#include <tree_sitter/parser.h>
#include <string.h>
#include <ctype.h>
#include <stdbool.h>
#include <stdlib.h>

/* --------- Token type enum --- must match externals[] order in grammar.js --------------------- */
typedef enum {
  /* keywords */
  KW_FORWARD, KW_GLOBAL, KW_TYPE, KW_FROM,
  KW_WITHIN, KW_END, KW_VARIABLES, KW_SHARED,
  KW_PRIVATE, KW_PUBLIC, KW_PROTECTED,
  KW_FUNCTION, KW_SUBROUTINE, KW_EVENT, KW_RETURN,
  KW_PROTOTYPES, KW_LIBRARY, KW_ALIAS,
  KW_AUTOINSTANTIATE,
  KW_ON, KW_STRUCTURE,
  KW_IF, KW_THEN, KW_ELSE, KW_ELSEIF,
  KW_CHOOSE, KW_CASE,
  KW_FOR, KW_TO, KW_STEP, KW_NEXT,
  KW_DO, KW_WHILE, KW_UNTIL, KW_LOOP,
  KW_WITH,
  KW_TRY, KW_CATCH, KW_FINALLY,
  KW_THROWS, KW_THROW, KW_RAISE,
  KW_CREATE, KW_DESTROY, KW_USING,
  KW_CALL, KW_SUPER, KW_PARENT, KW_THIS,
  KW_OBJECT, KW_REF, KW_READONLY, KW_CONSTANT, KW_DEFAULT,
  KW_IS, KW_AND, KW_OR, KW_NOT,
  KW_NULL, KW_TRUE, KW_FALSE,
  KW_POST, KW_DYNAMIC, KW_STATIC, KW_TRIGGER,
  KW_EXIT, KW_GOTO, KW_HALT, KW_CLOSE,
  KW_OPEN,
  /* SQL keywords */
  KW_SELECT, KW_SELECTBLOB, KW_INSERT, KW_UPDATE,
  KW_UPDATEBLOB, KW_DELETE, KW_COMMIT, KW_ROLLBACK,
  KW_DECLARE, KW_CURSOR, KW_FETCH, KW_PREPARE,
  KW_EXECUTE, KW_IMMEDIATE, KW_CONNECT, KW_DISCONNECT,
  KW_INTO, KW_CONTINUE,
  /* lexer mode tokens */
  DW_START,
  DW_TEXT,
  DW_END,
  /* composite tokens */
  ENUM_LITERAL,
  PB_EXPORT_HEADER,
  PB_EXPORT_COMMENTS,
  CONTINUATION,
  /* error recovery */
  ERROR_SENTINEL,
  /* type_var_header: emitted when scanner sees 'type variables' (two-word sequence)
     Used as the exclusive start token for type_variables_block so it can't be
     confused with variable_decl(kw_type_as_keyword_as_id, variables_as_id) */
  TYPE_VAR_HEADER,
  /* Atomic two-word token: 'end function' or 'end subroutine'.
     Makes function_decl terminator unambiguous, preventing GLR state explosion
     in large functions with nested IF blocks. */
  END_FUNC,    /* 'end function' or 'end subroutine' */
  THEN_NL,     /* 'then' at end-of-line — marks multi-line IF (no forking needed then) */
  /* return newline: emitted when return is followed by newline (no expression) */
  RETURN_NL,
  /* block comment - external, supports nested block comments */
  BLOCK_COMMENT,
} TokenType;

/* --------- Scanner state --------------------------------------------------------------------------------------------------------------------------------------------------------------------- */
typedef struct {
  bool in_dw_mode;          /* currently inside a DataWindow block */
  int  comment_depth;       /* nesting depth for block comments (FIX #6) */
} ScannerState;

/* --------- Helpers ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ */

static void skip_whitespace(TSLexer *lexer) {
  while (lexer->lookahead == ' '  || lexer->lookahead == '\t' ||
         lexer->lookahead == '\r' || lexer->lookahead == '\n') {
    lexer->advance(lexer, true);  /* true = mark as whitespace */
  }
}

/* Helper: is char a valid identifier start? */
static bool is_id_start(int32_t c) {
  return isalpha(c) || c == '_' || c == '$' || c > 0x7F;
}

/* Helper: is char a valid identifier continuation? */
static bool is_id_part(int32_t c) {
  return isalnum(c) || c == '_' || c == '$' || c > 0x7F;
}

/* --------- Identifier buffer scan -------------------------------------------
   Read the full identifier into a lower-case buffer.
   Advances the lexer through the identifier.
   Returns the length (0 if not an identifier).
   BOMB 5 FIX: word boundary is enforced by reading until non-id char.
---------------------------------------------------------------------------- */
#define MAX_IDENT 64
static int scan_identifier(TSLexer *lexer, char buf[MAX_IDENT]) {
  if (!is_id_start(lexer->lookahead)) return 0;
  int len = 0;
  while (is_id_part(lexer->lookahead) && len < MAX_IDENT - 1) {
    buf[len++] = (char)tolower(lexer->lookahead);
    lexer->advance(lexer, false);
  }
  buf[len] = '\0';
  return len;
}

/* Compare buf to keyword --- simple strcmp after lowercasing done by scan_identifier */
#define KW_MATCH(kw) (strcmp(buf, (kw)) == 0)

/* --------- Keyword lookup: try to match one of the known keywords.
   IMPORTANT: call only after scan_identifier has read the full identifier.
   Returns the TokenType matched, or -1 if not a keyword.

   CRITICAL ORDERING (mirrors PowerScriptLexer.g4):
   - THROWS before THROW  (maximal munch handled by full-identifier-first approach)
   - SELECTBLOB before SELECT  (BOMB 4 FIX)
   - UPDATEBLOB before UPDATE  (BOMB 4 FIX)
   - ELSEIF before ELSE (elseif is a single identifier since no space)
   Note: "end if", "end choose" etc. are compound; "end" alone is KW_END.
--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- */
static int lookup_keyword(const char *buf) {
  switch (buf[0]) {
    case 'a':
      if (KW_MATCH("autoinstantiate")) return KW_AUTOINSTANTIATE;
      if (KW_MATCH("alias"))           return KW_ALIAS;
      if (KW_MATCH("and"))             return KW_AND;
      break;
    case 'c':
      if (KW_MATCH("choose"))     return KW_CHOOSE;
      if (KW_MATCH("commit"))     return KW_COMMIT;
      if (KW_MATCH("connect"))    return KW_CONNECT;
      if (KW_MATCH("constant"))   return KW_CONSTANT;
      if (KW_MATCH("continue"))   return KW_CONTINUE;
      if (KW_MATCH("create"))     return KW_CREATE;
      if (KW_MATCH("cursor"))     return KW_CURSOR;
      if (KW_MATCH("call"))       return KW_CALL;
      if (KW_MATCH("catch"))      return KW_CATCH;
      if (KW_MATCH("case"))       return KW_CASE;
      if (KW_MATCH("close"))      return KW_CLOSE;
      break;
    case 'd':
      if (KW_MATCH("declare"))    return KW_DECLARE;
      if (KW_MATCH("delete"))     return KW_DELETE;
      if (KW_MATCH("disconnect")) return KW_DISCONNECT;
      if (KW_MATCH("destroy"))    return KW_DESTROY;
      if (KW_MATCH("dynamic"))    return KW_DYNAMIC;
      if (KW_MATCH("default"))    return KW_DEFAULT;
      if (KW_MATCH("do"))         return KW_DO;
      break;
    case 'e':
      /* maximal-munch compound: ELSEIF before ELSE */
      if (KW_MATCH("elseif"))     return KW_ELSEIF;
      if (KW_MATCH("else"))       return KW_ELSE;
      if (KW_MATCH("event"))      return KW_EVENT;
      if (KW_MATCH("execute"))    return KW_EXECUTE;
      if (KW_MATCH("exit"))       return KW_EXIT;
      if (KW_MATCH("end"))        return KW_END;
      break;
    case 'f':
      if (KW_MATCH("finally"))    return KW_FINALLY;
      if (KW_MATCH("false"))      return KW_FALSE;
      if (KW_MATCH("fetch"))      return KW_FETCH;
      if (KW_MATCH("forward"))    return KW_FORWARD;
      if (KW_MATCH("function"))   return KW_FUNCTION;
      if (KW_MATCH("for"))        return KW_FOR;
      if (KW_MATCH("from"))       return KW_FROM;
      break;
    case 'g':
      if (KW_MATCH("global"))     return KW_GLOBAL;
      if (KW_MATCH("goto"))       return KW_GOTO;
      break;
    case 'h':
      if (KW_MATCH("halt"))       return KW_HALT;
      break;
    case 'i':
      if (KW_MATCH("if"))         return KW_IF;
      if (KW_MATCH("immediate"))  return KW_IMMEDIATE;
      if (KW_MATCH("insert"))     return KW_INSERT;
      if (KW_MATCH("into"))       return KW_INTO;
      if (KW_MATCH("is"))         return KW_IS;
      break;
    case 'l':
      if (KW_MATCH("library"))    return KW_LIBRARY;
      if (KW_MATCH("loop"))       return KW_LOOP;
      break;
    case 'n':
      if (KW_MATCH("next"))       return KW_NEXT;
      if (KW_MATCH("not"))        return KW_NOT;
      if (KW_MATCH("null"))       return KW_NULL;
      break;
    case 'o':
      if (KW_MATCH("object"))     return KW_OBJECT;
      if (KW_MATCH("on"))         return KW_ON;
      if (KW_MATCH("open"))       return KW_OPEN;
      if (KW_MATCH("or"))         return KW_OR;
      break;
    case 'p':
      if (KW_MATCH("parent"))     return KW_PARENT;
      if (KW_MATCH("post"))       return KW_POST;
      if (KW_MATCH("prepare"))    return KW_PREPARE;
      if (KW_MATCH("private"))    return KW_PRIVATE;
      if (KW_MATCH("protected"))  return KW_PROTECTED;
      if (KW_MATCH("prototypes")) return KW_PROTOTYPES;
      if (KW_MATCH("public"))     return KW_PUBLIC;
      break;
    case 'r':
      if (KW_MATCH("raise"))      return KW_RAISE;
      if (KW_MATCH("readonly"))   return KW_READONLY;
      if (KW_MATCH("ref"))        return KW_REF;
      if (KW_MATCH("return"))     return KW_RETURN;
      if (KW_MATCH("rollback"))   return KW_ROLLBACK;
      break;
    case 's':
      /* BOMB 4 FIX: SELECTBLOB before SELECT, UPDATEBLOB before UPDATE */
      if (KW_MATCH("selectblob")) return KW_SELECTBLOB;
      if (KW_MATCH("select"))     return KW_SELECT;
      if (KW_MATCH("shared"))     return KW_SHARED;
      if (KW_MATCH("static"))     return KW_STATIC;
      if (KW_MATCH("step"))       return KW_STEP;
      if (KW_MATCH("structure"))  return KW_STRUCTURE;
      if (KW_MATCH("subroutine")) return KW_SUBROUTINE;
      if (KW_MATCH("super"))      return KW_SUPER;
      break;
    case 't':
      if (KW_MATCH("then"))       return KW_THEN;
      if (KW_MATCH("this"))       return KW_THIS;
      /* THROWS before THROW --- maximal munch (both are full identifiers) */
      if (KW_MATCH("throws"))     return KW_THROWS;
      if (KW_MATCH("throw"))      return KW_THROW;
      if (KW_MATCH("to"))         return KW_TO;
      if (KW_MATCH("trigger"))    return KW_TRIGGER;
      if (KW_MATCH("true"))       return KW_TRUE;
      if (KW_MATCH("try"))        return KW_TRY;
      if (KW_MATCH("type"))       return KW_TYPE;
      break;
    case 'u':
      /* BOMB 4 FIX: UPDATEBLOB before UPDATE */
      if (KW_MATCH("updateblob")) return KW_UPDATEBLOB;
      if (KW_MATCH("update"))     return KW_UPDATE;
      if (KW_MATCH("until"))      return KW_UNTIL;
      if (KW_MATCH("using"))      return KW_USING;
      break;
    case 'v':
      if (KW_MATCH("variables"))  return KW_VARIABLES;
      break;
    case 'w':
      if (KW_MATCH("while"))      return KW_WHILE;
      if (KW_MATCH("with"))       return KW_WITH;
      if (KW_MATCH("within"))     return KW_WITHIN;
      break;
    default:
      break;
  }
  return -1; /* not a keyword */
}


/* --------- DW_MODE scanner ------------------------------------------------------------------------------------------------------------------------------------------------------------------ */

/* Scan "release <digits> ;" which triggers DW_MODE.
   Uses scan_identifier to read the word, then checks it's "release". */
static bool try_scan_dw_start(TSLexer *lexer, ScannerState *state) {
  char buf[MAX_IDENT];
  if (scan_identifier(lexer, buf) == 0) return false;
  if (strcmp(buf, "release") != 0) return false;

  /* skip whitespace */
  while (lexer->lookahead == ' ' || lexer->lookahead == '\t') {
    lexer->advance(lexer, true);
  }
  /* digits */
  if (!isdigit(lexer->lookahead)) return false;
  while (isdigit(lexer->lookahead) || lexer->lookahead == '.') {
    lexer->advance(lexer, false);
  }
  /* optional whitespace then ; */
  while (lexer->lookahead == ' ' || lexer->lookahead == '\t') {
    lexer->advance(lexer, true);
  }
  if (lexer->lookahead != ';') return false;
  lexer->advance(lexer, false);

  state->in_dw_mode = true;
  return true;
}

/* Inside DW_MODE: scan one line of DW content as DW_TEXT,
   or detect "end datawindow" to pop the mode. */
static bool scan_dw_line(TSLexer *lexer, ScannerState *state,
                         const bool *valid_symbols) {
  /* skip empty lines */
  while (lexer->lookahead == '\r' || lexer->lookahead == '\n') {
    lexer->advance(lexer, true);
  }
  if (lexer->lookahead == 0) {
    state->in_dw_mode = false;
    return false;
  }

  /* Check for "end datawindow" --- read first word and compare */
  if (tolower(lexer->lookahead) == 'e') {
    char buf[MAX_IDENT];
    int len = scan_identifier(lexer, buf);
    if (len > 0 && strcmp(buf, "end") == 0) {
      /* skip whitespace */
      while (lexer->lookahead == ' ' || lexer->lookahead == '\t')
        lexer->advance(lexer, true);
      len = scan_identifier(lexer, buf);
      if (len > 0 && strcmp(buf, "datawindow") == 0) {
        state->in_dw_mode = false;
        lexer->result_symbol = DW_END;
        return true;
      }
    }
    /* Fall through to consume the rest of the line as DW_TEXT.
       The characters already consumed are part of DW_TEXT. */
  }

  /* Consume to end of line as DW_TEXT */
  while (lexer->lookahead != '\r' && lexer->lookahead != '\n' &&
         lexer->lookahead != 0) {
    lexer->advance(lexer, false);
  }
  lexer->result_symbol = DW_TEXT;
  return true;
}

/* --------- ENUM_LITERAL scanner (BOMB 2 FIX) -----------------------------------
   Scan identifier followed immediately by !
   We do NOT advance before knowing the result --- we integrate this into
   the combined identifier/keyword scan below.
   Called only when we have already read the identifier buffer.
   The caller must advance past '!' if returning true.
---------------------------------------------------------------------------- */
static bool is_enum_literal_suffix(TSLexer *lexer) {
  return lexer->lookahead == '!';
}

/* --------- CONTINUATION scanner ------------------------------------------------------------------------------------------------------------------------------------------------ */
static bool try_scan_continuation(TSLexer *lexer) {
  if (lexer->lookahead != '&') return false;
  lexer->advance(lexer, false);
  /* optional trailing spaces/tabs */
  while (lexer->lookahead == ' ' || lexer->lookahead == '\t')
    lexer->advance(lexer, true);
  /* must be at line end */
  if (lexer->lookahead == '\r') lexer->advance(lexer, true);
  if (lexer->lookahead == '\n') { lexer->advance(lexer, true); return true; }
  return false;
}

/* --------- PB Export header scanner ------------------------------------------------------------------------------------------------------------------------------------ */
static bool try_scan_export_header(TSLexer *lexer, TokenType *result) {
  /* Optional "HA" prefix (some PB versions) */
  if (lexer->lookahead == 'H' || lexer->lookahead == 'h') {
    int32_t h = lexer->lookahead;
    lexer->advance(lexer, false);
    if (lexer->lookahead == 'A' || lexer->lookahead == 'a') {
      lexer->advance(lexer, false);
    } else {
      /* Not an HA prefix --- bail (can't backtrack easily, mark error) */
      return false;
    }
  }
  if (lexer->lookahead != '$') return false;

  /* Match "$PBExportHeader$" or "$PBExportComments$" */
  const char *hdr = "$PBExportHeader$";
  const char *cmt = "$PBExportComments$";
  const char *ph = hdr, *pc = cmt;
  bool is_header = true, is_comment = true;

  while (*ph || *pc) {
    int32_t ch = lexer->lookahead;
    if (*ph && ch != *ph) is_header = false;
    if (*pc && ch != *pc) is_comment = false;
    if (!is_header && !is_comment) return false;
    lexer->advance(lexer, false);
    if (*ph) ph++;
    if (*pc) pc++;
  }

  /* consume rest of line */
  while (lexer->lookahead != '\r' && lexer->lookahead != '\n' &&
         lexer->lookahead != 0) {
    lexer->advance(lexer, false);
  }

  *result = is_header ? PB_EXPORT_HEADER : PB_EXPORT_COMMENTS;
  return true;
}

/* --------- Nested block comment scanner (FIX #6 / FIX #7) --------------------------------------------------------------- */
static bool try_scan_block_comment(TSLexer *lexer, ScannerState *state) {
  if (lexer->lookahead != '/') return false;
  lexer->advance(lexer, false);
  if (lexer->lookahead != '*') return false;
  lexer->advance(lexer, false);

  int depth = 1;
  while (lexer->lookahead != 0 && depth > 0) {
    if (lexer->lookahead == '/') {
      lexer->advance(lexer, false);
      if (lexer->lookahead == '*') { depth++; lexer->advance(lexer, false); }
    } else if (lexer->lookahead == '*') {
      lexer->advance(lexer, false);
      if (lexer->lookahead == '/') { depth--; lexer->advance(lexer, false); }
    } else {
      lexer->advance(lexer, false);
    }
  }
  return true;
}

/* ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
   tree_sitter_powerbuilder_external_scanner_scan  --- main entry point
--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- */
bool tree_sitter_powerbuilder_external_scanner_scan(
    void *payload, TSLexer *lexer, const bool *valid_symbols)
{
  ScannerState *state = (ScannerState *)payload;

  /* ------ DW_MODE handling --------------------------------------------------------------------------------------------------------------------------------------------------------- */
  if (state->in_dw_mode) {
    if (valid_symbols[DW_TEXT] || valid_symbols[DW_END]) {
      return scan_dw_line(lexer, state, valid_symbols);
    }
    /* If parser doesn't want DW tokens here, pop the mode and fall through */
    state->in_dw_mode = false;
  }

  /* ------ THEN_NL: emitted when 'then' is at end-of-line (multi-line IF) ---------
     Strategy: skip horizontal whitespace, optional comments, then check for newline/EOF.
     Handles both line comments (//) and block comments (slash-star ... star-slash) after 'then'.
     The '&' line-continuation character means a multi-line statement (NOT multi-line IF body),
     so we return false for '&' to use the single-line IF alternative.
  --------------------------------------------------------------------------- */
  if (valid_symbols[THEN_NL]) {
    while (true) {
      /* Skip horizontal whitespace only (preserve newline for detection) */
      while (lexer->lookahead == ' ' || lexer->lookahead == '\t') {
        lexer->advance(lexer, true);
      }
      /* Check for '&' continuation — statement continues on next line, NOT multi-line IF body.
         We must emit CONTINUATION here (rather than returning false) because returning false
         causes tree-sitter to fail the entire scan; it won't re-call the scanner for CONTINUATION.
         Emitting CONTINUATION (an extra) causes the parser to skip it and look for the statement. */
      if (lexer->lookahead == '&') {
        if (valid_symbols[CONTINUATION] && try_scan_continuation(lexer)) {
          lexer->result_symbol = CONTINUATION;
          return true;
        }
        return false;  /* Single-line IF with continuation (fallback) */
      }
      /* Handle line comment: // ... */
      if (lexer->lookahead == '/') {
        int32_t slash = lexer->lookahead;
        lexer->advance(lexer, true);
        if (lexer->lookahead == '/') {
          /* Line comment: skip to end of line */
          while (lexer->lookahead != '\n' && lexer->lookahead != '\r' && lexer->lookahead != 0) {
            lexer->advance(lexer, true);
          }
          /* After line comment, fall through to newline check */
          break;
        } else if (lexer->lookahead == '*') {
          /* Block comment: scan to matching end-of-comment sequence */
          lexer->advance(lexer, true);  /* consume '*' */
          while (lexer->lookahead != 0) {
            if (lexer->lookahead == '*') {
              lexer->advance(lexer, true);
              if (lexer->lookahead == '/') {
                lexer->advance(lexer, true);  /* consume closing '/' */
                break;  /* End of block comment */
              }
            } else {
              lexer->advance(lexer, true);
            }
          }
          /* After block comment, continue outer loop to check for more comments or newline */
          continue;
        } else {
          /* Not a comment — stray '/' means statement on same line */
          return false;
        }
      }
      break;  /* No more comments to skip */
    }
    /* Check for CR+LF, LF, or EOF → multi-line IF body follows */
    if (lexer->lookahead == '\r') {
      lexer->advance(lexer, true);
    }
    if (lexer->lookahead == '\n' || lexer->lookahead == 0) {
      if (lexer->lookahead == '\n') lexer->advance(lexer, true);
      lexer->result_symbol = THEN_NL;
      return true;
    }
    /* Something else on same line → single-line IF */
    return false;
  }

  /* ------ RETURN_NL: emit when 'return' is at end-of-line (no expression) ----
     Must check BEFORE skip_whitespace so we can see the newline.
     Strategy: skip only horizontal whitespace (spaces/tabs), then check for
     newline or EOF. If found, emit RETURN_NL without consuming the newline
     (advance with mark=true so it's treated as whitespace).
     If no newline found, return false — tree-sitter resets the lexer position.
  --------------------------------------------------------------------------- */
  if (valid_symbols[RETURN_NL]) {
    /* Skip horizontal whitespace only */
    while (lexer->lookahead == ' ' || lexer->lookahead == '\t') {
      lexer->advance(lexer, true);
    }
    /* Check for CR+LF or LF or EOF */
    if (lexer->lookahead == '\r') {
      lexer->advance(lexer, true);
    }
    if (lexer->lookahead == '\n' || lexer->lookahead == 0) {
      if (lexer->lookahead == '\n') lexer->advance(lexer, true);
      lexer->result_symbol = RETURN_NL;
      return true;
    }
    /* No newline: return false so tree-sitter resets position and tries
       the expression path for return_stmt. */
    return false;
  }

  skip_whitespace(lexer);

  if (lexer->lookahead == 0) return false;

  /* ------ CONTINUATION  (& at end of line) ------------------------------------------------------------------------------------------------------ */
  if (valid_symbols[CONTINUATION] && lexer->lookahead == '&') {
    if (try_scan_continuation(lexer)) {
      lexer->result_symbol = CONTINUATION;
      return true;
    }
  }

  /* ------ PB Export headers ------------------------------------------------------------------------------------------------------------------------------------------------------ */
  if ((valid_symbols[PB_EXPORT_HEADER] || valid_symbols[PB_EXPORT_COMMENTS])
      && (lexer->lookahead == '$' || lexer->lookahead == 'H' || lexer->lookahead == 'h'))
  {
    TokenType tok;
    if (try_scan_export_header(lexer, &tok)) {
      if (valid_symbols[tok]) {
        lexer->result_symbol = tok;
        return true;
      }
    }
  }

  /* ------ Nested block comment: try BLOCK_COMMENT first, then ERROR_SENTINEL fallback --------- */
  if (lexer->lookahead == '/') {
    if (valid_symbols[BLOCK_COMMENT]) {
      if (try_scan_block_comment(lexer, state)) {
        lexer->result_symbol = BLOCK_COMMENT;
        return true;
      }
    } else if (valid_symbols[ERROR_SENTINEL]) {
      /* Peek --- if next is *, consume as comment so parser skips it */
      if (try_scan_block_comment(lexer, state)) {
        lexer->result_symbol = ERROR_SENTINEL;
        return true;
      }
    }
  }

  /* ------ DW_START: "release N ;" triggers DW_MODE ------------------------------------------------------------------------------
     BOMB 4 / FIX #10: "release" is also a valid start of DW blocks
     inside .sru/.srw files. ------------------------------------------------------------------------------------------------------------------------------------------ */
  if (valid_symbols[DW_START] && tolower(lexer->lookahead) == 'r') {
    if (try_scan_dw_start(lexer, state)) {
      lexer->result_symbol = DW_START;
      return true;
    }
  }
  /* ------ Combined identifier/enum-literal/keyword scan ----------------------
     CRITICAL: We read the FULL identifier first before making any decision.
     This avoids the partial-advance bug where sequential match attempts
     leave the lexer at a mid-identifier position.

     Steps:
       1. Read full identifier into buffer (advances lexer through identifier)
       2. If next char is '!' and ENUM_LITERAL is valid: emit ENUM_LITERAL
       3. If identifier matches a keyword and that keyword is valid: emit it
       4. Otherwise: return false, tree-sitter uses built-in identifier regex.

     NOTE: When we return false after advancing, tree-sitter does NOT roll back.
     However, step 4 only happens when NEITHER enum_literal NOR a keyword is
     needed here. In that case, the built-in 'identifier' regex rule in grammar.js
     will still match -- BUT it has already been consumed by scan_identifier!

     To handle this correctly, we NEVER return false after consuming chars.
     Instead, if the token is not a keyword or enum_literal in this context,
     we emit it as... well, we can't. We must not return false.

     SOLUTION: Only call scan_identifier when we KNOW the external scanner
     is being called for keyword/enum_literal purposes (i.e., at least one
     of the keyword valid_symbols is set). If only the identifier built-in
     is needed, the external scanner is not called for it.

     The grammar.js 'word' rule and 'identifier' regex handle plain identifiers
     without going through the external scanner.
  --------------------------------------------------------------------------- */
  if (is_id_start(lexer->lookahead)) {
    /* TYPE_VAR_HEADER: emit atomic two-word token 'type variables' before regular keyword scan.
       This must be done BEFORE scan_identifier so we can control mark_end precisely.
       Strategy: manually check 'type' char by char, then whitespace, then 'variables' char by char.
       If both words are found: emit TYPE_VAR_HEADER spanning both words.
       If only 'type' matches: emit KW_TYPE (if valid) with token ending after 'type'.
       This prevents implicit_variables_block from consuming 'type variables' as a variable_decl. */
    if (valid_symbols[TYPE_VAR_HEADER]) {
      int32_t c = lexer->lookahead;
      if (c == 't' || c == 'T') {
        /* Try to match 'type' case-insensitively */
        const char *type_str = "type";
        bool type_matched = true;
        for (int i = 0; type_str[i]; i++) {
          if (tolower(lexer->lookahead) != type_str[i]) { type_matched = false; break; }
          lexer->advance(lexer, false);
        }
        if (type_matched && !is_id_part(lexer->lookahead)) {
          /* Consumed 'type' successfully — mark end here for KW_TYPE fallback.
             IMPORTANT: use advance(false) for whitespace to keep the token start at position 0.
             Using advance(true) would make tree-sitter treat the whitespace as "before the token"
             and reset the token start, causing TYPE_VAR_HEADER to start AFTER the whitespace. */
          lexer->mark_end(lexer);
          /* Skip horizontal whitespace — use advance(false) to keep token start at original position.
             This means the whitespace is "inside" the TYPE_VAR_HEADER token, which is fine. */
          while (lexer->lookahead == ' ' || lexer->lookahead == '\t') {
            lexer->advance(lexer, false);
          }
          /* Try to match 'variables' case-insensitively, char by char */
          const char *vars_str = "variables";
          bool vars_matched = true;
          for (int i = 0; vars_str[i]; i++) {
            if (tolower(lexer->lookahead) != vars_str[i]) { vars_matched = false; break; }
            lexer->advance(lexer, false);
          }
          if (vars_matched && !is_id_part(lexer->lookahead)) {
            /* Found 'type variables' — update mark and emit TYPE_VAR_HEADER */
            lexer->mark_end(lexer);
            lexer->result_symbol = TYPE_VAR_HEADER;
            return true;
          }
          /* 'variables' not found — emit just 'type' = KW_TYPE (token end at mark after 'type') */
          if (valid_symbols[KW_TYPE]) {
            lexer->result_symbol = KW_TYPE;
            return true;
          }
          /* KW_TYPE not valid — shouldn't happen when TYPE_VAR_HEADER is valid, but handle gracefully */
          return false;
        }
        /* First char was 't'/'T' but not a full 'type' word — fall through to scan_identifier */
        /* Note: we've advanced past some chars. Since we cannot truly backtrack,
           we must handle this -- but this path only happens for identifiers starting with 't'
           that are NOT 'type'. scan_identifier below would normally consume them.
           The issue: we've already advanced past those chars in the TYPE_VAR_HEADER check.
           Solution: since TYPE_VAR_HEADER only fires on 't'/'T', and we're checking 'type'
           specifically, if 'type_matched' is false, we've consumed some chars but NOT a full word.
           We need to continue consuming the rest of the identifier and handle it below.
           Fall through to scan_identifier approach by consuming the rest. */
        char buf_rest[MAX_IDENT];
        int rest_len = scan_identifier(lexer, buf_rest);
        /* Full identifier is 't'... + rest. We need to emit it as a keyword or handle below.
           We can't easily reconstruct the full identifier. Just return false and let tree-sitter
           reset the position. */
        return false;
      }
    }

    /* END_FUNC: atomic two-word token 'end function' or 'end subroutine'.
       Strategy: match 'end' word, skip whitespace, match 'function' or 'subroutine'.
       Fallback to KW_END if second word does not match.
       Only fires when valid_symbols[END_FUNC] is true (i.e. parser expects a function/subroutine terminator). */
    if (valid_symbols[END_FUNC] &&
        (lexer->lookahead == 'e' || lexer->lookahead == 'E')) {
      const char *end_str = "end";
      bool end_matched = true;
      for (int i = 0; end_str[i]; i++) {
        if (tolower(lexer->lookahead) != end_str[i]) { end_matched = false; break; }
        lexer->advance(lexer, false);
      }
      if (end_matched && !is_id_part(lexer->lookahead)) {
        /* Consumed 'end' — mark here for KW_END fallback */
        lexer->mark_end(lexer);
        /* Skip horizontal whitespace (advance(false) keeps token start at original position) */
        while (lexer->lookahead == ' ' || lexer->lookahead == '\t') {
          lexer->advance(lexer, false);
        }
        int32_t nc = tolower(lexer->lookahead);
        if (nc == 'f' || nc == 's') {
          /* Try 'function' (nc=='f') or 'subroutine' (nc=='s') */
          const char *word = (nc == 'f') ? "function" : "subroutine";
          bool word_ok = true;
          for (int i = 0; word[i]; i++) {
            if (tolower(lexer->lookahead) != word[i]) { word_ok = false; break; }
            lexer->advance(lexer, false);
          }
          if (word_ok && !is_id_part(lexer->lookahead)) {
            lexer->mark_end(lexer);
            lexer->result_symbol = END_FUNC;
            return true;
          }
        }
        /* No two-word match: fall back to KW_END (token ending after 'end') */
        if (valid_symbols[KW_END]) {
          lexer->result_symbol = KW_END;
          return true;
        }
        return false;
      }
      /* 'end' did not match fully — consume rest and fall through */
      if (!end_matched) {
        char buf_e[MAX_IDENT];
        scan_identifier(lexer, buf_e);
        return false;
      }
    }

    char buf[MAX_IDENT];
    int len = scan_identifier(lexer, buf);
    if (len > 0) {
      /* BOMB 2 FIX: check for enum literal first */
      if (valid_symbols[ENUM_LITERAL] && lexer->lookahead == '!') {
        lexer->advance(lexer, false); /* consume '!' */
        lexer->result_symbol = ENUM_LITERAL;
        return true;
      }

      /* Keyword lookup */
      int kw = lookup_keyword(buf);
      if (kw >= 0 && valid_symbols[kw]) {
        lexer->result_symbol = (TokenType)kw;
        return true;
      }

      /* Not a keyword or enum_literal in this context.
         We cannot return false because we already advanced past the identifier.
         The grammar's built-in 'identifier' regex cannot re-scan these chars.
         However, tree-sitter's external scanner integration actually DOES
         rewind the position when the scanner returns false -- this is
         guaranteed by the tree-sitter runtime implementation.
         See: https://tree-sitter.github.io/tree-sitter/creating-parsers#external-scanners
         "The lexer's position is reset to the position before the scanner was called." */
    }
  }

  return false;
}

/* ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
   State lifecycle --- allocate / free / serialize / deserialize
--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- */

void *tree_sitter_powerbuilder_external_scanner_create() {
  ScannerState *state = (ScannerState *)calloc(1, sizeof(ScannerState));
  state->in_dw_mode    = false;
  state->comment_depth = 0;
  return state;
}

void tree_sitter_powerbuilder_external_scanner_destroy(void *payload) {
  free(payload);
}

unsigned tree_sitter_powerbuilder_external_scanner_serialize(
    void *payload, char *buffer)
{
  ScannerState *state = (ScannerState *)payload;
  buffer[0] = (char)state->in_dw_mode;
  buffer[1] = (char)state->comment_depth;
  return 2;
}

void tree_sitter_powerbuilder_external_scanner_deserialize(
    void *payload, const char *buffer, unsigned length)
{
  ScannerState *state = (ScannerState *)payload;
  if (length >= 1) state->in_dw_mode    = (bool)buffer[0];
  if (length >= 2) state->comment_depth = (int)buffer[1];
}
