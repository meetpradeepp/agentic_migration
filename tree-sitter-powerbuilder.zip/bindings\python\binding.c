#include <Python.h>

typedef struct TSLanguage TSLanguage;

/* Declared in src/parser.c (generated) */
const TSLanguage *tree_sitter_powerbuilder(void);

static PyObject *_binding_language(PyObject *Py_UNUSED(self), PyObject *Py_UNUSED(args)) {
    return PyLong_FromVoidPtr((void *)tree_sitter_powerbuilder());
}

static PyMethodDef methods[] = {
    {"language", _binding_language, METH_NOARGS,
     "Get the tree-sitter language pointer for PowerBuilder."},
    {NULL, NULL, 0, NULL},
};

static struct PyModuleDef module = {
    .m_base = PyModuleDef_HEAD_INIT,
    .m_name = "_binding",
    .m_doc = "PowerBuilder tree-sitter language binding",
    .m_size = -1,
    .m_methods = methods,
};

PyMODINIT_FUNC PyInit__binding(void) {
    return PyModule_Create(&module);
}
