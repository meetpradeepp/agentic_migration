/**
 * tree-sitter-powerbuilder — grammar.js
 *
 * PowerScript grammar for .sru / .srw / .srf / .srm files.
 *
 * Translated from ANTLR4:
 *   - PowerScriptLexer.g4   (all BOMB fixes 1-6, FIX #1/#6/#7/#8/#10)
 *   - PowerScriptParser.g4  (all structural fixes)
 *
 * Case-insensitive keywords are handled by the external scanner (src/scanner.c).
 * The scanner also manages:
 *   - DW_MODE  (embedded DataWindow blocks in .sru/.srw)
 *   - COMMENT_MODE (nested block comments)
 *   - ENUM_LITERAL (trailing !)
 *   - CONTINUATION (line-continuation with &)
 */

// ─────────────────────────────────────────────────────────────────────────────
// Operator precedence constants  (higher number = tighter binding)
// Mirrors the expression rule ordering in PowerScriptParser.g4
// ─────────────────────────────────────────────────────────────────────────────
const PREC = {
  OR:         1,
  AND:        2,
  EQUALITY:   3,
  RELATIONAL: 4,
  ADD:        5,
  MUL:        6,
  POWER:      7,   // BOMB 3 FIX: ^ higher than * /
  UNARY:      8,
  CALL:       9,
  MEMBER:     10,
  ARRAY:      11,
};

module.exports = grammar({
  name: 'powerbuilder',

  // ── Tokens produced by the external scanner ──────────────────────────────
  externals: $ => [
    // Keywords (case-insensitive — scanner handles tolower comparison)
    $.kw_forward,    $.kw_global,     $.kw_type,       $.kw_from,
    $.kw_within,     $.kw_end,        $.kw_variables,  $.kw_shared,
    $.kw_private,    $.kw_public,     $.kw_protected,
    $.kw_function,   $.kw_subroutine, $.kw_event,      $.kw_return,
    $.kw_prototypes, $.kw_library,    $.kw_alias,
    $.kw_autoinstantiate,
    $.kw_on,         $.kw_structure,
    $.kw_if,         $.kw_then,       $.kw_else,       $.kw_elseif,
    $.kw_choose,     $.kw_case,
    $.kw_for,        $.kw_to,         $.kw_step,       $.kw_next,
    $.kw_do,         $.kw_while,      $.kw_until,      $.kw_loop,
    $.kw_with,
    $.kw_try,        $.kw_catch,      $.kw_finally,
    $.kw_throws,     $.kw_throw,      $.kw_raise,
    $.kw_create,     $.kw_destroy,    $.kw_using,
    $.kw_call,       $.kw_super,      $.kw_parent,     $.kw_this,
    $.kw_object,     $.kw_ref,        $.kw_readonly,   $.kw_constant,   $.kw_default,
    $.kw_is,         $.kw_and,        $.kw_or,         $.kw_not,
    $.kw_null,       $.kw_true,       $.kw_false,
    $.kw_post,       $.kw_dynamic,    $.kw_static,     $.kw_trigger,
    $.kw_exit,       $.kw_goto,       $.kw_halt,       $.kw_close,
    $.kw_open,
    // SQL keywords
    $.kw_select,     $.kw_selectblob, $.kw_insert,     $.kw_update,
    $.kw_updateblob, $.kw_delete,     $.kw_commit,     $.kw_rollback,
    $.kw_declare,    $.kw_cursor,     $.kw_fetch,      $.kw_prepare,
    $.kw_execute,    $.kw_immediate,  $.kw_connect,    $.kw_disconnect,
    $.kw_into,       $.kw_continue,
    // Lexer mode tokens
    $.dw_start,       // "release N ;" triggers DW_MODE
    $.dw_text,        // one non-empty line inside DW block
    $.dw_end,         // "end datawindow" pops DW_MODE
    // Composite tokens
    $.enum_literal,   // BOMB 2 FIX: identifier!  e.g. Right!
    $.pb_export_header,
    $.pb_export_comments,
    $.continuation,   // & at end of line (skip)
    // Error recovery sentinel
    $.error_sentinel,
    // Two-word token 'type variables' — exclusive start of type_variables_block
    // Prevents implicit_variables_block from consuming 'type variables' as a variable_decl
    $.type_var_header,
    // Atomic two-word token: 'end function' or 'end subroutine'
    // Makes function_decl terminator unambiguous to the GLR parser,
    // preventing exponential state growth in large functions with nested IF blocks.
    $.end_func,   // 'end function' or 'end subroutine'
    // THEN_NL: emitted when 'then' is at end-of-line (signals multi-line IF).
    // This disambiguates multi-line IF from single-line IF without GLR forking,
    // eliminating the [block, if_stmt] conflict that causes state explosion with
    // deep IF nesting in large functions like w_ban.srw.
    $.then_nl,    // 'then' followed by newline → multi-line IF
    // Return newline: emitted when return is at end-of-line (no expression follows)
    $.return_nl,
    // Block comment (external to handle nested /* */)
    $.block_comment,
  ],

  // ── Extras: whitespace and comments are skipped everywhere ───────────────
  extras: $ => [
    /[ \t\r\n]+/,
    $.line_comment,
    $.block_comment,
    $.continuation,
  ],

  // ── Conflict resolution hints ─────────────────────────────────────────────
  // PowerScript is inherently ambiguous from 1-token lookahead because:
  //   - kw_type can start: type_decl, type_variables_block, instance_var_block,
  //     prototype_block, keyword_as_id (in variable_decl or expression)
  //   - identifiers can start: variable_decl, assignment_stmt, call_stmt, expression_stmt
  // We declare all known conflicts so tree-sitter uses GLR for these positions.
  conflicts: $ => [
    [$.variable_decl, $.assignment_stmt],
    [$.call_stmt, $.expression_stmt],
    [$.assignment_stmt, $.expression_stmt],
    [$.forward_type_decl, $.global_type_decl],
    [$.forward_type_decl, $.type_decl],
    [$.global_type_decl, $.type_decl],
    [$.lvalue, $.expression],
    [$.type_decl, $.type_variables_block],
    [$.type_decl, $.prototype_block],
    [$.modifier, $.keyword_as_id],
    [$.qualified_name, $.lvalue],
    [$.qualified_name, $.type_name],
    [$.struct_member_decl, $.variable_decl],
    [$.struct_member_decl, $.assignment_stmt],
    [$.global_type_decl, $.global_variables_block],
    [$.shared_variables_block, $.variable_decl],
    [$.type_variables_block, $.variable_decl],
    [$.type_variables_block, $.implicit_variables_block],
    [$.keyword_as_id, $.access_modifier],
    [$.keyword_as_id, $.function_decl],
    [$.keyword_as_id, $.event_decl],
    [$.keyword_as_id, $.forward_block],
    [$.keyword_as_id, $.prototype_block],
    [$.keyword_as_id, $.on_block],
    [$.keyword_as_id, $.on_stub],
    [$.on_block, $.on_stub],
    [$.on_stub, $.ui_id],
    [$.keyword_as_id, $.modifier],
    [$.lvalue, $.primary_expr, $.keyword_as_id],
    [$.compilation_unit, $.dangling_div],
    [$.compilation_unit, $.dangling_close_comment],
    [$.compilation_unit, $.on_block_stmt],
    [$.implicit_variables_block, $.statement],
    [$.call_stmt, $.primary_expr],
    [$.primary_expr, $.type_name],
    [$.call_stmt, $.primary_expr, $.type_name],
    [$.function_decl, $.type_name],
    [$.type_decl],
    [$.event_decl, $.qualified_name],
    [$.block],
    [$.create_stmt, $.expression],
    [$.call_stmt],
    [$.sql_body],
    [$.variable_decl],
    [$.global_type_decl],
    [$.forward_type_decl],
    [$.global_type_decl, $.keyword_as_id],
    [$.forward_type_decl, $.keyword_as_id],
    [$.type_decl, $.keyword_as_id],
    [$.lvalue, $.ui_id, $.qualified_name],
    [$.ui_id, $.qualified_name],
    [$.lvalue, $.ui_id],
    [$.event_decl, $.empty_stmt],
    [$.function_decl, $.empty_stmt],
    // [$.block, $.if_stmt] is NOT needed with then_nl: multi-line IF is syntactically unique
    [$.arg_list, $.primary_expr],
      [$.member_init_value, $.literal, $.keyword_as_id],
      [$.member_init_value, $.literal],
      [$.member_init_value, $.keyword_as_id],
      [$.forward_type_decl, $.global_type_decl, $.keyword_as_id],
      [$.forward_type_decl, $.variable_decl],
      [$.global_type_decl, $.variable_decl],
      [$.type_decl, $.variable_decl],
      [$.global_type_decl, $.modifier, $.keyword_as_id],
      [$.forward_type_decl, $.modifier, $.keyword_as_id],
      [$.function_decl, $.variable_decl],
      [$.function_decl, $.modifier],
      [$.function_decl, $.keyword_as_id],
      [$.event_decl, $.variable_decl],
      [$.create_stmt, $.primary_expr],
      [$.create_stmt, $.expression, $.primary_expr],
      [$.create_stmt, $.expression],
      [$.expression, $.primary_expr],
    ],

  // ── The word rule tells tree-sitter what identifiers look like ───────────
  word: $ => $.identifier,

  // ══════════════════════════════════════════════════════════════════════════
  // RULES
  // ══════════════════════════════════════════════════════════════════════════
  rules: {

    // ── Top level ──────────────────────────────────────────────────────────
    compilation_unit: $ => seq(
      optional($.export_header),
      repeat(choice(
        $.forward_block,
        $.global_type_decl,
        $.type_decl,
        $.prototype_block,
        $.global_variables_block,
        $.type_variables_block,
        $.shared_variables_block,
        $.implicit_variables_block,   // FIX #4
        $.function_decl,
        $.event_decl,
        $.on_block,
        $.on_stub,
        $.statement,
        $.data_window_block,
        '/',   // DanglingDiv — eats stray / at global level
        '.',   // DanglingDot
        seq('*', '/'),  // DanglingCloseComment — eats stray */ at global level
      )),
    ),

    export_header: $ => repeat1(choice(
      $.pb_export_header,
      $.pb_export_comments,
    )),

    // ── DataWindow block (opaque — content captured by DW_MODE) ───────────
    data_window_block: $ => seq(
      $.dw_start,
      repeat($.dw_text),
      optional($.dw_end),
    ),

    // ── Forward block ─────────────────────────────────────────────────────
    forward_block: $ => seq(
      $.kw_forward,
      optional($.kw_prototypes),
      repeat(choice(
        $.function_prototype,
        $.event_prototype,
        $.forward_type_decl,
        $.global_variables_block,
        $.type_variables_block,
        $.shared_variables_block,
        // global TYPENAME VARNAME (e.g. global transaction sqlca)
        seq($.kw_global, $.type_name, $.ui_id, optional(';')),
      )),
      choice(
        seq($.kw_end, $.kw_forward, optional($.kw_prototypes)),
        seq($.kw_end, $.kw_prototypes),
      ),
    ),

    function_prototype: $ => prec.right(choice(
      seq(
        optional($.access_modifier), optional($.kw_global),
        $.kw_function, optional($.type_name), $.qualified_name,
        '(', optional($.param_list), ')',
        optional($.throws_clause), optional(';'),
      ),
      seq(
        optional($.access_modifier), optional($.kw_global),
        $.kw_subroutine, $.qualified_name,
        '(', optional($.param_list), ')',
        optional($.throws_clause), optional(';'),
      ),
    )),

    throws_clause: $ => seq($.kw_throws, $.qualified_name),

    event_prototype: $ => prec.right(seq(
      $.kw_event,
      optional(seq($.kw_type, $.any_id)),
      $.qualified_name,
      optional($.any_id),  // optional PBM event ID, e.g. pbm_custom51
      optional(seq('(', optional($.param_list), ')')),
      optional(';'),
    )),

    // ── Global type decl ──────────────────────────────────────────────────
    // global_type_decl: "global type Name from Base ... end type"
    // end type is REQUIRED so the parser greedily consumes all struct_member_decl.
    global_type_decl: $ => prec(3, seq(
      optional($.access_modifier),
      $.kw_global, $.kw_type,
      $.ui_id,
      optional(seq($.kw_from, $.type_ref)),
      optional(seq($.kw_within, $.qualified_name)),
      optional($.kw_autoinstantiate),
      repeat($.struct_member_decl),
      seq($.kw_end, $.kw_type),
    )),

    // ── Forward type decl ─────────────────────────────────────────────────
    forward_type_decl: $ => prec(3, seq(
      optional($.access_modifier),
      optional($.kw_global),
      $.kw_type,
      $.ui_id,
      optional(seq($.kw_from, $.type_ref)),
      optional(seq($.kw_within, $.qualified_name)),
      optional($.kw_autoinstantiate),
      repeat($.struct_member_decl),
      seq($.kw_end, $.kw_type),
    )),

    // ── Type decl ─────────────────────────────────────────────────────────
    // type_decl: like global_type_decl but starts with just kw_type (no global)
    // end type is REQUIRED so the parser greedily consumes all struct_member_decl.
    type_decl: $ => prec(3, seq(
      optional($.access_modifier),
      $.kw_type,
      $.ui_id,
      optional(seq($.kw_from, $.type_ref)),
      optional(seq($.kw_within, $.qualified_name)),
      optional($.kw_autoinstantiate),
      repeat($.struct_member_decl),
      seq($.kw_end, $.kw_type),
    )),

    // ── External DLL prototype block ──────────────────────────────────────
    prototype_block: $ => seq(
      $.kw_type, $.kw_prototypes,
      repeat($.external_function_decl),
      $.kw_end, $.kw_prototypes,
    ),

    external_function_decl: $ => prec.right(choice(
      seq(
        $.kw_function, optional($.type_name), $.qualified_name,
        '(', optional($.param_list), ')',
        optional($.continuation),  // & before LIBRARY on next line
        $.kw_library, $.string_literal,
        optional($.continuation),
        optional(seq($.kw_alias, $.kw_for, $.string_literal)),
        optional(';'),
      ),
      seq(
        $.kw_subroutine, $.qualified_name,
        '(', optional($.param_list), ')',
        optional($.continuation),
        $.kw_library, $.string_literal,
        optional($.continuation),
        optional(seq($.kw_alias, $.kw_for, $.string_literal)),
        optional(';'),
      ),
    )),

    // ── Struct member decl (inside type blocks) ───────────────────────────
    // catch-all `statement` prevents backtracking cascade on unexpected lines
    struct_member_decl: $ => prec.right(choice(
      $.event_prototype,
      seq(
        $.ui_id, $.ui_id,
        optional(seq('[', optional($.number), ']')),
        optional(seq('=', $.member_init_value)),
        optional(';'),
      ),
      $.statement,
    )),

    member_init_value: $ => prec(1, choice(
      seq(optional('-'), $.number),
      $.string_literal,
      $.kw_true, $.kw_false, $.kw_null,
      $.expression,
      seq('{', optional(seq($.member_init_value, repeat(seq(',', $.member_init_value)))), '}'),
    )),

    // ── Variables blocks ──────────────────────────────────────────────────
    global_variables_block: $ => seq(
      $.kw_global, $.kw_variables,
      repeat(choice(
        seq($.access_modifier, ':'),
        $.variable_decl,
      )),
      $.kw_end, $.kw_variables,
    ),

    type_variables_block: $ => seq(
      $.type_var_header,
      repeat(choice(
        seq($.access_modifier, ':'),
        $.variable_decl,
      )),
      $.kw_end, $.kw_variables,
    ),

    shared_variables_block: $ => seq(
      $.kw_shared, $.kw_variables,
      repeat(choice(
        seq($.access_modifier, ':'),
        $.variable_decl,
      )),
      $.kw_end, $.kw_variables,
    ),

    // FIX #4: implicit instance variables (common in .srw/.sru)
    implicit_variables_block: $ => seq(
      repeat1($.variable_decl),
      $.kw_end, $.kw_variables,
    ),

    // ── Instance var block: "type SomeClass ... end SomeClass" ────────────
    // instance_var_block ends with "end ClassName" (not "end type").
    // Using $.identifier (not $.any_id) for the closing name guarantees
    // the scanner emits a plain identifier (not KW_TYPE), so 'end type'
    // can ONLY close type_decl, never instance_var_block.
    instance_var_block: $ => seq(
      $.kw_type, $.any_id,
      repeat($.instance_var_decl),
      $.kw_end, $.identifier,
    ),

    instance_var_decl: $ => prec.right(seq(
      $.ui_id,
      $.variable_declarator,
      repeat(seq(',', $.variable_declarator)),
      optional(';'),
    )),

    // ── on event stubs (no end on) ────────────────────────────────────────
    // Handles two forms of on-stub (single-line or bare, no end on):
    //   Form 1: 'on eventname; [inline_code]'  (semicolon form with optional body)
    //   Form 2: 'on eventname'                  (bare form, no semicolon, no body)
    // on_block (prec.right(2)) wins over on_stub when dotted name + 'end on' follows.
    on_stub: $ => prec.right(choice(
      seq($.kw_on, $.any_id, ';', optional($.statement)),
      seq($.kw_on, $.any_id),
    )),

    // ── on...end on  blocks ───────────────────────────────────────────────
    // Higher precedence (2) ensures on_block beats on_stub when 'end on' follows.
    on_block: $ => prec.right(2, seq(
      $.kw_on, seq($.ui_id, repeat(seq(choice('.', '::', '`'), $.any_id))),
      optional($.block),
      choice(seq($.kw_end, $.kw_on), $.kw_end),
      optional(';'),
    )),

    // ── Function / event declarations ─────────────────────────────────────
    // With explicit return type: public function integer myFn(...)
    // Without explicit return type: public function myFn(...)
    // The optional return type + optional GLOBAL creates deep ambiguity if
    // modeled as free optional(any_id) optional(kw_global).
    // Solution: use access_modifier + optional(kw_global) prefix as a single
    // anchor; the function keyword disambiguates from expression contexts.
    // prec.right(4,...) ensures function_decl wins over variable_decl when
    // 'global function ...' or 'global subroutine ...' is ambiguous.
    function_decl: $ => prec.right(4, choice(
      // public/private/protected? global? function retType? name(...)
      seq(
        optional($.access_modifier),
        optional($.kw_global),
        $.kw_function, optional($.type_name), $.qualified_name,
        '(', optional($.param_list), ')',
        optional($.throws_clause), optional(';'),
        optional($.block),
        $.end_func,
      ),
      seq(
        optional($.access_modifier),
        optional($.kw_global),
        $.kw_subroutine, $.qualified_name,
        '(', optional($.param_list), ')',
        optional($.throws_clause), optional(';'),
        optional($.block),
        $.end_func,
      ),
    )),

    event_decl: $ => seq(
      $.kw_event,
      optional(seq($.kw_type, $.any_id)),
      $.qualified_name,
      optional(seq('(', optional($.param_list), ')')),
      optional(';'),
      optional($.block),
      seq($.kw_end, $.kw_event),
    ),

    param_list: $ => seq(
      $.param,
      repeat(seq(',', $.param)),
    ),

    param: $ => seq(
      optional(choice($.kw_ref, $.kw_readonly)),
      $.type_name,
      $.any_id,
      optional($.array_suffix),
      optional(seq('=', $.expression)),
    ),

    // ── Block ─────────────────────────────────────────────────────────────
    // Uses repeat1 so the rule itself never matches empty.
    // Call sites that need an optional block use optional($.block).
    block: $ => repeat1($.statement),

    // ── Statements ────────────────────────────────────────────────────────
    // ORDER MATTERS — mirrors PowerScriptParser.g4 statement rule ordering
    statement: $ => choice(
      $.sql_statement,          // SQL FIRST — prevents DECLARE ambiguity
      $.variable_decl,
      $.assignment_stmt,
      $.post_increment_stmt,    // lvalue ++
      $.post_decrement_stmt,    // lvalue --
      $.pre_increment_stmt,     // ++ lvalue
      $.pre_decrement_stmt,     // -- lvalue
      $.call_stmt,
      $.post_event_stmt,
      $.create_stmt,
      $.if_stmt,
      $.choose_stmt,
      $.for_stmt,
      $.do_stmt,
      $.with_stmt,
      $.try_catch_stmt,
      $.throw_stmt,
      $.raise_stmt,
      $.goto_stmt,
      $.halt_stmt,
      $.destroy_stmt,
      $.return_stmt,
      $.exit_stmt,
      $.label_decl,             // BOMB 6 FIX: GOTO target labels
      $.on_block_stmt,          // FIX: on...end on inside method bodies (.srm)
      $.dangling_member_access, // catches getparent(). typos
      $.dangling_div,           // catches stray /
      $.dangling_close_comment, // catches stray */ (nested block comments)
      $.expression_stmt,
      $.empty_stmt,
    ),

    variable_decl: $ => prec.right(seq(
      optional($.access_modifier),
      repeat($.modifier),
      $.type_name,
      $.variable_declarator,
      repeat(seq(',', $.variable_declarator)),
      optional(';'),
    )),

    variable_declarator: $ => seq(
      $.ui_id,
      optional($.array_suffix),
      optional(seq('=', $.expression)),
    ),

    modifier: $ => prec(2, choice($.kw_readonly, $.kw_shared, $.kw_global, $.kw_constant)),

    // lvalue handles: obj[i].prop, this.arr[i], super::method, etc.
    // prec.right: greedy chain
    lvalue: $ => prec.right(seq(
      choice($.kw_this, $.kw_super, $.kw_parent, $.any_id),
      optional(choice($.array_index, $.empty_array_index)),
      repeat(seq(
        choice('.', '::', '`'),
        $.any_id,
        optional(choice($.array_index, $.empty_array_index)),
      )),
    )),

    assignment_stmt: $ => prec.right(choice(
      seq($.lvalue, '=',  $.expression, optional(';')),
      seq($.lvalue, '+=', $.expression, optional(';')),  // FIX #8
      seq($.lvalue, '-=', $.expression, optional(';')),
      seq($.lvalue, '*=', $.expression, optional(';')),
      seq($.lvalue, '/=', $.expression, optional(';')),
      seq($.lvalue, '^=', $.expression, optional(';')),  // BOMB 3 FIX
    )),

    post_increment_stmt: $ => prec.right(seq($.lvalue, '+', '+', optional(';'))),
    post_decrement_stmt: $ => prec.right(seq($.lvalue, '-', '-', optional(';'))),
    pre_increment_stmt:  $ => prec.right(seq('+', '+', $.lvalue, optional(';'))),
    pre_decrement_stmt:  $ => prec.right(seq('-', '-', $.lvalue, optional(';'))),

    call_stmt: $ => prec.right(choice(
      seq($.qualified_name, optional(seq('(', optional($.arg_list), ')')), optional(';')),
      seq($.lvalue, '(', optional($.arg_list), ')', optional(';')),
      seq($.kw_call, $.kw_super, '::', $.qualified_name, optional(seq('(', optional($.arg_list), ')')), optional(';')),
      seq($.kw_call, $.qualified_name, optional(seq('(', optional($.arg_list), ')')), optional(';')),
    )),

    post_event_stmt: $ => prec.right(seq(
      $.kw_post, $.kw_event, $.qualified_name,
      '(', optional($.arg_list), ')',
      optional(';'),
    )),

    create_stmt: $ => prec.right(choice(
      seq($.kw_create, $.qualified_name, optional(';')),
      seq($.kw_create, $.kw_using, $.expression, optional(';')),
    )),

    // BOMB 6 FIX: REF/READONLY inline in argList so ArgListContext.expression() works
    arg_list: $ => seq(
      optional(choice($.kw_ref, $.kw_readonly)),
      $.expression,
      repeat(seq(',', optional(choice($.kw_ref, $.kw_readonly)), $.expression)),
    ),

    // Multi-line IF: 'then' followed by newline => then_nl token fires => multi-line branch.
    // Single-line IF: 'then' followed by statement on same line => then_nl absent => inline branch.
    // This disambiguates at parse time WITHOUT GLR forking, eliminating [block, if_stmt] conflict.
    if_stmt: $ => prec.right(choice(
      seq(
        $.kw_if, $.expression, $.kw_then, $.then_nl,
        optional($.block),
        repeat(seq($.kw_elseif, $.expression, $.kw_then, $.then_nl, optional($.block))),
        optional(seq($.kw_else, $.then_nl, optional($.block))),
        seq($.kw_end, $.kw_if),
        optional(';'),
      ),
      seq($.kw_if, $.expression, $.kw_then, $.statement),
    )),

    choose_stmt: $ => prec.right(seq(
      $.kw_choose, $.kw_case, $.expression,
      repeat1($.case_block),
      optional(seq($.kw_case, $.kw_else, $.block)),
      seq($.kw_end, $.kw_choose),
      optional(';'),
    )),

    case_block: $ => prec.right(seq(
      $.kw_case,
      $.case_condition,
      repeat(seq(',', $.case_condition)),
      optional($.block),
    )),

    case_condition: $ => choice(
      seq($.kw_is, $.relational_op, $.expression),
      seq($.expression, $.kw_to, $.expression),
      $.expression,
    ),

    for_stmt: $ => prec.right(seq(
      $.kw_for, $.qualified_name, '=', $.expression, $.kw_to, $.expression,
      optional(seq($.kw_step, $.expression)),
      optional($.block),
      $.kw_next,
      optional(';'),
    )),

    // 3 DO variants from PowerScriptParser.g4
    do_stmt: $ => prec.right(choice(
      seq(
        $.kw_do, choice($.kw_while, $.kw_until), $.expression,
        $.block,
        choice($.kw_loop, seq($.kw_end, optional(choice($.kw_while, $.kw_until)))),
        optional(';'),
      ),
      seq(
        $.kw_do, $.block,
        choice($.kw_loop, seq($.kw_end, optional($.kw_do))),
        choice($.kw_while, $.kw_until), $.expression,
        optional(';'),
      ),
      seq(
        $.kw_do, $.block,
        choice($.kw_loop, seq($.kw_end, optional($.kw_do))),
        optional(';'),
      ),
    )),

    with_stmt: $ => prec.right(seq(
      $.kw_with, $.expression, $.block,
      seq($.kw_end, $.kw_with), optional(';'),
    )),

    // TRY...CATCH...FINALLY...END TRY  (multiple typed/untyped CATCH supported)
    try_catch_stmt: $ => prec.right(seq(
      $.kw_try, $.block,
      repeat(seq(
        $.kw_catch,
        optional(seq('(', optional($.param), ')')),
        $.block,
      )),
      optional(seq($.kw_finally, $.block)),
      seq($.kw_end, $.kw_try), optional(';'),
    )),

    throw_stmt:   $ => prec.right(seq($.kw_throw,   $.expression, optional(';'))),
    raise_stmt:   $ => prec.right(seq($.kw_raise,   $.expression, optional(';'))),
    goto_stmt:    $ => prec.right(seq($.kw_goto,    $.any_id, optional(';'))),
    halt_stmt:    $ => prec.right(seq($.kw_halt,    optional($.kw_close), optional(';'))),
    destroy_stmt: $ => prec.right(seq($.kw_destroy, $.qualified_name, optional(';'))),
    return_stmt:  $ => prec.right(choice(
      seq($.kw_return, $.return_nl),                        // return at end-of-line (no expression)
      seq($.kw_return, $.expression, optional(';')),         // return with expression
      seq($.kw_return, optional(';')),                       // return; or bare return
    )),
    exit_stmt:    $ => prec.right(seq($.kw_exit,    optional(';'))),

    // BOMB 6 FIX: GOTO label declarations  e.g.  label_err:
    label_decl: $ => prec.right(seq($.any_id, ':', optional(';'))),

    // FIX: on...end on blocks nested inside method bodies (.srm menu files)
    on_block_stmt: $ => $.on_block,

    dangling_member_access: $ => prec.right(seq($.expression, '.', optional(';'))),
    dangling_div:           $ => prec.right(seq('/', optional(';'))),
    dangling_close_comment: $ => prec.right(1, seq('*', '/')),
    expression_stmt:        $ => prec.right(seq($.expression, optional(';'))),
    empty_stmt:             $ => ';',

    // ── SQL statements ────────────────────────────────────────────────────
    // SQL block is first in `statement` to prevent DECLARE ambiguity.
    // sqlBody uses an explicit token list (no negated sets in tree-sitter).
    sql_statement: $ => prec.right(choice(
      seq($.kw_insert,     $.sql_body, optional(seq($.kw_using, $.transaction_ref)), optional(';')),
      seq($.kw_update,     $.sql_body, optional(seq($.kw_using, $.transaction_ref)), optional(';')),
      seq($.kw_delete,     $.sql_body, optional(seq($.kw_using, $.transaction_ref)), optional(';')),
      seq($.kw_select,     $.sql_body, optional(seq($.kw_using, $.transaction_ref)), optional(';')),
      seq($.kw_selectblob, $.sql_body, optional(seq($.kw_using, $.transaction_ref)), optional(';')),  // BOMB 4 FIX
      seq($.kw_updateblob, $.sql_body, optional(seq($.kw_using, $.transaction_ref)), optional(';')),  // BOMB 4 FIX
      seq($.kw_commit,     optional(seq($.kw_using, $.transaction_ref)), optional(';')),
      seq($.kw_rollback,   optional(seq($.kw_using, $.transaction_ref)), optional(';')),
      // Cursor operations — DYNAMIC variant supported
      seq($.kw_declare, $.any_id, optional($.kw_dynamic), $.kw_cursor, $.kw_for,
          $.sql_body, optional(seq($.kw_using, $.transaction_ref)), optional(';')),
      seq($.kw_open,  optional($.kw_dynamic), $.any_id, optional(seq($.kw_using, $.transaction_ref)), optional(';')),
      seq($.kw_fetch, optional($.kw_dynamic), $.any_id, $.kw_into, $.host_var_list,
          optional(seq($.kw_using, $.transaction_ref)), optional(';')),
      seq($.kw_close, optional($.kw_dynamic), $.any_id, optional(seq($.kw_using, $.transaction_ref)), optional(';')),
      seq($.kw_prepare, $.any_id, $.kw_from, $.host_var, optional(seq($.kw_using, $.transaction_ref)), optional(';')),
      seq($.kw_execute, $.any_id, optional(seq($.kw_using, $.transaction_ref)), optional(';')),
      seq($.kw_execute, $.kw_immediate, $.host_var, optional(seq($.kw_using, $.transaction_ref)), optional(';')),
      seq($.kw_connect,    optional(seq($.kw_using, $.transaction_ref)), optional(';')),
      seq($.kw_disconnect, optional(seq($.kw_using, $.transaction_ref)), optional(';')),
    )),

    // Safe SQL body: consumes all tokens except SEMI and USING.
    // Strings are consumed first so embedded semicolons are safe.
    sql_body: $ => repeat1($.sql_token),

    sql_token: $ => choice(
      $.string_literal,  // strings first — ; inside is harmless
      $.number,
      $.identifier,
      '+', '-', '*', '/',
      '=', '<', '>', '<=', '>=', '<>',
      '(', ')', ',', '.',
      '[', ']',
      seq(':', $.any_id),   // host variables :varname
      // Keyword tokens that can appear inside SQL body
      $.kw_not, $.kw_and, $.kw_or, $.kw_is, $.kw_null,
      $.kw_into,   // SELECT col INTO :var FROM ...
      $.kw_select, $.kw_from, $.kw_where, $.kw_join, $.kw_order, $.kw_group,
      $.kw_having, $.kw_like, $.kw_between, $.kw_in, $.kw_exists,
      $.kw_insert, $.kw_update, $.kw_delete,   // nested DML in SQL body
      $.kw_case, $.kw_then, $.kw_else,         // SQL CASE expressions
      $.kw_for,                                 // FOR UPDATE / cursor
      $.kw_on,                                  // JOIN ... ON ...
      $.kw_when,                                // SQL CASE WHEN ... THEN
    ),

    // SQL keywords not otherwise in PB keyword list
    kw_where:   _ => /[wW][hH][eE][rR][eE]/,
    kw_join:    _ => /[jJ][oO][iI][nN]/,
    kw_order:   _ => /[oO][rR][dD][eE][rR]/,
    kw_group:   _ => /[gG][rR][oO][uU][pP]/,
    kw_having:  _ => /[hH][aA][vV][iI][nN][gG]/,
    kw_like:    _ => /[lL][iI][kK][eE]/,
    kw_between: _ => /[bB][eE][tT][wW][eE][eE][nN]/,
    kw_in:      _ => /[iI][nN]/,
    kw_exists:  _ => /[eE][xX][iI][sS][tT][sS]/,
    kw_when:    _ => /[wW][hH][eE][nN]/,

    transaction_ref: $ => $.any_id,

    host_var_list: $ => seq($.host_var, repeat(seq(',', $.host_var))),
    host_var:      $ => seq(':', $.any_id),

    // ── Expressions ───────────────────────────────────────────────────────
    // Precedence mirrors the expression rule in PowerScriptParser.g4 exactly.
    expression: $ => choice(
      $.primary_expr,

      // CREATE expressions
      seq($.kw_create, $.qualified_name),
      seq($.kw_create, $.kw_using, $.expression),

      // Array access (tightest structural binding)
      prec.left(PREC.ARRAY,  seq($.expression, choice($.array_index, $.empty_array_index))),

      // Object calls: expr.DYNAMIC? POST? EVENT? anyId(args?)
      prec.left(PREC.MEMBER, seq(
        $.expression, '.',
        optional(choice($.kw_dynamic, $.kw_static)),
        optional(choice($.kw_post, $.kw_trigger)),
        optional(choice($.kw_event, $.kw_function)),
        $.ui_id,
        optional(seq('(', optional($.arg_list), ')')),
      )),

      // Member access
      prec.left(PREC.MEMBER, seq($.expression, '.', $.ui_id)),
      prec.left(PREC.MEMBER, seq($.expression, '`', $.ui_id)),

      // .object.prop  (ObjectAccess)
      prec.left(PREC.MEMBER, seq($.expression, '.', $.kw_object, '.', $.any_id)),

      // Function call
      prec.left(PREC.CALL, seq($.expression, '(', optional($.arg_list), ')')),

      // Unary
      prec.right(PREC.UNARY, seq('-',      $.expression)),
      prec.right(PREC.UNARY, seq('+',      $.expression)),
      prec.right(PREC.UNARY, seq($.kw_not, $.expression)),

      // BOMB 3 FIX: ^ exponentiation (higher than * /)
      prec.right(PREC.POWER, seq($.expression, '^', $.expression)),

      prec.left(PREC.MUL,        seq($.expression, choice('*', '/'), $.expression)),
      prec.left(PREC.ADD,        seq($.expression, choice('+', '-'), $.expression)),
      prec.left(PREC.RELATIONAL, seq($.expression, $.relational_op, $.expression)),
      prec.left(PREC.EQUALITY,   seq($.expression, choice('=', '<>'), $.expression)),
      prec.left(PREC.AND,        seq($.expression, $.kw_and, $.expression)),
      prec.left(PREC.OR,         seq($.expression, $.kw_or,  $.expression)),
    ),

    primary_expr: $ => choice(
      $.qualified_name,
      $.literal,
      seq('(', $.expression, ')'),
      $.kw_this,
      $.kw_super,
      $.kw_parent,   // Fix 1: parent window/control reference
      // Array literals: {1, 2, 3}
      seq('{', optional(seq($.expression, repeat(seq(',', $.expression)))), '}'),
      // CREATE as expression: ds = create datastore; ds = create using expr
      seq($.kw_create, $.kw_using, $.expression),
      seq($.kw_create, $.qualified_name),
    ),

    literal: $ => choice(
      $.string_literal,
      $.number,
      $.kw_true,
      $.kw_false,
      $.kw_null,
      $.enum_literal,   // BOMB 2 FIX: Right!, Center!, Update!
    ),

    relational_op: $ => choice('<', '>', '<=', '>='),

    // ── Names ─────────────────────────────────────────────────────────────

    type_name: $ => seq(
      $.qualified_name,
      optional($.array_suffix),
      optional($.precision_suffix),
    ),

    // END deliberately excluded — eating END breaks block closures
    // Mirrors keywordAsId rule in PowerScriptParser.g4
    // prec(-1): structural rules always outrank keyword_as_id
    keyword_as_id: $ => prec(-1, choice(
      $.kw_create,     $.kw_destroy,    $.kw_object,
      $.kw_close,      $.kw_open,       $.kw_default,    $.kw_is,
      $.kw_with,       $.kw_case,
      $.kw_function,   $.kw_subroutine, $.kw_type,       $.kw_structure,
      $.kw_call,       $.kw_post,       $.kw_super,
      $.kw_connect,    $.kw_disconnect, $.kw_execute,    $.kw_on,
      $.kw_dynamic,    $.kw_static,     $.kw_trigger,
      $.kw_select,     $.kw_insert,     $.kw_update,     $.kw_delete,
      $.kw_commit,     $.kw_rollback,   $.kw_declare,    $.kw_fetch,
      $.kw_prepare,    $.kw_selectblob, $.kw_updateblob, // BOMB 4 FIX
      $.kw_readonly,   $.kw_global,     $.kw_constant,
      $.kw_private,    $.kw_public,     $.kw_protected,
      $.kw_into,       $.kw_from,       $.kw_using,
      $.kw_true,       $.kw_false,      $.kw_null,       $.kw_this,
      $.kw_while,      $.kw_until,      $.kw_step,
      $.kw_autoinstantiate, $.kw_library, $.kw_alias,
      $.kw_parent,     $.kw_goto,       $.kw_halt,       $.kw_throws,
      $.kw_finally,    $.kw_continue,
    )),

    any_id: $ => choice($.identifier, $.keyword_as_id),

    // Allows PB menu separator names like m_- or m_-1
    // prec.right ensures the optional tail is consumed greedily
    ui_id: $ => prec.right(seq($.any_id, optional(seq('-', optional(choice($.any_id, $.number)))))),

    // Supports . :: ` separators
    // prec.right: greedy dot-chain (a.b.c parsed as deep, not a then .b.c)
    qualified_name: $ => prec.right(seq(
      $.any_id,
      repeat(seq(choice('.', '::', '`'), $.ui_id)),
    )),

    access_modifier: $ => choice($.kw_private, $.kw_public, $.kw_protected),

    type_ref: $ => choice(
      $.qualified_name,
      $.kw_object,
      $.kw_structure,
    ),

    // Arrays: [] or [expr TO expr, ...]
    array_suffix: $ => choice(
      seq('[', ']'),
      seq('[', $.array_bound, repeat(seq(',', $.array_bound)), ']'),
    ),

    array_bound: $ => seq($.expression, optional(seq($.kw_to, $.expression))),

    precision_suffix: $ => seq('{', $.number, '}'),

    array_index:       $ => seq('[', $.expression, repeat(seq(',', $.expression)), ']'),
    empty_array_index: $ => seq('[', ']'),

    // ── Tokens ────────────────────────────────────────────────────────────

    // BOMB 6 FIX: tilde-delimited strings ~"text~" and ~'text~'
    // BOMB 1 FIX: tilde escapes ~n ~t ~r ~" ~' ~~
    string_literal: _ => token(choice(
      seq('"',  repeat(choice(/[^"\n~]/, seq('~', /[^\n]/))), '"'),
      seq("'",  repeat(choice(/[^'\n~]/, seq('~', /[^\n]/))), "'"),
      seq('~"', repeat(choice(/[^~]/,  seq('~', /[^"]/  ))), '~"'),   // tilde-delimited
      seq("~'", repeat(choice(/[^~]/,  seq('~', /[^']/  ))), "~'"),
    )),

    // FIX #10: unified number token — integers and decimals
    number: _ => /[0-9]+(\.[0-9]+)?/,

    // BOMB 1 FIX: no hyphen; BOMB 5 FIX: no ! (ENUM_LITERAL handles !)
    // Unicode range for non-ASCII identifiers
    identifier: _ => /[a-zA-Z_$\u0080-\uFFFF][a-zA-Z0-9_$\u0080-\uFFFF]*/,

    line_comment:  _ => token(seq('//', /.*/)),
    // block_comment is now handled by external scanner (supports nested /* */)
  },
});
