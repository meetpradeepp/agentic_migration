from setuptools import setup

setup(
    packages=["tree_sitter_powerbuilder"],
    package_dir={"tree_sitter_powerbuilder": "bindings/python/tree_sitter_powerbuilder"},
    package_data={"tree_sitter_powerbuilder": ["*.dll", "*.so"]},
)
