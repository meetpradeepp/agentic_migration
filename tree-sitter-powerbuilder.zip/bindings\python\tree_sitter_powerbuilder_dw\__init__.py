"""
tree-sitter-powerbuilder-dw — DataWindow grammar for tree-sitter.

Usage:
    import tree_sitter_powerbuilder_dw
    from tree_sitter import Language, Parser

    lang = Language(tree_sitter_powerbuilder_dw.language())
    parser = Parser(lang)

    with open("myfile.srd", "rb") as f:
        tree = parser.parse(f.read())

    print("Has errors:", tree.root_node.has_error)
"""

import ctypes
import os
import sys
from pathlib import Path

_HERE = Path(__file__).parent


def _load_lib():
    # Windows: .dll bundled alongside this __init__.py
    if sys.platform == "win32":
        _path = _HERE / "powerbuilder_dw.dll"
    else:
        # Linux/Mac: .so must be compiled from src-dw/ — see README
        _path = _HERE / "powerbuilder_dw.so"

    if not _path.exists():
        raise FileNotFoundError(
            f"Grammar library not found: {_path}\n"
            "On Linux/Mac, compile from source:\n"
            "  gcc -std=c11 -shared -O2 -fPIC -o powerbuilder_dw.so "
            "-I src src-dw/parser.c"
        )

    lib = ctypes.CDLL(str(_path))
    lib.tree_sitter_powerbuilder_dw.restype = ctypes.c_void_p
    return lib


_lib = _load_lib()


def language():
    """Return the tree-sitter language pointer for PowerBuilder DataWindow."""
    return _lib.tree_sitter_powerbuilder_dw()


__all__ = ["language"]
__version__ = "1.0.0"
