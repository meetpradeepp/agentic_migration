# Channel Test Harness — Quick-start Installation

## Prerequisites

- Python 3.13+
- [uv](https://docs.astral.sh/uv/getting-started/installation/) (recommended) **or** pip
- On Windows: Tesseract OCR installed and on PATH (for `citrix` channel)
- On Windows: PowerBuilder runtime installed (for `winpb` channel)

---

## Option A — One-command install (uv, recommended)

### Windows

```powershell
.\install.ps1
```

### Linux / macOS

```bash
chmod +x install.sh && ./install.sh
```

---

## Option B — Manual install with uv

```bash
# 1. Install uv if you don't have it
#    Windows:      winget install astral-sh.uv
#    Linux/macOS:  curl -LsSf https://astral.sh/uv/install.sh | sh

# 2. Create a virtual environment pinned to Python 3.13
uv venv --python 3.13

# 3. Install the harness wheel with the extras you need:
#
#   Angular (web) channel only:
uv pip install wheels/channel_test_harness-*.whl[angular]
#
#   Citrix (OCR) channel:
#   uv pip install wheels/channel_test_harness-*.whl[citrix]
#
#   Native Windows PB channel (Windows only):
#   uv pip install wheels/channel_test_harness-*.whl[winpb]
#
#   Oracle DB validator / JIT provisioner:
#   uv pip install wheels/channel_test_harness-*.whl[oracle]
#
#   Everything at once:
#   uv pip install wheels/channel_test_harness-*.whl[all]

# 4. Install Playwright browser (angular channel only)
uv run playwright install chromium

# 5. Copy the scaffold into your project directory
cp -r scaffold/ my_project/
cd my_project/

# 6. Configure environment
cp .env.example .env
# Edit .env and fill in credentials and URLs

# 7. Verify wiring — no app needed
CHANNEL=angular uv run behave --dry-run features/

# 8. Run a single channel
CHANNEL=angular uv run python main.py

# 9. Run all channels in parallel and generate an HTML report
uv run python main.py --channels angular citrix winpb --clean --html
```

---

## Option C — pip (no uv)

```bash
# 1. Create a virtual environment
python -m venv .venv
source .venv/bin/activate      # Windows: .venv\\Scripts\\activate

# 2. Install the harness wheel (replace [angular] with the extras you need)
pip install wheels/channel_test_harness-*.whl[angular]

# 3. Install Playwright browser (angular channel only)
playwright install chromium

# 4. Copy scaffold, configure .env, and run
cp -r scaffold/ my_project/ && cd my_project/
cp .env.example .env
CHANNEL=angular python -m behave --dry-run features/
```

---

## Channel extras reference

| Extra | Packages installed | Use when |
|---|---|---|
| `angular` | `playwright` | Angular / modern web UI channel |
| `citrix` | `pyautogui`, `pytesseract`, `Pillow` | Citrix screen-automation channel |
| `winpb` | `pywinauto`, `pyautogui`, `pytesseract`, `Pillow` | Native Windows PB channel |
| `oracle` | `oracledb` | Oracle DB validator or JIT provisioner |
| `all` | everything above | Full multi-channel setup |

---

## Next steps

See `docs/testing_strategy.md` — Section 12 (Team onboarding) for a
day-by-day adoption plan and common mistakes to avoid.
