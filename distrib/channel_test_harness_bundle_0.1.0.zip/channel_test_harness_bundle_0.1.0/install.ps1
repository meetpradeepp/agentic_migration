# install.ps1 — Windows install helper for channel-test-harness bundle
# Run from the bundle root directory: .\install.ps1
Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

Write-Host "=== Channel Test Harness — Windows installer (uv) ===" -ForegroundColor Cyan

# 0. Install uv if not already present
if (-not (Get-Command uv -ErrorAction SilentlyContinue)) {
    Write-Host "[0/5] Installing uv..."
    winget install astral-sh.uv --silent
    # Refresh PATH so uv is visible in this session
    $env:PATH = [System.Environment]::GetEnvironmentVariable('PATH','Machine') + ';' + `
                [System.Environment]::GetEnvironmentVariable('PATH','User')
}

# 1. Create venv pinned to Python 3.13
Write-Host "[1/5] Creating virtual environment..."
uv venv --python 3.13

# 2. Install wheel (angular extra by default; edit as needed)
Write-Host "[2/5] Installing harness wheel..."
$wheel = Get-ChildItem "wheels\*.whl" | Select-Object -First 1
if (-not $wheel) { Write-Error "No .whl file found in wheels/"; exit 1 }
# Change [angular] to [citrix], [winpb], [oracle], or [all] as needed
uv pip install "$($wheel.FullName)[angular]"

# 3. Install Playwright browser (angular channel only)
Write-Host "[3/5] Installing Playwright browser..."
uv run playwright install chromium

# 4. Copy scaffold
Write-Host "[4/5] Copying scaffold to my_project/ ..."
if (-not (Test-Path "my_project")) {
    Copy-Item -Recurse scaffold my_project
    Copy-Item .env.example my_project\.env.example
    Write-Host "     Scaffold copied to my_project/"
    Write-Host "     Edit my_project\.env and fill in your credentials."
} else {
    Write-Host "     my_project/ already exists — skipping scaffold copy."
}

# 5. Verify wiring (no app needed)
Write-Host "[5/5] Running Gherkin dry-run to verify step wiring..."
$env:CHANNEL = "angular"
$env:TEST_CSR_USERNAME = "dry-run"
$env:TEST_CSR_PASSWORD = "dry-run"
$env:MODERN_BASE_URL   = "http://localhost"
Push-Location my_project
uv run behave --dry-run features/ 2>&1 | Write-Host
Pop-Location

Write-Host ""
Write-Host "Done!  See docs\testing_strategy.md for next steps." -ForegroundColor Green
