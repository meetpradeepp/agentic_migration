# Channel Test Harness — Testing Strategy

**Document type**: Enterprise Testing Strategy  
**Applies to**: All teams adopting `channel-test-harness`  
**Maintained by**: QA Platform Team  
**Review cycle**: Quarterly  

---

## Contents

1. [Objectives](#1-objectives)
2. [Scope](#2-scope)
3. [Testing levels](#3-testing-levels)
4. [Channel strategy](#4-channel-strategy)
5. [Tag taxonomy and test planning](#5-tag-taxonomy-and-test-planning)
6. [Risk-based execution model](#6-risk-based-execution-model)
7. [Test data strategy](#7-test-data-strategy)
8. [Environment matrix](#8-environment-matrix)
9. [CI/CD pipeline stages](#9-cicd-pipeline-stages)
10. [Reporting and metrics](#10-reporting-and-metrics)
11. [Defect management](#11-defect-management)
12. [Team onboarding](#12-team-onboarding)
13. [Governance](#13-governance)

---

## 1. Objectives

The harness exists to answer one question with evidence:

> *When a CSR performs the same operation through different system interfaces, do all of them agree on the outcome?*

Secondary objectives:

| # | Objective | How the harness addresses it |
|---|---|---|
| 1 | **Parity assurance** | Runs identical Gherkin scenarios on every channel; compares outcomes numerically |
| 2 | **Regression prevention** | `@regression` suite runs on every PR; `@bug_*` tags permanently guard fixed defects |
| 3 | **Release confidence** | `@smoke @critical` scenarios form the release gate; must pass across all channels |
| 4 | **Traceability** | `@req_*` and `@story_*` tags map every automated scenario to an ALM/Jira item |
| 5 | **Velocity** | Parallel channel execution and shared Gherkin cut overall cycle time |

---

## 2. Scope

### In scope

- Functional parity testing across `angular`, `citrix`, and `winpb` channels
- API-level validation (system-of-record checks via REST or Oracle DB)
- UI vs SOR divergence detection (rendered value vs back-end value within a channel)
- Cross-channel value and pass/fail divergence detection
- Harness infrastructure (loader, result store, comparator, reporter)

### Out of scope

- Performance / load testing
- Security / penetration testing
- Accessibility auditing
- Unit testing of business logic inside the application under test
- Manual exploratory sessions (tracked as `@manual_only` but not automated)

---

## 3. Testing levels

The harness operates across three levels.  Each level has a different owner, runtime, and confidence boundary.

```
Level 3 — End-to-End BDD         (app + infra required; minutes to hours)
Level 2 — Gherkin dry-run        (Python only; seconds)
Level 1 — Harness unit tests     (Python only; < 2 seconds)
```

### Level 1 — Harness unit tests

**Runner**: `uv run pytest tests/`  
**Frequency**: Every commit (pre-push hook + CI)  
**Infrastructure required**: None — pure Python, no apps, no `.env`  

Covers the harness infrastructure itself:

| Test module | What it guards |
|---|---|
| `tests/test_loader.py` | Shared + feature-specific locator tiers; collision detection; `auto_discover`; cache invalidation |
| `tests/test_tags.py` | `extract_labels()` correctness; severity/type priority rules; `should_skip()` lifecycle |
| `tests/test_result_store.py` | JSON schema; append behaviour; rounding; label persistence; `clear()` |
| `tests/test_comparator.py` | `CLEAN`/`VALUE_DIV`/`PASSFAIL_DIV`/`INCOMPLETE`/`UNVALIDATED` status logic; `build_report_data()` breakdowns; requirements traceability |

**Pass criteria**: 100 % of tests green.  Any failure blocks merge.

### Level 2 — Gherkin dry-run

**Runner**: `uv run behave --dry-run <features-dir>`  
**Frequency**: Every PR that touches a `.feature` file or `steps/` directory  
**Infrastructure required**: Python env + `.env` credentials (no running app)  

Validates that every Gherkin sentence has a matching step definition.  Catches:
- Unimplemented steps (step definition missing)
- Renamed steps with orphaned `.feature` references
- Tag typos that would silently skip scenarios

**Pass criteria**: Zero undefined or missing steps.

### Level 3 — End-to-end BDD

**Runner**: `uv run python main.py --channels <list> --clean --html`  
**Frequency**: Nightly full suite; on-demand for PRs touching action/engine/locator code  
**Infrastructure required**: Running application(s), populated `.env`, test accounts  

This is where cross-channel parity is actually verified.  See [CI/CD pipeline stages](#9-cicd-pipeline-stages) for when each tag subset runs.

---

## 4. Channel strategy

### When to use each channel

| Channel | Key | Technology | Typical environment |
|---|---|---|---|
| Modern web | `angular` | Playwright (DOM) | All environments — headless in CI, headed locally |
| Legacy Citrix | `citrix` | PyAutoGUI + Tesseract OCR | Windows VM or Citrix delivery host |
| Native Windows PB | `winpb` | pywinauto UIA | Windows host with PB runtime installed |

### Channel execution rules

1. **Every scenario must produce a result on every channel it declares** — if a channel result file is missing, the comparator marks the scenario `INCOMPLETE` and the run fails.
2. **Channel-specific workarounds belong in the action class** — never in Gherkin or step definitions.
3. **Validation strategy is channel-aware by default** — `angular` uses `APIValidator`, `citrix`/`winpb` use `DBValidator`.  Override per scenario with `VALIDATION_STRATEGY` env var or `@readonly` tag.
4. **A scenario tagged `@readonly` skips SOR validation on all channels** — it only verifies that the UI rendered without error.

### Adding a new channel

1. Create `engines/<new>_engine.py` implementing `launch()` / `quit()`
2. Create `actions/<new>_actions.py` subclassing `BaseActions`
3. Register in `environment.py` `before_all()` under the new channel key
4. Add a `"<new>"` block to every locator JSON intent the feature uses
5. Add the channel key to the `matrix` in `.github/workflows/ci.yml`

---

## 5. Tag taxonomy and test planning

Tags are the primary mechanism for controlling which scenarios run in which context.  Every scenario **must** carry at least one severity tag and one type tag.

### Mandatory tags (every scenario)

| Category | Tags | Rule |
|---|---|---|
| Severity | `@critical` `@high` `@medium` `@low` | Exactly one per scenario.  Determines release-gate impact. |
| Type | `@smoke` `@regression` `@sanity` `@e2e` `@exploratory` | Exactly one per scenario.  Determines CI stage. |

### Recommended tags

| Category | Tags | Usage |
|---|---|---|
| Area | `@area_<domain>` | Feature-level tag matching the feature folder name |
| Traceability | `@req_<ID>` `@story_<ID>` `@bug_<ID>` | Link to ALM/Jira; required for `@critical` and `@high` scenarios |
| Data | `@requires_clean_account` `@requires_prepaid_account` `@requires_enterprise_account` `@readonly` | Controls account provisioning lifecycle |

### Lifecycle tags (use sparingly)

| Tag | Behaviour | When to use |
|---|---|---|
| `@wip` | Excluded from all CI runs | Scenario under active development; remove before merging to `main` |
| `@skip_ci` | Excluded only in CI (`IS_CI=true`) | Scenario requires manual setup that CI cannot provide |
| `@manual_only` | Always skipped | Scenario is documented for traceability but will never be automated |

### Tag-based execution selection

```bash
# Release gate — smoke tests only
uv run behave --tags "@smoke and not @wip"

# Full regression excluding slow E2E
uv run behave --tags "@regression and not @e2e and not @wip"

# Critical path across all types
uv run behave --tags "@critical and not @wip"

# Single functional area
uv run behave --tags "@area_adjustments and not @wip"

# Regression guard for a specific Jira fix
uv run behave --tags "@bug_FIX-789"
```

---

## 6. Risk-based execution model

Test execution is tiered by severity.  Higher-severity failures block sooner and escalate faster.

| Severity | Release gate? | Failure action | Escalation |
|---|---|---|---|
| `@critical` | **Yes — blocks release** | Stop all channels immediately; page on-call | P1 incident within 15 min |
| `@high` | **Yes — blocks sign-off** | Fail the pipeline; mandatory fix before release | P2 Jira ticket |
| `@medium` | No — may defer | Fail the pipeline; fix within the sprint | P3 Jira ticket |
| `@low` | No | Warning only in report | P4 backlog item |

### Divergence severity matrix

When cross-channel divergences are found the following escalation applies, regardless of scenario severity:

| Divergence type | Immediate action |
|---|---|
| `PASSFAIL_DIVERGENCE` on `@critical` | P1 — block release, page on-call |
| `PASSFAIL_DIVERGENCE` on `@high` | P2 — block sign-off |
| `VALUE_DIVERGENCE` > 1 % on any `@critical`/`@high` | P2 |
| `VALUE_DIVERGENCE` within tolerance on `@medium`/`@low` | Investigate; not a blocker |
| `INCOMPLETE` (missing channel) | Always a blocker — treat as `PASSFAIL_DIVERGENCE` |

---

## 7. Test data strategy

### Strategy selection

| Strategy | Key | When to use |
|---|---|---|
| Pool | `DATA_STRATEGY=POOL` | Dev / regression — accounts pre-created, reused across runs, protected by FileLock |
| Just-In-Time | `DATA_STRATEGY=JIT` | UAT / staging — fresh accounts created per scenario, torn down after |

### Account type mapping

| Tag | Account type provisioned | Release strategy |
|---|---|---|
| `@requires_clean_account` | Postpaid | Returned to pool / deleted after scenario |
| `@requires_prepaid_account` | Prepaid | Returned to pool / deleted after scenario |
| `@requires_enterprise_account` | Enterprise | Returned to pool / deleted after scenario |
| `@readonly` | No provisioning | No release needed |

### Data isolation rules

1. **A pool account must never be used by more than one channel simultaneously** — the `FileLock` in `DataManager` enforces this.
2. **JIT accounts must be deleted** in `after_scenario()` even when the scenario fails — implement this in your `AccountProvisioner.delete()`.
3. **Test accounts must never overlap with production accounts** — use a dedicated test prefix or a segregated schema.
4. **Pool files are gitignored** — never commit real account IDs to source control.

---

## 8. Environment matrix

| Environment | Channels active | Data strategy | Validation | Tag filter |
|---|---|---|---|---|
| **Local dev** | Any single channel | `POOL` | Optional (`none` allowed) | All except `@skip_ci` |
| **Dev CI** | `angular` | `JIT` | `api` | `@smoke and not @wip` |
| **Regression CI** | `angular` + `citrix` | `JIT` | `api` + `db` | `@regression and not @wip` |
| **Nightly full** | All 3 channels | `JIT` | `api` + `db` | `not @wip and not @manual_only` |
| **UAT** | All 3 channels | `JIT` | `api` + `db` | `@sanity` |
| **Pre-production** | `angular` | `POOL` | `api` | `@smoke @critical` |

---

## 9. CI/CD pipeline stages

```
┌─────────────────────────────────────────────────────────────┐
│  Stage 1 — Harness health (< 5 s)                           │
│  pytest tests/                                              │
│  Failure: blocks merge immediately                          │
└──────────────────────────┬──────────────────────────────────┘
                           │ passes
┌──────────────────────────▼──────────────────────────────────┐
│  Stage 2 — Gherkin validation (< 30 s)                      │
│  behave --dry-run features/                                 │
│  Failure: missing/undefined step definitions                │
└──────────────────────────┬──────────────────────────────────┘
                           │ passes
┌──────────────────────────▼──────────────────────────────────┐
│  Stage 3 — Smoke gate (2–5 min)                             │
│  CHANNEL=angular behave --tags "@smoke and not @wip"        │
│  Failure: blocks all downstream stages                      │
└──────────────────────────┬──────────────────────────────────┘
                           │ passes
┌──────────────────────────▼──────────────────────────────────┐
│  Stage 4 — Full regression (parallel, 10–30 min)            │
│  python main.py --channels angular citrix winpb             │
│              --clean --html                                  │
│              -- behave args: --tags "not @wip"              │
│  Produces: reports/comparison_<run_id>.html                 │
│  Failure: value or pass/fail divergence blocks release      │
└──────────────────────────┬──────────────────────────────────┘
                           │ passes
┌──────────────────────────▼──────────────────────────────────┐
│  Stage 5 — Report archival                                  │
│  Upload reports/ to artifact store / test management system  │
└─────────────────────────────────────────────────────────────┘
```

### GitHub Actions configuration

The CI workflow lives in `.github/workflows/ci.yml`.  Key points:

- `angular` channel runs on `ubuntu-latest` (headless Playwright)
- `citrix` and `winpb` channels run on `windows-latest` (screen-level automation)
- Required secrets: `TEST_CSR_USERNAME`, `TEST_CSR_PASSWORD`, `MODERN_BASE_URL`, `MODERN_API_URL`, `MODERN_API_KEY`, `LEGACY_APP_PATH`, `LEGACY_DB_USER`, `LEGACY_DB_PASS`, `LEGACY_DB_DSN`
- Configure via **repo Settings → Secrets and variables → Actions**

---

## 10. Reporting and metrics

### Per-run HTML report

Generated at `reports/comparison_<run_id>.html`.  Contains:

| Section | Content |
|---|---|
| Summary banner | Total scenarios, CLEAN / mismatch / fail counts, per-channel pass rates |
| Label breakdowns | Counts by severity, test type, and functional area — with progress bars |
| Requirements coverage | All `@req_*` IDs with their scenario names, status, area, and severity |
| Scenario table | Filterable by status and severity/type; per-channel balance columns; Labels chip column |

### KPIs tracked per release

| Metric | Target | Action if missed |
|---|---|---|
| `@smoke @critical` pass rate | 100 % | Block release |
| `@smoke @high` pass rate | 100 % | Block sign-off |
| Cross-channel divergence rate | 0 % for `@critical`/`@high` | P1/P2 incident |
| `INCOMPLETE` scenarios | 0 % | Investigate channel availability |
| `@regression` pass rate | ≥ 95 % | QA sign-off review required |
| Requirements covered by `@smoke` | ≥ 80 % of `@critical` reqs | Test gap analysis |

### Trend tracking

Store the `comparison_<run_id>.html` and raw `reports/*.json` files as CI artifacts.  Use the `run_id` timestamp to plot pass rates over time in your dashboarding tool (Grafana, Power BI, etc.).

---

## 11. Defect management

### Defect lifecycle tags

| Defect state | Tag to apply | Effect |
|---|---|---|
| Under investigation | `@wip` | Excluded from CI; team works to understand root cause |
| Confirmed, not fixed | `@skip_ci` | Excluded from CI; Jira ticket tracks the fix |
| Fixed — regression guard active | `@bug_FIX-<ID>` | Included in `@regression` suite forever; failure = regression |
| Won't fix | `@manual_only` | Excluded from automation; documented for traceability |

### Divergence triage workflow

When `compare_channels.py` reports a divergence:

```
1. Check the HTML report — identify which channels diverged and on which scenario
2. Cross-reference the account_id — is the account in a known bad state?
3. Re-run the single scenario manually on each channel to confirm reproducibility
4. Check SOR (API/DB) directly — is the divergence in the application or in the test data?
5. File a Jira ticket with: channel, scenario name, account_id, observed values, expected value
6. Tag the scenario @skip_ci until the fix is deployed
7. After fix: remove @skip_ci, add @bug_<ticket_id>, run regression suite
```

---

## 12. Team onboarding

### For a new team adopting the harness

**Estimated time**: 2–3 days for a team with Python BDD experience

| Day | Task | Output |
|---|---|---|
| 1 morning | Install harness; run `pytest tests/`; run `--dry-run` on the examples project | Green Level 1 and 2 tests; understanding of the architecture |
| 1 afternoon | Write one `.feature` file with two scenarios; implement `BaseActions` for your angular channel only | First green E2E scenario on `angular` |
| 2 morning | Add locators for your second channel; implement `BaseActions` for `citrix` or `winpb` | Two-channel run with HTML report |
| 2 afternoon | Set up `before_all()` / `after_scenario()` lifecycle; wire `DataManager` with your provisioner | Full data lifecycle working |
| 3 | Add traceability tags; configure CI workflow; write smoke suite | CI pipeline running; first comparison report as artifact |

### Minimum viable `features/environment.py`

```python
import os
from locators.loader import set_domains_path, auto_discover_feature_locators
from config.settings import Config
from engines.modern_web_engine import ModernWebEngine
from utils.tags import extract_labels, should_skip

_ROOT = os.path.dirname(os.path.abspath(__file__))

def before_all(context):
    Config.validate()
    set_domains_path(os.path.join(_ROOT, "locators", "domains"))
    auto_discover_feature_locators(_ROOT)
    engine = ModernWebEngine(Config.MODERN_BASE_URL)
    engine.launch()
    context.actions = YourAngularActions(engine)

def before_scenario(context, scenario):
    context.labels = extract_labels(scenario)
    reason = should_skip(context.labels)
    if reason:
        scenario.skip(reason)

def after_all(context):
    context._engine.quit()
```

### Common mistakes and how to avoid them

| Mistake | Symptom | Fix |
|---|---|---|
| Not calling `set_domains_path()` | `FileNotFoundError: Locator domains directory not found` | Call it in `before_all()` before any locator is resolved |
| Not calling `auto_discover_feature_locators()` | `KeyError: No locator defined for intent 'ApplyCredit'` | Call after `set_domains_path()` in `before_all()` |
| Duplicate intent across locator files | `RuntimeError: Duplicate intent 'X'` | Each intent must live in exactly one JSON file |
| Using `@wip` in production branch | Scenarios silently never run in CI | Remove `@wip` before merging; or use `@skip_ci` if the scenario should stay but be deferred |
| Missing severity or type tag | Scenario appears as `untagged` in report breakdowns | Add at least `@<severity>` and `@<type>` to every scenario |
| SOR validator not set for JIT scenario | `AttributeError: 'NoneType' has no attribute 'get_account_balance'` | Set `context.validator` in `before_all()` or use `@readonly` to skip SOR checks |

---

## 13. Governance

### Strategy ownership

| Role | Responsibility |
|---|---|
| QA Platform Team | Maintain harness; review and update this strategy quarterly |
| Team QA Lead | Ensure scenarios for their domain meet tagging standards; review HTML report per sprint |
| CI/CD Engineer | Maintain pipeline stages; ensure artifacts are retained per policy |
| Release Manager | Gate releases on `@smoke @critical` pass rate; approve `@skip_ci` deferences |

### Change process

1. Changes to the harness core (engines, loader, result store, comparator) require a PR reviewed by QA Platform Team
2. Changes to the tag taxonomy require an update to this document and a broadcast to all adopting teams
3. New channels must be documented in [Section 4](#4-channel-strategy) before they reach the regression stage
4. Tolerance thresholds (`TOLERANCE = 0.005` in `compare_channels.py`) require sign-off from Release Management before being changed

### Document history

| Date | Version | Change |
|---|---|---|
| 2026-04-28 | 1.0 | Initial version |
| 2026-05-04 | 1.1 | Added shared/feature-specific locator tier strategy; updated onboarding table |
