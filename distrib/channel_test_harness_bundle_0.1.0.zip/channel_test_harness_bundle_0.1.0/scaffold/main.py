"""
main.py — channel-test-harness runner

Modes
-----
Single channel (default — channel set via CHANNEL env var):
    CHANNEL=angular python main.py
    CHANNEL=citrix  python main.py
    CHANNEL=winpb   python main.py

Multi-channel parallel run + comparison:
    python main.py --channels angular citrix
    python main.py --channels angular citrix winpb --html

    Spawns one behave process per channel simultaneously.
    All processes share the same RUN_ID so the comparator can pair their files.
    After all finish, runs compare_channels.py --run-id <RUN_ID>.

    --html  also renders the HTML report via tools/report.py
    --clean removes previous result files for the generated RUN_ID before starting
    --out   set HTML output path (implies --html)

CI pipeline example:
    python main.py --channels angular citrix winpb --clean --html
"""
import argparse
import os
import subprocess
import sys
from datetime import datetime

from validation.result_store import clear as _clear_results


def _generate_run_id() -> str:
    return datetime.now().strftime("%Y%m%dT%H%M%S")


def _run_channel(channel: str, run_id: str) -> subprocess.Popen:
    """Spawn a behave process for the given channel, injecting the shared RUN_ID."""
    env = os.environ.copy()
    env["CHANNEL"] = channel
    env["RUN_ID"]  = run_id
    cmd = [sys.executable, "-m", "behave", "features/"]
    print(f"[main] Starting {channel} (run_id={run_id}): {' '.join(cmd)}")
    return subprocess.Popen(cmd, env=env)


def _run_single():
    """Delegate to behave directly (channel/RUN_ID from environment)."""
    cmd = [sys.executable, "-m", "behave", "features/"]
    print(f"[main] Running single channel ({os.getenv('CHANNEL', 'angular')})")
    result = subprocess.run(cmd)
    sys.exit(result.returncode)


def _run_multi(channels: list[str], clean: bool, html: bool, out: str | None):
    """
    Spawn all channel suites in parallel under a shared RUN_ID, wait for all,
    then compare and optionally render HTML.

    Exit code is 0 only when:
      - every channel suite returned 0
      - compare_channels.py found no divergences
    """
    run_id = os.getenv("RUN_ID") or _generate_run_id()
    print(f"[main] Run ID: {run_id}")
    print(f"[main] Channels: {', '.join(channels)}")

    if clean:
        print("[main] Clearing previous result files...")
        for ch in channels:
            _clear_results(channel=ch, run_id=run_id)

    procs = {ch: _run_channel(ch, run_id) for ch in channels}
    exit_codes = {ch: proc.wait() for ch, proc in procs.items()}

    print()
    for ch, rc in exit_codes.items():
        status = "OK" if rc == 0 else f"FAILED (rc={rc})"
        print(f"[main] {ch:<12} {status}")
    print()

    results_dir = os.getenv("REPORTS_DIR", "reports")
    compare_cmd = [
        sys.executable, "tools/compare_channels.py",
        "--run-id", run_id,
        "--results-dir", results_dir,
    ]
    if html or out:
        compare_cmd.append("--html")
    if out:
        compare_cmd += ["--out", out]

    compare_result = subprocess.run(compare_cmd)

    if any(rc != 0 for rc in exit_codes.values()) or compare_result.returncode != 0:
        sys.exit(1)
    sys.exit(0)


def main():
    parser = argparse.ArgumentParser(description="channel-test-harness runner")
    parser.add_argument(
        "--channels", nargs="+", metavar="CHANNEL",
        help="Channels to run in parallel (e.g. --channels angular citrix winpb). "
             "If omitted, runs a single channel from the CHANNEL env var.",
    )
    parser.add_argument(
        "--clean", action="store_true",
        help="Remove previous result files for this run before starting.",
    )
    parser.add_argument(
        "--html", action="store_true",
        help="Render an HTML comparison report after the run.",
    )
    parser.add_argument(
        "--out", default=None,
        help="HTML output path (implies --html).",
    )
    args = parser.parse_args()

    if args.channels:
        _run_multi(args.channels, clean=args.clean, html=args.html, out=args.out)
    else:
        _run_single()


if __name__ == "__main__":
    main()

