#!/usr/bin/env bash
# install.sh — Linux/macOS install helper for channel-test-harness bundle
set -euo pipefail

echo "=== Channel Test Harness — installer (uv) ==="

# 0. Install uv if not already present
if ! command -v uv &>/dev/null; then
  echo "[0/5] Installing uv..."
  curl -LsSf https://astral.sh/uv/install.sh | sh
  export PATH="$HOME/.local/bin:$PATH"
fi

# 1. Create venv pinned to Python 3.13
echo "[1/5] Creating virtual environment..."
uv venv --python 3.13
source .venv/bin/activate

# 2. Install wheel (angular extra by default; edit as needed)
echo "[2/5] Installing harness wheel..."
wheel=$(ls wheels/*.whl 2>/dev/null | head -1)
if [ -z "$wheel" ]; then echo "ERROR: No .whl found in wheels/"; exit 1; fi
# Change [angular] to [citrix], [winpb], [oracle], or [all] as needed
uv pip install "${wheel}[angular]"

# 3. Install Playwright browser (angular channel only)
echo "[3/5] Installing Playwright browser..."
uv run playwright install chromium

# 4. Copy scaffold
echo "[4/5] Copying scaffold to my_project/ ..."
if [ ! -d "my_project" ]; then
    cp -r scaffold my_project
    cp .env.example my_project/.env.example
    echo "     Scaffold copied to my_project/"
    echo "     Edit my_project/.env and fill in your credentials."
else
    echo "     my_project/ already exists -- skipping scaffold copy."
fi

# 5. Verify wiring (no app needed)
echo "[5/5] Running Gherkin dry-run to verify step wiring..."
pushd my_project
CHANNEL=angular TEST_CSR_USERNAME=dry-run TEST_CSR_PASSWORD=dry-run \
  MODERN_BASE_URL=http://localhost \
  uv run behave --dry-run features/ || true
popd

echo ""
echo "Done!  See docs/testing_strategy.md for next steps."
