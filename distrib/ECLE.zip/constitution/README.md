# ECLE 2.0 Constitution

The constitution is the **single source of truth** for every design, implementation,
and operational decision in ECLE 2.0.

Every engineer reads it before writing their first line of code.
A contract violation found in review **blocks merge** — no exceptions.

---

## Folder structure

```
constitution/
  README.md                          ← this file — load first
  contracts/                         ← living rules enforced by CI + review
  schemas/                           ← machine-readable data contracts
  adrs/                              ← immutable log of why decisions were made
```

Load **only the file relevant to your current task** — do not load the whole folder at once.

---

## contracts/

Living rules. Enforced by CI, code review, and eval suites.
"MUST" = non-negotiable. "SHOULD" = justified exception allowed with reviewer sign-off.

| File | Governs |
|---|---|
| `01-coding-standards.md` | Python style, SOLID/DRY/KISS/SRP, type hints, anti-pattern blacklist |
| `02-sdlc-contract.md` | Spec-first, branch/PR/review/CI lifecycle, non-negotiable rules |
| `03-testing-contract.md` | Test pyramid, coverage requirements, eval suites as hard CI gates |
| `04-fact-contract.md` | FACT enforcement — Fast/Accurate/Complete/Trustworthy per layer |
| `05-confidence-contract.md` | 6-dimension confidence profile, fidelity ceiling, propagation |
| `06-grounding-contract.md` | Every claim must cite evidence; grounding stack; rejection rules |
| `07-staleness-contract.md` | No silent stale answers; thresholds; response envelope |
| `08-language-pack-contract.md` | Pack folder structure, manifest.yaml spec, extractor interface |
| `09-event-pipeline-contract.md` | Event types, SRP per worker, idempotency, error handling |
| `10-anti-patterns.md` | Banned patterns — reviewer rejects on sight |
| `11-mcp-contract.md` | MCP tool rules — FACT envelope mandatory, error shapes, banned behaviours, HTTP transport spec (all phases), caller intent protocol |
| `12-embedding-contract.md` | ONNX mandate, slim payload rules, collection naming, idempotency key, micro-batching |
| `13-incremental-ingestion-contract.md` | O(changed_files) guarantee, content_hash skip rules, neighbourhood hash, cascade staleness, behavioral fingerprint gate (§8), neighbor propagation bounds (§9) |
| `14-deployment-contract.md` | Three-tier deployment rules — no tier branches in code, IArtifactStore mandatory, worker statelessness |
| `15-db-schema-contract.md` | All Structured DB tables — columns, indexes, partitioning, migration rules; `repo_role` on `repositories`; `extraction_fidelity` on `file_facts`; `api_keys`, `query_audit_log`, `tenants`, `tenant_config`, `confidence_votes` (from ADR-0019/0020/0024); `function_table_ops`, `file_literals` (from ADR-0031) |
| `16-observability-contract.md` | Prometheus metrics catalogue for all components; SLO definitions (p95/p99 latency, Kafka lag, stale vector ratio); OpenTelemetry distributed tracing; structured JSON log standard; mandatory alerting rules; Grafana dashboard template |
| `17-phase-roadmap-contract.md` | Phase boundaries, entry/exit criteria, deliverables per phase, scope enforcement, version tag rules |
| `18-implementation-guidelines.md` | Architectural patterns, ADR consumption during implementation, worker/test/config/DB patterns, build workflow, DI wiring |

## schemas/

Machine-readable data contracts between components.
**A schema change requires an ADR before implementation.**

| File | Defines |
|---|---|
| `facts-base-schema.json` | `CanonicalFactFileBase` — every `facts.json` must conform |
| `metrics-schema.json` | `CpgFileMetrics` — `metrics.json` from language packs |
| `events-table.sql` | PostgreSQL events table DDL — immutable append log |
| `language-pack-manifest.schema.yaml` | `manifest.yaml` contract for every language pack |

---

## adrs/

Immutable decision log. Once accepted, an ADR is never edited — it is superseded by a new ADR.

| File | Decision |
|---|---|
| `ADR-0001` through `ADR-0027` | See individual files for titles |
| `ADR-0028-runtime-data-and-logging-layout.md` | `ecle-data/` and `ecle-logs/` directory layout, central logging config, path consolidation |
| `ADR-0029-agent-token-optimization.md` | Agent memory digests at `.github/memory/`; compact contract references; ~60% token reduction |
| `ADR-0030-pipeline-workspace.md` | Structured workspace at `.github/pipeline/workspace/`; ADR consumption during implementation |

## adrs/

Architecture Decision Records. Written **before** implementation begins.
Never deleted — superseded ADRs are marked `Status: Superseded by ADR-NNNN`.

| ADR | Decision |
|---|---|
| `ADR-0001-event-driven-pipeline.md` | Event-driven pipeline over direct worker calls — **superseded by ADR-0013** |
| `ADR-0002-language-pack-registry.md` | Dynamic language pack registry over static extractor map |
| `ADR-0003-three-backend-architecture.md` | Structured DB + Vector Index + Topology Graph |
| `ADR-0004-slim-vector-design.md` | Multi-layer vector store (Layer 1/2/3); slim payloads; growth containment |
| `ADR-0005-framework-overlay-packs.md` | Framework overlay packs (Angular/React/Vue) activated by repo-level detection |
| `ADR-0006-mcp-graphql-query-layer.md` | Stateless MCP over HTTP + GraphQL (both from Phase 1, all tiers); JSON-RPC 2.0 on `POST /mcp`; Strawberry on `POST /graphql`; Phase 3 adds vector/graph resolvers additively; why not stdio; why not REST |
| `ADR-0007-artifact-store-ir-intermediary.md` | facts.json on disk as IR intermediary between parse_repo and downstream workers |
| `ADR-0008-local-first-embeddings.md` | ONNX/OpenVINO mandatory; cloud embedding APIs opt-in only; air-gapped default |
| `ADR-0009-contract-first-cross-repo-linking.md` | O(C log C) contract matching over O(N²) entity matching; PoC failure lesson |
| `ADR-0010-three-tier-deployment-model.md` | Dev (single-machine) → Docker Compose (small prod) → Kubernetes (enterprise); same code all tiers |
| `ADR-0011-louvain-community-detection.md` | Louvain on topology graph → cluster_id; two-phase model (topology clustering → vector centroids); O(E log E) |
| `ADR-0012-multi-level-language-detection.md` | Three-pass detection (extension → content heuristics → layered extraction); framework detection rules in `detection_rules/`; multi-layer files and embedded sub-languages |
| `ADR-0013-kafka-event-broker.md` | Kafka (KRaft, no ZooKeeper) as exclusive broker all tiers; Redpanda for dev; consumer groups replace Celery; Redis removed; supersedes ADR-0001 |
| `ADR-0014-semantic-first-query-planning.md` | Semantic-first routing; three query modes (semantic/structured/composite); Louvain cluster as semantic→structural handoff; `query_mode` in FACT envelope; amends ADR-0003 routing layer |
| `ADR-0014-A1` (amendment in ADR-0014) | Coarse-to-fine cascade execution (Layer 3 → Layer 1 → Layer 2); recall-safety fallback; `search_depth` in FACT envelope |
| `ADR-0015-three-axis-onboard-model.md` | Three-axis onboard model: content_type (code/config/data/data-sql/docs) × source (git/local) × schedule (once/recurring/re-run); 30 valid configurations; platform/module role interaction |
| `ADR-0016-tree-sitter-extraction-depth.md` | Tree-sitter extraction depth standard — 9 categories required from `full` packs; Joern-equivalent depth without JVM; `extraction_fidelity` (FULL/PARTIAL/HEURISTIC) on every file_facts row |
| `ADR-0017-platform-module-repository-model.md` | Platform vs module repo roles; ingest-time isolation; query-time enrichment; neighbor propagation never crosses repo boundaries; day-2 evolution scenarios; cross-repo join mechanics |
| `ADR-0018-intent-driven-flow-registry.md` | Intent-driven flow registry; FlowSelector + FlowExecutor + StepRegistry pattern; `ecle_enrich` vocabulary alignment step; JSON-configurable flows with operator tuning; MCP progress notifications; `suggested_next` + `enrich_carry` carry-forward in FACT envelope |
| `ADR-0019-authn-authz-model.md` | API key (Phase 2) + JWT bearer (Phase 3) auth; SHA256-stored keys; tenant-scoped query/admin/ingest scopes; per-key 20 RPS + per-tenant 100 RPS rate limiting; audit log; air-gap JWT mode |
| `ADR-0020-admin-control-plane.md` | Admin REST API on port 4001 (separate from MCP); tenant/repo/API key management; runtime config overrides (60 s poll, no restart); operational health endpoints; bootstrap CLI |
| `ADR-0021-data-lifecycle.md` | Tenant purge with 7-day grace period; repo purge with 3-day grace; fact version archival (90 days); audit log retention (365 days); GDPR right-to-erasure flow |
| `ADR-0022-tenant-isolation-model.md` | Three isolation tiers: Tier A (logical, RLS + tenant_id, default), Tier B (schema-per-tenant), Tier C (physical — single-tenant Helm); resource quotas; per-tenant Kafka topics optional |
| `ADR-0023-disaster-recovery.md` | RPO/RTO defined per deployment tier; dev=re-ingest; compose=daily pg_dump; enterprise=managed PG PITR (1h RPO); vector store fully re-derivable; monthly restore drill mandatory |
| `ADR-0024-feedback-learning-loop.md` | `ecle_feedback` MCP tool (Phase 3); `learning_analyzer` worker; `confidence_votes` table; vote formula with sqrt decay; `behavioral_accuracy` adjustment; vote reset on behavioral change; `BOOKMARK` signal |
| `ADR-0025-domain-ontology-strategy.md` | Three-layer vocabulary (base + tenant YAML + auto-derived TF-IDF); `ontology_enricher` worker SRP; `ontology_version` in FACT envelope; `semantic_accuracy` computation; decay trigger on vocabulary update |
| `ADR-0026-admin-portal-ui.md` | React 18 SPA served by `ecle-admin` binary; four pages (Onboard, Import Jobs, System Health, Worker Control); ZIP-in-browser upload via JSZip; API key in sessionStorage only (OWASP A03); no Node runtime at deploy time |
| `ADR-0027-async-component-autonomy.md` | Every worker is async, independently deployable, independently scalable; Kafka-only inter-component communication (direct worker calls banned); per-worker KEDA ScaledObject; per-worker lifecycle control (run/pause/drain/reset-offset); pipeline_state step tracking per job |
| `ADR-0028-runtime-data-and-logging-layout.md` | `ecle-data/` and `ecle-logs/` directory layout; central logging config; path consolidation |
| `ADR-0029-agent-token-optimization.md` | Agent memory digests at `.github/memory/`; compact contract references; validator/spec-reviewer still load full contracts |
| `ADR-0030-pipeline-workspace.md` | Structured workspace at `.github/pipeline/workspace/`; ADR consumption during implementation; orchestrator populates at G1 |
| `ADR-0031-stitching-completeness.md` | Cross-source stitching schema: `function_table_ops`, `file_literals`, `columns[]` in sql_statements, `SERVICE`/`EVENT` artifact types, DDL column extraction in `field_extractions`, `tuxedo_service`/`rpc_service` entry point types |
| `ADR-TEMPLATE.md` | Copy this for every new ADR |

---

## Constitution rules

1. Read the full constitution before your first commit.
2. Contract violations in review **block merge** — no exceptions, no workarounds.
3. ADRs are written **before** the decision is implemented — never retroactively.
4. Schema changes require an ADR. No schema change without a corresponding ADR.
5. `10-anti-patterns.md` items are hard-banned — zero tolerance in review.
6. Contracts are updated when the system evolves — stale contracts are bugs.
7. Every spec in `specs/` MUST reference the contracts it implements.
