# ADR-0031: Cross-Source Stitching Completeness

**Status:** Accepted  
**Date:** 2026-05-08  
**Deciders:** Lead Engineer, Architecture Review  
**Supersedes:** —  
**Superseded by:** —  
**Amends:** ADR-0016 (extraction depth — adds column-level and literal extraction), ADR-0017 (platform-module model — adds service registry and DDL column enrichment)

---

### FACT Impact

| Dimension | Impact |
|-----------|--------|
| **Fast** | Neutral — new tables are indexed lookups; no scan overhead. `function_table_ops` is O(sql_count) per file during ingestion. |
| **Accurate** | Improves — column-level resolution eliminates false positives from table-level-only matching. Function-scoped SQL attribution replaces file-level attribution. |
| **Complete** | Improves — closes 8 identified gaps where ECLE 1.0 returned no useful response. Enables service-name, column-name, literal-value, and business-term queries that were previously unanswerable. |
| **Trustworthy** | Improves — every new fact carries provenance (source repo, source line, extraction method). DDL-sourced column definitions are E1 evidence (deterministic extraction). |

---

### Context

ECLE 1.0 field testing produced 7 prompts that ECLE could not answer or answered
incompletely. Root cause analysis reveals a common pattern: **answering real-world
questions requires joining facts from multiple sources** — code repos AND platform
repos — and the structured schema lacks the join surfaces to stitch them.

The failures fall into three categories:

**Category A — Code-to-platform stitch failures (Prompts #1–#4):**
Queries like "which tuxedo services call function X" or "which function updates column Y
in table Z" require facts from code (call graph, SQL statements) joined with facts from
platform repos (service registry, DDL column definitions). The code-side facts exist in
`function_calls` and `sql_statements`, but the platform-side join targets are missing or
incomplete.

**Category B — Platform-to-platform stitch failures (Prompts #5–#7):**
Queries like "what is a TFB account" or "where is bill type stored" require business
glossary terms (from docs platform repos) joined with DDL column definitions (from DDL
platform repos). Neither the glossary→schema mapping nor the column-level DDL extraction
exists in Contract 15.

**Category C — Value-level resolution failures (Prompts #3, #4):**
Queries like "which code creates event P10MDataPassEndOfServiceOccurred" or "which code
inserts PARAM_NAME='PRE_P10M'" require searching for specific string literal values
within code. The `literals` array exists in `facts-base-schema.json` but has no
corresponding structured DB table for indexed lookup.

The `fact-data-slicing.md` design document already anticipated `function_table_ops` and
`file_literals` tables but they were not promoted to Contract 15. This ADR formalizes
the complete set of schema additions needed for cross-source stitching.

---

### Decision

We will add six schema changes to close the cross-source stitching gaps. All changes
are additive — no existing tables or columns are modified or removed.

#### 1. `function_table_ops` table — function→table→column granularity

Promotes the design from `fact-data-slicing.md` to Contract 15. One row per
(function, table, operation) tuple, with full SQL text for reference.

```
function_table_ops
  id                  UUID PK
  tenant_id           VARCHAR
  function_id         UUID FK     → function_facts.id
  file_fact_id        UUID FK     → file_facts.id (denormalized for direct file join)
  repo_id             VARCHAR     Denormalized
  table_name          VARCHAR     Normalized uppercase. Indexed.
  operation           VARCHAR     READ | WRITE | DDL | READWRITE
  columns             TEXT[]      Column names extracted from SQL (nullable — see §6 below)
  sql_text            TEXT        Full SQL text for reference and text search
  line                INT         Line number of the SQL statement
  is_current          BOOLEAN     Mirrors parent function_facts.is_current
```

**Relationship to `file_tables`:** `file_tables` is the file-level aggregate (which
tables does this file touch?). `function_table_ops` is the function-level detail (which
function executes which SQL against which table and columns?). Both are needed —
file-level for broad queries, function-level for precise impact analysis.

**Population:** `persist_facts` worker. For each `sql_statement` in the facts JSON,
scoped to its `enclosing_method`:
- `function_id` = `function_facts.id` for the enclosing method
- `table_name` = each entry in `sql_statement.tables[]`
- `columns` = extracted from SQL text (see §6)
- `sql_text` = `sql_statement.sql_text`

#### 2. `file_literals` table — searchable string constants

One row per unique literal value per file. Enables exact-match lookup for event names,
flag values, magic strings, and domain constants.

```
file_literals
  id                  UUID PK
  tenant_id           VARCHAR
  file_fact_id        UUID FK     → file_facts.id
  repo_id             VARCHAR     Denormalized
  value               VARCHAR     The literal value. Indexed.
  literal_type        VARCHAR     string | int | float | boolean | table_name
  line                INT         First occurrence line number
  enclosing_method    VARCHAR     Function that contains this literal (nullable for file-level)
  is_current          BOOLEAN     Mirrors parent file_facts.is_current
```

**Deduplication:** Multiple occurrences of the same literal value in the same file
produce ONE row (first occurrence wins for `line`). Cross-file occurrences produce
separate rows.

**Filtering:** Not all literals are worth storing. Language packs SHOULD filter out:
- Numeric literals 0 and 1 (too common to be useful)
- Empty strings
- Single-character strings
- Literals already captured in `sql_statements.sql_text` as SQL keywords

The `LITERAL_MIN_LENGTH` constant (default: 3) gates string literal storage.
The `LITERAL_MAX_PER_FILE` constant (default: 500) caps storage per file to prevent
bloat from generated files with thousands of constants.

**Population:** `persist_facts` worker. For each entry in `facts.literals[]`:
- `value` = `literal.value`
- `literal_type` = `literal.type`
- `line` = `literal.line`
- `enclosing_method` = resolved from `execution_sequence` parent chain if available,
  otherwise null

#### 3. `columns[]` added to `sql_statements` in facts-base-schema

The `sql_statements` schema item gains a `columns` array:

```json
"columns": {
  "type": "array",
  "items": { "type": "string" },
  "description": "Column names referenced in the SQL statement. Extracted from SELECT list, INSERT column list, UPDATE SET clause, WHERE clause. Normalized uppercase."
}
```

**Extraction rules:**
- `INSERT INTO table(col1, col2, ...)` → columns = `[col1, col2, ...]`
- `UPDATE table SET col1 = ..., col2 = ...` → columns = `[col1, col2]`
- `SELECT col1, col2 FROM table` → columns = `[col1, col2]`
- `SELECT *` → columns = `["*"]` (wildcard — cannot resolve without DDL)
- `WHERE col1 = :host_var` → col1 added to columns
- Columns from JOINs and subqueries included if extractable
- If column extraction fails (dynamic SQL, complex expressions), `columns` is `null`
  (not empty array — null signals "could not extract", empty signals "no columns")

**Extraction fidelity:** Column extraction from SQL text is best-effort. The
`extraction_fidelity` field on `file_facts` already covers this — `PARTIAL` fidelity
means some columns may be missing.

#### 4. `SERVICE` added to `shared_artifacts.artifact_type` enum

The `artifact_type` enum in `shared_artifacts` is extended:

```
TABLE | KAFKA_TOPIC | PACKAGE | SHARED_TYPE | REST_ENDPOINT | SERVICE | EVENT
```

Two new types:
- **`SERVICE`** — a named service (Tuxedo service, batch job, daemon) mapped to its
  source file(s) and entry point(s). Populated from service registry platform repos
  (UBBCONFIG, deployment descriptors, service catalogs).
- **`EVENT`** — a named event or notification type. Populated from event catalog
  platform repos or extracted from code where event publishing patterns are detected.

**`SERVICE` population flow:**
```
Platform repo (UBBCONFIG / service config)
  → content_type: data
  → Language pack: config parser (INI / UBBCONFIG / YAML)
  → Extract: { service_name, source_file, entry_point_function }
  → Write to shared_artifacts:
      artifact_name  = service_name (e.g. "csChgProdTp")
      artifact_type  = SERVICE
      defining_repo_id = platform repo ID
```

**`EVENT` population flow:**
```
Platform repo (event catalog / message schema)
  → content_type: data
  → Language pack: schema parser (JSON Schema / XML / Avro)
  → Extract: { event_name, schema, publisher, subscribers }
  → Write to shared_artifacts:
      artifact_name  = event_name (e.g. "P10MDataPassEndOfServiceOccurred")
      artifact_type  = EVENT
      defining_repo_id = platform repo ID
```

#### 5. `entry_point_type` enum extended with `tuxedo_service`

The `file_entry_points.entry_point_type` enum is extended:

```
http_handler | batch_main | scheduled | event_handler | tuxedo_service | rpc_service
```

Two new types:
- **`tuxedo_service`** — Tuxedo service entry point. The `entry_point_name` carries
  the service name from UBBCONFIG.
- **`rpc_service`** — generic RPC service entry point for non-Tuxedo RPC frameworks.

When a `SERVICE` artifact in `shared_artifacts` is linked to a file via
`cross_repo_edges`, the corresponding `file_entry_points` row SHOULD be created or
updated with the service name and type. This stitch is performed by the
`link_contracts` worker when it processes service registry platform repos.

#### 6. `field_extractions` extended for DDL column definitions

The existing `field_extractions` table is extended with two new columns:

```
parent_table        VARCHAR     Table this column belongs to (nullable — null for standalone field defs)
column_position     INT         Ordinal position in CREATE TABLE (nullable)
description         TEXT        From COMMENT ON COLUMN or inline comment (nullable)
```

**Population from DDL platform repos:**

```
Platform repo (ddl-schemas)
  → content_type: data-sql
  → DDL parser extracts CREATE TABLE statements
  → For each column in each table:
      field_name       = column_name (e.g. "INIT_ACTIVATION_DATE")
      field_type       = column_type (e.g. "DATE")
      parent_table     = table_name (e.g. "SUBSCRIBER")
      parent_service   = null (DDL is table-scoped, not service-scoped)
      max_length       = from VARCHAR(N) / NUMBER(N) declaration
      valid_values     = from CHECK constraints or COMMENT annotations
      column_position  = ordinal position
      description      = from COMMENT ON COLUMN or inline comment
      source_repo_id   = DDL platform repo ID
```

**This enables the full stitch for "where is column X in table Y":**

```sql
SELECT fe.field_name, fe.field_type, fe.parent_table,
       fe.description, fe.valid_values, fe.source_repo_id
FROM field_extractions fe
WHERE fe.parent_table = 'SUBSCRIBER'
  AND fe.field_name = 'INIT_ACTIVATION_DATE'
  AND fe.is_current = true;
```

**Relationship to `shared_artifacts`:** Each table in the DDL produces both a
`shared_artifacts` row (`artifact_type = TABLE`) and N `field_extractions` rows
(one per column). They are linked by `parent_table = shared_artifacts.artifact_name`.

---

### Cross-Source Query Resolution — How the Stitches Work

#### Query: "List tuxedo services calling function X" (Prompt #1)

```
Step 1: function_calls WHERE callee_name = 'X'
        → caller function IDs

Step 2: function_facts JOIN file_facts
        → file paths for each caller

Step 3: file_entry_points WHERE entry_point_type = 'tuxedo_service'
        → service names for each file
   OR:  shared_artifacts WHERE artifact_type = 'SERVICE'
        JOIN cross_repo_edges on file
        → service names from platform registry

Result: function callers + service names. Complete.
```

#### Query: "Functions updating column Y in table Z" (Prompt #2)

```
Step 1: function_table_ops WHERE table_name = 'Z' AND operation = 'WRITE'
        → function IDs + sql_text + columns[]

Step 2: Filter WHERE 'Y' = ANY(columns)
   OR:  WHERE sql_text ILIKE '%Y%'   (fallback if columns is null)
        → functions that write to column Y

Step 3: field_extractions WHERE parent_table = 'Z' AND field_name = 'Y'
        → column definition, type, description from DDL platform repo

Result: function names + file paths + DDL enrichment. Complete.
```

#### Query: "Code creating event E" (Prompt #3)

```
Step 1: file_literals WHERE value = 'E'
        → file IDs + enclosing_method + line

Step 2: function_facts for enclosing_method
        → function details

Step 3: shared_artifacts WHERE artifact_name = 'E' AND artifact_type = 'EVENT'
        → event definition from platform catalog

Result: function + file + event definition. Complete.
```

#### Query: "Code inserting value V into table T" (Prompt #4)

```
Step 1: function_table_ops WHERE table_name = 'T' AND operation = 'WRITE'
        AND sql_text ILIKE '%V%'
        → functions whose INSERT/UPDATE SQL contains the value

Step 2: file_literals WHERE value = 'V'
        AND file_fact_id IN (files from step 1)
        → confirms the literal exists in the same file/function

Step 3: field_extractions WHERE parent_table = 'T'
        → column definitions, valid values from DDL

Result: function + SQL evidence + DDL context. Complete.
```

#### Query: "What table/column stores concept C" (Prompts #5–#7)

```
Step 1: BM25 search on field_extractions(field_name, description)
        + shared_artifacts(artifact_name, definition_summary)
        for terms related to C
        → candidate tables + columns

Step 2: field_extractions WHERE parent_table IN (candidates)
        → full column listing with types, descriptions, valid_values

Step 3: file_tables WHERE table_name IN (candidates)
        → module repo files that read/write these tables

Result: table + column + definition + code references. Complete.
```

---

### Ingestion Cost

| Table | Rows per file (typical) | Computation |
|-------|------------------------|-------------|
| `function_table_ops` | 0–20 (one per function×table combo) | O(sql_count) — iterate `sql_statements`, group by `enclosing_method` |
| `file_literals` | 0–100 (deduplicated) | O(literal_count) — iterate `literals`, deduplicate by value |
| `field_extractions` (DDL) | 0–200 (one per column per DDL file) | O(columns) — iterate CREATE TABLE columns |

Total additional ingestion cost per file: sub-millisecond structured DB writes. No
vector computation. No cross-file lookups. Fully parallelizable.

---

### Constants

| Constant | Default | Scope | Description |
|----------|---------|-------|-------------|
| `LITERAL_MIN_LENGTH` | 3 | `persist_facts` | Minimum string literal length to store in `file_literals` |
| `LITERAL_MAX_PER_FILE` | 500 | `persist_facts` | Maximum literal rows per file (prevents bloat from generated code) |

---

### Consequences

**Positive:**

- All 7 ECLE 1.0 failure prompts become answerable with deterministic structured queries
- Function→table→column granularity enables precise impact analysis
- Service registry stitching enables service-name queries without code-level knowledge
- DDL column enrichment enables business-concept→storage-location queries
- Literal search enables event-name and constant-value queries
- All new tables follow existing Contract 15 patterns (tenant isolation, `is_current`, denormalized `repo_id`)

**Negative / Trade-offs:**

- `file_literals` can be large for files with many constants — mitigated by `LITERAL_MAX_PER_FILE` cap
- Column extraction from SQL is best-effort — complex dynamic SQL may yield null columns
- Service registry requires a language pack for UBBCONFIG / deployment descriptor parsing — new language pack work
- DDL column extraction requires a language pack for DDL parsing — new language pack work for `data-sql` content type

**Neutral / Operational notes:**

- `function_table_ops` and `file_literals` are populated by the existing `persist_facts` worker — no new Kafka consumer needed
- `field_extractions` DDL population uses the existing `persist_facts` worker with `content_type=data-sql` routing
- `shared_artifacts` SERVICE/EVENT rows are populated by `build_contract_registry` from platform repos — existing worker, extended extraction
- All new indexes follow the existing partial index pattern (`WHERE is_current = true`)

---

### Alternatives Considered

| Alternative | Why Rejected |
|-------------|-------------|
| Store `sql_text` in `file_tables` instead of creating `function_table_ops` | `file_tables` is file-level; multiple functions in the same file may write to the same table with different SQL. Function-level granularity is required for precise attribution. |
| Full SQL parsing for column extraction (using a SQL grammar) | Over-engineering for Phase 1. ECLE's SQL is embedded (Pro*C, PowerBuilder) — a regex-based column extractor from `INSERT INTO table(cols)` and `UPDATE table SET col=` patterns handles 80%+ of cases. Full SQL grammar is a Phase 3+ enhancement. |
| Store all literals (no filtering) | A 10K-line generated file with 5000 numeric literals would bloat the DB with useless data. The `LITERAL_MIN_LENGTH` and `LITERAL_MAX_PER_FILE` caps are essential. |
| Create a separate `glossary_terms` table for business vocabulary | Premature. The BM25 hybrid search on `field_extractions.description` + `shared_artifacts.definition_summary` + `documents` covers business-term queries without a separate glossary table. If BM25 proves insufficient, a glossary table can be added in a future ADR. |
| Embed column names in the vector store | Violates Contract 06 §8 — column names are Tier 1-domain facts (exact lookup, never embedded). Column definitions are structured data, not semantic content. |

---

### Compliance

- Contract: `constitution/contracts/15-db-schema-contract.md` — `function_table_ops`, `file_literals` tables added; `field_extractions` extended; `shared_artifacts.artifact_type` enum extended; `file_entry_points.entry_point_type` enum extended
- Contract: `constitution/contracts/01-coding-standards.md` — new constants `LITERAL_MIN_LENGTH`, `LITERAL_MAX_PER_FILE` follow §constants convention
- Schema: `constitution/schemas/facts-base-schema.json` — `columns` array added to `sql_statements`
- ADR-0016: Tree-Sitter Extraction Depth — column extraction and literal extraction extend the extraction depth model
- ADR-0017: Platform-Module Repository Model — SERVICE and EVENT artifact types extend the platform enrichment model
- ADR-0015: Three-Axis Onboard Model — `content_type=data` and `content_type=data-sql` routing already supports service registry and DDL platform repos
- Eval: `eval_stitching_completeness` — 7 test prompts from ECLE 1.0 field testing used as regression suite

---

### References

| ID | Citation | Relevance |
|----|----------|-----------|
| R1 | ECLE 1.0 Field Test Results, May 2026 | 7 failure prompts that motivated this ADR |
| R2 | `ideas/constitution/fact-data-slicing.md` | Original `function_table_ops` design |
| R3 | `ideas/constitution/fact-query-engine.md` | `TUXEDO_SERVICE` artifact type and `serviceMap` query |
