# ADR-0002: Dynamic Language Pack Registry

**Status:** Accepted  
**Date:** 2026-05-05  
**Deciders:** Lead Engineer, Architecture Review  
**Supersedes:** —  
**Superseded by:** —  

---

### Context

ECLE 2.0 must handle 20+ languages at initial rollout, with new languages added continuously as customer repositories are onboarded. An early design used a static `ExtractorRegistry` — a Python dict mapping file extensions to hardcoded extractor classes. Every new language required a code change, a PR, a test run, and a deployment.

AMF (Agentic Migration Factory) demonstrated a superior pattern: each language is a self-contained folder with a `manifest.yaml` that declares its extensions, grammar, fidelity, and preprocessing rules. The registry scans the folder at startup and self-configures. Adding a language is a folder drop + restart, with zero code changes.

ECLE 2.0 adopts this manifest-driven model directly, extended with FACT compliance requirements (fidelity ceiling propagation, DefaultPack fallback guarantee).

---

### Decision

We will implement a `LanguagePackRegistry` that scans `language_packs/` at worker startup, loads every `manifest.yaml`, validates it against `constitution/schemas/language-pack-manifest.schema.yaml`, and builds an extension-to-pack lookup table. The `DefaultPack` is always loaded last and claims no extensions — it is the fallback for any extension not claimed by another pack.

- Each pack lives at `language_packs/<language_id>/`
- Required files: `manifest.yaml`, `fast_extractor.py`, `schema.py`
- `fast_extractor.extract()` must never raise — exceptions are caught internally and stored in `extraction_errors[]`
- `DefaultPack` sets `fidelity=HEURISTIC`, `used_fallback=true`, confidence ceiling 0.5

---

#### Hot-reload

The registry monitors `language_packs/` via `watchdog.observers.Observer`. On `FileCreatedEvent` or `FileModifiedEvent` for any `manifest.yaml` or `fast_extractor.py`:

1. Load and validate the changed pack into a staging slot.
2. If validation passes: atomically replace the pack entry in the extension lookup dict (CPython dict assignment is atomic under the GIL — no explicit lock needed for the swap).
3. If validation fails: log error; emit `language_pack.reload_failed` Kafka event; existing pack remains unchanged.
4. Emit `language_pack.reloaded` Kafka event on success.

In-flight extractions that started before the swap complete with the old pack — worker-level idempotency handles any re-runs against the new pack. **No worker restart required** to pick up a new or updated language pack.

---

#### Extension conflict resolution

Manifests declare `registry.priority` (integer, default `0`). On extension conflict between two packs:

- Higher priority wins — the lower-priority pack's conflicting extension is dropped (not the whole pack); a warning is logged.
- Equal priority on the same extension → `DuplicateExtensionError`: **fatal at startup** (must be resolved before workers start); **non-fatal on hot-reload** (incoming pack rejected, `language_pack.reload_failed` emitted, existing pack unchanged).
- Resolution path: set `registry.priority` in the winning pack's `manifest.yaml`.

```yaml
# in manifest.yaml
registry:
  priority: 10   # higher number wins on extension conflict; default 0
```

---

#### Extension miss handling

DefaultPack handles all unknown extensions — processing never blocks. Additionally:

- Registry emits a miss count per extension via **shared Kafka counter**:
  - Each worker emits `language_pack.extension_miss { extension, count: N }` to Kafka when it has accumulated `COVERAGE_GAP_REPORT_INTERVAL` (default: `10`) misses for an extension in its local session.
  - A lightweight `coverage_gap_aggregator` consumer (single instance, low-priority) reads these events and maintains a per-tenant, per-extension global count in the `coverage_gap_counts` table (Structured DB).
  - When global count for an extension crosses `COVERAGE_GAP_THRESHOLD` (env var, default: `100` globally): emit `language_pack.coverage_gap` Kafka event with `extension` and `global_miss_count`.
- Rationale: in-memory per-worker `_miss_counts` silently fails at Tier 3 with 20+ worker replicas — each worker sees 1/N of global traffic and the threshold is never crossed in any single process.
- This is an observability signal — operators can install the correct pack and hot-reload without restarting.

---

#### Per-file selection — Pass 0 and Pass 1 optimisations

**Pass 0 — extension lookup:** O(1) dict lookup per file. Already optimal.

**Pass 1 — content heuristics (framework detection, ADR-0012):**
- All regex patterns in `detection_rules/*.yaml` are **compiled at registry load time** — not per file. Compilation cost is paid once at startup or hot-reload.
- Pass 1 reads only the **first `DETECTION_SCAN_BYTES` bytes** (env var, default: `4096`) — imports, decorators, and framework markers always appear near the top of a file.
- Detection rules within a pack are evaluated in **descending `confidence` order** — highest-confidence rule first.
- **Short-circuit:** if any `required` pattern in a rule fails to match, the rule is skipped immediately without evaluating `supporting` patterns.
- Full file bytes are passed to Pass 2 (`fast_extractor.extract()`) unchanged.

---

### Consequences

**Positive:**

- Open/Closed Principle: adding a language requires no changes to core code
- Language packs are independently versioned and testable
- `manifest.yaml` is machine-readable — registry can report installed packs, coverage gaps, and fidelity distribution without inspecting code
- `DefaultPack` guarantees the pipeline never stalls on an unknown file type
- Fidelity declared in manifest propagates automatically as confidence ceiling — no manual wiring
- Hot-reload: new or updated packs go live within seconds of a folder drop — no restart, no downtime
- Coverage gaps are observable via `language_pack.coverage_gap` Kafka events — operators notified before filing support tickets

**Negative / Trade-offs:**

- `manifest.yaml` schema must be kept stable; breaking changes require all packs to be updated
- `DuplicateExtensionError` at startup is fatal — operators must set `registry.priority` to resolve before workers start
- Extractor quality is only as good as the grammar; HEURISTIC packs produce lower-confidence results
- `watchdog` is an additional dependency; filesystem event delivery is OS-dependent (inotify on Linux, FSEvents on macOS, ReadDirectoryChangesW on Windows)

**Neutral / Operational notes:**

- `language_packs/` directory is mounted as a volume in containerised deployments
- CI must run `eval_schema_conformance` against all manifests in the folder on every PR
- `language_pack_coverage_report` MCP tool reads `_miss_counts` and installed pack list — add in Phase 2
- `DETECTION_SCAN_BYTES` and `COVERAGE_GAP_THRESHOLD` are tunable env vars; defaults suit most repos

---

### Alternatives Considered

| Alternative | Why Rejected |
|-------------|-------------|
| Static `ExtractorRegistry` (hardcoded dict) | Every new language = code change + deploy; violates Open/Closed Principle |
| Plugin entry points (setuptools) | Requires `pip install` per language; impractical for air-gapped deployments; no hot-reload |
| Database-driven registry | Adds DB dependency to worker startup; manifest.yaml is simpler and version-controllable |
| Single universal extractor with heuristics | Cannot achieve FULL fidelity for structured languages; degrades confidence across the board |
| File watcher with full registry rebuild on any change | Rebuilding all packs on a single-file change is wasteful; staged slot + atomic swap is cheaper |
| `importlib.reload()` for hot-reload | Unsafe — module-level state may not reset; `watchdog` + fresh module load into staging slot is cleaner |

---

### Compliance

- Contract: `constitution/contracts/08-language-pack-contract.md` — `registry.priority` field added to manifest spec
- Schema: `constitution/schemas/language-pack-manifest.schema.yaml`
- Schema: `constitution/schemas/facts-base-schema.json`
- ADR-0012: Pass 1 detection optimisations (compiled regexes, `DETECTION_SCAN_BYTES` scan limit, short-circuit evaluation) are specified here and implemented in the registry
- Eval: `eval_fallback_coverage` — verifies DefaultPack is invoked for unknown extensions
- Eval: `eval_fidelity_ceiling` — verifies confidence never exceeds pack-declared fidelity
- Eval: `eval_schema_conformance` — validates every facts.json against facts-base-schema.json
- Eval: `eval_hot_reload` — drops a new pack folder during an active ingest run; verifies subsequent files use the new pack and in-flight files complete without error
