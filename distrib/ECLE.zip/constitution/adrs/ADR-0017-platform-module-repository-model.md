# ADR-0017: Platform-Module Repository Model

**Status:** Accepted  
**Date:** 2026-05-06  
**Deciders:** Lead Engineer, Architecture Review  
**Supersedes:** —  
**Superseded by:** —  
**Amends:** ADR-0009 (cross-repo linking now operates within this model)

---

### FACT Impact

| Dimension | Impact |
|-----------|--------|
| **Fast** | Ingest-time isolation guarantees O(changed_files) ingestion cost. Module repo ingestion never triggers platform re-indexing. Cross-repo enrichment is query-time join on pre-indexed data — milliseconds, not minutes. |
| **Accurate** | Platform facts carry the same grounding guarantees as module facts. Enrichment is deterministic join, not inference. |
| **Complete** | Platform knowledge is always available to module queries. Changes to platform data propagate to answers at the next query — no stale enrichment window. |
| **Trustworthy** | Cross-repo enrichment is traceable: every enriched answer records which platform repo and version provided the enrichment data. |

---

### Context

ECLE 1.0 encountered a severe performance problem during the cross-repo linking phase.
When a new module repo was ingested, the system attempted to "enhance" it by linking it
against all previously indexed repos — re-running contract matching, re-computing shared
artifact tables, re-scoring similarity across all entities. As the number of onboarded
repos grew, this became prohibitively slow:

- Billing repo (module) + 3 platform repos → linking step took minutes
- Adding a fourth platform repo caused it to re-run for all existing module repos
- Human-understanding docs repo re-triggered full re-linking on every update

The root cause: **enrichment was happening at ingest time, not query time**. Every new
repo triggered cross-repo linking as part of its ingestion pipeline, compounding with
every previously onboarded repo.

ECLE 2.0 fixes this by formalizing a distinction that existed implicitly in practice:

**Platform repos** — shared, cross-cutting repos that provide reference context to all
module repos (DDL schemas, API contracts, shared docs, system-understanding documents).
They change rarely. Their knowledge enriches everything.

**Module repos** — individual service/application repos (billing, order management, etc.)
that contain the primary business logic. They change frequently. They consume platform
context at query time.

Examples from ECLE 1.0 PoC:

| Repo | Role | Why |
|------|------|-----|
| `shared_docs` | platform | Cross-cutting documentation used by all teams |
| `ddl_schemas` | platform | Database schema definitions shared across all services |
| `system_understanding` | platform | Human-readable system maps, domain vocabulary |
| `billing-service` | module | Individual service with its own logic |
| `payment-gateway` | module | Individual service |
| `reporting-engine` | module | Individual service |

---

### Decision

#### 1. `repo_role` is a first-class property of every repository

The `repositories` table carries a non-nullable `repo_role` field:

```
repo_role: platform | module
```

- Set at onboard time, not changeable without re-indexing.
- Default: `module` if not specified.
- Both roles go through **identical ingestion pipelines** — same workers, same events,
  same vector collections, same Structured DB tables.

#### 2. Platform repos are indexed in full isolation

A platform repo's ingestion run is entirely self-contained:

```
platform repo change
        │
        ▼
 parse_repo → persist_facts → batch_embed → topology_build → cluster_centroids
        │
        └── NO cross-repo cascade. No module repo re-indexing triggered.
```

Platform repo vectors live in the same collection naming scheme as module repos:
```
{tenant_id}__{repo_id}__layer1      ← file centroids (platform repo)
{tenant_id}__{repo_id}__layer2      ← function bodies (platform repo)
{tenant_id}__{repo_id}__layer3      ← cluster centroids (platform repo)
```

The `repositories.repo_role` field is what distinguishes them, not the collection name.

#### 3. Module repos are indexed in full isolation

A module repo's ingestion run is also entirely self-contained:

```
module repo change
        │
        ▼
 parse_repo → persist_facts → batch_embed → topology_build → cluster_centroids
        │
        └── NO platform re-indexing triggered. No other module re-indexing.
```

Module repos do NOT embed platform data into their own vectors. Platform enrichment is
resolved at **query time only**.

#### 4. Cross-repo enrichment is query-time, not ingest-time

When a query arrives for a module repo, the query engine enriches the response by
joining against pre-indexed platform repo data:

```
Query: "What touches TABLE_CUSTOMER_ACCOUNTS in billing-service?"
        │
        ├── Step 1: Structured DB lookup for billing-service (module) → 12 files
        │
        ├── Step 2: shared_artifacts join → TABLE_CUSTOMER_ACCOUNTS appears in
        │           ddl_schemas (platform) with 15 columns, 3 indexes
        │
        ├── Step 3: service_call_index join → system_understanding (platform) has
        │           human-readable description of CUSTOMER_ACCOUNTS purpose
        │
        └── Response: billing files + DDL enrichment + human context
                      All from pre-indexed data. Zero ingest-time work.
```

**The enrichment cost is bounded by the query, not by the number of repos.** Adding a
new platform repo does not cause any module repo to re-index.

#### 5. Neighbor propagation NEVER crosses repo boundaries

Topology edges within a module repo propagate normally (ADR-0007, Contract 13).

Cross-repo edges (module→platform or platform→module) are **reference edges only**:

| Edge direction | Type | Behavior |
|---------------|------|----------|
| module → module (same repo) | topology edge | Neighbor propagation applies |
| platform → platform (same repo) | topology edge | Neighbor propagation applies |
| module → platform | cross-repo reference edge | NO propagation. Reference only. |
| platform → module | cross-repo reference edge | NO propagation. Reference only. |

When a platform repo file changes:
1. Platform repo's own topology propagation runs (within platform repo only).
2. No module repo re-embeddings are triggered.
3. Module queries immediately benefit from updated platform data on next query.

When a module repo file changes:
1. Module repo's own topology propagation runs (within module repo only).
2. No platform repo re-indexing is triggered.

#### 6. Platform repos are hub-exempt at the system level

Platform repos are structurally equivalent to hub files (ADR-0007, Contract 13 §9):
they are referenced by many module repos but their change cost must not cascade.

The hub exemption rule from Contract 13 applies: platform repos' cross-repo edges
are exempt from neighbor-triggered context recompute by definition of `repo_role=platform`.
This does not need to be computed from centrality — it is a structural property.

#### 7. `cross_repo_edges` records enrichment provenance

Every cross-repo enrichment join that produces a fact in a response is recorded in
`cross_repo_edges`:

```sql
cross_repo_edges (
  source_repo_id      -- module repo
  source_file_id      -- specific file in module repo
  target_repo_id      -- platform repo
  target_artifact_id  -- specific artifact (table, service, field) in platform repo
  edge_type           -- SHARED_TABLE | SERVICE_CONTRACT | FIELD_DEFINITION | DOMAIN_DOC
  resolution          -- resolved | probable | unresolved_external
  resolved_at         -- timestamp
  is_current          -- boolean
)
```

This table is populated by `link_contracts` worker (ADR-0009) and by `ecle_shared_artifacts`
tool at query time (lazy resolution). It is NOT populated during module repo ingestion.

---

### Ingestion Sequencing

When onboarding a new tenant:

```
Step 1: Onboard all platform repos first (parallel)
         ├── ddl_schemas
         ├── shared_docs
         └── system_understanding

Step 2: Once platform repos are fully indexed, onboard module repos (parallel)
         ├── billing-service
         ├── payment-gateway
         └── reporting-engine

Step 3: Run contract linking (ADR-0009) — O(C log C)
         Runs once after all repos are indexed.
         Subsequent runs: triggered only when a repo publishes new contracts.
```

**Subsequent incremental updates:**
- Platform repo change → re-index platform repo only. No module re-index. No re-linking.
- Module repo change → re-index module repo only. Contract linking runs only for the
  changed repo's contracts (not all contracts).

---

### Day-2 Evolution Scenarios

The initial onboarding sequence covers a fresh tenant. Four additional scenarios must
be handled correctly without triggering the ECLE 1.0 cascade problem.

#### Scenario A: New artifact added to an existing platform repo

Example: a new DDL file `customer_v2.sql` is added to the `ddl_schemas` platform repo.

```
1. Platform repo detects change (git push / watcher)
2. Incremental ingestion runs for the changed/added files only (ADR-0013)
     parse_repo → persist_facts → batch_embed (new artifact only)
3. build_contract_registry runs for the new contracts extracted from the new file
4. link_contracts runs for the NEW contracts only — O(C_new log C_existing)
     This is NOT a full re-link. Only the new contracts are matched.
5. cross_repo_edges updated for new matches found.
6. Done. No module repo is touched.

Query effect: the next module query that references TABLE_CUSTOMER_V2 automatically
picks up the new DDL enrichment via query-time join. No module re-index needed.
```

**Cost: O(changed_platform_files)**

#### Scenario B: Entirely new platform repo onboarded (modules already exist)

Example: a new `audit_schemas` platform repo is added after 10 module repos are
already indexed.

```
1. New platform repo runs full initial ingestion (self-contained)
     parse_repo → persist_facts → batch_embed → topology_build → cluster_centroids
2. build_contract_registry runs for the new platform repo's contracts
3. link_contracts runs cross-repo: new_platform_contracts vs existing_module_contracts
     O(C_new_platform log C_all_existing)
     This is scoped to the new repo's contracts — NOT a re-link of all contracts.
4. cross_repo_edges populated for new matches.
5. Done. No existing module repo re-indexes.

Query effect: all existing module queries that reference artifacts in audit_schemas
immediately benefit from enrichment. The enrichment was unavailable before; it is now
available at query time without any action by module repo owners.
```

**Cost: O(new_platform_files + new_contracts × log(existing_contracts))**
**Zero cost to existing module repos.**

#### Scenario C: Entirely new module repo onboarded (platform repos already exist)

Example: a new `claims-service` module repo is added after the platform repos and
5 other module repos are already indexed.

```
1. New module repo runs full initial ingestion (self-contained)
     parse_repo → persist_facts → batch_embed → topology_build → cluster_centroids
2. build_contract_registry runs for the new module repo's contracts
3. link_contracts runs cross-repo: new_module_contracts vs existing_platform_contracts
     O(C_new_module log C_all_platforms)
     Also runs: new_module_contracts vs existing_module_contracts (ADR-0009 module-module links)
4. cross_repo_edges populated for new matches.
5. Done. No existing platform or module repo re-indexes.

Query effect: new module immediately benefits from all existing platform enrichment.
Existing module queries are unaffected (no cross-module contamination).
```

**Cost: O(new_module_files + new_contracts × log(existing_contracts))**
**Zero cost to all existing repos.**

#### Scenario D: Platform repo role changes (module → platform reclassification)

Example: `system_understanding` was initially onboarded as a module, now reclassified
as platform.

```
1. Update repositories.repo_role = 'platform' for the repo.
2. Trigger a full contract re-linking run for that repo only.
     link_contracts re-classifies all its cross_repo_edges as enrichment edges.
3. Propagation rules for that repo's topology edges are updated:
     cross-repo edges from this repo → all set to reference-only (no propagation).
4. No re-ingestion required. No re-embedding required. Metadata change only.
```

**This is a metadata-only operation. No re-indexing.**

---

### Invariants (Must Hold in All Scenarios)

| Invariant | Enforcement |
|-----------|-------------|
| A module repo ingest NEVER triggers another repo's re-ingest | `parse_repo` worker emits events scoped to `repo_id` only |
| A platform repo change NEVER re-indexes module repos | Topology propagation is bounded to `same repo_id` |
| `link_contracts` runs are scoped to changed contracts only | Worker consumes `contracts.registered` events per-repo; does NOT reload all contracts |
| Query-time enrichment is always available without re-linking | Cross-repo joins use `repositories.repo_role` directly; `cross_repo_edges` is advisory, not required for query execution |
| New platform repo → enrichment available on next query, zero module action | Query engine resolves enrichment lazily at query time via `repo_role` filter |

---

### Query-Time Enrichment Mechanics

Per ADR-0014 (Semantic-First Query Planning), the actual query mode distribution is:

| Mode | Share | Primary backend |
|------|-------|----------------|
| Semantic | ~55% | Vector index |
| Composite | ~30% | Vector → structured join |
| Structured | ~10% | Structured DB only |

Semantic and composite modes dominate. The enrichment mechanism is different for each.

#### Structured enrichment (applies in all three modes as a secondary step)

Platform enrichment for structured lookups is a **keyed lookup on pre-populated index
tables**, never a cross-repo scan:

```
shared_artifacts       — populated at platform repo ingest time, indexed on artifact_name
service_call_index     — populated at platform repo ingest time, indexed on artifact_name
field_extractions      — populated at platform repo ingest time, indexed on field_name
```

When a module query resolves a result (e.g., TABLE_CUSTOMER_ACCOUNTS touched by 12 files),
the enrichment step is:

```
SELECT * FROM shared_artifacts WHERE artifact_name = 'CUSTOMER_ACCOUNTS'
  — one indexed lookup, < 1ms, regardless of how many platform repos exist
```

The result row already carries `repo_id` of the platform repo that defined it. No
scan across platform repos. No fan-out. The platform repos are pre-merged into these
shared index tables at ingest time.

**Platform repo count has zero effect on enrichment query cost.** 10 platform repos or
100 — the query hits the same pre-indexed tables.

#### Semantic enrichment (~55% of queries)

Semantic queries operate on **named collections per ADR-0004**. A module query targets
the module's own collection:

```
{tenant_id}__{module_repo_id}__layer1     ← module file centroids
{tenant_id}__{module_repo_id}__layer2     ← module function bodies
```

Cross-repo capability discovery uses the single aggregated collection:

```
{tenant_id}__cross_repo__capabilities     ← cluster centroids from ALL repos, all roles
```

This collection is **pre-populated** by the `cluster_centroids` worker for every repo
(platform and module alike) as part of their own ingestion. A semantic search across
all repos is **one vector query against one collection** — not 30 separate queries
against 30 collections.

For a tenant with 10 platform repos + 20 module repos = 30 repos:
- Scoped module query → 1 collection searched
- Capability discovery → 1 cross_repo__capabilities collection searched
- Never: 30 collections searched in parallel or sequence

#### Composite enrichment (~30% of queries)

A composite query (e.g., "fee calculation files and what tables they touch") runs:

```
Step 1: Vector search in {tenant}__{module_repo}__layer1 → top-K file IDs
Step 2: Structured DB lookup for those file IDs → tables, functions, edges
Step 3: shared_artifacts keyed lookup for each table found → platform enrichment
```

Steps 1+2 are module-scoped. Step 3 is one keyed lookup per unique table name found —
bounded by the result set size, not by the number of platform repos.

#### Fan-out is explicit and bounded, never implicit

A cross-repo sweep ("find everything about fee calculation across all repos") is a
distinct query mode that MUST be explicitly requested by the caller via `query_intent`.
It is not triggered by default. When executed:

- Fan-out targets at most: `cross_repo__capabilities` (1 collection) + up to 5
  module-specific collections if `repo_ids` is specified in the request
- Never targets all collections unconditionally
- The `query_intent = 'cross_repo_sweep'` signal gates this at the query planner level

**Rule: the query engine MUST NOT fan out across all repo collections without an
explicit `repo_ids` list or `query_intent = 'cross_repo_sweep'` in the caller request.
Implicit fan-out is a performance violation.**

---

### Cross-Repo Scale Mitigations

The query-time enrichment mechanics above are correct at hundreds of repos. At thousands
of repos two specific bottlenecks emerge. Three mitigations are encoded here.

#### Mitigation 1 — `repo_scope[]` cap on cross-repo sweep

The `cross_repo_sweep` query mode fans out across the `cross_repo__capabilities`
collection. At 10K repos × 500 clusters/repo = 5M centroid vectors, ANN latency
degrades linearly (~200ms). Additionally the calling agent almost always has context
about which repos are relevant.

**Rule:** `ecle_cross_repo_links` and any tool using `query_intent='cross_repo_sweep'`
MUST accept a `repo_scope[]` parameter:

| `repo_scope` provided | Behaviour |
|---|---|
| Populated (e.g. `["billing", "payment-gateway"]`) | ANN filtered to those repos' cluster centroids only. N repos × 500 clusters = small, bounded search. |
| Absent | `MAX_CROSS_REPO_REPOS` cap applies (default: `50`). ANN is bounded to top-50 repos by last-activity recency. |

`MAX_CROSS_REPO_REPOS` is a deployment constant, tunable per tier:

| Tier | Default |
|---|---|
| `dev` | 10 |
| `compose` | 25 |
| `enterprise` | 50 |

Implicit fan-out to all collections without `repo_scope` or the cap guard is a
**performance violation** (existing rule, reinforced here).

#### Mitigation 2 — Batch structured enrichment lookups

The current structured enrichment path issues one SQL round-trip per repo result:

```
# WRONG — N sequential round-trips
for repo_id in matched_repo_ids:
    rows = db.query("SELECT * FROM shared_artifacts WHERE repo_id = ?", [repo_id])
```

`cross_repo_lookup` step MUST use a single batched query:

```sql
-- ONE round-trip regardless of result count
SELECT * FROM shared_artifacts
WHERE tenant_id = :tenant_id
  AND repo_id    = ANY(:repo_ids)
  AND is_current = TRUE;
```

Same pattern for `service_call_index` and `field_extractions`. All three enrichment
tables support this via their existing `(tenant_id, artifact_name)` indexes.
Batched queries reduce 30 sequential round-trips to 3 parallel round-trips.

#### Mitigation 3 — Materialized `cross_repo_summary` (async, Kafka-triggered)

At 5K+ repos the `cross_repo__capabilities` collection itself becomes the bottleneck.
Mitigation 1 (cap) is a query-time guard; Mitigation 3 is a pre-computation that makes
the guard unnecessary for common patterns.

**Mechanism:** A new worker `cross_repo_indexer` consumes the `repo.indexed` Kafka
event (emitted by `cluster_centroids` when a repo's indexing run completes) and
maintains a materialized `cross_repo_summary` table — one row per repo, one
pre-computed summary vector per repo:

```
Kafka: repo.indexed { repo_id, tenant_id, cluster_ids[] }
                ↓
        cross_repo_indexer (consumer group)
                ↓
  1. Fetch Layer 3 centroid vectors for all clusters in this repo
  2. Compute mean → repo-level summary vector (384-dim)
  3. Upsert cross_repo_summary row for this repo
  4. Done — no other repo touched, no blocking
```

**This is entirely async and non-blocking:**
- The `repo.indexed` event is consumed after ingestion completes — no ingestion stall
- `cross_repo_indexer` runs as a separate consumer group — does not delay `cluster_centroids`
- If `cross_repo_indexer` is lagging, queries fall back to direct `cross_repo__capabilities`
  ANN without error — `cross_repo_summary` is an acceleration, not a dependency

**Query-time use:**

```
# With cross_repo_summary available (Phase 2+, enterprise tier):
ANN over cross_repo_summary (N_repos vectors, 384-dim)  →  top-10 repo_ids
                ↓
ANN over cross_repo__capabilities filtered to those 10 repos → top-K clusters
                ↓
Structured hydrate (batched per Mitigation 2)
```

This reduces the ANN search space from 5M cluster centroids to `N_repos` repo-level
vectors (10K vectors → trivially fast, ~1ms), then a second scoped ANN over ~5,000
cluster centroids for just those repos.

**Table:** `cross_repo_summary` — see Contract 15 §2.

**`cross_repo_indexer` worker properties:**

| Property | Value |
|---|---|
| Trigger | `repo.indexed` Kafka event |
| Consumer group | `cross_repo_indexer` |
| Idempotent | Yes — upsert on `(tenant_id, repo_id)` |
| Phase | 2 (requires vector store) |
| Tier | All (no-op at dev if `EMBED_LAYERS=1`) |
| Blocking | Never — async consumer, no ingestion pipeline dependency |

---

### Consequences

**Positive:**

- Cross-repo enhancement becomes a query-time join — O(1) per query regardless of
  number of platform repos
- Module repo ingestion cost is strictly O(changed_module_files) — never grows with
  platform repo count
- Platform repo updates immediately improve all module queries — no re-ingest cycle
- Hub cascade problem is eliminated by structural rule, not by centrality heuristic

**Negative / Trade-offs:**

- `repo_role` must be set correctly at onboard time — wrong role assignment causes
  incorrect propagation behavior
- Contract linking (ADR-0009) must be aware of `repo_role` to classify edge direction
- Queries that span both platform and module repos require the query engine to join
  across collection namespaces — adds one additional lookup step

**Neutral / Operational notes:**

- Both platform and module repos can be re-indexed on demand without affecting the other
- Tier 3 non-code docs (human-understanding repos, shared_docs) are still classified as
  `repo_role=platform` even though their content is `content_type=docs` — the role is
  about their structural position in the system, not their content type
- A platform repo that contains code (e.g., a shared library) is indexed with full CPG
  depth — `repo_role=platform` does not imply lightweight indexing

---

### Alternatives Considered

| Alternative | Why Rejected |
|-------------|-------------|
| Re-run cross-repo linking on every module ingest | O(repos²) at scale. Proven to be the bottleneck in ECLE 1.0 PoC. |
| Embed platform facts into module repo vectors | Couples module ingest to platform state. Platform update forces all module re-embedding. Violates isolation. |
| Single flat repo model, no role distinction | Cannot express hub exemption. Cannot sequence onboarding. Cannot isolate cascade. |
| Distinguish roles only at query time (no DB field) | Unenforceable. Workers cannot apply correct propagation rules without a declared role. |

---

### Compliance

- ADR-0003: Three-Backend Architecture — `cross_repo_edges` lives in Structured Fact DB
- ADR-0004: Multi-Layer Vector Store — `cross_repo__capabilities` collection is the single aggregated entry point for cross-repo semantic queries; `repo_role` is metadata in `repositories` table
- ADR-0007: Topology Edge Contract — cross-repo edges are reference edges (propagation exempt)
- ADR-0009: Contract-First Cross-Repo Linking — amended: contract linking runs within this model's sequencing rules
- ADR-0011: Louvain Community Detection — clustering runs per-repo; no cross-repo cluster merging
- **ADR-0014: Semantic-First Query Planning** — query mode distribution (Semantic ~55%, Composite ~30%, Structured ~10%) governs enrichment path; enrichment mechanics section above is authoritative for cross-repo join cost
- Contract 13: Incremental Ingestion — propagation bounds apply within-repo only (§9 hub exemption)
- Contract 15: DB Schema — `repositories` table carries `repo_role` field
