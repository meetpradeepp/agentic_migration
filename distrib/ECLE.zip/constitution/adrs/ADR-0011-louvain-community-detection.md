# ADR-0011: Louvain Community Detection for Structural Clustering

**Status:** Accepted  
**Date:** 2026-05-05  
**Deciders:** Lead Engineer, Architecture Review  
**Supersedes:** —  
**Superseded by:** —  
**FACT impact:**
- Fast: `improves` — O(E log E) Louvain vs O(N²) pairwise comparison; community pre-filtering reduces ANN search space per cluster query
- Accurate: `improves` — communities grounded in actual code dependencies (call graph, data flow, imports), not embedding proximity; `cluster_alignment` confidence dimension becomes meaningful
- Complete: `improves` — every file gets a `cluster_id`; no file is orphaned; DefaultPack files still cluster by topology even without embeddings
- Trustworthy: `improves` — deterministic algorithm on a deterministic graph; same topology → same communities; traceable from cluster assignment back to graph edges

---

### Context

ECLE needs to group files into communities for three purposes:
1. **Query scoping** — answer "which files are part of the billing subsystem?" without full-corpus scan
2. **Confidence scoring** — `cluster_alignment` (dimension 5 of 6) measures how well a file fits its cluster after re-embedding; requires a cluster assignment to exist first
3. **Semantic enrichment** — `ontology_enricher` annotates clusters with domain vocabulary, not individual files; cluster granularity is the right unit for domain meaning

The naive approach — clustering in vector space using k-means or hierarchical clustering on embeddings — has a critical flaw: it groups files by *textual similarity*, not by *structural dependency*. Two files with very similar names and function signatures but no runtime relationship would be placed in the same cluster. Two interdependent files with different vocabularies (a DataWindow and its SQL proc) would be split.

ECLE 1.0 used Louvain community detection on the code topology graph. Communities were stable, interpretable, and aligned with subsystem boundaries (billing, policy, rating, reporting). This was the most useful structural abstraction for domain annotation.

---

### Decision

We will run Louvain community detection on the **topology graph** (not on the vector space) to assign every file a `cluster_id`.

**Two-phase cluster assignment:**

1. **Phase A — Topology clustering (Louvain):**  
   The `compute_topology` worker runs Louvain on the weighted directed graph of topology edges (FUNCTION_CALL, WRITE_READ, EXECUTION_SEQUENCE, IMPORT, STATE_FLOW edges). Edge weights from `topology_edges.weight` column.

   **Resolution parameter γ — auto-scaled by repo size:**
   ```
   LOUVAIN_RESOLUTION_AUTO = true   (default)
   γ = 0.5 + 0.5 × log10(max(file_count, 10)) / log10(1_000_000)
   Range: 0.5 (tiny repos) → 1.0 (1M-file monoliths)
   ```
   Fixed override: `LOUVAIN_RESOLUTION` env var (range 0.5–2.0). Auto-scale is disabled when the override is set.

   **Singleton exclusion:** Files with no topology edges (zero in-degree AND zero out-degree) are assigned `cluster_id = null` in `file_facts` and excluded from all cluster-downstream work (Layer 3, `ontology_enricher`, centroid computation). `LOUVAIN_MIN_CLUSTER_SIZE` (default: `2`) is the minimum membership for a cluster to be materialized; clusters below this threshold collapse their members to `cluster_id = null`. Queries for files with `cluster_id = null` skip Layer 3 and start at Layer 1 directly.

   Produces `cluster_id` per file (or `null` for singletons).

2. **Phase B — Vector centroid (batch_embed):**  
   After Phase A, `cluster_centroids` worker computes Layer 3 centroid vectors by averaging all Layer 1 file vectors within a cluster. Centroid vectors stored in collection `{tenant}__{repo}__layer3`. `cluster_alignment` confidence dimension is the cosine similarity between a file's Layer 1 vector and its cluster's Layer 3 centroid.

The `cluster_id` written to `file_facts` and the slim vector payload in Phase A is the authoritative cluster assignment. Phase B centroids are derived from it — not the other way around.

**Louvain is the right algorithm here because:**
- It finds communities at multiple resolutions via `γ` parameter — billing at γ=1.0 may split into invoice-generation and fee-calculation at γ=1.5; both are valid
- It handles disconnected subgraphs — isolated files become singletons, excluded via `LOUVAIN_MIN_CLUSTER_SIZE`
- It is O(E log E) where E = edges — fast at ECLE's scale
- It produces stable community IDs across re-runs on the same graph (deterministic given sorted edge input)

**Incremental re-clustering (scale mitigation):**

Running full-graph Louvain on every `graph.updated` event is O(E log E) per file change — prohibitive at enterprise scale with active development.

The `compute_topology` worker uses **subgraph-bounded re-clustering** instead:

```
graph.updated { changed_file_ids[] }
    │
    ▼
Expand 2-hop neighbourhood of all changed_file_ids
    │
    ├── subgraph_size ≤ LOUVAIN_INCREMENTAL_THRESHOLD (default: 5000 files)?
    │     YES → run Louvain on subgraph only
    │           write updated cluster_ids for files in subgraph
    │           emit topology.updated { scope: "incremental", affected_cluster_ids[] }
    │
    └── subgraph_size > threshold OR spanning_ratio > 0.3 (>30% of repo)?
          → promote to full re-run
            emit topology.updated { scope: "full", affected_cluster_ids[] }
```

Configuration constants:

| Constant | Default | Meaning |
|---|---|---|
| `LOUVAIN_INCREMENTAL_THRESHOLD` | `5000` | Max subgraph size before promoting to full re-run |
| `LOUVAIN_SPANNING_RATIO` | `0.3` | If subgraph spans > 30% of repo files → full re-run |
| `LOUVAIN_MIN_CLUSTER_SIZE` | `2` | Min members for a cluster to be materialized |
| `LOUVAIN_RESOLUTION_AUTO` | `true` | Auto-scale γ by log10(file_count) |
| `LOUVAIN_RESOLUTION` | _(unset)_ | Fixed γ override; disables auto-scale when set |

---

### Cluster stability contract

Two identifiers per cluster — **stability ID** and **version counter**:

```
cluster_stable_id = SHA256(sorted(file_ids_in_cluster))[:16]   ← changes when membership changes
cluster_version   = integer, monotonically incrementing          ← bumped on every membership change
```

Downstream workers consume `cluster_stable_id` as the join key. `cluster_version` signals staleness.

**Drift threshold — controls when downstream recompute fires:**

Small membership fluctuations (single file added/removed) should not cascade recomputes across hundreds of files. The `compute_topology` worker tracks membership change ratio:

```
drift = |new_members △ old_members| / max(|old_members|, 1)
```

| `drift` | Action |
|---|---|
| ≤ `LOUVAIN_DRIFT_THRESHOLD` (default `0.05`) | Update `cluster_stable_id` and `cluster_version` in DB. **Do NOT emit centroid/enrichment recompute.** |
| > threshold | Update IDs + emit `topology.updated` with `recompute: true` → triggers `cluster_centroids` + `ontology_enricher` |
| Cluster dissolved (all members reassigned) | Always triggers recompute |

This means a cluster gaining or losing 1 file in a 100-file cluster (drift = 0.01) does **not** recompute centroids or enrichment — eliminating the O(cluster_size) cascade from single-file commits.

---

### Cluster stabilization parameters

After every Louvain run, `ClusterStabilizer.stabilize()` applies three proven thresholds
(ECLE 1.0, SPEC-018) before writing cluster assignments to `file_facts`. These prevent
oscillation on incremental commits and enforce minimum cluster lifetimes.

| Constant | Default | Meaning |
|---|---|---|
| `LOUVAIN_STABILIZER_MIN_DELTA` | `1.5` | Minimum modularity gain required to reassign a file to a different cluster. A file MUST NOT be moved unless the new cluster produces ≥ 1.5 more modularity than the current assignment. Prevents oscillation from marginal improvements on small incremental commits. |
| `LOUVAIN_STABILIZER_MIN_LIFETIME` | `10` | Minimum number of commits a cluster must exist before it can be dissolved or merged into another cluster. New clusters formed in the last 10 commits are protected from immediate reassignment — gives rapidly evolving subsystems time to stabilize. |
| `LOUVAIN_STABILIZER_MAX_CLUSTER_SIZE` | `500` | Maximum files in a single cluster. Clusters exceeding this size are flagged for a sub-Louvain run at the next full re-run, splitting the oversized cluster into sub-communities. A 500-file cluster is too coarse for domain annotation. |

**Rules:**
1. A file's `cluster_id` MUST NOT change unless the reassignment modularity gain ≥ `LOUVAIN_STABILIZER_MIN_DELTA`. If the gain is below threshold, the file retains its current `cluster_id` for this commit.
2. A cluster created within the last `LOUVAIN_STABILIZER_MIN_LIFETIME` commits MUST NOT be dissolved or merged — even if a subsequent Louvain run would eliminate it. The cluster's `cluster_version` is bumped; membership changes are allowed; dissolution is deferred.
3. A cluster exceeding `LOUVAIN_STABILIZER_MAX_CLUSTER_SIZE` triggers a sub-Louvain run on that cluster at the next full re-run (scope = that cluster's file set). The sub-run produces new child cluster IDs; the parent `cluster_stable_id` is retired.

These three constants are enforced by `compute_topology` and verified by `eval_cluster_stability`.
- Files whose `cluster_stable_id` changes AND `drift > threshold` → `cluster_alignment` reset to `null` pending centroid recompute
- Files whose `cluster_stable_id` changes but `drift ≤ threshold` → `cluster_alignment` unchanged; no recompute
- Files whose `cluster_stable_id` is unchanged → `cluster_alignment` unchanged; no re-embedding needed

| Constant | Default | Meaning |
|---|---|---|
| `LOUVAIN_DRIFT_THRESHOLD` | `0.05` | Max membership change ratio before triggering downstream recompute |

---

### Worker responsibility

| Worker | Trigger | Output |
|---|---|---|
| `compute_topology` | `graph.updated` event | Runs Louvain; writes `cluster_id` to `file_facts`; emits `topology.updated` with per-cluster change summary |
| `cluster_centroids` | `topology.updated` event (clusters changed) OR `file.embedded` event (new file in existing cluster) | Averages Layer 1 vectors per cluster; upserts Layer 3 centroid to vector store; updates `cluster_alignment` for all files in changed clusters |
| `ontology_enricher` | `topology.updated` event | Reads cluster membership; maps cluster to domain vocabulary; writes `dsl_mappings` and `ontology_annotations`; emits `ontology.enriched` |

---

### Alternatives Considered

| Alternative | Why Rejected |
|---|---|
| K-means on vector space | Groups by textual similarity, not structural dependency; billing DataWindow and its SQL proc would be split; cluster boundaries don't map to subsystems |
| DBSCAN on vector space | Requires epsilon tuning per repo; produces noise points (unclustered files); no natural resolution parameter |
| Hierarchical agglomerative clustering | O(N² memory) at scale; dendrogram cuts are arbitrary; no stable community IDs |
| Spectral clustering | Requires full graph Laplacian — O(N³) for eigendecomposition; impractical at 50K+ files |
| Connected components only (no community detection) | Too coarse — one large component for a 500K-file monolith; no subsystem granularity |
| Leiden algorithm | Improvement over Louvain for resolution-limit problem; valid candidate for Phase 2 benchmark; Louvain sufficient for Phase 1 |

---

### Compliance

- Contract: `constitution/contracts/05-confidence-contract.md` — `cluster_alignment` dimension requires `cluster_id` from this ADR
- Contract: `constitution/contracts/12-embedding-contract.md` — Layer 3 centroid computation depends on `cluster_id` written here
- Contract: `constitution/contracts/04-fact-contract.md` — `semantic.domain_concepts` in FACT envelope populated by `ontology_enricher` which uses cluster membership from this ADR
- Schema: `constitution/schemas/facts-base-schema.json` — `cluster_id` field (to be added)
- ADR-0003: `ITopologyGraph` interface provides the graph; Louvain runs over it
- ADR-0004: `cluster_id` in slim vector payload sourced from this ADR's Phase A output

---

### References

| # | Citation | Relevance to this ADR |
|---|----------|----------------------|
| R1 | Blondel, V.D. et al. "Fast unfolding of communities in large networks", J. Stat. Mech. 2008 (arXiv:0803.0476) | The Louvain algorithm paper (~17,000 citations). Tested on 118M-node web graph and 2.6M-node phone network. Validates scalability for ECLE's topology graph. |
| R2 | Edge, D. et al. "From Local to Global: A Graph RAG Approach to Query-Focused Summarization", 2024 (arXiv:2404.16130) | Microsoft GraphRAG uses the same pattern: extract entity graph → Louvain community detection → community summaries → hybrid retrieval. ECLE's architecture is GraphRAG applied to code. |
| R3 | Traag, V.A. et al. "From Louvain to Leiden: guaranteeing well-connected communities", Scientific Reports 2019 | Leiden algorithm improves Louvain's resolution-limit problem; validates our Phase 2 benchmark plan |
| R4 | Liu, X. et al. "Evaluating the Factuality of LLMs using Large-Scale Knowledge Graphs", 2024 (arXiv:2404.00942) | Knowledge graphs as ground truth for factuality evaluation — validates ECLE's graph-backed FACT model |
