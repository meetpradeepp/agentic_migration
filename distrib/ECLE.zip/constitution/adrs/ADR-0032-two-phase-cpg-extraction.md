# ADR-0032: Two-Phase CPG Extraction (Structural → Deep)

**Status:** Accepted
**Date:** 2026-05-09
**Deciders:** Lead Engineer, Architecture Review
**Supersedes:** —
**Superseded by:** —
**Amends:** ADR-0016 (extraction depth — two ordered phases formalised; structural artifacts are intermediate stage, not a committed DB tier), Contract 08 (language pack — `fast_extractor.py` is now the primary path, `extractor.sc` is reference/fallback only), Contract 09 (event pipeline — adds `repo.structural_complete` Kafka event), Contract 13 (incremental ingestion — phase-aware skip gate)

---

### FACT Impact

| Dimension | Impact |
|-----------|--------|
| **Fast** | `neutral` — structural phase adds 5–10 min of pre-Joern processing. DB availability is unchanged versus single-phase (users still wait for Joern to complete before facts are committed). Pipeline throughput is the same — deep Joern extraction is the bottleneck in both models. |
| **Accurate** | `improves` — every committed `file_facts` row is at full depth by construction. There are no mixed-tier confidence profiles in the DB; all committed rows carry the manifest-declared `behavioral_accuracy` ceiling (0.95 for FULL packs). No partial facts are ever queryable. |
| **Complete** | `neutral` — users still wait for the deep (Joern) phase to complete before any facts are available. Coverage is the same as single-phase Joern extraction; the two-phase pipeline is an implementation detail, not a coverage improvement. |
| **Trustworthy** | `improves` — `_extraction_tier` is internal pipeline plumbing only; it is never surfaced in the DB, confidence profiles, or MCP responses. All committed facts are full depth — no hidden partial states, no tier-mixing, no silent accuracy degradation. The `persist_facts` guard raises `ValueError` if `_extraction_tier` is present at commit time, making the invariant machine-enforced. |

---

### Context

Onboarding a 3,000-file enterprise codebase through ECLE's `parse_repo` worker runs Joern
CPG extraction per file. Measured on a 16 GB Windows host:

| Extraction path | Time per file | 3,000-file repo | Knowledge graph available |
|----------------|---------------|-----------------|--------------------------|
| Joern (deep) | 30–60s/file | ~25–50 hours | Only after **all** files complete |
| Tree-sitter (structural) | <100ms/file | ~5 min | After **each** file completes |

The knowledge graph is entirely unavailable during Joern extraction. A single failed file
blocks the entire repo job. Developers cannot query ECLE until the multi-hour run finishes.

Tree-sitter, already the primary parser per Contract 08 and ADR-0016, produces facts that
are sufficient for the majority of MCP tool queries:

- Function names, signatures, call graph (syntactic) → answerable
- SQL table operations, literals, imports → answerable
- Type-resolved call targets, data flow edges, PDG → requires Joern deep phase

The insight proven in the pb_parse sister project (see `ideas/SPEC-062-joern-jvm-and-batching.md`):
two sequential extraction passes on the same file produce a superset of facts, not a
duplication of work. Structural facts are a strict subset of deep facts. The deep phase
*enriches* the structural facts — it does not replace them from scratch.

This ADR formalises the two-phase model as an ECLE 2.0 constitutional rule.

---

### Decision

We will extract every repository in **two ordered phases**, each triggered by a Kafka event.
The phases share the `parse_repo` worker code but run as independent Kafka consumer
instances consuming different topics. No ImportJob queue, no polling — the event itself
is the trigger.

**Pipeline event chain:**

```
upload.received
    ↓ scan_source
repo.detected
    ↓ parse_repo (structural mode — consumes ecle.repo.detected)
      fast_extractor.py per file → .facts.json to artifact store (no DB write)
      emits ONE repo.structural_complete per repo
    ↓ Kafka: ecle.repo.structural_complete
parse_repo (deep mode — consumes ecle.repo.structural_complete)
      extractor.sc (Joern) per file
      reads structural .facts.json via JOERN_EXISTING_FACTS env var
      applies field-by-field merge (see merge table below)
      removes _extraction_tier from final artifact
      emits file.ir_produced per file + repo.ir_produced
    ↓ Kafka: ecle.file.ir_produced
persist_facts → file_facts DB (ONCE, always full depth)
```

**Phase 1 — Structural (Tree-sitter, `parse_repo` structural mode):**
- Parser: `fast_extractor.py` in the language pack (tree-sitter grammar traversal)
- Output: `.facts.json` written with `"_extraction_tier": "structural"`
- Destination: artifact store only — `{artifact_root}/{repo_id}/{commit_sha}/facts/<file_id>.facts.json`
- No DB write. No `file.ir_produced` event emitted.
- On repo completion: emits exactly ONE `repo.structural_complete` event (see payload below)
- Speed: <100ms/file; full 3,000-file repo completes in ~5 minutes

**Phase 2 — Deep (Joern, `parse_repo` deep mode):**
- Trigger: `repo.structural_complete` Kafka event
- Parser: `extractor.sc` Joern CPG script
- Joern receives path to structural `.facts.json` via `JOERN_EXISTING_FACTS` env var
- Joern enriches the structural artifact field-by-field using the merge table (below)
- Deep phase removes `_extraction_tier` from the final artifact before emitting
- Emits `file.ir_produced` per successfully processed file
- Emits `repo.ir_produced` after all files processed
- Speed: 30–60s/file; full 3,000-file repo takes ~25–50 hours

**`repo.structural_complete` payload (Contract 09 §3):**

```json
{
  "repo_id":     "string  — identifies the repo",
  "tenant_id":   "string  — tenant isolation (ADR-0022)",
  "artifact_dir":"string  — path to {repo_id}/{commit_sha}/facts/ in artifact store",
  "file_count":  "int     — total files processed in structural phase",
  "failed_files":"list[str] — file IDs where tree-sitter error-node ratio > 5%; Joern will run from scratch on these",
  "commit_sha":  "string  — git commit SHA of the extracted state"
}
```

**`_extraction_tier` field rules:**
- `fast_extractor.py` MUST set `"_extraction_tier": "structural"` in every facts dict it produces.
- The deep phase MUST remove `_extraction_tier` from the merged artifact before writing to disk.
- `persist_facts` MUST raise `ValueError` if `_extraction_tier` is present in the artifact at commit time:

```python
tier = facts.get("_extraction_tier")
if tier is not None:
    raise ValueError(
        f"Artifact {artifact_path!r} still carries _extraction_tier={tier!r}. "
        "Deep enrichment did not complete. Cannot commit partial facts."
    )
```

This guard is the machine-enforced invariant that ensures no partial artifacts reach the DB.
**There is no `extraction_tier` column on `file_facts`.** All committed rows are full depth
by construction — the DB schema needs no tier column.

**Field merge table — Structural → Deep (proven in ECLE 1.0, SPEC-049):**

The deep phase applies the following merge rules when combining Joern output with the
structural `.facts.json`. This table is authoritative — implementations MUST NOT deviate.

| Fact field | Tree-sitter produces | Joern produces | Merge rule |
|---|---|---|---|
| Function names | Yes | Yes | **Keep** either (identical) |
| Function complexity | Basic (nesting depth) | Full (cyclomatic) | **Replace** with Joern |
| Function parameters | Names only | Names + types | **Replace** with Joern |
| Local variables | No | Yes | **Add** from Joern |
| SQL statements | String-scanned (basic) | Fully classified (READ/WRITE/DDL) | **Replace** with Joern |
| Table operations | Partial | Full | **Replace** with Joern |
| Dependencies | Yes (syntactic) | Yes (resolved) | **Union** (deduplicate by `id`/`name+line`) |
| Call graph | Static name | Type-resolved targets | **Replace** with Joern |
| Struct definitions | Yes | No | **Keep** tree-sitter |
| Macro definitions | Yes | No | **Keep** tree-sitter |
| Typedefs | Yes | No | **Keep** tree-sitter |
| Preprocessor branches | Yes | No | **Keep** tree-sitter |
| Data flow edges | No (empty `[]`) | Yes | **Add** from Joern |
| Control flow edges | No (empty `[]`) | Yes | **Add** from Joern |
| Comments | File-read | CPG-extracted | **Replace** with Joern |
| Execution sequence | Basic | With data flow | **Replace** with Joern |

**Failed-file handling:**
- Files listed in `failed_files[]` of `repo.structural_complete` had tree-sitter error-node
  ratio > 5% in structural phase (Contract 08 §4 fallback threshold).
- The deep phase runs Joern from scratch for these files (no structural `.facts.json` to merge from).
- The resulting artifact has `_extraction_tier` absent (removed by deep phase) — correct full-depth output.

**Artifact store lifecycle:**
- Structural `.facts.json` files are written to `{artifact_root}/{repo_id}/{commit_sha}/facts/`.
- The deep phase reads them via `JOERN_EXISTING_FACTS` and writes enhanced artifacts in-place.
- After `persist_facts` commits successfully (all `file.stored` events for the repo), the artifact
  store files may be cleaned up per ADR-0021 (Data Lifecycle) retention policy.
- If deep phase fails mid-repo, the structural artifacts remain in the store — the deep phase
  can be retriggered by replaying the `repo.structural_complete` event from Kafka.

**Confidence ceiling:**
All committed `file_facts` rows use the ceiling declared in the language pack's `manifest.yaml`
(`extraction_depth: full` → ceiling 0.95). There are no per-tier ceiling rules. The manifest
ceiling is the only ceiling.

---

### Consequences

**Positive:**
- Single DB write per file — no double-persist, no tier-promotion logic, no in-place update exception to Contract 15.
- All committed facts are at full depth (manifest-declared confidence ceiling consistently applied).
- Joern operates on pre-structured artifacts (enrichment, not from-scratch) — faster than running Joern cold on every file.
- Pipeline is fully event-driven end-to-end; no polling, no ImportJob queue for phase handoff.
- Replay is safe: `repo.structural_complete` can be replayed from Kafka to re-trigger deep without re-running structural.
- DB schema is simpler — no `extraction_tier` column, no `CHECK` constraint, no migration required.

**Negative / Trade-offs:**
- Users see zero queryable facts until the deep (Joern) phase completes for the repo. No progressive visibility.
- Artifact store must retain structural `.facts.json` files for the duration of deep extraction (disk space: one `.facts.json` per file in the repo during the processing window).
- Deep extraction failure with no structural artifact fallback (artifact store lost) means user must re-run from scratch.

**Neutral / Operational notes:**
- `_extraction_tier` in intermediate artifacts is internal pipeline plumbing — never surfaced in `file_facts`, confidence profiles, or MCP tool responses.
- Language packs without a `fast_extractor.py` (none in ECLE 2.0 — all packs ship one per Contract 08) fall back to running Joern in structural phase. `repo.structural_complete` is still emitted; the deep phase sees the artifact and skips-or-enriches per the merge table.
- PowerBuilder uses the `powerscript` JAR in structural phase. `_extraction_tier: "structural"` is set by the PB `fast_extractor.py` wrapper. Deep phase treats PB artifacts identically.

---

### Alternatives Considered

| Alternative | Why Rejected |
|-------------|-------------|
| Single phase: only Joern, run faster | The JVM-startup overhead is architectural; per-file mode for 3,000 files is 25–50 hours regardless of tuning. Does not change the zero-DB-availability window. |
| Single phase: only Tree-sitter, drop Joern | Loses DFG, type resolution, PDG — facts that enterprise queries (impact analysis, data flow) require. ECLE's FACT/Complete guarantee cannot be met without Joern. |
| Progressive enrichment (commit structural first, promote to full on deep completion) | Creates double-write to `file_facts`, requires an in-place update exception to Contract 15's append-only rule, and forces all query paths to handle mixed-tier confidence profiles. The added complexity outweighs the benefit of earlier visibility — rejected in favour of single-commit simplicity. |
| Separate file-level event for structural (`file.structural_produced`) | Structural artifacts are intermediate; broadcasting them as a first-class Kafka event invites downstream workers to consume half-finished data. A single repo-level event (`repo.structural_complete`) is the correct boundary signal — it asserts the full repo is structurally ready for deep extraction. |
| Parallel extraction (structural + deep simultaneously) | Race condition on artifact store files. Deep merge must not start until structural `.facts.json` is complete per file. Sequential is required by the merge table semantics. |
| ImportJob queue for phase handoff (initial design) | Introduces polling, queue management UI complexity, and a non-Kafka communication path between phases. Violates Contract 09 §0 Rule 1 (Kafka is the only inter-component channel). Replaced by `repo.structural_complete` Kafka event. |

---

### Compliance

- Contract: `constitution/contracts/08-language-pack-contract.md` — `fast_extractor.py` is primary path; `extractor.sc` is reference/fallback
- Contract: `constitution/contracts/09-event-pipeline-contract.md` — `repo.structural_complete` event added to §3 catalogue; `parse_repo` SRP updated in §4
- Contract: `constitution/contracts/13-incremental-ingestion-contract.md` — phase-aware skip gate in §3
- Contract: `constitution/contracts/19-cpg-extraction-tier-contract.md` — full tier governance rules (artifact store lifecycle, `_extraction_tier` guard, merge table authority)
- Schema: `constitution/schemas/facts-base-schema.json` — `_extraction_tier` field (intermediate artifact only; absent from committed facts)
- Eval: `eval_two_phase_cycle` — structural parse completes → `repo.structural_complete` emitted on `ecle.repo.structural_complete` → deep triggered → `file.ir_produced` emitted per file → `persist_facts` commits once → no `_extraction_tier` in any committed artifact → single `file_facts` row per file at full depth
- Eval: `eval_idempotent_ingest` — replay `repo.structural_complete` → deep re-runs → `ON CONFLICT DO NOTHING` on `file_facts` → no duplicate rows
- Eval: `eval_fidelity_ceiling` — all committed `file_facts` rows carry manifest-declared ceiling (0.95 for FULL packs); no 0.70-ceiling rows present
