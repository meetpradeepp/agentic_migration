# ADR-0035: Each Phase is a Product Milestone

**Status:** Accepted
**Date:** 2026-05-12
**Deciders:** Lead Engineer, Architecture Review
**Supersedes:** —
**Superseded by:** —
**Amends:** Contract 17 (Phase Roadmap Contract) — adds milestone model, walking-skeleton
concept, and per-phase capability statement to every phase definition.

---

### FACT Impact

| Dimension | Impact |
|-----------|--------|
| **Fast** | `improves` — walking-skeleton milestones expose integration bottlenecks earlier, preventing late-stage discoveries that cause O(N) rework. |
| **Accurate** | `improves` — real user feedback on a working milestone corrects design assumptions before the next phase locks them in. |
| **Complete** | `neutral` — no change to what is eventually built; all specs in every phase still complete before the version tag. |
| **Trustworthy** | `improves` — each milestone is a demonstrable, verifiable capability; the version tag certifies a working product increment, not just passing CI gates. |

---

### Context

Contract 17 defines six sequential phases. Each phase has entry criteria, a deliverables
table, exit criteria, and a version tag. The structure is correct — but inside each phase,
all specs are treated as a flat set with no delivery ordering. A phase does not produce
anything usable until every spec in the phase is complete.

This creates a waterfall effect inside each phase:

- Phase 1 has nine specs. None of them, individually, gives a user anything to interact
  with. The first usable output (ingest a repo and query facts via MCP) requires at least
  six specs to be done first. The remaining three specs (Language Pack Registry, Upload
  API, Semantic Interpreter) are real features — but they are enhancements on top of a
  working skeleton, not prerequisites for it.
- In practice, all nine specs are treated equally. There is no signal about which specs
  unlock the milestone capability and which ones extend it. Developers have no intermediate
  target to aim for. The first working system appears only at the end of the phase.

The right model is: **each phase is a product milestone**. The phase delivers a
demonstrable, user-facing capability. A walking skeleton — the minimum set of specs
that produces that capability end-to-end — must be identified and implemented first.
The remaining specs in the phase are enhancements that extend the skeleton before the
version tag is applied.

This is not a change to phase sequencing (Phase N+1 still cannot begin until Phase N
exits). It is a change to the delivery ordering *inside* each phase and to the
expectation of what a phase produces.

---

### Decision

We will add a **milestone model** to Contract 17 that applies to every phase:

**1. Milestone capability statement.**
Every phase definition MUST include a one-sentence `Milestone capability` that describes
the user-facing, demonstrable outcome produced by that phase. The milestone capability
is the minimum bar that the phase must clear before the version tag is applied.

**2. Walking skeleton.**
Every phase definition MUST identify a `Walking skeleton` — the ordered, minimum set of
specs whose completion produces the milestone capability end-to-end. Walking-skeleton
specs are implemented first, in dependency order, before any enhancement specs begin.
A walking skeleton is not a separate version tag — it is an internal delivery checkpoint
within the phase.

**3. Enhancement specs.**
All remaining specs in the phase that extend the walking skeleton are `Enhancement specs`.
They must all be complete before the version tag is applied, but they may be implemented
in any order after the walking skeleton is working.

**4. Version tag = working product increment.**
The version tag for a phase certifies that:
- The milestone capability works end-to-end.
- All specs (walking skeleton + enhancements) are `Status: Implemented`.
- All exit criteria pass.
The version tag is NOT applied to the walking skeleton alone — it marks the full phase.

**5. Phase sequence unchanged.**
Phase N+1 entry criteria still require Phase N's version tag. This ADR does not relax
phase sequencing — it adds structure inside each phase.

---

### Consequences

**Positive:**

- Every phase produces a demonstrable product increment; no phase is a pure technical
  foundation with nothing visible at the end.
- Walking skeleton gives teams an intermediate target: "get this working first, then
  extend it."
- Integration problems surface at the walking-skeleton checkpoint, not at the end of
  the phase.
- Each version tag carries a clear user-facing meaning, not just a CI gate result.
- Product feedback loops activate earlier — the walking skeleton can be shown to
  stakeholders while enhancement specs are still in progress.

**Negative / Trade-offs:**

- Slight overhead: each phase definition is longer (adds milestone capability +
  walking-skeleton table + enhancement-specs table).
- Walking-skeleton classification requires judgement — the boundary between "skeleton"
  and "enhancement" must be agreed at phase-planning time (G3 planner gate).

**Neutral / Operational notes:**

- Walking-skeleton completion is tracked in `phase-status.md` as a named checkpoint,
  not as a separate pipeline gate.
- The orchestrator enforces walking-skeleton ordering at G3 (plan subtasks must place
  skeleton specs before enhancement specs).
- `state.json` gains no new fields; the existing `current_gate` and spec `Status` fields
  are sufficient to track skeleton vs. enhancement progress.

---

### Alternatives Considered

| Alternative | Why Rejected |
|-------------|-------------|
| Sub-phases (e.g. Phase 1a / 1b) with separate version tags | Adds version tag complexity; breaks the clean N → N+1 sequence contract; downstream phases would need to declare entry criteria against sub-phase tags. |
| Keep flat spec set but add priority labels (P0/P1) | Labels have no enforcement mechanism; the planner would ignore them without a structural rule. Walking skeleton is structural — the planner MUST order skeleton specs first. |
| Require a demo checkpoint PR before enhancements begin | PR-based gates add process overhead without improving the artifact; the walking-skeleton concept achieves the same outcome through spec ordering in the plan. |
