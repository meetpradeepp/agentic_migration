## ADR-0034: Semantic Rule Engine for Fact-Level Annotation

**Status:** Accepted
**Date:** 2026-05-11
**Deciders:** Lead Engineer, Architecture Review
**Companion:** Contract 20 (Semantic Rule Engine Contract)
**Supersedes:** —
**Superseded by:** —
**Amends:** ADR-0025 (adds precedence note: rule-engine annotations precede cluster-stem enrichment), ADR-0027 (adds `semantic_interpreter` to worker registry), ADR-0018 (updates `enrich` step — exact lookup in `semantic_annotations` first, cluster-stem fallback second), ADR-0020 (adds `POST /admin/v1/semantic-rules/{tier}` endpoint)
**FACT impact:**
- Fast: `improves` — per-file single-fact rules evaluated in microseconds (compiled glob/regex); per-repo batch bounded by `rule_count × fact_count` with no network calls
- Accurate: `improves` — deterministic pattern matching; `rule_id` + `rule_version` pinned in every annotation; no probabilistic inference at the fact level
- Complete: `improves` — fills the platform/group/role knowledge gap that Tree-sitter structurally cannot produce; enables answering "how many Tuxedo services are there?" and "how many GTBan pipeline flows?"
- Trustworthy: `improves` — full annotation lineage (`rule_id`, `rule_version`, `annotated_at`) stored per row; base rules are versioned and immutable; re-annotation is auditable and scoped to the changed rule

---

### Context

Tree-sitter extracts correct but opaque structural facts. Three compounding gaps block FACT-C
(Completeness) compliance and make Phase 2 embeddings semantically blind from day one if left
unresolved:

1. **Platform classification gap** — `par_ban*` functions are Tuxedo service handlers. After
   full ingestion ECLE cannot answer "how many Tuxedo services are there?" The answer is
   *unknown*, not zero. This is a FACT-C failure, not a search quality issue.
2. **Function group blindness** — `atGTBan_extract`, `atGTBan_process`, `atGTBan_report` are
   extracted as three unrelated functions. No shared group, no suffix-role inference, no
   pipeline-pattern detection.
3. **Phase 2 coupling** — embedding workers consume `ecle.file.stored` and embed whatever
   `function_facts` contains. Un-annotated facts produce vectors that are semantically blind
   for enterprise naming conventions. The defect would be baked permanently into the vector
   space.

ADR-0025 (domain ontology) operates at cluster-centroid level using probabilistic stem
matching. That is complementary but insufficient: it cannot produce precise, per-fact
annotations and it belongs to Phase 4. A deterministic, per-fact annotation layer is needed
in Phase 1, before Phase 2 embeddings are generated. Contract 15 §1 Rule 6 requires an ADR
for every schema change; the `semantic_annotations` table requires this ADR.

---

### Decision

We will introduce a new `semantic_interpreter` Kafka worker (SRP) that evaluates a
three-tier rule set against extracted facts and writes deterministic annotations to a new
`semantic_annotations` table, emitting `ecle.facts.annotated` after all rules have been
evaluated for a repository.

#### Worker SRP

`semantic_interpreter` has exactly one job: evaluate semantic rules against extracted facts
and persist annotations. It does not parse, embed, or modify existing fact rows.

**Module path:** `src/ecle/workers/semantic_interpreter/`

**Consumes (two trigger events, independent consumer groups):**

| Event | Consumer group | Trigger reason |
|---|---|---|
| `ecle.file.stored` | `ecle.semantic_interpreter_file` | Single-fact rules evaluable per file (no cross-file co-occurrence needed) |
| `ecle.repo.indexed` | `ecle.semantic_interpreter_repo` | Multi-fact rules that require co-occurrence across multiple facts in the same repo |

Both groups are idempotent. Processing `ecle.file.stored` twice for the same `file_id`
produces the same `semantic_annotations` rows (upsert on unique constraint).

**Emits:** `ecle.facts.annotated` (one event per repo, after all rules evaluated for that repo).

#### Three-tier rule model

Rules are evaluated in precedence order: **repo > tenant > base**. Within the same tier,
the highest `confidence` wins. On a tie within the same tier, first-match-wins in file order.

| Tier | Description | Storage | Mutability |
|---|---|---|---|
| Base | Shipped with ECLE; cross-industry patterns | `src/ecle/workers/semantic_interpreter/base_rules/` | Read-only; versioned by ECLE release |
| Tenant | Per-tenant YAML uploaded via Admin API | Artifact store: `semantic_rules/{tenant_id}/tenant.yaml` | Hot-reloadable; owner-controlled |
| Repo | Per-repo YAML override; highest precedence | Artifact store: `semantic_rules/{tenant_id}/{repo_id}/repo.yaml` | Hot-reloadable; owner-controlled |

Conflict resolution is explicit: the annotation written to `semantic_annotations` carries the
`rule_id` and `rule_version` of the winning rule, so the applied tier is always traceable.

#### YAML rule schema (formalised in Contract 20)

**Pattern-match rule (single fact):**

```yaml
rule_id: tuxedo-service-handler
version: 1
target: function_facts           # file_tables | function_facts | function_table_ops
match:
  field: function_name
  pattern: "par_*"               # glob; prefix "re:" for regex
annotate:
  platform: Tuxedo
  type: service_handler
  group: null
confidence: 1.0
```

**Capture-group inference rule (suffix → role + group):**

```yaml
rule_id: gtban-pipeline-group
version: 1
target: function_facts
match:
  field: function_name
  pattern: "re:^at(?P<group>[A-Z][a-zA-Z0-9]+)_(extract|process|report)$"
annotate:
  group: "{match.group}"         # named capture group substitution
  role: "{match[2]}"             # positional capture group → role
  type: pipeline_stage
confidence: 1.0
```

**Multi-fact co-occurrence rule (repo-batch trigger only):**

```yaml
rule_id: shared-table-group
version: 1
target: function_table_ops
match:
  co_touch:
    table_name: "*"              # any table touched by ≥2 functions
    min_functions: 2
annotate:
  group: "{table_name}"
  type: shared_table_group
confidence: 0.8
```

Rule schema and evaluation semantics are formalised in Contract 20 (to be authored as
SPEC-0010 is planned). This ADR defines the architecture; Contract 20 defines the grammar.

#### `semantic_annotations` table (Contract 15 addition)

Follows Contract 15 §1 version-chain rules: `is_current` flag, `superseded_at`, `previous_id`.

| Column | Type | Notes |
|---|---|---|
| `id` | UUID PK | |
| `tenant_id` | VARCHAR | Tenant isolation key |
| `repo_id` | VARCHAR | Repository identifier |
| `target_type` | VARCHAR | `file_tables \| function_facts \| function_table_ops` |
| `target_id` | UUID FK | Points to the row in the target table; nullable for file-level annotations |
| `rule_id` | VARCHAR | Rule that produced this annotation |
| `rule_version` | INT | Version of the rule at annotation time |
| `platform` | VARCHAR | e.g. `Tuxedo`, `Spring`, `Django`; nullable |
| `domain_entity` | VARCHAR | Ontology-aligned entity name (used by ADR-0018 `enrich` step); nullable |
| `type` | VARCHAR | e.g. `service_handler`, `pipeline_stage`; nullable |
| `group` | VARCHAR | Logical group name inferred from name pattern; nullable |
| `role` | VARCHAR | Role within the group (e.g. `extract`, `process`, `report`); nullable |
| `confidence` | NUMERIC | Rule match confidence (from rule YAML `confidence` field) |
| `annotated_at` | TIMESTAMPTZ | Timestamp of annotation write |
| `is_current` | BOOLEAN | True only for the active annotation for this `(tenant_id, repo_id, target_type, target_id, rule_id)` |
| `superseded_at` | TIMESTAMPTZ | Nullable; set when annotation is superseded by re-annotation |
| `previous_id` | UUID FK | Previous annotation version; nullable for first annotation |

**Unique constraint:** `(tenant_id, repo_id, target_type, target_id, rule_id)` — upsertable;
ensures idempotent re-runs.

**Index (Contract 15 addition):** `(tenant_id, repo_id, target_type, target_id, rule_id)` —
supports the `enrich` step exact-lookup in ADR-0018.

#### Re-annotation strategy

When a rule file is updated and pushed via the Admin API:

1. Admin API validates YAML schema and bumps `rule_version`.
2. Admin API emits a dedicated re-annotation event (payload: `rule_id`, `rule_version_new`,
   `tenant_id`, `repo_id`; scoped to the changed rule only if `repo_id` is provided, or
   tenant-wide if not).
3. `semantic_interpreter` invalidates rows matching `rule_id = <changed_rule_id>` by setting
   `is_current=false` and `superseded_at=now()`, then re-evaluates only that rule against all
   relevant facts.
4. **Full repo re-annotation** (all rules, all facts) is triggered only when the
   `--force-reannotate` flag is passed to the Admin CLI. This is a destructive operation
   gated behind explicit intent.

#### Layered ingestion architecture (non-negotiable invariants)

The ingestion pipeline is structured in two strictly ordered layers. These invariants are
**non-negotiable** and must not be violated by any future spec or worker:

| Layer | Components | Responsibility | May influence layer below? |
|-------|-----------|---------------|---------------------------|
| **Layer 0** | Tree-sitter, Joern, `parse_repo`, `persist_facts` | Commodity extraction — produces raw structural facts as fast as possible | No |
| **Layer 1** | `semantic_interpreter` | Adds domain meaning to stored facts via deterministic rules | N/A (downstream) |

**Invariant 1 — Layer 0 is extraction-only.** `parse_repo` and `persist_facts` workers do
not annotate, classify, or route based on naming conventions. Batch formation in Layer 0
(SPEC-062 Phase C/D count-based sharding) is driven exclusively by file count and available
JVM memory — never by rule engine output. The rule engine has no input into Joern's batch
planner.

**Invariant 2 — Ingestion is not complete until `ecle.facts.annotated` is emitted.**
`ecle.repo.indexed` (emitted by `persist_facts`) is an **intermediate** signal — it means
raw structural facts are stored. `ecle.facts.annotated` (emitted by `semantic_interpreter`)
is the **ingestion completion** signal — it means annotated facts are available. Any worker
that consumes the final ingestion result (e.g. Phase 2 `batch_embed`) MUST subscribe to
`ecle.facts.annotated`, not `ecle.repo.indexed`.

**Invariant 3 — Phase 2 embeddings consume annotated facts.** The Phase 2 `batch_embed`
worker subscribes to `ecle.facts.annotated`. This guarantees that `platform`, `type`,
`group`, and `role` annotations are available as embedding metadata before any vector is
generated. Embedding un-annotated facts is a FACT-C (Completeness) failure.

---

#### Relationship to ADR-0025 (domain ontology)

These two systems are complementary, not competing:

| Dimension | Semantic Rule Engine (this ADR) | Domain Ontology Enricher (ADR-0025) |
|---|---|---|
| Granularity | Individual fact row | Cluster centroid |
| Method | Deterministic pattern match | Probabilistic stem matching |
| Phase | Phase 1 | Phase 4 |
| Output | `semantic_annotations.domain_entity` | `cluster_labels`, `concept_stems[]` |

In the ADR-0018 `enrich` step, the lookup order is:
1. Exact lookup in `semantic_annotations.domain_entity` (this ADR — Phase 1 output)
2. Cluster-stem fallback via ADR-0025 enrichment (Phase 4 output)

ADR-0025 is amended to add this precedence note (see Amendments below).

#### Admin API amendment (ADR-0020)

New endpoints added to `http://host:4001/admin/v1`:

| Method | Path | Description |
|---|---|---|
| `POST` | `/semantic-rules/tenant` | Upload or replace tenant-tier rule file (YAML); validates schema; bumps version; triggers scoped re-annotation |
| `POST` | `/semantic-rules/repo` | Upload or replace repo-tier rule file (YAML); `repo_id` in body; triggers scoped re-annotation |
| `GET` | `/semantic-rules/{tier}` | Retrieve current rule file for `tenant` or `repo` tier |
| `DELETE` | `/semantic-rules/{tier}` | Remove tenant or repo rule file; reverts to next-lower tier |

All endpoints require `admin` scope. `X-Tenant-Id` header required.

---

### Consequences

**Positive:**
- FACT-C (Completeness) is restored: queries for "Tuxedo service handlers", "GTBan pipeline
  group", and "how many Tuxedo services?" become answerable with deterministic evidence.
- Phase 2 embeddings are semantically rich from day one: `platform`, `type`, `group`, `role`
  fields in `semantic_annotations` are available as embedding metadata before any vector is
  generated.
- Rule lineage is full: every annotation records `rule_id`, `rule_version`, `annotated_at`.
  Operators can audit which rule produced which annotation.
- Base rules are immutable and versioned by ECLE release; regression from rule changes is
  scoped to the changed rule only, never full-corpus.

**Negative / Trade-offs:**
- New worker to deploy and operate (`semantic_interpreter`); adds to K8s manifest count and
  monitoring surface.
- Rule YAML authoring requires care — incorrect patterns silently annotate wrong facts. The
  Admin API schema validation reduces but does not eliminate this risk.
- Multi-fact co-occurrence rules (`repo.indexed` trigger) perform an in-memory join of
  `function_table_ops` rows for a repo; large repos with many functions sharing many tables
  may require batch windowing. This is bounded by `SEMANTIC_INTERPRETER_MAX_COOCCURRENCE_ROWS`
  config key.
- `semantic_annotations` table grows proportionally to rule count × fact count × rule
  re-evaluations; requires a retention policy for `is_current=false` rows (managed by
  ADR-0021 data lifecycle).

**Neutral / Operational notes:**
- `semantic_interpreter` follows ADR-0027 Rule 2: independent `Dockerfile`, K8s `Deployment`,
  `ScaledObject`.
- KEDA scaling: input topic `ecle.file.stored` (file-trigger group); `ecle.repo.indexed`
  (repo-trigger group). Both groups independently scaled.
- `eval_async_coupling` automatically verifies `semantic_interpreter` does not import other
  worker modules (no code change needed to CI — the eval covers all workers).
- Re-annotation on rule change is scoped and fast for typical rule sets (< 1,000 rules × tens
  of thousands of functions = sub-second on indexed DB).
- Contract 20 (YAML rule schema) is the companion contract; authored as part of SPEC-0010.

---

### Alternatives Considered

| Alternative | Why Rejected |
|---|---|
| Embed rule matching into `persist_facts` worker | Violates SRP (Contract 09 §2 Rule 2); `persist_facts` already has one job (IR → DB); mixing annotation logic creates a god worker (Anti-pattern A1) |
| Annotate at query time (runtime rule evaluation) | Violates the 2 s query timeout (Contract 04); annotation would re-run on every query; `semantic_accuracy` would be non-persistent and non-auditable |
| Use ADR-0025 ontology enricher and extend it to fact level | ADR-0025 is probabilistic and cluster-level; it cannot produce deterministic per-fact annotations; conflating the two layers degrades `semantic_accuracy` on cluster enrichment |
| Store annotations as JSONB columns on `function_facts` / `file_tables` | Violates Contract 15 §1 Rule 6 (schema change requires ADR — but more critically: JSONB column annotations cannot be upserted per-rule, cannot carry independent lineage per annotation, and cannot be individually invalidated by `rule_id`); separate table is the correct design |
| LLM-based function classification at ingest time | Violates the non-negotiable no-LLM-at-runtime rule (copilot-instructions.md §4); non-deterministic; ungroundable; inference cost at ingest scale is prohibitive |
| Defer to Phase 4 alongside ADR-0025 | Phase 2 embeddings begin in Phase 2; embedding un-annotated facts bakes semantic blindness permanently into the vector space; this is a FACT-C failure, not a future enhancement |

---

### Amendments Required

The following documents are amended concurrently with this ADR's acceptance:

#### ADR-0025 — add precedence note

In the **Decision** section, under "Layer 3 — Auto-derived cluster labels", add:

> **Rule-engine precedence (ADR-0034):** Before applying cluster-stem or auto-derived
> enrichment, the `enrich` step MUST perform an exact lookup in `semantic_annotations`
> (ADR-0034). If a `domain_entity` value is present for the queried fact, it is used directly.
> Cluster-stem matching applies only when `semantic_annotations` returns no `domain_entity`
> for the fact.

#### ADR-0027 — add `semantic_interpreter` to worker registry (Rule 3 scaling table)

Add to the KEDA scaling table:

| Worker | Min replicas | Max replicas | Lag threshold | Input topic |
|---|---|---|---|---|
| `semantic_interpreter` (file group) | 1 | 8 | 100 | `ecle.file.stored` |
| `semantic_interpreter` (repo group) | 1 | 4 | 20 | `ecle.repo.indexed` |

Add to the SRP boundary table (Contract 09 §4 / ADR-0027 Rule 2):

| Worker | Its one job | Domain boundary |
|---|---|---|
| `semantic_interpreter` | Evaluate semantic rules against extracted facts; persist `semantic_annotations`; emit `ecle.facts.annotated` | Parsing, vectors, graph, topology |

#### ADR-0018 — update `enrich` step

In the **Architecture** section, under the `StepRegistry`, update the `enrich` step
description to:

> `"enrich"` → `enrich.run` — Enriches query tokens with domain vocabulary. Lookup order:
> (1) exact match in `semantic_annotations.domain_entity` (ADR-0034, Phase 1 output);
> (2) cluster-stem fallback from ADR-0025 ontology enrichment (Phase 4 output).
> First match wins; fallback only when (1) returns no result.

#### ADR-0020 — add semantic-rules endpoints

Add to the Admin API surface table (under a new section "Semantic Rule Management"):

| Method | Path | Description |
|---|---|---|
| `POST` | `/semantic-rules/tenant` | Upload tenant-tier YAML rule file; validates schema; triggers scoped re-annotation |
| `POST` | `/semantic-rules/repo` | Upload repo-tier YAML rule file; `repo_id` in body |
| `GET` | `/semantic-rules/{tier}` | Retrieve current rule file for `tenant` or `repo` tier |
| `DELETE` | `/semantic-rules/{tier}` | Remove tier rule file; reverts to next-lower tier |

#### Contract 09 — add `ecle.facts.annotated` event

Add to the event type catalogue (§3):

| Event type | Topic | Emitted by | Consumed by | Payload required fields |
|---|---|---|---|---|
| `facts.annotated` | `ecle.facts.annotated` | `semantic_interpreter` | `batch_embed` ★ | `repo_id`, `tenant_id`, `annotation_count`, `rule_ids[]`, `annotated_at` |

★ `batch_embed` consumes `ecle.facts.annotated` as a signal that annotations are stable
before embedding proceeds. This ensures Phase 2 vectors encode annotated facts.

#### Contract 15 — add `semantic_annotations` table and index

Add to §2 Table inventory (Layer 2 — Function-level facts) a new table entry:

> **`semantic_annotations`** — see ADR-0034 for full column specification. Phase 1 table.
> Unique constraint: `(tenant_id, repo_id, target_type, target_id, rule_id)`.
> Index: `(tenant_id, repo_id, target_type, target_id, rule_id)` — `WHERE is_current = true`
> partial index on `target_type`.

---

### Compliance

- Contract: `constitution/contracts/09-event-pipeline-contract.md` — new event `ecle.facts.annotated`; new worker SRP row for `semantic_interpreter`
- Contract: `constitution/contracts/15-db-schema-contract.md` — new `semantic_annotations` table; new index
- Contract: `constitution/contracts/10-anti-patterns.md` — `semantic_interpreter` must not import other workers; SRP enforced
- Contract: `constitution/contracts/04-fact-contract.md` — annotation lineage satisfies FACT-T (Trustworthy) requirement for traceable grounding
- Schema: `constitution/schemas/semantic_annotations.sql` (to be authored in SPEC-0010)
- Schema: `constitution/schemas/semantic_rule.yaml` (to be authored in Contract 20)
- Eval: `eval_async_coupling` — verifies `semantic_interpreter` isolation on every PR
- Eval: `eval_idempotent_ingest` — verifies upsert idempotency on `semantic_annotations`
- Eval: `eval_event_chain_complete` — verifies `ecle.facts.annotated` emitted after annotation write
