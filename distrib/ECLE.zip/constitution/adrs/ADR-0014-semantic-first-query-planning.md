# ADR-0014: Semantic-First Query Planning

**Status:** Accepted  
**Date:** 2026-05-06  
**Deciders:** Lead Engineer, Architecture Review  
**Supersedes:** —  
**Superseded by:** —  
**Amends:** ADR-0003 (three backends are correct; routing layer assumption is wrong)  
**Amended by:** ADR-0014-A1 (coarse-to-fine cascade execution — see §Cascade below); ADR-0014-A2 (Muvera re-rank at Layer 2 — see §Muvera Re-rank below)
**Implemented by:** ADR-0018 (Intent-Driven Flow Registry — modes map to flow families; exact step sequence per intent+context is in `flow_registry.json`)  
**FACT impact:**
- Fast: `improves` — semantic pre-filter via Louvain cluster narrows structured query scope from full corpus to one cluster; composite queries avoid full-table scans; cascade execution further reduces average vector search cost by short-circuiting at the cheapest layer that achieves recall
- Accurate: `improves` — semantic-first routing finds the right domain area before asking structural questions; cascade recall-safety fallback prevents silent answer degradation at cluster boundary
- Complete: `improves` — exploratory queries (the majority) now return domain-contextualised results; cascade improves cross-repo completeness by using a single aggregated Layer 3 collection
- Trustworthy: `improves` — routing decision is explicit and traceable in the FACT envelope (`query_mode`, `search_depth` fields); caller can see whether answer came from cluster centroid or function body

---

### Context

ADR-0003 assumed query volume distribution: **80% structured, 20% semantic**. This was wrong.

The error was measuring *query type* rather than *conversation flow*. In production, users and LLMs do not arrive at ECLE already knowing which file, function, or table they need. The actual pattern is:

```
"How does the billing module handle failed payments?"     ← semantic (exploration)
"Which services are involved in retry logic?"            ← semantic (narrowing)
"Show me the PaymentRetryService"                        ← semantic → structured handoff
"What does PaymentRetryService.retry() call?"            ← structural (precision)
"List all callers of retry()"                            ← graph traversal (impact)
```

The first 3–4 turns of any real conversation are exploratory — the user does not know what to ask precisely yet. Structural and graph queries are the *destination*, reached only after semantic search has located the right area of the codebase. Structural queries are fast to answer but useless if aimed at the wrong cluster.

**Consequence of the wrong assumption in ADR-0003:**
- Vector index described as "auxiliary" — wrong; it is the primary entry point for exploration
- "80% of queries never touch the vector index" stated as a positive — that would actually mean most queries were failing to locate relevant code and defaulting to brute-force structured scans
- Query planner treated as a simple if/else router — it needs intent detection

---

### Decision

We will implement **three query modes** in the GraphQL query planner, with **semantic-first as the default** for queries without a known anchor point:

---

#### Mode 1 — Semantic (exploration, no known anchor)

**Trigger:** Query is conceptual or exploratory. No known file path, function name, or table name in the query.

```
User query → embed query → ANN search on vector store → top-K file_ids + cluster_ids
           → load cluster domain_concepts from ontology_enricher output
           → load structural summary facts for those file_ids from structured DB
           → compose result: [domain context] + [structural summary]
           → return with query_mode: "semantic"
```

The Louvain cluster (ADR-0011) is the handoff bridge: ANN returns cluster_ids → cluster scopes all downstream structured queries. Without the cluster scope, structured queries would scan the full corpus.

**`semantic_accuracy` gate:** if `semantic_accuracy = null` for the matched cluster (Pass 3 never ran), the query planner must include a `semantic_caveat` in the response: domain context is unavailable for this cluster; results are structural only. Never silently return a degraded result.

---

#### Mode 2 — Structured (precision, known anchor)

**Trigger:** Query contains a known anchor — a file path, function name, class name, table name, or `file_id`.

```
User query → extract anchor identifiers → structured DB lookup (exact match / filter)
           → optional graph traversal for relational queries ("callers of", "called by")
           → return with query_mode: "structured"
```

This is the fast path. O(log N) index lookup on structured DB. Does not touch the vector store.

---

#### Mode 3 — Composite (semantic pre-filter → structural post-filter)

**Trigger:** Query is exploratory but needs precise structural output ("Find all error handlers in the billing module").

```
User query → embed query → ANN search → cluster_ids (semantic pre-filter)
           → structured DB query scoped to file_ids within those clusters (structural post-filter)
           → return with query_mode: "composite"
```

This is the key optimisation ADR-0003 missed: **ANN narrows the search space; structured DB answers precisely within it**. A composite query on a 500K-file codebase scans only the files in 1–3 Louvain clusters (~hundreds of files), not the full corpus.

---

#### Coarse-to-Fine Cascade Execution (Amendment ADR-0014-A1)

**Applies to:** Mode 1 (Semantic) and Mode 3 (Composite). Does NOT apply to Mode 2
(Structured/Precise) — that mode bypasses the vector store entirely.

Semantic queries execute as a cascade through the three vector layers defined in
ADR-0004, stopping at the cheapest layer that achieves sufficient recall:

```
Query (Mode 1 or 3)
     │
     ▼
LAYER 3 — cluster centroids
  {tenant}__{repo}__layer3  or  {tenant}__cross_repo__capabilities
  Tiny collection (~50–200 vectors per repo)
  Cost: near-instant ANN search
     │
     ├── results ≥ K_min AND top similarity ≥ CASCADE_THRESHOLD?
     │     YES → return Layer 3 answer. STOP.
     │           search_depth = "layer3"
     │
     ▼
LAYER 1 — file centroids
  {tenant}__{repo}__layer1
  Search scoped to files within matched clusters only (not full collection)
     │
     ├── results ≥ K_min AND top similarity ≥ CASCADE_THRESHOLD?
     │     YES → return Layer 1 answer. STOP.
     │           search_depth = "layer1"
     │
     ▼
LAYER 2 — function bodies
  {tenant}__{repo}__layer2
  Search scoped to functions within matched files only (not full collection)
     │
     └── return Layer 2 answer.
           search_depth = "layer2"
```

**Configuration constants (tunable per deployment):**

| Constant | Default | Meaning |
|----------|---------|---------|
| `SEMANTIC_CASCADE_THRESHOLD` | `0.75` | Minimum cosine similarity to accept a layer result |
| `SEMANTIC_CASCADE_K_MIN` | `5` | Minimum result count — if below this at any layer, cascade unconditionally to next layer |
| `SEMANTIC_CASCADE_MAX_CLUSTERS` | `5` | Maximum number of Layer 3 cluster hits that feed into Layer 1 ANN scope. Prevents Layer 1 search space explosion when many clusters match a broad query. If Layer 3 returns more than this, only the top-N by similarity score are used for Layer 1 scoping. |

**Recall-safety fallback — mandatory:**

If Layer 3 returns fewer than `K_min` results above `CASCADE_THRESHOLD`, the query planner
MUST cascade to Layer 1 regardless of the scores returned. Stopping at Layer 3 with
insufficient results is a silent gap violation — a relevant file in a weakly-represented
cluster would be dropped without the caller knowing.

The fallback applies at each layer:
- `len(layer3_results) < K_min` → cascade to Layer 1 (unconditional)
- `len(layer1_results) < K_min` → cascade to Layer 2 (unconditional)

**FACT analysis:**

| Dimension | Effect | Condition |
|-----------|--------|-----------|
| Fast | Positive — Layer 3 search eliminates Layer 1/2 cost for most explore queries | Unconditional |
| Accurate | Positive | **Requires** recall-safety fallback. Without it: negative (boundary-cluster files silently dropped) |
| Complete | Positive | **Requires** recall-safety fallback. Without it: silent gaps violate completeness contract |
| Trustworthy | Positive — `search_depth` in FACT envelope makes answer resolution level visible to caller | Unconditional |

**This cascade is only adopted because all four FACT dimensions are net positive with
the mandatory fallback rule. If the recall-safety fallback were optional, the idea would
be dropped.**

---

#### Optional Muvera Re-rank at Layer 2 (Amendment ADR-0014-A2)

When the cascade reaches Layer 2 (`search_depth="layer2"`), an optional Muvera
token-level re-ranker fires before results are returned (ADR-0004-A1).

**Trigger conditions — ALL must be true:**
- `search_depth = "layer2"` (cascade reached function body layer)
- `LAYER2_RERANK_ENABLED = true` (deployment flag)
- `layer2_rerank` not explicitly set to `false` in query options

**What does NOT trigger re-rank:**
- Layer 3 or Layer 1 cascade stops (`search_depth = "layer3"` or `"layer1"`) — those layers use centroid vectors, not function bodies; MaxSim is not applicable
- Mode 2 (Structured) — vector store not used

**FACT envelope when re-rank fires:** `"reranker": "muvera"` in the `fast` block (see §`query_mode`). When re-rank does not fire: `"reranker": null`.

**Configuration constants** (defined in ADR-0004-A1, referenced here):

| Constant | Default |
|---|---|
| `LAYER2_RERANK_ENABLED` | `false` (dev) / `true` (enterprise) |
| `LAYER2_RERANK_TOP_K` | `50` |
| `LAYER2_RERANK_DIM` | TBD — operator evaluating; candidate 768+ |

---

#### Intent detection — how the planner chooses a mode

The query planner resolves mode in this priority order:

**Primary — caller-provided `query_intent`:**
The calling LLM agent classifies intent from conversation context and passes it as a structured argument. The calling LLM has full conversation history and semantic understanding — it is more reliable at intent classification than any heuristic. This is the expected path for all LLM agent consumers.

| `query_intent` value | Mode selected |
|---|---|
| `"explore"` | Semantic (Mode 1) |
| `"locate"` | Composite (Mode 3) |
| `"precise"` | Structured (Mode 2) |

If `known_anchors` is also provided, the query planner uses it to pre-scope the ANN search (for Mode 1/3) or as direct lookup keys (for Mode 2). `known_anchors` never overrides `query_intent` — intent determines mode; anchors refine execution within that mode.

**Fallback — heuristic argument inspection (when `query_intent` is absent):**
For non-LLM callers or older clients that do not pass `query_intent`:

| Signal present | Mode selected |
|---|---|
| `file_path`, `file_id`, `function_name`, `class_name`, `table_name` argument populated | Structured (Mode 2) |
| Conceptual query AND `precise_output: true` flag | Composite (Mode 3) |
| Conceptual query AND no `precise_output` flag | Semantic (Mode 1) |

`query_intent` absent is **never an error** — graceful degradation to heuristics. `intent_source` in the FACT envelope distinguishes the two paths: `"caller"` vs `"heuristic"` vs `"default"`. A high rate of `"heuristic"` in production is a signal the calling agent is not implementing the protocol correctly.

See Contract 11 §11 for the tool description template and `known_anchors` schema that guide LLM agents at the call site.

---

#### Revised query volume distribution

Based on real ECLE 1.0 production traffic analysis:

| Mode | Estimated volume | Latency target |
|---|---|---|
| Semantic (Mode 1) | ~55% | < 200 ms |
| Composite (Mode 3) | ~30% | < 500 ms |
| Structured (Mode 2) | ~10% | < 50 ms |
| Pure graph traversal | ~5% | < 1 000 ms |

Semantic is the plurality. The vector store is not auxiliary — it is the primary entry point.

---

#### `query_mode` in the FACT envelope

Every query response MUST include `query_mode` in the FACT envelope:

```json
{
  "query_mode": "composite",
  "search_depth": "layer2",
  "cluster_ids_used": ["a3f1b2c4d5e6f7a8"],
  "cascade_stopped_at": "layer2",
  "reranker": "muvera",
  "semantic_caveat": null,
  "knowledge_current_as_of": "2026-05-05T14:32:00Z"
}
```

`search_depth` values: `"layer3"` (cluster-level answer), `"layer1"` (file-level), `"layer2"` (function-level), `"structured"` (Mode 2 — vector store not used).
`cascade_stopped_at` equals `search_depth` for Mode 1/3; omitted for Mode 2.
`reranker`: `"muvera"` when Muvera re-rank was applied (only possible at `search_depth="layer2"`); `null` otherwise.

This makes the routing decision observable and auditable. If a user gets an unexpected result, they can inspect `query_mode`, `search_depth`, and `cluster_ids_used` to understand why.

---

#### Semantic gate — when semantic_accuracy is null

If the query planner selects Mode 1 or Mode 3 and the matched cluster has `semantic_accuracy = null`:

- **Do not degrade silently.** Return results with `semantic_caveat: "Domain context unavailable for this cluster — Pass 3 (ontology enrichment) has not run. Results are structural only."`
- Emit `reindex.requested` event with `reason: "semantic_accuracy_null"` — triggers ontology enrichment pipeline asynchronously.
- Never block the response waiting for enrichment.

This is consistent with the staleness contract (07): serve honestly with caveats; never block.

---

### What does NOT change from ADR-0003

- The three backends (`IStructuredDB`, `IVectorStore`, `ITopologyGraph`) — correct
- The typed interfaces — correct
- Backend swap without touching query logic — correct
- Phase 1 SQLite implementation — correct
- Slim vector payloads (ADR-0004) — correct

What changes: the routing layer's mental model, the default mode, and the `query_mode` field in the FACT envelope.

---

### Alternatives Considered

| Alternative | Why Rejected |
|---|---|
| Keep ADR-0003 routing as-is (simple if/else by query type) | Does not model the semantic→structural conversation flow; composite queries fall through to full-corpus structured scans |
| LLM-based intent detection (classify the query before routing) | Non-deterministic; adds latency; violates no-LLM-at-any-layer principle; heuristic argument inspection is sufficient |
| Always run semantic first then always refine with structured | Composite overhead on every query including pure structured lookups; wastes latency for Mode 2 queries |
| Separate query API per mode | Pushes routing decision to MCP tool authors; inconsistent behaviour; query planner should own routing |

---

### Compliance

- ADR-0003: three backends unchanged; routing layer amended by this ADR
- ADR-0011: Louvain `cluster_id` is the semantic→structured handoff key; this ADR depends on it
- Contract: `constitution/contracts/04-fact-contract.md` — `query_mode` and `cluster_ids_used` added to FACT envelope
- Contract: `constitution/contracts/06-grounding-contract.md` — composite query lineage must trace both the ANN step and the structured step
- Contract: `constitution/contracts/07-staleness-contract.md` — `semantic_caveat` field follows same pattern as `staleness_caveat`
- Contract: `constitution/contracts/11-mcp-contract.md` — MCP tools must pass `precise_output` flag appropriately; never make routing decisions themselves
