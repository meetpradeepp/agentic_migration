# ADR-0009: Contract-First Cross-Repo Linking

**Status:** Accepted  
**Date:** 2026-05-05  
**Deciders:** Lead Engineer, Architecture Review  
**Supersedes:** —  
**Superseded by:** —  
**Amended by:** ADR-0017 (platform-module repo roles govern linking direction and sequencing)

---

### Context

ECLE 2.0 must resolve dependencies between repositories: which API in Repo A does
Repo B call? Which shared type from Repo C does Repo D extend? Which Kafka topic
published by Repo E is consumed by Repos F and G?

ECLE 1.0 PoC attempted **entity-level matching**: compare every function, class,
and type in every repo against every other repo to find matches. This produced:

- **O(N²) comparisons** — 10 repos × 10K entities each = 10⁸ comparisons
- **Memory exhaustion** — loading all entities from all repos simultaneously exceeded heap
- **Timeout failures** — jobs exceeded the 30-minute Celery task limit
- **False positives** — common function names (`get`, `load`, `parse`) matched across unrelated repos

The fundamental problem: entity matching compares the wrong thing. Two repos sharing
a function named `calculate_tax` are probably unrelated. Two repos sharing a REST
**contract** (URL path, method, schema) are definitively linked.

---

### Decision

We will use **contract-first cross-repo linking** instead of entity matching.

A **contract** is a named, versioned interface that a repo publishes or consumes:
- REST endpoint: `{method, path, schema}`
- Event topic: `{broker, topic_name, schema}`
- Shared package: `{package_name, version_range}`
- Shared type/schema: `{type_name, namespace}`
- Database table: `{table_name, operation}` (READ/WRITE boundary)

**Four-step process:**

1. **Per-repo contract extraction** (independent, parallel):
   `build_contract_registry` worker consumes `repo.ir_produced`; extracts contracts
   from `facts.json` artifacts; writes to `contracts` table in Structured Fact DB.

2. **Global contract index** (one-time per source):
   `link_contracts` worker consumes `source.scanned`; reads all contracts for all repos
   in the upload; groups by `(contract_type, contract_name)`.

3. **Contract matching** (O(C log C)):
   For each contract group with ≥2 repos: create `cross_repo_link` rows.
   C = number of distinct contracts across all repos; C << N (total entities).

4. **Link classification** (deterministic):
   Each link is classified:
   - `resolved` — exact match (package name + version range overlap)
   - `probable` — name match, schema compatible (fuzzy match score > 0.8)
   - `unresolved_external` — referenced but not found in any indexed repo
   - `unknown` — insufficient evidence to classify

**Result:** O(C log C) where C = contracts, vs O(N²) where N = entities. At 10 repos
× 100 contracts each = 1000 contracts → ~10K comparisons, not 10⁸.

---

### Consequences

**Positive:**

- O(C log C) complexity is tractable at enterprise scale (100+ repos)
- Contract extraction is per-repo and independent — parallelises with `parse_repo`
- Unresolved links are classified, not dropped — engineers see gaps explicitly
- False positive rate is drastically lower than entity matching — contracts are intentional interfaces
- Link classification produces a learning signal (which heuristics worked) for the feedback loop

**Negative / Trade-offs:**

- Cross-repo links are only as good as contract extraction — repos that don't follow conventions may have no extractable contracts
- `unresolved_external` links (third-party APIs) are expected and frequent — operators must be comfortable with partial coverage
- Schema matching for `probable` links requires fuzzy comparison logic — non-trivial to implement correctly
- Two repos communicating via shared database tables (READ/WRITE pattern) are captured; two repos communicating via file transfer are not

**Neutral / Operational notes:**

- `contracts` and `cross_repo_links` are new tables in the Structured Fact DB (Phase 3 migration)
- Phase 1/2: `build_contract_registry` and `link_contracts` workers are stubs (emit events, write no data)
- Phase 3: full implementation
- The `cross.linked` event includes `unresolved_count` — operators monitor this as a quality signal

---

### Alternatives Considered

| Alternative | Why Rejected |
|-------------|-------------|
| Entity-level matching (all functions vs all functions) | O(N²); proven to exhaust memory in ECLE 1.0 PoC; high false positive rate |
| Vector similarity for cross-repo linking | Semantically similar code ≠ linked code; two billing modules in different repos may be similar but independent |
| Manual link annotation only | Doesn't scale; misses undocumented dependencies; still requires entity enumeration to prompt annotations |
| Import-only analysis (package names) | Misses in-process dependency via shared DB tables, REST calls, and message queues |

---

### Compliance

- Contract: `constitution/contracts/09-event-pipeline-contract.md` (event types: `contracts.registered`, `cross.linked`)
- ADR-0003: Three-Backend Architecture — `contracts` and `cross_repo_links` tables live in the Structured Fact DB
- ADR-0001: Event-Driven Pipeline — `build_contract_registry` consumes `repo.ir_produced`; `link_contracts` consumes `source.scanned`
- **ADR-0017: Platform-Module Repository Model** — `link_contracts` worker MUST respect repo_role:
  - Contract matching runs within-repo first, then cross-repo
  - Platform→module links are classified as enrichment edges (not bidirectional topology)
  - `link_contracts` runs AFTER all platform repos are fully indexed (ADR-0017 §Ingestion Sequencing)
  - **Platform ingest timeout gate:** if any platform repo has `parse_status != 'done'` after `PLATFORM_INGEST_TIMEOUT` (default: `30` minutes), `link_contracts` proceeds with the available indexed platform repos and emits `link_contracts.partial_platform { missing_repos[] }`. Module queries for those missing repos will have no cross-repo enrichment until the platform repo completes and a re-link is triggered. A `coverage_warning` is added to all affected query responses.
  - Subsequent runs: triggered per-repo for changed contracts only — NOT a full re-link across all repos

---

### References

| # | Citation | Relevance to this ADR |
|---|----------|----------------------|
| R1 | Newman, S. "Building Microservices", O'Reilly 2021, Ch. 4: Integration — Contract-first / API-first integration | Validates contract-based linking over entity-level matching for inter-service dependencies |
| R2 | Fellegi, I. & Sunter, A. "A Theory for Record Linkage", JASA 1969 | Foundational record linkage theory: classifies pairs as match/non-match/possible — ECLE's 4-tier classification (resolved/probable/unresolved_external/unknown) is a practical application |
| R3 | OpenAPI Specification 3.1 (spec.openapis.org) & AsyncAPI 3.0 (asyncapi.com) | Industry standards for contract-first API definition; ECLE's contract extraction targets these same interface boundaries (REST, events, shared schemas) |
