# ADR-0019: Authentication and Authorization Model

**Status:** Accepted
**Date:** 2026-05-07
**Deciders:** Lead Engineer, Architecture Review, Security Review
**Supersedes:** —
**Superseded by:** —
**Amends:** ADR-0006 (MCP/GraphQL layer — adds auth surface), ADR-0010 (deployment model — adds auth config per tier)
**FACT impact:**
- Fast: `neutral` — token validation adds < 2 ms per request; cached JWT public keys avoid remote round-trips
- Accurate: `improves` — tenant isolation guaranteed by cryptographic token binding, not trusting `X-Tenant-Id` header alone
- Complete: `neutral` — auth does not affect coverage; unauthenticated requests return 401, not partial results
- Trustworthy: `improves` — every query response is traceable to an authenticated caller; audit log ties `subject` to `query_id`; air-gapped deployments use locally-signed tokens with no cloud dependency

---

### Context

The current constitution defers authentication to "Phase 2+" with a single line: `Authorization: Bearer <token>`. This is insufficient for enterprise deployment. In Phase 1 dev mode, any process on the local network can query any tenant's code intelligence by setting `X-Tenant-Id: acme`. Production deployments (Tier 2/3) need:

1. **Authentication** — proof that the caller is who they claim to be (which client app, which user or service account).
2. **Authorization** — proof that the authenticated caller is permitted to query a specific tenant's data and use specific tools.
3. **Air-gap safety** — regulated and air-gapped deployments (ADR-0008's core use case) cannot use cloud IdP callbacks (OAuth redirect flows, cloud JWK endpoints).
4. **Audit trail** — enterprise procurement requires proof of who queried what, when.

ECLE's query surface is read-only (no data mutation via MCP). The auth model is therefore simpler than write-capable systems: it is primarily about **tenant isolation** and **caller identification**, not fine-grained write permissions.

---

### Decision

We will implement a **two-layer auth model**: API key authentication for service-to-service calls (always supported), with optional JWT bearer token authentication for human-facing clients (Phase 2+ only). All auth is **stateless** (no server-side session state) — consistent with MCP server statelessness (Contract 11 §1 Rule 4).

#### Layer 1 — API Key Authentication (Phase 2, all tiers)

Every non-dev request must carry a valid API key in the `Authorization` header:

```
Authorization: ApiKey <api_key>
```

API keys are **tenant-scoped**: each key is bound to exactly one `tenant_id` at creation time. The server validates: key exists + key is active + key's `tenant_id` matches `X-Tenant-Id` header. If either check fails → `403 Forbidden`.

**API key storage:**

```sql
CREATE TABLE api_keys (
  id          UUID PRIMARY KEY,
  tenant_id   VARCHAR NOT NULL,
  key_hash    VARCHAR NOT NULL UNIQUE,  -- SHA256(api_key); raw key never stored
  label       TEXT,                    -- human-readable name (e.g. "VS Code extension prod")
  scopes      TEXT[],                  -- ["query", "admin"] — see §Scopes
  created_at  TIMESTAMP NOT NULL,
  expires_at  TIMESTAMP,               -- NULL = non-expiring
  revoked_at  TIMESTAMP,               -- NULL = active
  last_used_at TIMESTAMP
);
```

Keys are 32-byte random values, base64url-encoded (256 bits entropy). Only `SHA256(key)` is stored. The raw key is shown exactly once at creation time — never retrievable after that.

**Key lifecycle:**
- Created via Admin API (ADR-0020) — only tenant admin or system admin can create.
- Revoked by setting `revoked_at` — takes effect within 1 minute (cache TTL).
- Expired keys return `401 Unauthorized` with `"error": "api_key_expired"`.
- Revoked keys return `401 Unauthorized` with `"error": "api_key_revoked"`.

#### Layer 2 — JWT Bearer Token (Phase 3, optional)

For human-facing callers (VS Code extension, web dashboard) that integrate with a corporate IdP (OIDC/SAML). JWT is validated locally using the IdP's public key (fetched once at startup, cached, refreshed on rotation).

```
Authorization: Bearer <jwt_token>
```

JWT claims required:
```json
{
  "sub":    "user@corp.com",        // caller identity for audit log
  "tenant": "acme",                 // must match X-Tenant-Id
  "scopes": ["query"],              // see §Scopes
  "iat":    1714000000,
  "exp":    1714003600
}
```

**Air-gap mode:** When `AUTH_JWT_MODE=local`, ECLE validates JWTs using a locally-configured signing key (`AUTH_JWT_LOCAL_SECRET` or a local JWKS file at `AUTH_JWT_LOCAL_JWKS_PATH`). No network call to IdP required. Tokens are issued by a locally-running service or pre-generated admin script. This is the air-gapped deployment path.

#### Scopes

| Scope | Permits |
|-------|---------|
| `query` | All `ecle_*` MCP tools (read-only); `POST /graphql`; `GET /health` |
| `admin` | Admin API endpoints (ADR-0020) — repo onboarding, key management, config overrides |
| `ingest` | `POST /api/upload` — source upload endpoint (service-to-service) |

An API key may carry multiple scopes. A JWT may carry multiple scopes. Missing scope → `403 Forbidden`.

#### Dev tier (Tier 1)

Auth is **disabled by default** in Tier 1 dev: `MCP_AUTH_DISABLED=true` (default when `ECLE_TIER=dev`). Any request without a token is treated as tenant `ECLE_DEV_TENANT` (default: `"dev"`). Setting `MCP_AUTH_DISABLED=false` in dev enables auth for local testing.

#### Validation order (all tiers except dev with auth disabled)

```
Request arrives at POST /mcp
    │
    ├── MCP_AUTH_DISABLED=true?  → skip all auth, inject dev tenant context
    │
    ├── Parse Authorization header
    │     ├── "ApiKey ..."  → API key validation path
    │     ├── "Bearer ..."  → JWT validation path
    │     └── missing       → 401 Unauthorized { "error": "missing_authorization" }
    │
    ├── Validate token (key hash lookup or JWT signature + expiry)
    │     └── invalid/expired/revoked → 401 Unauthorized
    │
    ├── Extract tenant_id from token
    │     ├── must match X-Tenant-Id header value
    │     └── mismatch → 403 Forbidden { "error": "tenant_mismatch" }
    │
    ├── Check scope for this endpoint
    │     └── missing scope → 403 Forbidden { "error": "insufficient_scope" }
    │
    └── Inject auth context { subject, tenant_id, scopes } into request handler
```

#### Audit log

Every authenticated request produces an audit record. Written to `query_audit_log` table (append-only — no updates, no deletes):

```sql
CREATE TABLE query_audit_log (
  id           UUID PRIMARY KEY,
  tenant_id    VARCHAR NOT NULL,
  subject      TEXT,               -- "user@corp.com" or "apikey:<label>" or "anonymous:dev"
  request_id   VARCHAR NOT NULL,   -- echoed X-Request-Id
  tool         VARCHAR,            -- MCP tool name or NULL for GraphQL direct
  query_ms     INT,
  result_count INT,
  timed_out    BOOLEAN,
  called_at    TIMESTAMP NOT NULL
);
```

Audit log is **excluded** from the "no hard deletes" rule (Contract 15 §1). It is governed by the data lifecycle contract (ADR-0021): retained for `AUDIT_LOG_RETENTION_DAYS` (default: 365 days), then hard-deleted by scheduled job.

#### Rate limiting

| Scope | Limit | Enforcement |
|-------|-------|-------------|
| Per API key | `RATE_LIMIT_PER_KEY_RPS` (default: 20 req/s) | In-process token bucket (Tier 1/2); Redis sliding window (Tier 3) |
| Per tenant (all keys combined) | `RATE_LIMIT_PER_TENANT_RPS` (default: 100 req/s) | Redis counter (Tier 2/3 only) |

Rate limit exceeded → `429 Too Many Requests`. `Retry-After` header set to bucket refill time.

---

### Consequences

**Positive:**
- API key model is simple, universally supported (curl, VS Code extension, Python SDK), and works without browser redirect flows — ideal for service-to-service and air-gapped use
- JWT path supports corporate SSO without forking the codebase — operators configure `AUTH_JWT_JWKS_URL` or `AUTH_JWT_LOCAL_JWKS_PATH`
- Audit log gives enterprise procurement team their compliance evidence: who queried what, when
- Stateless validation — no session table, no session affinity required; consistent with horizontal scaling

**Negative / Trade-offs:**
- API key management (rotation, revocation) requires the Admin API (ADR-0020) — Phase 2 dependency
- JWT expiry (typically 1 hour) means agents running long sessions must handle token refresh; LLM agents calling ECLE must be configured to re-authenticate on `401`
- Redis required for per-tenant rate limiting at Tier 3 — already a Tier 3 component, so no new dependency

**Neutral / Operational notes:**
- `MCP_AUTH_DISABLED=true` is the Tier 1 dev default — local development is unchanged
- Key rotation: create new key → update caller config → revoke old key. Zero-downtime rotation.
- `AUTH_JWT_JWKS_REFRESH_INTERVAL` (default: 3600 s) controls key cache TTL; set lower when IdP rotates keys frequently
- `AUDIT_LOG_RETENTION_DAYS` (default: 365) is tunable via env var; must be ≥ 90 for SOC 2 compliance

---

### Alternatives Considered

| Alternative | Why Rejected |
|-------------|-------------|
| mTLS (mutual TLS) for service-to-service | Requires certificate management infrastructure; cert rotation is operationally complex; API keys are simpler and sufficient for ECLE's read-only surface |
| OAuth 2.0 client credentials flow for API keys | Adds token endpoint complexity and round-trip; API keys with SHA256 storage achieve the same security properties with less infrastructure |
| Session cookies | Breaks stateless contract (Contract 11 §1 Rule 4); incompatible with horizontal scaling; incompatible with non-browser callers |
| No auth at all (trust network perimeter) | Not viable for multi-tenant deployments; `X-Tenant-Id` header spoofing is trivial without token binding |

---

### Compliance

- Contract: `constitution/contracts/11-mcp-contract.md` — transport rules amended to require auth at Tier 2+
- Contract: `constitution/contracts/14-deployment-contract.md` — `MCP_AUTH_DISABLED` added to Tier 1 config table
- ADR: `ADR-0020` (Admin API) — key management endpoints
- ADR: `ADR-0021` (Data Lifecycle) — audit log retention
- Schema: `constitution/schemas/` — `api_keys` and `query_audit_log` table DDL
