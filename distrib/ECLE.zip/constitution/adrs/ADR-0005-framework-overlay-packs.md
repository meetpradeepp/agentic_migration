# ADR-0005: Framework Overlay Pack Activation

**Status:** Accepted  
**Date:** 2026-05-05  
**Deciders:** Lead Engineer, Architecture Review  
**Supersedes:** —  
**Superseded by:** —  

---

### Context

Angular, React, Vue, and plain TypeScript/JavaScript all share the same file extensions:
`.ts`, `.tsx`, `.js`, `.jsx`. The `LanguagePackRegistry` (ADR-0002) resolves packs by
extension — so extension-based lookup alone cannot differentiate a React component from
a plain TypeScript utility file.

This matters because the facts each framework requires are structurally different:

| Framework | Framework-specific facts needed |
|-----------|--------------------------------|
| Angular   | `@Component`, `@NgModule`, `@Injectable` decorators; routes; DI tokens |
| React     | JSX trees; hooks (`useState`, `useEffect`); component props shape |
| Vue       | SFC (`<template>`, `<script>`, `<style>`) sections; Composition API |
| Plain TS  | Classes, interfaces, type aliases — no framework overlay needed |

Without framework awareness, the TypeScript pack extracts generic class/function facts
but misses the component tree, route graph, hook dependency chain, and DI topology
that are the primary structural concerns of a framework codebase.

Framework detection must happen **at the repo level** (not file level), because
`package.json`, `angular.json`, `next.config.js`, and `vite.config.ts` declare the
framework once for the whole repo. Individual files do not reliably self-identify.

**Schema impact:** This ADR requires a new optional field `activates_on_framework` in
`manifest.yaml`. Per constitution rule 4, a schema change requires an ADR before
implementation — this ADR is that prerequisite. The schema is updated in
`constitution/schemas/language-pack-manifest.schema.yaml` after this ADR is accepted.

---

### Decision

We will implement **framework overlay packs** — a second class of language pack that:

1. Claims **no file extensions** (`extensions.source: []`)
2. Declares `extensions.activates_on_framework: <framework_id>` instead
3. Is activated by the `parse_repo` worker based on **repo-level framework context**, not file extension

**Three-layer framework detection** (executed by `scan_source` worker):

**Layer 1 — Repo manifest files (primary, most reliable):**
```
package.json  → dependencies/devDependencies keys:
  "@angular/core"           → angular
  "react" | "react-dom"     → react
  "vue"                     → vue
  "next"                    → nextjs
  "nuxt"                    → nuxt
angular.json                → angular (definitive)
next.config.js / .ts        → nextjs (definitive)
nuxt.config.ts              → nuxt (definitive)
vite.config.ts (+ react plugin) → react
```

**Layer 2 — File naming conventions (secondary signal, for confirmation):**
```
*.component.ts / *.module.ts / *.directive.ts / *.pipe.ts → angular
*.jsx / *.tsx (non-angular)                                → react
*.vue                                                       → vue (own extension)
```

**Layer 3 — AST import signals (fallback, used only when layers 1+2 are ambiguous):**
```
import { Component } from '@angular/core'  → angular
import React from 'react'                  → react  
import { useState } from 'react'           → react
```

The `scan_source` worker emits a `repo.framework_detected` event after Layer 1 detection.
The `parse_repo` worker reads this event and, for each `.ts`/`.tsx`/`.js`/`.jsx` file,
activates the appropriate overlay pack on top of the base TypeScript/JavaScript pack.

**Execution order for a framework file:**
```
1. Base pack runs first  → extracts functions, imports, calls (base facts)
2. Overlay pack runs second → adds framework-specific facts on top
3. facts.json contains both base fields AND overlay extension fields
4. framework field set in facts.json: { framework: "angular", framework_version: "17.x" }
```

**manifest.yaml for an overlay pack:**
```yaml
metadata:
  language_id: angular
  name: Angular Framework Overlay
  version: "1.0"
  family: oo
extensions:
  source: []                        # claims no extensions
  activates_on_framework: angular   # activated by repo framework context
fast_extraction:
  enabled: true
  grammar: null                     # uses base pack's parsed tree, not its own grammar
  fidelity: FULL
```

---

### Consequences

**Positive:**

- Extension-to-pack registry is unchanged — overlay packs are an additive concept, not a redesign
- Framework detection is repo-scoped once — not repeated per file (O(1) per repo, not O(N))
- Base pack + overlay = composable extraction; overlay only adds fields, never removes them
- Adding a new framework = new folder drop + restart (same contract as base packs)
- `framework` field in `facts.json` enables framework-filtered queries (`fact_find_files(framework="angular")`)

**Negative / Trade-offs:**

- Layer 1 detection can be wrong (monorepos with mixed frameworks in different sub-folders)
- Overlay pack receives the already-parsed tree from the base pack — they must be compatible versions
- `scan_source` now has a new responsibility (framework detection) alongside repo detection — small SRP stretch
- `repo.framework_detected` is a new event type — events table catalogue must be updated

**Neutral / Operational notes:**

- Monorepo support (multiple frameworks in one repo) deferred to Phase 3; Phase 1 assigns one framework per repo root
- `activates_on_framework: plain` is the explicit no-overlay signal — base TypeScript pack runs alone
- Vue is simpler: `.vue` files have their own extension and their own base pack; no overlay needed

---

### Alternatives Considered

| Alternative | Why Rejected |
|-------------|-------------|
| Separate extension per framework (e.g. `.angular.ts`) | Requires renaming all source files — not feasible |
| Single universal JS/TS pack with heuristic framework detection per file | Per-file detection is unreliable and expensive; misses repo-level signals |
| Runtime detection inside the base pack extractor | Too late — extractor must know framework context before choosing which AST nodes to walk |
| Separate registry for framework packs | Unnecessary complexity — overlay packs fit cleanly into the existing registry model with one new field |
| Framework as a manifest tag only (no separate pack folder) | Framework facts are substantial enough to warrant a separate module; prevents God-class extractor (A1) |

---

### Schema Changes Required

The following schema change is gated on this ADR being accepted:

**`constitution/schemas/language-pack-manifest.schema.yaml`:**
- `extensions.source.minItems`: 1 → 0 (overlay packs have empty source list)
- `extensions.activates_on_framework`: new optional string field
  - enum: `[angular, react, vue, nextjs, nuxt, svelte, plain]`
- Example: Angular overlay pack added

**`constitution/schemas/facts-base-schema.json`:**
- `framework`: new optional string field (populated by overlay packs)
- `framework_version`: new optional string field

---

### Compliance

- Contract: `constitution/contracts/08-language-pack-contract.md` — overlay pack checklist extends the 10-step checklist
- Schema: `constitution/schemas/language-pack-manifest.schema.yaml` — updated post this ADR
- Schema: `constitution/schemas/facts-base-schema.json` — `framework` field added post this ADR
- Eval: `eval_fallback_coverage` — must verify overlay activates correctly for known framework repos
- ADR-0002: Language Pack Registry — overlay packs are an extension of that model
