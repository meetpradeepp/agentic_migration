# ADR-0022: Multi-Tenancy Isolation Model

**Status:** Accepted
**Date:** 2026-05-07
**Deciders:** Lead Engineer, Architecture Review
**Supersedes:** —
**Superseded by:** —
**Amends:** ADR-0010 (deployment model — adds isolation tiers), ADR-0013 (Kafka — per-tenant topic option)
**FACT impact:**
- Fast: `neutral` — logical isolation (default) has no query performance impact; physical isolation adds infrastructure overhead but not query latency
- Accurate: `neutral` — isolation model does not affect extraction or grounding
- Complete: `improves` — explicit isolation model eliminates ambiguity; operators can make binding SLA commitments to tenants
- Trustworthy: `improves` — a tenant can independently verify that its data cannot be accessed by another tenant; noisy-neighbor risk is bounded and documented

---

### Context

ECLE 2.0 uses logical multi-tenancy: `tenant_id` is a column on every table, all tenants share the same PostgreSQL instance, Kafka cluster, and vector store. This is efficient and correct for most deployments, but creates two enterprise concerns:

1. **Noisy neighbor:** A tenant running a large ingest (50K files) can saturate Kafka consumer bandwidth, starving other tenants' smaller ingests. No per-tenant resource quota exists today.
2. **Regulatory isolation:** Some enterprise customers (financial services, healthcare, government) require that their data is physically isolated — either in a separate database schema, separate database instance, or a fully separate ECLE deployment — as a contractual or regulatory requirement. "Your data is in the same table as another customer's data, separated by a WHERE clause" is not acceptable to all buyers.

This ADR defines three isolation tiers with documented properties, allowing operators to choose the right model for each customer's requirements.

---

### Decision

We will define three isolation tiers. The isolation tier is set at **tenant creation time** (ADR-0020 `POST /tenants`) and is immutable without re-provisioning.

#### Isolation Tier A — Logical (default)

All tenants share all infrastructure. Isolation enforced by `tenant_id` column filters on every query.

| Component | Isolation mechanism |
|-----------|-------------------|
| PostgreSQL | Row-level `tenant_id` filter; Row-Level Security (RLS) policy as defense-in-depth at Tier 3 |
| Vector store | Collection namespace `{tenant_id}__*` |
| Kafka | Shared topics; partition key includes `tenant_id` |
| Artifact store | Path prefix `artifacts/{tenant_id}/` |

**Resource quotas (Tier A, enforced by Admin API and worker pre-checks):**

| Resource | Default quota | Override via |
|----------|--------------|--------------|
| Max repos per tenant | 100 | `QUOTA_MAX_REPOS` config or Admin API override |
| Max files per tenant | 500,000 | `QUOTA_MAX_FILES` |
| Max query QPS per tenant | 100 | `RATE_LIMIT_PER_TENANT_RPS` (ADR-0019) |
| Max concurrent ingests | 5 repos | `QUOTA_MAX_CONCURRENT_INGESTS` |

A tenant exceeding a quota receives `429 Too Many Requests` (query) or a rejection event (`ingest.quota_exceeded` Kafka event) rather than silently degrading other tenants.

**PostgreSQL Row-Level Security (Tier 3 defense-in-depth):**
```sql
ALTER TABLE file_facts ENABLE ROW LEVEL SECURITY;
CREATE POLICY tenant_isolation ON file_facts
  USING (tenant_id = current_setting('app.tenant_id'));
```
Workers set `SET LOCAL app.tenant_id = <tenant_id>` at the start of each DB transaction. Any query that omits the `tenant_id` filter returns zero rows — not an error, not another tenant's rows.

#### Isolation Tier B — Schema Isolation

Each tenant gets a dedicated PostgreSQL schema (`SCHEMA = tenant_{tenant_id}`). All tables exist in each schema; no RLS needed — queries only access the tenant's schema. Same PostgreSQL instance, same Kafka, same vector store.

| Component | Isolation mechanism |
|-----------|-------------------|
| PostgreSQL | Dedicated schema per tenant (`tenant_{id}.file_facts`, etc.) |
| Vector store | Same as Tier A — collection namespace |
| Kafka | Same as Tier A — shared topics |
| Artifact store | Same as Tier A — path prefix |

**When to use:** Tenant requires "no row-level sharing" but does not require fully separate infrastructure. Useful for GDPR Article 25 (data protection by design) compliance where schema isolation is sufficient evidence of data separation.

**Provisioning:** Admin API creates the schema and runs Alembic migrations against it. Worker processes set `search_path = tenant_{id}` per request.

**Trade-off:** Schema proliferation — PostgreSQL degrades above ~1,000 schemas. Tier B is appropriate for deployments with < 200 tenants.

#### Isolation Tier C — Physical (single-tenant deployment)

One ECLE instance per tenant. All infrastructure is dedicated. This is a deployment model choice, not a code change.

| Component | Isolation mechanism |
|-----------|-------------------|
| PostgreSQL | Dedicated instance (or RDS/Azure DB) |
| Vector store | Dedicated Qdrant cluster |
| Kafka | Dedicated Kafka cluster (or MSK/Event Hubs namespace) |
| Artifact store | Dedicated S3 bucket / Azure container |
| MCP server | Dedicated pods; dedicated DNS name |

**When to use:** Financial services (FCA, SEC data segregation requirements), healthcare (HIPAA), government (FedRAMP), or any customer whose contract requires physical data segregation.

**Provisioning:** Helm chart (ADR-0010 Phase 4) with `tenantId` as a Helm value. Each tenant is a separate Helm release. No code changes — only configuration.

**Cost:** Full infrastructure duplication per tenant. Charge-back must be modelled accordingly.

#### Isolation tier summary

| Property | Tier A (Logical) | Tier B (Schema) | Tier C (Physical) |
|----------|-----------------|-----------------|-------------------|
| Infrastructure | Shared | Shared | Dedicated |
| Noisy neighbor risk | Mitigated by quotas | Mitigated by quotas | Eliminated |
| GDPR row-level isolation | Via WHERE + RLS | Via schema boundary | Via instance boundary |
| Max tenants per deployment | 1,000+ | ~200 | 1 |
| Onboarding time | Seconds | Seconds | Minutes (Helm deploy) |
| Phase available | Phase 2 | Phase 3 | Phase 4 |

#### Per-tenant Kafka topic isolation (optional, Tier B/C)

For tenants that require Kafka-level isolation (Tier B/C), ECLE supports per-tenant topic namespacing:

```
ecle.{tenant_id}.file.ir_produced   ← tenant-scoped topic
```

Enabled by: `KAFKA_PER_TENANT_TOPICS=true` (default: false). Worker consumer group also namespaced: `ecle.{tenant_id}.persist_facts`. This eliminates cross-tenant partition sharing.

**Trade-off:** At 100 tenants × 12 topics × 12 partitions = 14,400 Kafka partitions. Kafka leader election overhead is non-trivial at this scale. Only enable for Tier B/C deployments with < 50 tenants.

---

### Consequences

**Positive:**
- Tier A with RLS + quotas covers the vast majority of enterprise use cases with no infrastructure overhead
- Tier C is a pure deployment configuration — no code branching, consistent with ADR-0010's "same code, all tiers" principle
- Isolation tier is documented and auditable — operators can show prospective customers which tier they're on

**Negative / Trade-offs:**
- RLS `SET LOCAL` requires all DB connections to set the session variable — if a worker forgets to set it, queries return empty results silently (not an error). Must be enforced in `IStructuredDB.execute()` base method.
- Schema isolation (Tier B) means Alembic migrations must run per-schema — migration tooling must iterate over all tenant schemas. `eval_schema_migration` must cover multi-schema deployments.
- Per-tenant Kafka topics are operationally expensive at scale — only justify for Tier C customers.

**Neutral / Operational notes:**
- Tier assignment is stored in `tenants.tier` (ADR-0020). Workers read this at startup and configure their DB connection accordingly.
- Tier A is the default for all new tenants. Upgrade to Tier B/C requires re-provisioning (create new tenant schema/deployment, re-ingest data, switch DNS/API keys).
- `QUOTA_MAX_REPOS`, `QUOTA_MAX_FILES` can be overridden per-tenant via Admin API config overrides (ADR-0020).

---

### Alternatives Considered

| Alternative | Why Rejected |
|-------------|-------------|
| Logical isolation only, no RLS | RLS is defense-in-depth — a missing WHERE clause in a future query would expose cross-tenant data without it; cost is negligible |
| Physical isolation for all tenants | Infrastructure cost is prohibitive for SaaS offerings; logical isolation + quotas is sufficient for most customers |
| Tenant-per-database (not schema) | PostgreSQL connection overhead per database is higher than per-schema; schema isolation achieves similar guarantees with lower overhead |

---

### Compliance

- Contract: `constitution/contracts/15-db-schema-contract.md` §1 — RLS policy mandate for Tier 3
- ADR: `ADR-0019` — per-tenant rate limits enforced by auth layer
- ADR: `ADR-0020` — `tenants.tier` set at creation time; quota override via Admin API
- ADR: `ADR-0021` — purge scope includes schema drop for Tier B
- Regulatory: GDPR Article 25 (data protection by design); HIPAA Administrative Safeguards; FedRAMP AC-4 (information flow)

---

### References

| # | Citation | Relevance to this ADR |
|---|----------|----------------------|
| R1 | Salesforce Multi-Tenancy Architecture (developer.salesforce.com) | Original SaaS multi-tenancy model; three isolation tiers (shared → schema → dedicated) match ECLE's Tier A/B/C |
| R2 | PostgreSQL Row-Level Security (postgresql.org/docs/current/ddl-rowsecurity.html) | Official PostgreSQL RLS documentation; validates `SET LOCAL app.tenant_id` pattern |
| R3 | OWASP Top 10:2021 — A01: Broken Access Control | RLS as database-layer defense-in-depth against access control failures |
| R4 | Azure SQL Elastic Pools & Database-per-Tenant pattern (learn.microsoft.com) | Industry pattern for tiered tenant isolation; validates schema vs database vs instance separation |
| R5 | GDPR Article 25 (eur-lex.europa.eu) — Data Protection by Design and by Default | Regulatory basis for schema isolation as evidence of data separation |
