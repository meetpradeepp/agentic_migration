# ADR-0026: Admin Portal UI

**Status:** Accepted
**Date:** 2026-05-07
**Deciders:** Lead Engineer, Architecture Review
**Supersedes:** —
**Superseded by:** —
**Amends:** ADR-0020 (adds a browser UI on top of the Admin REST API)
**FACT impact:** neutral — the portal is an operator tool, not on the query or ingestion hot path

---

### Context

ECLE 1.0 shipped an Admin UI built as a Python web application. It covered three operational workflows visible in the ECLE 1.0 screenshots:

1. **Onboard** — select content type, repo role, upload source (file upload or Git URL), trigger ingestion.
2. **Import Jobs** — paginated list of all ingestion jobs with status, duration, item counts, run date, and a Remove action.
3. **System Health** — per-repo knowledge-graph summary cards (code files, functions, connections, DB operations, documents, searchable items) with Ready badge.

ECLE 1.0 used a Python-rendered UI. For ECLE 2.0 the driver is:
- A Python-rendered UI required a Python web server, a template engine, and session handling — overlapping with, but separate from, the Admin REST API.
- A React SPA removes that server-side concern: the `ecle-admin` binary serves the bundled static assets once; the browser owns all rendering; the Admin REST API (ADR-0020) is the only backend.
- React also makes it straightforward to implement the ZIP-in-browser pattern (no server-side zip utility needed for the upload path).

The Admin Portal is **not a public product UI**. It is an operator tool for provisioning, monitoring, and debugging. It does not need to support mobile or heavy interactivity — functional > polished.

---

### Decision

We will build the Admin Portal as a **React 18 SPA** (TypeScript, Vite), bundled into static assets and served by the `ecle-admin` process at `GET /`. The `ecle-admin` binary becomes both the REST API server and the static file server — no separate Nginx or CDN.

**Tech choices:**

| Concern | Choice | Rationale |
|---------|--------|-----------|
| UI framework | React 18 + TypeScript | Team familiarity; React ecosystem is well-documented; TypeScript prevents shape mismatches with API responses |
| Build tool | Vite | Fast HMR, small bundle, zero config for static output |
| Component library | Radix UI Primitives + Tailwind CSS | Accessible, unstyled primitives + utility CSS — no opinionated design system lock-in; mirrors the ECLE 1.0 style (minimal, white/magenta) |
| HTTP client | `fetch` (built-in) + SWR | No extra dependency for data fetching; SWR gives cache + revalidation for health polling |
| ZIP packaging | `JSZip` (browser) | Client-side zipping — the browser zips the selected folder before upload; no server-side zip utility required |
| State management | React `useState` / `useReducer` only | Portal state is simple (form state + list data); no Redux |
| Routing | React Router v6 | Three pages; client-side routing |
| Auth | `Authorization: ApiKey <key>` in every fetch | No cookie session; the raw key is entered once in a setup screen and stored in `sessionStorage` — never `localStorage` |

**Source location:** `src/ecle/admin_ui/` — React/TypeScript source.
**Built output:** `src/ecle/admin_ui/dist/` — committed to repo; `ecle-admin` binary serves from this path.
**Dev workflow:** `npm run dev` in `src/ecle/admin_ui/` starts the Vite dev server proxying API calls to `localhost:4001`.

---

### Portal pages

#### Page 1 — Onboard (`/`)

Matches the ECLE 1.0 Onboard screen:

**Form fields:**
- **What are you onboarding?** — `<select>` with options: `Auto-detect (recommended)`, `Code`, `Docs`, `Config`, `Data`, `Data-SQL`. Maps to `content_types[]` in `POST /admin/v1/repos`.
- **This data applies to** — toggle: `Specific repository` | `All repositories (platform)`. Maps to `repo_role = module | platform`. When `platform` is selected, a second `<select>` appears: `Platform (shared)` (pre-populated with known platform repos).
- **Where is your data located?** — toggle: `Upload Files` | `Git Repository`.
  - `Upload Files`: drag-and-drop zone — `Select a folder or drag files here`. Accepts folder selection (`webkitdirectory`) or individual files.
  
    **After folder selection — File Selection Summary modal (pre-flight, client-side only):**
    Before JSZip runs and before any network call is made, the browser executes a pre-flight scan of all selected files and opens the File Selection Summary modal. This gives the operator full visibility into exactly what will be uploaded.

    Pre-flight algorithm:
    1. Fetch the allowed extension list from `GET /admin/v1/language-packs` (cached for the session; one call per page load). This returns every extension the installed language packs can handle.
    2. For each file in the `FileList`, classify it as `included` or `filtered`:
       - `included` — extension is in the allowed extension list, or `content_type=auto` and extension is a known code/docs/config/data extension.
       - `filtered` — extension is not in the allowed list; reason string: `".{ext} not in allowed extensions"`.
    3. Build a folder-tree structure from all file paths, accumulating per-folder `included_count` and `filtered_count`.

    **Modal content:**
    ```
    ┌─ File Selection Summary ──────────────────────────── [×] ─┐
    │                                                             │
    │  ✅ 7952 included    ✗ 1199 filtered                       │
    │                                                             │
    │  ⚠ vstcsm/ (7952 included, 1199 filtered)                  │
    │    ✅ amdocs/ (109 files)                                   │
    │    ⚠ ar/ (171 included, 20 filtered)                       │
    │      ✅ inc/ (76 files)                                     │
    │      ⚠ src/ (95 included, 20 filtered)                     │
    │        ✗ par_adj.c.cos  — .cos not in allowed extensions   │
    │        ✗ par_adj.c.union — .union not in allowed extensions │
    │        ✗ par_ban_level_services.c.cos — ...                 │
    │        ...                                                  │
    │                                                             │
    │                              [ Copy ]  [ Close ]           │
    └─────────────────────────────────────────────────────────────┘
    ```

    **Folder icon rules:**
    - ✅ green checkbox — `filtered_count == 0`
    - ⚠ amber warning — `filtered_count > 0 && included_count > 0` (partial)
    - ✗ red cross — `included_count == 0` (entire folder filtered)

    **Copy button**: copies a plain-text version of the summary tree to the clipboard (same format as shown). Useful for sharing with the team or raising a language pack coverage request.

    **Close / Proceed**: modal has only `Close`. Closing the modal returns to the Onboard form with the selection intact. The drop zone summary line updates to show the breakdown of included files by detected content type (e.g., `data, 6050 code, 739 data-sql`) — matching the ECLE 1.0 drop zone sub-text.

    **On submit (Start Onboarding)**: JSZip runs over the `included` file list only — filtered files are never added to the ZIP. The modal is NOT shown again at submit time; it was shown at selection time.

    **Drop zone summary line** (shown after selection, below the drop zone):
    `{N} code, {N} docs, {N} config, {N} data-sql` — content-type counts of included files, inferred from extension. `Clear` link resets the selection.

  - `Git Repository`: text input for Git URL + optional branch. On submit, sends `POST /admin/v1/repos` with `source_type=git`.
- **Start Onboarding** — primary action button. Disabled until required fields are filled.

**Post-submit:** redirect to Import Jobs page (`/jobs`) with the new job highlighted.

**View all jobs →** link top-right, routes to `/jobs`.

---

#### Page 2 — Import Jobs (`/jobs`)

Matches the ECLE 1.0 "Import Jobs" screen. Paginated table of all ingestion jobs for the current tenant.

**Table columns:**
- **Repo** — `repo_id` (short name, linked to `/health#{repo_id}`)
- **Type** — `content_type` + `fidelity` badge (e.g., `code structural`, `code deep`, `data-sql`, `config`, `auto`)
- **Imported** — `imported_count` (item count)
- **Duration** — `duration_ms` formatted as `8m 14s`, `25s`, etc.
- **Run Date** — `started_at` formatted as `Apr 29, 06:55 PM`
- **Status** — `Complete` (green) / `Running` (blue, with spinner) / `Failed` (red) / `Pending` (grey). Sub-text line for detail: e.g., `78 new, 22 empty` or `43 docs, 256 chunks`
- **Actions** — `Remove` button → `DELETE /admin/v1/import-jobs/{job_id}` (removes job record, does NOT purge repo data)

**Filters:** search by repo name, filter by status, filter by content type. All client-side on the fetched page.

**Pagination:** 10 rows/page. `GET /admin/v1/import-jobs?page=N&per_page=10`. Navigation: first / prev / page-N / next / last.

**Auto-refresh:** SWR polls every 5 s while any job has `status = running | pending`.

---

#### Page 3 — System Health (`/health`)

Matches the ECLE 1.0 System Health screen. Per-repo knowledge-graph summary cards.

**Data source:** `GET /admin/v1/health/repos` — returns the same per-repo gauges as the Prometheus metrics in Contract 16 §2, but as JSON for the UI.

**Card layout per repo:**
```
{repo_id}   [Ready | Running | Failed]
┌──────────┬──────────┬──────────┬──────────┬──────────┬──────────┐
│  N,NNN   │  N,NNN   │  N,NNN   │    N     │   N,NNN  │  N,NNN  │
│Code Files│Functions │Connections│DB Ops   │Documents │Searchable│
└──────────┴──────────┴──────────┴──────────┴──────────┴──────────┘
```

Platform repo card shows the `PLATFORM` badge (as in ECLE 1.0). Tile is hidden when the count for that dimension is 0 for that repo (e.g., `csm_powerbuilder` in ECLE 1.0 had no Connections tile).

**Search:** client-side filter by repo name.

**Pagination:** 5 cards/page (repos with most searchable items first).

---

#### Page 4 — Worker Control (`/workers`)

New page added per ADR-0027. Single pane of glass for all Kafka worker state — lifecycle control, scaling visibility, per-worker metrics.

**Data source:** `GET /admin/v1/workers` (ADR-0020 amendment). Polled every 5 s via SWR.

**Worker table columns:**

| Column | Source | Notes |
|--------|--------|-------|
| Worker | `worker_name` | Display name, e.g. `parse_repo` |
| Status | `lifecycle` | Coloured badge: `running` (green) / `paused` (amber) / `draining` (blue) |
| Kafka Lag | `kafka_lag` | Right-aligned number; red if > `KAFKA_LAG_ALERT_THRESHOLD` |
| Throughput | `throughput_rpm` | Messages/min (last 5 min rolling) |
| Error Rate | `error_rate` | Percentage; red if > 1% |
| Replicas | `replicas.current / replicas.max` | e.g. `3 / 16` |
| Last Heartbeat | `last_heartbeat` | Relative time (`42s ago`); red if > 90 s (worker may be down) |
| Actions | — | Context-sensitive buttons (see below) |

**Per-row action buttons (context-sensitive):**

| Worker state | Available actions |
|-------------|-------------------|
| `running` | `Pause`, `Drain` |
| `paused` | `Resume`, `Reset Offset` (opens confirmation modal) |
| `draining` | _(no action — shows progress bar until lag=0)_ |

**Reset Offset modal** — double-confirmation guard:
1. Select offset target: `Earliest (full reprocess)` / `Latest (skip backlog)` / `Custom timestamp`.
2. Warning banner: "This will reprocess all messages from the selected point. This action cannot be undone."
3. Type worker name to confirm — input must match exactly before the Submit button enables.
4. Sends `POST /admin/v1/workers/{name}/reset-offset` with `{ "offset_target": "...", "confirm": true }`.

**Per-worker detail drawer** (click row → slide-in panel):
- 1h sparkline charts: kafka lag, throughput, error rate (data from `GET /admin/v1/workers/{name}`)
- Pipeline step contributions: mini-table of recent `import_jobs` showing this worker's `pipeline_state` entry
- Last 5 ERROR log lines for this worker (from `GET /admin/v1/workers/{name}/recent-errors`)
- Current scaling config: min/max replicas, lag threshold — inline editable (calls `PUT /admin/v1/config/WORKER_{NAME}_MAX_REPLICAS`)

**Navigation:** "Workers" added to top nav bar alongside "Onboard" and "Health".

---

### ZIP upload flow

```
Browser                      ecle-admin (port 4001)          Kafka
   │                                │                           │
   │  user selects folder           │                           │
   │  pre-flight scan runs          │                           │
   │  File Selection Summary modal  │                           │
   │  user reviews & closes modal   │                           │
   │                                │                           │
   │  JSZip.generateAsync()         │                           │
   │  (included files only → ZIP)   │                           │
   │                                │                           │
   │  POST /admin/v1/upload         │                           │
   │  Content-Type: multipart/form-data                         │
   │  Fields: repo_id, content_types[], repo_role,              │
   │          zip file,                                         │
   │          filtered_extensions[] (from pre-flight)           │
   │────────────────────────────────▶                           │
   │                                │  save ZIP to IArtifactStore
   │                                │  (path: uploads/{tenant}/{job_id}.zip)
   │                                │  write import_jobs row (status=pending)
   │                                │  for each filtered_extension:
   │                                │    emit language_pack.extension_miss
   │                                │    → coverage_gap_aggregator (ADR-0002)
   │                                │  emit upload.received event
   │                                │────────────────────────────▶
   │  202 { job_id }                │                           │
   │◀───────────────────────────────│                           │
   │                                │                           │
   │  redirect to /jobs             │                           │
   │  poll GET /import-jobs/{job_id}│                           │
```

`POST /admin/v1/upload` constraints:
- Max ZIP size: `UPLOAD_MAX_BYTES` (default: 500 MB). Enforced in the Admin API before saving.
- File count cap: `UPLOAD_MAX_FILES` (default: 50,000 files in ZIP). Enforced by `scan_source` worker after extraction.
- ZIP is extracted by the `scan_source` Kafka worker (not the Admin API) — Admin API is not in the parse path.
- After extraction, `scan_source` emits `repo.detected` per discovered repo root, exactly as for Git sources.
- `filtered_extensions[]` field carries the per-extension filtered file counts from the browser pre-flight (`{ ".cos": 847, ".union": 352 }`). Admin API emits one `language_pack.extension_miss` event per extension exceeding 0 filtered files — feeding the `coverage_gap_aggregator` (ADR-0002) with real upload-time signal. This makes the coverage gap tracking proactive: operators see gaps before ingestion completes.

---

### `ecle-admin` binary changes (ADR-0020 amendment)

The `ecle-admin` binary gains:
1. Static file handler: `GET /` and `GET /assets/*` serve the Vite build output from `src/ecle/admin_ui/dist/`.
2. SPA fallback: any unmatched `GET` path returns `index.html` (React Router handles client-side routes).
3. New endpoints (see ADR-0020 §ZIP Upload and §Import Jobs).
4. `ADMIN_UI_ENABLED=true` default for all tiers. Set `ADMIN_UI_ENABLED=false` to disable the UI and serve only the REST API (e.g., headless CI/CD use).

**Dev vs. prod:**
- Dev: Vite dev server on port 5173 proxies `/admin/v1/**` to `localhost:4001`. `ecle-admin` does not serve static files in dev mode (`ADMIN_UI_DEV=true`).
- CI: `npm run build` runs as part of the Python build (via `Makefile` target `build-ui`). Output committed to `src/ecle/admin_ui/dist/` so the Python package ships the UI without a Node runtime at deploy time.
- Tier 1/2/3: Node is NOT required at runtime — only the built static assets ship.

---

### Auth in the browser

The API key is **never stored in `localStorage`** (XSS risk — OWASP A03).

Auth flow:
1. First visit → redirect to `/setup` page (key entry screen).
2. User pastes their `admin`-scoped API key.
3. Key stored in `sessionStorage` only — cleared on tab close.
4. Every `fetch` call attaches `Authorization: ApiKey <key>`.
5. On 401 response → clear key from `sessionStorage` + redirect to `/setup`.

`X-Tenant-Id` is stored alongside the key in `sessionStorage`, set on the `/setup` screen.

---

### Consequences

**Positive:**
- Single binary (`ecle-admin`) serves both the REST API and the portal — no extra deployment concern.
- No Node runtime at deploy time — UI is a pre-built static bundle.
- ZIP-in-browser eliminates the need for server-side zip utilities and handles large folder uploads gracefully via chunked multipart (browser handles progress natively).
- React SPA is richer and faster to iterate on than a Python-rendered UI — component reuse across all three pages.

**Negative / Trade-offs:**
- Adds a `npm run build` step to the CI pipeline — Node toolchain required in CI.
- `JSZip` runs in the main thread for large folders (>10,000 files) — may block UI briefly. Mitigation: run JSZip in a Web Worker (`JSZip` supports streaming generation).
- `sessionStorage` key storage means the user must re-enter the key after closing the tab. Acceptable for an operator tool — operators are not end users.

---

### Alternatives Considered

| Alternative | Why Rejected |
|-------------|-------------|
| Python-rendered UI (ECLE 1.0 approach) | Mixes server-side template rendering with the REST API — two concerns in one process; harder to iterate on UI without touching Python; no clean separation of API contract from presentation |
| Streamlit | Suited for data science dashboards, not operational UIs with forms, tables, and file upload; no clean REST API separation |
| Server-side ZIP extraction at upload time | Blocks the Admin API process during extraction of large uploads; extraction belongs in the Kafka worker pipeline |
| Separate Nginx for static files | Adds an extra deployment component for no benefit; `ecle-admin` can serve static files with standard Python ASGI middleware (e.g., `starlette.staticfiles`) |

---

### Compliance

- ADR: `ADR-0020` — Admin REST API; this ADR amends it with UI surface and ZIP upload endpoint
- ADR: `ADR-0019` — API key auth; key stored in `sessionStorage`, never `localStorage`
- Contract: `constitution/contracts/09-event-pipeline-contract.md` — `upload.received`, `source.received` events
- Contract: `constitution/contracts/15-db-schema-contract.md` — `import_jobs` table
- Contract: `constitution/contracts/16-observability-contract.md` — import job duration metrics feed System Health page
- OWASP A03 (XSS) — API key in `sessionStorage` only, never `localStorage` or DOM attributes
