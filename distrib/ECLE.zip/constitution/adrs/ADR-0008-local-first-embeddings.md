# ADR-0008: Local-First ONNX/OpenVINO Embeddings

**Status:** Accepted  
**Date:** 2026-05-05  
**Deciders:** Lead Engineer, Architecture Review  
**Supersedes:** —  
**Superseded by:** —  

---

### Context

ECLE 2.0 must embed source code chunks and function signatures as dense vectors for
semantic search (Layer 1/2/3 of the vector index). The embedding step runs inside the
`batch_embed` Celery worker and must satisfy three constraints:

1. **Air-gapped compliance** — enterprise customers run ECLE inside isolated networks
   with no internet access. Calling an external embedding API (OpenAI, Cohere, Voyage)
   is not possible in these environments.

2. **Cost predictability** — external APIs charge per token. At 1M files × ~2K tokens
   average = 2B tokens per full corpus embedding. At $0.10/1M tokens, that is $200 per
   full corpus run. On model upgrade or schema change, the full corpus must be
   re-embedded. Cost is unbounded.

3. **Latency control** — external API round-trips add 50–500ms per batch. Local ONNX
   inference runs at ~2–5ms per batch on CPU, ~0.5ms on GPU. This is required to keep
   the `batch_embed` worker throughput compatible with the ingestion pipeline.

The decision of which specific model to use (384-dim vs 768-dim) is deferred to a
Phase 2 benchmark ADR. This ADR records only the deployment model decision: local-only,
ONNX runtime mandatory.

---

### Decision

We will mandate **local ONNX/OpenVINO inference** as the only supported embedding
execution mode by default. Cloud embedding APIs are **opt-in adapters**, not the default,
and are disabled unless explicitly configured.

**Baseline model:** `all-MiniLM-L6-v2` (384-dim, Apache 2.0 licence).  
This is the Phase 1 default. Phase 2 will benchmark 768-dim alternatives and produce a
separate ADR recording the chosen model.

**Interface:** `IEmbeddingModel` — concrete implementations:
- `ONNXEmbeddingModel` (default, mandatory for air-gapped)
- `OpenVINOEmbeddingModel` (Intel hardware acceleration)
- `OpenAIEmbeddingModel` (opt-in adapter, disabled by default)

**Config:**
```
EMBEDDING_BACKEND: "onnx" | "openvino" | "openai"   — default: "onnx"
EMBEDDING_MODEL_PATH: path to .onnx model file
EMBEDDING_MODEL_NAME: "all-MiniLM-L6-v2"
EMBEDDING_DIM: 384
```

**Idempotency key** (prevents re-embedding unchanged content):
```
key = SHA256(entity_id + content_hash + EMBEDDING_MODEL_NAME + str(EMBEDDING_DIM))
```
If key exists in `indexing_state.embed_idempotency_key`: skip. Never re-embed unchanged content.

---

### Consequences

**Positive:**

- Air-gapped deployment is first-class — works with zero network connectivity
- No per-token cost; total cost of embedding is bounded by compute hardware
- Latency is local (~2–5ms/batch CPU, ~0.5ms/batch GPU) — compatible with ingestion throughput
- Model is version-pinned in `EMBEDDING_MODEL_NAME` — reproducible embeddings
- ONNX format is hardware-agnostic: runs on x86 CPU, ARM, Intel GPU (OpenVINO), NVIDIA (ONNX Runtime GPU)
- Cloud API adapter is an opt-in fallback for teams without local GPU — not removed, just not default

**Negative / Trade-offs:**

- ONNX model file must be distributed with the deployment (not downloaded at runtime in air-gapped)
- Model upgrade requires a full corpus re-embedding sweep (expensive at scale)
- Local CPU embedding is slower than GPU — Phase 1 on CPU may be a bottleneck for large corpora
- `IEmbeddingModel` interface adds abstraction layer vs direct `sentence-transformers` call

**Neutral / Operational notes:**

- Phase 1: CPU ONNX only; GPU and OpenVINO are config options, not required
- Model file included in Docker image or mounted as a volume — ops decision
- Re-embedding on model upgrade is a background job — old vectors remain queryable with `model_version` filter until sweep completes (per ADR-0004 slim payload design)
- `EMBEDDING_DIM` must match the vector collection's declared dimension — mismatch raises `DimensionMismatchError` at upsert time

---

### Alternatives Considered

| Alternative | Why Rejected |
|-------------|-------------|
| OpenAI Embeddings API as default | Violates air-gapped requirement; unbounded cost; latency unpredictable |
| `sentence-transformers` Python library (no ONNX) | ONNX runtime is faster on CPU; ONNX is more portable across hardware; `sentence-transformers` can export to ONNX |
| Fine-tuned code embedding model (CodeBERT, UniXcoder) | Higher quality for code; excluded from Phase 1 because ONNX export is non-trivial; deferred to Phase 2 benchmark |
| No abstraction (hardcode ONNX calls) | Prevents testing with mock model; prevents opt-in cloud adapter; violates Open/Closed principle |

---

### Compliance

- Contract: `constitution/contracts/12-embedding-contract.md` (runtime rules)
- ADR-0004: Slim Vector Design — `model_version` in slim payload uses `EMBEDDING_MODEL_NAME + EMBEDDING_DIM`
- Eval: `eval_idempotent_ingest` — verifies unchanged content is not re-embedded
- Anti-pattern: A6 (hardcoded backend — `batch_embed` must use `IEmbeddingModel` factory)

---

### References

| # | Citation | Relevance to this ADR |
|---|----------|----------------------|
| R1 | Nussbaum, Z. et al. "Nomic Embed: Training a Reproducible Long Context Text Embedder", TMLR 2024 (arXiv:2402.01613) | Fully open-source, open-data 8192-context embedding model outperforming OpenAI Ada-002 — proves local-first embeddings are production-viable |
| R2 | Gao, Y. et al. "Retrieval-Augmented Generation for Large Language Models: A Survey", 2024 (arXiv:2312.10997) | Survey confirms local embedding models achieve competitive quality without cloud dependency |
| R3 | ONNX Runtime (onnxruntime.ai) — Microsoft open standard for portable ML inference | Industry standard for air-gapped, cross-platform model deployment; used by Azure, AWS, Google for edge inference |
