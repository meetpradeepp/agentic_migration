# ADR-0021: Data Lifecycle — Retention, Deletion, and GDPR

**Status:** Accepted
**Date:** 2026-05-07
**Deciders:** Lead Engineer, Architecture Review, Legal/Compliance
**Supersedes:** —
**Superseded by:** —
**Amends:** Contract 15 (DB schema — "no hard deletes" rule gains a defined exception), ADR-0013 (Kafka retention tiering — governed by this ADR)
**FACT impact:**
- Fast: `neutral` — lifecycle jobs run as Celery Beat tasks off the query hot path; no query-time cost
- Accurate: `neutral` — deleted data was already excluded by `is_current` and `tenant_id` filters; deletion does not affect active query results
- Complete: `improves` — explicit data lifecycle policy removes ambiguity for operators; GDPR compliance enables enterprise deals that would otherwise be blocked
- Trustworthy: `improves` — operators can make honest data retention claims to customers and regulators; audit log retention is formally bounded and predictable

---

### Context

Contract 15 §1 states "No hard deletes on fact tables — old versions are superseded, never deleted." This is the right policy for operational data integrity (no lost history during active ingestion). However it creates three problems:

1. **GDPR Article 17 (Right to Erasure):** EU customers can request deletion of their data. "We keep everything forever" is not a legally valid response.
2. **Storage growth:** Perpetual history with no archival policy means unbounded PostgreSQL and artifact store growth. At scale (10K files × 100 commits × 20 bytes/row) the `indexing_state` table alone grows by ~20M rows/month.
3. **Kafka retention gap:** ADR-0013 now defines tiered Kafka retention (3–90 days by category). The DB has no equivalent policy — Kafka deletes after days, Postgres retains forever. The asymmetry means replay is impossible past the Kafka retention window anyway, making perpetual DB history operational theater.

The "no hard deletes" rule is correct **within the active lifecycle of a repo**. It must be amended to allow **scheduled hard purge** after defined retention periods or explicit deletion requests.

---

### Decision

We will introduce a **data lifecycle model** with three operations: **tenant purge**, **repo purge**, and **audit log expiry**. All purges are scheduled (not immediate), logged, and idempotent.

#### 1. Tenant Purge

Triggered by `DELETE /admin/v1/tenants/{tenant_id}` (ADR-0020). Removes all data associated with a tenant across all stores.

**Schedule:** Purge begins `TENANT_PURGE_DELAY_DAYS` (default: 7) days after the deletion request. This grace period allows accidental deletions to be cancelled.

**Scope:** ALL data for the tenant is deleted:
- All rows in all fact tables where `tenant_id = <id>` — hard deleted
- All vector collections `{tenant_id}__*` — dropped from vector store
- All artifact files under `artifacts/<tenant_id>/` — deleted from artifact store
- All Kafka consumer group offsets for `ecle.{tenant_id}.*` topics (if per-tenant topics are used)
- `api_keys` for the tenant
- `tenant_config` entries for the tenant
- `query_audit_log` rows for the tenant (after `AUDIT_LOG_RETENTION_DAYS` — cannot be pre-deleted for audit compliance)

**Purge is irreversible.** No soft-delete at tenant level — once the grace period ends, all data is gone.

**Mechanism:** Celery Beat job `purge_tenant_task` checks `tenants.purge_at` daily. When `purge_at <= NOW()`, executes the full deletion sequence. Emits `tenant.purged` Kafka event on completion.

#### 2. Repo Purge

Triggered by `DELETE /admin/v1/repos/{repo_id}` (ADR-0020). Removes all data for one repository within a tenant.

**Schedule:** Purge begins `REPO_PURGE_DELAY_DAYS` (default: 3) days after deletion request.

**Scope:**
- All `file_facts` rows (all versions) for this `(tenant_id, repo_id)` — hard deleted (cascades to `function_facts`, `file_tables`, `file_entry_points`, `file_external_calls`, `function_calls`, `topology_edges`, `cluster_assignments`, `indexing_state`)
- All vector collection entries for `repo_id` filter — deleted from vector store (not full collection drop — other repos share Layer 3 centroids for cross-repo collection)
- Artifact files under `artifacts/<tenant_id>/<repo_id>/` — deleted from artifact store
- `cross_repo_edges` rows referencing this `repo_id` (as source or target) — hard deleted
- `shared_artifacts` rows from this `repo_id` — hard deleted
- `cross_repo_summary` row for this `repo_id` — hard deleted

`repositories` row is NOT deleted — it is marked `index_status = 'purged'`. This preserves the repo's name/role in the audit trail without retaining any code data.

**Mechanism:** Celery Beat job `purge_repo_task`. Emits `repo.purged` Kafka event.

#### 3. Fact Table Version Archival (historical versions, not current)

For active repos, `is_current=false` rows accumulate indefinitely. These are old versions of files that have been re-indexed. They are needed for:
- `version_distance` computation (needs previous version)
- Audit trail (when was function X last seen with this signature?)

After `FACT_VERSION_RETENTION_DAYS` (default: 90), non-current versions are hard-deleted:
```sql
DELETE FROM file_facts
WHERE is_current = false
  AND superseded_at < NOW() - INTERVAL '{FACT_VERSION_RETENTION_DAYS} days'
  AND tenant_id = :tenant_id;
```

This runs as a Celery Beat job `archive_old_versions_task` (nightly, low priority). Cascades to all child tables via FK ON DELETE CASCADE.

**Exception:** The current row (`is_current=true`) is NEVER deleted by this job. Only superseded versions are eligible.

#### 4. Audit Log Expiry

`query_audit_log` rows are hard-deleted after `AUDIT_LOG_RETENTION_DAYS` (default: 365):
```sql
DELETE FROM query_audit_log
WHERE called_at < NOW() - INTERVAL '{AUDIT_LOG_RETENTION_DAYS} days';
```

Minimum compliant value: 90 days (SOC 2 requirement). Maximum: unlimited (some regulated industries require 7 years — set `AUDIT_LOG_RETENTION_DAYS=2555`).

#### 5. GDPR Right to Erasure Flow

When a GDPR erasure request is received for a specific user identity (`sub` field in audit log):

1. Admin calls `POST /admin/v1/gdpr/erasure` with `{ "subject": "user@corp.com" }`.
2. ECLE deletes all `query_audit_log` rows where `subject = "user@corp.com"` — immediately, not scheduled.
3. Revokes all API keys where the key's `label` metadata matches the subject (soft revoke).
4. ECLE does NOT delete code facts — source code is not personal data. Only the audit log (who made which query) and API keys (caller identity) are personal data in ECLE's data model.
5. Returns a signed deletion confirmation receipt (`erasure_id`, timestamp, row counts deleted) — suitable for regulatory evidence.

**What is NOT personal data in ECLE:**
- Source code content (belongs to the organization, not the individual)
- `file_facts`, `function_facts`, topology edges — structural facts about code
- Vector embeddings — dense numerical representations of code structure

**What IS personal data in ECLE:**
- `query_audit_log.subject` — ties a person's identity to their queries
- `api_keys.label` — may contain a person's name or email

#### 6. Lifecycle configuration constants

| Constant | Default | Minimum | Meaning |
|----------|---------|---------|---------|
| `TENANT_PURGE_DELAY_DAYS` | 7 | 0 | Grace period before tenant purge executes |
| `REPO_PURGE_DELAY_DAYS` | 3 | 0 | Grace period before repo purge executes |
| `FACT_VERSION_RETENTION_DAYS` | 90 | 7 | How long to keep superseded fact versions |
| `AUDIT_LOG_RETENTION_DAYS` | 365 | 90 | How long to keep query audit records |
| `KAFKA_RETENTION_CRITICAL_DAYS` | 30 | 7 | ADR-0013 critical pipeline retention |
| `KAFKA_RETENTION_BULK_DAYS` | 7 | 1 | ADR-0013 derived event retention |
| `KAFKA_RETENTION_OPS_DAYS` | 3 | 1 | ADR-0013 operational event retention |
| `KAFKA_RETENTION_DLQ_DAYS` | 90 | 30 | DLQ retention |

---

### Consequences

**Positive:**
- GDPR Article 17 compliance path is defined and implementable
- Storage growth is bounded — `file_facts` history beyond 90 days is pruned; audit log is bounded
- Tenant offboarding is operationally clean — no manual DB cleanup required
- Aligns with ADR-0013's Kafka tiered retention model: DB and Kafka retention are now consistent (pipeline replay is impossible past Kafka retention anyway)

**Negative / Trade-offs:**
- `FACT_VERSION_RETENTION_DAYS=90` means `version_distance` history beyond 90 days is unavailable — acceptable because version distance is only relevant for recent changes
- Tenant purge grace period means data is not immediately deleted — GDPR erasure requests for code facts (not personal data) are not required by law, only audit log erasure is
- Cascading deletes are expensive at large scale — purge jobs must be rate-limited (`PURGE_BATCH_SIZE = 1000` rows per transaction, sleep between batches) to avoid locking the DB

**Neutral / Operational notes:**
- Contract 15 §1 "no hard deletes" rule is now amended: hard deletes are permitted for (a) lifecycle-expired fact versions, (b) purge operations, (c) GDPR erasure, (d) audit log expiry. All other deletes remain banned.
- `cancellation` of a pending purge: `PATCH /admin/v1/repos/{repo_id}` with `{ "cancel_purge": true }` sets `purge_at = null`.
- All purge operations emit a Kafka event (`tenant.purged`, `repo.purged`) for downstream observability.

---

### Alternatives Considered

| Alternative | Why Rejected |
|-------------|-------------|
| Keep "no hard deletes" rule absolutely | Not GDPR-compliant; unbounded storage growth; rejected |
| Immediate hard delete (no grace period) | One accidental Admin API call destroys months of indexing work; grace period is essential |
| Separate archival DB for old versions | Two DB instances to maintain; query complexity doubled; version pruning achieves the same space saving with less complexity |
| Kafka compaction for audit log | Kafka is not queryable by subject; `query_audit_log` in PG is the audit store; Kafka retains pipeline events, not query history |

---

### Compliance

- Contract: `constitution/contracts/15-db-schema-contract.md` §1 — amended to permit lifecycle hard deletes
- ADR: `ADR-0013` — Kafka retention tiers governed by this ADR's constants
- ADR: `ADR-0019` — audit log retention period (`AUDIT_LOG_RETENTION_DAYS`)
- ADR: `ADR-0020` — purge endpoints in Admin API
- Regulatory: GDPR Article 17 (Right to Erasure); SOC 2 Type II audit log requirements
