# ADR-0015: Three-Axis Onboard Model

**Status:** Accepted  
**Date:** 2026-05-06  
**Deciders:** Lead Engineer, Architecture Review  
**Supersedes:** —  
**Superseded by:** —  
**Related:** ADR-0012, ADR-0017, Contract 06 §8 (tiered knowledge authority)

---

### FACT Impact

| Dimension | Impact |
|-----------|--------|
| **Fast** | `improves` — content_type selection at onboard time routes directly to the correct parser; no runtime parser detection per file; platform repo data (Tier 1-domain) routes to exact lookup tables, never to embedding pipeline, eliminating unnecessary vector compute |
| **Accurate** | `improves` — domain-specific parsers (XML, DDL, API spec) produce exact structured rows with full field fidelity; embedding would lose precision; routing to the right parser is determined before any data is read |
| **Complete** | `improves` — all 30 onboard configurations (5 content types × 2 sources × 3 schedules) are valid and handled; no content type falls through to a generic handler or is silently skipped |
| **Trustworthy** | `improves` — every onboarded artifact carries `content_type` and `repo_role` in its lineage; the tier authority model (Contract 06 §8) is enforced by routing, not by runtime assertion |

---

### Context

ECLE 1.0 had a single onboard path: clone a repo, run CPG, load facts. This broke down
as the system encountered:

- **Domain XML directories** with thousands of files following a common schema — loaded
  one at a time with no common-structure awareness
- **DDL schemas** embedded as SQL files in repos — parsed as text, not as structured schema
- **System understanding documents** (Markdown, DOCX) — ignored entirely or ingested
  as raw text blobs
- **Config files** — not distinguished from source code; caused spurious CPG extraction errors
- **Platform repos vs module repos** — no distinction at onboard time; both went through
  identical pipelines regardless of their role

The result: everything was code-like, everything went through CPG (or failed trying),
and the system had no model for the authority level of what it was ingesting.

ECLE 2.0 resolves this with a **three-axis onboard model**: content type determines the
parser; source determines the connector; schedule determines the trigger. These are
independent axes — any combination is valid.

---

### Decision

#### The three axes

```
┌─────────────────────────────────────────────────────────┐
│              THREE-AXIS ONBOARD MODEL                    │
│                                                          │
│  AXIS 1: Content Type (WHAT — selects parser)            │
│  ┌──────────┬──────────┬──────────┬──────────┬────────┐ │
│  │  code    │  config  │  data    │  data-sql│  docs  │ │
│  └──────────┴──────────┴──────────┴──────────┴────────┘ │
│                                                          │
│  AXIS 2: Source (WHERE — selects connector)              │
│  ┌────────────────────┬──────────────────────┐          │
│  │  git               │  local               │          │
│  └────────────────────┴──────────────────────┘          │
│                                                          │
│  AXIS 3: Schedule (WHEN — selects trigger)               │
│  ┌──────────┬──────────────┬──────────────┐             │
│  │  once    │  recurring   │  re-run      │             │
│  └──────────┴──────────────┴──────────────┘             │
│                                                          │
│  5 × 2 × 3 = 30 valid onboard configurations            │
└─────────────────────────────────────────────────────────┘
```

---

#### Axis 1: Content type → parser routing

| Content type | File extensions | Parser | Output tier | Storage target |
|-------------|----------------|--------|------------|----------------|
| `code` | `.c`, `.cpp`, `.java`, `.py`, `.js`, `.ppc`, `.cbl`, `.go`, `.cs` | tree-sitter + extractor.sc (ADR-0016) | Tier 1-code | Structured DB (file_facts, function_facts, etc.) + Vector Layer 1/2 |
| `config` | `.yaml`, `.yml`, `.cfg`, `.env`, `.properties`, `.sh`, `.bat` | Config parser (key-value + server group extraction) | Tier 1-domain | Structured DB (field_extractions, service_call_index) |
| `data` | `.xml`, `.fml`, `.txt` (structured), `.tsv`, `.csv` | Schema-aware domain parser (per document type — see §Document type detection) | Tier 1-domain | Structured DB (field_extractions, service_call_index, shared_artifacts) |
| `data-sql` | `.sql`, `.ddl`, `.rql`, `.pks`, `.pkb` | SQL/DDL parser (CREATE TABLE, ALTER, INDEX, stored procs) | Tier 1-domain | Structured DB (file_tables for schema, field_extractions for columns) |
| `docs` | `.md`, `.docx`, `.pdf`, `.html`, `.txt` (narrative) | Document reader + chunker | Tier 3 | Structured DB (doc_chunks) + Vector Layer Docs |

**Critical routing rules:**
- `data` and `data-sql` → Structured DB ONLY. These content types MUST NOT produce vector embeddings. Embedding destroys their precision (Contract 06 §8 Tier 1-domain rule).
- `docs` → Layer Docs vector collection. These MUST NOT write to fact tables (`file_facts`, `function_facts`).
- `code` → both Structured DB and Vector Layer 1/2. This is the only content type that goes to both.
- `config` → Structured DB only. Config values are exact lookup targets.

**Document type detection for `data`:**

When `content_type=data`, a lightweight document-type detector runs before the parser is
selected. Detection is based on root element name (for XML), file naming conventions,
and header structure. This is a secondary detection step, not ADR-0012 language detection.

| Document type pattern | Detected as | Parser used |
|--------------------|------------|------------|
| XML with service/operation schema structure | `api_spec` | API spec parser |
| XML with field/type declarations | `field_definition` | Field definition parser |
| Structured text with key: value pairs | `config_flat` | Flat config parser |
| CSV/TSV with header row | `tabular_data` | Tabular parser |

If document type cannot be detected → `data_type = 'unknown'` → skip with `parse_status = 'unsupported'`. Never force a parser on unrecognized data.

---

#### Axis 2: Source → connector routing

| Source | Connector | What it does |
|--------|-----------|-------------|
| `git` | `GitConnector` | Clone/pull repo, track commits, resolve HEAD, extract changed files since last indexed commit |
| `local` | `LocalFsConnector` | Scan directory, compute content_hash per file, detect additions/changes |

Both connectors emit the same `file.discovered` events — downstream workers are connector-agnostic.

**git-specific behaviors:**
- Maintains `versions` table rows (commit history)
- `schedule=recurring` → webhook or polling for new commits
- Changed file detection: `git diff HEAD~1..HEAD --name-only`

**local-specific behaviors:**
- No commit history — uses `content_hash` as sole change signal
- `schedule=recurring` → filesystem watcher (inotify / ReadDirectoryChangesW)
- No `commit_sha` — `commit_sha = content_hash[:16]` in all lineage fields

---

#### Axis 3: Schedule → trigger routing

| Schedule | Trigger mechanism | Use case |
|----------|-----------------|---------|
| `once` | Manual CLI command or single API call | Initial import of a static snapshot; one-time domain data load |
| `recurring` | Webhook receiver (git push) or filesystem watcher | Live repos; platform repos that evolve with the system |
| `re-run` | Manual retry via API (`POST /repos/{repo_id}/reindex`) | Recovery after pipeline failure; forced refresh after extractor upgrade |

`re-run` on a repo with `content_hash` unchanged behaves as a `once` run with the
behavioral fingerprint gate active (Contract 13 §8) — it re-parses nothing if facts
are unchanged.

---

#### Axis interaction: `repo_role` + `content_type`

ADR-0017 repo roles apply at the repo level, not per file. Within a single repo, all
files share the same `repo_role`. The combination of role + content type determines
the enrichment authority:

| repo_role | content_type | Knowledge tier | Enrichment scope |
|-----------|-------------|---------------|-----------------|
| `platform` | `code` | Tier 1-code | Shared library facts available to all module queries |
| `platform` | `data` | Tier 1-domain | Domain field defs / API specs enriching all module queries |
| `platform` | `data-sql` | Tier 1-domain | DDL schemas enriching all module queries via `shared_artifacts` |
| `platform` | `docs` | Tier 3 | Platform-scoped documentation for all module doc searches |
| `platform` | `config` | Tier 1-domain | Shared config/service definitions |
| `module` | `code` | Tier 1-code | Module-scoped code facts |
| `module` | `data` | Tier 1-domain | Module-scoped domain data |
| `module` | `docs` | Tier 3 | Module-scoped documentation |

**The enrichment direction is always platform → module at query time (ADR-0017). A
module repo's content never enriches a platform repo.**

---

#### Onboard configuration example

```yaml
# billing-service module repo — code + docs
repo_id: billing-service
repo_role: module
content_type: code
source: git
schedule: recurring
branch: main

# shared DDL schemas — platform repo, data-sql type
repo_id: ddl-schemas
repo_role: platform
content_type: data-sql
source: git
schedule: recurring
branch: main

# system understanding docs — platform repo, docs type
repo_id: system-understanding
repo_role: platform
content_type: docs
source: local
schedule: once

# domain XML field definitions — platform repo, data type
repo_id: tuxedo-field-defs
repo_role: platform
content_type: data
source: local
schedule: recurring
```

---

### Alternatives Considered

| Alternative | Why Rejected |
|-------------|-------------|
| Single `onboard` command with auto-detection of content type | Auto-detection is unreliable for enterprise formats. Wrong detection sends DDL through CPG parser, failing the job and producing no facts. Explicit declaration is safer. |
| Per-file content type detection | Adds per-file overhead; a directory of 10,000 domain XMLs does not need 10,000 individual detection runs. The operator knows what the repo contains. |
| Separate onboard commands per content type (`onboard-code`, `onboard-docs`, etc.) | Pushes the three-axis model into the CLI surface rather than the configuration layer. Harder to script and automate. |
| Only support `git` source | Local directories are a real enterprise pattern for static snapshots, air-gapped environments, and legacy archive ingestion. Excluding local would block valid use cases. |

---

### Compliance

- ADR-0012: Multi-Level Language Detection — `code` content type hands off to ADR-0012 three-pass detection after initial axis routing
- ADR-0016: Tree-Sitter Extraction Depth — applies to `code` content type only
- ADR-0017: Platform-Module Repository Model — `repo_role` is set at onboard time; this ADR's axis model provides the onboard configuration surface for ADR-0017
- Contract 06 §8: Tiered Knowledge Authority — content_type routing enforces tier assignment; `data` and `data-sql` routing to Structured DB only enforces the "Tier 1-domain MUST NOT be embedded" rule
- Contract 09: Event Pipeline — onboard connector emits `file.discovered`; downstream workers are connector-agnostic
- Contract 13: Incremental Ingestion — all content types are subject to `content_hash` skip rules; `code` is additionally subject to the behavioral fingerprint gate
- Contract 15: DB Schema — `repositories` table carries `repo_role`; `documents` table carries `content_type`
