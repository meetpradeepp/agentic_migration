# ADR-0010: Three-Tier Deployment Model

**Status:** Accepted  
**Date:** 2026-05-05  
**Deciders:** Lead Engineer, Architecture Review  
**Supersedes:** —  
**Superseded by:** —  

---

### Context

ECLE 2.0 must serve three distinct operational contexts:

1. **A developer running locally** — one engineer, one machine, no infrastructure. Needs
   to be up and running in minutes with `pip install` + `python -m ecle`. No Docker
   required. SQLite files, ChromaDB local directory, no Redis, Celery runs in-process.

2. **A small team or proof-of-concept production deployment** — 2–5 engineers, one server
   or small VM. Needs process isolation, restartability, and basic ops. Docker Compose
   manages all services. No Kubernetes overhead.

3. **An enterprise deployment** — large codebase (1M+ LOC, 10+ repos), multiple tenants,
   high availability, air-gapped network. Kubernetes orchestrates workers. Managed
   PostgreSQL, managed Redis, Qdrant cluster, optional managed Neo4j. Workers scale
   horizontally by event queue lag.

The key architectural constraint: **the same codebase runs in all three tiers**. Tier
selection is a config/infrastructure decision — not a code branch. Engineers must never
write code that only works in one tier.

---

### Decision

We will define three named deployment tiers and mandate that all backend choices, config
paths, and process models map cleanly onto them via environment configuration alone.

---

### Tier 1 — Single-Machine Dev (`ECLE_TIER=dev`)

**Intended for:** Local development, demos, individual engineers.

| Component | Tier 1 choice |
|-----------|--------------|
| Structured DB | PostgreSQL (local install at `c:\utilities\postgresql`) |
| Vector Index | Qdrant (local install at `c:\utilities\qdrant`; `http://localhost:6333`) |
| Topology Graph | Neo4j (local install at `c:\utilities\neo4j`; `bolt://localhost:7687`) |
| Artifact Store | Local filesystem (`ecle-data/repos/{tenant}/{repo}/ir/`) |
| Runtime config | `ecle-data/config/ecle.yaml` + `logging.yaml` (ADR-0028) |
| Log output | `ecle-logs/` — per-service log files (ADR-0028) |
| Event broker | Kafka (KRaft, single broker) — local install at `c:\utilities\kafka`; `KAFKA_BOOTSTRAP_SERVERS=localhost:9092` |
| Workers | Native Kafka consumer processes (confluent-kafka-python); no Celery |
| Celery Beat | Retained for periodic tasks (nightly evals, staleness sweeps) |
| MCP server | HTTP transport (`localhost:8001`) — stdio banned per Contract 11 §7 |
| FastAPI | `uvicorn` single process, port 8000 |
| Redis | Not required |
| PostgreSQL | Not required |

**Setup:** `pip install ecle[dev]` → `ecle init` → `ecle start`  
**No Docker required.** All data in `ecle-data/`, all logs in `ecle-logs/` (ADR-0028).

---

### Tier 2 — Docker Compose (`ECLE_TIER=compose`)

**Intended for:** Small team, PoC production, single-server deployment.

| Component | Tier 2 choice |
|-----------|--------------|
| Structured DB | PostgreSQL (Docker service: `ecle-postgres`) |
| Vector Index | ChromaDB (Docker service: `ecle-chroma`, persisted volume) |
| Topology Graph | PostgreSQL recursive CTEs (same DB as Structured DB) |
| Artifact Store | Docker named volume (`ecle-artifacts`), mounted to all workers |
| Event broker | Kafka (KRaft mode, single broker) — Docker service: `ecle-kafka` (`confluentinc/cp-kafka:7.7`) |
| Workers | Native Kafka consumer processes (Docker services); one container per worker type |
| Celery Beat | Docker service: `ecle-celery-beat` (periodic tasks only) |
| MCP server | SSE/HTTP transport, port 8001 |
| FastAPI | `uvicorn` with 2 workers, port 8000 |
| Redis | Not required |

**Setup:** `docker compose up -d`  
`docker-compose.yml` ships with the repo. One command, all services.  
Workers are separate containers: one per Celery worker type.

**Services in `docker-compose.yml`:**
```
ecle-api          FastAPI app
ecle-mcp          MCP server (SSE)
ecle-postgres     PostgreSQL 16
ecle-kafka        Kafka 3.7+ (KRaft, single broker, no ZooKeeper)
ecle-chroma       ChromaDB
ecle-celery-beat  Celery Beat (periodic tasks only)
ecle-worker-scan-source
ecle-worker-parse-repo
ecle-worker-persist-facts
ecle-worker-build-graph
ecle-worker-chunk-file
ecle-worker-batch-embed
ecle-worker-compute-topology
```

---

### Tier 3 — Kubernetes Enterprise (`ECLE_TIER=enterprise`)

**Intended for:** Large enterprise, multi-tenant, air-gapped, high availability.

| Component | Tier 3 choice |
|-----------|--------------|
| Structured DB | Managed PostgreSQL (AWS RDS / Azure Database / on-prem HA Postgres) |
| Vector Index | Qdrant cluster (3+ nodes) |
| Topology Graph | PostgreSQL recursive CTEs or managed Neo4j Aura |
| Artifact Store | S3 / Azure Blob Storage / NFS (pluggable via `IArtifactStore`) |
| Event broker | Kafka cluster (3+ brokers, KRaft) or managed: Confluent Cloud / AWS MSK / Azure Event Hubs (Kafka protocol) |
| Connection pool | **`pgbouncer` (mandatory, transaction mode)** in front of PostgreSQL — see connection pool sizing below |
| Celery Beat | Kubernetes CronJob (periodic tasks only) |
| Workers | Native Kafka consumer processes (Kubernetes Deployments); scaled by consumer group lag via KEDA |
| MCP server | SSE/HTTP, Kubernetes Service, TLS termination at ingress |
| FastAPI | Kubernetes Deployment, 2+ replicas, HPA |
| Redis | Managed Redis (ElastiCache / Azure Cache) |

**Setup:** Helm chart (Phase 4).  
Each worker type is a Kubernetes `Deployment`. HPA scales worker replicas based on
unprocessed event count from the PostgreSQL events table (custom metric via KEDA).

**Kubernetes resource model:**
```
Deployments:   ecle-api, ecle-mcp, ecle-worker-{name} (one per worker type)
               ecle-pgbouncer  ← mandatory at Tier 3
Services:      ecle-api-svc, ecle-mcp-svc, ecle-pgbouncer-svc
ConfigMaps:    ecle-config (non-secret config)
Secrets:       ecle-secrets (DB DSN, Kafka bootstrap servers, S3 credentials)
PersistentVolumeClaims: ecle-artifacts (only if NFS; S3/Azure uses no PVC)
ScaledObjects: ecle-worker-parse-repo (KEDA: scale 1–20 on Kafka consumer group lag)
               ecle-worker-persist-facts (KEDA: scale 1–10)
               ecle-worker-batch-embed (KEDA: scale 1–8, GPU node pool preferred)
```

**pgbouncer connection pool sizing (Tier 3):**

With 10 worker types × up to 10 replicas each × 2 connections per replica = up to 200 application-side connections. PostgreSQL `max_connections` default is 100. Without a connection pool, workers fail to connect under load.

| Parameter | Value | Rationale |
|---|---|---|
| `pool_mode` | `transaction` | Workers hold connections only during SQL execution, not between Kafka polls |
| `max_client_conn` | `500` | Upper bound including MCP + FastAPI + all workers |
| `default_pool_size` | `20` | Server-side connections to PostgreSQL |
| `DB_POOL_MIN_SIZE` | `2` | Per-worker sqlalchemy pool minimum |
| `DB_POOL_MAX_SIZE` | `5` | Per-worker sqlalchemy pool maximum; multiply by replicas to get pgbouncer load |

`DATABASE_URL` for all workers and API must point to pgbouncer (`ecle-pgbouncer-svc:5432`), never directly to PostgreSQL. Workers MUST NOT use `AUTOCOMMIT` mode with pgbouncer transaction pooling.

---

### Cross-tier constraints (apply to all tiers)

These are enforced by `constitution/contracts/14-deployment-contract.md`:

1. **Config drives tier selection** — `ECLE_TIER` + backend env vars. No code branches.
2. **Same DB schema in all tiers** — SQLite and PostgreSQL share the same DDL (SQLite
   uses `IF NOT EXISTS`; PostgreSQL uses Alembic migrations from Phase 2).
3. **Artifact store is pluggable** — `IArtifactStore` interface. Workers never call
   `open()` directly; always go through the interface.
4. **Workers are stateless** — no instance-level state between task invocations. Safe
   to scale to N replicas in Tier 3 without coordination.
5. **MCP server is stateless** — each tool call is independent. Safe to run multiple
   replicas behind a load balancer.

---

### Consequences

**Positive:**

- A developer can start contributing in minutes — no Docker, no infrastructure setup
- The same code is tested in CI using Tier 2 (Docker Compose) — no "works on my machine"
- Tier 3 is an ops configuration change, not a code change — no re-testing required
- Horizontal worker scaling in Tier 3 is free — workers are already stateless by SRP design

**Negative / Trade-offs:**

- `IArtifactStore` interface must be implemented before Phase 2 (Tier 2 uses a volume;
  Tier 3 uses S3/Azure — the code must not hardcode `open()`)
- Local Kafka at `c:\utilities\kafka` must be started before running ECLE in dev — documented in `README.md`; one command
- Helm chart (Tier 3) deferred to Phase 4 — Tier 3 is manual K8s YAML until then

**Neutral / Operational notes:**

- `ECLE_TIER` is informational — the actual behaviour is driven by `STRUCTURED_BACKEND`,
  `VECTOR_BACKEND`, `ARTIFACT_BACKEND`, `KAFKA_BOOTSTRAP_SERVERS` etc. Setting
  `ECLE_TIER=dev` auto-populates sensible defaults for all of these.
- Tier 2 `docker-compose.yml` ships in the repo root and is maintained as production code.
- Tier 3 Helm chart ships in `deploy/helm/` from Phase 4.

---

### Alternatives Considered

| Alternative | Why Rejected |
|-------------|-------------|
| Single Docker Compose for all tiers | Dev experience is poor — engineers shouldn't need Docker to run tests |
| Tier-specific code branches (`if TIER == "enterprise"`) | Code forks; impossible to test all tiers in CI; violates Open/Closed principle |
| Kubernetes-only (no Docker Compose tier) | Prohibitively complex for small teams and PoC deployments |
| Serverless functions for workers | Cold start latency incompatible with event pipeline; Kafka consumer model fits workers better |

---

### Compliance

- Contract: `constitution/contracts/14-deployment-contract.md` — coding rules derived from this ADR
- Contract: `constitution/contracts/01-coding-standards.md` — no hardcoded paths, no direct `open()` calls
- SPEC-0001: Backend interfaces (factory functions) — the mechanism that makes tier-switching possible
- ADR-0007: Artifact Store — `IArtifactStore` interface required by Tier 2/3
- ADR-0003: Three-Backend Architecture — backend swap is the mechanism for tier promotion
