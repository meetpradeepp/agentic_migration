# ADR-0024: Feedback Loop and Learning Analyzer

**Status:** Accepted
**Date:** 2026-05-07
**Deciders:** Lead Engineer, Architecture Review
**Supersedes:** —
**Superseded by:** —
**Amends:** Contract 05 (confidence contract — defines the voting formula; learning_analyzer now has a complete implementation path)
**FACT impact:**
- Fast: `neutral` — feedback processing is async (Kafka consumer); no query-path latency impact
- Accurate: `improves` — `behavioral_accuracy` dimension converges toward actual usefulness over time; developer signal corrects extraction quality gaps that structural metrics cannot detect
- Complete: `neutral` — feedback does not add missing facts; it adjusts confidence weights on existing facts
- Trustworthy: `improves` — confidence adjustments are traceable to explicit developer signals (`CONFIRM`/`DENY`), not to opaque decay timers; audit trail of votes is queryable

---

### Context

Contract 05 §3 defines a confidence voting formula and two vote types (`CONFIRM` / `DENY`). Contract 09 lists a `feedback.given` event consumed by `learning_analyzer`. However, there is no:

- Definition of what `learning_analyzer` does
- Feedback API or MCP tool for submitting signals
- Persistence model for vote counts (needed to compute `sqrt(total_votes)` in the formula)
- Rule for when adjusted confidence propagates to query results
- Prevention of feedback gaming (a single user flooding `CONFIRM` votes)

Without this, ECLE is a "continuously indexing engine" but not a "continuously learning engine" — a gap between the product vision and the implementation.

**Signal types and their meaning:**

| Signal | Trigger | Meaning |
|--------|---------|---------|
| `CONFIRM` | Developer accepts a recommendation, uses a suggested function, code passes review, result was helpful | ECLE's `behavioral_accuracy` assessment was correct or better than actual state |
| `DENY` | Developer rejects a recommendation, reverts code based on ECLE suggestion, reports wrong result | ECLE's `behavioral_accuracy` was wrong; result was misleading |
| `BOOKMARK` | Developer explicitly saves a result for later use | Positive signal, weaker than `CONFIRM`; does not affect `behavioral_accuracy` but feeds future result ranking |

---

### Decision

We will implement the learning loop as a dedicated Kafka consumer worker (`learning_analyzer`) and a lightweight feedback API endpoint, with vote persistence in a `confidence_votes` table.

#### 1. Feedback submission — `ecle_feedback` MCP tool (Phase 3)

```json
POST /mcp
{
  "method": "tools/call",
  "params": {
    "name": "ecle_feedback",
    "arguments": {
      "entity_id":   "uuid",          // file_facts.id or function_facts.id
      "signal":      "CONFIRM | DENY | BOOKMARK",
      "query_id":    "uuid",          // X-Request-Id of the response being rated
      "session_id":  "uuid",          // optional; groups a conversation turn
      "comment":     "string"         // optional; human-readable reason
    }
  }
}
```

`ecle_feedback` is a **write tool** — the only MCP tool that mutates state. It emits a `feedback.given` event to Kafka. It returns immediately (202 pattern: `{ "status": "accepted", "feedback_id": "uuid" }`). It does NOT block waiting for the confidence update to propagate.

**Validation:**
- `entity_id` must exist in `file_facts` or `function_facts`
- `signal` must be one of the three defined values
- `query_id` must exist in `query_audit_log` (ties feedback to an audited response)
- Rate limit: max 10 `CONFIRM`/`DENY` signals per `(subject, entity_id)` per 24-hour window — prevents gaming

#### 2. `feedback.given` event payload

```json
{
  "event_type": "feedback.given",
  "entity_id":  "uuid",
  "entity_type": "file | function",
  "signal":     "CONFIRM | DENY | BOOKMARK",
  "query_id":   "uuid",
  "subject":    "user@corp.com",    // from auth context (ADR-0019)
  "session_id": "uuid",
  "tenant_id":  "acme",
  "given_at":   "2026-05-07T10:00:00Z"
}
```

#### 3. `learning_analyzer` worker

**SRP:** Consume `feedback.given` events → update `confidence_votes` table → recompute `behavioral_accuracy` for the entity.

```
feedback.given event
        │
        ├── Look up existing votes for (tenant_id, entity_id) in confidence_votes
        │
        ├── Check rate limit: subject has < FEEDBACK_RATE_LIMIT_PER_DAY votes
        │     for this entity today → reject with DENY_VOTE logged (not retried)
        │
        ├── Upsert confidence_votes row:
        │     confirm_count += (signal == CONFIRM ? 1 : 0)
        │     deny_count    += (signal == DENY ? 1 : 0)
        │     bookmark_count += (signal == BOOKMARK ? 1 : 0)
        │     total_votes   += 1
        │     last_vote_at  = NOW()
        │
        ├── Compute new behavioral_accuracy:
        │     vote_delta = (+CONFIRM_WEIGHT if CONFIRM else -DENY_WEIGHT if DENY else 0)
        │     raw = current_behavioral_accuracy + (vote_delta / sqrt(total_votes))
        │     new_accuracy = clamp(raw, fidelity_floor, confidence_ceiling)
        │
        ├── Update file_facts.behavioral_accuracy (or function_facts)
        │     WHERE id = entity_id AND is_current = true
        │
        └── Emit confidence.updated { entity_id, old_accuracy, new_accuracy, reason: "vote" }
```

**Constants:**

| Constant | Default | Meaning |
|----------|---------|---------|
| `CONFIRM_WEIGHT` | `0.05` | Max per-vote increment (at 1 total vote; diminishes with sqrt) |
| `DENY_WEIGHT` | `0.08` | Deny is weighted higher — a developer rejecting a result is stronger signal than accepting |
| `FEEDBACK_RATE_LIMIT_PER_DAY` | `10` | Max CONFIRM/DENY votes per (subject, entity_id) per 24h |
| `FEEDBACK_MIN_VOTES_TO_PERSIST` | `3` | Confidence update only written to `file_facts` after ≥ 3 total votes — prevents single-vote noise |

**Floor rule:** `behavioral_accuracy` MUST NOT drop below the fidelity ceiling floor. A HEURISTIC file (ceiling=0.6) has a floor of `0.5 × 0.6 = 0.3` (not 0.0). Formula:
```
floor = fidelity_ceiling × BEHAVIORAL_ACCURACY_FLOOR_RATIO  (default: 0.5)
```

#### 4. `confidence_votes` table (new)

```sql
CREATE TABLE confidence_votes (
  id              UUID PRIMARY KEY,
  tenant_id       VARCHAR NOT NULL,
  entity_id       UUID NOT NULL,          -- file_facts.id or function_facts.id
  entity_type     VARCHAR NOT NULL,       -- 'file' | 'function'
  confirm_count   INT NOT NULL DEFAULT 0,
  deny_count      INT NOT NULL DEFAULT 0,
  bookmark_count  INT NOT NULL DEFAULT 0,
  total_votes     INT NOT NULL DEFAULT 0,
  last_vote_at    TIMESTAMP,
  UNIQUE (tenant_id, entity_id)
);
```

This table persists across re-indexing. When a file is re-indexed (`content_hash` changes), votes are **not reset** — the human signal remains valid until the file's behavior changes significantly. If `version_distance > BEHAVIORAL_CHANGE_THRESHOLD` (Contract 13 §8) on re-index, votes ARE reset (behavioral change invalidates prior developer assessments).

#### 5. Vote reset on behavioral change

```
Re-index event for entity_id:
    │
    ├── version_distance > BEHAVIORAL_CHANGE_THRESHOLD (0.10)?
    │     YES → Reset confidence_votes: confirm_count=0, deny_count=0, total_votes=0
    │           Set behavioral_accuracy = fidelity_ceiling (back to extraction default)
    │           Emit confidence.reset { entity_id, reason: "behavioral_change" }
    │
    └── version_distance ≤ threshold?
          → Votes carry over. behavioral_accuracy unchanged by re-index.
```

This is the correct model: human signal about "does this function do what ECLE says it does?" is invalidated when the function's behavior changes, but not when it's cosmetically reformatted.

#### 6. Confidence update propagation

Updated `behavioral_accuracy` values are live on the **next query** — no cache invalidation needed because queries always read from `file_facts` with `is_current=true`. The update is durable (DB write) before the `confidence.updated` event is emitted.

**No query-path blocking.** The learning loop is entirely async. A developer clicking "thumbs up" on a result does not delay the next query.

---

### Consequences

**Positive:**
- Closes the "continuous learning" gap — ECLE now improves as developers use it
- Vote persistence across re-indexes means accumulated signal is not lost on every commit
- `CONFIRM`/`DENY` asymmetry (deny weight > confirm weight) reflects the asymmetry of developer intent — rejecting a bad result is more informative than accepting a good one
- Vote floor prevents confidence collapse on over-voted entities

**Negative / Trade-offs:**
- `FEEDBACK_MIN_VOTES_TO_PERSIST=3` means a single developer's feedback has no visible effect on a fresh entity — intentional, but may feel unresponsive in small teams. Set to 1 in dev tier if desired.
- `ecle_feedback` is a write tool — the only one in the MCP catalogue. Requires `query` scope (same as all tools); no separate write scope needed since the write is bounded to entities the caller has already queried.
- Feedback gaming is rate-limited but not fully prevented — a tenant admin could provision many subjects and flood votes. Mitigation: `FEEDBACK_RATE_LIMIT_PER_DAY` is the first line; statistical outlier detection in `learning_analyzer` is a Phase 4 enhancement.

**Neutral / Operational notes:**
- `confidence.updated` events are low-volume (one per feedback event that crosses the `FEEDBACK_MIN_VOTES_TO_PERSIST` threshold) — no partition count concerns.
- Feedback does not affect `syntactic_freshness`, `contextual_accuracy`, `edge_coherence`, `cluster_alignment`, or `semantic_accuracy` — only `behavioral_accuracy`.
- `BOOKMARK` signal feeds a future `ecle_related` tool (suggested: Phase 4) that surfaces results frequently bookmarked by a team; it does not affect confidence dimensions.

---

### Alternatives Considered

| Alternative | Why Rejected |
|-------------|-------------|
| Implicit feedback (click tracking, time-on-result) | Requires browser/client instrumentation; signals are noisy; not feasible for API-first callers |
| LLM-based quality scoring of results | Violates no-LLM-at-any-layer rule; adds latency; not deterministic |
| Decay-based confidence adjustment (time-based) | Contract 05 explicitly bans this — stable code earns stable confidence; time is not evidence of wrongness |
| Per-session feedback (not persisted) | Not useful for learning; feedback must accumulate across sessions to have statistical power |

---

### Compliance

- Contract: `constitution/contracts/05-confidence-contract.md` §3 — voting formula; floor rule
- Contract: `constitution/contracts/09-event-pipeline-contract.md` — `learning_analyzer` added to SRP worker table; `feedback.given` event in catalogue
- Contract: `constitution/contracts/11-mcp-contract.md` — `ecle_feedback` added to tool catalogue (Phase 3)
- Contract: `constitution/contracts/15-db-schema-contract.md` — `confidence_votes` table
- ADR: `ADR-0019` — rate limit enforcement; `subject` from auth context tied to feedback

---

### References

| # | Citation | Relevance to this ADR |
|---|----------|----------------------|
| R1 | Rocchio, J. "Relevance Feedback in Information Retrieval", 1971 (in Salton, "The SMART Retrieval System") | Foundational relevance feedback algorithm; CONFIRM/DENY signals are the binary variant of Rocchio's explicit feedback |
| R2 | Wilson, E.B. "Probable Inference, the Law of Succession, and Statistical Inference", JASA 1927 | Wilson score interval for binomial proportion confidence — basis for diminishing-returns voting formulas used in Stack Overflow, Reddit, IMDb |
| R3 | Christakopoulou, K. et al. "Towards Conversational Recommender Systems", KDD 2016 | Interactive feedback loops in recommendation systems; validates async feedback collection without blocking query path |
| R4 | Ouyang, L. et al. "Training language models to follow instructions with human feedback", NeurIPS 2022 (arXiv:2203.02155) | RLHF signal collection methodology; ECLE applies the same CONFIRM/DENY signal structure deterministically, not via RL |
