# ADR-0018: Intent-Driven Flow Registry

**Status:** Accepted
**Date:** 2026-05-07
**Deciders:** Lead Engineer, Architecture Review
**Supersedes:** —
**Superseded by:** —
**Amends:** —
**Amended by:** —
**FACT impact:**
- Fast: `improves` — flow selection is a single dict lookup (~0.1 ms); per-step timeouts prevent any one step from consuming the full budget; optional steps degrade gracefully rather than blocking; progress tokens give LLM callers real-time step visibility without polling
- Accurate: `improves` — enrich step aligns raw query tokens to stored domain vocabulary before ANN search; flows composed for specific intent+context combinations produce better-matched result sets than a single generic query path
- Complete: `improves` — `suggested_next` block in FACT envelope carries forward anchors between turns; LLM caller always knows what to call next and with what context; `enrich_carry` eliminates repeated vocabulary lookups across turns
- Trustworthy: `improves` — `flow_id` and `step_ms[]` in FACT envelope make execution path fully visible and auditable; flow JSON is operator-visible configuration, not hidden code logic; `reason_code` in `suggested_next` is deterministic and traceable

---

### Context

Two problems emerged from ECLE 1.0 production MCP usage:

**Problem 1 — Cold-start vocabulary mismatch.** LLM agents arrive at ECLE not knowing the
codebase vocabulary. The caller intent protocol (Contract 11 §11) requires the agent to pass
`query_intent` and `known_anchors` — but on the first turn neither is known. Raw natural language
queries miss because they do not match the domain concepts stored by `ontology_enricher`
(cluster labels, DSL patterns, canonical module names). Result quality on turn 1 is poor.

**Problem 2 — Permission fatigue.** MCP clients (VS Code Copilot, Claude Desktop) prompt for
user approval on every tool call. A natural enrich → search → refine flow = 3 approval
dialogs for one user question. Users click through without reading or abandon the session.

**Rejected solutions:**

| Approach | Why rejected |
|---|---|
| LLM-based query rewriting | Violates no-LLM-at-any-layer rule; non-deterministic; adds latency; generates text ECLE cannot ground |
| Hardcoded multi-step tool functions | Routing logic embedded in code; no operator tuning without code changes; combinatorial explosion as flows grow |
| Session state between tool calls | Violates Contract 11 §1 Rule 4 (stateless); horizontal scaling breaks |
| Single giant compound tool | Loses FACT traceability; `query_plan` becomes opaque |

**Correct solution:** A **JSON-driven flow registry** that separates intent routing (data) from step
execution (code), combined with a `StepRegistry` that binds step type names to executor
functions via a static dict. Each MCP tool remains stateless; multi-step execution is
internal to a single tool call.

---

### Decision

We will introduce three new components:

1. **Flow Registry** (`src/ecle/mcp/flows/flow_registry.json`) — data file listing all flows
2. **FlowSelector** (`src/ecle/mcp/flow_selector.py`) — picks a flow from registry by scoring
3. **FlowExecutor** (`src/ecle/mcp/flow_executor.py`) — runs steps in order, manages `carry`
4. **StepRegistry** (`src/ecle/mcp/step_registry.py`) — static dict: step name → executor fn
5. **Step implementations** (`src/ecle/mcp/steps/*.py`) — one module, one `run()` function each

These sit **below** MCP tools (public surface) and **above** backends (IStructuredDB etc.).
MCP tools call FlowSelector + FlowExecutor. Steps call backends via injected interfaces.

---

### Architecture

```
MCP Tool (ecle_search, ecle_enrich, ...)
         │  selects flow via FlowSelector
         ▼
Flow Registry (flow_registry.json)
  15 flows × { steps[], timeouts, selection_conditions }
         │  resolves step names via StepRegistry
         ▼
Step Registry (static dict: name → async fn)
  "enrich"             → enrich.run
  "layer1_ann"         → layer1_ann.run
  "layer2_ann"         → layer2_ann.run
  "layer3_ann"         → layer3_ann.run
  "cross_repo_ann"     → cross_repo_ann.run
  "muvera_rerank"      → muvera_rerank.run
  "structured_hydrate" → structured_hydrate.run
  "structured_filter"  → structured_filter.run
  "cross_repo_lookup"  → cross_repo_lookup.run
  "graph_traverse"     → graph_traverse.run
         │  each step receives StepContext
         ▼
Backends
  IStructuredDB / IVectorStore / ITopologyGraph
```

Steps communicate **only** via `carry` — a dict accumulated across steps in the current
request. Steps never call other steps. Steps never call MCP tools.

---

### Flow Registry Schema

Each flow entry:

```json
{
  "flow_id": "locate_function_rerank",
  "selects_when": {
    "query_intent":  "locate",
    "entity_type":   "function"
  },
  "steps": [
    { "step": "enrich",              "optional": true,  "timeout_ms": 150,
      "params": { "ann_top_k": 5, "weight_overlap": 0.6, "weight_ann": 0.4 } },
    { "step": "layer2_ann",          "optional": false, "timeout_ms": 300,
      "params": { "top_k": 50 } },
    { "step": "muvera_rerank",       "optional": true,  "timeout_ms": 200,
      "params": { "top_k": 10 } },
    { "step": "structured_hydrate",  "optional": false, "timeout_ms": 100,
      "params": {} }
  ],
  "total_timeout_ms": 800,
  "ships_phase": 2
}
```

**Field rules:**

| Field | Operator-tunable | Constraint |
|---|---|---|
| `top_k` per step | ✅ Yes | Min 1, max 200 |
| `timeout_ms` per step | ✅ Yes | Sum of all steps ≤ `total_timeout_ms` |
| `total_timeout_ms` | ✅ Yes | Hard cap: 1900 ms (100 ms reserved for envelope + HTTP) |
| `optional` | ✅ Yes | |
| `step` name | ❌ No | Must exist in StepRegistry; unknown name = startup error |
| `ships_phase` | ❌ No | Set by tool author; immutable once filed |
| `flow_id` | ❌ No | Unique across registry |

---

### Flow Selection Algorithm

FlowSelector scores every flow against the current request context. Selection is
**deterministic** — no LLM, no probabilistic inference.

```
score = Σ matched selects_when fields
      + 10  if entity_type matches  (specificity bonus)
      + 5   if repo_role matches
      + 3   if cross_repo matches

Highest score wins. Tie → fallback flow for that intent family.
```

**Mandatory fallback flows** (always match — one per intent family):

| Flow ID | Selects when |
|---|---|
| `explore_fallback` | `query_intent = "explore"` — minimum viable explore path |
| `locate_fallback` | `query_intent = "locate"` — minimum viable locate path |
| `precise_fallback` | `query_intent = "precise"` — minimum viable precise path |
| `enrich_only` | `tool = "ecle_enrich"` — standalone enrich entry point |

A request that matches no scored flow must match a fallback. If no fallback matches,
that is a startup validation error (missing fallback for an intent family).

---

### Canonical Flow Catalogue (Phase assignment per flow)

| Flow ID | Primary conditions | Ships phase |
|---|---|---|
| `explore_single_repo` | explore, cross_repo=false | 1 |
| `explore_cross_repo` | explore, cross_repo=true | 2 |
| `explore_doc_heavy` | explore, content_type=docs | 2 |
| `explore_cold_start` | explore, enrichment_confidence<0.3 | 2 |
| `locate_function_rerank` | locate, entity_type=function | 2 |
| `locate_function_structured` | locate, entity_type=function, rerank=false | 1 |
| `locate_table` | locate, entity_type=table | 1 |
| `locate_file` | locate, entity_type=file | 1 |
| `locate_cross_repo` | locate, cross_repo=true | 2 |
| `precise_structured` | precise | 1 |
| `precise_graph` | precise, graph_traversal=true | 3 |
| `impact_analysis` | tool=ecle_impact | 3 |
| `enrich_only` | tool=ecle_enrich | 2 |
| `explore_fallback` | explore (catch-all) | 1 |
| `locate_fallback` | locate (catch-all) | 1 |

---

### StepContext and StepResult interfaces

```python
# src/ecle/mcp/steps/base.py

@dataclass
class StepContext:
    query:      str
    repo_id:    str
    tenant_id:  str
    params:     dict          # values from flow JSON step.params
    carry:      dict          # keyed output from all prior steps this request
    db:         IStructuredDB
    vector:     IVectorStore
    graph:      ITopologyGraph

@dataclass
class StepResult:
    data:     Any
    step_ms:  int
    skipped:  bool = False    # True when optional step produced no result
    notes:    list[str] = None  # appended to query_plan in FACT envelope
```

**`carry` access pattern** — steps read prior output by step name:

```python
enrich_out   = ctx.carry.get("enrich")          # None if step was skipped/absent
layer2_ids   = ctx.carry.get("layer2_ann", {}).get("ids", [])
```

This means steps are **order-independent within their slot** — they never assume a specific
prior step ran; they check `carry` and degrade gracefully if it is absent.

---

### enrich Step — Execution Detail

The `enrich` step is the vocabulary alignment primitive. It reads stored domain knowledge
and returns structured metadata only — it never generates or rewrites query text.

**Four passes:**

| Pass | Mechanism | Backend | Phase |
|---|---|---|---|
| 1 | Token extraction (stop-word removal) | In-process | 1 |
| 2 | Exact/prefix SQL match on `function_facts`, `file_tables` | IStructuredDB | 1 |
| 3 | Concept stem overlap against `cluster_assignments.concept_stems[]` | IStructuredDB | 1 |
| 4 | Layer 3 ANN on `cross_repo__capabilities` collection | IVectorStore | 2 |

Pass 4 is guarded by `ctx.vector.is_available()` — degrades cleanly to Pass 1–3 in Phase 1.

**Output** (structured metadata only — never generated text):

```json
{
  "matched_concepts":       ["billing-cycle", "retry-policy"],
  "candidate_clusters":     ["a3f1b2c4d5e6f7a8"],
  "candidate_anchors": {
    "function_name":  "retry",
    "module_hint":    "billing",
    "entity_type":    "function"
  },
  "suggested_intent":       "locate",
  "enrichment_confidence":  0.87,
  "enrichment_sources":     ["concept_overlap", "function_exact", "layer3_ann"]
}
```

`suggested_intent` is derived from **deterministic rules** — never LLM inference:

| Condition | `suggested_intent` |
|---|---|
| Exact function name matches found | `"locate"` |
| Table matches only, no function matches | `"locate"` |
| Only concept matches (no specific identifiers) | `"explore"` |

---

### Startup Validation

`validate_flow_registry()` runs once at server start — **never at query time**.

Checks performed:
1. Every `step` name in every flow exists in `STEP_REGISTRY` → `StartupError` if not
2. Every flow's step `timeout_ms` sum ≤ `total_timeout_ms` → `StartupError` if not
3. Every flow's `total_timeout_ms` ≤ 1900 → `StartupError` if not
4. One fallback flow exists per intent family → `StartupError` if missing
5. All `flow_id` values are unique → `StartupError` if duplicate

A server that fails startup validation does not start. Operator must fix the flow JSON
before the process can accept requests.

---

### LLM Caller Update Mechanisms

Two mechanisms keep the calling LLM informed across turns:

#### 1 — MCP Progress Notifications (within a turn)

When `_meta.progressToken` is present in the JSON-RPC request, the server emits
`notifications/progress` events on the held-open HTTP connection after each step completes:

```
notifications/progress {
  "progressToken": "req-uuid-001",
  "progress": 2,
  "total": 4,
  "message": "layer2_ann: 50 candidates found"    ← from StepResult.notes[0]
}
```

Progress message text comes from `StepResult.notes[]`. No generated text — notes are
produced by step executors from structured data (counts, IDs, scores).

#### Cross-repo sweep flows — `repo_scope[]` and `MAX_CROSS_REPO_REPOS`

Flows with a `cross_repo_sweep` step MUST include `repo_scope` as a step param:

```json
{ "step": "cross_repo_ann", "params": {
    "repo_scope":            [],
    "max_repos_if_unscoped": 50
}}
```

If the caller provides `repo_scope[]`, the ANN is filtered to those repos only.
If absent, the step caps fan-out at `max_repos_if_unscoped` (per ADR-0017 Mitigation 1).
A flow that fans out to all repos without this guard is a **startup validation error**.

At Phase 2+ when `cross_repo_summary` is available, the `cross_repo_ann` step
automatically uses the two-stage ANN (repo-level summary → scoped cluster ANN)
without any flow JSON change — the step executor detects the table's presence.

#### `layer2_ann` step — `repo_id` filter is always mandatory

The `layer2_ann` executor MUST always apply a `repo_id` filter, regardless of whether
the `enrich` step ran:

```python
# carry may or may not have enrich output
enrich_out  = ctx.carry.get("enrich")
cluster_ids = enrich_out["candidate_clusters"] if enrich_out else None

results = await ctx.vector.search(
    collection = f"{ctx.tenant_id}__{ctx.repo_id}__layer2",
    vector     = ctx.vector.embed(ctx.query),
    top_k      = ctx.params["top_k"],
    filter     = {
        "repo_id":    ctx.repo_id,          # ← ALWAYS present
        "cluster_id": {"$in": cluster_ids}  # ← added if enrich ran
    }
)
```

`ctx.repo_id` is always available from the tool call input — this filter costs nothing
and prevents full-collection scans when enrich is skipped or timed out.

#### `cross_repo_lookup` step — always batch

The `cross_repo_lookup` executor MUST issue a single batched query per enrichment
table, never N sequential round-trips (ADR-0017 Mitigation 2):

```python
rows = await ctx.db.query("""
    SELECT * FROM shared_artifacts
    WHERE tenant_id = :tenant_id
      AND repo_id   = ANY(:repo_ids)
      AND is_current = TRUE
""", {"tenant_id": ctx.tenant_id, "repo_ids": matched_repo_ids})
```

Same pattern for `service_call_index` and `field_extractions`. Three queries total,
not 3 × N.

---

#### 2 — FACT Envelope Carry-Forward (between turns)

The FACT envelope `fast` block carries three fields forward to the next turn:

**`enrich_carry`** — output of the enrich step, ready to pass as `known_anchors` on the
next call. LLM agent does not need to run enrich again.

**`suggested_next`** — deterministic recommendation for the next tool call:

```json
"suggested_next": {
  "tool":          "ecle_impact",
  "query_intent":  "precise",
  "known_anchors": {
    "function_name": "PaymentRetryService.retry",
    "file_path":     "billing/retry.py"
  },
  "reason_code": "top_result_is_entry_point"
}
```

`reason_code` rules (deterministic — no LLM):

| Condition | `reason_code` | Suggested tool |
|---|---|---|
| Top result `execution_model = 'entry_point'` | `top_result_is_entry_point` | `ecle_impact` |
| `enrichment_confidence < 0.5` | `low_enrichment_confidence` | `ecle_enrich` |
| `coverage_warnings` non-empty | `incomplete_index` | `ecle_repo_summary` |
| `fast.timed_out = true` | `partial_results` | repeat with narrower anchors |
| `total_hits > 50` | `results_too_broad` | `ecle_find_functions` with anchor |
| None of the above | `null` | `null` |

`suggested_next` is a **hint only** — the calling LLM decides whether to follow it.
It is never a command and never blocks the current response.

**`step_ms[]`** — per-step timing array. Lets the calling agent and operators correlate
slow turns to specific steps without re-running the query.

---

### Overhead Analysis

| Source | Cost | Notes |
|---|---|---|
| Flow selection | ~0.1 ms | Dict lookup + score over 15 entries |
| `carry` merging between steps | ~0.01 ms/step | Dict assignment |
| `asyncio.wait_for` per step | ~0.1 ms/step | Python coroutine scheduling |
| Startup validation | 0 ms at query time | Runs once at server start |
| **Total framework overhead** | **< 1 ms per request** | |

Step backend costs are identical to the current direct-call approach — same backends,
same queries. The flow registry adds no measurable latency.

**Worst-case flow budget** (`locate_function_rerank`, CPU Muvera):

| Step | Cost |
|---|---|
| enrich (4 passes) | ~16 ms |
| layer2_ann (cluster-scoped) | ~50 ms |
| muvera_rerank (50 candidates, CPU) | ~160 ms |
| structured_hydrate (10 IDs) | ~5 ms |
| Framework overhead | ~1 ms |
| FACT envelope assembly | ~5 ms |
| **Total** | **~237 ms** — 3× headroom to 2s limit |

---

### Consequences

**Positive:**
- Routing logic is visible JSON configuration, not hidden code — operators can read and tune flows without a code release
- A/B testing: duplicate a flow with a new `flow_id`, adjust parameters, route traffic via feature flag; `flow_id` in FACT envelope correlates to quality metrics
- Each step is one small file, one function, one responsibility — easy to test in isolation
- `carry` is the only inter-step communication channel — no hidden shared state
- LLM callers get structured progress and carry-forward context; no polling required

**Negative / Trade-offs:**
- Flow JSON must be validated at startup — a bad file prevents server start (acceptable: fail-fast is safer than runtime failure)
- Adding a new step type requires a PR (code + step module) before the flow JSON can reference it — cannot add new capability via JSON alone
- `suggested_next` rules table must be maintained as new tools ship — stale rules produce unhelpful suggestions

**Neutral:**
- `ships_phase` on flows mirrors `ships_phase` on tools — only flows for Phase 1 tools are active Phase 1; later flows load at startup but their steps return `skipped=True` until backends are wired
- Flow JSON lives in `src/` not `constitution/` — it is implementation, not contract. Only the schema and validation rules are constitutionally mandated here

---

### Alternatives Considered

| Alternative | Why Rejected |
|---|---|
| Hardcoded multi-step if/elif routing | Routing logic hidden in code; no operator tuning; grows into unmaintainable branching |
| Tool-calls-tool (MCP tool calls another MCP tool) | Breaks FACT lineage — only outer tool visible to caller; breaks stateless contract |
| LLM-based flow selection | Non-deterministic; adds latency; violates no-LLM rule; heuristic scoring is sufficient |
| Session state across calls | Violates Contract 11 §1 Rule 4; breaks horizontal scaling |
| Single compound tool per intent | Cannot tune without code change; `query_plan` becomes opaque |

---

### Compliance

- Contract 11 §1 Rule 4 — stateless: flows are per-request; `carry` is request-scoped, never persisted
- Contract 11 §7 — progress tokens: `notifications/progress` emitted after each step when `_meta.progressToken` present
- Contract 04 — FACT envelope: `flow_id`, `step_ms[]`, `enrich_carry`, `suggested_next` added to `fast` block
- ADR-0014 — semantic-first modes: flows are the execution instantiation of modes; mode determines flow family; flow determines exact step sequence
- ADR-0014-A1 — cascade: cascade logic moves into step sequence in flows; `layer3_ann → layer1_ann → layer2_ann` is a flow, not a special code path
- ADR-0014-A2 — Muvera re-rank: `muvera_rerank` is a named step in StepRegistry; activated by including it in a flow's step list
- Contract 15 — `cluster_assignments.concept_stems[]` column required for enrich Pass 3 (added in §2)
- ADR-0008 — local-first: enrich step uses the same ONNX model as `batch_embed` for Pass 4 ANN; no new model runtime required
