# ADR-0003: Three-Backend Query Architecture

**Status:** Accepted  
**Date:** 2026-05-05  
**Deciders:** Lead Engineer, Architecture Review  
**Supersedes:** —  
**Superseded by:** —  
**Amended by:** ADR-0014 (semantic-first routing layer)

---

### Context

ECLE 2.0 answers three fundamentally different query types:

1. **Structured lookups** — "Give me all functions in file X", "Find all SQL writes to table T", "List all callers of function F". These are exact-match, filter-heavy queries over known fields. These are the *destination* of a conversation, not the starting point.

2. **Semantic search** — "Find code that handles authentication", "Which functions are semantically similar to this snippet?". Require ANN search over dense vectors. This is the *entry point* for exploration — most conversations begin here before narrowing to structural queries.

3. **Topology traversal** — "What is the call depth from entry point E to database layer D?", "Which files would be affected if I change function F?". Require graph traversal (BFS/DFS/CTE) over dependency edges.

A single vector database (the obvious first choice) handles only query type 2 well. Forcing structured lookups through ANN search is 10–50× slower and loses precision. Forcing graph traversal through vector search is impossible for multi-hop queries.

---

### Decision

We will maintain three specialised backends, each with a typed interface, behind a GraphQL query planner that routes to the appropriate backend based on query shape:

- **Structured Fact DB** (`IStructuredDB`): SQLite (Phase 1) → PostgreSQL (Phase 2). Handles precision queries once the right area of the codebase is identified. Stores all `facts.json` fields as queryable columns.
- **Vector Index** (`IVectorStore`): ChromaDB (Phase 1) → Qdrant (Phase 2). Slim payloads only (see ADR-0004). **Primary entry point** for exploration queries; pre-filters by Louvain cluster before structured post-filter.
- **Topology Graph** (`ITopologyGraph`): SQLite recursive CTEs (Phase 1) → Neo4j (Phase 2). Handles call-graph traversal and impact analysis.

The MCP server is stateless in front of `/graphql`. Swapping any backend (e.g. SQLite → PostgreSQL) requires zero changes to MCP tools or GraphQL schema. **Query routing is governed by ADR-0014** (semantic-first query planning — three modes: semantic, structured, composite).

---

### Consequences

**Positive:**

- Each backend is optimised for its query type — no performance compromise
- Interfaces (`IStructuredDB`, `IVectorStore`, `ITopologyGraph`) allow backend swap without touching query logic
- SQLite in Phase 1 requires zero infrastructure — single file, zero ops cost
- Vector index as primary exploration entry point enables composite queries: ANN narrows cluster scope, structured DB answers precisely within it
- Graph backend enables impact analysis queries that vector search cannot answer

**Negative / Trade-offs:**

- Three backends = three operational concerns in production
- Data must be written to all three backends after extraction — increases write path complexity
- Consistency across backends is eventual, not transactional — a partial write failure must be handled by the event pipeline
- GraphQL query planner adds a routing layer — must be kept simple to avoid becoming a bottleneck

**Neutral / Operational notes:**

- Phase 1 uses SQLite for both Structured DB and Topology Graph — single process, zero infrastructure
- Migration from SQLite to PostgreSQL/Neo4j in Phase 2 is a backend swap behind the interface — no query logic changes
- Vector index is always required: if ChromaDB is unavailable, Mode 1 and Mode 3 queries degrade to structured-only with `semantic_caveat` (see ADR-0014)

---

### Alternatives Considered

| Alternative | Why Rejected |
|-------------|-------------|
| Single vector database for all queries | ANN search is wrong tool for exact lookups (slow, imprecise); cannot do multi-hop graph traversal |
| Single relational database with pgvector | pgvector ANN is slower than dedicated vector DB at scale; graph traversal via recursive CTEs degrades past 5 hops |
| Single graph database (Neo4j only) | Graph DBs are poor at bulk structured lookups; no built-in ANN; adds heavy infrastructure for Phase 1 |
| Elasticsearch for all three | Full-text search is not ANN; graph traversal is not native; operational complexity disproportionate to Phase 1 scale |

---

### Compliance

- Contract: `constitution/contracts/04-fact-contract.md` (FACT query envelope)
- Contract: `constitution/contracts/05-confidence-contract.md` (6-dim confidence)
- Contract: `constitution/contracts/06-grounding-contract.md` (grounding stack uses all three backends)
- Contract: `constitution/contracts/07-staleness-contract.md` (staleness score sourced from Structured DB)
- Anti-pattern: A6 (hardcoded backend — all backend access must go through typed interfaces)
- ADR-0014: semantic-first query planning — amends this ADR's routing layer

---

### References

| # | Citation | Relevance to this ADR |
|---|----------|----------------------|
| R1 | Dong, X.L. "Generations of Knowledge Graphs: The Crazy Ideas and the Business Impact", PVLDB 2023 (arXiv:2308.14217) | Validates three-backend pattern: entity KGs (structured), text-rich KGs (vector), and dual neural KGs (graph) — same separation ECLE uses |
| R2 | Edge, D. et al. "From Local to Global: A Graph RAG Approach to Query-Focused Summarization", 2024 (arXiv:2404.16130) | Microsoft GraphRAG uses the same hybrid: vector retrieval + graph traversal + structured summaries |
| R3 | Principled GraphQL, Apollo (principledgraphql.com) — Principle #10: "Separate the GraphQL Layer from the Service Layer" | Validates GraphQL as a routing layer over heterogeneous backends |
| R4 | Richardson, C. "Microservices Patterns", Manning 2025 — CQRS pattern | Three backends follow CQRS: each backend is a read-optimised projection of the same source events |
