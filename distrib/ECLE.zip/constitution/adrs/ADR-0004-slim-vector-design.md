# ADR-0004: Multi-Layer Vector Store Design with Growth Containment

**Status:** Accepted  
**Date:** 2026-05-05  
**Deciders:** Lead Engineer, Architecture Review  
**Supersedes:** —  
**Superseded by:** —  
**Amends:** —
**Amended by:** ADR-0004-A1 (Muvera re-rank at all vector layers — see §Muvera Re-rank below), ADR-0004-A2 (BM25 hybrid search with RRF — see §Hybrid Search below)
**FACT impact:**
- Fast: `improves` — slim payloads bound vector store memory to ~4 GB at 1M files; Layer 3 cluster centroids narrow ANN scope before Layer 1 search; ANN + DB join completes in ~8 ms
- Accurate: `improves` — three layers match query granularity to result granularity; function-level search (Layer 2) avoids false positives from file-level aggregation; `cluster_alignment` confidence dim quantifies semantic coherence
- Complete: `improves` — Layer 3 enables subsystem-level discovery that would be missed by file-level ANN alone; all three ADR-0014 query modes are served by their corresponding layer
- Trustworthy: `improves` — slim payloads decouple vector freshness from fact freshness; Structured DB is single source of truth; `is_current` and `model_version` fields enable clean invalidation without serving stale facts

---

### Context

ECLE must support three qualitatively different search access patterns (ADR-0014):

1. **Explore** — "how does the billing module work?" — no known anchor; needs subsystem-level and file-level semantic discovery
2. **Locate** — "find functions similar to `PaymentService.retry()`" — ANN pre-filter at function granularity + structured post-filter
3. **Precise** — "what does `PaymentService.retry()` call?" — direct DB lookup; no ANN needed

A single vector collection at one granularity cannot serve all three patterns efficiently:
- File-level vectors are too coarse for function similarity search (Locate mode)
- Function-level vectors are too numerous for subsystem discovery (Explore mode; a 1M-file repo has ~10M+ functions)
- Neither addresses coarse-grained cluster-level pre-filtering, which narrows Explore-mode ANN from 1M candidates to ~1,000

A naive "fat payload" design (embedding full `facts.json` content as vector payload) creates a separate problem: at 1M files with average 50 KB facts, that is 50 GB+ of vector store memory, and any fact update requires atomic re-embedding. This defeats the purpose of a vector index.

The two problems are related: the answer to both is a **multi-layer slim-payload design** — multiple purposeful collections, each covering one search granularity, all sharing the same minimal 5-field payload.

---

### Decision

We will maintain **three vector collections per tenant/repo** with **slim payloads only** (5 routing fields; no fact content). Each layer serves a specific query mode and has a bounded, predictable memory footprint.

---

#### Layer 1 — File Centroid (Explore and Locate pre-filter)

**Purpose:** Semantic exploration and cluster-scoped pre-filtering. One vector per file version, computed as the centroid (mean) of all function-level chunk vectors for that file.

**Collection name:** `{tenant_id}__{repo_id}__layer1`  
**Produced by:** `batch_embed` worker  
**Primary query mode:** ADR-0014 Mode 1 (Semantic/Explore) and Mode 2 (Composite/Locate — ANN pre-filter)

**Memory budget at 1M files:**
- Vectors: 1M × 384 floats × 4 bytes = ~1.5 GB
- Payload (5 fields): ~0.5 GB
- Total Layer 1: ~2 GB

---

#### Layer 2 — Function Body (Locate — function similarity)

**Purpose:** Precise function-level semantic similarity. One vector per function version, computed from the function body text.

**Collection name:** `{tenant_id}__{repo_id}__layer2`  
**Produced by:** `batch_embed` worker  
**Primary query mode:** ADR-0014 Mode 2 (Composite/Locate) — ANN on function bodies, then structured post-filter within the matched cluster

**Memory budget at 1M files (assuming 10 functions/file average):**
- Vectors: 10M × 384 floats × 4 bytes = ~15 GB (enterprise tier)
- Payload (5 fields): ~2 GB
- Total Layer 2: ~17 GB (enterprise); ~1.7 GB at 100K files (dev/compose tier)

Layer 2 is optional at `dev` tier — skipped when `EMBED_LAYERS=1` is set. Always enabled at `enterprise` tier.

#### Muvera Re-rank — All Layers (Amendment ADR-0004-A1)

After ANN returns top-K candidates at **any layer**, a Muvera token-level re-ranker
refines result order before returning to the caller. Each layer re-ranks against a
different text source, but the mechanism is identical: fetch text → encode → MaxSim → re-order.

**How it works (query-time only — zero write-path impact):**

```
ANN top-K candidates (IDs + scores)
  ↓
fetch re-rank text for each candidate from Structured DB  (one SQL round-trip)
  ↓
encode query + each candidate text through Muvera token encoder (on-the-fly, not stored)
  ↓
compute exact MaxSim per candidate  →  re-order  →  return final top-K
```

**Re-rank text source per layer:**

| Layer | ANN returns | Re-rank text fetched from | Text content |
|-------|-------------|--------------------------|--------------|
| Layer 1 (files) | `file_facts.id` | `file_facts` + `file_tables` + `function_facts` | `assemble_embedding_text()` — behavioral signature: functions, tables read/written, external calls, SQL ops, complexity, execution model |
| Layer 2 (functions) | `function_facts.id` | `function_facts` + `function_calls` + `function_table_ops` | `assemble_fn_embedding_text()` — function name, return type, tables, callees, complexity, entry point flag |
| Layer 3 (clusters) | `cluster_id` | `file_facts` (top-5 files by centrality within cluster) | Concatenated `assemble_embedding_text()` of the 5 most central files — gives MaxSim enough tokens to distinguish cluster purpose |

**Layer 3 detail — why top-5 files, not all:**
A cluster can contain hundreds of files. Encoding all of them would blow the 2s timeout.
The top-5 by centrality (highest `topology_edges` degree within the cluster) capture the
cluster's dominant behavior. At 3,000–10,000 clusters, ANN is already near-exact on the
small collection — re-ranking catches the edge cases where centroid averaging masks the
cluster's primary purpose.

**What does NOT change:**
- Collection schemas, embedding dim (384), slim payload — all unchanged at all layers
- `batch_embed` worker — no change
- `chunk_file` worker — no change
- Ingestion pipeline — no change
- Storage budget — zero additional storage (token vecs are ephemeral, never stored)
- `assemble_embedding_text()` and `assemble_fn_embedding_text()` — already exist for
  `chunk_file`; re-ranker calls the same functions at query time

**Configuration constants:**

| Constant | Default | Meaning |
|---|---|---|
| `RERANK_ENABLED` | `false` (dev) / `true` (enterprise) | Global on/off switch for all layers |
| `RERANK_MODEL` | `muvera-base` | Muvera checkpoint to load (~440 MB, BERT-based, no LLM) |
| `RERANK_DIM` | TBD — operator evaluating; candidate 768+ | Token embedding dim used during MaxSim inference only; **not stored anywhere** |
| `RERANK_LAYER1_TOP_K` | `50` | ANN candidate count passed to re-ranker at Layer 1 |
| `RERANK_LAYER2_TOP_K` | `50` | ANN candidate count passed to re-ranker at Layer 2 |
| `RERANK_LAYER3_TOP_K` | `20` | ANN candidate count passed to re-ranker at Layer 3 (smaller collection) |
| `RERANK_LAYER3_FILES_PER_CLUSTER` | `5` | Top-N files by centrality used to build cluster re-rank text |
| `RERANK_TIMEOUT_MS` | `500` | Per-layer re-rank timeout; if exceeded, fall back to ANN order |

`RERANK_DIM` is set once before Phase 2 deployment. It governs inference-time
tensor shape only — changing it requires no re-embedding or collection migration.

**Latency budget per layer:**

| Layer | ANN latency | Re-rank overhead | Total | Guard |
|-------|-------------|------------------|-------|-------|
| Layer 1 (50 files) | ~3 ms | ~50–150 ms (1 SQL + 50 MaxSim) | ~150 ms | 500 ms timeout, then fallback |
| Layer 2 (50 functions) | ~3 ms | ~30–200 ms (1 SQL + 50 MaxSim) | ~200 ms | 500 ms timeout, then fallback |
| Layer 3 (20 clusters) | ~1 ms | ~50–100 ms (5 SQL per cluster × 20 = 100 rows, but batch-fetched as 1 query) | ~100 ms | 500 ms timeout, then fallback |
| Cascade (L3→L1→L2) | ~7 ms | ~300–450 ms (all three re-ranks) | ~450 ms | 2s hard timeout (Contract 04) |

**Cascade interaction:**
In a full cascade query (ADR-0014 Mode 1: Semantic/Explore), re-ranking at each layer
feeds refined candidates to the next layer. The cascade short-circuits if the per-layer
timeout is hit — downstream layers receive ANN-ordered candidates instead:

```
Layer 3 ANN (20 clusters) → Muvera re-rank → top-3 clusters
  ↓
Layer 1 ANN scoped to those clusters (50 files) → Muvera re-rank → top-10 files
  ↓
Layer 2 ANN scoped to those files (50 functions) → Muvera re-rank → top-10 functions
```

If Layer 1 re-rank times out, Layer 2 still re-ranks its own ANN results independently.
Each layer's re-rank is autonomous — no layer depends on another's re-rank succeeding.

**Graceful degradation:**
- `RERANK_ENABLED=false` → pure ANN order at all layers (Phase 1 behavior)
- Muvera model not loaded → log WARNING at startup; queries proceed without re-ranking
- Per-layer timeout hit → that layer falls back to ANN order; emit `rerank.timeout` Kafka event
- Structured DB unavailable → re-rank text fetch fails; fall back to ANN order; emit `rerank.fallback` Kafka event

**FACT impact of re-rank:**

| Dimension | Effect |
|---|---|
| Fast | Neutral — adds ~300–450 ms on full cascade; guarded by 2s hard timeout; each layer independently times out at 500 ms |
| Accurate | Positive — MaxSim finds behaviorally similar entities that centroid-ANN scores poorly (identifier renaming, copy-paste variants, cluster centroid averaging) |
| Complete | Positive — near-clone detection improves at Layer 2; cluster disambiguation improves at Layer 3; `ecle_find_duplicates` and `ecle_search` recall both increase |
| Trustworthy | Positive — `"reranker": "muvera", "reranked_layers": [1, 2, 3]` in FACT envelope makes re-rank application visible to caller; fallback events logged |

---

#### BM25 Hybrid Search with Reciprocal Rank Fusion (Amendment ADR-0004-A2)

ANN search alone misses results where exact keyword matches (table names, function names,
service identifiers) are more relevant than cosine similarity. BM25 full-text search
catches these cases. The two result sets are fused using Reciprocal Rank Fusion (RRF)
before Muvera re-ranking.

**How it works (query-time only — ingestion impact is one `tsvector` column):**

```
User query: "FEES_LEDGER batch processing"
  ↓
┌─────────────────────┐     ┌─────────────────────┐
│ ANN search (vector)  │     │ BM25 search (PG FTS) │
│ top-K by cosine sim  │     │ top-K by BM25 score  │
└────────┬────────────┘     └────────┬────────────┘
         │                           │
         └─────────┬─────────────────┘
                   ↓
         Reciprocal Rank Fusion (RRF)
              merged top-K
                   ↓
         Muvera re-rank (ADR-0004-A1)
              final top-K
```

**RRF formula (Cormack et al., SIGIR 2009):**

```
RRF_score(d) = Σ  1 / (k + rank_i(d))
               i∈{ANN, BM25}

where k = 60 (standard constant)
```

RRF is parameter-free (no learned weights), deterministic, and works even when one
retriever returns no results for a query. If a document appears in only one result set,
it still gets scored — no result is lost.

**Write-path change — `embedding_text_tsv` column:**

The behavioral signature text assembled by `chunk_file` (same text that gets embedded)
is also stored as a `tsvector` column in the Structured DB for BM25 scoring:

| Table | New column | Type | Populated by |
|-------|-----------|------|-------------|
| `file_facts` | `embedding_text_tsv` | `TSVECTOR` | `chunk_file` worker (at ingestion time, alongside `file.chunked` event) |
| `function_facts` | `embedding_text_tsv` | `TSVECTOR` | `chunk_file` worker |

```sql
-- GIN index for fast BM25 lookup
CREATE INDEX idx_file_facts_tsv ON file_facts USING GIN (embedding_text_tsv)
  WHERE is_current = true;
CREATE INDEX idx_function_facts_tsv ON function_facts USING GIN (embedding_text_tsv)
  WHERE is_current = true;
```

**Why store `tsvector`, not raw text?**
- `tsvector` is pre-tokenized + stemmed — BM25 scoring at query time requires no text processing
- PostgreSQL `ts_rank_cd()` gives BM25-equivalent scoring natively
- Raw embedding text is NOT stored — it can be reconstructed from structured columns
  by `assemble_embedding_text()` when needed (for Muvera re-rank)
- `tsvector` is ~200 bytes per row vs ~500 bytes for raw text — 60% smaller

**Query flow with hybrid search:**

```python
# Layer 1 hybrid search example
async def hybrid_search_files(query: str, repo_id: str, top_k: int = 10):
    # 1. ANN search (vector DB)
    query_vec = embedding_model.encode(query)
    ann_results = vector_db.search(
        collection=f"{tenant}__{repo_id}__layer1",
        vector=query_vec,
        filter={"is_current": True, "model_version": CURRENT_MODEL},
        top_k=HYBRID_ANN_TOP_K,  # default: 50
    )

    # 2. BM25 search (PostgreSQL full-text)
    bm25_results = structured_db.query("""
        SELECT id, ts_rank_cd(embedding_text_tsv, plainto_tsquery(:query)) AS bm25_score
        FROM file_facts
        WHERE tenant_id = :tenant AND repo_id = :repo_id AND is_current = true
          AND embedding_text_tsv @@ plainto_tsquery(:query)
        ORDER BY bm25_score DESC
        LIMIT :limit
    """, query=query, limit=HYBRID_BM25_TOP_K)  # default: 50

    # 3. RRF fusion
    fused = reciprocal_rank_fusion(ann_results, bm25_results, k=60)

    # 4. Muvera re-rank (if enabled)
    if RERANK_ENABLED:
        fused = muvera_rerank(query, fused[:RERANK_LAYER1_TOP_K])

    return fused[:top_k]
```

**Which layers get hybrid search:**

| Layer | BM25 source | Hybrid? | Rationale |
|-------|------------|---------|-----------|
| Layer 1 (files) | `file_facts.embedding_text_tsv` | Yes | "Find files that touch FEES_LEDGER" — exact table name match is critical |
| Layer 2 (functions) | `function_facts.embedding_text_tsv` | Yes | "Find functions that call db_connect" — exact callee name match |
| Layer 3 (clusters) | N/A | No | Clusters are centroids with no meaningful text for keyword match; ANN + re-rank is sufficient |
| Layer Docs | `doc_chunks.chunk_text` (already stored) | Yes | Document search benefits most from hybrid — keywords in docs are highly specific |

**Configuration constants:**

| Constant | Default | Meaning |
|---|---|---|
| `HYBRID_SEARCH_ENABLED` | `false` (dev) / `true` (enterprise) | Global on/off switch |
| `HYBRID_ANN_TOP_K` | `50` | ANN candidates before fusion |
| `HYBRID_BM25_TOP_K` | `50` | BM25 candidates before fusion |
| `HYBRID_RRF_K` | `60` | RRF constant (standard value from Cormack et al.) |

**Full retrieval pipeline with all amendments:**

```
Query
  ↓
┌──────────────┐  ┌──────────────┐
│ ANN (vector) │  │ BM25 (PG FTS)│   ← ADR-0004-A2
└──────┬───────┘  └──────┬───────┘
       └────────┬────────┘
                ↓
        RRF fusion (top-K)              ← ADR-0004-A2
                ↓
        Muvera re-rank (MaxSim)         ← ADR-0004-A1
                ↓
        Join Structured DB (facts)      ← ADR-0004 core
                ↓
        Grounding verifier (lineage)    ← Contract 06
                ↓
        FACT envelope response          ← Contract 04
```

**Graceful degradation:**
- `HYBRID_SEARCH_ENABLED=false` → pure ANN + re-rank (ADR-0004-A1 behavior)
- PostgreSQL FTS unavailable → ANN-only; emit `hybrid.bm25_unavailable` Kafka event
- BM25 returns zero results → RRF uses ANN results only (RRF handles single-source gracefully)
- Both BM25 and ANN return results for a document → RRF boosts it (appears in both lists)

**FACT impact of hybrid search:**

| Dimension | Effect |
|---|---|
| Fast | Neutral — BM25 on GIN index is ~2–5 ms; RRF is O(K) merge; total adds ~10 ms before re-rank |
| Accurate | Positive — exact keyword matches for table names, function names, service identifiers no longer missed by ANN |
| Complete | Positive — recall improves 10–20% (per RAG survey literature); queries like "FEES_LEDGER" now return all files touching that table even if embeddings diverge |
| Trustworthy | Positive — `"retrieval": "hybrid_rrf", "sources": ["ann", "bm25"]` in FACT envelope; caller sees which retrieval path contributed |

---

#### Layer 3 — Cluster Centroid (Subsystem discovery, coarse pre-filter)

**Purpose:** Subsystem-level semantic entry point. One vector per Louvain community (cluster), computed as the mean of all Layer 1 vectors in that cluster.

**Collection name:** `{tenant_id}__cross_repo__capabilities`  
**Produced by:** `cluster_centroids` worker (consumes `topology.updated` events — ADR-0011)  
**Primary query mode:** ADR-0014 Mode 1 (Semantic/Explore) — first ANN pass returns the closest cluster(s), then Layer 1 ANN is scoped to those clusters

**Memory budget:** Sublinear growth — Louvain community count grows as ~√N of files. At 1M files: ~3,000–10,000 clusters → Layer 3 collection is always < 50 MB.

---

#### Slim payload — all layers

Every upserted vector MUST carry exactly these 5 fields in its payload, regardless of layer:

```json
{
  "repo_id":       "string",
  "cluster_id":    "string | null",
  "is_current":    true,
  "model_version": "all-MiniLM-L6-v2@384d",
  "layer":         1
}
```

**No fact content in payloads.** Functions, SQL statements, call edges, imports, and confidence scores belong in the Structured Fact DB. After ANN returns candidate IDs, the query planner fetches full facts by `id` join (~5 ms). Total latency budget: ANN search ~3 ms + DB join ~5 ms = ~8 ms.

This decoupling means: fact updates never require re-embedding unless the embedded text content itself changed. The Structured DB is the single source of truth.

---

#### Growth containment summary

| Layer | Scale factor | Memory at 1M files |
|-------|-------------|-------------------|
| Layer 1 (file centroids) | O(files) | ~2 GB |
| Layer 2 (function bodies) | O(files × avg_functions) | ~17 GB enterprise / skip at dev |
| Layer 3 (cluster centroids) | O(√files) — sublinear | < 50 MB |
| **Total** | | **~19 GB enterprise, ~2 GB dev** |

Without slim payloads, Layer 1 alone at fat payload would be ~50 GB+. Slim payloads reduce the per-vector storage cost by ~25×.

---

#### Supporting fields

- `is_current=false`: soft-delete without removing the vector from the collection — stale vectors are pre-filtered out of ANN results, then deleted by the stale-vector sweep
- `model_version`: invalidation key when `EMBEDDING_MODEL_NAME` or `EMBEDDING_DIM` changes — new key triggers re-embedding sweep; old vectors remain queryable with `model_version` filter until sweep completes
- `cluster_id`: written by `compute_topology` (ADR-0011), not by `batch_embed`; enables `cluster_alignment` confidence dimension (cosine similarity between file Layer 1 vector and its cluster Layer 3 centroid) without querying the topology graph at query time

---

#### Stale vector sweep — frequency SLA

Stale vectors (`is_current=false`) accumulate between Celery Beat sweeps. A high stale ratio degrades ANN index efficiency (ChromaDB at Phase 1 is especially sensitive). The sweep is a mandatory operational concern, not an optional cleanup:

| Tier | Max tolerated stale ratio | Sweep frequency | Trigger |
|---|---|---|---|
| `dev` | 50% | Manual / on demand | `ecle sweep-vectors` CLI |
| `compose` | 20% | Nightly (Celery Beat) | 02:00 UTC cron |
| `enterprise` | 10% | Every 6 hours (Celery Beat) | Cron + alert if ratio exceeds threshold |

`VECTOR_MAX_STALE_RATIO` (default: tier-appropriate value above) — if ratio is exceeded at query time, emit a `vector_store.stale_ratio_exceeded` Kafka event for operator alerting. Never block the query.

#### Model upgrade re-embedding sweep strategy

A model upgrade invalidates every vector in every layer. At 1M files × 11M vectors (Layer 1 + 2), a naive single-worker sweep takes hours. The sweep MUST be parallelizable:

```
1. Operator sets EMBEDDING_MODEL_NAME + EMBEDDING_DIM to new values
2. Emit model.upgrade.started { old_model, new_model, collections[] } to Kafka
3. sweep_coordinator worker (Celery Beat triggered) partitions work:
     FOR each collection (layer1, layer2, docs):
       SELECT DISTINCT cluster_id FROM file_facts ORDER BY centrality DESC
       Emit re-embed.batch { cluster_id, layer, model_version_new } per cluster
       → Hot clusters (highest centrality) first — most-queried data is fresh soonest
4. batch_embed workers consume re-embed.batch events (standard consumer group fan-out)
   → Scales horizontally — add more batch_embed replicas to accelerate sweep
5. Old vectors remain queryable (model_version filter) until sweep completes per cluster
6. sweep_coordinator emits model.upgrade.completed when all clusters done
```

Configuration constants:

| Constant | Default | Meaning |
|---|---|---|
| `EMBED_SWEEP_BATCH_SIZE` | `500` | Files per re-embed.batch Kafka message |
| `EMBED_SWEEP_PRIORITY` | `centrality_desc` | Order: `centrality_desc` (hot-first) \| `modified_desc` (recent-first) \| `random` |
| `VECTOR_MAX_STALE_RATIO` | `0.10` (enterprise) | Alert threshold for stale vector ratio |

---

#### Embedding model

`all-MiniLM-L6-v2` (384-dim, ONNX/OpenVINO mandatory for air-gapped deployment). 768-dim benchmark deferred to Phase 2.

---

### Consequences

**Positive:**

- Three layers map directly to ADR-0014's three query modes — no routing mismatch
- Growth is bounded and predictable per layer — memory budget can be quoted to operators before deployment
- Facts can be updated in the Structured DB without re-embedding unless embedded text changed
- `is_current=false` enables soft-delete — stale vectors do not pollute ANN results
- `model_version` enables clean invalidation on model upgrade — old vectors remain queryable until sweep completes
- `cluster_id` on all layers enables `cluster_alignment` confidence dimension at query time without graph traversal
- Air-gapped deployment is first-class: ONNX/OpenVINO mandatory, no cloud embedding APIs

**Negative / Trade-offs:**

- Every semantic search requires a two-hop DB join (~5 ms overhead per query)
- If Structured DB is unavailable, ANN results return IDs only — no facts
- Layer 2 at enterprise scale (~17 GB) requires dedicated memory allocation; cannot be co-located with Layer 1 on small VMs
- `model_version` mismatch invalidation requires a full re-embedding sweep per collection — expensive at scale; mitigated by cluster-partitioned parallel sweep via Kafka (see §Model upgrade sweep strategy above)
- Three collections require three `get_or_create_collection()` calls at startup and three upsert paths in `batch_embed`

**Neutral / Operational notes:**

- Phase 1 uses ChromaDB; Phase 2 evaluates Qdrant for production scale
- `EMBED_LAYERS=1` skips Layer 2 at `dev` tier — reduces memory footprint to ~2 GB on developer machines
- Layer 3 computation is triggered by `topology.updated` events, not by `batch_embed` — `cluster_centroids` worker is separate
- Re-embedding on model upgrade runs as a Kafka-partitioned parallel sweep; `sweep_coordinator` Celery Beat job emits one `re-embed.batch` message per cluster, prioritized by centrality; `batch_embed` consumers process in parallel

---

### Alternatives Considered

| Alternative | Why Rejected |
|-------------|-------------|
| Fat payload (full facts in vector store) | ~50 GB+ memory at 1M files; consistency problems on fact update; vector store is not a structured query engine |
| Duplicate all facts in both vector store and Structured DB | Doubles storage; dual-write consistency problem; vector store payload queries are slower than SQL for structured fields |
| Single collection (file-level only) | Cannot serve function-level Locate queries (Layer 2); no subsystem-level coarse pre-filter (Layer 3); ADR-0014 Mode 2 would require full-corpus ANN then post-filter — inefficient |
| No vector store (structured search only) | Semantic search is the primary entry point for ~55% of queries (ADR-0014 correction to ADR-0003's wrong "20%" figure); removing the vector store means most user conversations cannot navigate the codebase at all |
| 768-dim embeddings from Phase 1 | 2× memory cost per layer for marginal quality gain at Phase 1 scale; benchmark before committing |
| External embedding API (OpenAI, Cohere) | Violates air-gapped deployment requirement; latency unpredictable; cost unbounded at scale |

---

### Compliance

- Contract: `constitution/contracts/04-fact-contract.md` — `query_mode`, `cluster_ids_used` in FACT envelope `fast` block; `cluster_alignment` in 6-dim confidence profile
- Contract: `constitution/contracts/05-confidence-contract.md` — `cluster_alignment` dim computed from Layer 1 vs Layer 3 cosine similarity
- Contract: `constitution/contracts/07-staleness-contract.md` — `is_current` field is the staleness pre-filter at ANN time
- Contract: `constitution/contracts/12-embedding-contract.md` — collection naming, slim payload fields, layer assignment rules, `model_version` invalidation
- ADR-0003: Three-Backend Architecture — vector index (all three layers) is the primary entry point for Explore/Locate modes
- ADR-0011: Louvain Community Detection — `cluster_id` written to `file_facts` before `cluster_centroids` can compute Layer 3; two-phase ordering constraint
- ADR-0014: Semantic-First Query Planning — Layer 1 serves Mode 1 and Mode 2 ANN pre-filter; Layer 2 serves Mode 2 function similarity; Layer 3 serves Mode 1 coarse cluster pre-filter
- Eval: `eval_fidelity_ceiling` — verifies ANN results are joined with full facts before confidence scoring

---

### References

| # | Citation | Relevance to this ADR |
|---|----------|----------------------|
| R1 | Khattab, O. & Zaharia, M. "ColBERT: Efficient and Effective Passage Search via Contextualized Late Interaction over BERT", SIGIR 2020 (arXiv:2004.12832) | Multi-vector late interaction architecture: independently encode query and documents, compute fine-grained similarity — validates ECLE's multi-layer vector design over single-vector approaches |
| R2 | Gao, Y. et al. "Retrieval-Augmented Generation for Large Language Models: A Survey", 2024 (arXiv:2312.10997) | Categorises RAG into Naive → Advanced → Modular; ECLE's three-layer slim design maps to Modular RAG with decoupled retriever modules |
| R3 | Gao, Y. et al. "Modular RAG: Transforming RAG Systems into LEGO-like Reconfigurable Frameworks", 2024 (arXiv:2407.21059) | Validates decomposing retrieval into independent modules with typed metadata rather than monolithic retrieve-then-generate |
| R4 | Malkov, Y. & Yashunin, D. "Efficient and Robust Approximate Nearest Neighbor using Hierarchical Navigable Small World Graphs", IEEE TPAMI 2018 (arXiv:1603.09320) | HNSW algorithm used by Qdrant/ChromaDB; validates ANN index choice and ef_search tuning |
| R5 | Nussbaum, Z. et al. "Nomic Embed: Training a Reproducible Long Context Text Embedder", TMLR 2024 (arXiv:2402.01613) | Open-weight, local-runnable embedding model outperforming OpenAI Ada-002; validates local-first embedding feasibility |
| R6 | Khattab, O. & Zaharia, M. "ColBERT v2: Effective and Efficient Retrieval via Lightweight Late Interaction", NAACL 2022 (arXiv:2112.01488) | MaxSim late interaction scoring — the re-ranking mechanism Muvera implements. Retrieval quality improvement of 15-30% recall@10 over single-vector ANN |
| R7 | Lassance, C. et al. "Muvera: Multi-Vector Retrieval via Fixed Dimensional Encodings", 2024 (arXiv:2405.19504) | Muvera's fixed-dimensional encoding of multi-vector representations for efficient MaxSim; validates query-time re-ranking without stored token vectors |
| R8 | Cormack, G.V. et al. "Reciprocal Rank Fusion outperforms Condorcet and individual Rank Learning Methods", SIGIR 2009 | RRF formula: `1/(k+rank)` fusion of multiple retriever result sets. Parameter-free, deterministic, outperforms learned fusion methods. Validates ECLE's BM25+ANN hybrid approach |
| R9 | Robertson, S.E. & Zaragoza, H. "The Probabilistic Relevance Framework: BM25 and Beyond", Foundations and Trends in IR 2009 | Definitive BM25 reference. PostgreSQL `ts_rank_cd()` implements BM25-equivalent scoring natively. Validates keyword retrieval as complementary to semantic search |
