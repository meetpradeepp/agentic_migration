# ADR-0012: Multi-Level Language and Framework Detection

**Status:** Accepted  
**Date:** 2026-05-05  
**Deciders:** Lead Engineer, Architecture Review  
**Supersedes:** —  
**Superseded by:** —  
**FACT impact:**
- Fast: `neutral` — detection runs inside `parse_repo` worker as additional pass; no new worker; O(lines_in_file) per file
- Accurate: `improves` — framework-aware extraction produces richer structural facts; semantic layer has concrete evidence rather than guessing from decorator names alone
- Complete: `improves` — multi-level detection surfaces every framework layer in a single file; nothing silently dropped
- Trustworthy: `improves` — detection evidence stored as first-class field `detected_layers[]`; every claim about framework membership is traceable to the specific pattern that triggered it

---

### Context

The current registry lookup is purely by file extension. This is sufficient for file types with unique extensions (`.svelte`, `.vue`, `.pbl`) but breaks down in three scenarios:

**Scenario 1 — Framework shares an extension with its host language.**  
An Angular component is a `.ts` file. A plain TypeScript utility is also a `.ts` file. A Nest.js controller is also a `.ts` file. Extension lookup returns the TypeScript language pack for all three — it cannot distinguish them. The same problem applies to React (`.tsx`/`.js`), Django (`.py`), FastAPI (`.py`), and Spring (`.java`).

**Scenario 2 — A single file contains multiple language layers.**  
A `.svelte` file contains HTML template, a `<script lang="ts">` TypeScript block, and a `<style lang="scss">` block. Each layer has its own grammar, its own facts, and its own confidence ceiling. Treating the file as monolithic (one extraction pass, one fidelity score) loses the inner structure.

**Scenario 3 — Nested frameworks within a language.**  
An Angular `.ts` file may simultaneously contain:
- Angular component metadata (`@Component`, `@Injectable`)
- RxJS reactive patterns (`Observable`, `pipe`, `switchMap`)
- A project-specific command-bus DSL (`@CommandHandler`, `@EventSourcing`)

All three layers co-exist in one file. The structural extractor sees all decorators but has no model of what they mean. The semantic layer (`ontology_enricher`) needs to know which ontologies to load — it cannot load the entire ontology catalogue for every file.

---

### Decision

We introduce **three-pass detection** running inside the `parse_repo` worker, before and during `fast_extractor.extract()`. The output is a `detected_layers[]` array written to every `file_facts` row and every `facts.json` IR artifact.

---

### Pass 0 — Extension resolution (existing, unchanged)

Registry lookup by file extension → returns the primary `LanguagePack`.  
This is the authoritative language assignment. All subsequent passes add to it; they do not replace it.

---

### Pass 1 — Content heuristics (NEW — runs inside parse_repo, before extraction)

A lightweight, fast scanner over raw file bytes. **No tree-sitter, no AST.** Uses regex patterns and string matching only. Runs in microseconds per file.
Performance guarantees (enforced by `LanguagePackRegistry` — see ADR-0002):
- All regex patterns are compiled at registry load time — never per file.
- Only the first `DETECTION_SCAN_BYTES` bytes (default: `4096`) are scanned — framework markers appear near the top.
- Rules are evaluated in descending `confidence` order; a failed `required` pattern short-circuits the rule immediately.
Purpose: detect frameworks, dialects, and embedded sub-languages present in the file.

**Detection rules** are declared in `detection_rules/` directory under each language pack:

```
language_packs/
  typescript/
    manifest.yaml
    fast_extractor.py
    schema.py
    detection_rules/
      angular.yaml       # rules for detecting Angular patterns
      react.yaml         # rules for detecting React patterns
      nestjs.yaml
      rxjs.yaml
  python/
    detection_rules/
      django.yaml
      fastapi.yaml
      sqlalchemy.yaml
  svelte/
    detection_rules/
      svelte_blocks.yaml  # rules for locating <script> and <style> inner blocks
```

A detection rule file declares a list of pattern groups:

```yaml
# angular.yaml
framework_id: "angular"
ontology: "ontologies/angular.yaml"
grammar: "tree-sitter-angular"   # OPTIONAL — sub-grammar for framework-specific syntax
grammar_scope: "inline_template" # OPTIONAL — full_file | inline_template | byte_range | null
confidence: 0.9          # detection confidence when ALL required patterns match
patterns:
  required:              # ALL must match to trigger detection
    - pattern: "@Component"
      type: string
    - pattern: "@NgModule|@Injectable|@Directive|@Pipe"
      type: regex
  supporting:            # each match raises confidence toward 1.0
    - pattern: "from '@angular/core'"
      type: string
    - pattern: "from '@angular/common'"
      type: string
```

Pass 1 output — a `DetectedLayer` per matched framework:

```python
@dataclass
class DetectedLayer:
    layer_type: str          # "framework" | "dialect" | "embedded_language" | "dsl"
    id: str                  # e.g. "angular", "rxjs", "scss", "project.command_bus"
    ontology_file: str       # path to ontology file to load during semantic enrichment
    detection_confidence: float   # 0.0–1.0; from rule file + supporting pattern boosts
    evidence: list[str]      # the specific patterns that triggered detection (for traceability)
    byte_range: tuple[int, int] | None  # for embedded languages — None for whole-file frameworks
    grammar: str | None      # sub-grammar package name (e.g. "tree-sitter-angular"); None = no sub-parse
    grammar_scope: str | None  # full_file | inline_template | byte_range | None
```

Pass 1 is **read-only and side-effect-free**. It does not modify any facts. It produces a list of `DetectedLayer` objects that are passed to Pass 2 and written to the IR.

---

### Pass 2 — Layered extraction (ENHANCED fast_extractor.py)

Pass 1 results are passed to `fast_extractor.extract()` as an additional parameter:

```python
def extract(
    tree_or_bytes: Any,
    source_bytes: bytes,
    file_path: Path,
    language_dir: Path,
    detected_layers: list[DetectedLayer],   # NEW — from Pass 1
) -> dict[str, Any]:
```

The extractor uses `detected_layers` to:

1. **Select extraction sub-modules.** If `detected_layers` contains `angular`, the TypeScript extractor activates its Angular sub-extractor (which knows how to parse `@Component` metadata, `template`, `styleUrls`, `providers`). Without detection, the sub-extractor stays dormant.

2. **Run sub-grammars for framework-specific syntax.** If a `DetectedLayer` has a non-null `grammar`, the extractor loads that tree-sitter grammar and passes the appropriate bytes (determined by `grammar_scope`) to it. Example: Angular inline template — `grammar_scope: inline_template` → extractor locates the `template: \`...\`` string literal, slices its bytes, parses with `tree-sitter-angular`, returns template AST facts in a nested `ExtractedBlock`. The primary grammar (`tree-sitter-typescript`) handles everything else.

   **Sub-grammar conflict rule:** if two `DetectedLayer` entries both declare a `grammar` with overlapping byte ranges, the higher `detection_confidence` grammar wins for that range. The lower-confidence layer still contributes ontology enrichment — it does not get a separate parse.

3. **Handle embedded language blocks.** If a `DetectedLayer` has a `byte_range`, the extractor slices that byte range and delegates to the appropriate sub-extractor or registered language pack. Example: the Svelte pack detects `<script lang="ts">` block, slices its bytes, delegates to the TypeScript pack's `extract()` — returns a nested `ExtractedBlock` within the Svelte facts.

4. **Set per-layer fidelity.** The outer file gets a `fidelity` from the primary pack (e.g. `FULL` for TypeScript). Each `ExtractedBlock` from a sub-grammar or embedded language gets its own `fidelity`. The file's effective `syntactic_freshness` ceiling = `min(fidelity_ceiling for each layer)`.

Output additions to `facts.json` IR:

```json
{
  "detected_layers": [
    {
      "layer_type": "framework",
      "id": "angular",
      "ontology_file": "ontologies/angular.yaml",
      "detection_confidence": 0.95,
      "evidence": ["@Component", "from '@angular/core'"]
    },
    {
      "layer_type": "framework",
      "id": "rxjs",
      "ontology_file": "ontologies/rxjs.yaml",
      "detection_confidence": 0.80,
      "evidence": ["Observable", "pipe", "switchMap"]
    }
  ],
  "extracted_blocks": []
}
```

---

### Pass 3 — Semantic enrichment (existing ontology_enricher, ENHANCED)

`ontology_enricher` currently loads a fixed set of ontology files per cluster.  
After this ADR, it **also loads per-file ontologies** from `detected_layers[].ontology_file`.

Order of ontology loading:
1. Cluster-level ontologies (from Louvain community — ADR-0011)
2. File-level ontologies from `detected_layers` (this ADR)
3. Project-level custom DSL ontology (always loaded last — may override)

Conflict resolution: if two ontologies map the same pattern to different domain concepts, the **more specific** ontology wins (file-level > cluster-level > project-level). Conflicts are logged as `ontology.conflict` events — not silently dropped.

---

### Multi-level example

**File:** `src/billing/invoice.component.ts`

| Pass | Result |
|---|---|
| Pass 0 (extension) | Primary pack = TypeScript |
| Pass 1 (heuristics) | Detected: `angular` (confidence 0.95, evidence: `@Component`, `@Injectable`), `rxjs` (confidence 0.80, evidence: `Observable`, `switchMap`) |
| Pass 2 (extraction) | TypeScript facts + Angular component metadata block (template URL, providers, inputs/outputs) + RxJS stream topology (observable chains identified) |
| Pass 3 (semantic) | Loads `ontologies/angular.yaml` + `ontologies/rxjs.yaml` + cluster ontology → `domain_concepts: ["billing.invoice-view", "angular.smart-component", "rxjs.data-pipeline"]` |

All four passes are traceable in the `file_facts` row. An engineer debugging why a file has `angular` in its `domain_concepts` can trace: `domain_concepts → detected_layers.angular → evidence: ["@Component"]`.

---

### `detected_layers` as a first-class field

`detected_layers[]` is written to:
- `facts.json` IR artifact (extraction output)
- `file_facts` table (persisted by `persist_facts` worker)
- FACT envelope `lineage` block (for query response traceability)

It is **never inferred or reconstructed** from other fields. If detection did not run, the field is an empty array — not absent.

---

### What does NOT change

- Language pack folder structure — detection rules are additive (`detection_rules/` subdirectory, optional)
- `fast_extractor.extract()` signature is backward-compatible — `detected_layers` defaults to `[]`; existing packs that do not handle it are unaffected
- Registry lookup by extension (Pass 0) remains authoritative for primary language assignment
- DefaultPack behaviour — it receives `detected_layers=[]` and returns baseline text extraction; no framework detection for unknown file types

---

### Detection rule ownership

Framework ontologies and detection rules are **not bundled with the host language pack**. They live in:

```
ontologies/
  angular.yaml
  react.yaml
  nestjs.yaml
  rxjs.yaml
  django.yaml
  fastapi.yaml
  sqlalchemy.yaml
  svelte.yaml
```

```
language_packs/typescript/detection_rules/
  angular.yaml    ← points to ontologies/angular.yaml
  react.yaml
  nestjs.yaml
  rxjs.yaml
```

This separation means:
- The TypeScript pack does not own the Angular ontology — the ontology team does
- A new framework can be added by dropping a `detection_rules/*.yaml` + `ontologies/*.yaml` — no code change
- The same ontology file (`ontologies/rxjs.yaml`) can be referenced by both TypeScript and JavaScript detection rules

---

### Alternatives Considered

| Alternative | Why Rejected |
|---|---|
| Extension-only detection (current) | Cannot distinguish framework from plain language; Scenario 1 and 3 unaddressed |
| Single monolithic detector (separate worker) | Adds a new synchronous step before `parse_repo`; increases pipeline depth; detection is fast enough to run inline |
| AST-based detection (tree-sitter) | Accurate but slow; detection is a pre-filter — heuristics sufficient for framework identification; AST is already used in Pass 2 extraction |
| ML-based classifier for framework detection | Non-deterministic; not traceable; violates Trustworthy lever; no LLM at any layer |
| Load all ontologies for every file | Correct but O(all_ontologies × all_files); semantic enrichment becomes the bottleneck at scale; targeted loading is faster and more precise |

---

### Compliance

- Contract: `constitution/contracts/08-language-pack-contract.md` — `detection_rules/` subdirectory added; `fast_extractor.extract()` signature extended; `detected_layers[]` field added to required IR output
- Contract: `constitution/contracts/06-grounding-contract.md` — `detected_layers[].evidence` provides lineage for every framework attribution
- Contract: `constitution/contracts/04-fact-contract.md` — `semantic_accuracy` dimension scores Pass 3 output; `detected_layers` is the evidence chain from structural fact to domain concept
- Contract: `constitution/contracts/05-confidence-contract.md` — fidelity ceiling for multi-layer files = `min(fidelity_ceiling for each extracted layer)`
- ADR-0011: `ontology_enricher` cluster-level ontology loading is extended but not replaced by this ADR's per-file loading
- ADR-0002: `LanguagePackRegistry` loads `detection_rules/` during pack registration; existing registry interface unchanged
