# ADR-0023: Disaster Recovery and Backup Strategy

**Status:** Accepted
**Date:** 2026-05-07
**Deciders:** Lead Engineer, Architecture Review, Operations
**Supersedes:** —
**Superseded by:** —
**Amends:** ADR-0010 (deployment model — adds DR requirements per tier)
**FACT impact:**
- Fast: `neutral` — backup and recovery processes are off the query hot path
- Accurate: `neutral` — recovery restores the same deterministic facts; accuracy is not affected by the DR model
- Complete: `improves` — documented RPO/RTO means operators know exactly how much data can be lost and how long recovery takes; "we don't know" is not a valid answer for enterprise procurement
- Trustworthy: `improves` — a recoverable system is a trustworthy system; enterprises require documented DR procedures for SOC 2, ISO 27001, and FedRAMP

---

### Context

ECLE 2.0 has three durable data stores:
1. **Structured DB** (PostgreSQL / SQLite) — canonical fact store; single source of truth
2. **Artifact store** (local filesystem / S3 / Azure Blob) — `facts.json` IR intermediary files
3. **Vector store** (ChromaDB / Qdrant) — derived from structured DB + artifact store; **fully re-derivable**

The fundamental observation is that the vector store is entirely derivable from the structured DB and artifact files. If the vector store is lost, a full re-embedding sweep recovers it. This means:

**Primary recovery targets: Structured DB + Artifact Store only.**

The vector store is never the primary backup target — it is always a derived view.

---

### Decision

We will define RPO (Recovery Point Objective) and RTO (Recovery Time Objective) per tier, backed by concrete backup mechanisms for each data store.

#### RPO and RTO targets

| Tier | Structured DB RPO | Structured DB RTO | Artifact Store RPO | Artifact Store RTO |
|------|-------------------|-------------------|--------------------|--------------------|
| `dev` | ∞ (no backup) | ∞ (re-index from source) | ∞ (no backup) | ∞ (re-index from source) |
| `compose` | 24 hours | 4 hours | 24 hours | 2 hours |
| `enterprise` | 1 hour | 30 minutes (hot standby) | 1 hour | 15 minutes |

**Vector store RPO/RTO are not bounded by backup — they are bounded by re-embedding sweep time:**

| Tier | Vector store recovery method | Expected recovery time |
|------|------------------------------|----------------------|
| `dev` | Drop and re-embed from artifact store | Minutes (small corpus) |
| `compose` | Drop and re-embed from artifact store | Hours (depends on corpus size) |
| `enterprise` | Qdrant native snapshot restore + delta re-embed | 15–60 minutes |

#### Tier 1 — Dev (no backup mandate)

No backup infrastructure. Recovery = re-index from source repos.

`ECLE_TIER=dev` is not intended for persistent data. If SQLite and local ChromaDB are lost, the operator re-runs ingestion from the source repos. This is documented in `README.md` — not a failure, it is the intended dev-tier recovery model.

#### Tier 2 — Docker Compose (daily backup)

**Structured DB (PostgreSQL):**
- `pg_dump` run nightly by Celery Beat (`backup_db_task`) at 03:00 UTC
- Output: compressed SQL dump at `BACKUP_PATH/postgres/{date}.sql.gz`
- Retention: last 7 dumps kept locally (configurable via `BACKUP_PG_RETAIN_COUNT`)
- Test: monthly restore drill (`eval_restore_drill`) — restore to temp container, verify row counts match

**Artifact store:**
- `rsync` or `tar` of `ARTIFACT_STORE_PATH` to `BACKUP_PATH/artifacts/{date}.tar.gz`
- Run nightly by same Celery Beat job
- Retention: last 7 archives

**Recovery procedure (Tier 2):**
```
1. Restore PostgreSQL from latest pg_dump:
   pg_restore -d ecle_db backup.sql.gz

2. Restore artifact files:
   tar -xzf artifacts-backup.tar.gz -C ARTIFACT_STORE_PATH

3. Trigger vector store rebuild:
   POST /admin/v1/repos/{repo_id}/reindex
   (or: POST /admin/v1/vector-store/rebuild  ← triggers sweep_coordinator)

4. Monitor recovery via GET /admin/v1/health until status = "healthy"
```

Recovery from backup: ~4 hours for a 50-repo deployment.

#### Tier 3 — Kubernetes Enterprise (HA + point-in-time recovery)

**Structured DB (Managed PostgreSQL):**
- Managed service (RDS / Azure Database) provides automated daily snapshots + continuous WAL archiving
- RPO: 1 hour (WAL archiving frequency configurable; default 5-minute WAL flush)
- RTO: 30 minutes — failover to read replica promoted to primary (automatic with RDS Multi-AZ)
- Point-in-time recovery (PITR): restore to any point within the last 35 days (RDS default)
- Cross-region backup: enabled via RDS automated backup replication or Azure geo-redundant backup

**Artifact store (S3 / Azure Blob):**
- S3: versioning enabled + cross-region replication rule to `ARTIFACT_BACKUP_REGION`
- Azure: geo-redundant storage (GRS) or zone-redundant (ZRS) depending on compliance requirement
- RPO: 1 hour (replication lag for active ingestion)
- Files are **immutable** (content-addressed: `artifacts/{tenant}/{repo}/{sha}/file.facts.json`) — overwrite is not possible; only new versions appear

**Kafka (Managed: Confluent / MSK / Event Hubs):**
- Managed services provide built-in replication across availability zones
- Critical pipeline topics (30-day retention per ADR-0013) act as a short-term pipeline replay buffer
- Kafka is NOT a primary recovery target — it is a pipeline buffer, not a durable store. Recovery does not depend on Kafka replay beyond its retention window.

**Vector store (Qdrant):**
- Qdrant cluster (3+ nodes per ADR-0010) provides native replication — single node failure does not require recovery
- Qdrant snapshots: automated daily via Kubernetes CronJob, stored to S3 bucket `QDRANT_SNAPSHOT_BUCKET`
- Recovery: restore Qdrant snapshot, then trigger delta re-embed for files indexed since snapshot
- Incremental re-embed uses `embed_status = 'stale'` in `indexing_state` to scope work

**Recovery procedure (Tier 3 — catastrophic failure):**
```
1. Restore PostgreSQL:
   RDS: initiate PITR restore to target timestamp
   Azure: restore from geo-redundant backup

2. Artifact store:
   S3: data is already geo-replicated; point workers to replica bucket
   Azure: failover to paired region storage account

3. Qdrant:
   Restore from latest daily snapshot
   Compute delta: SELECT entity_id FROM indexing_state
                  WHERE embed_status != 'done' OR indexed_at > snapshot_timestamp
   Emit re-embed.batch events for delta scope

4. Kafka consumer group offsets:
   Workers will replay from last committed offset (still within retention window if < 30 days)
   If retention exceeded: workers start from latest offset; pipeline state is recovered from DB

5. Monitor: GET /admin/v1/health
```

#### Backup verification — mandatory monthly drill (`eval_restore_drill`)

A non-negotiable monthly drill runs against the most recent backup:

1. Restore DB to an isolated temporary environment.
2. Count rows per table — must match last recorded row counts within 5%.
3. Run 3 representative queries — must return non-empty results.
4. Destroy the temporary environment.

**Pass criteria:** Restore completes within 2× RTO target; row counts within tolerance; queries succeed.

**Failure:** Alert to operator; incident opened. Backup process is broken until drill passes.

#### Re-ingest as ultimate fallback

If both DB and artifact store backups are unrecoverable (catastrophic event), ECLE can rebuild from source repositories:

```
For each repo in repositories table (preserved in backup or admin-provided list):
    POST /admin/v1/repos   ← re-onboard
    POST /api/upload       ← re-ingest source
```

This is O(full_corpus) ingestion time. For a 10K-file, 50-repo deployment at 200 files/minute throughput: approximately 50 minutes of ingestion. This represents the absolute worst-case RTO with no backup recovery available.

---

### Consequences

**Positive:**
- RPO/RTO targets are now documented and auditable — enterprise procurement and SOC 2 auditors have a concrete commitment to evaluate
- Vector store exclusion from primary backup targets reduces backup storage cost by ~40% (vectors are large; structured DB and artifact files are smaller)
- Re-ingest fallback means ECLE is recoverable even without backups, given access to source repos
- Monthly drill is codified as a mandatory eval — backup rot (backups exist but cannot be restored) is caught early

**Negative / Trade-offs:**
- Tier 2 backup relies on Celery Beat — if the Beat scheduler is down, backups are missed silently. Backup monitoring alert (`backup_age > 36h → alert`) must be implemented.
- PITR for managed PostgreSQL has cost implications at high WAL volume. At 10K files/day ingestion rate, WAL volume is ~500MB/day — manageable.
- Re-ingest fallback requires source repos to be accessible — air-gapped deployments must ensure source repo access during DR events.

**Neutral / Operational notes:**
- `BACKUP_PATH` (Tier 2) is a mounted volume path — not the artifact store path; separate volume.
- Backup jobs run at 03:00 UTC by default; configurable via `BACKUP_CRON_EXPRESSION`.
- `eval_restore_drill` is a monthly hard gate, not a daily one — it is too expensive to run nightly. A missed drill (> 35 days since last success) triggers an alert.

---

### Alternatives Considered

| Alternative | Why Rejected |
|-------------|-------------|
| Back up vector store as primary target | Vector store is fully re-derivable from DB + artifact files; backing it up doubles backup cost and complexity for zero additional safety |
| Continuous DB replication at Tier 2 | Compose tier doesn't justify the complexity of streaming replication; daily snapshots + re-ingest fallback is sufficient |
| Kafka as the primary durable store (replay everything from Kafka) | Kafka retention is 3–30 days; a 31-day pause would lose critical pipeline events; PostgreSQL is the primary durable store |

---

### Compliance

- ADR: `ADR-0010` — deployment model; backup tiers align with deployment tiers
- ADR: `ADR-0021` — data lifecycle; purge operations must not run during an active backup window
- Contract: `constitution/contracts/03-testing-contract.md` — `eval_restore_drill` added as monthly eval
- Regulatory: SOC 2 Type II (Availability criteria); ISO 27001 A.17.1 (IT continuity); FedRAMP CP-9 (information system backup)
