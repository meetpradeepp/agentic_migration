# ADR Template
# Copy this file, rename it ADR-NNNN-short-title.md, fill in every section.
# Status must be one of: Proposed | Accepted | Deprecated | Superseded by ADR-XXXX

---
## ADR-XXXX: [Title — one line, noun phrase]

**Status:** Proposed  
**Date:** YYYY-MM-DD  
**Deciders:** [Names or roles — e.g. "Lead Engineer, Architecture Review"]  
**Supersedes:** —  
**Superseded by:** —  
**FACT impact:**
- Fast: `improves | neutral | degrades` — _one-line reason_
- Accurate: `improves | neutral | degrades` — _one-line reason_
- Complete: `improves | neutral | degrades` — _one-line reason_
- Trustworthy: `improves | neutral | degrades` — _one-line reason_

---

### Context

*What is the problem, constraint, or force that requires a decision?  
Include relevant background, scale targets, and non-functional requirements.  
Keep to 3–8 sentences.*

---

### Decision

*State the decision in one unambiguous sentence starting with "We will…"  
Then explain the mechanism in bullet points if needed.*

We will …

---

### Consequences

**Positive:**

- …

**Negative / Trade-offs:**

- …

**Neutral / Operational notes:**

- …

---

### Alternatives Considered

| Alternative | Why Rejected |
|-------------|-------------|
| …           | …           |

---

### Compliance

*List any contracts, schemas, or eval suites that enforce this decision.*

- Contract: `constitution/contracts/XX-…`
- Schema: `constitution/schemas/…`
- Eval: `eval_…`
