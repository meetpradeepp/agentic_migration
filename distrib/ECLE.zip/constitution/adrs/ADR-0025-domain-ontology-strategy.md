# ADR-0025: Domain Ontology Strategy

**Status:** Accepted
**Date:** 2026-05-07
**Deciders:** Lead Engineer, Architecture Review
**Supersedes:** —
**Superseded by:** —
**Amends:** ADR-0012 (detection rules format — ontology vocabulary sourced from detection_rules context), ADR-0018 (flow registry — `enrich` step vocabulary alignment uses the ontology)
**FACT impact:**
- Fast: `neutral` — ontology enrichment is async (post-ingest); query-time use of pre-enriched annotations adds < 1 ms
- Accurate: `improves` — named domain concepts on clusters and files increase precision of semantic queries; `semantic_accuracy` dimension is now formally defined and computable
- Complete: `improves` — domain vocabulary coverage is observable via `GET /admin/v1/coverage`; gaps are surfaced, not hidden
- Trustworthy: `improves` — `ontology_version` in FACT envelope is traceable to a specific ontology snapshot; when ontology changes, `semantic_accuracy` decays and recalculates — no silent drift

---

### Context

The `ontology_enricher` worker is referenced in 8 places across the constitution but has no dedicated definition. The following are undefined:

- What is the "ontology"? A hardcoded vocabulary? A customer-provided taxonomy? Auto-derived from code?
- Where do `domain_concepts` and `dsl_patterns` come from?
- What is `ontology_version` in the FACT envelope? How is it managed?
- How does a customer extend the vocabulary for their domain?
- What happens when the ontology is updated — which files need re-enrichment?

Without answering these, `semantic_accuracy` is uncomputable, `ecle_enrich` is partially specified, and Phase 2 cannot ship domain-aware queries.

---

### Decision

The domain ontology is a **three-layer vocabulary system** — a base vocabulary (shipped with ECLE), an optional tenant vocabulary (customer-provided), and auto-derived cluster labels (computed from code structure). All three are versioned, traceable, and hot-reloadable.

#### Layer 1 — Base vocabulary (shipped with ECLE)

A curated set of cross-industry domain concept stems. Stored in `src/ecle/ontology/base_vocabulary/`.

Structure:
```
src/ecle/ontology/base_vocabulary/
  financial.yaml          # billing, payment, settlement, ledger, reconciliation...
  data_access.yaml        # read, write, transaction, query, fetch, persist...
  orchestration.yaml      # schedule, trigger, retry, queue, dispatch, worker...
  security.yaml           # auth, encrypt, token, session, permission, role...
  messaging.yaml          # publish, consume, topic, event, subscribe, emit...
  <domain>.yaml           # extensible by adding new YAML files
```

Each YAML file:
```yaml
domain: "financial"
version: "1.0"
concepts:
  - term: "billing-cycle"
    stems: ["bill", "cycl", "period", "invoic"]
    related: ["payment", "settlement"]
    tier1_code_signals: ["function_name_patterns", "table_name_patterns"]
  - term: "payment-gateway"
    stems: ["payment", "gateway", "charg", "transact"]
    ...
```

**Version:** `base_vocabulary` is tagged by ECLE release version. Changing base vocabulary bumps `ECLE_ONTOLOGY_BASE_VERSION`.

#### Layer 2 — Tenant vocabulary (customer-provided)

Customers can extend the ontology for their domain without modifying ECLE code. Stored in the tenant's artifact store at `ontology/{tenant_id}/vocabulary.yaml`.

Format: same schema as base vocabulary. Terms here override base vocabulary if they share a `term` key. New terms are additive.

**Hot-reload:** `POST /admin/v1/ontology/reload` triggers `language_pack.reloaded`-equivalent event for ontology, causing `ontology_enricher` to re-run on all clusters with `semantic_accuracy < 1.0`.

**Version:** tenant vocabulary has its own `tenant_vocabulary_version` string (admin-set label like `"v3"` or `"2026-Q1"`). Stored in `tenant_config`.

#### Layer 3 — Auto-derived cluster labels (computed)

When a cluster has no strong vocabulary match (neither base nor tenant vocabulary produces `enrichment_confidence ≥ 0.5`), `ontology_enricher` derives a label from the cluster's dominant function names and table names using term frequency:

```
auto_label = top_3_tf_idf_terms_from_cluster_function_names + table_names
```

Auto-derived labels are stored in `cluster_assignments.domain_concepts[]` prefixed with `"auto:"` to distinguish them from vocabulary-matched concepts (e.g. `"auto:payment_batch_process"`).

Auto-derived labels have `semantic_accuracy = 0.5` (a fixed lower ceiling for auto-derived terms — they are useful for navigation but are not authoritative domain vocabulary). Vocabulary-matched concepts have `semantic_accuracy` computed from the match confidence score.

#### `ontology_version` in FACT envelope

```json
"semantic": {
  "ontology_version": "ecle-base@1.2+acme-vocab@v3"
}
```

Format: `"{base_version}+{tenant_version}"` (omit tenant part if no tenant vocabulary).

When the ontology version changes, all files with `semantic_accuracy > 0` are queued for re-enrichment via `reindex.requested` event (low-priority queue). Re-enrichment does not re-parse or re-embed — it only re-runs `ontology_enricher` using the updated vocabulary.

#### `ontology_enricher` worker — full SRP definition

**SRP:** Consume `topology.updated { recompute: true }` events → for each affected cluster → compute domain concept matches → write to `cluster_assignments.domain_concepts[]` and `concept_stems[]` → compute per-file `semantic_accuracy`.

**Algorithm (per cluster):**

```
For each cluster in changed_cluster_ids:
    1. Collect all function names, table names, entry point names for files in cluster
    2. For each concept in (base_vocabulary + tenant_vocabulary):
         match_score = weighted_overlap(concept.stems, tokenized_names)
    3. threshold = ONTOLOGY_MATCH_THRESHOLD (default: 0.3)
    4. domain_concepts = [concept.term for concept if match_score >= threshold]
                         sorted by match_score descending
    5. concept_stems = flatten([concept.stems for concept in domain_concepts])
    6. If len(domain_concepts) == 0:
         auto_label = derive_label_from_tf_idf(function_names, table_names)
         domain_concepts = ["auto:" + auto_label]
         semantic_accuracy = 0.5
    7. Else:
         semantic_accuracy = min(1.0, max(match_scores)) × fidelity_ceiling
    8. Upsert cluster_assignments: domain_concepts, concept_stems, semantic_accuracy
    9. Update file_facts.semantic_accuracy for all files in cluster
   10. Emit ontology.enriched { cluster_id, concept_count, semantic_accuracy }
```

**What `ontology_enricher` does NOT do:**
- Does not embed ontology terms into vectors (Term 1-domain rule — exact lookup, not similarity)
- Does not generate concept descriptions (no LLM)
- Does not modify function names or code facts
- Does not run on every `topology.updated` — only when `recompute: true` (contract 09 fix already applied)

#### `ontology_version` decay trigger

When `ECLE_ONTOLOGY_BASE_VERSION` or `tenant_vocabulary_version` changes:
1. All `cluster_assignments` rows for the tenant have `semantic_accuracy` set to `null` (unenriched state).
2. All affected files have `semantic_accuracy = null` in `file_facts`.
3. Batch re-enrichment queued via `reindex.requested` events (one per cluster, low-priority).
4. Queries during re-enrichment return `semantic_accuracy: null` and `semantic_caveat: "Domain vocabulary updated — re-enrichment in progress"`.

This prevents stale domain labels from being served as accurate after an ontology update.

#### DSL patterns — relationship to ontology

`dsl_patterns` in the FACT envelope come from `detect_dsl_mappings` worker (ADR-0012), not from `ontology_enricher`. The distinction:

| | `dsl_patterns` | `domain_concepts` |
|---|---|---|
| **Source** | `detect_dsl_mappings` (code structure patterns) | `ontology_enricher` (vocabulary matching) |
| **Example** | `"DataWindow:unbuffered-fetch"` | `"billing-cycle"` |
| **Granularity** | File-level | Cluster-level |
| **Basis** | Syntactic pattern match in extraction rules | Semantic overlap with vocabulary stems |
| **Authority** | Tier 1-code (structural fact) | Tier 2-derived (vocabulary match) |

`dsl_patterns` are structural facts extracted by the language pack. `domain_concepts` are semantic annotations applied by the ontology enricher. They are complementary, not redundant.

---

### Consequences

**Positive:**
- `semantic_accuracy` is now fully computable — the confidence dimension is no longer a specification placeholder
- Base vocabulary provides immediate value on day 1 (financial, data_access, messaging domains pre-loaded)
- Tenant vocabulary extension is self-service via Admin API + YAML — no ECLE code changes needed
- `ontology_version` in FACT envelope makes domain annotation provenance fully traceable
- Auto-derived labels ensure no cluster is ever unlabeled — worst case is an auto-label, not a null

**Negative / Trade-offs:**
- Tenant vocabulary management is a new operational concern — customers must maintain their YAML as their domain evolves. Stale tenant vocabulary produces stale domain labels. `ontology_version` decay trigger handles this.
- Batch re-enrichment after vocabulary updates is O(cluster_count) — for a 1K-cluster deployment, expect ~10 minutes re-enrichment time.
- Auto-derived labels (Layer 3) are inherently less precise than vocabulary-matched concepts. They should be treated as navigation hints, not authoritative domain claims.

**Neutral / Operational notes:**
- `ONTOLOGY_MATCH_THRESHOLD` (default: 0.3) is tunable via Admin API config overrides. Lower threshold = more concepts matched per cluster = higher recall, lower precision.
- Base vocabulary ships in `src/ecle/ontology/base_vocabulary/` and is updated with ECLE releases. Tenant vocabulary lives in artifact store and survives ECLE upgrades.
- `ontology_enricher` is a Kafka consumer worker (Tier 1/2/3 — all tiers) with one consumer group.

---

### Alternatives Considered

| Alternative | Why Rejected |
|-------------|-------------|
| LLM-generated cluster labels | Violates no-LLM-at-any-layer rule; non-deterministic; cannot be versioned |
| External knowledge graph (e.g. Wikidata) | External dependency; latency; not air-gap safe; over-engineered for code domain vocabulary |
| Embedding-based vocabulary matching | Approximate matching appropriate for Tier 2 similarity queries; domain concept labeling requires precision; exact stem overlap is sufficient and fast |
| No ontology (structural facts only) | `semantic_accuracy` dimension is uncomputable; `ecle_enrich` vocabulary alignment step has no vocabulary to align to; domain queries degrade to keyword search |

---

### Compliance

- Contract: `constitution/contracts/05-confidence-contract.md` — `semantic_accuracy` computation defined
- Contract: `constitution/contracts/09-event-pipeline-contract.md` — `ontology_enricher` SRP fully defined; `ontology.enriched` event payload
- Contract: `constitution/contracts/11-mcp-contract.md` — `ecle_enrich` step vocabulary source
- ADR: `ADR-0012` — `detect_dsl_mappings` relationship to ontology enrichment clarified
- ADR: `ADR-0018` — `enrich` step Pass 3 (cluster stem overlap) uses `concept_stems[]` from this ADR

---

### References

| # | Citation | Relevance to this ADR |
|---|----------|----------------------|
| R1 | W3C SKOS (Simple Knowledge Organization System), 2009 Recommendation (w3.org/TR/skos-reference/) | W3C standard for concept schemes with broader/narrower/related relationships; ECLE's vocabulary YAML is a practical simplification of SKOS |
| R2 | W3C OWL 2 Web Ontology Language, 2012 Recommendation (w3.org/TR/owl2-overview/) | Formal ontology standard; validates three-layer vocabulary approach (base + extension + derived) |
| R3 | Gruber, T. "A Translation Approach to Portable Ontology Specifications", Knowledge Acquisition 1993 | Foundational ontology paper: "an ontology is a specification of a conceptualization" — ECLE's base vocabulary is exactly this |
| R4 | Guarino, N. "Formal Ontology in Information Systems", IOS Press 1998 | Formal basis for domain ontology design; validates separating structural facts from semantic annotations |
