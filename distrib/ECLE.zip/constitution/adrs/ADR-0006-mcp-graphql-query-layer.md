# ADR-0006: MCP + GraphQL Query Layer

**Status:** Accepted  
**Date:** 2026-05-05  
**Deciders:** Lead Engineer, Architecture Review  
**Supersedes:** —  
**Superseded by:** —  
**Amended by:** ADR-0014 (semantic-first query planning — replaces query planner heuristic defined here)

---

### FACT Impact

| Dimension | Impact |
|-----------|--------|
| **Fast** | `improves` — HTTP loopback latency is equivalent to stdio for local dev; multi-client support eliminates process contention; 2-second hard timeout enforced at transport layer from Phase 1; GraphQL adds one thin in-process resolver hop with no measurable latency at local scale |
| **Accurate** | `improves` — all MCP tools route through the same GraphQL resolver path from Phase 1; no per-tool routing divergence; centralised schema validation on every query |
| **Complete** | `improves` — all three backends wired from Phase 1; no capability gaps due to deferred resolvers; tool delivery is progressive but resolver layer is complete; multi-client HTTP eliminates single-consumer stdio bottleneck |
| **Trustworthy** | `improves` — `X-Tenant-Id` header validated from Phase 1; `X-Request-Id` enables end-to-end log correlation from first deployment; no auth-less stdio surface in any tier |

---

### Context

ECLE 2.0 must expose its structured knowledge to AI agents (GitHub Copilot, Claude,
Cursor, custom agents). The query layer sits between all consumers and the three storage
backends (Structured DB, Vector Index, Topology Graph).

Three design questions need recording:

1. **Why MCP** — what protocol exposes ECLE tools to AI agents?
2. **Why GraphQL over REST** — what is the query interface between MCP tools and backends?
3. **Why HTTP from Phase 1** — why not stdio for local dev then HTTP later?
4. **Why direct `IStructuredDB` in Phase 1, then GraphQL in Phase 3** — why defer the
   query planner?

**Why not REST:** REST requires a separate endpoint per query type. ECLE has 13 named
tool queries across three backends. REST would produce 13+ endpoints, each with its own
routing logic, response shape, and FACT envelope assembly — duplicating logic and
violating DRY. GraphQL field selection means each MCP tool fetches exactly what it needs
in one query; no over-fetching.

**Why not direct DB in production:** Workers call `IStructuredDB` directly; that is fine
for ingestion. But query-time routing (semantic / structured / composite) based on query
intent must be centralised — otherwise every MCP tool duplicates the routing decision.
See ADR-0014 for the three query modes and caller-provided intent protocol.

**Why MCP:** MCP is the emerging standard protocol for exposing tools to LLM-based AI
agents. It provides tool discovery, input schema validation, and structured output — all
without ECLE knowing which agent is calling it. The MCP server is stateless: it receives
a tool call, queries the backend, wraps in a FACT envelope, returns. No session state.

**Why HTTP from Phase 1, not stdio:** stdio binds the MCP server to a single calling
process — VS Code and a CLI tool cannot share the same server. A Phase 1 stdio server
would require a Phase 2 transport migration, changing every agent's configuration. HTTP
loopback (`localhost:4000`) has equivalent latency to stdio for local dev. HTTP also
allows tenant header validation (`X-Tenant-Id`) and request correlation (`X-Request-Id`)
from the first deployment — capabilities that cannot be added to stdio without a
protocol redesign. One transport, all phases, all tiers.

---

### Decision

We will implement a **two-layer query architecture** with **HTTP transport, GraphQL, and all three backends from Phase 1**:

**Phase 1 (SPEC-0007):**  
MCP server → HTTP (`localhost:4000`) → `POST /graphql` → Strawberry resolver → `IStructuredDB` | `IVectorStore` | `ITopologyGraph`.  
All three backends are wired from Phase 1. Resolvers for structured, vector, and graph
queries are implemented — no stubs, no deferred `not_implemented` paths. The Phase 1
scope boundary is which **tools** are implemented, not which backends the resolver layer
supports. Tools shipped in Phase 1 use structured queries; tools shipped in Phase 2 add
vector queries; Phase 3 adds graph traversal. The resolver layer accommodates all three
from the start.

**Progressive tool delivery (not backend gating):**

| Phase | Tools shipped | Resolvers active |
|-------|-------------|------------------|
| 1 | `ecle_find_files`, `ecle_find_functions`, `ecle_find_tables`, `ecle_find_callers`, `ecle_find_entry_points`, `ecle_repo_summary` | `IStructuredDB` |
| 2 | `ecle_search`, `ecle_find_similar`, `ecle_find_duplicates`, `ecle_search_docs`, `ecle_shared_artifacts` | + `IVectorStore` |
| 3 | `ecle_impact`, `ecle_trace_path`, `ecle_trace_data`, `ecle_view_database`, `ecle_view_api_contracts`, `ecle_cross_repo_links` | + `ITopologyGraph` |

**GraphQL design:**
- Framework: Strawberry (Python, type-safe, code-first schema)
- Single endpoint: `POST /graphql`
- Schema is the single contract between MCP and backends — swapping a backend requires
  zero changes to the GraphQL schema or MCP tools
- Query planner routing: determined by `query_intent` argument passed by the calling LLM
  agent (`"explore"` → semantic, `"locate"` → composite, `"precise"` → structured);
  falls back to heuristic argument inspection when `query_intent` is absent.
  Full routing specification in ADR-0014.

**MCP server design:**
- Transport: **HTTP only, all phases and all tiers** (see Contract 11 §7 for full HTTP surface spec)
- Endpoint: `POST /mcp` (JSON-RPC 2.0); `GET /health`; `GET /metrics`
- Default port: `4000` (overridable via `MCP_PORT`)
- Stateless — no session state between calls; horizontally scalable from day one
- Entry point: `python -m ecle.mcp.server`
- Every tool response is the FACT envelope (per `constitution/contracts/04-fact-contract.md`)
- MCP tools MUST NOT return raw DB rows — always wrapped in FACT envelope
- `X-Tenant-Id` header validated on every request, all phases
- `X-Request-Id` header echoed in every response for log correlation
- Auth (`Authorization: Bearer`) required Phase 2+; skipped in dev tier when `MCP_AUTH_DISABLED=true`

---

### Consequences

**Positive:**

- MCP tool signatures and HTTP surface are frozen from Phase 1 — agents built in Phase 1 work unchanged in Phase 2 and 3
- All three backends wired from Phase 1 — adding a Phase 2 or Phase 3 tool is a new tool + new resolver, never a backend migration
- No routing logic in any MCP tool — tools call GraphQL, resolvers route; one place to change routing behaviour
- Multi-client HTTP from Phase 1 — VS Code, Cursor, CLI, and agents query simultaneously
- Tenant isolation and request correlation enforced at transport from the first deployment
- Strawberry code-first schema: schema is generated from Python types, always in sync with implementation, no separate SDL file to maintain
- Backend swap (SQLite → PostgreSQL, ChromaDB → Qdrant) requires implementing a new `IStructuredDB` / `IVectorStore` — zero changes to GraphQL schema or MCP tools

**Negative / Trade-offs:**

- **Schema discipline required from day one** — because the schema is the contract, a careless field rename or type change in Phase 1 breaks all tools. Schema changes require explicit PR review. This is the right constraint but adds friction.
- **Three backends wired in Phase 1 means Phase 1 is not the simplest possible implementation** — `IVectorStore` and `ITopologyGraph` must have working Phase 1 implementations (ChromaDB local, SQL-CTE graph), not mocks. This is accepted: the backends are well-scoped and the interfaces are thin.
- **Strawberry in-process GraphQL adds one function call boundary** between MCP and the DB — not a network hop, but an extra call stack frame. Negligible at any realistic scale; measurable only under synthetic microbenchmark.
- **GraphQL introspection must be disabled in Tier 2/3** — introspection exposes the full schema to any caller; fine in dev, a security surface in production. Requires explicit config (`GRAPHQL_INTROSPECTION=false`).

**Neutral / Operational notes:**

- The MCP server and GraphQL resolver run in the same process — not two separate services. `POST /graphql` is an in-process call, not a network call.
- The FastAPI app (ingestion API) is a separate process; MCP server and FastAPI do not share a port.
- In docker-compose: one container for FastAPI (`:8000`), one for MCP+GraphQL (`:4000`), one per worker.
- Introspection enabled in Tier 1 dev (`GRAPHQL_INTROSPECTION=true` default); disabled in Tier 2/3.

---

### Alternatives Considered

| Alternative | Why Rejected |
|-------------|-------------|
| REST API only (no GraphQL) | 13+ endpoints; duplicated routing and FACT envelope assembly per endpoint; over-fetching; DRY violation |
| Direct tool-to-DB in all phases (no GraphQL ever) | Routing logic duplicated in every tool; adding a backend requires changing all tools; no centralised schema contract |
| gRPC instead of GraphQL | Binary protocol; harder to inspect in dev; GraphQL introspection and Strawberry type generation better match the self-documenting tool discovery pattern MCP requires |
| OpenAPI/Swagger instead of MCP | OpenAPI is a human-facing API contract; MCP provides tool discovery, input schema, and structured output natively for LLM agent consumption |
| Full REST + OpenAPI (no MCP) | Correct for browser/human clients; wrong protocol for LLM agent tool consumption |
| **GraphQL deferred to Phase 3** | Phase 1 tools would call `IStructuredDB` directly — routing logic duplicated across all tools; Phase 3 migration would require changing every tool internally; rejected because it creates the migration problem it was trying to defer |
| **Stubs/not_implemented for Phase 1 vector+graph resolvers** | Stubs produce silent capability gaps; a Phase 1 agent calling `ecle_search` would get an error with no clear upgrade path; all three backends are implementable in Phase 1 with their local implementations (ChromaDB, SQL CTEs) — there is no technical reason to defer them |
| **stdio for Phase 1, HTTP for Phase 2** | stdio binds the server to a single process; no multi-client support; requires a transport migration in Phase 2 that changes every agent's configuration; HTTP loopback has equivalent latency with none of the limitations |

---

### Compliance

- Contract: `constitution/contracts/04-fact-contract.md` (FACT envelope on every MCP response)
- Contract: `constitution/contracts/11-mcp-contract.md` (MCP tool rules; §11 caller intent protocol)
- Contract: `constitution/contracts/06-grounding-contract.md` (Layer 4 = GraphQL/MCP results)
- Eval: `eval_grounding_coverage` — MCP tool results must cite evidence
- ADR-0003: Three-Backend Architecture — GraphQL query planner routes between the three backends defined there
- ADR-0014: Semantic-first query planning — amends the routing heuristic defined in this ADR
