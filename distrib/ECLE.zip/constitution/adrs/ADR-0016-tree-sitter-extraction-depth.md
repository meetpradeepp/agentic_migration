# ADR-0016: Tree-Sitter Extraction Depth Standard

**Status:** Accepted  
**Date:** 2026-05-06  
**Deciders:** Lead Engineer, Architecture Review  
**Supersedes:** —  
**Superseded by:** —  
**Related:** ADR-0002, ADR-0012, ADR-0015, Contract 08

---

### FACT Impact

| Dimension | Impact |
|-----------|--------|
| **Fast** | `neutral` — tree-sitter grammar traversal is significantly faster than Joern's JVM-based CPG; extraction depth is now bounded by grammar rules, not JVM heap size |
| **Accurate** | `improves` — extraction depth is declared per language pack via `extraction_depth` manifest fields; queries can filter for `extraction_fidelity=FULL` packs; partial packs surface gaps explicitly rather than silently missing fields |
| **Complete** | `improves` — all 9 extraction categories are required from Full packs; the eval benchmark (`eval_fidelity_ceiling`) validates against a fixed reference corpus; no silent gaps |
| **Trustworthy** | `improves` — `extraction_fidelity` field on every `file_facts` row (FULL / PARTIAL / HEURISTIC) tells callers the quality of the extraction; grounding contract (06) cites extractor version in every lineage item |

---

### Context

AMF (ECLE's predecessor) used **Joern** — a JVM-based code property graph tool — to
extract deep structural facts from source code. Joern provides:

- Full function signatures (name, parameters with types, return type)
- Complete call graphs (caller, callee, call type: direct/indirect/dynamic)
- SQL statement extraction (table name, operation, raw statement)
- Data flow edges (PDG — program dependence graph)
- Import/dependency graph
- Error handling patterns (try/catch structure, error propagation)
- Cyclomatic complexity and execution model detection
- Entry point identification (main functions, handlers, batch triggers)

ECLE 2.0 replaces Joern with **tree-sitter** + **extractor.sc** scripts + **Python
utilities**. The reasons:

| Reason | Detail |
|--------|--------|
| Joern requires JVM | Adds ~500 MB runtime dependency; complicates air-gapped packaging |
| Joern memory usage | Full CPG for a 10K-file repo can exceed 16 GB heap |
| Joern PDG is slow | Program Dependence Graph computation is O(N²) for large files |
| tree-sitter is incremental | Grammar traversal only re-parses changed files; Joern re-analyzes the full CPG |
| tree-sitter packs are modular | Each language is an independent grammar; new language = new grammar, not Joern plugin |
| Air-gapped deployment | tree-sitter compiles to native; no JVM, no remote repos needed |

**The risk:** switching away from Joern could silently reduce extraction depth, making
ECLE's knowledge shallower than AMF's. This ADR establishes that extraction depth is
a **contractual standard** — tree-sitter packs MUST extract equivalent depth. The
mechanism is different (grammar traversal + extractor rules instead of CPG); the
extracted facts are the same.

---

### Decision

#### The 9 extraction categories — required from all `full` packs

Every language pack claiming `extraction_depth: full` MUST extract all 9 categories
for every source file it processes:

---

**Category 1: Function signatures**

```json
{
  "id": 107374182400,
  "name": "calculate_fee",
  "returnType": "integer",
  "args": ["amount", "fee_code"],
  "variables": [],
  "start_line": 42,
  "end_line": 89,
  "complexity": 7,
  "snippet": ""
}
```

Field `returnType` uses camelCase to match AMF extractor.sc Scala output. `persist_facts` normalises to `return_type` snake_case in the DB. `execution_model` is derived from `entry_points` detection, not stored on the function itself.

---

**Category 2: Call edges**

```json
{
  "caller_function": "calculate_fee",
  "callee_name": "get_rate_table",
  "call_type": "direct",
  "line_number": 56
}
```

`call_type` values: `direct` (static call to named function), `indirect` (call through
function pointer or variable), `dynamic` (runtime dispatch — e.g., virtual calls, reflection).

For languages where indirect/dynamic calls cannot be resolved statically, `callee_name`
is set to `"__unresolved__"` and `call_type` to `"dynamic"`. This is an explicit gap,
not a silent omission.

---

**Category 3: SQL statements**

```json
{
  "table_name": "UNRATED_CDRS",
  "operation": "READ",
  "raw_statement": "SELECT * FROM UNRATED_CDRS WHERE STATUS = 'P'",
  "line_number": 102
}
```

`operation` values: `READ` (SELECT), `WRITE` (INSERT/UPDATE/DELETE/MERGE), `DDL`
(CREATE/ALTER/DROP), `READWRITE` (transaction that does both).

`raw_statement` is truncated to 512 characters. Embedded SQL in Pro*C, COBOL EXEC SQL
blocks, and JDBC strings are all treated identically — the statement is extracted
regardless of embedding mechanism.

---

**Category 4: Imports and dependencies**

```json
{
  "imported_path": "billing/rate_engine.h",
  "import_type": "include",
  "line_number": 3
}
```

`import_type` values: `module` (Python import, Java import), `include` (C/C++ #include),
`require` (Node.js require/import), `copy` (COBOL COPY), `exec_sql` (Pro*C embedded SQL
dependency), `package_ref` (Go module, Java Maven dependency).

---

**Category 5: Error handling patterns**

```json
{
  "try_catch_blocks": 3,
  "error_types_caught": ["IOException", "SQLException", "RuntimeException"],
  "propagation_pattern": "rethrow",
  "unhandled_count": 1
}
```

`propagation_pattern` values: `swallow` (catch and discard), `log_only` (catch and log),
`rethrow` (catch and re-throw), `transform` (catch and throw different type), `none`
(no error handling detected).

For languages without try/catch (C, COBOL, Pro*C), error handling is detected via
`errno` checks, `SQLCODE` checks, and return code validation patterns.

---

**Category 6: Entry points**

```json
{
  "entry_point_name": "main",
  "entry_point_type": "batch_main",
  "signature": "int main(int argc, char** argv)"
}
```

`entry_point_type` values per `execution_model` detection rules. A file may have
multiple entry points (e.g., a service handler file with multiple HTTP verb handlers).

---

**Category 7: Data flow markers (structural inference — not PDG)**

Joern's Program Dependence Graph (PDG) computes precise data flow at the variable level.
This is O(N²) and replaced in ECLE by **structural data flow markers**:

```json
{
  "data_writes": [{"id": 1, "target": "ll_result", "line": 43, "origin": "sql"}],
  "data_reads":  [{"id": 2, "source": "\"TestApp\"", "line": 31, "origin": "assignment"}]
}
```

`origin` values: `assignment` (LHS/RHS of an assignment statement), `sql` (SQL INTO or WHERE host variable), `datawindow` (DataWindow SetItem/GetItem call — PB-specific).

**Topology edges (ADR-0007) encode the same information at the graph level:**
`WRITE_READ` edges connect the files that write tables to files that read them.
`SERVICE_CALL` edges connect caller files to callee services.
This is equivalent to Joern's interprocedural data flow for the architecture-level
questions ECLE answers ("what touches this table?", "what depends on this service?").
Fine-grained variable-level data flow is explicitly out of scope.

---

**Category 8: Metrics**

Metrics computed by a separate `metrics.sc` script (not `extractor.sc`), written to a
separate `metrics.json` file. See `schemas/metrics-schema.json`. Decoupled from facts
so metric computation failures do not block fact ingestion.

```json
{
  "function_count": 12,
  "total_lines": 847,
  "code_lines": 612,
  "comment_lines": 127,
  "avg_cyclomatic_complexity": 4.2,
  "max_cyclomatic_complexity": 17,
  "sql_statement_count": 8,
  "call_edge_count": 34
}
```

These are file-level aggregates. They feed the `file_facts.cyclomatic_complexity`
field and the confidence profile.

---

**Category 9: Execution model and concurrency markers**

Derived from `entry_points` detection rules in `detection_rules/{language}/execution_model.yaml`.
Expressed as the `entry_point_type` on each entry point: `batch_main`, `event_handler`,
`service_handler`, `scheduled`, `library`. In PowerBuilder every function/event is a
public entry point — the `entry_points.py` FSS extractor promotes all functions.

---

#### Execution sequence — Hierarchical Semantic Spine

The `execution_sequence` array is the lossless execution spine with parent→child AST
relationships. Each node uses `node_type` (not `op`) matching the tree-sitter / CPG node
taxonomy as produced by AMF extractor.sc v5.3+:

```json
{
  "id": 30064771072,
  "line": 43,
  "node_type": "CALL",
  "enclosing_method": "gf_get_user",
  "parent_node_id": 107374182400,
  "code": "select user_id into :ll_result from users where active = 'Y' using sqlca;"
}
```

`node_type` values: `CALL`, `RETURN`, `LITERAL`, `IDENTIFIER`, `CONTROL_STRUCTURE`,
`ASSIGNMENT`, `UNKNOWN`. `parent_node_id` references the `id` of the parent node in the
same array (null for root nodes). `UNKNOWN` is used for `DYNAMIC_SQL_RESOLVED` nodes.

**IMPORTANT:** The field is `node_type`, not `op`. The ECLE 2.0 base schema uses
`node_type` throughout. Any pack writing `op` instead will fail `eval_schema_conformance`.

---

#### `extraction_depth` declaration in pack manifest

Every language pack's `manifest.yaml` MUST declare `extraction_depth` per category:

```yaml
extraction_depth:
  function_signatures: full       # all 9 fields extracted
  call_edges: full
  sql_statements: full
  imports: full
  error_handling: partial         # try/catch detected; propagation_pattern heuristic only
  entry_points: full
  data_flow_markers: full
  metrics: full
  execution_model: partial        # execution_model detected; concurrency_model heuristic
```

Valid values per category: `full` | `partial` | `heuristic` | `none`.

| Value | Meaning |
|-------|---------|
| `full` | All fields in the category are extracted with deterministic accuracy |
| `partial` | Most fields extracted; some require heuristic inference (documented in pack README) |
| `heuristic` | Fields are estimated from surrounding patterns; not guaranteed accurate |
| `none` | Category not applicable for this language (e.g., `sql_statements: none` for HTML) |

**`extraction_fidelity` on `file_facts`:**

The overall `extraction_fidelity` for a file is the minimum across all applicable
categories:
- All applicable categories = `full` → `extraction_fidelity = FULL`
- Any applicable category = `partial` → `extraction_fidelity = PARTIAL`
- Any applicable category = `heuristic` → `extraction_fidelity = HEURISTIC`
- Any applicable category = `none` (and the file uses that feature) → `extraction_fidelity = PARTIAL`

---

#### Eval benchmark — `eval_fidelity_ceiling`

Packs claiming `full` for a category are evaluated against a fixed reference corpus:

```
eval corpus: 50 files per language, hand-annotated ground truth
eval metric: precision + recall per extraction category
pass threshold: precision ≥ 0.95, recall ≥ 0.90 for all 'full' categories
```

`eval_fidelity_ceiling` runs nightly. A pack that drops below threshold for a `full`
category has its manifest automatically downgraded to `partial` for that category until
the pack maintainer fixes and re-passes the benchmark.

---

#### Language packs in scope — AMF-derived, Joern-to-tree-sitter migration status

All language packs exist in AMF today. ECLE 2.0 directly migrates them. Every pack has
both a `fast_extractor.py` (tree-sitter, primary target) and a legacy `extractor.sc`
(Joern, kept as reference/fallback during transition).

**Parser model per language (as at AMF):**

| Language | `language_id` | Extensions | Joern `parser_id` | Tree-sitter grammar | AMF fast_extractor.py | ECLE 2.0 primary |
|----------|--------------|------------|-------------------|--------------------|-----------------------|------------------|
| PowerBuilder | `powerbuilder` | `.srw .sru .srf .srm .srs .srd .sra .srp .srq` | `powerscript` | `tree-sitter-powerbuilder` | ✅ exists (`fast_extractor.py`) | **tree-sitter** |
| Pro\*C | `proc` | `.pc .ppc` | `proc` (C grammar after sanitizer) | `tree-sitter-c` | ✅ exists | **tree-sitter** |
| C | `c` | `.c` | `joern` | `tree-sitter-c` | ✅ exists (shared `c_family_extractors.py`) | **tree-sitter** |
| C++ | `cpp` | `.cpp .cxx .cc .h .hpp` | `joern` | `tree-sitter-cpp` | ✅ exists | **tree-sitter** |
| Java | `java` | `.java` | `joern --language javasrc` | `tree-sitter-java` | ✅ exists | **tree-sitter** |
| Python | `python` | `.py` | `joern` | `tree-sitter-python` | ✅ exists | **tree-sitter** |
| JavaScript/TypeScript | `javascript` | `.js .jsx .ts .tsx` | `joern --language jssrc` | `tree-sitter-javascript` | ✅ exists | **tree-sitter** |
| C# | `csharp` | `.cs` | `joern --language csharpsrc` | `tree-sitter-c-sharp` | ✅ exists | **tree-sitter** |
| Go | `go` | `.go` | `joern --language go` | `tree-sitter-go` | ✅ exists | **tree-sitter** |

**FSS extractor modules** (in `extractors/` subdirectory, auto-discovered by `BaseLanguage.get_extractor()`):

| Extractor name | Purpose | PB | Pro*C | C/C++ |
|----------------|---------|----|---------|---------|
| `data_access` | DB reads/writes/transaction ops | ✅ | ✅ | ✅ |
| `entry_points` | Entry point detection | ✅ | ✅ | ✅ |
| `conditionals` | Branch/control-flow analysis | ✅ | ✅ | ✅ |
| `temporal` | Time-dependent operations | ✅ | ✅ | ✅ |
| `termination` | Return/exit path analysis | ✅ | ✅ | ✅ |
| `side_effects` | I/O, globals, state mutations | ✅ | ✅ | ✅ |
| `external_calls` | DLL/service/API call detection | ✅ | — | — |

FSS extractor names are registered in `BaseLanguage.EXTRACTOR_NAMES`. ECLE 2.0 language
packs MUST use the same extractor names — no renaming.

**Known partial categories per language (tree-sitter path):**

| Language | Partial/heuristic categories | Reason |
|----------|------------------------------|--------|
| PowerBuilder | `data_flow_markers` (partial) | DataWindow SQL extraction is heuristic (`.describe()` calls, not inline SQL) |
| Pro\*C | `call_edges` (partial) | Pointer-function calls cannot be statically resolved by tree-sitter-c |
| C | `error_handling` (partial), `concurrency_model` (heuristic) | `errno` / signal patterns require heuristic pattern matching |
| C++ | `concurrency_model` (heuristic) | `std::thread` / OpenMP patterns are heuristic |
| JavaScript | `call_edges` (partial) | Dynamic dispatch and prototype chain calls common |
| Java | All full | Spring/JDBC patterns fully covered by tree-sitter-java |
| Python | All full | |
| C# | All full | |
| Go | All full | |

---

#### Joern-to-tree-sitter migration strategy

Joern is NOT removed from ECLE 2.0 immediately. The migration is incremental to avoid
regressions. The following rules govern the transition:

**Dual-pipeline rule (during transition):**
Each language pack runs `fast_extractor.py` (tree-sitter) as the **primary** path.
The Joern `extractor.sc` is retained in the pack folder as a **reference** and
**fallback** only. `extractor.sc` is NOT invoked in the normal pipeline — it is
only used:
1. By `eval_fidelity_ceiling` to compare tree-sitter output against Joern reference facts for the eval corpus.
2. As a manual fallback when a `fast_extractor.py` raises an unhandled exception
   (controlled by `EXTRACTION_JOERN_FALLBACK=true` env var, default `false`).

**Graduation criteria (tree-sitter fully replaces Joern for a language):**
1. `eval_fidelity_ceiling` passes: tree-sitter output precision ≥ 0.95, recall ≥ 0.90 vs Joern reference for all `full` categories.
2. No `extraction_errors` in the eval corpus run.
3. `fidelity=FULL` or `fidelity=PARTIAL` (as declared in manifest) matches actual output.
4. Pack maintainer explicitly sets `fact_extraction.joern_fallback: false` in `manifest.yaml`.

**Current graduation status:**

| Language | Tree-sitter graduated? | Notes |
|----------|----------------------|-------|
| PowerBuilder | ✅ Yes | `extractor.sc` v5.4 retained as reference; `fast_extractor.py` is primary |
| Pro\*C | ✅ Yes | Sanitizer converts `.pc`→`.c`; tree-sitter-c handles the rest |
| C | ✅ Yes | Shared `c_family_extractors.py` |
| C++ | ✅ Yes | Shared `c_family_extractors.py` + cpp extensions |
| Java | ✅ Yes | |
| Python | ✅ Yes | |
| JavaScript | ✅ Yes | |
| C# | ⚠️ In progress | `fast_extractor.py` exists; eval corpus not yet passing |
| Go | ⚠️ In progress | `fast_extractor.py` exists; eval corpus not yet passing |

Joern is removed from CI dependencies once ALL languages graduate.
Until then, Joern remains in the `requirements-dev.txt` but is NOT in `requirements.txt`
(not required at runtime in Tier 2/3).

---

### Alternatives Considered

| Alternative | Why Rejected |
|-------------|-------------|
| Keep Joern for deep extraction | JVM dependency, memory requirements, and O(N²) PDG cost conflict with FACT.Fast. Air-gapped packaging is significantly harder. |
| Use LLM to infer missing extraction depth | Violates no-LLM-at-any-layer principle. Non-deterministic. Cannot be included in grounding lineage. |
| Declare variable-level data flow as a goal | O(N²) per file; replaces topology edge model with per-variable graph; proven to be the AMF bottleneck. Structural data flow markers + topology edges cover 95% of the questions ECLE answers. |
| No extraction depth standard — let packs vary | Silent depth variation breaks the completeness guarantee. Callers have no way to know they're getting shallow facts. `extraction_fidelity` and the manifest standard make gaps visible and auditable. |

---

### Compliance

- ADR-0002: Language Pack Registry — pack manifest is extended with `extraction_depth` section; existing `manifest.yaml` contract amended
- ADR-0012: Multi-Level Language Detection — language detection (pass 1/2/3) is prerequisite to pack selection; this ADR governs what the selected pack must produce
- ADR-0015: Three-Axis Onboard Model — this ADR applies to `content_type=code` only
- Contract 06: Grounding Contract — `extractor_version` in lineage maps to the pack that produced the extraction; `extraction_fidelity` maps to the tier 1-code authority level
- Contract 08: Language Pack Contract — `extraction_depth` section added to manifest spec
- Contract 15: DB Schema — `file_facts.extraction_fidelity` column stores the computed fidelity level

---

### References

| # | Citation | Relevance to this ADR |
|---|----------|----------------------|
| R1 | Brunsfeld, M. "Tree-sitter — A new parsing system for programming tools", Strange Loop 2018 | Tree-sitter creator's talk; validates incremental parsing for code intelligence tooling |
| R2 | Wagner, T. & Graham, S. "Efficient and Flexible Incremental Parsing", UC Berkeley 1998 | Academic foundation for tree-sitter's incremental parsing algorithm |
| R3 | Wagner, T. & Graham, S. "Incremental Analysis of Real Programming Languages", UC Berkeley 1997 | Extended incremental parsing to production languages; validates error-recovery approach |
| R4 | Paige, R. "Practical Algorithms for Incremental Software Development Environments", UC Berkeley 1997 | Foundational paper on incremental computation for dev tools; cited by tree-sitter docs |
| R5 | Tree-sitter (tree-sitter.github.io) — used by GitHub, Neovim, Zed, Helix, Semgrep | Industry adoption validates tree-sitter as the standard for production code parsing |
| R6 | Microsoft Language Server Protocol (LSP) specification | Tree-sitter's design inspiration (per MCP spec docs); validates modular language pack pattern |
