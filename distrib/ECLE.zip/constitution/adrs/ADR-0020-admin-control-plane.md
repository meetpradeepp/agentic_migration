# ADR-0020: Admin Control Plane

**Status:** Accepted
**Date:** 2026-05-07
**Deciders:** Lead Engineer, Architecture Review
**Supersedes:** —
**Superseded by:** —
**Amends:** ADR-0006 (adds admin API surface alongside MCP), ADR-0015 (onboard model — admin API is the onboard trigger)
**FACT impact:**
- Fast: `neutral` — admin operations are low-frequency; not on the query hot path
- Accurate: `neutral` — admin operations configure data sources, not extract facts
- Complete: `improves` — operators can inspect indexing state, coverage gaps, and repo health without direct DB access; coverage gaps are actionable through the admin API
- Trustworthy: `improves` — every admin operation is authenticated (`admin` scope — ADR-0019), audited in `query_audit_log`, and traceable; no side-channel DB mutations required for onboarding

---

### Context

ECLE 2.0 has no defined operational interface for the humans who run it. Currently:
- Tenant provisioning = direct DB insert into `repositories` table
- Repo onboarding = direct `POST /api/upload` with no structured workflow
- Config overrides = restart pods with new env vars
- Coverage gap response = read raw Kafka events or query `indexing_state` directly
- API key creation (ADR-0019) = no mechanism defined

Enterprise operators need a documented, authenticated, audited control plane that does not require database access or pod restarts for routine operations.

The Admin API is **not an LLM interface**. It is an operational REST API for human operators and CI/CD pipelines. It is separate from the MCP server (query surface) — different port, different auth scope, different rate limits.

---

### Decision

We will add an Admin API server (`src/ecle/admin/`) on a separate port (`ADMIN_PORT`, default: `4001`) that exposes structured REST endpoints for operational management. All endpoints require `admin` scope (ADR-0019).

#### Admin API surface

**Base URL:** `http://host:4001/admin/v1`

**Auth:** `Authorization: ApiKey <admin_key>` — must carry `admin` scope. `X-Tenant-Id` header required. System-level operations (tenant provisioning) require a system-admin key (not tenant-scoped, only creatable at bootstrap time).

---

##### Tenant Management (system-admin scope)

| Method | Path | Description |
|--------|------|-------------|
| `POST` | `/tenants` | Provision a new tenant |
| `GET` | `/tenants` | List all tenants |
| `GET` | `/tenants/{tenant_id}` | Get tenant details + health summary |
| `DELETE` | `/tenants/{tenant_id}` | Schedule tenant purge (ADR-0021) |

`POST /tenants` body:
```json
{
  "tenant_id": "acme",
  "display_name": "Acme Corp",
  "tier": "enterprise",
  "config_overrides": {}
}
```

Creates the tenant row in the `tenants` table. Does not create repos or API keys.

---

##### Repository Management (admin scope, tenant-scoped)

| Method | Path | Description |
|--------|------|-------------|
| `POST` | `/repos` | Onboard a new repository |
| `GET` | `/repos` | List repos with indexing status |
| `GET` | `/repos/{repo_id}` | Repo detail: status, file counts, coverage |
| `PATCH` | `/repos/{repo_id}` | Update `display_name` or `default_branch` (not `repo_role`) |
| `DELETE` | `/repos/{repo_id}` | Schedule repo data purge (ADR-0021) |
| `POST` | `/repos/{repo_id}/reindex` | Trigger full re-index (emits `reindex.requested` Kafka event) |

`POST /repos` body:
```json
{
  "repo_id":        "billing-service",
  "repo_name":      "Billing Service",
  "repo_role":      "module",
  "source_type":    "git",
  "source_ref":     "https://git.corp.com/billing.git",
  "default_branch": "main",
  "content_types":  ["code", "docs"]
}
```

`repo_role` is **set at creation and immutable** — consistent with ADR-0017. Changing `repo_role` requires `DELETE` + re-onboard.

---

##### API Key Management (admin scope, tenant-scoped)

| Method | Path | Description |
|--------|------|-------------|
| `POST` | `/keys` | Create a new API key — returns raw key exactly once |
| `GET` | `/keys` | List keys (hashes + metadata, never raw key) |
| `DELETE` | `/keys/{key_id}` | Revoke a key immediately |
| `PATCH` | `/keys/{key_id}` | Update label or expiry |

`POST /keys` response:
```json
{
  "key_id":    "uuid",
  "raw_key":   "ecle_k_<base64url_32_bytes>",   ← shown ONCE; not stored
  "label":     "VS Code extension prod",
  "scopes":    ["query"],
  "expires_at": null
}
```

---

##### Config Overrides (admin scope, tenant-scoped)

Runtime-tunable configuration that takes effect without pod restart. Stored in `tenant_config` table. Worker processes poll this table on a short TTL (default: 60 s). Pod restart is NOT required.

| Method | Path | Description |
|--------|------|-------------|
| `GET` | `/config` | List all active overrides for this tenant |
| `PUT` | `/config/{key}` | Set a config override value |
| `DELETE` | `/config/{key}` | Remove override (reverts to env var default) |

**Overridable config keys (runtime, no restart):**

| Key | Type | Default | Effect |
|-----|------|---------|--------|
| `LOUVAIN_RESOLUTION` | float | auto | Override γ for this tenant's repos |
| `LOUVAIN_MIN_CLUSTER_SIZE` | int | 2 | Singleton exclusion threshold |
| `LOUVAIN_DRIFT_THRESHOLD` | float | 0.05 | Centroid recompute trigger |
| `SEMANTIC_CASCADE_MAX_CLUSTERS` | int | 5 | Layer 3 cluster cap per cascade |
| `MAX_CROSS_REPO_REPOS` | int | tier-dependent | Cross-repo query scope cap |
| `COVERAGE_GAP_THRESHOLD` | int | 100 | Language pack miss alert threshold |
| `PLATFORM_INGEST_TIMEOUT` | int (minutes) | 30 | link_contracts wait timeout |
| `UPLOAD_MAX_BYTES` | int (bytes) | 524288000 | Max ZIP upload size (500 MB) |
| `UPLOAD_MAX_FILES` | int | 50000 | Max files allowed inside uploaded ZIP |
| `WORKER_{NAME}_MIN_REPLICAS` | int | see ADR-0027 table | KEDA min replica count for named worker |
| `WORKER_{NAME}_MAX_REPLICAS` | int | see ADR-0027 table | KEDA max replica count for named worker |
| `WORKER_{NAME}_LAG_THRESHOLD` | int | see ADR-0027 table | KEDA lag-per-replica trigger for named worker |

**Non-overridable at runtime** (require pod restart): `EMBEDDING_MODEL_NAME`, `EMBEDDING_DIM`, `STRUCTURED_BACKEND`, `VECTOR_BACKEND`, `KAFKA_BOOTSTRAP_SERVERS`. Changing these requires coordinated re-deployment.

---

##### ZIP Upload (admin scope, tenant-scoped)

| Method | Path | Description |
|--------|------|-------------|
| `POST` | `/upload` | Upload a ZIP of source files; creates an import job and triggers the ingestion pipeline |

`POST /upload` — `Content-Type: multipart/form-data`:

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `repo_id` | string | Yes | Target repository (must already exist in `repositories`) |
| `content_types` | string (comma-sep) | No | Override auto-detect: `code,docs,config,data,data-sql` |
| `repo_role` | string | No | `module` (default) or `platform` |
| `file` | binary | Yes | ZIP file; max `UPLOAD_MAX_BYTES` (default 500 MB) |

Response `202 Accepted`:
```json
{ "job_id": "uuid", "status": "pending" }
```

Behaviour:
1. Validate ZIP size ≤ `UPLOAD_MAX_BYTES`. Reject 413 if exceeded.
2. Save ZIP to `IArtifactStore` at path `uploads/{tenant_id}/{job_id}.zip`.
3. Write a row to `import_jobs` (status=`pending`).
4. Emit `upload.received` Kafka event → `scan_source` worker extracts the ZIP and continues the standard pipeline.
5. ZIP extraction happens in the `scan_source` worker — NOT in the Admin API process.

Note: When `source_type=git`, use `POST /repos` as before. `POST /upload` is exclusively for the ZIP/file-upload path from the Admin Portal.

---

##### Import Job Tracking (admin scope, tenant-scoped)

| Method | Path | Description |
|--------|------|-------------|
| `GET` | `/import-jobs` | List all import jobs (paginated) |
| `GET` | `/import-jobs/{job_id}` | Get one job's status, counts, error |
| `DELETE` | `/import-jobs/{job_id}` | Remove job record (does NOT purge repo data) |

`GET /import-jobs` query params: `page` (default 1), `per_page` (default 10, max 100), `repo_id` (filter), `status` (filter), `content_type` (filter).

`GET /import-jobs` response shape:
```json
{
  "jobs": [
    {
      "job_id":         "uuid",
      "repo_id":        "billing-service",
      "content_type":   "code",
      "fidelity":       "structural",
      "source_type":    "zip_upload | git",
      "status":         "complete | running | pending | failed",
      "imported_count": 78,
      "empty_count":    22,
      "duration_ms":    932000,
      "started_at":     "2026-04-29T18:41:00Z",
      "completed_at":   "2026-04-29T18:56:32Z",
      "error_message":  null
    }
  ],
  "total": 49,
  "page":  1,
  "per_page": 10
}
```

Job `status` transitions: `pending` → `running` → `complete | failed`. Transitions are written by the `scan_source` / `persist_facts` / `batch_embed` workers via the `import_jobs` table — not by the Admin API.

---

##### Admin Portal UI (ADR-0026)

The `ecle-admin` binary serves a React SPA at `GET /`. See ADR-0026 for full specification. Key integration points:

- `GET /admin/v1/health/repos` — returns per-repo knowledge-graph summary (mirrors Contract 16 §2 gauges as JSON) for the System Health page.
- `POST /admin/v1/upload` — receives ZIP from browser, starts import job.
- `GET /admin/v1/import-jobs` — feeds the Import Jobs page.
- `ADMIN_UI_ENABLED=true` default all tiers. `ADMIN_UI_DEV=true` skips static file serving (Vite dev server handles it).

---

##### Worker Lifecycle Control (admin scope — ADR-0027)

Each worker polls `worker_lifecycle` table on 30 s TTL. These endpoints write to that table and are audited.

| Method | Path | Description |
|--------|------|-------------|
| `GET` | `/workers` | List all workers: name, lifecycle state, current lag, replica count, throughput (msg/min), error rate |
| `GET` | `/workers/{worker_name}` | Worker detail: metrics history (last 1h), pipeline_state contributions, last heartbeat |
| `POST` | `/workers/{worker_name}/pause` | Pause worker — stop consuming after current in-flight messages complete |
| `POST` | `/workers/{worker_name}/resume` | Resume a paused worker |
| `POST` | `/workers/{worker_name}/drain` | Process to lag=0 then auto-pause |
| `POST` | `/workers/{worker_name}/reset-offset` | Reset consumer group offset; body: `{ "offset_target": "earliest \| latest \| <timestamp>" }`. Requires explicit `"confirm": true` field — double-confirmation guard || `GET` | `/workers/{worker_name}/recent-errors` | Last 10 ERROR log lines for this worker (from structured log store or Kafka `ecle.worker.errors` topic) |
`GET /workers` response shape:
```json
{
  "workers": [
    {
      "worker_name":   "parse_repo",
      "lifecycle":     "running | paused | draining",
      "kafka_lag":     142,
      "replicas":      { "current": 3, "min": 1, "max": 16 },
      "throughput_rpm": 840,
      "error_rate":    0.002,
      "last_heartbeat": "2026-05-07T10:00:00Z"
    }
  ]
}
```

Lifecycle changes are written to `worker_lifecycle` table and recorded in `query_audit_log` with `tool = "admin:worker_lifecycle"`.

---

##### Operational Health (admin scope)

| Method | Path | Description |
|--------|------|-------------|
| `GET` | `/health` | System health: all worker consumer group lags, backend connectivity |
| `GET` | `/coverage` | Per-repo: indexed files, failed files, stale vectors, pending re-embeds |
| `GET` | `/coverage/{repo_id}` | File-level coverage detail for one repo |
| `GET` | `/language-packs` | Installed packs: name, version, fidelity, extension map. Also returns a flat `allowed_extensions[]` list — used by the Admin Portal pre-flight scan to classify files before upload |
| `POST` | `/language-packs/reload` | Trigger hot-reload of language pack registry (ADR-0002) |
| `GET` | `/coverage-gaps` | Extensions with global miss count above threshold |

`GET /health` response (abbreviated):
```json
{
  "status": "healthy | degraded | unhealthy",
  "backends": {
    "structured_db": "ok",
    "vector_store": "ok",
    "kafka": "ok | lag_alert"
  },
  "workers": {
    "parse_repo":    { "lag": 0, "status": "ok" },
    "persist_facts": { "lag": 3, "status": "ok" },
    "batch_embed":   { "lag": 45012, "status": "lag_alert" }
  },
  "stale_vector_ratio": 0.03,
  "checked_at": "2026-05-07T10:00:00Z"
}
```

`status = "degraded"` when any worker lag > `KAFKA_LAG_ALERT_THRESHOLD`.
`status = "unhealthy"` when any backend is unreachable.

---

#### Admin API server properties

- **Separate process:** `ecle-admin` binary, separate K8s Deployment, separate Service. Not the same process as `ecle-mcp`.
- **Not exposed publicly:** Tier 2/3 admin API is on an internal service, not exposed through the public ingress. `NetworkPolicy` restricts access to ops-tooling namespace only.
- **No async work:** Admin API calls are synchronous REST — write to DB, return response. Long-running work (re-index) is queued via Kafka event.
- **Rate limiting:** 10 req/s per key for admin endpoints (lower than query rate limits — admin operations should be rare).

---

#### `import_jobs` table (new)

```sql
CREATE TABLE import_jobs (
  job_id          UUID PRIMARY KEY,
  tenant_id       VARCHAR NOT NULL,
  repo_id         VARCHAR NOT NULL,
  content_type    VARCHAR,                         -- null = auto-detect
  fidelity        VARCHAR,                         -- structural | deep; set by parse_repo worker
  source_type     VARCHAR NOT NULL,                -- zip_upload | git
  artifact_path   TEXT,                            -- IArtifactStore path to ZIP (null for git)
  status          VARCHAR NOT NULL DEFAULT 'pending',  -- pending | running | complete | failed
  imported_count  INT      NOT NULL DEFAULT 0,
  empty_count     INT      NOT NULL DEFAULT 0,
  error_message   TEXT,
  started_at      TIMESTAMP NOT NULL,
  completed_at    TIMESTAMP,
  duration_ms     BIGINT
);

CREATE INDEX ON import_jobs (tenant_id, started_at DESC);
CREATE INDEX ON import_jobs (repo_id, status);
```

Job rows are retained for the duration of `AUDIT_LOG_RETENTION_DAYS` (ADR-0021), then hard-deleted. `DELETE /import-jobs/{job_id}` removes the row immediately (operator action, not a purge event).

#### `tenants` table (new)

```sql
CREATE TABLE tenants (
  id             UUID PRIMARY KEY,
  tenant_id      VARCHAR NOT NULL UNIQUE,
  display_name   TEXT,
  tier           VARCHAR NOT NULL DEFAULT 'compose',  -- dev | compose | enterprise
  created_at     TIMESTAMP NOT NULL,
  purge_at       TIMESTAMP,   -- NULL = active; set by DELETE /tenants/{id}
  is_active      BOOLEAN NOT NULL DEFAULT TRUE
);
```

#### `tenant_config` table (new)

```sql
CREATE TABLE tenant_config (
  id          UUID PRIMARY KEY,
  tenant_id   VARCHAR NOT NULL,
  config_key  VARCHAR NOT NULL,
  config_value TEXT NOT NULL,
  set_by      TEXT,            -- subject from auth context (audit)
  set_at      TIMESTAMP NOT NULL,
  UNIQUE (tenant_id, config_key)
);
```

---

### Consequences

**Positive:**
- Operators can manage the full system lifecycle without direct DB access or pod restarts
- CI/CD pipelines can automate repo onboarding and config management via scripted Admin API calls
- Runtime config overrides eliminate the "restart to change threshold" operational pattern
- API key management is self-service for tenant admins

**Negative / Trade-offs:**
- Additional binary (`ecle-admin`) to deploy and maintain — but it is a thin REST layer over the existing DB, so maintenance burden is low
- Runtime config polling introduces a 60 s propagation delay for config changes — acceptable for operational config, not acceptable for embedding model changes (those still require restart)

**Neutral / Operational notes:**
- Bootstrap: the first system-admin API key is created by a one-time `ecle-admin bootstrap` CLI command that writes directly to the DB and prints the raw key. Subsequent key management goes through the API.
- Tier 1 dev: admin API runs on the same process as the MCP server for simplicity (`ADMIN_EMBEDDED=true` default in dev).
- All admin operations are recorded in `query_audit_log` with `tool = "admin:{endpoint}"`.

---

### Alternatives Considered

| Alternative | Why Rejected |
|-------------|-------------|
| Kubectl/Helm only for operations | Only works for K8s (Tier 3); Tier 2 operators would need direct DB access; no audit log |
| Extend MCP server with admin tools | Mixing query tools and admin tools on the same port blurs the security boundary; admin `scope` enforcement is cleaner on a separate service |
| CLI-only admin (`ecle-admin` command) | Cannot be used by CI/CD pipelines or dashboards without wrapping in a service; REST is universally consumable |

---

### Compliance

- ADR: `ADR-0019` — admin scope in API key model; audit log
- ADR: `ADR-0021` — tenant/repo purge lifecycle
- ADR: `ADR-0026` — Admin Portal UI (React SPA served by this binary; ZIP upload flow; Import Jobs and System Health pages)
- ADR: `ADR-0015` — three-axis onboard model; Admin API is the onboard trigger
- ADR: `ADR-0002` — language pack hot-reload triggered by Admin API
- Contract: `constitution/contracts/14-deployment-contract.md` — `ADMIN_PORT`, `ADMIN_EMBEDDED`, `ADMIN_UI_ENABLED` config vars
- Contract: `constitution/contracts/15-db-schema-contract.md` — `import_jobs` table
- Contract: `constitution/contracts/09-event-pipeline-contract.md` — `upload.received` event
