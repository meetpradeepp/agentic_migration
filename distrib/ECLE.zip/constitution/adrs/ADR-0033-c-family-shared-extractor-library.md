# ADR-0033: C-Family Shared Extractor Library

**Status:** Accepted
**Date:** 2026-05-09
**Deciders:** Lead Engineer, Architecture Review
**Supersedes:** —
**Superseded by:** —
**Amends:** ADR-0016 (extraction depth — adds macros, typedefs, and preprocessor_branches as standard extraction categories for C-family languages), Contract 08 (language pack — formalises `common/` shared library convention)

---

### FACT Impact

| Dimension | Impact |
|-----------|--------|
| **Fast** | `neutral` — shared library reduces total Python code executed per file (one import, same traversal); no performance regression; tree-sitter AST traversal remains O(N) in token count. |
| **Accurate** | `improves` — header-heavy C/C++/Pro*C codebases previously produced zero structural facts from `.h` files (functions=0, structs=0 on macro/typedef-only headers). Macro and typedef extraction closes this silent gap. Preprocessor branch extraction surfaces conditional compilation paths that affect which code is active. |
| **Complete** | `improves` — macro definitions, function-like macros, typedef aliases, and `#ifdef`/`#ifndef` branch points are now first-class extracted facts rather than invisible source text. The extraction is language-agnostic at the schema level — other language packs (Java, Python, PowerBuilder) emit empty lists and zero counts, so no schema gap is created. |
| **Trustworthy** | `improves` — single implementation eliminates three-way drift risk. Bug fixes and extraction improvements apply to C, C++, and Pro*C simultaneously. Schema-level counts (`macros_count`, `typedefs_count`) are verifiable against source by automated eval. |

---

### Context

ECLE 2.0's language pack system (ADR-0002, Contract 08) places all language-specific
extraction logic inside `language_packs/<language_id>/fast_extractor.py`. For the C
language family (C, C++, Pro*C), this created a structural problem:

**All three languages use the same underlying grammar: `tree-sitter-c`.**

The C grammar (`tree-sitter-c`) exposes preprocessor nodes, typedef declarations, and
macro definitions for all three languages. Pro*C files are sanitized before parsing — the
`sanitizer.py` converts `EXEC SQL ... ;` blocks to `__JOERN_SQL_WRAPPER(...)` calls, and
the resulting file is valid C that the C grammar parses with zero error nodes. The
preprocessor and typedef structures in a `.ppc` file are syntactically identical to C.

Before this ADR, the three `fast_extractor.py` files either duplicated tree-sitter node
traversal logic or silently omitted categories that the grammar could produce. The field
testing evidence was stark:

**`operid.h` (mmUpMemo repo, header-only file):**
- 13 macro definitions
- 2 typedef declarations
- 1 `#ifdef IDL` branch
- Before this ADR: `functions=0, struct_definitions=0, includes=1, comments=1` — the file's entire semantic content was invisible to FACT.
- After this ADR: all 13 macros, 2 typedefs, and the branch point extracted and stored.

Header files in enterprise C/C++/Pro*C codebases are not edge cases — they are the
primary carriers of type definitions, macro constants, and interface contracts. Silent
extraction failure on `.h` files is a FACT/Complete violation.

**The `common/` pattern** is the correct fix: shared code that all three packs import.
This is explicitly supported by Contract 08's `language_packs/` folder structure — nothing
forbids subdirectories. A `common/` folder under `language_packs/` is not a new language
pack (it has no `manifest.yaml`); it is a shared Python library importable by any pack.

---

### Decision

We will maintain a single shared extraction library at:

```
language_packs/common/c_family_extractors.py
```

This file is the **one canonical location** for all tree-sitter-c node-type traversal
logic used by C, C++, and Pro*C. Per-language `fast_extractor.py` files import from it,
call the shared functions, and assemble the output dict. No tree-sitter node-type logic
lives in the per-language files — only language-specific post-processing (e.g. Pro*C
filtering out `__JOERN_SQL_WRAPPER` from `dependencies[]`).

#### Functions in `c_family_extractors.py`

| Function | Tree-sitter node types walked | Output |
|----------|------------------------------|--------|
| `extract_c_macros` | `preproc_def`, `preproc_function_def`, `preproc_call` (filtered to `#undef`) | `list[MacroDef]` — name, value, is_function_like, is_undef, line |
| `extract_c_typedefs` | `type_definition` + descent into `function_declarator` / `parenthesized_declarator` / `pointer_declarator` for alias name | `list[TypedefDef]` — alias, underlying_type, line |
| `extract_c_preprocessor_branches` | `preproc_ifdef`, `preproc_if` + `preproc_else`, `preproc_elif` for branch points | `list[PreprocBranch]` — kind (`ifdef`/`ifndef`/`if`), condition_text, line, has_else |
| `attach_preprocessor_context` | No AST walk — post-processing on the lists above | Annotates `functions[]` and `struct_definitions[]` with the `#ifdef` context they fall under |
| `_normalize_macro_value` | No AST walk — raw source bytes | Normalizes multi-line macros with backslash continuation |
| `_is_multiline_macro` | No AST walk — raw source bytes | Detects `\` continuation characters |

Pre-existing extraction functions (`extract_functions`, `extract_structs`, `extract_includes`,
`extract_dependencies`, `extract_sql`, `extract_comments`, `extract_literals`, `extract_globals`)
remain in `c_family_extractors.py` unchanged — this ADR documents the existing shared
library pattern and adds the three new categories.

#### New extraction categories (output schema fields)

**`macros[]`** — Macro definitions and undefs.

```json
{
  "macros": [
    {
      "name": "MAX_BUFFER_SIZE",
      "value": "4096",
      "is_function_like": false,
      "is_undef": false,
      "line": 14
    },
    {
      "name": "MIN(a, b)",
      "value": "((a) < (b) ? (a) : (b))",
      "is_function_like": true,
      "is_undef": false,
      "line": 22
    }
  ]
}
```

**`typedefs[]`** — Typedef alias declarations.

```json
{
  "typedefs": [
    {
      "alias": "ACCOUNT_ID",
      "underlying_type": "long",
      "line": 31
    },
    {
      "alias": "ProcessFn",
      "underlying_type": "void (*)(int, char *)",
      "line": 45
    }
  ]
}
```

**`preprocessor_branches[]`** — Conditional compilation branch points.

```json
{
  "preprocessor_branches": [
    {
      "kind": "ifdef",
      "condition": "IDL",
      "line": 67,
      "has_else": false
    },
    {
      "kind": "ifndef",
      "condition": "OPERID_H",
      "line": 1,
      "has_else": false
    }
  ]
}
```

#### Rollup counts in `file_facts`

Two new columns are added to `file_facts` for fast aggregate queries
(schema change governed by Contract 15 and the DB migration contract):

| Column | Type | Populated by | Notes |
|--------|------|-------------|-------|
| `macros_count` | INT | `persist_facts` | `len(facts.macros)` |
| `typedefs_count` | INT | `persist_facts` | `len(facts.typedefs)` |

`preprocessor_branches_count` is NOT a rollup column — branch counts are highly variable
and rarely queried in aggregate. Individual branches are searchable via full-text on the
`file_literals` table (condition strings are stored as literals of type `preprocessor_condition`).

#### Schema-agnostic design

Every language pack's facts schema extends `CanonicalFactFileBase`. The base schema
includes `macros`, `typedefs`, and `preprocessor_branches` as **optional lists defaulting
to `[]`**.

Language packs that do not use `c_family_extractors.py` (Java, Python, PowerBuilder, etc.)
emit `"macros": [], "typedefs": [], "preprocessor_branches": []` automatically via the
base schema default. The `persist_facts` worker writes `macros_count=0`, `typedefs_count=0`.

No language pack is forced to implement these categories. No query breaks if a non-C-family
file has empty lists.

#### `common/` folder convention (Contract 08 amendment)

The `language_packs/common/` folder is a **shared Python library**, not a language pack.

Rules:
1. `common/` has no `manifest.yaml`. The registry loader skips it.
2. Code in `common/` MUST be pure Python with no side effects at import time.
3. `common/` modules MUST NOT import from any specific language pack.
4. Language packs import from `common/` using a relative import: `from common.c_family_extractors import ...`
5. Any extraction logic used by two or more language packs MUST move to `common/`.
6. Language-specific post-processing (e.g. Pro*C's `__JOERN_SQL_WRAPPER` filter) stays in the per-language file.

---

### Consequences

**Positive:**
- Bug fixes in macro/typedef extraction apply to C, C++, and Pro*C simultaneously with one commit.
- Header-only files now produce meaningful structural facts.
- Preprocessor branches give ECLE visibility into conditional compilation (`#ifdef WINDOWS`, `#ifdef ORACLE`, etc.) — relevant for platform and environment analysis.
- Function-like macros (e.g. `#define ASSERT(x) do { ... } while(0)`) are extracted as structured data, not text noise.
- `attach_preprocessor_context` annotates functions with their enclosing `#ifdef` scope — a query can find "functions that only exist when `FEATURE_X` is defined".

**Negative / Trade-offs:**
- `common/` introduces a cross-pack import dependency. If `c_family_extractors.py` breaks, all three C-family packs break simultaneously. Mitigated by the shared unit test suite — `eval_c_family_extractors` runs on every PR.
- `macros_count` and `typedefs_count` columns require a DB migration. The migration is additive (nullable, default 0) — no existing row is invalidated.

**Neutral / Operational notes:**
- The `tree-sitter-c` grammar is unchanged. No custom grammar work is required.
- No Joern changes. No Scala scripts. Purely AST traversal of nodes the C grammar already exposes.
- Pro*C's sanitizer does not touch `#define`, `#ifdef`, or `typedef` lines — these pass through unchanged to tree-sitter-c. Extraction is correct on sanitized `.ppc` files.

---

### Alternatives Considered

| Alternative | Why Rejected |
|-------------|-------------|
| Duplicate logic in each per-language fast_extractor.py | Three-way drift is inevitable. The mmUpMemo bug was already present in two of three files before it was noticed. |
| Move all C-family logic into a single C pack and make C++ / Pro*C inherit | Inheritance between language packs violates ADR-0002's isolation principle. Packs must be independently deployable and replaceable. |
| Extract macros only in deep (Joern) phase | Joern does not extract macro definitions as first-class facts — it operates on preprocessed output. The structural phase is the correct place to capture preprocessor-level semantics. |
| Store preprocessor branches in a separate DB table | The query volume on preprocessor branches does not justify a dedicated table at Phase 1. The `preprocessor_branches[]` JSON array in the facts artifact and the `file_literals` condition-string rows are sufficient. Revisit in Phase 3 if topology analysis of conditional compilation paths is added. |

---

### Compliance

- Contract: `constitution/contracts/08-language-pack-contract.md` — `common/` convention rules (§X), three new required categories for C-family packs
- Contract: `constitution/contracts/15-db-schema-contract.md` — `file_facts.macros_count`, `file_facts.typedefs_count` columns
- Contract: `constitution/contracts/19-cpg-extraction-tier-contract.md` — structural tier capability matrix includes macros/typedefs for C-family
- Schema: `constitution/schemas/facts-base-schema.json` — `macros[]`, `typedefs[]`, `preprocessor_branches[]` fields in `CanonicalFactFileBase`
- Eval: `eval_c_family_extractors` — validates macro/typedef/branch extraction against reference header corpus (runs on every PR)
- Eval: `eval_schema_conformance` — asserts `macros_count` and `typedefs_count` columns present with correct defaults
