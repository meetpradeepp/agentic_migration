# ADR-0029: Agent Token Optimization via Offline Memory

**Status:** Accepted  
**Date:** 2026-05-08  
**Deciders:** Lead Engineer, Architecture Review  
**Supersedes:** —  
**Superseded by:** —  
**FACT impact:**
- Fast: `improves` — agents load compact digests (~50 lines) instead of full contracts (~250 lines each), reducing context window consumption by ~60%
- Accurate: `neutral` — validator still loads full contracts; digests are derived from source contracts, not approximations
- Complete: `improves` — freed context budget allows agents to hold more task-specific context (specs, plans, code)
- Trustworthy: `improves` — shared-rules file eliminates 360+ lines of duplicated rules that can drift out of sync across agents

---

### Context

The ECLE 2.0 agent pipeline (12 agents across 7 gates) consumes significant tokens per
pipeline run due to three structural inefficiencies:

1. **Redundant contract loading.** Contracts 01, 02, 03, and 10 are loaded by 8–10 agents
   each. A single G0→G6 pipeline run re-reads these four contracts ~8 times each.
   Total contract corpus is 3,466 lines across 17 files.

2. **Duplicated rules.** ~360 lines of identical rules (TDD order, anti-pattern checklist,
   coding standards, spec traceability, commit format, Kafka governance) are embedded
   independently in 6–10 agent files.

3. **No shared context.** Each agent invocation starts cold — no pre-computed knowledge
   about the constitution's key rules, current phase status, or event catalogue.

At scale (building Phase 1's 9+ specs through the full pipeline), this creates
unnecessary token overhead that limits the effective context budget available for
actual task work (reading specs, plans, and code).

---

### Decision

We will introduce an **offline memory layer** at `.github/memory/` containing
pre-digested, compact reference files that agents load instead of full constitution
contracts. The validator agent remains exempt — it always loads full contracts as the
compliance safety net.

The memory layer consists of:

1. **`constitution-digest.md`** — Compact digest of all 17 contracts. Key rules only,
   no code examples. ~150 lines vs ~3,466 lines of raw contracts.

2. **`shared-rules.md`** — Common rules extracted from agent files into a single
   reference. Agents reference this file instead of each embedding their own copy.
   Covers: TDD order, anti-pattern summary, coding standards checklist, spec
   traceability, commit format, Kafka governance, phase discipline.

3. **`event-catalogue.md`** — Compact event type reference derived from Contract 09.
   Event name, producer, consumer(s), required fields — in table format.

4. **`phase-status.md`** — Living document tracking current phase, active specs,
   and completed milestones. Updated by the release-manager at each phase transition.

**Loading strategy per agent tier:**

| Tier | Agents | What they load |
|------|--------|----------------|
| Digest-first | spec-writer, spec-patcher, planner, coder, tester, refactor, code-reviewer, release-manager, adr-writer | `.github/memory/` digests + full contracts only when verifying exact wording |
| Full-contract | validator, spec-reviewer | Full `constitution/contracts/` files (unchanged — these are the safety net) |
| Orchestrator | orchestrator | `.github/memory/` digests for triage; delegates full verification to validator |

**Maintenance rule:** When a contract is updated, the corresponding digest entry in
`.github/memory/constitution-digest.md` MUST be updated in the same commit. CI can
verify digest freshness via a hash comparison (future enhancement).

---

### Consequences

**Positive:**

- ~60% reduction in constitution-related token consumption per pipeline run
- Eliminated 360+ lines of rule duplication across agents
- Freed context budget for task-specific content (specs, code, plans)
- Single source of truth for shared rules — no more agent-to-agent drift
- Validator still loads full contracts, preserving compliance verification depth

**Negative / Trade-offs:**

- Digests must be kept in sync with source contracts (maintenance burden)
- Risk of digest staleness if a contract is updated without updating the digest
- Validator and spec-reviewer pay the full token cost (by design — they are the safety net)

**Neutral / Operational notes:**

- Memory files are checked into the repo alongside agents — no external dependency
- Agent files are updated to reference memory files but retain their unique logic
- No runtime impact — this is purely a development-time optimization

---

### Alternatives Considered

| Alternative | Why Rejected |
|-------------|-------------|
| Dynamic contract summarization per invocation | Adds latency; summary quality varies; defeats determinism goal |
| Removing "Before You..." sections entirely | Agents would have no guidance on what to load — too risky |
| Embedding full contracts in agent YAML frontmatter | YAML frontmatter has size limits; defeats the purpose |
| Single monolithic "constitution summary" file | Too large; agents would load irrelevant sections; no tier flexibility |

---

### Compliance

- Contract: `constitution/contracts/02-sdlc-contract.md` — ADR before architectural change
- This ADR does not change any contract — it changes how agents consume contracts
- No schema impact
- No eval suite impact
