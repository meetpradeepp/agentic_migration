# ADR-0001: Event-Driven Pipeline via PostgreSQL Events Table

**Status:** Superseded  
**Date:** 2026-05-05  
**Deciders:** Lead Engineer, Architecture Review  
**Supersedes:** —  
**Superseded by:** ADR-0013 (Kafka as exclusive event broker)  

---

### Context

ECLE 2.0 must ingest thousands of source files per repository, extract structured facts, build a topology graph, embed chunks, and register contracts — all without blocking the HTTP API and without coupling workers to each other.

Early designs considered direct worker-to-worker calls (RPC/HTTP) and a single monolithic processing function. Both approaches collapse under partial failure: if embedding fails mid-run, there is no safe replay point. We also require full audit lineage — every system action must be traceable to a triggering event.

A PostgreSQL `events` table as an immutable append log satisfies these constraints: each worker reads only events of its type, processes them, and emits follow-on events. The table is the single source of truth for pipeline state.

---

### Decision

We will use a PostgreSQL `events` table as the exclusive inter-worker communication channel. No worker may call another worker directly. The HTTP API thread only writes `source.received` and returns 202. All downstream work is asynchronous, event-triggered, and idempotent.

- Schema defined in `constitution/schemas/events-table.sql`
- Worker SRP boundaries defined in `constitution/contracts/09-event-pipeline-contract.md`
- Each event row carries: `event_type`, `tenant_id`, `repo_id`, `entity_id`, `payload` (JSONB), `idempotency_key`
- Workers mark `processed_at` on success; set `error` on failure (row retained for replay)

---

### Consequences

**Positive:**

- Full audit trail: every state transition is a durable row — debuggable, replayable
- Workers are independently deployable and scalable
- Partial failure is safe: failed events remain in the table and can be replayed without re-running successful steps
- Adding a new processing step = add a new worker that consumes an existing event type; zero changes to existing workers
- Idempotency key prevents duplicate work on Celery retry

**Negative / Trade-offs:**

- Slightly higher latency than direct calls (~5–50 ms per hop for DB round-trip)
- PostgreSQL becomes a critical dependency; must be HA in production
- Workers must poll or use LISTEN/NOTIFY — adds operational complexity vs. message broker
- Schema evolution of `payload` JSONB requires discipline (ADR + migration)

**Neutral / Operational notes:**

- Celery is used as the worker execution framework; it polls the events table via a thin adapter
- A dedicated `events` database separate from the facts database is recommended at scale
- The `error` column doubles as a dead-letter queue; no separate DLQ infrastructure needed

---

### Alternatives Considered

| Alternative | Why Rejected |
|-------------|-------------|
| Direct worker-to-worker HTTP/RPC | Tight coupling; cascading failures; no replay; violates SRP |
| Dedicated message broker (RabbitMQ / Kafka) | Extra infrastructure dependency; PostgreSQL already required; LISTEN/NOTIFY sufficient for Phase 1 |
| Monolithic processing function | Cannot scale independently; full re-run on any failure; no audit trail |
| Redis Streams | Loses durability guarantee; eviction risk; PostgreSQL already required |

---

### Compliance

- Contract: `constitution/contracts/09-event-pipeline-contract.md`
- Schema: `constitution/schemas/events-table.sql`
- Eval: `eval_event_chain_complete` — verifies every `source.received` eventually produces terminal events
- Eval: `eval_idempotent_ingest` — verifies replayed events produce identical output
- Anti-pattern: A15 (sync API worker calls), A16 (cross-boundary writes), A17 (missing idempotency key)
