# ECLE 2.0 — Consolidated References Index

> All academic papers, standards, and industry references cited across ADRs and contracts.
> Grouped by topic. Each entry links back to the ADR/contract that cites it.

---

## 1. Data Quality & Confidence

| Citation | Cited in |
|----------|----------|
| Wang, R. & Strong, D. "Beyond Accuracy: What Data Quality Means to Data Consumers", JMIS 1996 (~7,000 citations) | Contract 04, Contract 05 |
| Wand, Y. & Wang, R. "Anchoring Data Quality Dimensions in Ontological Foundations", CACM 1996 | Contract 04 |
| ISO 8000:2022 — Data Quality (iso.org/standard/81745.html) | Contract 04 |
| ISO/IEC 25012:2008 — Data quality model (SQuaRE series) | Contract 04 |
| Kazman, R. et al. "Architecture Tradeoff Analysis Method (ATAM)", CMU SEI Technical Report 2000 | Contract 04 |
| Wilson, E.B. "Probable Inference, the Law of Succession, and Statistical Inference", JASA 1927 | Contract 05, ADR-0024 |

## 2. Semantic Search & Vector Retrieval

| Citation | Cited in |
|----------|----------|
| Khattab, O. & Zaharia, M. "ColBERT: Efficient and Effective Passage Search via Contextualized Late Interaction over BERT", SIGIR 2020 (arXiv:2004.12832) | ADR-0004, Contract 05 |
| Gao, Y. et al. "Retrieval-Augmented Generation for Large Language Models: A Survey", 2024 (arXiv:2312.10997) | ADR-0004, ADR-0008 |
| Gao, Y. et al. "Modular RAG: Transforming RAG Systems into LEGO-like Reconfigurable Frameworks", 2024 (arXiv:2407.21059) | ADR-0004 |
| Malkov, Y. & Yashunin, D. "Efficient and Robust Approximate Nearest Neighbor using Hierarchical Navigable Small World Graphs", IEEE TPAMI 2018 (arXiv:1603.09320) | ADR-0004 |
| Nussbaum, Z. et al. "Nomic Embed: Training a Reproducible Long Context Text Embedder", TMLR 2024 (arXiv:2402.01613) | ADR-0004, ADR-0008 |
| Khattab, O. & Zaharia, M. "ColBERT v2: Effective and Efficient Retrieval via Lightweight Late Interaction", NAACL 2022 (arXiv:2112.01488) | ADR-0004 |
| Lassance, C. et al. "Muvera: Multi-Vector Retrieval via Fixed Dimensional Encodings", 2024 (arXiv:2405.19504) | ADR-0004 |
| Cormack, G.V. et al. "Reciprocal Rank Fusion outperforms Condorcet and individual Rank Learning Methods", SIGIR 2009 | ADR-0004 |
| Robertson, S.E. & Zaragoza, H. "The Probabilistic Relevance Framework: BM25 and Beyond", Foundations and Trends in IR 2009 | ADR-0004 |
| ONNX Runtime (onnxruntime.ai) — Microsoft open standard for portable ML inference | ADR-0008 |

## 3. Knowledge Graphs & Community Detection

| Citation | Cited in |
|----------|----------|
| Dong, X.L. "Generations of Knowledge Graphs: The Crazy Ideas and the Business Impact", PVLDB 2023 (arXiv:2308.14217) | ADR-0003 |
| Edge, D. et al. "From Local to Global: A Graph RAG Approach to Query-Focused Summarization", 2024 (arXiv:2404.16130) | ADR-0003, ADR-0011 |
| Blondel, V.D. et al. "Fast unfolding of communities in large networks", J. Stat. Mech. 2008 (arXiv:0803.0476) (~17,000 citations) | ADR-0011 |
| Traag, V.A. et al. "From Louvain to Leiden: guaranteeing well-connected communities", Scientific Reports 2019 | ADR-0011 |
| Liu, X. et al. "Evaluating the Factuality of LLMs using Large-Scale Knowledge Graphs", 2024 (arXiv:2404.00942) | ADR-0011 |

## 4. Provenance & Grounding

| Citation | Cited in |
|----------|----------|
| W3C PROV-DM: The PROV Data Model, W3C Recommendation 2013 (w3.org/TR/prov-dm/) | Contract 06 |
| W3C PROV-O: The PROV Ontology, W3C Recommendation 2013 (w3.org/TR/prov-o/) | Contract 06 |
| Moreau, L. & Groth, P. "Provenance: An Introduction to PROV", Morgan & Claypool 2013 | Contract 06 |
| Miles, S. et al. "PRIME: A Methodology for Developing Provenance-Aware Applications", ACM TOSEM 2011 | Contract 06 |

## 5. Staleness & Incremental Computation

| Citation | Cited in |
|----------|----------|
| Acar, U.A. "Self-Adjusting Computation", PhD thesis CMU 2005 | Contract 05, Contract 07, Contract 13 |
| RFC 9111 — HTTP Caching (supersedes RFC 7234) — httpwg.org | Contract 07 |
| RFC 5861 — HTTP Cache-Control Extensions for Stale Content (stale-while-revalidate) | Contract 07 |
| Mariappan, M. & Vora, K. "GraphBolt: Dependency-Driven Synchronous Processing of Streaming Graphs", EuroSys 2019 | Contract 07, Contract 13 |
| Quinlan, S. & Dorward, S. "Venti: A New Approach to Archival Storage", FAST 2002 | Contract 13 |

## 6. Event-Driven Architecture & Kafka

| Citation | Cited in |
|----------|----------|
| Richardson, C. "Microservices Patterns", Manning 2025 | ADR-0003, ADR-0013, ADR-0027 |
| Hohpe, G. & Woolf, B. "Enterprise Integration Patterns", Addison-Wesley 2003 | ADR-0013, ADR-0027, Contract 13 |
| Confluent, "Kafka: The Definitive Guide", O'Reilly 2021 | ADR-0013 |
| Apache Kafka KRaft (KIP-500) — kafka.apache.org | ADR-0013 |
| Reactive Manifesto (reactivemanifesto.org) | ADR-0027 |
| Kubernetes KEDA (keda.sh) — Event-Driven Autoscaling | ADR-0027 |

## 7. Parsing & Code Intelligence

| Citation | Cited in |
|----------|----------|
| Brunsfeld, M. "Tree-sitter — A new parsing system for programming tools", Strange Loop 2018 | ADR-0016 |
| Wagner, T. & Graham, S. "Efficient and Flexible Incremental Parsing", UC Berkeley 1998 | ADR-0016 |
| Wagner, T. & Graham, S. "Incremental Analysis of Real Programming Languages", UC Berkeley 1997 | ADR-0016 |
| Paige, R. "Practical Algorithms for Incremental Software Development Environments", UC Berkeley 1997 | ADR-0016 |
| Tree-sitter (tree-sitter.github.io) — used by GitHub, Neovim, Zed, Helix, Semgrep | ADR-0016 |

## 8. MCP, GraphQL & Tool Interfaces

| Citation | Cited in |
|----------|----------|
| Model Context Protocol Specification, LF Projects 2025 (modelcontextprotocol.io/specification) | Contract 11 |
| MCP Spec §3: Security and Trust & Safety | Contract 11 |
| Microsoft Language Server Protocol (LSP) — microsoft.github.io/language-server-protocol/ | ADR-0016, Contract 11 |
| Principled GraphQL — principledgraphql.com | ADR-0003, Contract 11 |
| Schick, T. et al. "Toolformer: Language Models Can Teach Themselves to Use Tools", 2023 (arXiv:2302.04761) | Contract 11 |

## 9. Ontology & Domain Modelling

| Citation | Cited in |
|----------|----------|
| W3C SKOS (Simple Knowledge Organization System), 2009 Recommendation (w3.org/TR/skos-reference/) | ADR-0025 |
| W3C OWL 2 Web Ontology Language, 2012 Recommendation (w3.org/TR/owl2-overview/) | ADR-0025 |
| Gruber, T. "A Translation Approach to Portable Ontology Specifications", Knowledge Acquisition 1993 | ADR-0025 |
| Guarino, N. "Formal Ontology in Information Systems", IOS Press 1998 | ADR-0025 |

## 10. Cross-Repo Linking & Record Linkage

| Citation | Cited in |
|----------|----------|
| Newman, S. "Building Microservices", O'Reilly 2021, Ch. 4: Integration | ADR-0009 |
| Fellegi, I. & Sunter, A. "A Theory for Record Linkage", JASA 1969 | ADR-0009 |
| OpenAPI Specification 3.1 (spec.openapis.org) & AsyncAPI 3.0 (asyncapi.com) | ADR-0009 |

## 11. Multi-Tenancy & Security

| Citation | Cited in |
|----------|----------|
| Salesforce Multi-Tenancy Architecture (developer.salesforce.com) | ADR-0022 |
| PostgreSQL Row-Level Security (postgresql.org/docs/current/ddl-rowsecurity.html) | ADR-0022 |
| OWASP Top 10:2021 — A01: Broken Access Control | ADR-0022 |
| Azure SQL Elastic Pools & Database-per-Tenant pattern (learn.microsoft.com) | ADR-0022 |
| GDPR Article 25 (eur-lex.europa.eu) — Data Protection by Design and by Default | ADR-0022 |

## 12. Feedback & Learning Loops

| Citation | Cited in |
|----------|----------|
| Rocchio, J. "Relevance Feedback in Information Retrieval", 1971 (in Salton, "The SMART Retrieval System") | ADR-0024 |
| Christakopoulou, K. et al. "Towards Conversational Recommender Systems", KDD 2016 | ADR-0024 |
| Ouyang, L. et al. "Training language models to follow instructions with human feedback", NeurIPS 2022 (arXiv:2203.02155) | ADR-0024 |

## 13. Observability & SRE

| Citation | Cited in |
|----------|----------|
| OpenTelemetry Specification (opentelemetry.io/docs/specs/otel/) — CNCF Incubating project | Contract 16 |
| Sridharan, C. "Distributed Systems Observability", O'Reilly 2018 — The Three Pillars | Contract 16 |
| Weiss, T. "The RED Method" (grafana.com/blog/2018/08/02/the-red-method/) | Contract 16 |
| Beyer, B. et al. "Site Reliability Engineering", O'Reilly 2016 — Chapter 6 | Contract 16 |
| W3C Trace Context (w3.org/TR/trace-context/) | Contract 16 |

---

> **Total: 62 unique citations across 11 ADRs and 7 contracts.**
>
> To add a new reference: add it to the relevant ADR/contract's References section,
> then add a row here under the appropriate topic group.
