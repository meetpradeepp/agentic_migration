-- ECLE 2.0 — events table DDL
-- The system's immutable append log.
-- All workers communicate exclusively through this table.
-- Schema version: 2.0
-- ADR: ADR-0001

-- ============================================================
-- Core events table
-- ============================================================
CREATE TABLE IF NOT EXISTS events (
    id            BIGSERIAL PRIMARY KEY,

    -- Event classification
    event_type    TEXT        NOT NULL,   -- e.g. 'source.received', 'file.ir_produced'
    tenant_id     TEXT        NOT NULL,
    repo_id       TEXT,                   -- null for source-level events
    entity_id     TEXT,                   -- file_id, upload_id, etc. — depends on event_type

    -- Payload — full event data as JSONB
    -- Schema of payload.* is defined per event_type in constitution/contracts/09-event-pipeline-contract.md
    payload       JSONB       NOT NULL,

    -- Lifecycle timestamps
    created_at    TIMESTAMP   NOT NULL DEFAULT NOW(),
    processed_at  TIMESTAMP,              -- set by consuming worker on success
    error         TEXT,                   -- set by consuming worker on failure; null = success

    -- Idempotency
    -- Workers check this before emitting to prevent duplicate events on retry
    idempotency_key TEXT UNIQUE           -- SHA256(event_type + entity_id + commit_sha)
);

-- ============================================================
-- Indexes
-- ============================================================

-- Primary consumer query: poll for unprocessed events of a given type
CREATE INDEX IF NOT EXISTS idx_events_type_unprocessed
    ON events (event_type, created_at)
    WHERE processed_at IS NULL AND error IS NULL;

-- Replay query: find all events for a given repo
CREATE INDEX IF NOT EXISTS idx_events_repo
    ON events (repo_id, event_type, created_at);

-- Tenant isolation
CREATE INDEX IF NOT EXISTS idx_events_tenant
    ON events (tenant_id, event_type, created_at);

-- Error investigation
CREATE INDEX IF NOT EXISTS idx_events_errors
    ON events (event_type, created_at)
    WHERE error IS NOT NULL;

-- ============================================================
-- Event type catalogue — valid values for event_type
-- (enforced by application-layer validation, not FK)
-- ============================================================
-- source.received        API → scan_source
-- repo.detected          scan_source → parse_repo
-- source.scanned         scan_source → link_contracts
-- file.ir_produced       parse_repo → persist_facts, build_graph
-- repo.ir_produced       parse_repo → build_contract_registry
-- file.stored            persist_facts → chunk_file, detect_dsl_mappings
-- graph.updated          build_graph → compute_topology
-- file.chunked           chunk_file → batch_embed
-- dsl.mapped             detect_dsl_mappings → ontology_enricher
-- file.embedded          batch_embed → cluster_centroids
-- topology.updated       compute_topology → (terminal)
-- ontology.enriched      ontology_enricher → (terminal)
-- contracts.registered   build_contract_registry → link_contracts
-- cross.linked           link_contracts → (terminal)
-- feedback.given         Feedback Collector → learning_analyzer

-- ============================================================
-- Operational queries (for monitoring/replay — not for workers)
-- ============================================================

-- Count unprocessed events by type (pipeline health)
-- SELECT event_type, COUNT(*) FROM events
-- WHERE processed_at IS NULL AND error IS NULL
-- GROUP BY event_type ORDER BY COUNT(*) DESC;

-- Find failed events for replay
-- SELECT id, event_type, entity_id, error, created_at
-- FROM events WHERE error IS NOT NULL ORDER BY created_at DESC LIMIT 100;

-- Full event chain for a file (tracing)
-- SELECT event_type, entity_id, created_at, processed_at, error
-- FROM events WHERE entity_id = '<file_id>' ORDER BY created_at;
