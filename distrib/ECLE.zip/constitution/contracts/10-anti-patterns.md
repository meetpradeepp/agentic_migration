# Contract 10 — Anti-Patterns

**Scope:** All code in `src/` and `tests/`.  
**Enforced by:** Code review (hard block on sight), `ruff` rules where automatable.  
**Status:** Active

This document lists patterns that are **unconditionally banned** in ECLE 2.0.
A reviewer who finds any of these in a PR **blocks merge immediately** — no discussion, no exception.

---

## Group 1 — Design anti-patterns (violation of SOLID/SRP/DRY)

### A1 — God class / God worker

A class or Celery worker that does more than one thing.

```python
# BANNED
class FactService:
    def parse_and_persist_and_embed_and_notify(self, ...): ...

class IngestWorker:
    def run(self, event):
        parse_source()       # parsing
        persist_to_db()      # persistence
        embed_vectors()      # embedding
        notify_downstream()  # orchestration
```

Fix: one class = one responsibility. One worker = one job. Split immediately.

---

### A2 — Direct worker-to-worker calls

Workers calling each other's functions directly, importing each other's modules, or making HTTP calls to each other instead of emitting events. This violates ADR-0027 §Rule 1 and is the single most critical coupling anti-pattern in ECLE.

```python
# BANNED — direct function call
class ParseRepoWorker:
    def run(self, event):
        facts = self._extract(file)
        PersistFactsWorker().run_persist(facts)   # ← banned: direct call
        BuildGraphWorker().run_graph(facts)        # ← banned: direct call

# BANNED — cross-worker import
from ecle.workers.persist_facts import PersistFactsWorker   # ← banned: cross-worker import

# BANNED — direct HTTP call to another worker
import httpx
httpx.post("http://ecle-batch-embed:9090/process", json=payload)   # ← banned
```

Fix: emit `file.ir_produced` Kafka event. The other workers consume it independently on their own schedule at their own replica count.

```python
# REQUIRED
class ParseRepoWorker:
    def run(self, event):
        facts = self._extract(file)
        self._kafka_producer.produce("ecle.file.ir_produced", value=facts.to_event())
        self._kafka_producer.flush()
        # done — persist_facts and build_graph pick it up independently
```

**Scope of ban** (ADR-0027 §Rule 1 — verified by `eval_async_coupling`):
- Any `import` of `ecle.workers.{name}` from within another `ecle.workers.{name}` module
- Any `requests` / `httpx` / `aiohttp` call targeting a worker's metrics port or internal URL
- Any direct DB write to a table that is another worker's primary output table

---

### A3 — Inheritance for code reuse (non-polymorphic)

Using inheritance to share utility functions.

```python
# BANNED
class PowerBuilderExtractor(PythonExtractor):  # PB is NOT a Python — this is wrong
    pass

class MyWorker(BaseDBHelper):  # worker inheriting from a DB helper for convenience
    pass
```

Fix: use composition. Inject the shared helper as a constructor parameter.

---

### A4 — Premature abstraction / YAGNI violation

Building for hypothetical future requirements not in the current spec.

```python
# BANNED — "we might need this later"
class AbstractEventProcessor(ABC):
    @abstractmethod
    def pre_process(self): ...
    @abstractmethod
    def process(self): ...
    @abstractmethod
    def post_process(self): ...
    @abstractmethod
    def on_error(self): ...
# (3 levels of abstraction for a single worker that runs one task)
```

Fix: write the simplest code that satisfies the spec. Abstract when the second real use case arrives.

---

### A5 — DRY violation — copy-pasted logic

The same logic block appearing in more than one place.

```python
# BANNED — same SQL fragment in 4 files
def get_current_file(repo_id, file_id):
    return db.fetchone("SELECT * FROM file_facts WHERE repo_id=? AND file_id=? AND is_current=1", ...)
# (same query appears in persist_facts.py, chunk_file.py, build_graph.py, batch_embed.py)
```

Fix: extract to `ecle.db.queries.get_current_file_fact()` on the second occurrence.

---

## Group 2 — Coupling anti-patterns

### A6 — Hardcoded backend references

Importing SQLite (or any concrete backend) directly in business logic.

```python
# BANNED — business logic coupled to concrete backend
from ecle.backends.structured.sqlite import SQLiteBackend

class PersistFactsService:
    def __init__(self):
        self.db = SQLiteBackend("ecle.db")   # hardcoded — impossible to swap or test
```

Fix: inject `IStructuredDB` via constructor. The caller decides which implementation.

---

### A7 — Global mutable state

Module-level variables that accumulate state across requests.

```python
# BANNED
_processed_files: list[str] = []   # module-level mutable list

def process_file(path):
    _processed_files.append(path)  # shared state, not thread-safe, not testable
```

Fix: pass state explicitly as function arguments or via class instance variables.

---

### A8 — Shared database connection passed between workers

Workers sharing a DB connection object.

```python
# BANNED — connection shared across threads/workers
shared_conn = sqlite3.connect("ecle.db")

class PersistFactsWorker:
    def run(self, event):
        shared_conn.execute(...)   # not thread-safe
```

Fix: each worker instance creates its own connection in `connect()`.

---

## Group 3 — Safety anti-patterns

### A9 — Bare `except` / silent swallowing

```python
# BANNED
try:
    facts = json.loads(path.read_text())
except:           # bare except — catches SystemExit, KeyboardInterrupt too
    return {}     # silent swallow — caller has no idea what went wrong
```

Fix: name specific exception types, chain with `from exc`, propagate or record.

---

### A10 — f-string SQL (SQL injection)

```python
# BANNED — security blocker, reviewer rejects immediately
cursor.execute(f"SELECT * FROM file_facts WHERE repo_id = '{repo_id}'")
cursor.execute("SELECT * FROM file_facts WHERE repo_id = '" + repo_id + "'")
```

Fix: always use parameterised queries: `cursor.execute("... WHERE repo_id = ?", (repo_id,))`.

---

### A11 — Secrets in code

```python
# BANNED
NEO4J_PASSWORD = "admin123"
API_KEY = "sk-abc123..."
```

Fix: `settings.NEO4J_PASSWORD` from Pydantic BaseSettings reading `.env`.

---

## Group 4 — Complexity anti-patterns

### A12 — Functions longer than 30 lines of logic

Functions that combine multiple responsibilities into one body.

Fix: extract named helpers. A well-named helper is self-documenting.

---

### A13 — Nested conditionals deeper than 3 levels

```python
# BANNED
if a:
    if b:
        if c:
            if d:   # 4 levels deep — unreadable
```

Fix: early return / guard clauses, extracted helper functions, `match` statement (Python 3.10+).

---

### A14 — Returning `None` as a sentinel / using None for errors

```python
# BANNED — caller cannot distinguish "not found" from "error"
def get_file_fact(file_id: str) -> dict | None:
    try:
        return db.fetchone(...)
    except Exception:
        return None    # same return as "not found" — ambiguous
```

Fix: raise a typed exception for errors; return `None` only for "not found".

---

## Group 5 — Event pipeline anti-patterns

### A15 — Synchronous processing in the API thread

```python
# BANNED — processing in API handler before returning 202
@app.post("/upload")
async def upload(file: UploadFile):
    zip_path = save_zip(file)
    extract_zip(zip_path)        # BANNED — synchronous work in API thread
    detect_repos(zip_path)       # BANNED
    return {"status": "done"}    # BANNED — should return 202 immediately
```

Fix: save + emit `source.received` event + return 202. All work in Celery workers.

---

### A16 — Worker writing to another worker's owned table

```python
# BANNED — parse_repo writing to file_facts (owned by persist_facts)
class ParseRepoWorker:
    def run(self, event):
        facts = extract_facts(file)
        db.insert("file_facts", facts)  # BANNED — cross-boundary write
        emit_event("file.ir_produced", ...)
```

Fix: `parse_repo` writes only the artifact file. `persist_facts` owns `file_facts`.

---

### A17 — Missing idempotency key on DB inserts

```python
# BANNED — will create duplicate rows on event replay
db.execute("INSERT INTO file_facts (...) VALUES (...)")

# CORRECT
db.execute(
    "INSERT OR IGNORE INTO file_facts (...) VALUES (...)"
    # keyed on (file_id, commit_sha) — safe to run twice
)
```

---

## Reviewer guidance

When you spot any of these:
1. Add a comment on the specific line: "Anti-pattern A{N} — see `constitution/contracts/10-anti-patterns.md`".
2. Set the PR to "Request changes".
3. Do not approve until the pattern is removed and a test for the correct behaviour is added.

There is no "we'll fix it later". Technical debt of this kind compounds in enterprise systems.
