# Contract 05 — Confidence Contract

**Scope:** Every entity in the knowledge graph; every query result.  
**Enforced by:** `eval_fidelity_ceiling` (every PR), confidence schema validation.  
**Status:** Active

---

## 1. The 6-dimension confidence profile

Every `file_facts` row, every query result, and every MCP tool response carries all six dimensions.
A single scalar confidence number is **banned** — it hides which dimension degraded.

| Dimension | What it measures | How it degrades |
|---|---|---|
| `syntactic_freshness` | CPG/IR artifact is current at this commit | Drops to 0.0 when `content_hash` changes without re-parse |
| `behavioral_accuracy` | Facts freshly extracted from current source | Drops when content_hash changes without re-derivation |
| `contextual_accuracy` | Neighbour files have not changed since this file was indexed | Degrades when neighbours change — the key innovation |
| `edge_coherence` | Topology edges match current facts of both endpoints | Drops when endpoint file changes without edge recompute |
| `cluster_alignment` | File's vector distance from its cluster centroid | Degrades when centroid drifts beyond threshold. **`null` when `cluster_stable_id = null` (singleton file)** — absence of cluster is not misalignment; do not report as 0.0 |
| `semantic_accuracy` | Domain annotations match the file's actual business purpose | `null` until `ontology_enricher` runs; drops when structural facts change significantly without re-enrichment, or when ontology version changes |

### `contextual_accuracy` — why it matters

A file can be perfectly fresh, yet its query result can be stale if its callers or callees changed.
ECLE tracks a **neighbourhood hash** per file — a hash of the IDs and content hashes of all
files within 2-hop graph distance. If a neighbour changes, `contextual_accuracy` drops
even though the file itself did not change. This prevents confidently-wrong answers.

### `semantic_accuracy` — why it is separate from embedding

`cluster_alignment` measures structural proximity to a vector cluster centroid — a similarity concern.
`semantic_accuracy` measures whether the domain vocabulary annotations on this file still reflect its actual structural facts — a meaning concern. They degrade independently:
- A file can have `cluster_alignment=1.0` (tight vector cluster) and `semantic_accuracy=null` (never annotated).
- A file can have `semantic_accuracy=0.9` (well-annotated) and `cluster_alignment=0.4` (drifted from centroid after recent changes).
- `semantic_accuracy` is `null`, not `0.0`, when unenriched — absence of annotation is not the same as wrong annotation.

---

## 2. Extraction fidelity ceiling

`extraction_fidelity` (from the language pack `manifest.yaml`) is a **hard ceiling**.
No dimension in the confidence profile can exceed this ceiling.

| `extraction_fidelity` | Ceiling applied | Meaning |
|---|---|---|
| `FULL` | 1.0 | Tree-sitter grammar produced complete structural facts |
| `PARTIAL` | 0.8 | Grammar exists but extraction is incomplete (e.g. XML) |
| `HEURISTIC` | 0.6 | Text/OCR extraction — structural meaning is inferred |
| `HEURISTIC` + `used_fallback: true` | 0.5 | DefaultPack fired — no grammar match |

Ceiling propagation is **mandatory**:
- A topology edge where either endpoint is `PARTIAL` → the edge's confidence profile ceiling = 0.8.
- A cluster centroid with any `HEURISTIC` constituent file → cluster confidence ceiling = 0.6.
- An MCP tool result derived from a `HEURISTIC` file → the tool response ceiling = 0.6.

---

## 3. Confidence voting (learning loop)

```
new_accuracy = old_accuracy + (vote_delta / sqrt(total_votes))
```

- `CONFIRM` signal (developer accepts recommendation, code passes review) → increments `behavioral_accuracy`.
- `DENY` signal (developer rejects, code reverts) → decrements `behavioral_accuracy`.
- Diminishing returns: the 100th vote has less impact than the 10th.
- Floor: `behavioral_accuracy` MUST NOT drop below the extraction fidelity ceiling floor.
  A HEURISTIC file cannot be voted to 0 — minimum = 0.5.
- No vote = no change. `behavioral_accuracy` is stable until a vote or a code change arrives.

---

## 4. Confidence decay

**Principle: stable code earns stable confidence. Time passing is not evidence of wrongness.**

Confidence dimensions decay only when there is **evidence of change or inconsistency**. A file that has not changed, whose neighbours have not changed, and whose cluster has not drifted is correct until proven otherwise. Decaying it on a timer forces unnecessary re-indexing of valid facts and makes confidence an unreliable signal (FACT/Trustworthy violation).

| Dimension | Decays when | Reset condition |
|---|---|---|
| `syntactic_freshness` | `content_hash` differs from last indexed value | Re-parse completes; new artifact written |
| `behavioral_accuracy` | Source file changes (`content_hash` changes) OR extraction grammar version changes | Re-parse + persist completes on the changed file |
| `contextual_accuracy` | Any file within 2-hop graph distance changes (`neighbourhood_hash` changes) | Neighbour's `file.stored` event processed; neighbourhood_hash recomputed |
| `edge_coherence` | Either endpoint file changes | Both endpoints re-parsed and edge recomputed |
| `cluster_alignment` | Cluster centroid drifts beyond `CENTROID_DRIFT_THRESHOLD` (config, default: cosine distance > 0.15) | `cluster_centroids` worker re-assigns file to updated centroid. **Exempt for singleton files (`cluster_stable_id = null`): `cluster_alignment = null`, not 0.0.** |

**What does NOT trigger decay:**
- Time elapsed without a vote — absence of vote is not evidence of inaccuracy
- Time elapsed without a code change — unchanged code is still correct
- A file being "old" — age alone carries no signal

**Vote signals (learning loop) adjust `behavioral_accuracy` up or down but never decay it passively:**
- `CONFIRM` signal → increment (developer accepted the recommendation)
- `DENY` signal → decrement (developer rejected; code reverted)
- Floor: `behavioral_accuracy` MUST NOT drop below the fidelity ceiling floor (HEURISTIC minimum = 0.5)
- Without any votes, `behavioral_accuracy` remains at the value set at last extraction — it does not drift downward

Decayed entities (any dimension below their fidelity floor) are queued for re-indexing on the next commit touching them or their neighbours.

---

## 5. How to read the profile in query results

```json
"confidence_profile": {
  "syntactic_freshness": 1.0,      ← IR artifact matches HEAD content_hash
  "behavioral_accuracy": 0.95,     ← slightly reduced by recent DENY votes
  "contextual_accuracy": 0.72,     ← a neighbour changed, neighbourhood_hash stale
  "edge_coherence": 0.91,          ← one edge endpoint was re-parsed, edge not yet recomputed
  "cluster_alignment": 0.84,       ← centroid has drifted beyond threshold since last assignment
  "semantic_accuracy": 0.88        ← domain annotations present and match current structural facts
},
"confidence_ceiling": 1.0,         ← FULL fidelity, no ceiling applied
"extraction_fidelity": "FULL"
```

The MCP server and GraphQL layer MUST surface these to the AI agent.
The AI agent MUST NOT make confident claims from a result where any dimension < 0.7
without surfacing a caveat to the user.

---

## 6. What is banned

- A single `confidence: 0.92` scalar — which dimension is 0.92? Always use all six.
- Suppressing low confidence dimensions from the response — a dimension of 0.3 must be visible.
- Returning `semantic_accuracy: 0.0` for an unenriched file — use `null`; absence of annotation is not wrong annotation.
- Hard-coding confidence values — all values are computed from live data, never static.
- Conflating `cluster_alignment` with `semantic_accuracy` — vector proximity and domain meaning are independent dimensions.
- Skipping `contextual_accuracy` because it is "too complex" — it is the key innovation; omitting it means the system gives confidently-wrong answers when neighbours change.

---

## 7. References

| # | Citation | Relevance |
|---|----------|----------|
| R1 | Khattab, O. & Zaharia, M. "ColBERT: Efficient and Effective Passage Search via Contextualized Late Interaction over BERT", SIGIR 2020 (arXiv:2004.12832) | Multi-dimensional similarity scoring over single-scalar — validates 6-dimension confidence over scalar confidence |
| R2 | Wang, R. & Strong, D. "Beyond Accuracy: What Data Quality Means to Data Consumers", JMIS 1996 | Multi-dimensional data quality; single scalar hides which dimension degraded |
| R3 | Wilson, E.B. "Probable Inference, the Law of Succession, and Statistical Inference", JASA 1927 | Wilson score interval — basis for diminishing-returns voting formula in §3 |
| R4 | Acar, U.A. "Self-Adjusting Computation", PhD thesis CMU 2005 | Incremental computation theory — contextual_accuracy's neighbourhood hash follows dependency graph invalidation |
