# Contract 17 — Phase Roadmap Contract

**Scope:** All specs, plans, and implementation work.  
**Enforced by:** Orchestrator agent, spec-reviewer agent, release-manager agent.  
**Status:** Active  
**Related:** Contract 02 (SDLC), Contract 09 (Event Pipeline), ADR-0010 (Three-Tier Deployment), ADR-0013 (Kafka), ADR-0027 (Async Autonomy), ADR-0035 (Phase as Product Milestone)

---

## 0. Purpose

This contract defines the **phase boundaries** for ECLE 2.0 development. Every phase is
a **product milestone** — it delivers a demonstrable, user-facing capability end-to-end.
No phase ends without something a user can interact with. Phases are sequential — a later
phase MUST NOT begin implementation until the preceding phase's exit criteria are met
(ADR-0035).

**HARD RULES:**

1. **No spec without a phase assignment.** Every spec's `Phase:` header MUST reference
   a phase defined in this contract.
2. **No phase-N+1 implementation until phase-N exit criteria pass.** The release-manager
   agent verifies exit criteria before recommending a version tag.
3. **Phases are additive.** Later phases extend earlier phases — they never break or
   replace delivered functionality.
4. **Verification is mandatory.** Each phase defines verification commands that must
   pass before the phase is considered complete.
5. **Scope is locked per phase.** If work doesn't fit the current phase's scope, it
   belongs to a later phase. No exceptions.
6. **Every phase has a walking skeleton.** The G3 planner MUST order walking-skeleton
   specs before enhancement specs in the implementation plan. Walking-skeleton specs are
   implemented first; enhancement specs extend the working skeleton within the same phase.
7. **Version tag = working product increment.** The version tag certifies that the
   milestone capability works end-to-end AND all specs (skeleton + enhancements) are
   `Status: Implemented`. The version tag is NEVER applied to the skeleton alone.

### Milestone model (ADR-0035)

Every phase definition in this contract contains three delivery structures:

| Structure | Definition |
|-----------|------------|
| **Milestone capability** | One sentence — the user-facing, demonstrable outcome the phase produces. The version tag certifies this capability works. |
| **Walking skeleton** | Minimum ordered set of specs whose completion produces the milestone capability end-to-end. Implemented first, in dependency order. |
| **Enhancement specs** | Remaining specs that extend the skeleton. Must all be `Status: Implemented` before the version tag. May be implemented in any order after the skeleton works. |

---

## 1. Phase 1 — Foundation: Kafka Workers + Structured DB + Parse Pipeline

**Milestone capability:** A developer can upload a source repository, have it parsed automatically, and query its functions, files, and SQL tables via MCP tools — all within a running ECLE instance.

**Entry criteria:** Constitution complete (all contracts, ADRs, schemas finalised).

### Walking skeleton

Minimum specs to deliver the milestone capability end-to-end. Implemented in this order:

| Order | Spec | Unlocks |
|-------|------|---------|
| 1 | SPEC-0001 — Foundation Interfaces | `IStructuredDB`, `IArtifactStore`, factory functions; all workers depend on this |
| 2 | SPEC-0008 — Kafka WorkerBase + Topic Registry | Worker lifecycle, offset management, DLQ routing; parse_repo and persist_facts depend on this |
| 3 | SPEC-0009 — Structured DB DDL | All DB tables; persist_facts depends on this |
| 4 | SPEC-0005 — parse_repo worker | Consumes `repo.detected` → extracts facts → emits `file.ir_produced` |
| 5 | SPEC-0006 — persist_facts worker | Consumes `file.ir_produced` → upserts structured DB → emits `file.stored` |
| 6 | SPEC-0007 — MCP Phase 1 Tools | `fact_find_files`, `fact_find_functions`, `fact_find_tables` with FACT envelope |

**Skeleton checkpoint:** After these six specs, a repo can be parsed via CLI trigger and queried via MCP.

### Enhancement specs

Extend the skeleton within Phase 1. All must be `Status: Implemented` before `v0.1.0`:

| Spec | What it adds |
|------|--------------|
| SPEC-0004 — Upload API + scan_source | `POST /upload` HTTP entry point; `scan_source` worker; replaces CLI trigger |
| SPEC-0002 — Language Pack Registry | Multi-language support; hot-reload; manifest validation; DefaultPack fallback |
| SPEC-0010 — Semantic Interpreter Worker | Deterministic fact annotation (ADR-0034); `ecle.facts.annotated` event; Phase 2 embedding prerequisite |
| SPEC-0011 — Deterministic Naming Enforcement | CI Stage 1 naming gate (`ECLE001`) for non-trivial scopes; deterministic lint findings for review readiness |

### Workers operational in Phase 1
- `scan_source`
- `parse_repo`
- `persist_facts`
- `semantic_interpreter` (file mode + repo mode)

### Events operational in Phase 1
- `upload.received`
- `source.received`
- `repo.detected`
- `file.ir_produced`
- `repo.ir_produced`
- `file.stored`
- `facts.annotated`

### Exit criteria (version tag: `v0.1.0`)
- [ ] All Phase 1 specs `Status: Implemented`
- [ ] Milestone capability demonstrated end-to-end
- [ ] `eval_schema_conformance` passes (facts validate against `facts-base-schema.json` v2.1)
- [ ] `eval_event_chain_complete` passes (upload → scan → parse → persist → MCP query)
- [ ] `eval_idempotent_ingest` passes (same event processed twice = same DB state)
- [ ] `eval_srp_isolation` passes (no cross-worker imports)
- [ ] `eval_fallback_coverage` passes (DefaultPack fires for `.xyz` files)
- [ ] Post-import smoke test passes (Contract 02 §9)
- [ ] Version tag: `v0.1.0`

### Verification commands
```bash
# Full event chain — from upload to query
POST /upload test_fixture.zip
ecle events --type repo.ir_produced --repo test_fixture
ecle stats --repo test_fixture           # files > 0, functions > 0
ecle mcp fact_find_files --repo test_fixture --query "*.py"   # results not empty
```

---

## 2. Phase 2 — Embedding + Vector Layers + Chunking

**Milestone capability:** A developer can search a repository using natural language ("find all billing functions") and receive semantically relevant results ranked by vector similarity — no keyword matching required.

**Entry criteria:** Phase 1 exit criteria met. `v0.1.0` tagged.

### Walking skeleton

| Order | Spec | Unlocks |
|-------|------|---------|
| 1 | Embedding model ADR (new) | Benchmark `all-MiniLM-L6-v2` vs alternatives; record model choice; required before any embed spec begins |
| 2 | IVectorStore ChromaDB impl (SPEC-TBD) | ChromaDB backend for `IVectorStore`; Layer 1 + Layer 2 collections; `batch_embed` depends on this |
| 3 | chunk_file worker (SPEC-TBD) | Consumes `file.stored` → chunks facts → emits `file.chunked` |
| 4 | batch_embed worker (SPEC-TBD) | Consumes `file.chunked` → ONNX embed → upserts vectors → emits `file.embedded` |
| 5 | fact_search MCP tool (SPEC-TBD) | Semantic search via Layer 1/2 vectors; FACT envelope response |

**Skeleton checkpoint:** After these five, a user can run a natural-language search against an indexed repo.

### Enhancement specs

| Spec | What it adds |
|------|--------------|
| Behavioral fingerprint gate (SPEC-TBD) | `version_distance < BEHAVIORAL_THRESHOLD` → skip re-embed on cosmetic changes |
| MCP SSE transport (SPEC-TBD) | HTTP SSE transport for MCP server (ADR-0006) |
| Auth — API keys (SPEC-TBD) | API key auth on MCP and Admin API (ADR-0019) |

### Workers operational (new in Phase 2)
- `chunk_file`
- `batch_embed`

### Events operational (new in Phase 2)
- `file.chunked`
- `file.embedded`

### Exit criteria (version tag: `v0.2.0`)
- [ ] All Phase 2 specs `Status: Implemented`
- [ ] Milestone capability demonstrated end-to-end
- [ ] `eval_fidelity_ceiling` passes (HEURISTIC fidelity → confidence ceiling ≤ 0.6)
- [ ] Refactor invariance eval passes (cosmetic rename → `version_distance < 0.05`)
- [ ] Embedding model ADR written and accepted
- [ ] `fact_search` returns results from Layer 1/2 vectors
- [ ] Version tag: `v0.2.0`

### Verification commands
```bash
ecle search "billing function" --repo test_fixture   # vector results, not empty
ecle stats --repo test_fixture --vectors             # layer1_count > 0, layer2_count > 0
```

---

## 3. Phase 3 — Topology Graph + Impact Analysis + GraphQL

**Milestone capability:** A developer can ask "what is the blast radius if I change this file?" and receive a multi-hop impact report showing every file, function, and service that would be affected — all grounded in the code topology graph.

**Entry criteria:** Phase 2 exit criteria met. `v0.2.0` tagged.

### Walking skeleton

| Order | Spec | Unlocks |
|-------|------|---------|
| 1 | ITopologyGraph impl (SPEC-TBD) | PostgreSQL recursive CTE backend; `build_graph` and `compute_topology` depend on this |
| 2 | build_graph worker (SPEC-TBD) | Consumes `file.ir_produced` → builds graph nodes + edges → emits `graph.updated` |
| 3 | compute_topology worker (SPEC-TBD) | Consumes `graph.updated` → Louvain community detection → emits `topology.updated` |
| 4 | fact_impact MCP tool (SPEC-TBD) | Multi-hop impact report from topology graph; the core milestone capability |

**Skeleton checkpoint:** After these four, `fact_impact` returns a grounded blast-radius report.

### Enhancement specs

| Spec | What it adds |
|------|--------------|
| GraphQL endpoint (SPEC-TBD) | FastAPI + Strawberry; query planner routes structured/vector/graph |
| fact_trace_path MCP tool (SPEC-TBD) | Call chain traversal (who calls what, how deep) |
| Coverage warnings (SPEC-TBD) | `indexing_state` completeness in FACT envelope |
| Incremental ingestion (SPEC-TBD) | `content_hash` skip rules (Contract 13) |

### Workers operational (new in Phase 3)
- `build_graph`
- `compute_topology`

### Events operational (new in Phase 3)
- `graph.updated`
- `topology.updated`

### Exit criteria (version tag: `v0.3.0`)
- [ ] All Phase 3 specs `Status: Implemented`
- [ ] Milestone capability demonstrated end-to-end
- [ ] `fact_impact` returns multi-hop results
- [ ] GraphQL schema validates (introspection returns schema)
- [ ] Louvain assigns `cluster_id` to all indexed files
- [ ] Incremental re-parse skips unchanged files
- [ ] Version tag: `v0.3.0`

---

## 4. Phase 4 — Ontology + DSL + Cluster Centroids

**Milestone capability:** A developer can ask "what business capabilities does this codebase support?" and receive a structured answer using domain vocabulary (e.g. "Billing: charge engine, fee calculation, invoice generation") — derived automatically from the code, not hand-authored.

**Entry criteria:** Phase 3 exit criteria met. `v0.3.0` tagged.

### Walking skeleton

| Order | Spec | Unlocks |
|-------|------|---------|
| 1 | Domain ontology YAML (SPEC-TBD) | Base + tenant YAML vocabularies (ADR-0025); required before DSL detection can classify anything |
| 2 | detect_dsl_mappings worker (SPEC-TBD) | Consumes `file.stored` → tags DSL concepts → emits `dsl.mapped` |
| 3 | ontology_enricher worker (SPEC-TBD) | Consumes `dsl.mapped` + `topology.updated` → enriches ontology → emits `ontology.enriched` |
| 4 | cluster_centroids worker (SPEC-TBD) | Consumes `file.embedded` + `topology.updated` → updates Layer 3 centroids |
| 5 | fact_view_database MCP tool (SPEC-TBD) | Exposes domain-annotated aggregate database view; the core milestone capability |

**Skeleton checkpoint:** After these five, a user can query domain-annotated capability views.

### Enhancement specs

| Spec | What it adds |
|------|--------------|
| Staleness enforcement (SPEC-TBD) | `staleness_score` on every cluster; `staleness_caveat` in FACT envelope (Contract 07) |
| fact_view_api_contracts MCP tool (SPEC-TBD) | Contract surface view across all entry points |
| sweep_coordinator (SPEC-TBD) | Celery Beat periodic re-index trigger for stale clusters |

### Workers operational (new in Phase 4)
- `detect_dsl_mappings`
- `ontology_enricher`
- `cluster_centroids`
- `sweep_coordinator` (Celery Beat periodic)

### Events operational (new in Phase 4)
- `dsl.mapped`
- `ontology.enriched`
- `re-embed.batch`

### Exit criteria (version tag: `v0.4.0`)
- [ ] All Phase 4 specs `Status: Implemented`
- [ ] Milestone capability demonstrated end-to-end
- [ ] `cluster_alignment` dimension active in confidence profile (not null)
- [ ] Staleness caveat appears in responses for stale clusters
- [ ] Layer 3 centroid count > 0 after full ingest
- [ ] `eval_staleness_honesty` passes
- [ ] Version tag: `v0.4.0`

---

## 5. Phase 5 — Cross-Repo Linking + Grounding + Feedback Loop

**Milestone capability:** A developer can ask "which other repositories depend on this shared library function?" and receive a cross-repo impact report — spanning multiple indexed repos — with complete grounding lineage on every result.

**Entry criteria:** Phase 4 exit criteria met. `v0.4.0` tagged.

### Walking skeleton

| Order | Spec | Unlocks |
|-------|------|---------|
| 1 | build_contract_registry worker (SPEC-TBD) | Consumes `repo.ir_produced` → extracts contracts → emits `contracts.registered` |
| 2 | link_contracts worker (SPEC-TBD) | Consumes `contracts.registered` → O(C log C) matching → emits `cross.linked` |
| 3 | cross_repo_indexer worker (SPEC-TBD) | Consumes `repo.indexed` → upserts cross-repo summary |
| 4 | Grounding verifier (SPEC-TBD) | Verifies all query results carry complete lineage (Contract 06); required before cross-repo results are surfaced |

**Skeleton checkpoint:** After these four, `fact_impact` spans multiple repos with full lineage.

### Enhancement specs

| Spec | What it adds |
|------|--------------|
| ecle_feedback MCP tool (SPEC-TBD) | Feedback signal collection from users (ADR-0024) |
| learning_analyzer worker (SPEC-TBD) | Consumes `feedback.given` → updates confidence votes → emits `confidence.updated` |
| coverage_gap_aggregator worker (SPEC-TBD) | Consumes `language_pack.extension_miss` → aggregates → emits `coverage_gap` |

### Workers operational (new in Phase 5)
- `build_contract_registry`
- `link_contracts`
- `cross_repo_indexer`
- `learning_analyzer`
- `coverage_gap_aggregator`

### Events operational (new in Phase 5)
- `contracts.registered`
- `cross.linked`
- `repo.indexed`
- `feedback.given`
- `confidence.updated`
- `language_pack.extension_miss`
- `language_pack.coverage_gap`

### Exit criteria (version tag: `v0.5.0`)
- [ ] All Phase 5 specs `Status: Implemented`
- [ ] Milestone capability demonstrated end-to-end
- [ ] Cross-repo `fact_impact` returns results spanning two repos
- [ ] `eval_grounding_coverage` passes (all query results carry complete lineage)
- [ ] Feedback loop: `ecle_feedback` → `confidence.updated` event chain works
- [ ] Version tag: `v0.5.0`

---

## 6. Phase 6 — Enterprise Scale-Out + Admin Portal + Production

**Milestone capability:** An enterprise team can onboard, manage, and monitor multiple tenant repositories through a web Admin Portal — with autoscaling workers, full observability, multi-tenant isolation, and a recoverable deployment — all without touching the CLI.

**Entry criteria:** Phase 5 exit criteria met. `v0.5.0` tagged.

### Walking skeleton

| Order | Spec | Unlocks |
|-------|------|---------|
| 1 | PostgreSQL backend (SPEC-TBD) | `IStructuredDB` PostgreSQL impl; pgbouncer mandatory (ADR-0010 Tier 3); all Tier 3 workers depend on this |
| 2 | Qdrant backend (SPEC-TBD) | `IVectorStore` Qdrant impl; production vector store |
| 3 | Neo4j backend (SPEC-TBD) | `ITopologyGraph` Neo4j impl; production graph store |
| 4 | Multi-tenancy (SPEC-TBD) | Tenant isolation (ADR-0022); RLS policies; required before Admin Portal can be safely exposed |
| 5 | Admin Portal UI (SPEC-TBD) | React 18 SPA — Onboard, Import Jobs, System Health, Worker Control (ADR-0026); the core milestone capability |

**Skeleton checkpoint:** After these five, an enterprise team can onboard repos and monitor jobs via the portal with tenant isolation enforced.

### Enhancement specs

| Spec | What it adds |
|------|--------------|
| KEDA autoscaling (SPEC-TBD) | Per-worker ScaledObject based on Kafka lag (ADR-0027) |
| Observability stack (SPEC-TBD) | Prometheus metrics, Grafana dashboards, OTel tracing (Contract 16) |
| Disaster recovery (SPEC-TBD) | Backup/restore procedures (ADR-0023) |
| Document embedding (SPEC-TBD) | `document_embedder` worker for non-code docs (Contract 12 §9) |

### Workers operational (new in Phase 6)
- `document_embedder`

### Exit criteria (version tag: `v1.0.0`)
- [ ] All Phase 6 specs `Status: Implemented`
- [ ] Milestone capability demonstrated end-to-end
- [ ] Tier 3 deployment works end-to-end (K8s + managed PG + Qdrant + Kafka cluster)
- [ ] Admin Portal: ZIP upload → file selection → import job tracking → completion
- [ ] KEDA scales workers based on Kafka lag
- [ ] `eval_observability_baseline` passes (Contract 16)
- [ ] `eval_log_masking` passes (no PII in logs)
- [ ] Multi-tenant isolation verified (Tenant A cannot see Tenant B data)
- [ ] DR drill executed successfully
- [ ] Version tag: `v1.0.0`

---

## 7. Rules for spec-writer and orchestrator

### Spec assignment
- Every spec MUST have `**Phase:** N` matching a phase in this contract
- The orchestrator MUST reject work that targets a phase whose entry criteria aren't met
- If a user requests work for a future phase, the orchestrator declares it and defers

### Scope enforcement
- If a spec grows to include deliverables from a later phase → STOP, split the spec
- The spec-reviewer MUST verify that the spec's scope fits within its declared phase
- No "Phase 1" spec may reference workers/events that only exist in Phase 3+

### Phase progression
- The release-manager verifies ALL exit criteria before recommending a version tag
- Version tags encode phase: `v0.{phase}.{patch}` for phases 1-5, `v1.0.0` for Phase 6
- Patches within a phase: `v0.1.1`, `v0.1.2` etc. (bug fixes, enhancements to existing specs)

### Constitution amendments
- Adding a new worker/event to Contract 09 requires identifying which phase it belongs to
- If a worker is added to Phase 1 scope, ALL Phase 1 exit criteria must still be achievable
- Phase scope can only be adjusted by amending this contract (requires user approval)
