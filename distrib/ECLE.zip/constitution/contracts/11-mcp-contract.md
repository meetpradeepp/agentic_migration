# Contract 11 — MCP Contract

**Scope:** Every MCP tool in `src/ecle/mcp/`.  
**Enforced by:** MCP response schema validation, `eval_grounding_coverage`, code review checklist.  
**Status:** Active  
**Related:** ADR-0006, ADR-0014, ADR-0017

---

## 1. Core rules — non-negotiable

1. **Every MCP tool response MUST be the FACT envelope** — no raw DB rows, no unstructured text.
2. **Tools MUST NOT generate content** — they return structured facts, never LLM-generated summaries.
3. **Tools MUST NOT access backends directly by name** — always via `IStructuredDB`, `IVectorStore`, `ITopologyGraph` factory functions.
4. **Tools MUST be stateless** — no session state between calls; every call is independent.
5. **Tools MUST validate input** before querying — invalid inputs return a structured error, never an exception trace.
6. **Every tool call MUST be written to `query_audit_log`** — tool name, query text, input summary (PII-free), and latency. No exceptions. The caller is informed via the `trustworthy.audit_notice` field in every FACT envelope response.
7. **Audit notice is mandatory in every response** — the `trustworthy.audit_notice` field MUST be set to `"Queries are recorded for system improvement and operational audit. See your organisation's data policy."` on every response. It MUST NOT be omitted, null, or empty.

---

## 2. FACT envelope — mandatory on every response

Every tool response MUST include the full FACT envelope defined in `constitution/contracts/04-fact-contract.md`.

A response missing any of the following is **malformed** and MUST NOT be returned:

```json
{
  "fact": {
    "fast":        { "query_ms": ..., "timed_out": false, "routing": "..." },
    "accurate":    { "confidence_profile": {...}, "confidence_ceiling": ..., "extraction_fidelity": "..." },
    "complete":    { "coverage_warnings": [...], "total_indexed_files": ..., "missing_repos": [...] },
    "trustworthy": {
      "timely":    { "knowledge_current_as_of": "...", "staleness_score": ..., "staleness_caveat": ... },
      "traceable": { "lineage": [...], "query_plan": [...] },
      "audit_notice": "Queries are recorded for system improvement and operational audit. See your organisation's data policy."
    }
  },
  "results":    [...],
  "total_hits": ...,
  "returned":   ...
}
```

`knowledge_current_as_of` MUST be an ISO-8601 timestamp. Absence = malformed response.

---

## 3. Per-result confidence profile — mandatory on every result item

Every item in `results[]` MUST include:

```json
"confidence_profile": {
  "syntactic_freshness":   float,   // 0.0–1.0 or null if not yet computed
  "behavioral_accuracy":   float,
  "contextual_accuracy":   float,
  "edge_coherence":        float,
  "cluster_alignment":     float | null,  // null until Phase 4
  "extraction_fidelity":   "FULL" | "PARTIAL" | "HEURISTIC",
  "confidence_ceiling":    float
}
```

Rules:
- `confidence_ceiling` is derived from `extraction_fidelity` per `05-confidence-contract.md`.
- No dimension may exceed `confidence_ceiling`.
- A scalar confidence number is **banned** — it hides which dimension degraded (anti-pattern).
- If a dimension cannot yet be computed (Phase 1 simplification): set to `1.0` for `is_current=True` rows, `0.5` for `is_current=False`. Document the simplification in the tool docstring.

---

## 4. Tool input rules

| Rule | Rationale |
|------|-----------|
| Required fields must be validated before any DB access | Fail fast — no partial work on invalid input |
| `limit` parameter MUST be clamped to `MAX_RESULTS` (default 100) | Prevents runaway queries |
| String filter parameters MUST be passed as parameterised SQL — never interpolated | SQL injection (anti-pattern A10) |
| Tool inputs MUST NOT accept raw SQL fragments | Attack surface; use typed filter objects || `query_intent` MUST be declared in tool schema with LLM guidance text (see §11) | Enables semantic-first routing; without it the planner falls back to heuristics |
---

## 5. Error response shape

When a tool cannot return results, it MUST return a structured error — never a Python exception trace:

```json
{
  "error": "validation_error" | "backend_unavailable" | "not_found" | "timeout",
  "message": "Human-readable explanation",
  "tool": "ecle_find_files",
  "input_received": { ... }
}
```

- `"backend_unavailable"` MUST NOT expose DB connection strings, internal paths, or stack traces.
- Empty results (`total_hits: 0`) are **not** errors — return a valid FACT envelope with `results: []`.

---

## 6. Coverage warnings — mandatory population rules

`fact.complete.coverage_warnings[]` MUST be populated when:

| Condition | Warning message |
|-----------|----------------|
| Queried `repo_id` has no rows in `indexing_state` | `"repo not indexed: {repo_id}"` |
| `indexing_state` has rows with `parse_status != 'done'` for queried repo | `"N files pending indexing in {repo_id}"` |
| `indexing_state` has rows with `parse_status = 'failed'` | `"N files failed indexing in {repo_id}; results may be incomplete"` |
| Any `file_facts` row returned has `is_current = False` | `"N results are from a superseded file version"` |

Coverage warnings MUST NEVER be suppressed. An empty `coverage_warnings: []` means no warnings, not that warnings were omitted.

---

## 7. Query result caps — mandatory

Every MCP tool that queries `file_facts`, `function_facts`, `function_calls`, topology
edges, or vector collections MUST apply an explicit `LIMIT`. Unbounded SELECTs, unbounded
graph traversals, and N+1 query loops are banned (Contract 10 anti-pattern A9).

These caps are proven production defaults validated on a 148,000-edge enterprise repository
(ECLE 1.0, SPEC-054). They are non-negotiable baselines; tools may expose them as
configurable parameters but MUST NOT exceed the hard upper bounds.

| Query type | Configurable default | Hard upper bound |
|---|---|---|
| Impact traversal results | 200 rows | 500 |
| `get_edges_from()` / `get_edges_to()` | 200 edges | 500 |
| `get_topology_edges()` (full dump) | 5,000 edges | 10,000 |
| Vector collection iteration (wildcard list) | 50 collections | 50 (hardcoded) |
| `search_file_ids(pattern, limit)` — ILIKE search | 5 matches | 20 |
| Word length minimum for ILIKE pattern | 3 chars (files), 4 chars (services) | hardcoded |

**Additional N+1 ban rules:**
- Platform-label lookups (`is_platform` flag per file): MUST be batched with a single
  `WHERE file_id IN (...)` query — never a per-row SELECT inside a result loop.
- Per-repo stats (`get_stats()` across multiple repos): MUST use `GROUP BY repo_id` in a
  single query — never a per-repo loop issuing one query per repo.
- `list_all_file_ids()` calls are banned. Use `search_file_ids(pattern, limit=5)` with a
  specific ILIKE pattern. Tools MUST NOT iterate the full file table to find matches.

**Lazy-init guard (anti-pattern A8):**
Backend handles (DB connection pools, vector store clients) MUST be fully initialised
and assigned before the worker's ready flag is set. The ready flag MUST NOT be set if
initialisation raises an exception. Pattern:

```python
self._db = create_db_client()   # raises on failure
self._ready = True              # only reached if create_db_client() succeeded
```

Setting `self._ready = True` before `self._db` is assigned is a constitution violation
and will be caught by `eval_query_caps`.

---

## 8. Transport — HTTP only, all phases

**stdio transport is banned.** The MCP server MUST use HTTP from Phase 1.

**Rationale:**
- stdio binds the MCP server to a single calling process — VS Code, CLI, and an agent cannot
  share the same MCP server simultaneously
- HTTP loopback (Phase 1 `dev` tier) has equivalent latency to stdio for local use
- HTTP allows auth, CORS, and multi-client support from day one without a Phase 2 retrofit
- All three deployment tiers (ADR-0010) use HTTP — one transport, zero branching
- Consistent with the event pipeline (Kafka HTTP consumers) and the deployment contract (§14)

### HTTP surface
|----------|-------|
| Protocol | HTTP/1.1 minimum; HTTP/2 preferred at Tier 3 |
| Binding (Tier 1 dev) | `localhost:4000` (default; overridable via `MCP_PORT`) |
| Binding (Tier 2/3) | Behind reverse proxy (nginx/ingress); not exposed directly |
| MCP endpoint | `POST /mcp` — single endpoint; tool name in JSON-RPC body |
| Health endpoint | `GET /health` — returns `{"status": "ok", "version": "..."}` |
| Metrics endpoint | `GET /metrics` — Prometheus format; disabled in dev tier |

### Request format — JSON-RPC 2.0 over HTTP POST

```http
POST /mcp HTTP/1.1
Content-Type: application/json
Authorization: Bearer <token>   ← required Phase 2+; omitted in dev tier
X-Tenant-Id: acme               ← required all phases
X-Request-Id: uuid              ← required all phases; echoed in response

{
  "jsonrpc": "2.0",
  "id": "req-uuid",
  "method": "tools/call",
  "params": {
    "name": "ecle_find_files",
    "arguments": {
      "repo_id": "billing-service",
      "language": "c",
      "query_intent": "locate",
      "known_anchors": { "module_hint": "billing" }
    }
  }
}
```

### Response format

```http
HTTP/1.1 200 OK
Content-Type: application/json
X-Request-Id: uuid              ← echoed from request
X-Query-Mode: composite         ← routing mode used
X-Search-Depth: layer1          ← cascade layer that answered (omit for structured)

{
  "jsonrpc": "2.0",
  "id": "req-uuid",
  "result": {
    "content": [ { "type": "text", "text": "{...FACT envelope JSON...}" } ],
    "isError": false
  }
}
```

Errors use `"isError": true` with the §5 error shape inside `content[0].text`.
HTTP status is always `200` for JSON-RPC (transport-level success); tool-level errors
are in `isError`. HTTP 4xx/5xx are reserved for transport failures only:

| HTTP status | Meaning |
|-------------|--------|
| `200` | Tool call completed (check `isError` for tool-level error) |
| `400` | Malformed JSON-RPC envelope (not a tool error) |
| `401` | Missing or invalid bearer token (Phase 2+ only) |
| `403` | `X-Tenant-Id` not authorised for this server |
| `429` | Rate limit exceeded |
| `503` | MCP server starting up or backend unavailable |

### Headers — required on every request

| Header | Required | Notes |
|--------|----------|-------|
| `Content-Type: application/json` | All phases | |
| `X-Tenant-Id` | All phases | Validated against `repositories` table; `403` if unknown |
| `X-Request-Id` | All phases | UUID; used for log correlation; echoed in response |
| `Authorization: Bearer <token>` | Phase 2+ | Dev tier skips auth when `MCP_AUTH_DISABLED=true` |

### CORS (browser-based callers)

| Setting | Value |
|---------|-------|
| `Access-Control-Allow-Origin` | `MCP_CORS_ORIGINS` env var (default: `localhost` only in dev) |
| `Access-Control-Allow-Methods` | `POST, GET, OPTIONS` |
| `Access-Control-Allow-Headers` | `Content-Type, Authorization, X-Tenant-Id, X-Request-Id` |
| Credentials | `false` — bearer token in header, not cookie |

CORS wildcard (`*`) is **banned** — it would allow any origin to query tenant data.

### Timeout

The MCP server enforces a **2-second hard timeout** on every tool call (FACT.Fast contract).
If the backend does not respond within 2000 ms:
- Return FACT envelope with `fast.timed_out: true`
- Partial results (if any) included with `coverage_warnings: ["response timed out — results may be incomplete"]`
- HTTP status: `200` (tool-level timeout, not transport failure)
- Never block indefinitely

### Progress notifications (within a turn)

When the JSON-RPC request includes `_meta.progressToken`, the server MUST emit
`notifications/progress` on the held-open HTTP connection after each flow step completes:

```json
{
  "jsonrpc": "2.0",
  "method": "notifications/progress",
  "params": {
    "progressToken": "req-uuid-001",
    "progress": 2,
    "total": 4,
    "message": "layer2_ann: 50 candidates found"
  }
}
```

- `message` text comes from `StepResult.notes[]` — produced from structured data (counts,
  IDs, scores). Never generated text.
- `progress` is 1-based step index; `total` is the total steps in the selected flow.
- If `_meta.progressToken` is absent, progress notifications are silently suppressed.

### GraphQL endpoint

The MCP server calls `POST /graphql` for all tool queries, all phases. The GraphQL
resolvers and all three backends (`IStructuredDB`, `IVectorStore`, `ITopologyGraph`)
are wired from Phase 1. Phase delivery controls which **tools** are shipped, not which
backends the resolver layer supports.

```
MCP tool handler
    │
    ▼
POST /graphql   (Strawberry, same process — in-process call, not a network hop)
    │
    ├── structured resolver → IStructuredDB    (Phase 1+)
    ├── vector resolver     → IVectorStore     (Phase 2+)
    └── graph resolver      → ITopologyGraph   (Phase 3+)
```

The GraphQL schema is checked into `src/ecle/graphql/schema.py`. Schema changes require
a PR with reviewer sign-off. Introspection is disabled in Tier 2/3 production
(`GRAPHQL_INTROSPECTION=false`); enabled in Tier 1 dev for tooling support.

The MCP server has no session state. Every `POST /mcp` is independent.
`X-Request-Id` is for log correlation only — not a session identifier.
Horizontal scaling: any instance can handle any request.

---

## 8. What tools MUST NOT do

| Banned behaviour | Anti-pattern |
|-----------------|--------------|
| Generate or infer content not present in the structured facts | A hallucination risk — LLM generation is only allowed in Layer 4 query formatting, not in tool logic |
| Return raw DB rows without FACT envelope | Violates FACT Contract (04) |
| Hardcode a backend (e.g. `import chromadb` directly in a tool) | Anti-pattern A6 |
| Return results without `confidence_profile` | Violates Confidence Contract (05) |
| Suppress `coverage_warnings` | Violates FACT Contract (04) — Complete property |
| Accept `repo_id = "*"` wildcard without explicit opt-in | Could trigger full-corpus scans; each tool must document whether cross-repo queries are supported |
| Expose DB errors directly in the response | Security — `backend_unavailable` error shape only |
| Call another MCP tool from within a tool | Breaks FACT lineage — only outer tool visible to caller; use FlowExecutor + StepRegistry instead (ADR-0018) |
| Return a rewritten or reformulated query string | Text generation — `ecle_enrich` returns structured vocabulary metadata only, never prose |

---

## 9. Tool catalogue

Tools are shipped in phases as their backing data layer becomes available. The phase
assignment is the contract — a Phase 2 tool MUST NOT be shipped before Phase 1 is
complete (Contract 17).

**Consolidation principle:** ECLE 1.0 had 30+ tools, many of which were filter
variations of the same query. ECLE 2.0 consolidates these into fewer, richer tools
with typed filter parameters. The table below records the ECLE 1.0 tool that each
ECLE 2.0 tool replaces, for traceability.

### Phase 1 — Foundation (structured DB + source access)

| Tool | Backend | ECLE 1.0 equivalent | Description |
|------|---------|--------------------|----|
| `ecle_find_files` | `IStructuredDB` | `ecle_file` + `ecle_files` + `ecle_file_history` | File lookup with filters: repo, language, execution model, entry-point flag, complexity range, history flag. Replaces three separate ECLE 1.0 tools via parameter-based dispatch. |
| `ecle_find_functions` | `IStructuredDB` | `ecle_functions` | Functions sorted by complexity; filter by entry-point type, min complexity, repo. |
| `ecle_find_callers` | `IStructuredDB` | `ecle_find_callers` + `ecle_service_callers` (partial) | All callers of a named function. When `resolve_service_name=true`, joins to `shared_artifacts` (type=SERVICE) to return Tuxedo/RPC service names alongside file callers (ADR-0031). |
| `ecle_find_tables` | `IStructuredDB` | `ecle_find_by_table` | Files and functions that read/write a named table. Includes operation type (READ/WRITE/DDL). |
| `ecle_find_by_column` | `IStructuredDB` (`function_table_ops`) | — (new, ADR-0031) | Functions that touch a specific column in a specific table. Answers "what updates INIT_ACTIVATION_DATE in SUBSCRIBER?". |
| `ecle_find_literal` | `IStructuredDB` (`file_literals`) | — (new, ADR-0031) | Files and functions containing a specific string constant. Answers "what code creates event P10MDataPassEndOfServiceOccurred?". |
| `ecle_find_entry_points` | `IStructuredDB` | `ecle_service_io` (partial) | Entry points by type: `tuxedo_service`, `http_handler`, `batch_main`, `scheduled`, `event_handler`, `rpc_service`. |
| `ecle_field_lookup` | `IStructuredDB` (`field_extractions`) | `ecle_view_fields` | Field/column definition from platform DDL or XML specs. Returns type, length, valid values, description, parent table. Answers "what is TFB account" and "where is bill type stored?". |
| `ecle_repo_summary` | `IStructuredDB` | `ecle_stats` + `ecle_repos` | Repo overview: file count, function count, edge count, table ops, languages, last indexed. `scope=single` (default) or `scope=all` to list all repos. |
| `ecle_source` | `IArtifactStore` | `ecle_source_read` | Raw source code for a file. Params: `file_path`, `repo_id`, `line_start` (optional), `line_end` (optional), `commit_sha` (optional). |

### Phase 2 — Semantic + cross-repo

| Tool | Backend | ECLE 1.0 equivalent | Description |
|------|---------|--------------------|----|
| `ecle_search` | `IVectorStore` | `ecle_search` + `ecle_source_lookup` | Semantic search: natural language → ranked file/function results. Includes BM25 hybrid with RRF fusion (ADR-0004-A2) and Muvera re-ranking (ADR-0004-A1). |
| `ecle_find_similar` | `IVectorStore` | — | Files/functions semantically similar to a given file or function. |
| `ecle_find_duplicates` | `IVectorStore` | — | Potential duplicate logic clusters across repos. |
| `ecle_search_docs` | `IVectorStore` (`__docs` collection) | — | Semantic search over indexed documentation (platform docs repos). |
| `ecle_enrich` | `IStructuredDB` + `IVectorStore` | `ecle_enrich` + `ecle_context_resource` | Mandatory first call for complex queries. Extracts entities, resolves vocabulary, returns routing context. `ecle_context_resource` is retired — `ecle_enrich` is the single entry point. |
| `ecle_shared_artifacts` | `IStructuredDB` | `ecle_shared_artifacts` + `ecle_artifact_summary` | Repos that touch a named artifact. `mode=single` (default) returns one artifact's repo list. `mode=summary` lists all shared artifacts ranked by breadth — replaces `ecle_artifact_summary`. |
| `ecle_service_map` | `IStructuredDB` (`service_call_index` + `shared_artifacts`) | `ecle_service_map` + `ecle_service_files` (partial) | Full map of a service: implementors, callers, callee dependencies, tables touched. Backed by `service_call_index` populated from platform service registry repos (ADR-0031). |
| `ecle_feedback` | `IStructuredDB` (write: `confidence_votes`) | — | Developer feedback on result quality. Emits `feedback.given` Kafka event (ADR-0024). |

### Phase 3 — Topology + impact analysis

| Tool | Backend | ECLE 1.0 equivalent | Description |
|------|---------|--------------------|----|
| `ecle_impact` | `ITopologyGraph` | `ecle_impact` + `ecle_service_impact` + `ecle_cross_repo_impact` | Change impact analysis. `scope=file` (default), `scope=service`, `scope=cross_repo`. Replaces three ECLE 1.0 tools via scope parameter. |
| `ecle_trace_path` | `ITopologyGraph` | `ecle_trace` + `ecle_estimate_change` | Trace execution path between two entities; estimate change blast radius (files, tables, services, effort sequence). |
| `ecle_trace_data` | `ITopologyGraph` | `ecle_trace` (data flow variant) | Trace data lineage: which writers feed which readers for a given table. |
| `ecle_view_database` | `IStructuredDB` + `ITopologyGraph` | — | Database lineage view: all tables, all writers/readers, all functions, with topology context. |
| `ecle_view_api_contracts` | `IStructuredDB` + `ITopologyGraph` | — | API contract view: endpoints, consumers, producers, schema versions. |
| `ecle_view_security` | `IStructuredDB` | — | Security hotspot view: auth files, crypto usage, input validation gaps. |
| `ecle_cross_repo_links` | `IStructuredDB` (`cross_repo_edges`) | `ecle_cross_repo_edges` | All cross-repo connections (inbound + outbound) for a repo. |

### Retired ECLE 1.0 tools (not carried forward)

| ECLE 1.0 tool | Reason not carried forward |
|--------------|---------------------------|
| `ecle_context_resource` | MCP resource wrapper around `ecle_enrich` — redundant; `ecle_enrich` is the single entry point |
| `ecle_common_fields` | Two `ecle_field_lookup` calls + agent-side diff is sufficient; a dedicated tool adds no DB-side value |

---

## 12. API versioning — additive-only evolution

The FACT envelope, MCP transport, and GraphQL schema MUST evolve additively. Breaking changes require a deprecation cycle.

**Additive-only rules (no version bump required):**
- New fields added to the FACT envelope `fast`, `accurate`, `complete`, `trustworthy`, or `semantic` blocks
- New tools added to the tool catalogue
- New optional parameters added to existing tool schemas
- New `reason_code` values in `suggested_next`

**Breaking changes (require deprecation cycle before removal):**
- Renaming or removing existing FACT envelope fields
- Changing the type of an existing field (e.g. `query_ms` from int to float requires explicit notice)
- Removing or renaming existing tools
- Removing or renaming existing required tool parameters

**Deprecation cycle:**
1. Mark field/tool/parameter as `"deprecated": true` in the schema and a `X-Deprecation-Notice` response header.
2. Keep the deprecated item functional for at minimum one full minor release cycle (Phase N → Phase N+1).
3. Emit `WARN` log on every use of a deprecated item.
4. Remove in the next phase after the deprecation notice.

**Endpoint versioning:**
- The MCP endpoint (`POST /mcp`) is NOT versioned in the URL — JSON-RPC method name is the contract surface.
- The Admin API (`/admin/v1/...`) uses URL versioning. A breaking Admin API change requires `/admin/v2/...` to be introduced before `/admin/v1/...` is removed.
- The GraphQL endpoint (`POST /graphql`) uses schema introspection for capability discovery — no URL versioning.

**Client compatibility guideline:** Clients MUST ignore unknown fields in the FACT envelope (additive compatibility). A client that fails on encountering an unknown field is non-compliant.

When reviewing any MCP tool PR:

- [ ] FACT envelope present on every return path (including error paths)
- [ ] `confidence_profile` present on every result item
- [ ] `coverage_warnings` populated per §6 rules
- [ ] `knowledge_current_as_of` present and set from `indexing_state`
- [ ] No backend hardcoded — uses factory function
- [ ] `limit` clamped to `MAX_RESULTS`
- [ ] All string filters use parameterised queries
- [ ] Error shape conforms to §5 — no raw exception traces
- [ ] `query_intent` argument present in tool schema with description text per §11
- [ ] `query_mode` in FACT envelope reflects the mode actually used (sourced from `query_intent` or fallback heuristic)
- [ ] `flow_id` present in `fast` block — matches a known flow in `flow_registry.json`
- [ ] `step_ms[]` present in `fast` block — one entry per step that ran
- [ ] `suggested_next` populated per ADR-0018 rules table, or explicitly `null`
- [ ] `enrich_carry` populated if enrich step ran, `null` otherwise

---

## 11. Caller intent protocol — LLM agent guidance

All MCP query tools accept two additional structured arguments that the **calling LLM agent is responsible for populating** from conversation context:

```json
{
  "query_intent": "explore" | "locate" | "precise",
  "known_anchors": {
    "file_path":      "src/billing/payment.py",   // if known
    "function_name":  "process_payment",           // if known
    "class_name":     "PaymentService",            // if known
    "table_name":     "payments",                  // if known
    "module_hint":    "billing",                   // soft hint — not an exact identifier
    "entity_type":    "class" | "function" | "file" | "table" | null
  }
}
```

**`query_intent` values:**

| Value | Meaning | Maps to query mode |
|---|---|---|
| `"explore"` | User is conceptually exploring — no known anchor, open-ended question | Semantic (Mode 1) |
| `"locate"` | User knows what they are looking for but does not have the exact identifier | Composite (Mode 3) |
| `"precise"` | User has a specific known anchor (file path, function name, table name) | Structured (Mode 2) |

**`known_anchors` is always optional.** If the LLM knows some context (e.g. the conversation has established we are in the billing module) it passes `module_hint: "billing"` even for an `explore` query. The query planner uses it to pre-scope the ANN search. If nothing is known, pass `known_anchors: {}`.

**Tool description template (required on every tool):**

Every MCP tool schema MUST include this guidance block in its `description` field, adapted to the tool:

```
Before calling this tool, classify the user's current intent from conversation context:
- If the user is exploring a concept with no specific code location in mind: query_intent="explore"
- If the user is looking for something specific but you do not yet have an exact file/function name: query_intent="locate"
- If the user has named a specific file, function, class, or table: query_intent="precise"
Pass any identifiers or module hints you have established in known_anchors{}.
Do not guess identifiers — only pass what the user has explicitly stated or what is unambiguous from context.
```

**Fallback behaviour:** if `query_intent` is absent (older client, non-LLM caller), the query planner falls back to the heuristic argument-presence check defined in ADR-0014. `query_intent` absent is never an error — it degrades gracefully.

**`query_mode` in FACT envelope** MUST reflect the mode actually executed, regardless of source:

```json
"fast": {
  "query_ms": 42,
  "timed_out": false,
  "routing": "composite",
  "intent_source": "caller"   // "caller" | "heuristic" | "default"
}
```

`intent_source: "heuristic"` or `"default"` in production is a signal that the calling agent is not passing `query_intent` — worth investigating.

---

## 12. References

| # | Citation | Relevance |
|---|----------|----------|
| R1 | Model Context Protocol Specification, LF Projects 2025 (modelcontextprotocol.io/specification) | Official MCP spec (JSON-RPC 2.0, BCP 14 terminology). ECLE's Contract 11 implements MCP's Resources + Tools features |
| R2 | MCP Spec §3: Security and Trust & Safety — "tools represent arbitrary code execution and must be treated with appropriate caution" | Validates ECLE's input validation before any backend access (§4) |
| R3 | Microsoft Language Server Protocol (LSP) — microsoft.github.io/language-server-protocol/ | MCP's design inspiration (per MCP spec docs); validates modular tool interface pattern |
| R4 | Principled GraphQL — principledgraphql.com, Principle #10: "Separate the GraphQL Layer from the Service Layer" | Validates MCP+GraphQL layering: MCP tools are the client-facing layer; GraphQL routes to backends |
| R5 | Schick, T. et al. "Toolformer: Language Models Can Teach Themselves to Use Tools", 2023 (arXiv:2302.04761) | Validates structured tool interfaces for AI agents; tools must declare schema, validation, and intent |
