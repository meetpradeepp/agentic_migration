# Contract 07 — Staleness Contract

**Scope:** Every query response from the GraphQL endpoint and MCP tools.  
**Enforced by:** `eval_staleness_honesty` (nightly hard gate), response envelope validation.  
**Status:** Active

---

## 1. The unconditional guarantee

**ECLE NEVER silently serves a stale answer as if it were fresh.**

When an agent or engineer queries any layer, the answer either:
(a) reflects the latest indexed state of the codebase, OR
(b) is transparently honest about its staleness — with a caveat, a score, and a timestamp.

Option (c) — serving stale knowledge as if fresh — does not exist in ECLE.

---

## 2. Staleness score

Every `file_facts` row carries a `staleness_score` (0.0 – 1.0).

```
staleness_score = own_staleness + contextual_staleness_contribution

own_staleness = 1.0  if content_hash differs from last indexed value (file changed, not re-parsed)
                0.0  if content_hash matches (file is current)

contextual_staleness_contribution = changed_neighbours / total_neighbours_within_2_hops
```

Where:
- `changed_neighbours` = count of files within 2-hop graph distance whose `content_hash` has changed since this file was last indexed
- `total_neighbours_within_2_hops` = count of files within 2-hop graph distance at time of last indexing (minimum 1 to avoid division by zero)

`staleness_score` is bounded to `[0.0, 1.0]`. A file with `own_staleness=0.0` and all neighbours current has `staleness_score = 0.0`.

The score is recomputed when:
- The file's own `content_hash` changes
- Any file within 2-hop graph distance has its `content_hash` change

**What does NOT recompute staleness score:**
- Cluster centroid drift — that is a `cluster_alignment` confidence signal, not a staleness signal
- Time passing — consistent with `05-confidence-contract.md` principle: stable code earns stable score

---

## 3. Response rules by staleness score

| Score | Response behaviour | Caveat in response |
|---|---|---|
| `0.0 – 0.1` | Serve from cache, no caveat | None |
| `0.1 – 0.3` | Serve from cache with staleness caveat | `"staleness_caveat": "Knowledge from <date>; re-indexing queued"` |
| `0.3 – 1.0` | Serve with WARNING caveat; **emit a re-index event** (non-blocking; pipeline picks it up asynchronously) | `"staleness_caveat": "WARNING: significant staleness detected. Results may not reflect recent changes."` |
| Never | Block response and wait for re-ingestion to complete | N/A — always serve something, always with honesty |

The last row is deliberate: **always serve something, always honest**.
Blocking a response while waiting for re-ingestion = making the system unusable under load.

---

## 4. What every response MUST include

```json
"trustworthy": {
  "timely": {
    "knowledge_current_as_of": "2026-05-05T09:14:00Z",
    "staleness_score": 0.02,
    "staleness_caveat": null
  }
}
```

`knowledge_current_as_of` is the **oldest** `last_indexed_at` timestamp across all `file_facts` rows involved in this response. It reflects the freshness of the stalest component — not the freshest. A response involving 10 files where 1 was indexed 30 days ago must report that timestamp, not the timestamp of the 9 current files.

Absence of this field = malformed response = GraphQL layer rejects it.

---

## 5. Staleness at the cluster level

For responses involving Louvain clusters:

```
cluster_staleness_score = sum(file_staleness_score * file_centrality for file in cluster)
                          / sum(file_centrality for file in cluster)
```

Where `file_centrality` = in-degree + out-degree of the file in the topology graph (hub files weighted more heavily than leaf files).

**Singleton guard:** Files with `cluster_stable_id = null` (singletons — ADR-0011 `LOUVAIN_MIN_CLUSTER_SIZE` exclusion) do not participate in any cluster staleness score. They carry their own `staleness_score` directly in the response. A query whose results are entirely singletons has no cluster-level staleness score — omit the field.

A cluster re-index event is emitted (non-blocking, not triggered from the query path) when:
1. `cluster_staleness_score` crosses 0.30, OR
2. A hub file (centrality ≥ `CLUSTER_HUB_THRESHOLD`, default: top 10% by centrality) in the cluster has `staleness_score > 0.0`, OR
3. An engineer explicitly invalidates a claim via the feedback API.

Re-synthesis is always async — the current query continues to completion with honest staleness caveats.

---

## 6. Hard gate

**A system that returns `confidence = 1.0` on stale knowledge is WORSE than one that returns nothing.**

`eval_staleness_honesty` runs nightly:
- Ingest a fixed reference corpus (minimum 500 files, defined in `tests/fixtures/staleness_eval/`).
- Simulate 5 commits that each change 10% of the corpus files — without re-indexing.
- Query the stale corpus across all three MCP tools.
- **Pass criteria:** every response has `staleness_score > 0.0` for files touched by the simulated commits AND a non-null `staleness_caveat`; `knowledge_current_as_of` reflects the oldest indexed timestamp, not the newest.
- Failure = release is blocked.

This eval cannot be skipped, mocked, or marked as "known failure".

---

## 6. References

| # | Citation | Relevance |
|---|----------|----------|
| R1 | RFC 9111 (HTTP Caching, supersedes RFC 7234) — httpwg.org | HTTP cache validation model: staleness determined by evidence (ETag/Last-Modified), not arbitrary TTL — same principle as ECLE's content_hash-based staleness |
| R2 | RFC 5861 — HTTP Cache-Control Extensions for Stale Content (stale-while-revalidate) | "Serve stale with caveat while revalidation happens async" — ECLE's staleness_caveat + async re-index event follows this exactly |
| R3 | Acar, U.A. "Self-Adjusting Computation", PhD thesis CMU 2005 | Dependency graph invalidation: recompute only what changed. ECLE's neighbourhood hash is an application of this theory |
| R4 | Mariappan, M. & Vora, K. "GraphBolt: Dependency-Driven Synchronous Processing of Streaming Graphs", EuroSys 2019 | Tracks dependencies across graph changes; validates neighbourhood-hash approach for contextual staleness |
