# Contract 19 — CPG Extraction Tier Contract

**Scope:** Every language pack, the `parse_repo` worker, the `persist_facts` worker, every MCP tool that reads extraction facts, and every component that reports confidence profiles.
**Enforced by:** `eval_two_phase_cycle` (every PR), `eval_extraction_tier_label` (every PR), `eval_c_family_extractors` (every PR), `eval_idempotent_ingest` (every PR), `eval_fidelity_ceiling` (every PR).
**Status:** Active
**Related:** ADR-0032 (Two-Phase CPG Extraction), ADR-0033 (C-Family Shared Extractor Library), ADR-0016 (Extraction Depth Standard), Contract 05 (Confidence Contract), Contract 08 (Language Pack Contract), Contract 13 (Incremental Ingestion Contract), Contract 15 (DB Schema Contract)

---

## 0. The tier guarantee

**Every fact committed to the ECLE knowledge graph is at full extraction depth.**

The two-phase extraction pipeline (ADR-0032) uses structural extraction as an intermediate
stage to pre-compute tree-sitter facts before Joern runs. Structural artifacts live in the
artifact store only — they are never committed to `file_facts`. `persist_facts` MUST reject
any artifact that still carries `_extraction_tier`, enforcing the invariant at the
machine level.

This contract is the single source of truth for what each extraction phase produces,
how phases hand off via Kafka, how artifacts are merged, and what governance rules apply.

---

## 1. Phase definitions

| Phase | Signal | Parser | Destination | DFG edges | Type resolution | Macros / Typedefs |
|-------|--------|--------|-------------|-----------|-----------------|-------------------|
| Structural | `"_extraction_tier": "structural"` in `.facts.json` | `fast_extractor.py` (tree-sitter) | Artifact store only (no DB write) | ❌ Empty `[]` | ❌ Syntactic only | ✅ C-family packs |
| Deep (full) | `_extraction_tier` absent from final `.facts.json` | `extractor.sc` (Joern CPG) | Artifact store → `file_facts` DB via `persist_facts` | ✅ Extracted | ✅ Type-resolved | ✅ from tree-sitter (Kept) |

**Structural is an intermediate phase, not a DB tier.** No `extraction_tier` column exists
on `file_facts`. All committed rows are full-depth by construction. A `.facts.json` file
that still carries `_extraction_tier` at `persist_facts` time is rejected with `ValueError`.

---

## 2. The `_extraction_tier` field in `.facts.json`

### 2.1 Rules for producers (`fast_extractor.py` / `extractor.sc`)

1. **`fast_extractor.py` MUST set `"_extraction_tier": "structural"`** in every facts dict it produces. Without this field, `persist_facts` cannot distinguish structural from full output and defaults to full — a silent accuracy violation.
2. **`extractor.sc` MUST NOT set `_extraction_tier`**. Absence is the canonical signal for full-depth Joern output. Setting `"_extraction_tier": "full"` is allowed but redundant and discouraged — it creates a divergence risk if the field name ever changes.
3. No other `_extraction_tier` value is valid. Any value other than `"structural"` or absent causes `persist_facts` to raise `ValueError` before DB write.

### 2.2 Rules for consumers (`persist_facts`)

`persist_facts` MUST guard against committing an intermediate artifact:

```python
tier = facts.get("_extraction_tier")
if tier is not None:
    raise ValueError(
        f"Artifact {artifact_path!r} still carries _extraction_tier={tier!r}. "
        "Deep enrichment did not complete. Cannot commit partial facts."
    )
```

This guard is the **only** place where `_extraction_tier` is read by a consuming worker.
If it is present, the artifact is an intermediate structural file that the deep phase did
not finish processing. No other worker reads or acts on `_extraction_tier`.

### 2.3 Required output fields per tier

`fast_extractor.py` (structural tier) MUST produce all fields in `CanonicalFactFileBase`.
The following fields MUST be empty `[]` at structural tier — populating them with
synthesised data is a FACT/Accurate violation:

- `data_flow_edges` — requires PDG; tree-sitter cannot produce this
- `control_flow_edges` — requires full CFG; tree-sitter cannot produce this
- `function_calls[].resolved_target` — requires type resolution; set to `null`

All other `CanonicalFactFileBase` fields are populated at structural tier to the extent
the grammar allows.

---

## 3. Language pack capability matrix

Every language pack declares its structural-tier capabilities in `manifest.yaml` under
the `fast_extraction` block. The `capabilities` list tells query layers what can be
answered at structural depth without a coverage warning.

| Language | Structural parser | `data_flow_edges` | SQL | Macros | Typedefs | Preprocessor branches |
|----------|------------------|------------------|-----|--------|----------|----------------------|
| C | tree-sitter-c | ❌ | ✅ (string literal scan) | ✅ | ✅ | ✅ |
| C++ | tree-sitter-cpp | ❌ | ✅ | ✅ | ✅ | ✅ |
| Pro*C | sanitizer + tree-sitter-c | ❌ | ✅ (`__JOERN_SQL_WRAPPER`) | ✅ | ✅ | ✅ |
| Java | tree-sitter-java | ❌ | ✅ (string literal) | ❌ | ❌ | ❌ |
| Python | tree-sitter-python | ❌ | ✅ (string literal) | ❌ | ❌ | ❌ |
| PowerBuilder | powerscript JAR | ❌ | ✅ (embedded SQL nodes) | ❌ | ❌ | ❌ |
| C# | tree-sitter-c-sharp | ❌ | ✅ (string literal) | ❌ | ❌ | ❌ |
| Go | tree-sitter-go | ❌ | ✅ (string literal) | ❌ | ❌ | ❌ |
| JavaScript | tree-sitter-javascript | ❌ | ✅ (string literal) | ❌ | ❌ | ❌ |

**C-family packs (C, C++, Pro\*C) MUST use `c_family_extractors.py`** (ADR-0033) for
macro, typedef, and preprocessor-branch extraction. Any C-family pack that re-implements
this logic inline violates ADR-0033 and will be rejected at code review.

Non-C-family packs MUST emit `"macros": [], "typedefs": [], "preprocessor_branches": []`
via `CanonicalFactFileBase` defaults — no explicit code required.

---

## 4. Phase routing and Kafka handoff (Contract 09, ADR-0032)

### 4.1 Event-driven phase handoff

The two phases are triggered by Kafka events — there is no ImportJob queue or polling:

| Event consumed | `parse_repo` action | Event emitted |
|---|---|---|
| `repo.detected` | Run `fast_extractor.py` per file; write `.facts.json` with `_extraction_tier: "structural"` to artifact store; NO DB write | `repo.structural_complete` (one per repo) |
| `repo.structural_complete` | Run Joern per file; merge structural artifact (merge table §4.2); remove `_extraction_tier`; write final `.facts.json` to artifact store | `file.ir_produced` per file; `repo.ir_produced` after all files |

Files listed in `failed_files[]` of `repo.structural_complete` had tree-sitter error-node
ratio > 5%. The deep phase runs Joern from scratch for these files (no structural artifact
to merge from). The final artifact has `_extraction_tier` absent — correct full-depth output.

### 4.2 Field merge table — Structural → Deep (authoritative, SPEC-049)

The deep phase applies the following rules field-by-field when combining Joern output
with the structural `.facts.json`. Implementations MUST NOT deviate from this table.

| Fact field | Tree-sitter produces | Merge rule |
|---|---|---|
| Function names | Yes | **Keep** (identical in both phases) |
| Function complexity | Basic (nesting depth) | **Replace** with Joern (cyclomatic) |
| Function parameters | Names only | **Replace** with Joern (names + types) |
| Local variables | No | **Add** from Joern |
| SQL statements | String-scanned (basic) | **Replace** with Joern (classified READ/WRITE/DDL) |
| Table operations | Partial | **Replace** with Joern (full) |
| Dependencies | Yes (syntactic) | **Union** with Joern (deduplicate by `id`/`name+line`) |
| Call graph | Static name | **Replace** with Joern (type-resolved targets) |
| Struct definitions | Yes | **Keep** tree-sitter (Joern does not extract) |
| Macro definitions | Yes | **Keep** tree-sitter (Joern does not extract) |
| Typedefs | Yes | **Keep** tree-sitter (Joern does not extract) |
| Preprocessor branches | Yes | **Keep** tree-sitter (Joern does not extract) |
| Data flow edges | No (empty `[]`) | **Add** from Joern |
| Control flow edges | No (empty `[]`) | **Add** from Joern |
| Comments | File-read | **Replace** with Joern (CPG-extracted) |
| Execution sequence | Basic | **Replace** with Joern (with data flow) |

### 4.3 Artifact store lifecycle

- Structural `.facts.json` files are written to `{artifact_root}/{repo_id}/{commit_sha}/facts/`.
- The deep phase reads them via `JOERN_EXISTING_FACTS` env var and writes the merged final
  artifact in-place (overwrite is safe — artifact writes are atomic via `tmp + rename()`).
- After `persist_facts` commits all files for the repo successfully, artifact store files
  may be cleaned up per ADR-0021 (Data Lifecycle) retention policy.
- If deep phase fails mid-repo, structural artifacts remain in the store — deep can be
  retriggered by replaying `repo.structural_complete` from Kafka.

### 4.4 Language packs without `fast_extractor.py`

No ECLE 2.0 language pack omits `fast_extractor.py` (Contract 08 §2 requires it). If
a future pack ships without one, `parse_repo` MUST:
1. Log `WARNING: no fast_extractor.py for {language_id}, falling back to extractor.sc in structural phase`
2. Run `extractor.sc` for the structural phase
3. Set `_extraction_tier: "structural"` anyway — the phase is structural regardless of which extractor ran

---

## 5. DB rules

### 5.1 No `extraction_tier` column

`file_facts` has no `extraction_tier` column. The DB schema (Contract 15) is not amended
for a tier column — it is not needed because all committed rows are full-depth by
construction (enforced by the `_extraction_tier` guard in `persist_facts`).

### 5.2 Standard append-only ingest

`persist_facts` follows the standard append-only pattern (Contract 15 §1) for every file:
1. `INSERT INTO file_facts (...) VALUES (...)` — new row at full depth.
2. If a previous row exists for `(file_id, repo_id)`: `UPDATE file_facts SET is_current=false, superseded_at=now() WHERE id=<previous_id>`.

No in-place updates. No tier promotion SQL. The append-only rule has no exceptions.

### 5.3 Query filter rules

All queries against `file_facts` that do not explicitly request history MUST filter:
```sql
WHERE is_current = true
```

Since all `is_current=true` rows are full-depth, no tier filter is needed. The confidence
profile reflects the manifest-declared ceiling for all query results uniformly.

### 5.4 Stats reporting

`get_stats(repo_id)` reports total files at full depth:

```python
"total_files": count(file_facts, "is_current=1"),
```

There are no `structural_files` or `full_files` sub-counts — the invariant guarantees
all current rows are full depth.

---

## 6. Confidence profile rules (Contract 05 integration)

### 6.1 Single confidence ceiling

All committed `file_facts` rows use the ceiling declared in the language pack's
`manifest.yaml` (`extraction_depth: full` → `behavioral_accuracy` ceiling 0.95).
There are no per-tier ceiling rules. There is no structural ceiling of 0.70 in `file_facts`
— structural facts never reach the DB.

`behavioral_accuracy` MUST NOT exceed the manifest-declared ceiling regardless of
confidence votes or learning loop signals (Contract 05 §3).

### 6.2 `extraction_fidelity` in confidence profiles

All committed rows report `extraction_fidelity` as declared in `manifest.yaml`
(`FULL` for all ECLE 2.0 packs). There is no `PARTIAL` fidelity in committed rows
— structural artifacts are never committed.

### 6.3 MCP tool obligations

Every MCP tool that returns facts MUST:

1. Include `extraction_fidelity` in the confidence profile field of its response.
2. All results are from full-depth committed rows — no tier-based coverage warnings are needed.
3. Coverage warnings are still required for: repos not yet indexed, files pending indexing, files with `parse_status='failed'` (Contract 11 §6).

---

## 7. C-Family shared extractor rules (ADR-0033)

### 7.1 `common/` library convention

The `language_packs/common/` folder is a shared Python library. Rules:

1. No `manifest.yaml` in `common/` — the registry loader skips it.
2. Code in `common/` is pure Python; no side effects at import time.
3. `common/` modules MUST NOT import from any specific language pack.
4. Language pack imports: `from common.c_family_extractors import extract_c_macros, ...`
5. Any extraction logic used by two or more language packs MUST live in `common/`.
6. Language-specific post-processing stays in the per-language file.

### 7.2 C-family pack obligations

Every language pack whose `manifest.yaml` declares `family: c_family` MUST:

1. Import from `common/c_family_extractors.py` — no local re-implementation.
2. Include `macros`, `typedefs`, and `preprocessor_branches` in its output dict.
3. Pass the correct source bytes to helpers — not the sanitized bytes for Pro*C macros (macros survive sanitization, but sanitized bytes should be used for consistency as the tree is built from sanitized output).

### 7.3 Non-C-family pack obligations

Language packs not in the C family:

1. Do NOT import from `c_family_extractors.py`.
2. MUST NOT set `macros`, `typedefs`, or `preprocessor_branches` to non-empty values unless the language natively supports those constructs and the pack implements them explicitly.
3. The base schema defaults (`[]`) are sufficient — no explicit empty-list assignment required.

### 7.4 `macros_count` and `typedefs_count` in `file_facts`

```sql
macros_count    INT NOT NULL DEFAULT 0,
typedefs_count  INT NOT NULL DEFAULT 0
```

Populated by `persist_facts`:
```python
file_facts_data["macros_count"]   = len(facts.get("macros", []))
file_facts_data["typedefs_count"] = len(facts.get("typedefs", []))
```

These counts MUST match `len(macros[])` and `len(typedefs[])` in the facts artifact.
`eval_schema_conformance` validates the match on a sample of ingested rows.

---

## 8. Error node fallback (structural phase)

When `TreeSitterParser._count_errors()` finds > 5% error nodes in a parsed file:

1. `parse_file()` returns `success=False`.
2. `parse_repo` (structural mode) records this `file_id` in `failed_files[]` for the `repo.structural_complete` event.
3. No structural `.facts.json` is written for this file — the deep phase will run Joern from scratch.
4. `parse_repo` (deep mode) sees this file in `failed_files[]`, skips the structural artifact lookup, and runs Joern directly.
5. The resulting final artifact has `_extraction_tier` absent (removed by deep phase as normal) — full-depth output committed to DB.
6. `file.ir_produced` event for the fallback file carries `used_fallback=true`.

This is the expected path for files that tree-sitter cannot parse reliably. No exception to
the single-commit flow; no `extraction_tier` column required.

---

## 9. Eval suites

| Eval | Trigger | Assertion |
|------|---------|-----------|
| `eval_two_phase_cycle` | Every PR | Structural phase completes → `repo.structural_complete` emitted on `ecle.repo.structural_complete` → deep triggered → `file.ir_produced` emitted per file → `persist_facts` commits once → no `_extraction_tier` in any committed artifact → single `file_facts` row per file at full depth |
| `eval_extraction_tier_guard` | Every PR | `persist_facts` raises `ValueError` when given an artifact containing `_extraction_tier`; no such artifact reaches `file_facts` |
| `eval_c_family_extractors` | Every PR | `extract_c_macros`, `extract_c_typedefs`, `extract_c_preprocessor_branches` produce correct output for reference C/C++/Pro*C header corpus; `macros_count` + `typedefs_count` match `len()` of corresponding lists |
| `eval_idempotent_ingest` | Every PR | Replaying `repo.structural_complete` → deep re-runs → `ON CONFLICT DO NOTHING` on `file_facts` → no duplicate rows; identical final DB state |
| `eval_fidelity_ceiling` | Every PR | All committed `file_facts` rows have `behavioral_accuracy` ≤ manifest-declared ceiling (0.95 for FULL packs); no 0.70-ceiling rows present |
| `eval_failed_files_path` | Nightly | Files in `failed_files[]` are processed correctly by deep phase (Joern from scratch); `used_fallback=true` in `file.ir_produced`; committed artifact has no `_extraction_tier` |
| `eval_schema_conformance` | Nightly | `macros_count` column present; default=0; values match `len(macros[])` in corresponding fact artifact; no `extraction_tier` column present on `file_facts` |
