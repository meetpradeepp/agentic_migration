# Contract 06 — Grounding Contract

**Scope:** Every query result, MCP tool response, and GraphQL response from ECLE 2.0.  
**Enforced by:** Lineage completeness verifier (runtime), `eval_grounding_coverage` (nightly hard gate).  
**Status:** Active

---

## 1. The universal rule

**Every result returned by ECLE MUST be traceable to the deterministic artifact it was derived from.**

ECLE has no LLM at any layer. All facts are produced by deterministic extractors — `extractor.sc` scripts and Python-based utilities. There is no hallucination problem. The grounding problem is a **lineage completeness problem**: every result row must carry an unbroken chain from the query response back to the source file at a specific commit.

A result with a broken or missing lineage chain is **incomplete** and is flagged as `LINEAGE_INCOMPLETE`.

---

## 2. The grounding stack

All five layers are fully deterministic. No LLM at any layer.

```
Layer 0 — Source files (at a specific commit_sha)
  Ground truth. Read-only. Never modified by ECLE.
  Held in: staging area / git clone

Layer 1 — IR artifacts (facts.json)
  Deterministic extraction from Layer 0.
  Produced by: extractor.sc scripts + Python utilities in language packs
  Worker: parse_repo
  Lineage: artifact_path + content_hash + commit_sha

Layer 2 — Structured Fact DB
  Deterministic projection of Layer 1. SQL upserts. No inference.
  Worker: persist_facts
  Lineage: file_facts.id → artifact_path → commit_sha

Layer 3 — Topology graph
  Deterministic projection of Layer 1 call/import/data-flow edges. No inference.
  Worker: build_graph
  Lineage: topology_edges.source_file + target_file + commit_sha

Layer 4 — Vector index
  Deterministic ONNX embedding of Layer 2 fact text. No inference.
  Worker: batch_embed
  Lineage: vector point id → file_facts.id → artifact_path

Layer 5 — Query results (GraphQL / MCP tools)
  Composed from Layers 2–4. Deterministic query + join. No inference, no LLM.
  Lineage: every result item carries the full chain back to Layer 0.
```

---

## 3. Lineage completeness — what every result item MUST carry

Every item in a query response MUST include:

```json
"lineage": {
  "source_file": "billing/batch_rating.ppc",
  "artifact_path": "artifacts/acme/repo_abc/billing/batch_rating.ppc.facts.json",
  "extractor_version": "powerbuilder-pack@1.2.0",
  "commit_sha": "a3f9c2d",
  "indexed_at": "2026-05-05T09:10:12Z",
  "file_facts_id": "sha256-abc123"
}
```

A result item missing any of these fields is **incomplete** — the verifier rejects it and replaces it with a gap marker: `{"gap": true, "reason": "lineage_incomplete", "field": "<missing field>"}`.

The `query_plan` field in the FACT envelope records which layers were consulted and in what order:
```json
"query_plan": ["layer2:file_facts", "layer3:topology_edges:2-hop"]
```

---

## 4. Grounding verifier — how it works

The verifier runs on every query response before it leaves the GraphQL / MCP layer:

1. **Lineage check** — every result item has all required `lineage` fields.
2. **Artifact existence check** — `artifact_path` exists in the artifact store (fast `exists()` call — no read).
3. **DB row existence check** — `file_facts_id` exists in the Structured Fact DB.
4. **Coherence check** — `commit_sha` in lineage matches `commit_sha` in the `file_facts` row.
5. If any check fails → the result item is replaced with a gap marker and a `LINEAGE_INCOMPLETE` event is emitted.

The verifier does NOT re-run extraction. It only validates the existing chain.

---

## 5. Lineage requirements by query type

| Query type | Required lineage anchor |
|---|---|
| File summary | `file_facts.id` for that file |
| Function lookup | `function_facts.id` + parent `file_facts.id` |
| Impact analysis | `topology_edges` row(s) traversed + both endpoint `file_facts.id`s |
| Table access query | `file_tables` row(s) + parent `file_facts.id` |
| Semantic search result | Vector point `id` + joined `file_facts.id` |
| Cross-repo link | Link record + both endpoint `file_facts.id`s from their respective repos |

---

## 6. LINEAGE_INCOMPLETE event

When the verifier rejects a result item it emits:

```json
{
  "event_type": "lineage.incomplete",
  "entity_id": "<query_id>",
  "payload": {
    "query_id": "uuid",
    "tool": "ecle_find_files",
    "result_item_index": 3,
    "missing_field": "artifact_path",
    "file_facts_id": "sha256-abc123",
    "session_id": "..."
  }
}
```

These events are monitored by `eval_grounding_coverage`. A non-zero count means the extraction pipeline wrote incomplete lineage — a pipeline bug, not a grounding policy failure.

---

## 7. Eval gate

`eval_grounding_coverage` runs nightly with a fixed corpus.
**Pass criteria:** 0 `lineage.incomplete` events across all query results on the corpus.
Failure = the extraction pipeline is writing incomplete lineage chains. Release is blocked.

---

## 8. Tiered knowledge authority model

ECLE organizes all knowledge into four tiers by authority level. The grounding verifier
applies different lineage requirements per tier. Query responses that blend tiers MUST
declare each item's tier in the lineage block.

```
Tier 1-code: CPG facts (ground truth)
  Source:    tree-sitter grammar + extractor.sc scripts + Python utilities (deterministic)
  Storage:   Structured DB (exact) + Vector Index Layer 1/2 (semantic)
  Lineage:   file_facts.id → artifact_path → commit_sha
  Authority: Highest. Code is the executable truth. If Tier 1-code and Tier 1-domain
             conflict, Tier 1-code wins. Conflict is logged as a
             `knowledge.tier_conflict` event.

Tier 1-domain: Structured domain data (equally authoritative, different form)
  Source:    Deterministic parsers for domain-specific formats (XML field defs,
             API specs, DDL, config files, orchestration scripts)
  Storage:   Structured DB ONLY — field_extractions, service_call_index,
             shared_artifacts, file_tables (for DDL)
  Lineage:   structured_artifact.id → source_file_path → content_hash
  Authority: Equally authoritative to Tier 1-code within its domain.
  RULE:      Tier 1-domain data MUST NOT be embedded into vector collections.
             Embedding destroys precision (a field name becomes approximate).
             These facts are exact lookup targets, not similarity targets.
  Applies to: platform repos (ADR-0017) — shared_docs/DDL schemas/API specs are
              platform-scoped Tier 1-domain facts available to all module queries.

Tier 2: Derived knowledge (computed from Tier 1)
  Source:    ONNX embeddings of Tier 1-code behavioral signatures
  Storage:   Vector Index Layer 1/2/3
  Lineage:   vector_point.id → file_facts.id → artifact_path
  Authority: Derived. Cosine distance captures behavioral similarity, not identity.
             A Tier 2 result MUST be confirmed against Tier 1 for any precise claim.
             Never cite Tier 2 alone as ground truth.

Tier 3: Non-code knowledge (supporting context)
  Source:    Document readers (Markdown, DOCX, plaintext, HTML, PDF)
  Storage:   Structured DB doc_chunks table + Vector Index Layer Docs collection
  Lineage:   doc_chunk.id → document.id → source_file_path
  Authority: Informational only. Linked to Tier 1 via entity name matching (table names,
             service names, function names found in document text).
             A Tier 3 result MUST NOT be presented as structural ground truth.
             ALWAYS cite tier: "per system documentation" not "per code analysis".
  Applies to: platform repo docs (human-understanding repos, shared_docs) are Tier 3
              facts with platform-wide scope (ADR-0017).
```

**Authority precedence rules:**

| Scenario | Rule |
|----------|------|
| Tier 1-code and Tier 1-domain agree | Cite both. High confidence. |
| Tier 1-code and Tier 1-domain conflict | Tier 1-code wins. Emit `knowledge.tier_conflict`. Log both values. |
| Tier 2 result contradicts Tier 1-code | Tier 1-code wins. Tier 2 is approximate. |
| Only Tier 3 available for a question | Return with `semantic_caveat: "Answer sourced from documentation only — no code-level verification available"`. |
| Tier 1-domain data requested via semantic search | Reject. Tier 1-domain facts are exact lookup only. Route to Structured DB. |

**Lineage block — tier field (added to §3 lineage structure):**

Every result item MUST include `knowledge_tier` in the lineage block:

```json
"lineage": {
  "knowledge_tier": "tier1_code",
  "source_file": "billing/batch_rating.ppc",
  ...
}
```

Valid values: `"tier1_code"`, `"tier1_domain"`, `"tier2_derived"`, `"tier3_doc"`.

Mixed-tier responses (composite queries blending code facts + domain data + docs) MUST
declare the tier for each result item independently.

---

## 9. References

| # | Citation | Relevance |
|---|----------|----------|
| R1 | W3C PROV-DM: The PROV Data Model, W3C Recommendation 2013 (w3.org/TR/prov-dm/) | Official W3C standard for provenance. ECLE's 5-layer lineage maps to PROV's Entity → Activity → Entity derivation chains |
| R2 | W3C PROV-O: The PROV Ontology, W3C Recommendation 2013 (w3.org/TR/prov-o/) | OWL2 ontology for provenance interchange; ECLE's lineage JSON is a practical serialisation of PROV-O concepts |
| R3 | Moreau, L. & Groth, P. "Provenance: An Introduction to PROV", Morgan & Claypool 2013 | "Provenance is information used to form assessments about quality, reliability or trustworthiness" — exactly ECLE's grounding purpose |
| R4 | Miles, S. et al. "PRIME: A Methodology for Developing Provenance-Aware Applications", ACM TOSEM 2011 | Provenance-aware system design patterns; validates layered lineage verification approach |
