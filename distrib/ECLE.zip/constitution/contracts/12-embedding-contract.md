# Contract 12 — Embedding Contract

**Scope:** The `batch_embed` Celery worker and `IEmbeddingModel` implementations.  
**Enforced by:** `eval_idempotent_ingest` (every PR), `eval_fidelity_ceiling` (nightly).  
**Status:** Active  
**Related:** ADR-0004, ADR-0008, ADR-0011, ADR-0014, ADR-0017

---

## 1. Core rules — non-negotiable

1. **ONNX/OpenVINO is mandatory for default deployment** — cloud embedding APIs MUST NOT be used unless `EMBEDDING_BACKEND=openai` is explicitly set. Air-gapped compliance is not optional.
2. **Never re-embed unchanged content** — idempotency key MUST be checked before calling the model.
3. **All vector payloads MUST be slim** — only the 7 fields defined in ADR-0004. No fact content in vectors.
4. **`model_version` MUST be set on every upserted vector** — vectors without a model version cannot be invalidated on model upgrade.
5. **Embedding failures MUST NOT fail the file** — caught, logged, `embed_status = 'failed'` in `indexing_state`; worker continues.

---

## 2. Idempotency key — required format

```
embed_idempotency_key = SHA256(entity_id + content_hash + EMBEDDING_MODEL_NAME + str(EMBEDDING_DIM))
```

Before calling the model:
1. Look up `embed_idempotency_key` in `indexing_state`.
2. If `embed_status == 'done'` for this key: skip. Do not re-embed. Do not re-upsert.
3. If not found or `embed_status != 'done'`: embed, upsert, set `embed_status = 'done'`.

The idempotency key encodes the model — changing the model version produces a new key, triggering re-embedding. This is the correct behaviour.

---

## 3. Vector collection naming

Collections in the vector store MUST follow this convention exactly:

```
{tenant_id}__{repo_id}__layer1         ← one vector per file version (code)
{tenant_id}__{repo_id}__layer2         ← one vector per function version (code)
{tenant_id}__{repo_id}__source         ← source code chunks (NEW — SPEC-038)
{tenant_id}__{repo_id}__docs           ← one vector per document chunk (Tier 3 non-code)
{tenant_id}__cross_repo__capabilities  ← Layer 3 cluster centroids (all repos)
```

- Separator is double underscore `__` — single underscore is permitted in `tenant_id` and `repo_id`.
- Collection names are lowercase only.
- `batch_embed` MUST call `IVectorStore.get_or_create_collection()` before upserting — never assume the collection exists.
- The `__docs` collection exists for both `platform` and `module` repos (ADR-0017). Platform repo docs are indexed the same way — their role distinction lives in the `repositories` table, not in the collection name.
- The `__docs` collection is populated by the `document_embedder` worker, NOT by `batch_embed`. `batch_embed` owns `__layer1` and `__layer2` only.
- The `__source` collection is populated by the `source_embedder` worker. It contains function-boundary source code chunks (or fixed 100-line / 20-line-overlap chunks for large functions). `batch_embed` does NOT write to `__source` — they are independent workers with separate consumers.

---

## 4. Slim vector payload — required fields only

Every upserted `VectorPoint.payload` MUST contain exactly these fields:

```json
{
  "repo_id":           "string",
  "cluster_stable_id": "string | null",   // null for singleton files (ADR-0011)
  "is_current":        true,
  "model_version":     "all-MiniLM-L6-v2@384d",
  "layer":             1
}
```

The `model_version` string format is `"{EMBEDDING_MODEL_NAME}@{EMBEDDING_DIM}d"`.
Example: `"all-MiniLM-L6-v2@384d"`, `"all-mpnet-base-v2@768d"`.

**Banned payload fields:**
- Any field from `facts.json` (functions, sql_statements, calls, etc.)
- File content, source text, or excerpts
- Confidence scores or fidelity values
- Timestamps

These belong in the Structured Fact DB, joined by `id` after ANN search (ADR-0004).

---

## 5. Micro-batching rules

The `batch_embed` worker processes chunks in micro-batches:

| Parameter | Default | Override via config |
|-----------|---------|---------------------|
| `MAX_BATCH_ITEMS` | 128 chunks | `EMBED_MAX_BATCH_ITEMS` |
| `MAX_BATCH_TOKENS` | 32,768 tokens | `EMBED_MAX_BATCH_TOKENS` |
| `MAX_WAIT_MS` | 100 ms | `EMBED_MAX_WAIT_MS` |

A batch is flushed when ANY limit is reached. Never exceed `MAX_BATCH_TOKENS` — this
exceeds the model's context window and produces incorrect embeddings.

---

## 6. Layer assignment rules

| Vector layer | What is embedded | One vector per | Worker |
|---|---|---|---|
| Layer 1 | Centroid of all function-level chunk vectors for one file | File version (`file_id + commit_sha`) | `batch_embed` |
| Layer 2 | Individual function body text | Function version (`function_id + commit_sha`) | `batch_embed` |
| Layer 3 | Centroid of all Layer 1 vectors within a Louvain community | Cluster (`cluster_id`) | `cluster_centroids` |
| Layer Docs | Document chunk text (non-code: Markdown, DOCX, DDL narrative, plaintext) | Document chunk (`doc_chunk_id`) | `document_embedder` |
| Layer Src | Source code chunks at function boundaries (or fixed 100-line/20-line-overlap for large functions) | Source chunk (`source_chunk_id`) | `source_embedder` |

`batch_embed` produces Layer 1 and Layer 2 only. Layer 3 centroids are produced by the
separate `cluster_centroids` worker consuming `topology.updated` and `file.embedded` events.
`document_embedder` produces Layer Docs, consuming `document.chunked` events. It does NOT
produce Layer 1/2/3 vectors — document chunks are not code facts.

**Critical ordering constraint — topology before vectors:**

```
compute_topology (Louvain → cluster_id assigned to file_facts)
        ↓  topology.updated
cluster_centroids (Layer 3 centroid = mean of Layer 1 vectors in cluster)
        ↓  updates cluster_alignment in file_facts
ontology_enricher (domain annotation at cluster granularity)
```

`cluster_id` MUST be written to `file_facts` by `compute_topology` before `cluster_centroids`
runs. A `cluster_stable_id=null` file (singleton) cannot be assigned to a centroid. The `cluster_centroids`
worker MUST skip files with `cluster_stable_id=null` and log a WARNING — it does not block.

The `cluster_alignment` confidence dimension in a query result is the cosine similarity
between the file's Layer 1 vector and its cluster's Layer 3 centroid vector. It is `null`
until both the Louvain assignment (Phase A) and the centroid computation (Phase B) are complete.
See ADR-0011 for the two-phase cluster assignment model.

---

## 7. Function embedding batch constant

```python
EMBED_FUNCTION_BATCH_SIZE = 50  # functions per IVectorStore.upsert() call
```

This constant is **mandatory and not configurable**. Every `embed_functions()` implementation
MUST collect all function `VectorPoint` objects for a file, then batch-upsert them in
groups of `EMBED_FUNCTION_BATCH_SIZE`, flushing the remainder at the end.

**Why 50:** A typical source file contains 10–50 functions. Batching at 50 means one file
= one upsert round-trip in the common case, eliminating the 50× overhead of per-function
calls. ChromaDB handles up to 5,000 vectors per `upsert()` call; 50 is the safe default
that avoids memory pressure on large function corpora without sacrificing throughput.

**Non-conformant pattern (banned):**
```python
for fn in functions:
    vector_store.upsert([make_vector_point(fn)])  # per-function call — BANNED
```

**Conformant pattern:**
```python
points = [make_vector_point(fn) for fn in functions]
for batch in batched(points, EMBED_FUNCTION_BATCH_SIZE):
    vector_store.upsert(batch)
```

`eval_embed_batch` verifies that no production code path uses the per-function pattern
by asserting `upsert()` is never called with a single-element list for a file that has
more than one function.

---

## 8. `model_version` invalidation on model upgrade

When `EMBEDDING_MODEL_NAME` or `EMBEDDING_DIM` changes:

1. New embeddings use the new `model_version` string.
2. Old vectors with the old `model_version` remain in the collection — they are NOT deleted immediately.
3. Old vectors are pre-filtered out of ANN search results using `model_version == CURRENT_MODEL_VERSION` filter.
4. A background re-embedding sweep runs (`embed_status = 'stale'` in `indexing_state`).
5. Once a file is re-embedded: old vector is deleted; new vector replaces it.
6. Sweep is complete when no rows have `embed_status = 'stale'`.

---

## 8. Error handling rules

| Error | Action |
|-------|--------|
| ONNX model file not found | Worker DOES NOT START — `BackendInitError` at startup |
| `EMBEDDING_DIM` mismatch with collection | `DimensionMismatchError` at upsert — worker nacks event, does not crash |
| Single chunk embedding failure | Log ERROR; set `embed_status = 'failed'`; continue to next chunk — never fail the whole file |
| Cloud API called when `EMBEDDING_BACKEND != "openai"` | Should never happen — if it does, raise `ConfigError` immediately |

---

## 9. Document chunking strategy (`document_embedder` worker)

`document_embedder` owns the Layer Docs collection (`__docs`). It consumes `document.stored` events and produces `doc_chunks` DB rows + Layer Docs vectors.

**Supported document formats:**

| Format | Parser | Notes |
|--------|--------|-------|
| Markdown (`.md`) | `mistletoe` or `markdown-it-py` | Heading-aware splitting |
| Plain text (`.txt`) | Character-based splitter | No structure |
| DOCX (`.docx`) | `python-docx` | Paragraph-aware |
| HTML (`.html`) | `beautifulsoup4` | Tag-stripped; heading-aware |
| PDF (`.pdf`) | `pdfminer.six` (text layer only) | No OCR; image-only PDFs produce empty chunks |
| reStructuredText (`.rst`) | `docutils` | Section-aware |

Formats not in this list are handled by the plain-text fallback (no structure). Unknown formats produce a single chunk containing the full document text, up to `DOC_CHUNK_MAX_TOKENS`.

**Chunking rules:**

| Parameter | Default | Config var |
|-----------|---------|------------|
| `DOC_CHUNK_SIZE_TOKENS` | 512 | `EMBED_DOC_CHUNK_SIZE` |
| `DOC_CHUNK_OVERLAP_TOKENS` | 64 | `EMBED_DOC_CHUNK_OVERLAP` |
| `DOC_CHUNK_MAX_TOKENS` | 1024 | `EMBED_DOC_CHUNK_MAX` (hard cap; chunks exceeding this are split) |
| `DOC_CHUNK_MIN_TOKENS` | 32 | `EMBED_DOC_CHUNK_MIN` (chunks shorter than this are merged with next) |

**Heading-aware splitting (Markdown, DOCX, HTML, RST):**
Splitter MUST NOT split inside a heading block. A chunk boundary MUST align with a heading boundary when one is within `DOC_CHUNK_OVERLAP_TOKENS` of the target split point. This preserves section context in chunk text.

**`chunk_text` storage:**
Chunk text is stored in `doc_chunks.chunk_text` (Contract 15). This is the **only** fact table that stores source text content. Rationale: unlike code facts (which are structured and joinable), document chunk text cannot be reconstructed from structured columns at query time. The Tier 1-domain rule (no embedding of exact-lookup data) does not apply here — document text is Tier 3 knowledge, intentionally approximate.

**Idempotency:**
`embed_idempotency_key` for doc chunks: `SHA256(document_id + chunk_index + content_hash + EMBEDDING_MODEL_NAME)`. Same key format as code chunks. `document_embedder` checks this key before embedding.

---

## 10. Muvera re-ranking at query time (ADR-0004-A1)

Re-ranking is a **query-time concern**, not an ingestion concern. It does not affect
`batch_embed`, `chunk_file`, `document_embedder`, or any write-path worker.

**Rules:**

1. **All three code layers support re-ranking** — Layer 1 (files), Layer 2 (functions), Layer 3 (clusters). Layer Docs does not (Tier 3 text has no structured facts to re-rank against).
2. **Re-rank text is assembled from Structured DB** — the same `assemble_embedding_text()` and `assemble_fn_embedding_text()` functions used by `chunk_file` at ingestion time. No new text assembly logic.
3. **Re-rank tokens are ephemeral** — computed on-the-fly by the Muvera encoder, used for MaxSim scoring, then discarded. Never stored in vector DB or Structured DB.
4. **Timeout is per-layer** — `RERANK_TIMEOUT_MS` (default: 500 ms). If exceeded, that layer falls back to ANN order. Downstream layers in a cascade are not affected.
5. **Graceful degradation is mandatory** — if Muvera model is not loaded, or Structured DB is unreachable, or timeout fires: query succeeds with ANN-only results. Re-rank failure MUST NOT fail a query.
6. **FACT envelope MUST declare re-ranking** — `"reranker": "muvera"` and `"reranked_layers": [1, 2, 3]` (listing only layers where re-rank actually succeeded). If a layer fell back, it is omitted from the list.
7. **Fallback events** — emit `rerank.timeout` or `rerank.fallback` Kafka events when degradation occurs. These are operational signals, not errors.

---

## 11. BM25 hybrid search at query time (ADR-0004-A2)

Hybrid search combines ANN (vector similarity) with BM25 (keyword match) using Reciprocal
Rank Fusion. Like re-ranking, this is a **query-time concern** — the only write-path change
is the `embedding_text_tsv` column populated by `chunk_file`.

**Rules:**

1. **Layer 1 and Layer 2 support hybrid search** — `file_facts.embedding_text_tsv` and `function_facts.embedding_text_tsv` are GIN-indexed. Layer 3 does not (centroids have no meaningful keyword text). Layer Docs uses `doc_chunks.chunk_text` (already stored).
2. **`tsvector` is populated at ingestion time** — `chunk_file` worker writes both `*.chunks.json` (for embedding) and `embedding_text_tsv` (for BM25) from the same `assemble_embedding_text()` output. One source, two representations.
3. **RRF fusion is deterministic** — `RRF_score(d) = Σ 1/(k + rank_i(d))` with `k=60`. No learned weights. No tuning required.
4. **BM25 failure is not query failure** — if PostgreSQL FTS is unavailable or returns zero results, query proceeds with ANN-only results. Emit `hybrid.bm25_unavailable` Kafka event.
5. **FACT envelope MUST declare retrieval method** — `"retrieval": "hybrid_rrf"` and `"sources": ["ann", "bm25"]` when both contributed. `"retrieval": "ann_only"` when BM25 was unavailable or disabled.
6. **Pipeline order** — BM25 and ANN run in parallel → RRF fusion → Muvera re-rank. Re-ranking operates on the fused result set, not on each retriever's results independently.
