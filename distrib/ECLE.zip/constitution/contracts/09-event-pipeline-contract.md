# Contract 09 — Event Pipeline Contract

**Scope:** Every Kafka consumer worker and the Kafka broker.  
**Enforced by:** `eval_event_chain_complete`, `eval_srp_isolation`, `eval_idempotent_ingest`, `eval_async_coupling` (every PR).  
**Status:** Active  
**Related:** ADR-0013 (supersedes ADR-0001), ADR-0027 (Async Component Autonomy Model)

---

## 0. Architectural invariant — async-first, loosely coupled (ADR-0027)

**Every ECLE component is an autonomous, independently deployable, independently scalable unit.**

The following rules are **hard architectural constraints**, not guidelines. A PR that violates them is rejected at review:

1. **Kafka is the only inter-component communication channel.** Direct function calls, HTTP calls, or shared-memory communication between any two workers are banned. See `10-anti-patterns.md`.
2. **Each worker is independently deployable.** No worker imports another worker's module. Workers share only library code (`src/ecle/` clients and utilities).
3. **Each worker has independently configurable scaling bounds** (`WORKER_{NAME}_MIN_REPLICAS`, `WORKER_{NAME}_MAX_REPLICAS`, `WORKER_{NAME}_LAG_THRESHOLD`). See ADR-0027 §Rule 3.
4. **Each worker has an independently controllable lifecycle.** Workers poll `worker_lifecycle` table on 30 s TTL. Lifecycle states: `running | paused | draining`. See ADR-0027 §Rule 4.
5. **Each worker tracks its own contribution to every import job** via `import_jobs.pipeline_state` JSONB. Workers only patch their own key — never overwrite the full object.
6. **Each worker exposes `GET /metrics` independently** on its own pod port. Prometheus scrapes each worker pod directly — no aggregated metrics endpoint.

These six properties are verified by `eval_async_coupling` which runs on every PR. The eval asserts:
- No `import` of one worker module from another in the source tree.
- No `requests.post` / `httpx.post` / direct DB calls targeting another worker's primary table from within a worker module.
- All workers have a corresponding `worker_lifecycle` entry in `topic_registry.py`.

---

## 1. Core rules — non-negotiable

1. **Workers communicate exclusively via events** — never by direct function call or shared object.
2. **Every worker has exactly one job** (SRP) — a worker that does two things must be split.
3. **Every worker is idempotent** — processing the same event twice produces the same final state.
4. **The API thread does the minimum possible** — store the payload, emit one event, return 202. No processing.
5. **No worker reads from or writes to another worker's primary output** — boundaries are enforced by event contracts, not access control.
6. **CPG workers MUST respect `max_cpg_workers`** — the maximum number of concurrent Joern JVM processes. This limit is configured per deployment tier (ADR-0010). Per-repo exclusivity is mandatory: a repo that already has an active deep-phase job MUST NOT be claimed by a second worker. Content-type `"code"` jobs that invoke the Joern JVM consume a CPG slot; `facts`, `docs`, and `config` jobs do not. Workers that cannot claim a CPG slot MUST park the message (pause consumption) and retry after `CPG_SLOT_RETRY_MS` (default 5,000 ms) without committing the offset.

---

## 2. Kafka topics — the system's event backbone

All inter-worker communication flows through Kafka topics. See ADR-0013 for broker configuration, KRaft setup, and tier-specific deployment.

**Topic naming:** `ecle.{event_type}` — e.g. `ecle.file.ir_produced`  
**DLQ naming:** `ecle.dlq.{event_type}` — e.g. `ecle.dlq.file.ir_produced`  
**Consumer group naming:** `ecle.{worker_name}` — e.g. `ecle.persist_facts`

All topics are declared in `src/ecle/events/topic_registry.py` and created at startup. `auto.create.topics.enable=false` in all environments.

**Fan-out** (one event consumed by multiple workers) is handled natively by consumer groups. `file.ir_produced` is consumed by both `persist_facts` (group `ecle.persist_facts`) and `build_graph` (group `ecle.build_graph`) — Kafka delivers the full message stream to each group independently.

**Offset commit rules:**
- Offset is committed **only after** the processing result is durably written (DB committed, artifact written).
- `enable.auto.commit=False` is mandatory. Auto-commit is banned — it advances the offset before work is confirmed.
- On crash with no commit, Kafka redelivers from the last committed offset on restart.

**Audit trail:**
- Kafka topic retention is tiered by event category — see ADR-0013 §Audit trail for retention tiers (Critical: 30 days, Derived: 7 days, Operational: 3 days, DLQ: 90 days).
- PostgreSQL `pipeline_runs` table provides long-term audit: `(repo_id, event_type, entity_id, status, created_at, completed_at)`. Written by each worker after successful commit. Append-only.

---

## 3. Event type catalogue

Each event type maps to a Kafka topic `ecle.{event_type}`. Fan-out consumers listed in the Consumed by column each run as a separate consumer group and receive all messages independently.

| Event type | Topic | Emitted by | Consumed by | Payload required fields |
|---|---|---|---|---|
| `upload.received` | `ecle.upload.received` | Admin API (`POST /admin/v1/upload`) | `scan_source` | `job_id`, `tenant_id`, `repo_id`, `artifact_path`, `content_types[]`, `repo_role` |
| `source.received` | `ecle.source.received` | API | `scan_source` | `source_type`, `source_ref`, `upload_id`, `tenant_id` |
| `repo.detected` | `ecle.repo.detected` | `scan_source` | `parse_repo` | `repo_id`, `repo_path`, `languages[]`, `upload_id`, `tenant_id` |
| `source.scanned` | `ecle.source.scanned` | `scan_source` | `link_contracts` | `upload_id`, `repo_count`, `tenant_id` |
| `file.ir_produced` | `ecle.file.ir_produced` | `parse_repo` (deep phase) | `persist_facts`, `build_graph` ★ | `artifact_path`, `file_id`, `repo_id`, `language`, `fidelity`, `used_fallback`, `content_hash`, `commit_sha` |
| `repo.ir_produced` | `ecle.repo.ir_produced` | `parse_repo` (deep phase) | `build_contract_registry` | `repo_id`, `file_count`, `failed_count`, `fallback_count` |
| `repo.structural_complete` | `ecle.repo.structural_complete` | `parse_repo` (structural phase) | `parse_repo` (deep phase, consumer group `ecle.parse_repo_deep`) | `repo_id`, `tenant_id`, `artifact_dir`, `file_count`, `failed_files[]`, `commit_sha` |
| `file.stored` | `ecle.file.stored` | `persist_facts` | `chunk_file`, `detect_dsl_mappings`, `semantic_interpreter_file` ★ | `file_id`, `repo_id`, `tenant_id` |
| `graph.updated` | `ecle.graph.updated` | `build_graph` | `compute_topology` | `file_id`, `changed_file_ids[]`, `node_count`, `edge_count`, `repo_id` |
| `file.chunked` | `ecle.file.chunked` | `chunk_file` | `batch_embed` | `file_id`, `chunk_count`, `artifact_path` |
| `dsl.mapped` | `ecle.dsl.mapped` | `detect_dsl_mappings` | `ontology_enricher` | `file_id`, `concepts[]` |
| `file.embedded` | `ecle.file.embedded` | `batch_embed` | `cluster_centroids` | `file_id`, `model_version`, `vector_ids[]` |
| `topology.updated` | `ecle.topology.updated` | `compute_topology` | `cluster_centroids`, `ontology_enricher` ★ | `repo_id`, `changed_cluster_ids[]`, `edge_count`, `scope` (`"incremental"\|"full"`), `recompute` (bool) |
| `ontology.enriched` | `ecle.ontology.enriched` | `ontology_enricher` | — | `file_id`, `concepts[]` |
| `contracts.registered` | `ecle.contracts.registered` | `build_contract_registry` | `link_contracts` | `repo_id`, `contract_count` |
| `cross.linked` | `ecle.cross.linked` | `link_contracts` | — | `upload_id`, `link_count`, `unresolved_count` |
| `link_contracts.partial_platform` | `ecle.link_contracts.partial_platform` | `link_contracts` | — | `upload_id`, `missing_repos[]`, `coverage_warning` |
| `repo.indexed` | `ecle.repo.indexed` | `persist_facts` (after all files stored for a repo) | `cross_repo_indexer`, `semantic_interpreter_repo` ★ | `repo_id`, `tenant_id`, `file_count`, `cluster_count` |
| `re-embed.batch` | `ecle.re-embed.batch` | `sweep_coordinator` (Celery Beat) | `batch_embed` | `cluster_id`, `layer`, `model_version_new`, `file_ids[]` |
| `language_pack.extension_miss` | `ecle.language_pack.extension_miss` | Any worker running `parse_repo` | `coverage_gap_aggregator` | `tenant_id`, `extension`, `count` |
| `language_pack.coverage_gap` | `ecle.language_pack.coverage_gap` | `coverage_gap_aggregator` | — | `tenant_id`, `extension`, `global_miss_count` |
| `reindex.requested` | `ecle.reindex.requested` | Query layer (staleness caveat path) | `scan_source` | `repo_id`, `tenant_id`, `reason`, `requested_at` |
| `feedback.given` | `ecle.feedback.given` | `ecle_feedback` MCP tool (ADR-0024) | `learning_analyzer` | `entity_id`, `entity_type`, `signal`, `query_id`, `subject`, `tenant_id`, `given_at` |
| `confidence.updated` | `ecle.confidence.updated` | `learning_analyzer` | — | `entity_id`, `old_accuracy`, `new_accuracy`, `reason` |
| `facts.annotated` | `ecle.facts.annotated` | `semantic_interpreter_repo` (mode="repo" only) | `batch_embed` ★ (Phase 2) | `repo_id`, `tenant_id`, `annotation_count`, `rule_ids[]`, `annotated_at`, `X_Request_Id`, `X_Trace_Id` |
| `document.stored` | `ecle.document.stored` | `persist_facts` (for document files) | `document_embedder` | `document_id`, `repo_id`, `tenant_id`, `content_type` |
| `document.chunked` | `ecle.document.chunked` | `document_embedder` | `batch_embed` (Layer Docs) | `document_id`, `chunk_count`, `artifact_path` |
| `ontology.reload.requested` | `ecle.ontology.reload.requested` | Admin API `POST /ontology/reload` | `ontology_enricher` | `tenant_id`, `vocabulary_version` |

★ Fan-out: each consumer listed runs as a **separate consumer group** and receives the full message stream independently.

---

## 4. Worker SRP boundaries

| Worker | Its one job | Domain boundary (never crosses into) |
|---|---|---|
| `scan_source` | Detect repos in source payload | Parsing, DB, vectors |
| `parse_repo` | Source code → IR artifact files (two modes: **structural** — runs `fast_extractor.py` per file, writes intermediate `.facts.json` to artifact store, emits `repo.structural_complete` once per repo, no DB write; **deep** — consumes `repo.structural_complete`, runs Joern per file, enriches structural `.facts.json` using the SPEC-049 merge table, emits `file.ir_produced` per file) | DB writes, vectors, graph |
| `persist_facts` | IR artifact → Structured Fact DB; emits `repo.indexed` when all files for a repo are stored | Graph, vectors, parsing |
| `build_graph` | IR artifact → Neo4j nodes/edges | Structured DB, vectors |
| `chunk_file` | Structured facts → text chunks | Vectors, graph, parsing |
| `detect_dsl_mappings` | Structured facts → DSL tags | Vectors, graph, parsing |
| `batch_embed` | Text chunks → slim vectors; also handles `re-embed.batch` events (model sweep) | DB (read only), no writes to structured DB |
| `compute_topology` | Graph edges → topology edges in structured DB; incremental or full Louvain; emits `topology.updated { scope, recompute }` | Parsing, vectors |
| `ontology_enricher` | DSL tags → ontology enrichment | Parsing, vectors, graph |
| `cluster_centroids` | Update Layer 3 centroids; fires only when `topology.updated.recompute=true` | Parsing, structured DB, graph |
| `cross_repo_indexer` | Consume `repo.indexed` → upsert `cross_repo_summary` row | Parsing, graph, vectors |
| `sweep_coordinator` | Celery Beat job — partition re-embedding work and emit `re-embed.batch` events; priority: centrality descending | Parsing, DB, vectors |
| `coverage_gap_aggregator` | Consume `language_pack.extension_miss` → aggregate global miss counts; emit `language_pack.coverage_gap` when threshold crossed | Parsing, graph, vectors |
| `document_embedder` | Consume `document.stored` → chunk document into `doc_chunks` DB rows → emit `document.chunked`; owns Layer Docs vector collection (`__docs`) | Parsing, topology graph, code vectors |
| `learning_analyzer` | Consume `feedback.given` → update `confidence_votes` table → recompute `behavioral_accuracy` for entity; emit `confidence.updated` (ADR-0024) | Parsing, graph, embedding |

---

## 5. Idempotency contract

Every worker MUST be safe to run twice on the same event.

Implementation patterns:
- **DB inserts**: use `INSERT OR IGNORE` / `ON CONFLICT DO NOTHING` keyed on `(file_id, commit_sha)`.
- **Vector upserts**: use the vector store's `upsert()` — not `add()`.
- **Neo4j MERGE**: always `MERGE` — never `CREATE`.
- **Artifact writes**: write to a temp path, then `rename()` (atomic on POSIX). Overwrites are safe.
- **Event emission**: Kafka idempotent producer (`enable.idempotence=True`) prevents broker-level duplicates. Workers still guard against duplicate processing via DB `ON CONFLICT DO NOTHING` — the producer guarantee and the worker guarantee are independent defence layers.

Test: `eval_idempotent_ingest` — runs a full ingest twice on the same corpus and asserts DB state is identical. Also verifies offset is committed only after durable write (simulates crash-before-commit and confirms redelivery produces correct final state).

---

## 6. Error handling contract

| Failure type | Worker action | Kafka action |
|---|---|---|
| File-level parse error | Record in `facts.extraction_errors[]`; continue to next file | Emit `file.ir_produced` with `fidelity=HEURISTIC`, `used_fallback=true`; commit offset |
| Missing artifact file | Log error with `file_id`; skip this file | Forward to DLQ topic (`ecle.dlq.{topic}`); commit offset on original topic |
| Malformed payload (schema mismatch) | Log full payload with topic + partition + offset | Forward to DLQ; commit offset on original topic — do not block pipeline |
| Retryable error (transient DB/network) | Retry 3× with exponential backoff | Do NOT commit offset; message redelivered on next poll if worker restarts |
| Permanent error after retries exhausted | Log error with full context | Forward to DLQ; commit offset |
| Total worker crash (no commit made) | Process restarts (systemd / K8s pod restart) | Kafka redelivers from last committed offset automatically |

**One bad file MUST NOT crash the repo job.**  
**One bad repo MUST NOT crash the source scan.**  
All errors are observable in DLQ topics or `facts.extraction_errors[]` — never silent.  
DLQ topics require human review — no automatic reprocessing.

---

## 7. Event payload validation

Before emitting any event, the emitting worker MUST validate the payload against the
schema in the event catalogue (§3). Missing required fields = `ValueError` raised before insertion.

Before consuming any event, the consuming worker MUST validate the payload.
Malformed payload = set `events.error = "malformed payload: <detail>"`; skip processing.

This prevents silent downstream failures from propagating silently through the pipeline.
