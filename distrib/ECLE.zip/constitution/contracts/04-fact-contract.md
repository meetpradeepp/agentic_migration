# Contract 04 — FACT Contract

**Scope:** The entire ECLE 2.0 system — every architectural decision, every ADR, every spec, every design change, every runtime response.  
**Enforced by:** ADR review (design time), spec review (spec time), response envelope schema validation and FACT eval suites (runtime).  
**Status:** Active

---

## 1. FACT defined

FACT is the architectural north star of ECLE 2.0. It is not a response format. It is the reason every architectural decision is made.

Every design choice, backend selection, algorithm choice, and data model decision MUST be evaluated against these four levers: does it improve one without degrading another?

FACT is also observable at runtime — every response carries a `fact` envelope that proves the system is living up to its architectural promises (see §3).

The four levers:

| Property | Definition | Hard gate |
|---|---|---|
| **F**ast | Queries resolve in milliseconds. Ingestion is O(changed_files), not O(corpus). All traversals depth-bounded. No cascade staleness. | Query timeout enforced at 2s; timed-out responses return partial with `fast.timed_out: true` |
| **A**ccurate | Every claim grounded in structural evidence. 6-dimension confidence profile on every result. Verifiers enforce complete lineage on every result. | `eval_grounding_coverage` — 0 `lineage.incomplete` events pass nightly |
| **C**omplete | No silent gaps. If knowledge is missing or partial, the system says so explicitly. Coverage warnings always declared, never suppressed. | `indexing_state` checked pre-query; `coverage_warnings[]` in every response |
| **T**rustworthy | Every answer can be relied upon. Enforced by two sub-properties: **Timely** + **Traceable**. | See §5 and §6 |

---

## 2. FACT as architectural compass

Every ADR and spec MUST declare which FACT lever(s) it primarily improves, and confirm it does not degrade any other lever.

### The design question

Before any architectural decision is finalised, ask:

> *Which FACT lever does this improve, and by how much? Does it degrade any other lever? If so, is the trade-off justified?*

If a decision cannot answer this question it is not yet ready to be an ADR.

### Required fields in every ADR

Every ADR header MUST include:

```markdown
**FACT impact:**
- Fast: <improves | neutral | degrades> — <one-line reason>
- Accurate: <improves | neutral | degrades> — <one-line reason>
- Complete: <improves | neutral | degrades> — <one-line reason>
- Trustworthy: <improves | neutral | degrades> — <one-line reason>
```

A decision that degrades a lever MUST explain the trade-off in the ADR body and record a mitigation or a future ADR that recovers the lever.

### FACT classification of the existing ADRs

| ADR | Primary lever improved |
|-----|------------------------|
| ADR-0001 Event-driven pipeline | **Fast** (async, no blocking API thread) + **Trustworthy/Traceable** (immutable event log) |
| ADR-0002 Language pack registry | **Accurate** (structural extraction over text) + **Complete** (DefaultPack closes all gaps) |
| ADR-0003 Three-backend architecture | **Fast** (right tool per query type) + **Fast** (backend swap without code change) |
| ADR-0004 Slim vector design | **Fast** (8ms two-hop vs full payload scan) |
| ADR-0005 Framework overlay packs | **Accurate** (framework-aware facts, higher fidelity ceiling) |
| ADR-0006 MCP + GraphQL layer | **Fast** (query planner routes to cheapest backend) + **Complete** (unified entry point) |
| ADR-0007 Artifact store IR intermediary | **Trustworthy/Traceable** (immutable facts.json on disk) + **Fast** (workers skip unchanged files) |
| ADR-0008 Local-first embeddings | **Trustworthy** (no cloud dependency, air-gap safe) + **Fast** (no network round-trip) |
| ADR-0009 Contract-first cross-repo linking | **Fast** (O(C log C) not O(N²)) + **Accurate** (contract-grounded links) |
| ADR-0010 Three-tier deployment | **Fast** (right infra per scale) + **Trustworthy** (same code = predictable behaviour) |
| ADR-0011 Louvain community detection | **Fast** (cluster-scoped ANN pre-filter reduces search space) + **Accurate** (`cluster_alignment` dim + domain queries answerable) + **Complete** (every file gets a cluster_id; subsystem-level coverage reporting) + **Trustworthy** (deterministic cluster IDs traceable to topology edges) |
| ADR-0012 Multi-level language detection | **Accurate** (framework-aware extraction; sub-grammar parsing) + **Complete** (no framework layer silently dropped) + **Trustworthy** (`detected_layers[]` traces every framework claim to evidence) |
| ADR-0013 Kafka event broker | **Fast** (push-based consumer; no polling interval) + **Complete** (fan-out via consumer groups; both `persist_facts` and `build_graph` guaranteed delivery) + **Trustworthy** (offset-based replay; DLQ observable) |
| ADR-0014 Semantic-first query planning | **Fast** (ANN pre-filter narrows structured scan to cluster scope) + **Accurate** (semantic entry point finds right domain area before structural precision) + **Complete** (`query_mode`+`intent_source` in envelope; routing decision observable) |

### FACT violations — design anti-patterns

| Violation | Lever damaged | Example |
|-----------|---------------|---------|
| O(N²) entity matching | **Fast** | Comparing every function to every function across repos |
| Silent gaps (no coverage warning) | **Complete** | Returning empty results without checking `indexing_state` |
| Confidence=1.0 on stale data | **Trustworthy/Timely** | Omitting `knowledge_current_as_of` |
| Ungrounded claims | **Accurate** | Returning results without `lineage[]` |
| Cascade re-ingest on unrelated change | **Fast** | Re-parsing all files when one file changes |
| Hardcoded backend | **Fast** + **Trustworthy** | `sqlite3.connect()` in worker code prevents tier upgrade |
| Inline facts in event payload | **Fast** | Bloated events slow poll + replay (ECLE 1.0 lesson, ADR-0007) |
| Missing `query_mode` or `intent_source` | **Trustworthy/Traceable** | Routing decision invisible; cannot audit why result set was chosen |
| `semantic_caveat` suppressed when `semantic_accuracy=null` | **Trustworthy/Timely** | LLM agent receives domain context it never had; silent degradation |

---

## 2. FACT response envelope — MUST be present on every response

```json
{
  "results": [...],

  "fact": {
    "fast": {
      "query_ms": 237,
      "timed_out": false,
      "query_mode": "composite",
      "intent_source": "caller",
      "cluster_ids_used": ["a3f1b2c4d5e6f7a8"],
      "routing": "vector_index+structured_db",
      "reranker": "muvera",
      "flow_id": "locate_function_rerank",
      "step_ms": [16, 50, 160, 5],
      "enrich_carry": {
        "matched_concepts":   ["billing-cycle", "retry-policy"],
        "candidate_clusters": ["a3f1b2c4d5e6f7a8"],
        "candidate_anchors":  { "function_name": "retry", "module_hint": "billing", "entity_type": "function" },
        "suggested_intent":   "locate",
        "enrichment_confidence": 0.87
      },
      "suggested_next": {
        "tool":          "ecle_impact",
        "query_intent":  "precise",
        "known_anchors": { "function_name": "PaymentRetryService.retry", "file_path": "billing/retry.py" },
        "reason_code":   "top_result_is_entry_point"
      }
    },
    "accurate": {
      "confidence_profile": {
        "syntactic_freshness": 1.0,
        "behavioral_accuracy": 0.95,
        "contextual_accuracy": 0.88,
        "edge_coherence": 0.91,
        "cluster_alignment": 0.84,
        "semantic_accuracy": 0.91
      },
      "confidence_ceiling": 1.0,
      "extraction_fidelity": "FULL"
    },
    "complete": {
      "coverage_warnings": [],
      "total_indexed_files": 1842,
      "missing_repos": []
    },
    "trustworthy": {
      "timely": {
        "knowledge_current_as_of": "2026-05-05T09:14:00Z",
        "staleness_score": 0.02,
        "staleness_caveat": null,
        "semantic_caveat": null
      },
      "traceable": {
        "lineage": [
          {
            "source_file": "billing/batch_rating.ppc",
            "extractor_version": "powerbuilder-pack@1.0",
            "indexed_at": "2026-05-05T09:10:12Z",
            "commit_sha": "a3f9c2d"
          }
        ],
        "query_plan": ["structured_db:file_facts", "topology:2-hop"]
      },
      "audit_notice": "Queries are recorded for system improvement and operational audit. See your organisation's data policy."
    },
    "semantic": {
      "enriched": true,
      "ontology_version": "billing-domain@1.2",
      "domain_concepts": ["billing-cycle", "late-fee", "policy-contract"],
      "dsl_patterns": ["DataWindow:unbuffered-fetch", "SQLSelect:fees-ledger"],
      "semantic_coverage": 0.82,
      "embedding": {
        "model": "all-MiniLM-L6-v2",
        "dimension": 384,
        "model_version": "1.0"
      }
    }
  }
}
```

**`fast` block rules:**
- `query_mode`: `"semantic"` | `"structured"` | `"composite"` — the routing mode actually executed (ADR-0014).
- `intent_source`: `"caller"` | `"heuristic"` | `"default"` — how the query planner determined the mode. `"caller"` = LLM agent passed `query_intent`; `"heuristic"` = planner inferred from argument presence; `"default"` = no signal, defaulted to semantic.
- `cluster_ids_used`: Louvain cluster IDs used to scope the query (ADR-0011). Empty array for pure structured queries. Never absent — use `[]` if not applicable.
- `routing`: human-readable description of backends accessed (e.g. `"structured_db"`, `"vector_index+structured_db"`, `"topology_graph"`).
- `timed_out: true` means partial results were returned; the query hit the 2s hard limit.
- `reranker`: `"muvera"` when Muvera token-level re-rank was applied after Layer 2 ANN (ADR-0014-A2); `null` in all other cases. Never present with `search_depth` values `"layer1"`, `"layer3"`, or `"structured"`.
- `flow_id`: the flow that executed for this request (ADR-0018). Always present. Operators use this to correlate slow or low-quality turns to a specific flow for tuning.
- `step_ms[]`: per-step timing in milliseconds, in step execution order. Array length equals the number of steps that ran (skipped optional steps are excluded). Use to identify which step consumed budget.
- `enrich_carry`: structured output of the `enrich` step if it ran; `null` otherwise. The calling LLM agent SHOULD pass this as `known_anchors` on the next call to avoid re-running enrichment. Never a generated or rewritten query string — vocabulary metadata only.
- `suggested_next`: deterministic recommendation for the next tool call. `null` when no rule fires. The calling agent MAY follow it; it is a hint, never a command. `reason_code` values and their trigger conditions are defined in ADR-0018.

**`semantic_caveat` rules:**
- `null` — domain context was available and used.
- Non-null string — domain context was unavailable for matched clusters (`semantic_accuracy = null`); results are structural only. A `reindex.requested` event is emitted asynchronously. Never block the response.
- `enriched: false` means the `ontology_enricher` worker has not yet processed this result. `domain_concepts` and `dsl_patterns` are empty. `semantic_accuracy` in the confidence profile is `null`.
- `enriched: true` means domain annotations are present and `semantic_accuracy` is populated.
- `embedding` lives here — not in `lineage`. Lineage is structural (source file → extractor → facts.json → commit). The embedding model is a semantic/similarity concern, not a structural one.
- A response with `semantic.enriched: false` is still valid and complete. Semantic enrichment is additive; structural facts are always returned regardless.

---

## 9. Semantic — domain meaning

Embedding and semantics are separate concerns and must never be conflated:

| | Embedding | Semantics |
|---|---|---|
| **What it is** | Dense vector representation of fact text | Domain vocabulary annotation of a file's business purpose |
| **Produced by** | `batch_embed` worker (ONNX model) | `detect_dsl_mappings` + `ontology_enricher` workers |
| **Used for** | ANN similarity search ("find code like this") | Domain queries ("which files are part of the billing cycle?") |
| **Stored in** | Vector index (`IVectorStore`) | Structured Fact DB (`dsl_mappings`, `ontology_annotations` tables) |
| **In FACT envelope** | `semantic.embedding` block | `semantic.domain_concepts`, `semantic.dsl_patterns` |
| **Confidence dimension** | `cluster_alignment` (structural proximity to centroid) | `semantic_accuracy` (domain annotation matches current facts) |

**`semantic_accuracy`** in the confidence profile is:
- `null` — ontology enrichment has not run for this file (enriched=false)
- `0.0–1.0` — populated after `ontology_enricher` processes the file; degrades when the file's structural facts change significantly (new functions, changed SQL) without re-enrichment, or when the ontology version changes

`semantic_accuracy` obeys the same fidelity ceiling as all other dimensions. A HEURISTIC file cannot have `semantic_accuracy > 0.6`.

---

## 4. Fast — enforcement rules

- ANN search: `ef_search` capped at 64 by default.
- Topology traversal: depth capped at 4 hops by default (configurable via query parameter, max 8).
- Query timeout: 2 seconds hard limit. Partial results returned with `fast.timed_out: true`.
- Ingestion: `parse_repo` worker processes only changed files (content_hash comparison). Unchanged files emit no events. This is O(changed_files).
- No worker call is synchronous from the API thread. All processing is via events.

---

## 5. Trustworthy — Timely sub-property

**The system NEVER serves a stale answer as if it were fresh.**

| Staleness score | Response behaviour |
|---|---|
| `< 0.1` | Serve with no caveat |
| `0.1 – 0.3` | Serve with staleness caveat in `trustworthy.timely.staleness_caveat` |
| `> 0.3` | Serve with WARNING caveat; trigger immediate re-ingestion |
| Never | Block response waiting for re-ingestion |

`knowledge_current_as_of` MUST be present on **every** response.
A response with `confidence = 1.0` on stale knowledge is worse than no response.
The `eval_staleness_honesty` eval is a hard nightly gate — failure = system is unusable.

---

## 6. Trustworthy — Traceable sub-property

**Every result MUST include full lineage.**

Lineage MUST include:
- `source_file` — the original source file the result was derived from
- `parser_version` — language pack + version that produced the `facts.json`
- `embedding_model` — model name + dimension used to produce the vector
- `indexed_at` — when the artifact was last indexed
- `commit_sha` — the commit at time of indexing

Uncited claims are blocked by the Grounding verifier (see `06-grounding-contract.md`).
The `query_plan` field shows which backends were consulted and in what order.

---

## 7. Accurate — confidence ceiling propagation

`extraction_fidelity` from the language pack propagates as a ceiling on ALL confidence dimensions:

| `extraction_fidelity` | Confidence ceiling |
|---|---|
| `FULL` | 1.0 — no ceiling applied |
| `PARTIAL` | 0.8 — all dimensions capped at 0.8 |
| `HEURISTIC` | 0.6 — all dimensions capped at 0.6 |
| `HEURISTIC` + `used_fallback: true` | 0.5 — DefaultPack result |

An FPS edge or graph edge where either endpoint has `PARTIAL`/`HEURISTIC` fidelity inherits the lower ceiling.

---

## 8. Complete — coverage warnings

Pre-query, the GraphQL query planner checks `indexing_state` for:
- Repos that were never indexed
- Repos currently in-flight (indexing in progress)
- Files that failed parsing (recorded in `file_facts` with `parse_status = 'failed'`)

These are reported in `complete.coverage_warnings[]` — never silently omitted.
An empty `coverage_warnings[]` means full coverage was available at query time.

---

## 9. References

| # | Citation | Relevance |
|---|----------|----------|
| R1 | Wang, R. & Strong, D. "Beyond Accuracy: What Data Quality Means to Data Consumers", J. Management Information Systems 1996 (~7,000 citations) | Foundational IQ framework defining accuracy, completeness, timeliness, consistency — FACT maps directly to these dimensions |
| R2 | ISO 8000:2022 — Data Quality (iso.org/standard/81745.html) | International standard for data quality dimensions, measurement, and governance |
| R3 | Wand, Y. & Wang, R. "Anchoring Data Quality Dimensions in Ontological Foundations", CACM 1996 | Argues single quality scores hide degradation — validates ECLE's ban on scalar confidence |
| R4 | Kazman, R. et al. "Architecture Tradeoff Analysis Method (ATAM)", CMU SEI Technical Report 2000 | Every architectural decision must declare quality attribute trade-offs — FACT impact assessment follows ATAM |
| R5 | ISO/IEC 25012:2008 — Data quality model (SQuaRE series) | International standard defining inherent and system-dependent data quality characteristics |
