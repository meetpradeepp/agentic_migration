# Contract 03 — Testing Contract

**Scope:** All code in `src/` and `tests/`.  
**Enforced by:** CI Stage 1 (unit), CI Stage 2 (integration), nightly eval suite.  
**Status:** Active

---

## 1. Test pyramid

```
         ┌──────────────┐
         │     E2E      │  10% — full pipeline, docker-compose, nightly only
         └──────────────┘
       ┌──────────────────┐
       │   Integration    │  20% — cross-worker, real SQLite/ChromaDB, every PR
       └──────────────────┘
     ┌──────────────────────┐
     │      Unit Tests      │  70% — single class/function, no I/O, every PR
     └──────────────────────┘
```

---

## 2. Coverage requirements

| Code category | Minimum line coverage | Rationale |
|---|---|---|
| Any new code | 80% | Baseline quality |
| Interface definitions, base schemas | 95% | These are contracts — must be fully specified |
| Grounding verifiers | 100% | Safety-critical — incorrect verification = hallucination passes |
| Event payload validation | 95% | Malformed events cause silent data loss |
| Existing code | No regression | Coverage can only increase, never decrease |

---

## 3. Unit test rules

- **Write tests first** — tests for a spec are written before any implementation code. All tests MUST be committed (failing) before the first `feat(...)` commit on the branch (see `02-sdlc-contract.md` §4).
- **Source of truth** — every test case in `## Tests required` and every `## Acceptance criteria` example in the spec MUST have a corresponding test function. Untested AC examples = unfinished implementation.
- **Location:** `tests/unit/test_<module_name>.py` — mirrors `src/ecle/` exactly.
- **Name format:** `test_<function>_<scenario>` e.g. `test_persist_raises_on_missing_artifact`.
- **Isolation:** No test depends on another. No shared mutable state between tests.
- **No I/O:** Unit tests MUST NOT touch the filesystem, network, or a real DB.
  Use in-memory SQLite (`":memory:"`), `tmp_path` fixtures, and mocked interfaces.
- **Speed:** Each unit test MUST complete in < 100ms.
- **Deterministic:** Same input → same output, always. No random seeds, no timestamps without mocking.

```python
# CORRECT — isolated, no I/O, fast
def test_pack_registry_returns_default_for_unknown_extension(tmp_path):
    registry = LanguagePackRegistry(packs_dir=tmp_path)
    pack = registry.get(".xyz")
    assert pack.manifest["metadata"]["language_id"] == "default"
    assert pack.manifest["fast_extraction"]["fidelity"] == "HEURISTIC"

# WRONG — hits real filesystem, slow, non-deterministic
def test_pack_registry():
    registry = LanguagePackRegistry(packs_dir=Path("language_packs/"))
    assert registry.get(".py") is not None
```

---

## 4. Integration test rules

- **Location:** `tests/integration/test_<flow_name>.py` — named by the flow being tested.
- Use real SQLite (`:memory:` or temp file), real ChromaDB (temp dir), real Celery workers (eager mode).
- Docker Compose services (Neo4j, PostgreSQL) available in CI Stage 2.
- Must cover the full event chain for the flow being tested, not just one worker.
- Each integration test MUST leave no side effects (clean up DB/files in teardown).

---

## 5. Test properties by component type

| Property | Deterministic workers (parse, persist, embed) | Event-driven flows |
|---|---|---|
| **Deterministic** | Required — same input → same output | Required — same events → same final state |
| **Idempotent** | Required — processing the same event twice = same DB state | Required |
| **Fast** | < 100ms per unit test | < 5s per integration test |
| **Isolated** | No external service | Uses real backends in Docker |

---

## 6. Eval suites — hard CI gates

These are **not regular tests**. They are behavioural contracts.
Failure means the system is fundamentally broken. A failing eval blocks release.

| Eval | What it tests | Pass criteria | CI stage |
|---|---|---|---|
| `eval_fallback_coverage` | DefaultPack fires for unknown extensions | `used_fallback=true`, fidelity=HEURISTIC in event | Every PR |
| `eval_idempotent_ingest` | Processing same event twice = same DB state | Row counts identical; no duplicates | Every PR |
| `eval_fidelity_ceiling` | HEURISTIC fidelity propagates to confidence ceiling | `confidence_ceiling ≤ 0.6` on HEURISTIC results | Every PR |
| `eval_grounding_coverage` | All query results carry complete lineage chains | 0 `lineage.incomplete` events on nightly corpus | Nightly |
| `eval_staleness_honesty` | No stale answers served as fresh | `knowledge_current_as_of` always present | Nightly |
| `eval_event_chain_complete` | All events in a full ingest chain are emitted | All expected event types appear in log | Every PR |
| `eval_srp_isolation` | No worker touches another worker's domain | Checked via event payload inspection, not direct calls | Every PR |
| `eval_schema_conformance` | All `facts.json` artifacts conform to base schema | JSON Schema validation pass rate = 100% | Every PR |

---

## 7. Performance benchmarks — enforced in CI

| Operation | Target | Gate |
|---|---|---|
| `pack.sanitize()` per file | < 10ms | CI fails if exceeded on reference corpus |
| `tree_sitter.Parser().parse()` per file | < 10ms | CI fails if exceeded |
| `pack.fast_extractor.extract()` per file | < 50ms | CI fails if exceeded |
| Structured DB insert (full file row set) | < 100ms | CI fails if exceeded |
| ANN search (Layer 1, top-10) | < 50ms | CI fails if exceeded |
| GraphQL query (structured, simple) | < 200ms | CI fails if exceeded |
| Regression tolerance | < 10% degradation from baseline | Alert + block if exceeded |

---

## 8. Fixture strategy

```
Development:    run tests against real backends (local Docker)
CI Stage 1:     in-memory SQLite + ChromaDB temp dir — no Docker needed
CI Stage 2:     Docker Compose (PostgreSQL, Neo4j, Qdrant)
Nightly:        full E2E with live data fixtures
```

---

## 9. What to test (by layer)

Start from the spec, not from the implementation. For each component:
1. Copy every item from `## Tests required` into the test file as a `def test_...` stub (all failing).
2. Copy every item from `## Acceptance criteria` into the test file as a parameterised or named test.
3. Then write implementation until all pass.

| Layer | What to unit-test | What to integration-test |
|---|---|---|
| Language pack | `sanitize()`, `extract()` on known fixtures; fidelity field; fallback fires | Full parse_repo worker run on fixture repo |
| persist_facts | DB rows written correctly; idempotency; partial failure handling | file.ir_produced → file.stored event chain |
| build_graph | Neo4j MERGE calls; edge types; idempotency | file.ir_produced → graph.updated chain |
| chunk_file | Chunk boundaries; token budget respected; artifact written | file.stored → file.chunked chain |
| batch_embed | Vector shape; slim payload; Layer 1/2 correctness | file.chunked → file.embedded chain |
| GraphQL query | Routing decision (structured vs vector vs graph) | End-to-end query returning FACT envelope |
| MCP tools | Tool response shape; FACT envelope present | Full tool call → grounded response |
