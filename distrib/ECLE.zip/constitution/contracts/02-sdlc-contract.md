# Contract 02 — SDLC Contract

**Scope:** All code changes in `src/`, `tests/`, `specs/`, `constitution/`.  
**Enforced by:** Branch protection, CI gates, PR review checklist.  
**Status:** Active

---

## 1. The lifecycle — no step is skippable

```
Spec → Write failing tests → Implement → Green → Review → Merge → Release
```

**HARD RULE: Spec before code. Tests before implementation. Always.**

No implementation begins without a written spec at `specs/phase-N/SPEC-NNNN-<name>.md`.
Code without a spec is unauthorised code. Reviewer rejects it immediately.

**Phase governance:** Every spec's `Phase: N` header MUST reference a phase defined in
`17-phase-roadmap-contract.md`. Work targeting a future phase (whose entry criteria are
not yet met) is deferred — the orchestrator declares it and parks it. No phase-N+1 work
may begin until phase-N exit criteria pass. See Contract 17 for full rules.

TDD order within a feature branch:
1. Write all test cases listed in `## Tests required` and `## Acceptance criteria` — they all fail (Red).
2. Write the minimum implementation to make them pass (Green).
3. Refactor under green — no behaviour changes, tests stay green.
4. Open PR. CI proves green before review.

---

## 2. Spec format

Every spec MUST contain all of the following sections:

```markdown
# SPEC-NNNN — <title>

**Phase:** N
**Status:** Draft | Approved | Implemented | Superseded
**Implements:** <ADR-NNNN if applicable>
**Depends on:** <SPEC-NNNN, SPEC-NNNN>

## Problem
One paragraph — what gap or requirement this spec addresses.

## Decision
What we are building. Interface-first: define the public API, inputs, outputs,
events emitted, and events consumed BEFORE describing the implementation.

## Interface contract
<function signatures, event payload shapes, DB table changes>

## Behaviour
Numbered steps describing the exact execution model.

## Acceptance criteria
Concrete input/output examples that make the behaviour unambiguous and testable.
At least one example per non-trivial behaviour step.
Format: Given / Input / Expected output.
Test vectors for deterministic operations (hashes, IDs) committed to `tests/fixtures/`.

## Error handling
How each error condition is classified and reported.

## Tests required
File: `tests/unit/test_<name>.py` and/or `tests/integration/test_<name>.py`
List of test cases that must pass before this spec is considered implemented.

## Out of scope
Explicitly state what this spec does NOT cover.

## Deviations
Filled in at implementation time. Document every case where the implementation
diverged from this spec, and why. Empty = implementation matches spec exactly.
```

---

## 3. Branch strategy

```
main                     production-ready, always deployable
  └─ phase-{N}/{scope}-{feature}    feature branches
       e.g. phase-1/parser-language-pack-registry
            phase-2/embed-onnx-worker
```

Rules:
- Branch from `main` only.
- Branch name MUST include phase number and feature name.
- Keep branches short-lived — target < 1 week.
- Never commit directly to `main` — all changes via PR.

---

## 4. Commit standards

Format: `<type>(<scope>): <description> [Phase N]`

```
feat(parser): add LanguagePackRegistry scan on startup [Phase 1]
fix(events): emit fallback_count in repo.ir_produced payload [Phase 1]
test(parser): add unit tests for DefaultPack fallback path [Phase 1]
refactor(db): extract IStructuredDB interface from SQLiteBackend [Phase 1]
docs(constitution): add ADR-0002 language pack registry [Phase 1]
```

Types: `feat` | `fix` | `test` | `refactor` | `docs` | `chore` | `perf`

Rules:
- One logical change per commit — atomic, reversible.
- Present tense, imperative mood ("add", not "added" or "adds").
- Reference spec/ADR in the body when the commit implements one.
- **TDD commit order on every feature branch: `test(...)` commit MUST precede the first `feat(...)` commit.** Reviewer checks `git log --oneline` to verify order.
- Pre-commit hooks enforce: `ruff check` + `ruff format` + `pytest` on staged files.

---

## 5. PR rules

- **Max 500 lines changed** (excluding auto-generated files and test fixtures).
- PR description MUST include: what changed, which phase/spec it implements, link to spec doc.
- CI Stage 1 (lint + unit tests) MUST pass before reviewer looks at the PR.
- CI Stage 2 (integration tests) MUST pass before merge.
- No self-merge — at minimum one human review required.

---

## 6. Review checklist (9-point — reviewer applies to every PR)

1. **Spec conformance** — does the implementation match the spec exactly? No undocumented behaviour.
2. **Interface contract** — public APIs match the types defined in the spec.
3. **Coding standards** — `01-coding-standards.md` checklist passes.
4. **Test coverage** — new code ≥ 80% line coverage; critical paths 95%+.
5. **No anti-patterns** — `10-anti-patterns.md` items are absent.
6. **Event contract** — if the code emits or consumes events, payload matches `09-event-pipeline-contract.md`.
7. **No orphan data paths** — if a spec creates a table or writes a schema field, the write path EXISTS and is tested. Schema without writes = bug (learned from ADR-0001 post-mortem).
8. **Acceptance criteria covered** — every example in `## Acceptance criteria` has a corresponding test. No uncovered examples.
9. **Test traceability header** — every new test file has `# Implements: SPEC-NNNN` in its module docstring or header comment. Reviewer verifies the link is correct.
10. **SAST report** — `@sast` agent runs `bandit` + `pip-audit` at G5 and writes `.github/pipeline/workspace/current/reviews/sast-report.md`. Reviewer checks the verdict:
    - `FAIL`: pipeline halted — FAIL findings must be resolved before merge.
    - `WARN`: reviewer adds a PR comment acknowledging each WARN finding by name.
    - `PASS`: no action required.
    Full policy in ADR-0036. Agent file: `.github/agents/sast.agent.md`.

Additional reviews triggered by:
- **Security review** — new external dependency, new API endpoint, auth changes.
- **Architecture review** — cross-layer changes, schema changes, new event types.
- **SAST review** — mandatory at every G5 run via `@sast` agent (ADR-0036).

---

## 7. Non-negotiable rules

1. No direct commits to `main`.
2. No merge without passing CI.
3. No merge without code review.
4. No hardcoded values — config or constants, never magic numbers in logic.
5. No secrets in code — `.env` or vault only, never committed.
6. No stale docs — if code changes, the relevant spec and contract update in the same PR or a linked follow-up PR opened before merge.
7. No scope creep — if a task grows beyond the spec, split into a new spec and a new PR.
8. No orphan data paths — schema without writes is a bug.
9. No spec written after implementation — spec MUST pre-date the first commit on the feature branch.
10. No cross-cutting changes without a cross-cutting spec review — if Spec A reads from X and Spec B writes to X, both MUST reference each other. Reviewer verifies the write path exists before approving the read path.
11. No spec marked `Status: Implemented` without `## Deviations` filled in — even if empty (`_None — implementation matches spec exactly._`).
12. No test file without a traceability header — `# Implements: SPEC-NNNN` MUST appear in the module docstring or as a top-of-file comment.
13. No `feat(...)` commit without a prior `test(...)` commit on the same branch — TDD order is enforced at review. Implementation commits that arrive before test commits are rejected.

---

## 8. Release gates

Release gates are governed by `17-phase-roadmap-contract.md` exit criteria.

```
Phase completion → ALL exit criteria in Contract 17 §{phase} pass
                 → tag v0.{phase}.0
                 → CHANGES.md updated
                 → All eval suites pass (see 03-testing-contract.md)
                 → All specs in phase marked Status: Implemented
                 → All relevant constitution docs updated
```

The `release-manager` agent verifies all exit criteria before recommending a version tag.
A phase MUST NOT be tagged if any exit criterion is unmet. No exceptions.

Version scheme: `v0.{phase}.{patch}` for phases 1-5; `v1.0.0` for Phase 6 (enterprise GA).
Patches within a phase (bug fixes, enhancements): `v0.1.1`, `v0.1.2`, etc.

---

## 9. Post-implementation smoke test

After any ingestion or pipeline change, run this sequence and verify non-empty results at each step:

```bash
# 1. Upload a small known repo
POST /upload  test_fixture.zip

# 2. Poll until repo.ir_produced event appears
ecle events --type repo.ir_produced --repo test_fixture

# 3. Verify structured DB populated
ecle stats --repo test_fixture        # files > 0, functions > 0

# 4. Verify vectors exist
ecle search "billing function" --repo test_fixture    # results, not "no index"

# 5. Verify graph populated
ecle impact --file batch_rating.ppc --repo test_fixture    # edges > 0
```

Any step returning empty or erroring = integration gap. Fix before merging.
