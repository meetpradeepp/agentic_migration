# Contract 20 — Semantic Rule Engine Contract

> **Companion to:** ADR-0034 (Semantic Rule Engine for Fact-Level Annotation)
> **Spec:** SPEC-0010 (`semantic_interpreter` worker) — to be authored
> **Phase:** 1

This contract defines the YAML rule schema, evaluation semantics, annotation lineage
requirements, three-tier precedence model, re-annotation triggers, and the authoritative
Supported Keywords reference for the `semantic_interpreter` worker and all rule consumers.
Every rule file must conform to this contract before being accepted by the Admin API rule
endpoint or the base rule loader at startup.

---

## §1 Purpose

The semantic rule engine adds domain meaning to structurally-correct but semantically-opaque
facts produced by Layer 0 (Tree-sitter, Joern). A **rule** is a YAML document that matches
a structural fact (field value, co-occurrence pattern, or query token) and annotates it with
domain attributes (`platform`, `type`, `group`, `role`, `domain_entity`).

Rules are the **exclusive mechanism** for writing to `semantic_annotations`. No other
component may insert or update `semantic_annotations` rows except `semantic_interpreter`.

---

## §2 Rule Scopes

Every rule carries a `scope` field. Scope determines when the rule is evaluated and whether
the result is persisted.

| Scope | Evaluated by | Evaluated when | Persisted? | Latency budget |
|-------|-------------|---------------|-----------|---------------|
| `annotation` | `semantic_interpreter` worker | At ingest time (triggered by `ecle.file.stored` or `ecle.repo.indexed`) | Yes — written to `semantic_annotations` | No hard limit (background worker) |
| `search` | ADR-0018 `enrich` step | At query time | No — ephemeral per-query rewrite | < 1 ms total across all search rules |
| `display` | MCP result formatter | At response serialisation time | No — cosmetic substitution only | < 0.5 ms total |

### §2.1 scope: annotation

Evaluated by `semantic_interpreter`. Results are persisted to `semantic_annotations` using
an upsert on the unique constraint `(tenant_id, repo_id, target_type, target_id, rule_id)`.

**Required fields:** `rule_id`, `version`, `scope`, `target`, `match`, `annotate`, `confidence`
**Optional fields:** `applies_to`

```yaml
rule_id: string              # unique per tier + scope; required
version: int                 # monotonic; required; minimum value: 1
scope: annotation            # required
applies_to:                  # optional — pre-filter; omit = match any repository
  platform: string | null    # matches repositories.platform (see §6.3); case-insensitive
  language: string | null    # matches repositories.primary_language (see §6.5); case-insensitive
  repo_type: string | null   # matches repositories.repo_type (see §6.4)
target: enum                 # required; valid values: see §6.2
match:                       # required; exactly one of: field+pattern OR co_touch
  # --- Single-fact match ---
  field: string              # column name in the target table
  pattern: string            # glob (default) or "re:..." prefix for Python regex; named captures allowed
  # --- Multi-fact co-occurrence match (repo-batch trigger only) ---
  # co_touch is only valid when target = function_table_ops
  co_touch:
    table_name: string       # glob match on table_name column (e.g. "*" = any table)
    min_functions: int       # minimum number of distinct functions touching the matched table
annotate:                    # required; all fields nullable except those populated by match captures
  platform: string | null    # see §6.7 for reserved values
  domain_entity: string | null   # exact lookup key for ADR-0018 enrich step
  type: string | null        # see §6.6 for reserved values
  group: string | "{match.group_name}" | null   # literal or capture substitution; see §6.9
  role: string | "{match[N]}" | null            # literal or capture substitution; see §6.9
confidence: float            # 0.0–1.0 inclusive; see §6.10
```

**Single-fact rules** (`field + pattern`) are evaluated on both `ecle.file.stored` and
`ecle.repo.indexed` trigger events.

**Co-occurrence rules** (`co_touch`) are evaluated **only** on `ecle.repo.indexed` trigger
events — multi-fact patterns require the full per-repo fact set. Specifying `co_touch` in
a non-`function_table_ops` target or in a `search`/`display` scope rule is a schema
validation error (§5).

#### Example — platform annotation (single-fact, glob):

```yaml
rule_id: tuxedo-service-handler
version: 1
scope: annotation
target: function_facts
match:
  field: function_name
  pattern: "par_*"
annotate:
  platform: Tuxedo
  type: service_handler
confidence: 1.0
```

#### Example — capture-group inference (single-fact, regex):

```yaml
rule_id: gtban-pipeline-group
version: 1
scope: annotation
target: function_facts
match:
  field: function_name
  pattern: "re:^at(?P<group>[A-Z][a-zA-Z0-9]+)_(extract|process|report)$"
annotate:
  group: "{match.group}"
  role: "{match[2]}"             # group 2 = suffix (extract|process|report); group 1 = named "group" = "GTBan"
  type: pipeline_stage
confidence: 1.0
```

#### Example — multi-fact co-occurrence (co_touch):

```yaml
rule_id: shared-table-group
version: 1
scope: annotation
target: function_table_ops
match:
  co_touch:
    table_name: "*"
    min_functions: 2
annotate:
  group: "{table_name}"
  type: shared_table_group
confidence: 0.8
```

### §2.2 scope: search

Evaluated at query time by the ADR-0018 `enrich` step. MUST complete in **< 1 ms** across
all search rules combined. Rules MUST NOT access the database. Results are applied to the
live query only; they are never persisted.

Two mutually exclusive sub-forms: **rewrite rule** and **keyword group definition**. A
single rule document MUST contain exactly one sub-form.

```yaml
# --- Sub-form A: Rewrite rule ---
rule_id: string
version: int
scope: search
applies_to: ...              # same structure as §2.1 applies_to
match:
  query_token: string        # exact or glob match on individual user query tokens
rewrite:
  filter:                    # add DB filter predicates to the query plan
    platform: string | null  # restrict results to this platform
    type: string | null      # restrict results to this annotated type
    group: string | null     # restrict results to this annotated group
  expand_tokens: [string]    # additional query tokens to include in query expansion

# --- Sub-form B: Keyword group definition ---
rule_id: string
version: int
scope: search
keyword_group: string        # group name (e.g. "GTBan"); unique per rule file
members: [string]            # glob patterns resolving to group members at rule-load time
description: string          # shown verbatim in MCP tool response for user context
```

A keyword group definition MUST NOT include `match` or `rewrite`. A rewrite rule MUST NOT
include `keyword_group` or `members`. The two sub-forms are mutually exclusive within a
single rule document.

### §2.3 scope: display

Evaluated by the MCP result formatter before the response is serialised. Cosmetic only —
no query modification, no database access. MUST complete in **< 0.5 ms** across all display
rules combined.

```yaml
rule_id: string
version: int
scope: display
applies_to: ...              # same structure as §2.1 applies_to
match:
  field: string              # column name in the result row
  pattern: string            # glob (default) or "re:..." prefix
label: string                # human-readable label substituted in the output column header
description: string | null   # optional tooltip / explanation shown alongside the value
```

---

## §3 Rule Group Container

An optional wrapper that groups related rules under a shared `applies_to` context and
description. Valid for any scope. Individual rules within the group MAY provide their own
`applies_to` to override the group-level filter.

```yaml
rule_group: string           # group name; unique per rule file
version: int                 # monotonic; bumped when any enclosed rule or applies_to changes
applies_to:                  # group-level applies_to; rules without their own inherits this
  platform: string | null
  language: string | null
  repo_type: string | null
description: string          # human-readable purpose; shown in Admin API GET /semantic-rules/{tier} response
rules:
  - rule_id: ...
    version: ...
    scope: ...
    ...                      # all fields as defined per scope in §2
```

Rule group containers are parsed by the YAML rule loader as syntactic sugar. Each enclosed
rule is extracted as an independent rule carrying the group's `applies_to` (unless the rule
provides its own `applies_to`). The `rule_group` name is **not** stored in
`semantic_annotations` — it is purely organisational.

---

## §4 Three-Tier Precedence Model

Rules are loaded from three tiers and evaluated in strict precedence order:

| Tier | Source | Precedence | Mutability |
|------|--------|-----------|-----------|
| `repo` | Artifact store: `semantic_rules/{tenant_id}/{repo_id}/repo.yaml` | **Highest** | Hot-reloadable; repo owner-controlled |
| `tenant` | Artifact store: `semantic_rules/{tenant_id}/tenant.yaml` | Middle | Hot-reloadable; tenant admin-controlled |
| `base` | `src/ecle/workers/semantic_interpreter/base_rules/` | **Lowest** | Read-only; versioned with ECLE release |

**Conflict resolution rules (mandatory for all implementations):**

1. **repo > tenant > base.** When rules from different tiers match the same fact and
   produce conflicting annotations for the same field, the higher-tier rule wins.
2. **Within the same tier: highest confidence wins.** If two rules from the same tier
   match the same fact, the rule with the higher `confidence` value produces the annotation.
3. **Tie within same tier (equal confidence): first-match-wins in file order.** Rules are
   evaluated in the order they appear in the YAML file; the first matching rule wins.
4. **The winning rule's identity is always recorded.** `semantic_annotations.rule_id` and
   `semantic_annotations.rule_version` reflect the winning rule. Losing rules produce no
   row for this fact + field combination.

---

## §5 Pydantic Validation Requirements

All rule files MUST be validated via a Pydantic v2 model before loading. Schema module path
(to be created in SPEC-0010): `src/ecle/workers/semantic_interpreter/rule_schema.py`.

The Admin API (`POST /admin/v1/semantic-rules/{tier}`) and the base rule loader at startup
MUST both invoke this validation. A rule file that fails validation MUST be rejected with
a descriptive error message; it MUST NOT be partially loaded.

**Validation MUST reject with error:**

| Condition | Reason |
|-----------|--------|
| `scope` not in `{annotation, search, display}` | Invalid scope |
| `target` not in `{file_tables, function_facts, function_table_ops}` (annotation only) | Invalid target |
| `confidence` outside `[0.0, 1.0]` | Out of range |
| `confidence` not a float (e.g. a string or missing) | Wrong type |
| `version` < 1 | Monotonic constraint |
| `match.field+pattern` and `match.co_touch` both present | Mutually exclusive |
| `keyword_group` and `match` both present (search scope) | Sub-form violation |
| `match.co_touch` on a `search` or `display` scope rule | Invalid combination |
| `match.co_touch` on a target other than `function_table_ops` | Co-occurrence requires function_table_ops |
| `annotate` field references `{match.group_name}` but pattern has no such named group | Capture mismatch |
| `annotate` field references `{match[N]}` but pattern has no Nth positional group | Capture mismatch |
| Duplicate `rule_id` within the same tier's rule file | ID collision |
| `annotate` entirely absent (annotation scope) | Required field |
| `rewrite` entirely absent in a non-keyword-group search rule | Required field |
| `label` absent in a display rule | Required field |

**Validation MUST warn (log WARN, do not reject) on:**

| Condition | Reason |
|-----------|--------|
| `applies_to.platform` value not in reserved list (§6.3) | Open enum — may be custom platform |
| `applies_to.repo_type` value not in reserved list (§6.4) | Open enum — may be custom type |
| `confidence: 1.0` on a glob or regex pattern (not an exact literal) | High confidence on non-deterministic match |
| `applies_to.language` value not a recognised language string | Open enum |

---

## §6 Supported Keywords Reference

This section is the **authoritative enumeration** of all valid keyword values. Open enums
are validated against the `repositories` table at runtime; unknown values produce a WARN log
but are not rejected (they may represent future platforms or tenant-specific naming).

### §6.1 scope

| Value | Description |
|-------|-------------|
| `annotation` | Evaluated at ingest time by `semantic_interpreter`; result persisted to `semantic_annotations` |
| `search` | Evaluated at query time by ADR-0018 `enrich` step; ephemeral per-query rewrite |
| `display` | Evaluated by MCP result formatter at response time; cosmetic substitution only |

### §6.2 target (annotation scope only)

| Value | Source table | Eligible triggers |
|-------|-------------|------------------|
| `file_tables` | `file_tables` | `ecle.file.stored`, `ecle.repo.indexed` |
| `function_facts` | `function_facts` | `ecle.file.stored`, `ecle.repo.indexed` |
| `function_table_ops` | `function_table_ops` | `ecle.file.stored` (single-fact); `ecle.repo.indexed` (co_touch) |

### §6.3 applies_to.platform

Open enum. Any string is accepted; values are matched case-insensitively against
`repositories.platform`. The following are **reserved standard values** that resolve
without warning:

| Value | Description |
|-------|-------------|
| `Tuxedo` | BEA/Oracle Tuxedo middleware service |
| `Spring` | Spring Framework (Java) |
| `Django` | Django web framework (Python) |
| `Rails` | Ruby on Rails |
| `FastAPI` | FastAPI web framework (Python) |
| `Express` | Express.js (Node.js) |
| `Flask` | Flask web framework (Python) |
| `unknown` | Platform not yet classified |

Non-listed values are valid and will be matched against `repositories.platform` at
evaluation time. A WARN log is emitted if the value is not found in any known repository.

### §6.4 applies_to.repo_type

Open enum. Reserved standard values for `repositories.repo_type`:

| Value | Meaning |
|-------|---------|
| `platform_service` | Service deployed and managed by a platform framework (e.g. a Tuxedo server process) |
| `application` | General-purpose application repository |
| `library` | Shared library consumed by other repositories |
| `infrastructure` | Infrastructure / configuration repository (Terraform, Helm, Ansible, etc.) |
| `unknown` | Repository type not yet classified |

### §6.5 applies_to.language

Open enum. Any string is accepted; matched case-insensitively against
`repositories.primary_language`. Examples of expected values: `COBOL`, `Java`, `Python`,
`C`, `C++`, `JavaScript`, `TypeScript`, `Ruby`, `Go`.

### §6.6 annotate.type (annotation scope)

Reserved values for the `annotate.type` field. Custom values are permitted but are not
guaranteed to be interpreted by downstream consumers (ADR-0018 enrich step, MCP tools).

| Value | Meaning |
|-------|---------|
| `service_handler` | Entry-point function handled by a platform service framework |
| `pipeline_stage` | One stage in a multi-step data pipeline (e.g. extract / process / report) |
| `shared_table_group` | Set of functions that co-operate on the same database table |
| `entry_point` | Top-level program entry point (main function, CLI handler, API route) |
| `utility` | General-purpose utility function with no domain-specific role |
| `unknown` | Classification not determinable from available pattern evidence |

### §6.7 annotate.platform (annotation scope)

Reserved values for the `annotate.platform` field. Custom values are permitted.

| Value | Meaning |
|-------|---------|
| `Tuxedo` | BEA/Oracle Tuxedo middleware service |
| `Spring` | Spring Framework (Java) component |
| `Django` | Django web framework (Python) component |
| `Rails` | Ruby on Rails component |
| `FastAPI` | FastAPI web framework (Python) component |
| `unknown` | Platform not classifiable from available pattern evidence |

### §6.8 Pattern prefixes

| Prefix | Semantics | Matching function | Example |
|--------|-----------|------------------|---------|
| (none — default) | Glob — `fnmatch` semantics; `*` = any sequence, `?` = one character | `fnmatch.fnmatch(value, pattern)` | `par_*` matches `par_ban`, `par_auth` |
| `re:` | Python regex — full-string match semantics | `re.fullmatch(pattern[3:], value)` | `re:^at(?P<group>[A-Z]\w+)_(extract\|process\|report)$` |

Glob patterns are matched **case-sensitively** by default. To match case-insensitively,
use a regex with the `(?i)` inline flag: `re:(?i)par_.*`.

### §6.9 Capture substitution

Available only in `annotate` fields when `match.pattern` is a regex (`re:` prefix).
Capture substitutions are resolved at annotation time against the match result.

| Syntax | Source | Requirement |
|--------|--------|-------------|
| `{match.group_name}` | Named capture group in the `re:` pattern | Pattern MUST contain `(?P<group_name>...)` |
| `{match[N]}` | Positional capture group (1-based index) | Pattern MUST contain at least N capture groups |

Substitution expressions are **validated at rule-load time** by the Pydantic schema (§5).
A rule referencing `{match.group_name}` when the pattern contains no such named group is
rejected. A rule referencing `{match[N]}` when the pattern has fewer than N groups is
rejected.

### §6.10 confidence

`confidence` is a float in `[0.0, 1.0]` stored in `semantic_annotations.confidence`.

| Range | Meaning | Typical usage |
|-------|---------|--------------|
| `1.0` | Exact or fully deterministic match | Exact literal match; no ambiguity possible |
| `0.8 – 0.99` | High-confidence heuristic | Strong naming convention; rare edge cases possible |
| `0.5 – 0.79` | Medium-confidence heuristic | Useful signal but some mismatches expected |
| `0.0 – 0.49` | Low-confidence heuristic | Broad pattern; prefer higher-confidence override rules |

Downstream consumers (ADR-0018 enrich step, MCP tools) MAY filter results by a minimum
confidence threshold. The FACT-T (Trustworthy) contract requires that confidence is never
inflated: a rule matching on a broad glob MUST use `confidence < 1.0`.

---

## §7 Evaluation Semantics

### §7.1 annotation scope evaluation order

1. Load rule files for all applicable tiers (base + tenant + repo). Validate each file via
   the Pydantic schema (§5). On validation error: emit WARN log with file path and error
   detail; skip the invalid file; do not abort processing of valid files.
2. For each repository being annotated, evaluate `applies_to` pre-filter against
   `repositories.platform`, `repositories.primary_language`, and `repositories.repo_type`.
   Skip all rules in a file whose `applies_to` does not match the repository. Omitted
   `applies_to` = match any repository.
3. For each target fact row, evaluate applicable rules' `match.pattern` (glob or regex)
   against the specified `match.field` value. For `co_touch` rules, group
   `function_table_ops` rows by `table_name` and evaluate the co-occurrence condition.
4. On match: collect all `annotate` field values, resolving any capture substitutions (§6.9).
   Apply tier precedence (§4) across all matching rules for this fact.
5. Write one `semantic_annotations` row per winning `rule_id` for this fact. Upsert on
   `(tenant_id, repo_id, target_type, target_id, rule_id)` — idempotent (same event twice
   produces the same final state).
6. After all facts for the repository are processed, emit `ecle.facts.annotated` (Contract 09)
   with payload `{repo_id, tenant_id, annotation_count, rule_ids[], annotated_at}`.

### §7.2 search scope evaluation order

7. At query time, for each token in the user query, evaluate all `search` rules in
   load order. Apply `applies_to` pre-filter against the active query context.
8. On match: apply `rewrite.filter` predicates to the query plan; append
   `rewrite.expand_tokens` to the query token set.
9. Keyword group lookups: if the query token matches a `keyword_group` member pattern,
   expand to all members of that group.
10. MUST complete in < 1 ms total. No database access is permitted in search rule evaluation.

### §7.3 display scope evaluation order

11. At response-formatting time, for each result column matching `match.field` and
    `match.pattern`, substitute `label` in the output column header. Attach `description`
    as a tooltip field if present.
12. MUST complete in < 0.5 ms total.

---

## §8 Re-annotation Triggers

| Trigger | Scope | What is re-annotated |
|---------|-------|---------------------|
| New rule file uploaded via Admin API (`POST /admin/v1/semantic-rules/tenant` or `/repo`) | Scoped to changed `rule_id` | All facts in affected repositories for the changed `rule_id` only |
| `--force-reannotate` Admin CLI flag | Full | All annotations for all rules across all facts in the specified repository |
| `ecle.repo.indexed` received for a repository with no existing annotations | Full | All rules, all facts for that repository |
| `ecle.file.stored` received | Incremental | All single-fact (`field+pattern`) annotation rules for that file's extracted facts |

**Scoped re-annotation procedure** (on rule file update):

1. Admin API validates YAML schema and bumps `rule_version`.
2. Admin API emits a scoped re-annotation event with payload `{rule_id, rule_version_new, tenant_id, repo_id (optional)}`.
3. `semantic_interpreter` sets `is_current=false` and `superseded_at=now()` for all
   `semantic_annotations` rows matching `rule_id = <changed_rule_id>`.
4. `semantic_interpreter` re-evaluates that rule against all relevant facts, writing new
   rows with the updated `rule_version`.
5. Rows from other `rule_id` values are untouched.

---

## §9 Annotation Lineage Requirements

Every row written to `semantic_annotations` MUST carry full lineage. Missing lineage is a
FACT-T (Trustworthy) violation and MUST be caught at code review.

| Field | Requirement |
|-------|------------|
| `rule_id` | MUST match the `rule_id` in the winning rule YAML exactly |
| `rule_version` | MUST match the `version` field of the winning rule at annotation time |
| `annotated_at` | MUST be set to `NOW()` at write time; never back-filled |
| `is_current` | MUST be `true` on the newly written row |
| `previous_id` | MUST reference the superseded row UUID; MUST be `null` for the first annotation of this (tenant_id, repo_id, target_type, target_id, rule_id) combination |

Lineage is enforced by:
- `semantic_annotations` unique constraint: `(tenant_id, repo_id, target_type, target_id, rule_id)`
- `PostgreSQLStructuredDB.upsert()` version-chain logic (SPEC-0009)
- `eval_annotation_lineage` eval suite (§11)

---

## §10 Performance Requirements

| Operation | Budget | Config key |
|-----------|--------|-----------|
| Single-fact rule evaluation — glob | < 1 µs per rule per fact | — |
| Single-fact rule evaluation — regex (compiled) | < 10 µs per rule per fact | — |
| Full-repo annotation (1,000 rules × 10,000 facts) | < 60 s | `SEMANTIC_INTERPRETER_MAX_COOCCURRENCE_ROWS` |
| Search rule evaluation (all rules, per query) | < 1 ms total | Enforced by ADR-0018 enrich step timeout |
| Display rule evaluation (all rules, per response) | < 0.5 ms total | Enforced by MCP formatter |

Regex patterns MUST be compiled at rule-load time and cached for the lifetime of the
worker instance. Re-compiling patterns on every fact evaluation is a performance violation.

---

## §11 Compliance and Eval Suites

- **ADR-0034** — architecture, `semantic_interpreter` SRP, `semantic_annotations` table, event definitions, tier precedence
- **Contract 09** — `ecle.facts.annotated` event payload: `{repo_id, tenant_id, annotation_count, rule_ids[], annotated_at}`; topic: `ecle.facts.annotated`
- **Contract 15** — `semantic_annotations` table; unique constraint on `(tenant_id, repo_id, target_type, target_id, rule_id)`; partial index `WHERE is_current = true`
- **Contract 04** — annotation lineage (§9) satisfies FACT-T (Trustworthy)
- **Contract 10** — `semantic_interpreter` MUST NOT import other worker modules (Anti-pattern A2); `eval_async_coupling` enforces this
- **Contract 18** — `semantic_interpreter` inherits `WorkerBase`; all event consumption via Kafka (no direct calls)
- **Eval suite:** `eval_semantic_rule_schema` — validates all base rule YAMLs against this contract's Pydantic schema on every PR; fails CI if any base rule is invalid
- **Eval suite:** `eval_idempotent_annotation` — annotating the same repo twice produces identical `semantic_annotations` rows; upsert idempotency verified
- **Eval suite:** `eval_tier_precedence` — verifies repo > tenant > base precedence; same-tier highest-confidence wins; tie: first-match-wins in file order
- **Eval suite:** `eval_annotation_lineage` — verifies `rule_id`, `rule_version`, `annotated_at` present and correct on every written `semantic_annotations` row
- **Eval suite:** `eval_search_rule_latency` — asserts total search rule evaluation time < 1 ms under representative load
