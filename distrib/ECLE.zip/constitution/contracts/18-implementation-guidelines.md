# Contract 18 — Implementation Guidelines

**Scope:** All implementation work in `src/`, `tests/`, and agent-generated artifacts.  
**Enforced by:** Code review, validator agent, CI.  
**Status:** Active  
**Related:** Contract 01 (Coding Standards), Contract 02 (SDLC), Contract 03 (Testing), Contract 09 (Events), Contract 10 (Anti-Patterns), ADR-0027 (Async Autonomy), ADR-0029 (Token Optimization), ADR-0030 (Pipeline Workspace)

---

## 0. Purpose

This contract bridges the gap between **spec-level design decisions** and **code-level
execution**. Contracts 01–17 define what rules exist. This contract defines **how to
apply them during implementation** — the practical patterns, the build/test workflow,
the architectural guardrails, and the ADR consumption requirement.

**HARD RULE:** Every implementation decision that isn't obvious from the spec MUST be
traceable to an ADR. If no ADR exists for the decision, write one before implementing.

---

## 1. ADR Consumption During Implementation

### 1.1 Who reads ADRs and when

| Agent | When | ADRs to read |
|-------|------|-------------|
| **spec-writer** | At G1 (writing spec) | All ADRs listed in orchestrator's G0 classification |
| **planner** | At G3 (creating plan) | All ADRs in `workspace/current/adrs/` |
| **coder** | At G4 (each subtask) | All ADRs in `workspace/current/adrs/` |
| **code-reviewer** | At G5 (reviewing code) | All ADRs in `workspace/current/adrs/` |
| **tester** | At G4 (validating tests) | ADRs that define behavioral contracts (check spec's `Implements:` field) |
| **validator** | At every gate | ADRs referenced by the spec being validated |

### 1.2 How ADRs flow into the workspace

1. Spec-writer declares `Implements: ADR-NNNN` in the spec
2. Orchestrator copies all referenced ADRs into `.github/pipeline/workspace/current/adrs/`
3. Downstream agents load ADRs from the workspace — no searching required

### 1.3 What agents do with ADRs

- **Verify the implementation matches the ADR's Decision section** — the ADR says "We will X"; the code must do X
- **Check the ADR's Consequences section** — negative consequences may require specific mitigations in code
- **Reference the ADR in commit messages** when the commit directly implements an ADR decision

---

## 2. Architectural Patterns (Derived from ADRs)

These patterns are the implementation-level expression of ADR decisions. The coder
and code-reviewer MUST apply them. The validator checks for violations.

### 2.1 Worker Pattern (ADR-0013, ADR-0027, Contract 09)

Every Kafka worker follows this structure:

```python
"""
<worker_name> — <one-line description>.

Implements: SPEC-NNNN
Reads:  Kafka topic ecle.<consumed_event>
Writes: Kafka topic ecle.<produced_event>, <DB table or artifact>
"""

from __future__ import annotations

class <WorkerName>(WorkerBase):
    """<One sentence: what this worker's single job is>."""

    def __init__(self, *, config: WorkerConfig, <injected_deps>) -> None:
        super().__init__(config=config)
        self._dep = <injected_dep>  # injected, not constructed

    def process(self, event: Event) -> None:
        """Process a single event. Must be idempotent."""
        # 1. Validate/deserialize event payload
        # 2. Do the ONE thing this worker does
        # 3. Write result to DB/artifact store
        # 4. Emit downstream event(s)
        # 5. Kafka offset committed by WorkerBase after this returns
```

**Rules:**
- Inherit from `WorkerBase` (SPEC-0008) — it handles offset management, lifecycle, DLQ
- Constructor takes dependencies via injection — never construct backends internally
- `process()` is idempotent — same event twice = same DB state
- No `try/except` around the whole `process()` — `WorkerBase` handles error routing
- Workers are stateless — no instance variables persisting between `process()` calls

### 2.2 Backend Abstraction Pattern (ADR-0003, Contract 14)

```python
# CORRECT — business logic depends on interface
class PersistFactsService:
    def __init__(self, db: IStructuredDB) -> None:
        self._db = db

# CORRECT — factory selects implementation at startup
db = get_structured_db()  # returns SQLite in dev, PostgreSQL in Tier 3
service = PersistFactsService(db=db)

# WRONG — hardcoded backend
from ecle.backends.structured.sqlite import SQLiteBackend
service = PersistFactsService(db=SQLiteBackend("ecle.db"))
```

### 2.3 Event Emission Pattern (ADR-0013, Contract 09)

```python
# CORRECT — emit event, then commit offset (WorkerBase handles commit)
self._producer.produce(
    topic="ecle.file.ir_produced",
    key=file_id.encode(),
    value=payload.to_json().encode(),
    headers={
        "X-Request-Id": request_id,
        "X-Trace-Id": trace_id,
    },
)
self._producer.flush()

# WRONG — auto-commit (banned), missing headers, inline payload
producer.produce("file.ir_produced", json.dumps(facts))
```

### 2.4 Configuration Pattern (Contract 01 §6, Contract 14)

```python
# CORRECT
from ecle.config import settings

POLL_TIMEOUT = settings.KAFKA_POLL_TIMEOUT_S
artifact_dir = settings.ARTIFACT_STORE_PATH

# CORRECT — true constant (not configurable)
from ecle.constants import SCHEMA_VERSION
SCHEMA_VERSION: Final[str] = "2.1"

# WRONG
POLL_TIMEOUT = 30  # magic number
artifact_dir = Path("./ecle-data/artifacts")  # hardcoded
```

### 2.5 DB Access Pattern (Contract 15, Contract 01 §7)

```python
# CORRECT — parameterised, filters is_current, includes tenant_id
rows = db.fetchall(
    "SELECT id, symbol_name FROM function_facts "
    "WHERE repo_id = ? AND tenant_id = ? AND is_current = 1",
    (repo_id, tenant_id),
)

# WRONG — f-string SQL, no tenant isolation, no is_current filter
rows = db.fetchall(f"SELECT * FROM function_facts WHERE repo_id = '{repo_id}'")
```

### 2.6 Naming Clarity Pattern (Review Efficiency)

```python
# CORRECT — intent is obvious
db_connection = psycopg2.connect(settings.DATABASE_URL)
sql_query = "SELECT id FROM worker_lifecycle WHERE worker_name = %s"
sql_params = [worker_name]

# WRONG — ambiguous names cause review churn
c = psycopg2.connect(settings.DATABASE_URL)
q = "SELECT id FROM worker_lifecycle WHERE worker_name = %s"
p = [worker_name]
```

Rules:
- Prefer descriptive names for business values, state, and dependencies.
- One-letter names are allowed only for tiny local loop indexes or standard math notation.
- Run a first-pass readability sweep before final verification to avoid post-review rename churn.

---

## 3. Test Implementation Patterns (Contract 03)

### 3.1 Unit Test Pattern

```python
def test_<function>_<scenario>(tmp_path: Path) -> None:
    """Verifies AC-N: <acceptance criteria from spec>."""
    # Given — set up preconditions
    db = InMemoryStructuredDB()  # or ":memory:" SQLite
    service = TargetService(db=db)

    # When — execute the action
    result = service.do_thing(input_data)

    # Then — verify expected outcome
    assert result.field == expected_value
    assert db.fetchall("SELECT ...") == expected_rows
```

### 3.2 Worker Integration Test Pattern

```python
def test_<worker>_<flow>(tmp_path: Path) -> None:
    """Verifies end-to-end: <event_in> → <processing> → <event_out>."""
    # Given — set up worker with test backends
    config = WorkerConfig(...)
    db = SQLiteStructuredDB(":memory:")
    producer = MockKafkaProducer()
    worker = TargetWorker(config=config, db=db, producer=producer)

    # When — simulate event
    event = Event(topic="ecle.input.event", value=test_payload)
    worker.process(event)

    # Then — verify DB state and emitted events
    assert db.fetchall("SELECT ...") == expected
    assert producer.produced[0].topic == "ecle.output.event"
    assert producer.produced[0].headers["X-Request-Id"] is not None
```

### 3.3 Idempotency Test (Required for Every Worker)

```python
def test_<worker>_idempotent_on_duplicate_event(tmp_path: Path) -> None:
    """Verifies eval_idempotent_ingest: processing same event twice = same state."""
    worker = setup_worker(tmp_path)
    event = make_test_event()

    worker.process(event)
    state_after_first = snapshot_db(worker.db)

    worker.process(event)  # same event again
    state_after_second = snapshot_db(worker.db)

    assert state_after_first == state_after_second
```

### 3.4 Real-Kafka Integration Test Stability (Windows + local brokers)

When integration tests use a real Kafka broker and a background worker thread:

- Use a unique consumer group per test run (for example, suffix with UUID) to avoid stale committed offsets.
- For deterministic replay in tests, set consumer `auto.offset.reset="earliest"` unless the test explicitly validates `latest` semantics.
- Start the worker thread before producing the test event, and allow brief subscription/assignment warm-up.
- Explicitly stop worker threads in teardown (`worker.close()` then `thread.join(timeout=...)`) to prevent `Consumer closed` unhandled thread exceptions.
- Mark long-running infrastructure tests with an explicit timeout override (`@pytest.mark.timeout(...)`) so they are not constrained by strict unit-test defaults.

These rules are test-only harness guidance and do not change production consumer semantics.

---

## 4. File Organization (Contract 01 §2)

```
src/ecle/
  config.py              ← Settings (Pydantic BaseSettings)
  constants.py           ← Fixed constants (SCHEMA_VERSION, etc.)
  core/
    backends.py          ← get_structured_db(), get_vector_store(), etc.
    interfaces.py        ← IStructuredDB, IVectorStore, ITopologyGraph, IArtifactStore
  events/
    topic_registry.py    ← all Kafka topics declared here
    payloads.py          ← event payload dataclasses
  workers/
    base.py              ← WorkerBase (SPEC-0008)
    scan_source.py       ← one file per worker
    parse_repo.py
    persist_facts.py
  backends/
    structured/          ← IStructuredDB implementations
    vector/              ← IVectorStore implementations
    graph/               ← ITopologyGraph implementations
    artifacts/           ← IArtifactStore implementations
  language_packs/
    registry.py          ← LanguagePackRegistry
  mcp/
    server.py            ← MCP HTTP server
    tools/               ← one file per MCP tool
```

**Rules:**
- One worker per file in `src/ecle/workers/`
- One MCP tool per file in `src/ecle/mcp/tools/`
- Backend implementations grouped by interface type
- No cross-worker imports — workers share only `core/` and `events/`

---

## 5. Dependency Injection Wiring

At application startup (not import time):

```python
# src/ecle/main.py or worker entrypoint
def create_worker(worker_name: str) -> WorkerBase:
    """Factory that wires dependencies for a specific worker."""
    config = WorkerConfig.from_settings(settings, worker_name)
    db = get_structured_db()
    producer = get_kafka_producer()
    artifact_store = get_artifact_store()

    match worker_name:
        case "parse_repo":
            registry = LanguagePackRegistry(packs_dir=settings.LANGUAGE_PACKS_DIR)
            return ParseRepoWorker(
                config=config, registry=registry,
                artifact_store=artifact_store, producer=producer,
            )
        case "persist_facts":
            return PersistFactsWorker(
                config=config, db=db,
                artifact_store=artifact_store, producer=producer,
            )
```

**No singletons, no global state, no import-time side effects.**

---

## 6. Error Handling in Workers

| Error type | Example | Action | Contract ref |
|---|---|---|---|
| Transient | DB timeout, Kafka broker unavailable | Retry with exponential backoff (max 3) | Contract 09 §5 |
| Permanent | Malformed event payload, missing required field | Send to DLQ topic, commit offset, continue | Contract 09 §5 |
| Extraction | Language pack `extract()` returns errors | Record in `extraction_errors`, set fidelity=HEURISTIC, continue | Contract 08 |
| Validation | Event payload fails schema validation | Permanent → DLQ | Contract 09 §5 |

```python
# WorkerBase handles this — individual workers do NOT wrap process() in try/except
# WorkerBase.run() loop:
#   try: self.process(event); commit_offset()
#   except TransientError: retry with backoff
#   except PermanentError: send_to_dlq(event); commit_offset()
#   except Exception: send_to_dlq(event); commit_offset(); log.error(...)
```

---

## 7. Build & Test Workflow

### Local development (Tier 1)

```bash
# Install
pip install -e ".[dev]"

# Lint + format
ruff check src/ tests/
ruff format src/ tests/

# Type check
mypy src/ecle/

# Unit tests
pytest tests/unit/ -v --tb=short

# Integration tests (requires Docker for Kafka)
docker compose up -d kafka
pytest tests/integration/ -v --tb=short

# Single eval
pytest tests/eval/test_eval_idempotent_ingest.py -v
```

### 7.1 Windows command discipline (token-efficient)

On Windows PowerShell, Python commands MUST be executed via the configured interpreter path:

```powershell
& "c:/<repo>/.venv/Scripts/python.exe" -m pytest tests/unit/test_x.py -v
```

Rules:

- Do not use shell heredoc syntax (for example, `python - <<'PY'`) in PowerShell.
- Prefer one-shot invocations (`-m`, `-c`, script path) over interactive REPL entry during automation.
- Validate interpreter selection once per session before running long test batches.

### 7.2 Coverage command targeting

`pytest --cov` targets Python import modules/packages, not filesystem paths.

```bash
# CORRECT
pytest --cov=ecle.workers.base --cov=ecle.events.topic_registry

# WRONG
pytest --cov=src/ecle/workers/base.py --cov=src/ecle/events/topic_registry.py
```

Using filesystem paths can produce false `0%` coverage due to module resolution mismatch.

### CI pipeline

```
Stage 1 (every PR):  ruff check → ruff format → mypy → pytest tests/unit/ → eval suites
Stage 2 (every PR):  docker compose up → pytest tests/integration/
Nightly:             full corpus eval (eval_grounding_coverage, eval_staleness_honesty)
```

---

## 8. Migration & Schema Change Workflow

When a spec requires DB schema changes:

1. **ADR first** — document why the schema is changing (Contract 15 rule)
2. **Migration file** — `src/ecle/db/migrations/NNNN_<description>.sql`
3. **Idempotent DDL** — use `CREATE TABLE IF NOT EXISTS`, `ALTER TABLE ... ADD COLUMN IF NOT EXISTS`
4. **Test migration** — integration test that runs migration on empty DB and verifies schema
5. **Never drop columns** — only add or rename; old columns kept for backward compatibility
