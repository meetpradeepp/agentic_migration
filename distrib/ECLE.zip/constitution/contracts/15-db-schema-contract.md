# Contract 15 — Structured DB Schema Contract

**Scope:** All workers that read from or write to the Structured Fact DB.  
**Enforced by:** SQLAlchemy model audit (every PR), `eval_schema_migration` (nightly).  
**Status:** Active  
**Related:** ADR-0003, ADR-0007, ADR-0009, ADR-0011, ADR-0017

---

## 1. Core rules — non-negotiable

1. **No hard deletes on fact tables** — old versions are superseded (`is_current=false`), never deleted. History is permanent.
2. **Tenant isolation is mandatory** — every table that stores facts MUST carry `tenant_id`. Cross-tenant queries are forbidden.
3. **`is_current` flag is the freshness signal** — queries MUST filter `is_current=true` unless explicitly requesting history.
4. **Version chain is immutable** — `previous_id` FK once written is never updated. The chain is append-only.
5. **`repo_role` lives in `repositories` only** — workers determine platform/module behavior by joining to `repositories.repo_role`, never by hardcoding repo IDs.
6. **Schema changes require an ADR** — no column additions, removals, or type changes without a corresponding ADR filed first.

---

## 2. Table inventory

### Layer 1 — File-level facts

#### `file_facts`
One row per file per indexed version. The central fact table.

| Column | Type | Notes |
|--------|------|-------|
| `id` | UUID PK | Stable identifier for this version of this file |
| `tenant_id` | VARCHAR | Tenant isolation key |
| `repo_id` | VARCHAR | Repository identifier |
| `file_path` | VARCHAR | Repo-relative path |
| `language` | VARCHAR | From ADR-0012 three-pass detection |
| `grammar` | VARCHAR | Grammar pack used (e.g., `powerbuilder@2.1`) |
| `grammar_scope` | VARCHAR | Language scope within file |
| `execution_model` | VARCHAR | `entry_point \| batch \| service \| library` |
| `content_hash` | VARCHAR | SHA256 of raw file bytes |
| `commit_sha` | VARCHAR | Git commit SHA |
| `behavioral_fingerprint` | VARCHAR | SHA256 of sorted structural facts (Contract 13 §8) |
| `version_distance` | FLOAT | Cosine distance from previous version (nullable) |
| `previous_id` | UUID FK | Previous version of this file (nullable for v1) |
| `is_current` | BOOLEAN | True only for the latest indexed version |
| `superseded_at` | TIMESTAMP | When this version was superseded (nullable) |
| `neighbourhood_hash` | VARCHAR | SHA256 of 2-hop neighbor state (Contract 13 §4) |
| `centrality` | FLOAT | Betweenness centrality within cluster (for hub detection) |
| `cluster_stable_id` | VARCHAR | Louvain cluster assignment (ADR-0011); `SHA256(sorted(file_ids_in_cluster))[:16]`; `null` for singleton files (`LOUVAIN_MIN_CLUSTER_SIZE` exclusion) |
| `indexed_at` | TIMESTAMP | When this version was written |
| `extraction_fidelity` | VARCHAR | `FULL \| PARTIAL \| HEURISTIC` per ADR-0016 |
| `embedding_text_tsv` | TSVECTOR | Pre-tokenized behavioral signature text for BM25 hybrid search (ADR-0004-A2). Populated by `chunk_file` worker. GIN-indexed with `WHERE is_current = true` partial index. |

#### `file_tables`
Tables read/written by each file (from SQL statement extraction).

| Column | Type | Notes |
|--------|------|-------|
| `id` | UUID PK | |
| `tenant_id` | VARCHAR | |
| `file_fact_id` | UUID FK | → `file_facts.id` |
| `repo_id` | VARCHAR | Denormalized for fast lookup |
| `table_name` | VARCHAR | Normalized uppercase |
| `operation` | VARCHAR | `READ \| WRITE \| DDL \| READWRITE` |
| `is_current` | BOOLEAN | Mirrors parent `file_facts.is_current` |

#### `file_entry_points`
Entry points declared in each file (main functions, service handlers, batch triggers).

| Column | Type | Notes |
|--------|------|-------|
| `id` | UUID PK | |
| `tenant_id` | VARCHAR | |
| `file_fact_id` | UUID FK | |
| `entry_point_name` | VARCHAR | |
| `entry_point_type` | VARCHAR | `http_handler \| batch_main \| scheduled \| event_handler \| tuxedo_service \| rpc_service` (ADR-0031) |
| `is_current` | BOOLEAN | |

#### `file_external_calls`
External service calls made by each file (REST, MQ, RPC).

| Column | Type | Notes |
|--------|------|-------|
| `id` | UUID PK | |
| `tenant_id` | VARCHAR | |
| `file_fact_id` | UUID FK | |
| `target_service` | VARCHAR | Service name or URL pattern |
| `call_protocol` | VARCHAR | `REST \| KAFKA \| RPC \| MQ` |
| `is_current` | BOOLEAN | |

---

### Layer 2 — Function-level facts

#### `function_facts`
One row per function per indexed version.

| Column | Type | Notes |
|--------|------|-------|
| `id` | UUID PK | |
| `tenant_id` | VARCHAR | |
| `file_fact_id` | UUID FK | Parent file version |
| `repo_id` | VARCHAR | Denormalized |
| `function_name` | VARCHAR | |
| `parameters` | JSONB | `[{name, type}]` — from ADR-0016 extraction depth |
| `return_type` | VARCHAR | Nullable for void/unknown |
| `line_start` | INT | |
| `line_end` | INT | |
| `cyclomatic_complexity` | INT | |
| `execution_model` | VARCHAR | `entry_point \| batch \| service \| library` |
| `is_current` | BOOLEAN | |
| `previous_id` | UUID FK | Previous version of this function |
| `embedding_text_tsv` | TSVECTOR | Pre-tokenized behavioral signature text for BM25 hybrid search (ADR-0004-A2). Populated by `chunk_file` worker. GIN-indexed with `WHERE is_current = true` partial index. |

#### `function_calls`
Caller→callee relationships extracted from each file.

| Column | Type | Notes |
|--------|------|-------|
| `id` | UUID PK | |
| `tenant_id` | VARCHAR | |
| `caller_file_fact_id` | UUID FK | |
| `caller_function_id` | UUID FK | Nullable (file-level call if no enclosing function) |
| `callee_name` | VARCHAR | Raw name as extracted |
| `call_type` | VARCHAR | `direct \| indirect \| dynamic` |
| `line_number` | INT | |
| `is_current` | BOOLEAN | |

#### `function_table_ops`
Function→table→column granularity. One row per (function, table, operation) tuple (ADR-0031).

| Column | Type | Notes |
|--------|------|-------|
| `id` | UUID PK | |
| `tenant_id` | VARCHAR | |
| `function_id` | UUID FK | → `function_facts.id` |
| `file_fact_id` | UUID FK | → `file_facts.id` (denormalized for direct file join) |
| `repo_id` | VARCHAR | Denormalized |
| `table_name` | VARCHAR | Normalized uppercase. Indexed. |
| `operation` | VARCHAR | `READ \| WRITE \| DDL \| READWRITE` |
| `columns` | TEXT[] | Column names extracted from SQL (nullable — null means extraction failed, empty means no columns) |
| `sql_text` | TEXT | Full SQL text for reference and text search |
| `line` | INT | Line number of the SQL statement |
| `is_current` | BOOLEAN | Mirrors parent `function_facts.is_current` |

Note: `file_tables` is the file-level aggregate. `function_table_ops` is the function-level detail. Both are needed — file-level for broad queries, function-level for precise impact analysis.

#### `file_literals`
Searchable string constants and significant literal values per file (ADR-0031).

| Column | Type | Notes |
|--------|------|-------|
| `id` | UUID PK | |
| `tenant_id` | VARCHAR | |
| `file_fact_id` | UUID FK | → `file_facts.id` |
| `repo_id` | VARCHAR | Denormalized |
| `value` | VARCHAR | The literal value. Indexed. |
| `literal_type` | VARCHAR | `string \| int \| float \| boolean \| table_name` |
| `line` | INT | First occurrence line number |
| `enclosing_method` | VARCHAR | Function containing this literal (nullable for file-level) |
| `is_current` | BOOLEAN | Mirrors parent `file_facts.is_current` |

Deduplication: multiple occurrences of the same literal value in the same file produce one row (first occurrence). Capped at `LITERAL_MAX_PER_FILE` (default: 500) rows per file. String literals shorter than `LITERAL_MIN_LENGTH` (default: 3) are excluded.

---

### Layer 3 — Cluster facts

#### `cluster_assignments`
File → cluster mapping. Updated by `compute_topology` after each Louvain run.

| Column | Type | Notes |
|--------|------|-------|
| `id` | UUID PK | |
| `tenant_id` | VARCHAR | |
| `repo_id` | VARCHAR | |
| `file_fact_id` | UUID FK | |
| `cluster_stable_id` | VARCHAR | `SHA256(sorted(file_ids_in_cluster))[:16]` — join key for downstream workers; changes when cluster membership changes (ADR-0011) |
| `cluster_version` | INT | Monotonically incrementing counter; bumped on every membership change; used for staleness detection without hash comparison |
| `domain_concepts` | TEXT[] | Domain concept labels from `ontology_enricher` (e.g. `["billing-cycle","retry-policy"]`) |
| `concept_stems` | TEXT[] | Pre-computed stemmed tokens from `domain_concepts`; used by `enrich` step Pass 3 (ADR-0018); populated by `ontology_enricher`, never by `batch_embed` |
| `silhouette_score` | FLOAT | Cluster stability metric |
| `assigned_at` | TIMESTAMP | |
| `is_current` | BOOLEAN | |

#### `coverage_gap_counts`
Global miss counter for extension coverage gaps (ADR-0002 §Extension miss handling). Aggregated by `coverage_gap_aggregator` worker from `language_pack.extension_miss` events.

| Column | Type | Notes |
|--------|------|-------|
| `id` | UUID PK | |
| `tenant_id` | VARCHAR | |
| `extension` | VARCHAR | File extension (e.g. `.cbl`, `.rpgle`) |
| `global_miss_count` | INT | Total misses across all workers since last reset |
| `last_updated_at` | TIMESTAMP | |

Note: this table has no `is_current` flag — it is a running counter, not a versioned fact.

---

### Topology

#### `topology_edges`
Structural edges between files. Weighted, typed, versioned.

| Column | Type | Notes |
|--------|------|-------|
| `id` | UUID PK | |
| `tenant_id` | VARCHAR | |
| `repo_id` | VARCHAR | Same-repo edges only (ADR-0017) |
| `source_file_fact_id` | UUID FK | |
| `target_file_fact_id` | UUID FK | |
| `edge_type` | VARCHAR | `FUNCTION_CALL \| WRITE_READ \| EXECUTION_SEQUENCE \| SHARED_TYPE \| IMPORT \| STATE_FLOW \| ERROR_PROPAGATION \| CONFIG_DEPENDENCY \| DATA_LINEAGE \| SERVICE_CALL` |
| `weight` | FLOAT | Canonical weights per ADR-0007 |
| `is_current` | BOOLEAN | |
| `commit_sha` | VARCHAR | Commit at which edge was computed |

---

### Cross-repo / Enterprise

#### `shared_artifacts`
Artifacts referenced across multiple repos (tables, topics, packages, types). Pre-populated
at platform repo ingest time for enrichment queries (ADR-0017).

| Column | Type | Notes |
|--------|------|-------|
| `id` | UUID PK | |
| `tenant_id` | VARCHAR | |
| `artifact_name` | VARCHAR | Indexed. Exact match lookup key. |
| `artifact_type` | VARCHAR | `TABLE \| KAFKA_TOPIC \| PACKAGE \| SHARED_TYPE \| REST_ENDPOINT \| SERVICE \| EVENT` (ADR-0031) |
| `defining_repo_id` | VARCHAR | Platform repo that defines this artifact |
| `repo_role` | VARCHAR | `platform \| module` — copied from `repositories.repo_role` |
| `definition_summary` | TEXT | Human-readable summary (Tier 3 only — not for exact lookup) |
| `is_current` | BOOLEAN | |

#### `cross_repo_edges`
Cross-repository enrichment links (reference-only; no topology propagation — ADR-0017).

| Column | Type | Notes |
|--------|------|-------|
| `id` | UUID PK | |
| `tenant_id` | VARCHAR | |
| `source_repo_id` | VARCHAR | Module repo |
| `source_file_id` | UUID FK | Specific file in module repo |
| `target_repo_id` | VARCHAR | Platform repo |
| `target_artifact_id` | UUID FK | → `shared_artifacts.id` |
| `edge_type` | VARCHAR | `SHARED_TABLE \| SERVICE_CONTRACT \| FIELD_DEFINITION \| DOMAIN_DOC` |
| `resolution` | VARCHAR | `resolved \| probable \| unresolved_external` |
| `resolved_at` | TIMESTAMP | |
| `is_current` | BOOLEAN | |

#### `service_call_index`
Pre-indexed service call relationships from domain specs (Tier 1-domain). Populated by
`build_contract_registry` from platform API spec repos.

| Column | Type | Notes |
|--------|------|-------|
| `id` | UUID PK | |
| `tenant_id` | VARCHAR | |
| `source_repo_id` | VARCHAR | Repo that contains the calling spec |
| `caller_service` | VARCHAR | Indexed on `caller_service` |
| `callee_service` | VARCHAR | Indexed on `callee_service` |
| `artifact_name` | VARCHAR | Table/field/topic referenced (for cross-linking to `shared_artifacts`) |
| `call_protocol` | VARCHAR | `REST \| MQ \| RPC` |
| `is_current` | BOOLEAN | |

#### `field_extractions`
Domain field definitions from XML field defs, API specs, data dictionaries (Tier 1-domain).
Exact lookup only — never embedded.

| Column | Type | Notes |
|--------|------|-------|
| `id` | UUID PK | |
| `tenant_id` | VARCHAR | |
| `source_repo_id` | VARCHAR | Platform repo that defines this field |
| `field_name` | VARCHAR | Indexed. Exact match. |
| `field_type` | VARCHAR | Typed declaration |
| `max_length` | INT | Nullable |
| `valid_values` | JSONB | Nullable |
| `parent_service` | VARCHAR | Service this field belongs to |
| `parent_table` | VARCHAR | Table this column belongs to (nullable — null for standalone field defs) (ADR-0031) |
| `column_position` | INT | Ordinal position in CREATE TABLE (nullable) (ADR-0031) |
| `description` | TEXT | From COMMENT ON COLUMN or inline comment (nullable) (ADR-0031) |
| `is_current` | BOOLEAN | |

#### `cross_repo_summary`
Materialized repo-level summary for cross-repo ANN acceleration (ADR-0017 Mitigation 3).
Populated by `cross_repo_indexer` worker on `repo.indexed` Kafka event. One row per
repo per tenant. Used as a two-stage ANN pre-filter at 5K+ repos.

| Column | Type | Notes |
|--------|------|-------|
| `id` | UUID PK | |
| `tenant_id` | VARCHAR | |
| `repo_id` | VARCHAR | |
| `repo_role` | VARCHAR | Copied from `repositories.repo_role` at compute time |
| `summary_vector` | VECTOR(384) | Mean of all Layer 3 cluster centroid vectors for this repo |
| `cluster_count` | INT | Number of clusters included in the mean |
| `computed_at` | TIMESTAMP | When this row was last computed |
| `is_current` | BOOLEAN | False if repo has re-indexed since last compute (stale) |

Notes:
- This table is an **acceleration only** — never a dependency. If absent or stale,
  queries fall back to direct `cross_repo__capabilities` ANN without error.
- `summary_vector` is NOT stored in the vector store — it lives here for keyed lookup
  and optional in-process ANN over a small row set (< 50K rows).
- `is_current = false` when a newer `repo.indexed` event has been published but
  `cross_repo_indexer` has not yet processed it. Stale rows are still usable —
  they degrade to slightly less precise repo selection, not an error.

---

### Metadata

#### `repositories`
One row per onboarded repository per tenant.

| Column | Type | Notes |
|--------|------|-------|
| `id` | UUID PK | |
| `tenant_id` | VARCHAR | |
| `repo_id` | VARCHAR | Unique within tenant |
| `repo_name` | VARCHAR | Human-readable |
| `repo_role` | VARCHAR | `platform \| module` — non-nullable; set at onboard time (ADR-0017) |
| `source_type` | VARCHAR | `git \| local` |
| `default_branch` | VARCHAR | |
| `last_indexed_at` | TIMESTAMP | |
| `index_status` | VARCHAR | `pending \| active \| failed` |
| `platform` | VARCHAR NULLABLE | Rule engine `applies_to` pre-filter — ADR-0034, Contract 20 §6.3 |
| `primary_language` | VARCHAR NULLABLE | Rule engine `applies_to` pre-filter — ADR-0034, Contract 20 §6.5 |
| `repo_type` | VARCHAR NULLABLE | Rule engine `applies_to` pre-filter — ADR-0034, Contract 20 §6.4 |

#### `versions`
Commit history and version chain anchors.

| Column | Type | Notes |
|--------|------|-------|
| `id` | UUID PK | |
| `tenant_id` | VARCHAR | |
| `repo_id` | VARCHAR | |
| `commit_sha` | VARCHAR | |
| `branch` | VARCHAR | |
| `committed_at` | TIMESTAMP | |
| `files_changed` | INT | |
| `indexed_at` | TIMESTAMP | |

#### `documents`
Non-code source documents onboarded for Tier 3 knowledge.

| Column | Type | Notes |
|--------|------|-------|
| `id` | UUID PK | |
| `tenant_id` | VARCHAR | |
| `repo_id` | VARCHAR | Repo this doc belongs to (platform or module) |
| `file_path` | VARCHAR | |
| `content_type` | VARCHAR | `docs \| data \| data-sql \| config` |
| `content_hash` | VARCHAR | |
| `is_current` | BOOLEAN | |
| `indexed_at` | TIMESTAMP | |

#### `doc_chunks`
Individual chunks of documents for vector embedding (Layer Docs).

| Column | Type | Notes |
|--------|------|-------|
| `id` | UUID PK | Vector point ID in `__docs` collection |
| `tenant_id` | VARCHAR | |
| `document_id` | UUID FK | → `documents.id` |
| `repo_id` | VARCHAR | Denormalized |
| `chunk_index` | INT | 0-based position within document |
| `chunk_text` | TEXT | Actual text — this is the Tier 3 exception to "no content in DB" (content is too large for vector payload) |
| `token_count` | INT | |
| `is_current` | BOOLEAN | |

#### `indexing_state`
Per-file pipeline progress tracker. Single source of truth for completeness checks.

| Column | Type | Notes |
|--------|------|-------|
| `id` | UUID PK | |
| `tenant_id` | VARCHAR | |
| `repo_id` | VARCHAR | |
| `entity_id` | VARCHAR | File path or document path |
| `content_hash` | VARCHAR | Last seen content hash |
| `behavioral_fingerprint` | VARCHAR | Last seen behavioral fingerprint (Contract 13 §8) |
| `commit_sha` | VARCHAR | |
| `parse_status` | VARCHAR | `pending \| done \| failed` |
| `embed_status` | VARCHAR | `pending \| done \| failed \| stale \| skip_behavioral_unchanged` |
| `index_status` | VARCHAR | `pending \| done \| failed` |
| `updated_at` | TIMESTAMP | |

---

### Security and Auth

#### `tenants`
One row per provisioned tenant. Created by Admin API (ADR-0020).

| Column | Type | Notes |
|--------|------|-------|
| `id` | UUID PK | |
| `tenant_id` | VARCHAR | Unique across system |
| `display_name` | TEXT | |
| `tier` | VARCHAR | `dev \| compose \| enterprise` |
| `created_at` | TIMESTAMP | |
| `purge_at` | TIMESTAMP | NULL = active; set by delete request (ADR-0021) |
| `is_active` | BOOLEAN | |

#### `tenant_config`
Runtime configuration overrides per tenant (ADR-0020). Workers poll on 60 s TTL.

| Column | Type | Notes |
|--------|------|-------|
| `id` | UUID PK | |
| `tenant_id` | VARCHAR | |
| `config_key` | VARCHAR | One of the overridable keys listed in ADR-0020 |
| `config_value` | TEXT | |
| `set_by` | TEXT | Auth subject who set this value |
| `set_at` | TIMESTAMP | |

#### `api_keys`
API key registry. Raw key never stored — only SHA256 hash (ADR-0019).

| Column | Type | Notes |
|--------|------|-------|
| `id` | UUID PK | |
| `tenant_id` | VARCHAR | Key is bound to exactly one tenant |
| `key_hash` | VARCHAR | SHA256(raw_key); unique |
| `label` | TEXT | Human-readable name |
| `scopes` | TEXT[] | `["query", "admin", "ingest"]` |
| `created_at` | TIMESTAMP | |
| `expires_at` | TIMESTAMP | NULL = non-expiring |
| `revoked_at` | TIMESTAMP | NULL = active |
| `last_used_at` | TIMESTAMP | Updated on each successful auth |

#### `query_audit_log`
Append-only log of every authenticated MCP/Admin API call. Subject to retention policy (ADR-0021).

| Column | Type | Notes |
|--------|------|-------|
| `id` | UUID PK | |
| `tenant_id` | VARCHAR | |
| `subject` | TEXT | Auth identity — `user@corp.com` or `apikey:<label>` or `anonymous:dev` |
| `request_id` | VARCHAR | X-Request-Id header |
| `tool` | VARCHAR | MCP tool name or `admin:{endpoint}` |
| `query_text` | TEXT | The caller's natural language query or primary filter value (e.g. function name, table name). Stored for improvement analytics. Callers are informed of this in the FACT envelope `trustworthy.audit_notice` field. |
| `input_summary` | JSONB | Non-sensitive subset of tool arguments (e.g. `{repo_id, tool, query_intent}`). PII fields MUST be omitted. |
| `query_ms` | INT | |
| `result_count` | INT | |
| `timed_out` | BOOLEAN | |
| `called_at` | TIMESTAMP | |

Note: `query_audit_log` is NOT covered by the "no hard deletes" rule (Contract 15 §1). Rows are hard-deleted after `AUDIT_LOG_RETENTION_DAYS` (ADR-0021).

#### `confidence_votes`
Aggregated developer feedback votes per entity (ADR-0024).

| Column | Type | Notes |
|--------|------|-------|
| `id` | UUID PK | |
| `tenant_id` | VARCHAR | |
| `entity_id` | UUID | `file_facts.id` or `function_facts.id` |
| `entity_type` | VARCHAR | `file \| function` |
| `confirm_count` | INT | |
| `deny_count` | INT | |
| `bookmark_count` | INT | |
| `total_votes` | INT | |
| `last_vote_at` | TIMESTAMP | |

Note: votes survive re-indexing unless `version_distance > BEHAVIORAL_CHANGE_THRESHOLD` (ADR-0024 §vote-reset).

#### `import_jobs`
One row per ingestion job triggered via the Admin API or Admin Portal (ADR-0020, ADR-0026). Status transitions written by Kafka workers.

| Column | Type | Notes |
|--------|------|-------|
| `job_id` | UUID PK | |
| `tenant_id` | VARCHAR | |
| `repo_id` | VARCHAR | References `repositories.repo_id` |
| `content_type` | VARCHAR | null = auto-detect; `code \| docs \| config \| data \| data-sql` |
| `fidelity` | VARCHAR | null until set by `parse_repo` worker: `structural \| deep` |
| `source_type` | VARCHAR | `zip_upload \| git` |
| `artifact_path` | TEXT | IArtifactStore path to ZIP (`uploads/{tenant}/{job_id}.zip`); null for git |
| `status` | VARCHAR | `pending \| running \| complete \| failed` |
| `pipeline_state` | JSONB | Per-worker step tracking (ADR-0027). Shape: `{ "parse_repo": { "status": "complete", "file_count": 78 }, "persist_facts": { "status": "running" }, ... }`. Workers patch only their own key via `jsonb_set`. |
| `imported_count` | INT | Net-new items produced |
| `empty_count` | INT | Empty/skipped files |
| `error_message` | TEXT | null on success |
| `started_at` | TIMESTAMP | Set when Admin API creates the row |
| `completed_at` | TIMESTAMP | Set by final worker (batch_embed or document_embedder) |
| `duration_ms` | BIGINT | `completed_at - started_at` in ms |

`import_jobs` rows are retained for `AUDIT_LOG_RETENTION_DAYS` (ADR-0021), then hard-deleted. `DELETE /admin/v1/import-jobs/{job_id}` removes immediately.

#### `worker_lifecycle`
Per-worker lifecycle command table (ADR-0027). Workers poll this on 30 s TTL alongside `tenant_config`.

| Column | Type | Notes |
|--------|------|-------|
| `id` | UUID PK | |
| `worker_name` | VARCHAR | Unique — one active row per worker |
| `command` | VARCHAR | `run \| pause \| drain \| reset_offset` |
| `offset_target` | VARCHAR | Non-null only when `command=reset_offset`: `earliest \| latest \| <ISO timestamp>` |
| `set_by` | TEXT | Auth subject from `query_audit_log` |
| `set_at` | TIMESTAMP | |
| `acknowledged_at` | TIMESTAMP | Set by worker when it reads and applies the command; null = pending |

Default row: `command=run`, inserted at bootstrap for every registered worker. Workers MUST NOT crash on missing row — treat as `run`.

---

## 3. Indexing requirements

The following indexes MUST exist for query performance guarantees:

| Table | Index columns | Type | Reason |
|-------|--------------|------|--------|
| `file_facts` | `(tenant_id, repo_id, is_current)` | Composite | Primary query filter |
| `file_facts` | `(tenant_id, repo_id, file_path)` | Composite | File lookup by path |
| `file_facts` | `(cluster_stable_id, is_current)` | Composite | Cluster-scoped queries |
| `file_tables` | `(tenant_id, table_name, is_current)` | Composite | Shared artifact lookup |
| `function_facts` | `(tenant_id, repo_id, function_name, is_current)` | Composite | Function name search |
| `function_calls` | `(tenant_id, callee_name, is_current)` | Composite | Callers-of lookup |
| `shared_artifacts` | `(tenant_id, artifact_name)` | Composite | Enrichment join key |
| `service_call_index` | `(tenant_id, caller_service)` | Composite | Service dependency lookup |
| `service_call_index` | `(tenant_id, artifact_name)` | Composite | Cross-link lookup |
| `field_extractions` | `(tenant_id, field_name)` | Composite | Exact field lookup |
| `field_extractions` | `(tenant_id, parent_table, is_current)` | Composite | Column-by-table lookup (ADR-0031) |
| `function_table_ops` | `(tenant_id, table_name, is_current)` | Composite | Table operation lookup (ADR-0031) |
| `function_table_ops` | `(tenant_id, function_id, is_current)` | Composite | Function's table operations (ADR-0031) |
| `file_literals` | `(tenant_id, value, is_current)` | Composite | Literal value lookup (ADR-0031) |
| `file_literals` | `(tenant_id, file_fact_id, is_current)` | Composite | Literals per file (ADR-0031) |
| `indexing_state` | `(tenant_id, repo_id, entity_id)` | Unique | Idempotency check |
| `cross_repo_edges` | `(tenant_id, source_repo_id, target_repo_id)` | Composite | Enrichment query |
| `cross_repo_summary` | `(tenant_id, repo_id)` | Unique | Repo-level ANN pre-filter lookup |
| `cross_repo_summary` | `(tenant_id, is_current)` | Composite | Stale-row pre-filter |
| `cluster_assignments` | `(tenant_id, cluster_stable_id, is_current)` | Composite | Cluster membership lookup; used by `cluster_centroids` and `enrich` step |
| `coverage_gap_counts` | `(tenant_id, extension)` | Unique | Aggregator upsert key |
| `api_keys` | `(key_hash)` | Unique | Auth validation — O(1) key lookup |
| `api_keys` | `(tenant_id, revoked_at)` | Composite | List active keys per tenant |
| `query_audit_log` | `(tenant_id, called_at)` | Composite | Audit queries by tenant and time |
| `query_audit_log` | `(subject, called_at)` | Composite | GDPR erasure — find all rows by subject |
| `confidence_votes` | `(tenant_id, entity_id)` | Unique | Vote upsert key |
| `tenant_config` | `(tenant_id, config_key)` | Unique | Config lookup by key |
| `import_jobs` | `(tenant_id, started_at DESC)` | Composite | Import Jobs page pagination |
| `import_jobs` | `(repo_id, status)` | Composite | Worker status transition lookups |
| `worker_lifecycle` | `(worker_name)` | Unique | Worker polls by name; one active row per worker |
| `semantic_annotations` | `(tenant_id, repo_id, target_type, target_id, rule_id) WHERE is_current = true` | Partial unique | Idempotent re-run support (ADR-0034) |
| `semantic_annotations` | `(tenant_id, repo_id, is_current)` | Composite | Repo-level annotation query (ADR-0034) |
| `repositories` | `(tenant_id, platform)` | Composite | Rule engine `applies_to` pre-filter |

---

### Semantic Rule Engine

#### `semantic_annotations`
One row per annotated fact per rule. Written by `semantic_interpreter` worker (SPEC-0010, ADR-0034). Supports idempotent re-annotation via version-chain pattern.

| Column | Type | Notes |
|--------|------|-------|
| `id` | UUID PK | |
| `tenant_id` | VARCHAR | |
| `repo_id` | VARCHAR | |
| `target_type` | VARCHAR | `function_facts \| file_facts \| file_tables` — the source table containing the annotated row |
| `target_id` | UUID | `id` of the row in `target_type` table |
| `rule_id` | VARCHAR | Identifies the rule that produced this annotation |
| `rule_version` | VARCHAR | Tracks rule file version for change-scoped re-annotation (ADR-0034) |
| `platform` | VARCHAR NULLABLE | `annotate.platform` output from the matched rule |
| `type` | VARCHAR NULLABLE | `annotate.type` output; reserved values: `service_handler \| pipeline_stage \| shared_table_group \| entry_point \| utility \| unknown` |
| `group` | VARCHAR NULLABLE | `annotate.group` output; capture-group substitution applied |
| `role` | VARCHAR NULLABLE | `annotate.role` output |
| `domain` | VARCHAR NULLABLE | `annotate.domain` output |
| `confidence` | FLOAT | Copied from the matched rule's `confidence` field (0.0–1.0) |
| `is_current` | BOOLEAN | `true` for the authoritative row; `false` for superseded rows (version-chain pattern, Contract 15 §1 Rules 1+4) |
| `annotated_at` | TIMESTAMP | UTC timestamp when this annotation was written |

Unique constraint: `(tenant_id, repo_id, target_type, target_id, rule_id) WHERE is_current = true` — enforces one live annotation per fact per rule.

**Note:** `semantic_annotations` rows are NOT hard-deleted. Superseded rows have `is_current = false`. Subject to data lifecycle retention (ADR-0021).

---

## 4. Partition strategy (Tier 2 `compose` and Tier 3 `enterprise`)

| Table | Partition key | Reason |
|-------|--------------|--------|
| `file_facts` | `tenant_id` | Tenant isolation |
| `function_facts` | `tenant_id` | Tenant isolation |
| `topology_edges` | `(tenant_id, repo_id)` | Graph traversal scoped per repo |
| `indexing_state` | `tenant_id` | Completeness check scoped per tenant |
| `doc_chunks` | `tenant_id` | Volume control |
| `function_table_ops` | `tenant_id` | Tenant isolation (ADR-0031) |
| `file_literals` | `tenant_id` | Tenant isolation (ADR-0031) |

Tier 1 `dev` (SQLite): no partitioning — single-file DB.

---

## 5. Migration rules

1. Every schema change requires a numbered Alembic migration file.
2. Migrations MUST be reversible — every `upgrade()` has a corresponding `downgrade()`.
3. Adding a nullable column to an existing table: allowed without ADR.
4. Adding a non-nullable column, dropping a column, changing a column type: requires an ADR first.
5. Adding a new table: requires an ADR or explicit section in an existing ADR.
6. Renaming a table or column: requires an ADR and a two-step migration (add new → backfill → drop old).
