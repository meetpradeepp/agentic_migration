# Contract 08 — Language Pack Contract

**Scope:** Every language pack under `language_packs/`.  
**Enforced by:** `LanguagePackRegistry` loader validation at startup, `eval_schema_conformance` (every PR).  
**Status:** Active  
**Related:** `schemas/language-pack-manifest.schema.yaml`, `schemas/facts-base-schema.json`, ADR-0002, ADR-0012

---

## 1. What a language pack is

A language pack is a **self-contained folder** under `language_packs/<language_id>/`.
It encapsulates everything needed to parse one language family and produce a valid `facts.json`.

A language pack has **two independent extension points:**

| Extension point | What you add | When to use |
|---|---|---|
| **New language** | A new `language_packs/<language_id>/` folder | A file type has no pack yet (e.g. adding COBOL support) |
| **New framework / dialect** | A `detection_rules/<framework_id>.yaml` inside an existing pack | A framework shares an extension with its host language (e.g. Angular inside TypeScript) |

**Adding a new language** = drop a new folder + hot-reload (watchdog picks it up; no restart required).  
**Adding a new framework rule** = drop a `.yaml` file in `detection_rules/` + hot-reload.  
**No changes to `parse_repo`, `persist_facts`, `build_graph`, or any other worker in either case.**  
This is the Open/Closed principle applied at both the language layer and the framework layer.

---

## 2. Required folder structure

```
language_packs/
  <language_id>/
    manifest.yaml          REQUIRED — machine contract for the registry loader
    fast_extractor.py      REQUIRED — tree-sitter extraction (primary path); must export extract()
    schema.py              REQUIRED — Pydantic model extending CanonicalFactFileBase
    extractor.sc           OPTIONAL — legacy Joern CPG extraction script (reference/fallback only)
    sanitizer.py           OPTIONAL — pre-processing before parsing
    extractors/            OPTIONAL — FSS semantic sub-extractors (see §10)
      data_access.py       OPTIONAL — FSS slot: DB reads/writes/transactions
      entry_points.py      OPTIONAL — FSS slot: entry point classification
      conditionals.py      OPTIONAL — FSS slot: branch/control-flow analysis
      temporal.py          OPTIONAL — FSS slot: time-dependent operations
      termination.py       OPTIONAL — FSS slot: return/exit path analysis
      side_effects.py      OPTIONAL — FSS slot: I/O, global state mutations
      external_calls.py    OPTIONAL — FSS slot: DLL/service/API call detection
    detection_rules/       OPTIONAL — framework/dialect detection rules (see §9)
      <framework_id>.yaml  one file per detectable framework or dialect
```

If `manifest.yaml` or `fast_extractor.py` is absent, the registry loader raises
`InvalidLanguagePackError` at startup — the worker will not start. Fail-fast, not silent.

---

## 3. `manifest.yaml` contract

See `schemas/language-pack-manifest.schema.yaml` for the full JSON Schema.
Required fields match AMF manifest structure. Additional optional fields documented inline:

```yaml
metadata:
  language_id: "powerbuilder"   # registry key; snake_case; unique across all packs
  name: "PowerBuilder"          # human-readable label
  version: "1.0"                # semver; bump on any breaking change
  family: "4gl"                 # oo | 4gl | scripting | system | document | config | image

extensions:
  source: [".srw", ".sru", ".srf", ".srm", ".srs", ".srd"]  # registry lookup keys
  binary: [".pbl"]              # informational; not processed

# fact_extraction — describes the Joern extractor.sc reference (legacy, eval-only)
fact_extraction:
  script: "extractor.sc"        # path to Joern extraction script; retained for eval/fallback
  schema_class: "CanonicalFactFilePowerBuilder"  # Pydantic class in schema.py
  parser_id: "powerscript"      # joern | powerscript | proc — Joern --language flag
  capabilities:                 # categories Joern extracts at full/partial depth
    - sql_embedded
    - cursor_operations
    - gui_events
    - datawindow_objects
    - external_calls
    - entry_points
    - control_flow
  joern_fallback: false         # true = allow Joern fallback on fast_extractor failure (default: false)

# fast_extraction — describes the tree-sitter extractor (primary path in ECLE 2.0)
fast_extraction:
  enabled: true                 # false = DefaultPack text extraction only
  grammar: "tree-sitter-powerbuilder"   # pip package name; null if no grammar
  extractor: "fast_extractor.py"        # relative path to the primary extractor module
  fidelity: "FULL"              # FULL | PARTIAL | HEURISTIC — propagates to confidence ceiling

registry:
  priority: 0                   # higher number wins when two packs claim the same extension; default 0

preprocessing:
  enabled: true
  sanitizer: "sanitizer.py"    # relative path; omit or false to skip
  rules:
    strip_bom: true
    normalize_line_endings: true
    fix_encoding: "utf-8"
    custom: []                  # list of named transform functions in sanitizer.py
```

**Key differences from earlier ECLE 2.0 drafts:**
- `fast_extraction.fidelity` is the correct location for the fidelity value (not a top-level field).
- `fast_extraction.extractor` replaces any prior `fast_extraction.grammar` field. Both grammar and extractor are present.
- `fact_extraction.capabilities[]` is a list of capability strings, not a nested `extraction_depth` map.
- `fact_extraction.script` points to `extractor.sc`; it is NOT invoked at runtime (see §11).
- `fact_extraction.parser_id` drives the Joern `--language` flag used in CI eval only.

---

## 4. `fast_extractor.py` interface contract

Every pack MUST export exactly this function signature. No exceptions.

```python
def extract(
    tree_or_bytes: Any,          # tree_sitter.Tree if grammar enabled; raw bytes if text-only
    source_bytes: bytes,         # always provided; use for text operations
    file_path: Path,             # original file path for context
    language_dir: Path,          # this pack's directory (for loading resources)
    detected_layers: list[DetectedLayer] = [],  # from Pass 1 content heuristics (ADR-0012)
) -> dict[str, Any]:
    """
    Extract facts from source and return a dict conforming to CanonicalFactFileBase
    plus any language-specific extension fields declared in schema.py.

    Contract:
    - MUST always return a valid dict — NEVER raise an exception.
    - Errors go in the top-level 'extraction_errors' list field.
    - The returned dict MUST include at minimum all base schema required fields.
    - 'fidelity' MUST match the value declared in manifest.yaml fast_extraction.fidelity.
    - 'used_fallback' MUST be False for all packs except DefaultPack.
    - 'detected_layers' MUST be passed through to the output dict unchanged.
    - For multi-layer files, fidelity ceiling = min(fidelity_ceiling for each extracted layer).
    """
```

### Never-raise rule

`fast_extractor.extract()` MUST NOT raise under any circumstance.
If parsing fails partially, return what was extracted with `extraction_errors` populated.
One bad file must not crash the `parse_repo` worker.

```python
# CORRECT — never raises, records errors
def extract(tree_or_bytes, source_bytes, file_path, language_dir):
    result = empty_fact_file(str(file_path), "powerbuilder")
    try:
        _extract_functions(tree_or_bytes, source_bytes, result)
    except Exception as exc:
        result["extraction_errors"].append(f"function extraction failed: {exc}")
    return result

# WRONG — can crash the worker
def extract(tree_or_bytes, source_bytes, file_path, language_dir):
    return _extract_functions(tree_or_bytes, source_bytes)  # may raise
```

---

## 5. `schema.py` contract

Every pack MUST declare a Pydantic model extending `CanonicalFactFileBase`.
Language-specific fields are added here — never by modifying the base schema.

```python
# CORRECT — extends the base
from ecle.language_packs.common.facts_schema import CanonicalFactFileBase

class CanonicalFactFilePowerBuilder(CanonicalFactFileBase):
    datawindow_tables: list[DataWindowTable] = []
    external_functions: list[ExternalFunction] = []
    menu_items: list[dict] = []
    external_service_calls: list[dict] = []

# WRONG — modifies the base schema directly (breaks all other packs)
# Do not add PB fields to CanonicalFactFileBase
```

---

## 6. Fidelity values and their meaning

| Fidelity | When to use | Confidence ceiling |
|---|---|---|
| `FULL` | tree-sitter grammar with complete semantic extraction | 1.0 |
| `PARTIAL` | grammar exists but some constructs cannot be extracted | 0.8 |
| `HEURISTIC` | text/OCR extraction — structure inferred, not parsed | 0.6 |

DefaultPack always uses `HEURISTIC` and sets `used_fallback: true` on the event.
`used_fallback: true` lowers the ceiling further to 0.5.

---

## 7. DefaultPack — the always-succeeds fallback

`language_packs/default/` is the safety net for unrecognised files.
The registry returns DefaultPack whenever no other pack matches the file extension.

DefaultPack:
- Tokenises raw UTF-8 text (best-effort encoding recovery).
- Extracts: `raw_text_excerpt` (first 2000 chars), `line_count`, `token_count`.
- Sets `fidelity: HEURISTIC`, `used_fallback: true`.
- Returns a valid `CanonicalFactFileBase` — never raises.

**DefaultPack MUST NOT be replaced or removed.** It guarantees the pipeline never crashes
on an unknown file type. Files processed by DefaultPack are still indexed — they just
carry lower confidence and are clearly flagged.

---

## 8. Adding a new language — checklist

1. Create `language_packs/<language_id>/`
2. Write `manifest.yaml` — set `language_id`, `extensions.source`, `fast_extraction.fidelity`, `fast_extraction.grammar`, `fact_extraction.capabilities`
3. Install tree-sitter grammar: `pip install tree-sitter-<language>`
4. Write `fast_extractor.py` — implement `extract()` with the never-raise contract; use `common.schema_builder.empty_fact_file()` as the base dict factory; handle `detected_layers` parameter
5. Write `schema.py` — extend `CanonicalFactFileBase` with language-specific fields
6. Optionally write `sanitizer.py` if encoding/transform pre-processing is needed
7. Optionally create `extractors/<slot_name>.py` for any FSS sub-extractor slots your language needs (see §10)
8. Optionally create `detection_rules/<framework_id>.yaml` for each framework the language hosts (see §9)
9. Retain or port `extractor.sc` from AMF for use by `eval_fidelity_ceiling` (see §11)
10. Write unit tests: `tests/unit/language_packs/test_<language_id>_extractor.py`
11. Run `eval_schema_conformance` on a fixture file from the new language
12. Run `eval_fast_extractor_coverage` to verify all `fact_extraction.capabilities` are actually produced
13. Open a PR referencing the language pack spec (`specs/phase-N/SPEC-NNN-<language>-pack.md`)
14. Restart `parse_repo` workers — registry auto-discovers the new pack

---

## 9. Detection rules — framework and dialect detection (ADR-0012)

A language pack may include a `detection_rules/` subdirectory containing one `.yaml` file per detectable framework or dialect. These are used by Pass 1 content heuristics (run before `extract()`) to identify frameworks co-present in a file.

**Detection rule format:**

```yaml
# language_packs/typescript/detection_rules/angular.yaml
framework_id: "angular"
ontology: "ontologies/angular.yaml"    # loaded by ontology_enricher if this layer is detected
grammar: "tree-sitter-angular"         # OPTIONAL — sub-grammar for framework-specific syntax
grammar_scope: "inline_template"       # OPTIONAL — full_file | inline_template | byte_range | null
confidence: 0.9                        # base confidence when ALL required patterns match
patterns:
  required:                            # ALL must match to trigger detection
    - pattern: "@Component"
      type: string
    - pattern: "@NgModule|@Injectable|@Directive|@Pipe"
      type: regex
  supporting:                          # each match adds (1.0 - base_confidence) / len(supporting)
    - pattern: "from '@angular/core'"
      type: string
    - pattern: "from '@angular/common'"
      type: string
```

**`grammar` and `grammar_scope` fields:**

When a framework has its own syntax that the primary language grammar cannot parse (e.g. Angular inline templates inside `.ts`/`.js` files), the detection rule declares a sub-grammar:

| `grammar_scope` value | What bytes are passed to the sub-grammar |
|---|---|
| `full_file` | Entire file bytes — for hybrid files (e.g. `.svelte`, `.vue`) |
| `inline_template` | String literal values whose variable name matches `template:` |
| `byte_range` | The `byte_range` from the `DetectedLayer` — explicit range located by Pass 1 patterns |
| absent / `null` | No sub-grammar — detection and ontology enrichment only; no additional parsing |

Both fields are **optional**. A rule without `grammar` is valid — it contributes `detected_layers[]` and ontology loading but no additional parse tree.

**Sub-grammar conflict rule:** if two detection rules both declare `grammar` targeting overlapping byte ranges, the **higher-confidence rule's grammar wins** for that range. The lower-confidence rule still fires for ontology enrichment — it does not get a separate parse.

**Rules:**
- `required` patterns: ALL must match for the framework to be detected. If any required pattern is absent, the rule does not fire.
- `supporting` patterns: each match incrementally raises `detection_confidence` toward 1.0.
- Pattern `type: string` = substring match; `type: regex` = compiled regex search over raw source bytes.
- Detection rules MUST NOT import Python or run any code — they are declarative YAML only.
- Framework ontology files live in `ontologies/` (repo root), not inside the language pack — they are shared across languages (e.g., RxJS patterns apply to both TypeScript and JavaScript packs).

**Output written to facts.json:**

```json
"detected_layers": [
  {
    "layer_type": "framework",
    "id": "angular",
    "ontology_file": "ontologies/angular.yaml",
    "grammar": "tree-sitter-angular",
    "grammar_scope": "inline_template",
    "detection_confidence": 0.95,
    "evidence": ["@Component", "from '@angular/core'"]
  }
]
```

`detected_layers` is a required field on every `facts.json` IR artifact. Empty array (`[]`) if no frameworks detected — never absent.

See ADR-0012 for the full three-pass detection model, multi-level extraction, and embedded language handling.

---

## 10. FSS semantic sub-extractors (`extractors/` folder)

The `extractors/` subdirectory is the **Functional Semantic Segmentation (FSS)** sub-extractor system. It is **optional** but strongly recommended for any language that has complex DB access, service calls, or lifecycle patterns (PowerBuilder, Pro*C, C/C++, Java).

### Sub-extractor slot names

The slot names are fixed by `BaseLanguage.EXTRACTOR_NAMES`. ECLE 2.0 packs MUST use these exact names — no custom names. The registry discovers sub-extractors by scanning these exact filenames in `extractors/`:

| Slot name | File | Produces |
|-----------|------|----------|
| `data_access` | `extractors/data_access.py` | SQL DML operations, DB read/write, transaction events |
| `entry_points` | `extractors/entry_points.py` | Entry point list with `entry_point_type` classification |
| `conditionals` | `extractors/conditionals.py` | Branch/if/switch/loop analysis |
| `temporal` | `extractors/temporal.py` | Time-dependent operations (timers, date functions, scheduling) |
| `termination` | `extractors/termination.py` | Return/exit path analysis per function |
| `side_effects` | `extractors/side_effects.py` | I/O, global variable writes, state mutations |
| `external_calls` | `extractors/external_calls.py` | DLL, SOAP, HTTP, COM calls |

### How sub-extractors are invoked

`fast_extractor.py` calls `BaseLanguage.run_extractors()` after its own tree-sitter pass. Each sub-extractor module is imported dynamically by slot name and its `extract(facts_dict, tree, source_bytes)` function is called in slot order. Sub-extractors **post-process and annotate** the facts dict — they do not produce a new dict.

```python
# CORRECT — sub-extractor pattern
def extract(facts_dict: dict, tree, source_bytes: bytes) -> None:
    """Post-process facts_dict in-place. Do not return a new dict."""
    for func in facts_dict["functions"]:
        # ... annotate with entry_point_type etc.
    facts_dict["entry_points"].extend(detected_entry_points)
```

Sub-extractors MUST NOT raise. Exceptions are caught by `run_extractors()` and appended to `facts_dict["extraction_errors"]`.

### Pro*C exception — no `external_calls.py`

Pro*C does not have `external_calls.py` because external call detection for `.pc` files is handled entirely by the C-family shared extractor (`common/c_family_extractors.py`). The `data_access` slot handles all embedded SQL and cursor operations. This matches the AMF Pro*C pack structure.

---

## 11. Dual-parser contract — tree-sitter primary, Joern reference

Every ECLE 2.0 language pack operates on a **dual-parser model**:

| Parser | File | Role | Invoked in pipeline? |
|--------|------|------|---------------------|
| **tree-sitter** | `fast_extractor.py` | **Primary** — runs on every file in every repo ingestion | ✅ Yes (always) |
| **Joern CPG** | `extractor.sc` | Reference / fallback only | ❌ No (CI eval only unless `EXTRACTION_JOERN_FALLBACK=true`) |

**Both MUST produce schema-conformant output** against `facts-base-schema.json` v2.1.
This is verified by `eval_schema_conformance` for `fast_extractor.py` and by
`eval_fidelity_ceiling` for `extractor.sc`.

**`EXTRACTION_JOERN_FALLBACK`** (env var, default `false`):
- If `true`, the `parse_repo` worker will invoke `extractor.sc` as a fallback when
  `fast_extractor.extract()` raises an unhandled exception (should never happen —
  see §4 never-raise rule).
- NEVER set to `true` in Tier 2 (`compose`) or Tier 3 (`enterprise`) deployments.
- Only for debugging in Tier 1 (`dev`) after a grammar regression.

**Joern is NOT in `requirements.txt`.** It is in `requirements-dev.txt`. The runtime
pipeline has zero dependency on Joern being installed.

**Evaluation gates enforcing this contract:**

| Gate | What it checks | Triggered by |
|------|---------------|-------------|
| `eval_schema_conformance` | `fast_extractor.py` output validates against `facts-base-schema.json` v2.1 for all fixture files | Every PR that touches a language pack |
| `eval_fast_extractor_coverage` | All `fact_extraction.capabilities[]` declared in `manifest.yaml` are actually present in the output facts | Every PR that touches a language pack |
| `eval_fidelity_ceiling` | tree-sitter precision ≥ 0.95, recall ≥ 0.90 vs Joern reference for `full` categories | Language pack graduation PR (see ADR-0016 §Joern migration) |
