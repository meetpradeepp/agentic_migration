# Contract 13 — Incremental Ingestion Contract

**Scope:** The `parse_repo`, `persist_facts`, and `batch_embed` workers.  
**Enforced by:** `eval_idempotent_ingest` (every PR), `indexing_state` table audit.  
**Status:** Active  
**Related:** ADR-0001, ADR-0007

---

## 1. The guarantee

**ECLE MUST NOT re-process a file whose content has not changed.**

Ingestion is O(changed_files), not O(corpus). On a commit that touches 3 files in a
10K-file repo, only those 3 files flow through the full pipeline. The other 9,997 files
are skipped at the earliest possible check.

---

## 2. Change detection — `content_hash`

The canonical change signal is:

```
content_hash = SHA256(file_bytes)
```

A file has changed if and only if its `content_hash` differs from the value stored in
`indexing_state` for the same `(repo_id, entity_id)`.

**Rules:**
- `content_hash` is computed from raw bytes before sanitization — sanitization is idempotent, so the hash is still stable.
- `content_hash` is carried in the `file.ir_produced` event payload.
- Workers MUST check `indexing_state` before processing — if hash matches and status is `done`, skip.

---

## 3. Skip rules per worker

| Worker | Skip condition |
|--------|---------------|
| `parse_repo` | Phase 2+: `indexing_state.content_hash == current_hash` AND `parse_status == 'done'` → skip file, do not write artifact, do not emit `file.ir_produced` |
| `persist_facts` | `indexing_state.content_hash == event.content_hash` AND `parse_status == 'done'` → `ack()` immediately; no DB writes |
| `batch_embed` | `embed_idempotency_key` exists in `indexing_state` AND `embed_status == 'done'` → skip; no embedding; no upsert |

**Phase 1 note:** `parse_repo` does NOT implement the skip check in Phase 1 — it always
re-parses. The check is added in Phase 2 when incremental git ingestion is implemented.
`persist_facts` and `batch_embed` MUST implement their skip checks from Phase 1.

---

## 4. Neighbourhood hash — `contextual_accuracy` staleness detection

`contextual_accuracy` (per `05-confidence-contract.md`) degrades when a file's
**neighbours** change, even if the file itself did not change.

To detect this without scanning all neighbours on every query, each `file_facts` row
stores a `neighbourhood_hash`:

```
neighbourhood_hash = SHA256(
    sorted([
        (neighbour_file_id, neighbour_content_hash)
        for neighbour in files_within_2_hops(file_id)
    ])
)
```

When a neighbouring file is re-indexed: `compute_topology` worker recomputes
`neighbourhood_hash` for all files within 2 hops of the changed file and updates
`contextual_accuracy` accordingly.

**Rules:**
- `neighbourhood_hash` is stored in `file_facts.neighbourhood_hash` (nullable; null = not yet computed).
- If `neighbourhood_hash` is null: `contextual_accuracy = 1.0` (assume fresh until proven otherwise).
- `neighbourhood_hash` is computed by `compute_topology` after `graph.updated`, not by `persist_facts`.

---

## 5. `indexing_state` — the canonical status tracker

Every file that has been seen by the pipeline MUST have a row in `indexing_state`.
Workers update this table as they process files. The table is the single source of truth
for pipeline progress and completeness (used for FACT coverage warnings).

```sql
-- Key columns and their lifecycle
parse_status:   'pending' → 'done' | 'failed'   (set by persist_facts)
embed_status:   'pending' → 'done' | 'failed' | 'stale'  (set by batch_embed)
index_status:   'pending' → 'done' | 'failed'   (set when topology + embed both done)
```

**Rules:**
- `parse_repo` inserts the initial row with `parse_status='pending'` when it emits `file.ir_produced`.
- `persist_facts` updates `parse_status='done'` on successful DB write.
- `batch_embed` updates `embed_status='done'` on successful vector upsert.
- No worker deletes rows from `indexing_state` — rows are updated, never removed (history preserved).
- On re-ingestion of a changed file: update existing row (`content_hash`, `commit_sha`, reset statuses to `pending`).

---

## 6. Cascade staleness prevention

When file A changes and file B depends on A (within 2 hops in the graph):
- B's `contextual_accuracy` drops immediately (neighbourhood_hash mismatch).
- B is queued for `neighbourhood_hash` recompute — NOT for full re-parse.
- B's `parse_status` remains `done` — its facts have not changed.
- Only B's `contextual_accuracy` dimension degrades; `syntactic_freshness` and `behavioral_accuracy` remain stable.

This is the ECLE answer to cascade staleness: **never re-parse a file because its neighbour changed**. Degrade the affected confidence dimension and declare it in the FACT envelope. The file itself is still fresh.

---

## 7. Banned behaviours

| Banned | Reason |
|--------|--------|
| Re-parsing a file with unchanged `content_hash` | Wastes compute; violates O(changed_files) guarantee |
| Marking a file `parse_status='pending'` without inserting an `indexing_state` row first | Worker will not know the file exists; completeness check will miss it |
| Deleting `indexing_state` rows | History lost; completeness check breaks |
| Computing `neighbourhood_hash` inside `persist_facts` | Graph not yet built at persist time; `compute_topology` owns this |
| Treating `contextual_accuracy < 1.0` as a re-parse trigger | Only re-parse when `content_hash` changes; neighbour changes degrade confidence, not facts |

---

## 8. Behavioral fingerprint gate

**Purpose:** After `content_hash` changes and the IR is re-extracted, a significant
fraction of changes are cosmetic (comments, whitespace, formatting). If the structural
facts are identical, re-embedding provides zero signal and wastes ~70% of embedding compute.

**Behavioral fingerprint definition:**

```
behavioral_fingerprint = SHA256(
    sorted([
        *[f"{fn.name}({','.join(fn.param_types)}) -> {fn.return_type}" for fn in functions],
        *[f"{sql.table}:{sql.operation}" for sql in sql_statements],
        *[f"{call.caller}->{call.callee}:{call.call_type}" for call in call_edges],
        *[imp.imported_path for imp in imports]
    ])
)
```

This fingerprint captures structural identity — what the file does and who it talks to.
It is insensitive to whitespace, comments, variable renames that do not change signatures,
and line number shifts.

**Gate rules:**

| Condition | Action |
|-----------|--------|
| `content_hash` changed AND `behavioral_fingerprint` unchanged | Skip re-embedding. Set `embed_status = 'skip_behavioral_unchanged'`. Update `content_hash` in `indexing_state`. |
| `content_hash` changed AND `behavioral_fingerprint` changed | Proceed to re-embedding. Compute `version_distance`. |
| `content_hash` unchanged | Skip entirely (§3 content_hash skip rule — gate not reached). |

**`version_distance` — measuring how much behavior changed:**

```
version_distance = cosine_distance(
    behavioral_fingerprint_vector(new_facts),
    behavioral_fingerprint_vector(prev_facts)
)
```

Where the behavioral fingerprint vector is a compact structural feature vector (function
count, SQL read/write counts, call edge count, import count, cyclomatic complexity sum).
`version_distance` is stored in `file_facts.version_distance` for the new version row.

**Version distance thresholds — what they trigger:**

| Threshold | Classification | Consequence |
|-----------|---------------|-------------|
| `version_distance < 0.05` | Cosmetic change (comments, whitespace, docstring edits) | Re-embed only the changed file. Skip neighbor context recompute entirely. |
| `0.05 ≤ version_distance ≤ 0.10` | Minor structural change | Re-embed the changed file. No neighbor context recompute triggered. |
| `version_distance > 0.10` | Behavioral change (new function, changed call edges, new SQL writes) | Re-embed the changed file. Queue neighbor context recompute (§9). |

These thresholds are stored as `BEHAVIORAL_CHANGE_THRESHOLD = 0.10` and
`COSMETIC_CHANGE_THRESHOLD = 0.05` in deployment config.

**`behavioral_fingerprint` lifecycle:**

- Stored in `indexing_state.behavioral_fingerprint` (nullable; null = not yet computed or Phase 1).
- Written by `persist_facts` after successful IR extraction.
- Gate is implemented from **Phase 2** onward. In Phase 1, `persist_facts` computes and stores
  the fingerprint but does NOT skip re-embedding — the skip logic activates in Phase 2.

---

## 9. Neighbor propagation bounds

**Purpose:** When a file's `version_distance > 0.10` (behavioral change, §8), its
neighbors' `contextual_accuracy` must be recomputed. Without bounds, a single change in
a high-degree file triggers unbounded cascade work.

**Propagation rules:**

| Rule | Value | Reason |
|------|-------|--------|
| Minimum edge weight to propagate | `weight ≥ 2.0` | Only strong structural dependencies (FUNCTION_CALL=3.0, WRITE_READ=2.5, EXECUTION_SEQUENCE=2.0, STATE_FLOW=2.0) warrant neighbor recompute. Weak edges (IMPORT=0.5, SHARED_TYPE=1.0) do not. |
| Maximum hop depth | 2 hops | Beyond 2 hops, transitive impact drops below meaningful threshold. |
| Maximum files per propagation run | 50 files | Hard cap. If bounded traversal finds > 50 candidates, take the 50 with the highest edge weights. |
| Hub exemption | Files where `file_facts.centrality ≥ CLUSTER_HUB_THRESHOLD` (top 10% by centrality within cluster) | Hub files are referenced by too many files to safely recompute. They receive `contextual_accuracy_note = 'hub_exempt'` instead of a recomputed value. |
| Repo boundary | Propagation NEVER crosses repo boundaries | ADR-0017: cross-repo edges are reference-only. A module file changing does not trigger neighbor recompute in a platform repo, and vice versa. |

**Propagation trigger decision tree:**

```
file changed
    │
    ├── version_distance < 0.05 → NO propagation (cosmetic)
    ├── 0.05 ≤ version_distance ≤ 0.10 → NO propagation (minor structural)
    └── version_distance > 0.10 → propagation
            │
            ├── collect neighbors: edges with weight ≥ 2.0, max 2 hops, same repo_id
            ├── exclude hub files (centrality ≥ CLUSTER_HUB_THRESHOLD)
            ├── cap at 50 files (by edge weight descending)
            ├── for each candidate: recompute neighbourhood_hash (§4)
            └── for hub-exempt files: set contextual_accuracy_note = 'hub_exempt'
```

**Configuration constants:**

| Constant | Default |
|----------|---------|
| `PROPAGATION_MIN_EDGE_WEIGHT` | `2.0` |
| `PROPAGATION_MAX_HOPS` | `2` |
| `PROPAGATION_MAX_FILES` | `50` |
| `CLUSTER_HUB_THRESHOLD` | Top 10% by `file_facts.centrality` within cluster |

**Banned propagation behaviours:**

| Banned | Reason |
|--------|--------|
| Propagating on cosmetic changes (`version_distance < 0.05`) | Wastes compute; cosmetic changes do not affect neighbor context |
| Propagating across repo boundaries | ADR-0017 structural rule; cross-repo edges are reference-only |
| Propagating to hub-exempt files as a full recompute | Would trigger secondary cascades from the hub's own large neighborhood |
| Uncapped traversal | Without the 50-file cap, a change to a central file causes O(cluster_size) recomputes |

---

## 10. References

| # | Citation | Relevance |
|---|----------|----------|
| R1 | Acar, U.A. "Self-Adjusting Computation", PhD thesis CMU 2005 | Dependency graph invalidation: recompute only what changed. ECLE's content_hash + neighbourhood_hash is an application of this theory |
| R2 | Hohpe, G. & Woolf, B. "Enterprise Integration Patterns", Addison-Wesley 2003 — Idempotent Receiver | Idempotent processing ensures safe retry; ECLE's content_hash skip rule (§3) is the idempotent receiver pattern |
| R3 | Quinlan, S. & Dorward, S. "Venti: A New Approach to Archival Storage", FAST 2002 | Content-addressable storage using SHA-256 fingerprints; validates ECLE's content_hash as the primary change detection mechanism |
| R4 | GraphBolt: Mariappan, M. & Vora, K. "Dependency-Driven Synchronous Processing of Streaming Graphs", EuroSys 2019 | Incremental graph processing with dependency tracking; validates neighbourhood context propagation (§9) and bounded traversal |
