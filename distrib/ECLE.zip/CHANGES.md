# ECLE 2.0 — Change Registry

All changes to ECLE 2.0 are tracked here. Each entry references the spec it implements.
Entries are appended — never modified or deleted.

Format: `[SPEC-NNNN] Title — Date`

---

[SPEC-0011] Deterministic Naming Enforcement — 2026-05-14
- Implemented deterministic ECLE001 naming gate: AST-only checker that flags one-letter and denylist business variables in non-trivial scopes, with allow-list guards (tiny loop index, math-only notation, unpack throwaway).
- CLI runner (`scripts/run_naming_gate.py`) supports `--mode ci|local`, `--report`, `--paths`; exits 0 (clean), 1 (findings), 2 (error).
- Pre-commit hook `ecle001-naming-gate` wired in `.pre-commit-config.yaml` for local parity with CI Stage 1.
- Verified evidence: 16 unit/integration tests pass (T1–T16 + T13-CLI); 1 skipped (T12, Windows permission — runs in CI). All AC-1–AC-11 covered.
- **Type:** feat(linting) — Phase 1
- **Spec:** specs/phase-1/SPEC-0011-deterministic-naming-enforcement.md
- **Files changed:**
  - `src/ecle/linting/__init__.py` — package marker
  - `src/ecle/linting/naming_checker.py` — `NamingChecker`, `ScopeMetrics`, `NamingFinding`
  - `scripts/run_naming_gate.py` — CLI entrypoint
  - `tests/unit/test_naming_checker.py` — 10 unit tests (T1–T7, T11, T13, T16)
  - `tests/integration/test_naming_gate_ci_stage1.py` — 7 integration tests (T8–T10, T12–T15 + T13-CLI)
  - `.pre-commit-config.yaml` — `ecle001-naming-gate` hook
- **Constitution impact:** None — no new events, DB tables, or schemas.

[SPEC-0008] Kafka WorkerBase + Topic Registry — 2026-05-14
- Completed WorkerBase lifecycle, retry/DLQ flow, topic registry utilities, and integration hardening for real Kafka + PostgreSQL local validation.
- Verified evidence: unit and integration suites passing for WorkerBase and topic registry.

[SPEC-0009] Structured DB DDL + Concrete Backends — 2026-05-14
- Completed PostgreSQL structured backend, local artifact store, backend factories, and Alembic Phase 1 schema migration.
- Verified evidence: migration and PostgreSQL integration suites passing; Alembic invocation standardized to executable path for environment reliability.

[SPEC-0010] Semantic Interpreter Worker — 2026-05-14
- Completed rule schema/loader/evaluator/worker implementation and semantic annotation integration tests.
- Verified evidence: SPEC-0010 targeted unit and integration suite passing.
