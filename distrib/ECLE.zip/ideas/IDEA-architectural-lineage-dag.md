# IDEA: Architectural Lineage Tracking (LIA) + DAG Traversal

**Status:** Idea — not yet a spec  
**Raised:** 2026-05-11  
**Target phase:** Phase 3 (v0.3.0) — Topology Graph + GraphQL  
**Prior AMF art:** PVG (Stage 4), SPEC-047 (Cross-Tier Linker)

---

## The Question That Must Be Answerable

> "Show me everything about `DISCOUNT_CODE` — which DB column defines it, which code
> files touch it, which functions handle it, which service exposes it, which API
> contracts it."

This is **architectural lineage (LIA)**: tracing a concept or entity across layers:

```
DB column → code function → service entry point → API contract
```

A related capability is **DAG traversal**: answering execution-order questions:

> "What must run before `charge_engine.c` executes? What does it trigger?"

Both require traversing edges that cross the layers ECLE extracts — and today those
cross-layer edges are either missing from the schema or not yet built into a worker.

---

## What AMF Had — PVG (Projection View Generator)

AMF's Stage 4 produced 20 pre-materialised architectural view files. The views relevant
to lineage and DAG:

| View file | What it answered |
|-----------|-----------------|
| `database.pv` | Which files read/write which tables (table-level lineage) |
| `data_flow.pv` | How data moves across file boundaries (cross-file edges) |
| `sequence.pv` | Execution ordering DAG — what runs before/after what |
| `change_impact.pv` | Blast radius of a proposed change to a file or function |
| `api_contract.pv` | Entry points and their full outbound call graphs |
| `system_map.pv` | Full inventory: components, clusters, languages, entry points |

**Reference:** `ideas/WHAT-WE-BUILT.md` lines 61–70; `ideas/constitution/fact-architecture.md` (PVG mapping table)

---

## What ECLE 2.0 Decided (and Why It Was Right)

PVG was deleted as a pre-materialised stage. Views went stale after every commit —
a single file change forced regeneration of all 20 JSON files.

The ECLE 2.0 design converts each PVG view into an **on-demand parameterised query**
against the topology graph + vector DB:

| Old PVG view | ECLE 2.0 query equivalent |
|---|---|
| `database.pv` | Graph edges where artifact = table name (READ/WRITE) |
| `sequence.pv` | Traversal along `EXECUTION_SEQUENCE` edges, ordered by weight |
| `change_impact.pv` | Outbound graph traversal from a changed file, weighted by edge type |
| `data_flow.pv` | `WRITE_READ` edges enriched with Layer 1 table metadata |
| `api_contract.pv` | `is_entry_point=true` Layer 2 vectors + outbound edges |
| `system_map.pv` | Full Layer 1 + topology graph |

**Reference:** `ideas/constitution/fact-architecture.md` (PVG-to-query mapping table);
`constitution/adrs/ADR-0011-louvain-community-detection.md` (topology graph design)

This decision is correct and must not be reversed. The question is whether the
schema and phase plan have enough to actually build those queries.

---

## The Gap Today

### Extraction schema (what's missing)

| Lineage layer | What's in the schema | Gap |
|---|---|---|
| Table → code | `sql_statements[].tables`, `file_tables` (READ/WRITE) | Table-level only — no column granularity |
| Column → code | — | `CODE_USES_COLUMN` edge type **missing from schema** |
| Code → code (call DAG) | `dependencies[]`, topology edge types | Schema exists; no `compute_topology` worker yet (Phase 3) |
| Entry points | `entry_points[]` in `facts-base-schema.json` | Present but not yet joined to service definitions |
| Service → domain field | — | `SERVICE_USES_FIELD` edge **not designed in ECLE 2.0** |
| Domain field → column | — | `FIELD_MAPS_COLUMN` edge **not designed in ECLE 2.0** |
| Full chain traversal | — | No MCP tool or GraphQL query planned for end-to-end lineage |

### What Phase 3 already plans (partial coverage)

Phase 3 (`v0.3.0`) targets:
- `compute_topology` worker — builds topology edges from extracted facts
- GraphQL query layer — exposes the topology graph for traversal
- Louvain community detection — cluster assignment per file

This gives us the **code-to-code DAG**. It does not give us the **cross-layer chain**
(DB column → code → service → API).

### Prior AMF art not yet ported

`ideas/specs/week-7/SPEC-047-cross-tier-linker.md` designed the cross-tier edge model
for the AMF era. It defines `CODE_USES_COLUMN`, `FIELD_MAPS_COLUMN`, `SERVICE_USES_FIELD`,
`CONFIG_DB_CONNECTION`, `DB_OWNS_TABLE` and the BFS linker that materialises them.

That work applies directly — it needs porting to the ECLE 2.0 constitution (schema ADR +
Phase 3 spec extension).

---

## What Needs to Happen (When This Becomes a Spec)

### Step 1 — Schema ADR (before any spec)

A new ADR amending `facts-base-schema.json` and the topology edge catalogue to add:
- `CODE_USES_COLUMN` — code file/function → DB column
- `FIELD_MAPS_COLUMN` — domain field → DB column
- `SERVICE_USES_FIELD` — service entry point → domain field

Without this ADR, no spec can add these edge types (Contract 07 — schema changes need ADRs).

### Step 2 — Phase 3 spec extension: Cross-Tier Linker worker

A new worker (ported from AMF SPEC-047) that runs after `compute_topology`:
- Scans `sql_statements` for column references → creates `CODE_USES_COLUMN` edges
- Matches domain field names to `db_columns` → creates `FIELD_MAPS_COLUMN` edges
- Traces service IO fields to domain definitions → creates `SERVICE_USES_FIELD` edges

Trigger: Kafka `topology.complete` event. Output: cross-tier edges in `topology_edges`.

### Step 3 — MCP tool: `ecle_trace_entity`

A single parameterised MCP tool that traverses the full chain:
```
ecle_trace_entity(entity="DISCOUNT_CODE", entity_type="column|field|function|service")
→ returns full lineage graph: DB column → code files → functions → services → APIs
```

Open question: one composite tool vs. composable sub-queries (discuss at Phase 3 planning).

### Step 4 — Cross-repo lineage (defer to Phase 5)

The same entity (`DISCOUNT_CODE`) may appear in multiple repos. Resolving that chain
requires the Phase 5 cross-repo linking layer. Out of scope for Phase 3.

---

## Open Questions

1. Does column-level lineage (`CODE_USES_COLUMN`) live in `topology_edges` (graph) or in a
   separate `cross_tier_edges` table? Topology edges today are code-to-code only.

2. `ecle_trace_entity` — single composite MCP tool or composable sub-queries that the
   GraphQL layer stitches? Composable is more FACT-aligned (each query is testable in
   isolation) but requires a query planner.

3. When domain field → column matching fails (no DDL for a table), does ECLE declare a
   partial lineage gap in the response envelope or omit the chain? Must align with
   Contract 04 (FACT — Complete) and Contract 06 (Grounding).

4. The execution-order DAG (`EXECUTION_SEQUENCE` edges) — does it need a dedicated
   "topological sort" query or is graph traversal sufficient for the Phase 3 GraphQL layer?

---

## References

| File | Why relevant |
|---|---|
| `ideas/WHAT-WE-BUILT.md` | AMF PVG stage description |
| `ideas/constitution/fact-architecture.md` | PVG-to-query mapping; ECLE design rationale |
| `ideas/specs/week-7/SPEC-047-cross-tier-linker.md` | AMF cross-tier edge types (prior art to port) |
| `ideas/specs/week-5/SPEC-031-service-call-graph-index.md` | AMF service call graph / BFS index |
| `constitution/schemas/facts-base-schema.json` | Current extraction schema (missing column edges) |
| `constitution/adrs/ADR-0011-louvain-community-detection.md` | Topology graph + cluster design |
| `constitution/adrs/ADR-0032-two-phase-cpg-extraction.md` | Extraction pipeline (where column facts come from) |
| `constitution/contracts/07-staleness-contract.md` | On-demand vs. pre-materialised alignment |
