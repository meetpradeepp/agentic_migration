# SPEC-062: AMF Joern JVM Tuning + Extractor/Metrics Consolidation + Adaptive Parse Mode

**Status**: Spec (rev 3 — full Joern overhead minimisation)
**Owner**: Platform Architect
**Date**: 2026-05-08
**Triggered by**: `docs/PERFORMANCE_OPTIMISATION.md` (sister-project pb_parse work) — same JVM-startup tax exists in AMF deep processing, currently unmitigated.

**Scope evolution:**
- Rev 1: Phase A (JVM tuning) + Phase B (combined extract+metrics) only.
- Rev 2: + Phase B.1 universal metrics gap-fill (PB was the only language with metrics.sc).
- Rev 3: + Phase C (sharded script batching) + Phase D (adaptive parse mode driven by available host memory). Together they collapse Joern overhead at enterprise scale (5000-file repos).
- **Rev 4 (this rev):** PB project-mode parsing IS supported by the powerscript JAR — empirically verified via direct JAR invocation (15 files → 1 CPG, 9s vs 77s per-file = 8.5× speedup). The previous "PB exclusion from Phase D" was based on an unverified assumption about the AMF custom parser. The blocker is on the AMF Python wrapper side (`PowerScriptParser.parse_file()` accepts only single files, no `parse_directory()` method), NOT on the parser JAR. PB is now in scope for Phase D project-mode parsing.

**Implementation status by phase:**
| Phase | Status | Commit |
|-------|--------|--------|
| Phase A (JVM tuning from ecle.yaml) | ✅ Shipped | `5b36bcf`, `2694dc9` |
| Phase B.1 (universal metrics.sc) | ✅ Shipped | `c52dedb` |
| Phase B.2 (combined extract+metrics) | ✅ Shipped | `dcb3a6b` |
| Phase C foundation (PB batch script + sync tool) | ✅ Shipped | `2f7a590` |
| Phase C orchestration (sharded run.py wiring) | ⏳ Pending | this rev |
| Phase C propagation (C/C++/Proc batch scripts) | ⏳ Pending | this rev |
| Phase D (adaptive parse mode, PB included) | ⏳ Pending | this rev |

## Problem Statement

The AMF CPG stage spawns Joern as a subprocess up to **two times per file** in per-file mode (after the dead `joern-export` call site was removed in a parallel cleanup). Each invocation incurs a fresh JVM bootstrap + Scala/Joern framework load — measured at ~10–20s per call on a 16 GB Windows host.

| # | Call site (`AMF/stages/cpg/run.py`) | Function | Cost |
|---|--------------------------------------|----------|------|
| 1 | `joern --script extractor.sc` (per-file) | `_extract_facts()` | ~12s startup + ~1–3s work |
| 2 | `joern --script metrics.sc` (per-file)   | `_generate_metrics()` | ~12s startup + ~1–3s work |
| 3 | `joern --script extractor.sc` (project)  | `_process_project_mode_language()` | ~12s startup + bulk work (already batched per-language) |

Plus `joern-parse` runs once per file in `parsers/joern/parser.py:parse_file` and once per language in `parse_directory`.

**For a 200-file PowerBuilder repo** (per-file mode): `200 × 2 × ~12s = ~80 minutes of pure JVM overhead` before any extraction work happens.

Two compounding issues:
1. **No JVM tuning** — `JAVA_OPTS` / `_JAVA_OPTIONS` / `JOERN_OPTS` are never set or forwarded. The `JOERN_OPTS` manifest field at `AMF/stages/cpg/parsers/joern/manifest.yaml:36` is documented but unread. Default JVM startup pays repeated minor GCs during heap growth and never benefits from string deduplication on the (highly redundant) CPG string pool.
2. **Two scripts per file** — extractor.sc and metrics.sc each load the same `.cpg.bin` from scratch. The CPG load itself is fast (~0.3–1s); the wasteful part is paying JVM bootstrap twice for a graph that's already on disk and could be reused in-process.

The sister-project pb_parse work already proved both wins on the same JVM/Joern stack (see `docs/PERFORMANCE_OPTIMISATION.md`). This spec ports those lessons to AMF where the surface area is multi-language and parallel-worker-aware.

## Design Principle

**Same Joern, fewer JVMs.** No change to extraction logic, output schema, or fact contents. Only change *how often* and *with what flags* the JVM starts.

Output JSON files (`.facts.json`, `.metrics.json`) must be byte-identical to the current pipeline for the same input — verified by an A/B test on a fixture repo.

## Changes

This spec lands in **two phases**. Phase A (JVM tuning) is independent and ships first. Phase B (script consolidation) builds on Phase A.

### Phase A — JVM tuning (low blast radius, all languages)

JVM flags are **owned by `ecle.yaml`**, not hardcoded in AMF code. AMF reads them from env vars set by the ECLE → AMF subprocess bridge ([`src/ecle/cpg/client.py`](src/ecle/cpg/client.py)). When AMF is run standalone (no ECLE wrapper), conservative built-in fallbacks apply.

**A.1 — Configuration surface:**

New keys in [`ecle-data/config/ecle.yaml`](ecle-data/config/ecle.yaml#L80) under the existing `cpg:` block:

```yaml
cpg:
  enabled: true
  mode: local
  amf_root: …
  joern_home: …
  timeout: 3600
  # NEW (SPEC-062) — JVM tuning for Joern subprocesses
  java_opts: "-Xms512m -Xmx6g -XX:+UseStringDeduplication -XX:G1HeapRegionSize=16m -XX:MaxGCPauseMillis=200"
  # Used for: joern --script extractor.sc, metrics.sc, extract_and_metrics.sc, batch_extract_metrics.sc
  parse_java_opts: "-Xms128m -Xmx2g -XX:+UseG1GC -XX:MaxGCPauseMillis=200"
  # Used for: joern-parse (per-file CPG generation; smaller heap; exits fast)
  # NEW (SPEC-062 Phase B/C) — extraction mode
  combined_extraction: true            # Phase B: when true, run extractor + metrics in one JVM call per file
  batch_mode: auto                     # off | on | auto — Phase C: collapse N files → 1 JVM call per language
  batch_mode_threshold: 8              # batch_mode=auto activates when file_count >= threshold
```

**A.2 — `CPGSettings` dataclass extension** ([`src/ecle/config/settings.py:159`](src/ecle/config/settings.py#L159)):

```python
@dataclass
class CPGSettings:
    # ... existing fields ...
    java_opts: str = (
        "-Xms512m -Xmx6g -XX:+UseStringDeduplication "
        "-XX:G1HeapRegionSize=16m -XX:MaxGCPauseMillis=200"
    )
    parse_java_opts: str = (
        "-Xms128m -Xmx2g -XX:+UseG1GC -XX:MaxGCPauseMillis=200"
    )
    combined_extraction: bool = True
    batch_mode: str = "auto"            # off | on | auto
    batch_mode_threshold: int = 8
```

**A.3 — Env-var override map** ([`src/ecle/config/loader.py:29`](src/ecle/config/loader.py#L29)):

```python
"ECLE_CPG_JAVA_OPTS":          "cpg.java_opts",
"ECLE_CPG_PARSE_JAVA_OPTS":    "cpg.parse_java_opts",
"ECLE_CPG_COMBINED_EXTRACTION": "cpg.combined_extraction",
"ECLE_CPG_BATCH_MODE":          "cpg.batch_mode",
"ECLE_CPG_BATCH_MODE_THRESHOLD": "cpg.batch_mode_threshold",
```

Resolution order remains: CLI > env > ecle.yaml > dataclass defaults.

**A.4 — ECLE → AMF env handoff** ([`src/ecle/cpg/client.py:251`](src/ecle/cpg/client.py#L251), in the block that already sets `JOERN_HOME` and PATH):

```python
# Forward JVM tuning from ecle.yaml to AMF subprocess
if self.settings.cpg.java_opts:
    env["AMF_JOERN_JAVA_OPTS"] = self.settings.cpg.java_opts
if self.settings.cpg.parse_java_opts:
    env["AMF_JOERN_PARSE_JAVA_OPTS"] = self.settings.cpg.parse_java_opts
env["AMF_JOERN_COMBINED_EXTRACTION"] = "true" if self.settings.cpg.combined_extraction else "false"
env["AMF_JOERN_BATCH_MODE"] = self.settings.cpg.batch_mode
env["AMF_JOERN_BATCH_MODE_THRESHOLD"] = str(self.settings.cpg.batch_mode_threshold)
```

Why a separate `AMF_JOERN_JAVA_OPTS` env var instead of setting `JAVA_OPTS` directly here? Because Joern's launcher and direct `java -cp` invocations look at `JAVA_OPTS` themselves. Passing through a private name lets AMF decide *when* to apply it (e.g., parse subprocess uses the smaller bound) without polluting other Java tools that might inherit ECLE's env.

**A.5 — AMF helper** in [`AMF/stages/cpg/run.py`](AMF/stages/cpg/run.py) (module-level, ~line 470):

```python
# Conservative fallbacks for standalone AMF use (no ECLE wrapper).
# Primary configuration source: ecle.yaml cpg.java_opts → AMF_JOERN_JAVA_OPTS env.
_AMF_JOERN_JAVA_OPTS_FALLBACK = (
    "-Xms512m -Xmx6g -XX:+UseStringDeduplication "
    "-XX:G1HeapRegionSize=16m -XX:MaxGCPauseMillis=200"
)

def _build_joern_env(base_env: Mapping[str, str] | None = None) -> dict[str, str]:
    """Return a copy of os.environ (or base_env) with JAVA_OPTS injected.

    Resolution:
      1. Caller already set JAVA_OPTS or JOERN_OPTS → leave untouched
      2. AMF_JOERN_JAVA_OPTS in env (set by ECLE from ecle.yaml) → use it
      3. _AMF_JOERN_JAVA_OPTS_FALLBACK → standalone-AMF default

    _JAVA_OPTIONS is never set (it silently overrides user-supplied flags and
    is treated as hostile by some JDK distributions).
    """
    env = dict(base_env if base_env is not None else os.environ)
    if env.get("JAVA_OPTS") or env.get("JOERN_OPTS"):
        return env
    env["JAVA_OPTS"] = env.get("AMF_JOERN_JAVA_OPTS") or _AMF_JOERN_JAVA_OPTS_FALLBACK
    return env
```

**A.6 — Wire into all 3 surviving subprocess.run sites in `AMF/stages/cpg/run.py`:**

| Function | Current | New |
|----------|---------|-----|
| `_extract_facts()` (per-file extractor) | `env = os.environ.copy()` | `env = _build_joern_env()` |
| `_generate_metrics()` (per-file metrics) | `env = os.environ.copy()` | `env = _build_joern_env()` |
| `_process_project_mode_language()` (Java) | `env = os.environ.copy()` | `env = _build_joern_env()` |

(The fourth `joern-export` site at the old line 989 is gone — raw-export feature was removed in a parallel cleanup; downstream `cpg_bridge` is now facts-only.)

**A.7 — Parser-time JVM tuning** in [`AMF/stages/cpg/parsers/joern/parser.py`](AMF/stages/cpg/parsers/joern/parser.py):

`joern-parse` at lines 88 and 153 runs without an explicit env. Add a sibling helper:

```python
_AMF_JOERN_PARSE_JAVA_OPTS_FALLBACK = (
    "-Xms128m -Xmx2g -XX:+UseG1GC -XX:MaxGCPauseMillis=200"
)

def _build_parse_env() -> dict[str, str]:
    env = dict(os.environ)
    if env.get("JAVA_OPTS") or env.get("JOERN_OPTS"):
        return env
    env["JAVA_OPTS"] = env.get("AMF_JOERN_PARSE_JAVA_OPTS") or _AMF_JOERN_PARSE_JAVA_OPTS_FALLBACK
    return env
```

Pass `env=_build_parse_env()` to both `subprocess.run` calls.

**A.8 — Optional persistent config for direct CLI use:**

Document (in the perf doc, not auto-created) a one-line setup step: drop `JOERN_CLI_config.txt` next to the Joern install with the same flags prefixed `-J-`. This makes the same tuning apply when developers run `joern` directly outside AMF. Not coded — purely documented.

### Phase B — Combined extract+metrics script (per language)

For every language that today ships both `extractor.sc` and `metrics.sc`, we add a third script `extract_and_metrics.sc` that performs **both jobs in one JVM** using the already-loaded CPG.

**B.1 — Convention:** Each language plugin gets one new script:

```
AMF/stages/languages/<lang>/extract_and_metrics.sc
```

The script's `@main` accepts the same env vars as today's two scripts combined:

| Env var | Source | Purpose |
|---------|--------|---------|
| `JOERN_CPG_PATH` | required | CPG to load (loaded ONCE) |
| `JOERN_OUTPUT_PATH` | required | Where facts.json goes |
| `JOERN_METRICS_PATH` | optional | Where metrics.json goes; if unset, skip metrics |
| `JOERN_SOURCE_ROOT` | optional | Passed through |
| `JOERN_SOURCE_FILE` | optional | Passed through |
| `JOERN_PARSER_TYPE` | optional | Passed through (metrics.sc reads this) |
| `JOERN_TOKEN_STATS` | optional | Passed through |
| `JOERN_EXISTING_FACTS` | optional | SPEC-049 deep-merge hint, passed through |

Implementation: each combined script `import`s the existing `extractor.sc` and `metrics.sc` logic OR (simpler) inlines the two `@main` bodies into one function that loads the CPG once, calls extractor logic, then metrics logic. The two scripts don't share helpers today, so inlining is the cleanest port.

**B.2 — Language coverage (sequenced):**

| Order | Language | extractor.sc | metrics.sc (today) | metrics.sc (after spec) | Notes |
|-------|----------|--------------|--------------------|-------------------------|-------|
| 1 | `powerbuilder` | ✓ | ✓ (rich, PB-specific) | unchanged | First — has both, highest file counts in production |
| 2 | `java`         | ✓ | — | **NEW (universal)** | Project mode already batched; metrics added |
| 3 | `c`, `cpp`     | ✓ | — | **NEW (universal)** | Per-file mode — gets full Phase B win |
| 4 | `proc`         | ✓ | — | **NEW (universal)** | Per-file mode — gets full Phase B win |
| 5 | `_template`    | ✓ | — | **NEW (universal)** | Template ships with metrics so new packs inherit it |

**B.2a — Universal `metrics.sc` (new):** Each language without a hand-written metrics.sc gets a generic baseline that extracts language-agnostic CPG quality signals:

- **Parse fidelity**: `(resolved_calls + resolved_types) / (all_calls + all_types)` — `<unknown>` count is the inverse signal
- **Extraction yield**: counts of `method`, `call`, `typeDecl`, `local`, `controlStructure`, `return`, `literal` nodes; ratios of methods-with-line-numbers, calls-with-resolved-targets, typeDecls-with-members
- **Source coverage** (basic): distinct line numbers with any CPG node / total non-blank lines (no comment-tracking — that's PB-specific)
- **Schema compliance**: methods with valid (non-`<unknown>`) names, types with valid names

The script writes the same `metrics.json` shape as PB's metrics.sc (top-level keys: `filename`, `language`, `schema_version`, `generated_at`, `parse_fidelity`, `extraction_yield`, `source_coverage`, `overall_score`). PB-specific fields (`datawindow_summary`, `coverage_note`) stay in PB's metrics.sc only.

**B.2b — Manifest update (each language):** Add a `metrics:` block pointing at the new metrics.sc:

```yaml
metrics:
  enabled: true
  script: "metrics.sc"
  schema_version: "1.0"
  features:
    - "parse_fidelity"
    - "extraction_yield"
    - "source_coverage_basic"
```

For PowerBuilder, the existing block stays (rich metrics, schema_version 1.1).

**B.3 — Plugin contract change in `AMF/stages/languages/base_language.py`:**

Add an optional method:

```python
def get_combined_script(self) -> Path | None:
    """Return path to extract_and_metrics.sc if the language ships one, else None.

    When present, run.py uses the combined script and skips the separate metrics.sc call.
    """
    return None
```

PowerBuilder's `language.py` overrides this to return `extract_and_metrics.sc`. Java/C/C++/Proc inherit the `None` default.

**B.4 — run.py routing change:**

In the per-file pipeline (the section around lines 758–770 in `run.py`), add a branch:

```python
combined = language.get_combined_script() if hasattr(language, "get_combined_script") else None

if combined and combined.exists():
    # One JVM call: extractor + metrics
    facts_result = _extract_facts_combined(
        cpg_file, source_file, language, combined,
        cpg_logs_dir, base_name, token_stats,
    )
    metrics_result = {
        "success": facts_result.get("metrics_success", False),
        "metrics_file": facts_result.get("metrics_file"),
        "skipped": not language.metrics_enabled(),
    }
else:
    # Old two-call path (preserved for languages without combined script)
    facts_result = _extract_facts(...)   # unchanged
    metrics_result = _generate_metrics(...)  # unchanged
```

`_extract_facts_combined` is a new function that mirrors `_extract_facts` but also sets `JOERN_METRICS_PATH` in the env and returns metrics status alongside facts status.

**B.5 — Project-mode (`_process_project_mode_language`):**

Untouched in Phase B. Project mode already runs ONE Joern call per language. If a project-mode language ever ships metrics.sc, a project-mode combined script is a follow-up.

**B.6 — Raw JSON export (`_export_raw_json`):**

Untouched. `joern-export` is a different binary from `joern --script`; it cannot be folded into a script-side combined call. Phase A's JVM tuning still applies.

### Phase C — Sharded per-repo batching (script step)

Collapse **N files × 1 combined call → W chunks of (N/W) files × 1 batch call** by running W batch JVMs in parallel via the existing `ParallelFileProcessor`. Project-mode languages (Java) skip Phase C — their script step is already batched at the language level. Per-file-mode languages (PB, C, C++, Proc) get the full win.

**Why sharded, not single-batch:** a naive "one JVM for all 5000 files" loses the parallelism Phase B already provides via `ParallelFileProcessor`. At enterprise scale that single-JVM design is *slower* than parallel-per-file (5000 × 14s sequential vs 5000/16 × 14s parallel = 73 min). Sharding into W chunks (where W = worker count) preserves parallelism AND amortises JVM startup across each chunk's files.

**Wall-clock at different scales (W=16 workers):**

| Repo size | Pre-SPEC-062 | After A+B.2 | After Phase C (sharded) |
|-----------|--------------|-------------|--------------------------|
| 40 files  | ~36s         | ~42s parallel | **~18s** (3 files/chunk + 1 startup) |
| 200 files | ~3 min       | ~3 min      | **~37s** |
| 1000 files | ~15 min     | ~15 min     | **~3 min** |
| 5000 files | ~73 min     | ~73 min     | **~11 min** |

Bonus benefits: per-chunk recoverability (a crash kills one chunk's ~313 files, not all 5000), bounded memory per chunk (each JVM dies after its chunk), per-chunk progress visibility.

**C.1 — New Scala script per language:** `AMF/stages/languages/<lang>/batch_extract_metrics.sc`

Reads a manifest path from `JOERN_BATCH_MANIFEST` and loops over rows of `cpgPath | factsPath | metricsPath | sourceFile | tokenStats`.  Each row triggers `importCpg → run language extraction → run metrics tail → close project`.  Both the extraction logic and metrics tail are inlined per language (same approach as Phase B.2 — Joern script mode can't reliably load other .sc files).

```scala
@main def runBatch() = {
  val manifestPath = sys.env.getOrElse("JOERN_BATCH_MANIFEST",
    throw new RuntimeException("MISSING ENV: JOERN_BATCH_MANIFEST"))

  val rows = scala.io.Source.fromFile(manifestPath, "UTF-8").getLines()
    .filter(_.nonEmpty).filterNot(_.startsWith("#")).toList

  println(s"[batch] Processing ${rows.size} files in this chunk")
  var ok = 0; var failed = 0
  rows.foreach { row =>
    val parts = row.split('|').map(_.trim).padTo(5, "")
    val cpgPath = parts(0); val factsPath = parts(1); val metricsPath = parts(2)
    val sourceFile = parts(3); val tokenStats = parts(4)
    try {
      val proj = "batch_" + UUID.randomUUID().toString.take(8)
      val cpgOpt = importCpg(cpgPath, proj)
      if (cpgOpt.isEmpty) { println(s"[!] load failed: $cpgPath"); failed += 1 }
      else {
        val appCpg = cpgOpt.get
        // BEGIN inline language-specific extraction body (same as extractor.sc)
        // ... writes factsPath ...
        // BEGIN inline metrics tail (same as Phase B.2 tail snippet)
        // ... writes metricsPath if set ...
        close(proj)
        ok += 1
      }
    } catch { case e: Throwable =>
      println(s"[!] BATCH ERROR $cpgPath: ${e.getMessage}"); failed += 1
    }
  }
  println(s"[batch] done: $ok ok, $failed failed")
}
```

The body is generated from existing snippets to avoid divergence:
- Extraction body: per-language (PB/C/C++/Proc each have unique extraction logic)
- Metrics tail: shared (same `_metrics_tail*.scala_snippet` files from Phase B.2)
- The sync tool (`sync_metrics_tail.py`) gets a sibling that wraps the manifest loop around extractor body + metrics tail.

**C.2 — `BaseLanguage.get_batch_script()` (already in plugin contract):** returns `language_dir / "batch_extract_metrics.sc"` if it exists, else `None`. Already wired in Phase B.

**C.3 — Sharded orchestration in run.py:** new helper `_run_sharded_batch_for_language(language, files, ...)`:

```python
def _run_sharded_batch_for_language(language, files, parallel_processor, ...):
    """Phase 1: parse all CPGs (parallel, unchanged).
       Phase 2: split files into W chunks, run W batch_extract_metrics.sc calls in parallel."""
    # Phase 1 — same per-file CPG generation as today
    cpg_results = parallel_processor.process_files(files, _parse_cpg_only)

    # Phase 2 — chunk by worker count
    workers = parallel_processor.workers
    chunk_size = settings.cpg.batch_chunk_size or math.ceil(len(files) / workers)
    chunks = [files[i:i+chunk_size] for i in range(0, len(files), chunk_size)]

    # For each chunk: write its manifest, then call batch_extract_metrics.sc
    chunk_results = parallel_processor.process_chunks(chunks, _run_batch_chunk, language=language)
    return _merge_chunk_results(chunk_results)
```

Each chunk worker:
1. Writes its `batch_manifest_<chunk_id>.txt` with one row per file in the chunk
2. Sets `JOERN_BATCH_MANIFEST` and calls `joern --script batch_extract_metrics.sc` ONCE
3. Maps Joern stdout / written files back to per-file dicts

**C.4 — Activation gating:** `cpg.batch_mode` in ecle.yaml (already added in Phase A.1):

| `cpg.batch_mode` value | Behaviour |
|-------|----------|
| `off`              | Per-file mode using combined script (Phase B) |
| `on`               | Sharded batch mode (Phase C) for all per-file-mode languages |
| `auto` (default)   | Sharded batch when file count ≥ `cpg.batch_mode_threshold` (default 8), else per-file |

`cpg.batch_chunk_size` (new):
- `0` (default) — chunk = `ceil(N / worker_count)`, exactly fills W workers
- `>0` — explicit cap (operator override; e.g. `500` for safer chunks on flaky runs)

**C.5 — Parallel-worker compatibility:** Phase 1 (joern-parse per file) keeps current `ParallelFileProcessor` behaviour (W workers, one JVM each). Phase 2 (sharded batch) re-uses the SAME pool — each worker now runs ONE batch JVM that processes a chunk. Net: same number of concurrent JVMs as today (W), but each does N/W files of work instead of 1 file of work. Total Joern startups: `N + N` (today) → `N + W` (Phase C). At W=16, N=5000: from 10000 → 5016 startups (−50% on top of B.2's −50%).

### Phase D — Adaptive parse mode (memory-driven)

Phase C optimises the script step. After Phase C, **`joern-parse` becomes the dominant remaining cost at scale** (~5-7s per file × N, parallelised). For a 5000-file C repo on 16 workers: ~31 min just for parsing.

Joern's project-mode parsing collapses N parse JVMs into 1 — but it loads the whole-program CPG into memory and **OOMs on large repos at default 6 GB heap**. Production observation:

| Repo size | Per-file parse heap | Project-mode parse heap | Risk |
|-----------|---------------------|-------------------------|------|
| 100 files | ~300-600 MB | ~1-2 GB | Safe |
| 500 files | ~300-600 MB | ~3-5 GB | OK with `-Xmx6g` |
| 1000 files | ~300-600 MB | ~5-8 GB | Edge of `-Xmx8g` |
| 2000+ files | ~300-600 MB | **8-16 GB** | OOM risk |
| 5000 files | ~300-600 MB | **OOMs commonly** | Often unrunnable |

Phase D introduces a **memory-driven adaptive threshold**: pick project-mode parsing when the repo fits in available heap, fall back to per-file (which Phase C still optimises) when it doesn't.

**D.1 — Adaptive formula:**

```
available_mb       = psutil.virtual_memory().available / 1MB
safe_heap_mb       = available_mb × safety_factor       # default 0.6
max_files_in_proj  = (safe_heap_mb - baseline_mb) / per_file_mb

if num_files ≤ max_files_in_proj  → project-mode parse
else                                → per-file parse + Phase C sharded batch
```

How it adapts at different server sizes (defaults `per_file_mb=4`, `baseline_mb=500`, `safety_factor=0.6`):

| Server RAM | Available (post-OS) | Safe heap | Max files in project mode |
|------------|---------------------|-----------|----------------------------|
| 8 GB       | ~6 GB               | ~3.6 GB   | **~775 files**             |
| 16 GB      | ~12 GB              | ~7.2 GB   | **~1,675 files**           |
| 32 GB      | ~28 GB              | ~16.8 GB  | **~4,075 files**           |
| 64 GB      | ~58 GB              | ~34.8 GB  | **~8,575 files**           |

**D.2 — Configuration surface (extends ecle.yaml):**

```yaml
cpg:
  parse_mode: auto                        # auto | project | per_file
  parse_mode_threshold_files: 0           # 0 = compute dynamically; positive = explicit override
  parse_mode_per_file_mb: 4               # estimated heap MB per file in project mode
  parse_mode_baseline_mb: 500             # baseline JVM + Joern framework overhead
  parse_mode_safety_factor: 0.6           # fraction of available RAM to use as safe heap budget
  parse_mode_min_files_for_project: 50    # always per-file below this (project startup not worth it)
```

Five new env-var overrides (`ECLE_CPG_PARSE_MODE`, `ECLE_CPG_PARSE_MODE_THRESHOLD_FILES`, etc.) follow the existing pattern. Forwarded to AMF as `AMF_JOERN_PARSE_MODE*` env vars.

**D.3 — Decision logic in run.py:** new helper `_choose_parse_mode(language, num_files)`:

```python
def _choose_parse_mode(language, num_files: int) -> str:
    """Returns 'project' or 'per_file'. PB always per_file (custom parser)."""
    forced = os.getenv("AMF_JOERN_PARSE_MODE", "auto")
    if forced == "project":  return "project"
    if forced == "per_file": return "per_file"
    if not language.supports_project_mode():
        return "per_file"   # PB and any future custom-parser languages
    if num_files < int(os.getenv("AMF_JOERN_PARSE_MODE_MIN_FILES_FOR_PROJECT", "50")):
        return "per_file"
    explicit = int(os.getenv("AMF_JOERN_PARSE_MODE_THRESHOLD_FILES", "0"))
    if explicit > 0:
        return "project" if num_files <= explicit else "per_file"
    # Auto: derive from available memory
    import psutil
    avail_mb = psutil.virtual_memory().available / (1024 * 1024)
    safety = float(os.getenv("AMF_JOERN_PARSE_MODE_SAFETY_FACTOR", "0.6"))
    baseline = int(os.getenv("AMF_JOERN_PARSE_MODE_BASELINE_MB", "500"))
    per_file = int(os.getenv("AMF_JOERN_PARSE_MODE_PER_FILE_MB", "4"))
    safe_mb = avail_mb * safety
    max_files = (safe_mb - baseline) / per_file
    return "project" if num_files <= max_files else "per_file"
```

Logged at INFO every time a language's parse mode is chosen, with `(language, num_files, available_mb, decision)` so operators can tune the four knobs from real data.

**D.4 — `BaseLanguage.supports_project_mode()`:**

New method on `BaseLanguage` reading `parser.supports_project_mode` from the manifest (default `False`).  C/C++/Pro*C set this to `True` once their extractors are refactored. **PB also sets this to `True` (rev 4 correction)** — the powerscript JAR's directory mode is empirically verified.

**D.5 — Per-language extractor refactoring:** C/C++/Pro*C/PB extractors get a `JOERN_OUTPUT_DIR` branch (mirroring Java's existing pattern at [java/extractor.sc:357](AMF/stages/languages/java/extractor.sc#L357)):

```scala
val outputDir = sys.env.get("JOERN_OUTPUT_DIR")  // multi-file mode
val isMultiFile = outputDir.isDefined
if (isMultiFile) {
  validFiles.foreach { file =>
    val flatName = file.name.replace("/", "__").replace("\\", "__")
    val outPath = s"${outputDir.get}/$flatName.facts.json"
    // extraction logic for THIS file only
    // metrics tail: also writes per-file metrics if JOERN_METRICS_DIR set
  }
} else {
  // existing single-file mode unchanged
}
```

Same pattern for the metrics tail (writes one metrics.json per source file when `JOERN_METRICS_DIR` is set).

**D.6 — Manifest changes:**
```yaml
# Joern-frontend languages (C/C++/Pro*C):
parser:
  parser_id: "joern"
  supports_project_mode: true
  args: ["--language", "newc"]
  project_args: ["--language", "newc"]
```

```yaml
# PowerBuilder (custom powerscript parser):
parser:
  parser_id: "powerscript"
  supports_project_mode: true   # rev 4 — JAR supports directory natively
  args: []
  project_args: []
```

C/C++/Pro*C/Java/PB all set `supports_project_mode: true` after their corresponding parser wrapper + extractor.sc refactors land.

**D.6a — `PowerScriptParser.parse_directory()` (rev 4):** new method on the AMF Python wrapper at [parsers/powerscript/parser.py](AMF/stages/cpg/parsers/powerscript/parser.py) that invokes the JAR with a directory path:

```python
def parse_directory(self, input_dir: Path, output_file: Path, args: list[str] | None = None) -> ParseResult:
    """SPEC-062 Phase D — invoke powerscript2cpg.jar in directory mode.

    The JAR's CLI accepts EITHER a file or a directory as its first arg;
    in directory mode it processes all .srw/.sru/.srm/.srf/.srs files in
    the tree and produces ONE project-level CPG.
    """
    cmd_parts = [
        "java",
        "-cp", self._classpath_string(),
        "io.joern.powerscript.Powerscript2Cpg",
        str(input_dir),
        str(output_file),
    ]
    # ... mirror parse_file's subprocess invocation, env, timeout handling ...
```

The classpath logic already exists in `PowerScriptParser.parse_file()`; just refactor to share with `parse_directory()`.

**D.6b — PB extractor.sc directory-mode branch:** PB's extractor.sc (1700+ lines) currently extracts a single file's worth of data. In project mode, the loaded CPG contains all files. Add a JOERN_OUTPUT_DIR branch (mirroring Java) that loops `appCpg.file.l`, scopes extraction per-file, and writes one .facts.json per source file. The metrics tail similarly checks `JOERN_METRICS_DIR`. Both branches share the same core extraction logic (no duplication — just a router at the top).

**D.7 — OOM safety net:** when project-mode parse fails with a `java.lang.OutOfMemoryError` in Joern's stderr, run.py automatically retries the same language in per-file mode (logged as a warning, never fatal). Belt-and-braces in case the heuristic mis-predicts.

**D.8 — Out of scope for D:**
- Parse-mode switching at runtime BETWEEN languages (each language gets its own decision; mixed-language repos can have e.g. Java in project mode + PB in per-file).
- PB project-mode parsing (would require redesigning the custom AMF parser; tracked as a future spec).

## Files

### Phase A + B (✅ shipped)
| File | Change | Commit |
|------|--------|--------|
| `ecle-data/config/ecle.yaml` | Added `cpg.java_opts`, `cpg.parse_java_opts`, `cpg.combined_extraction`, `cpg.batch_mode`, `cpg.batch_mode_threshold` | `5b36bcf` |
| `src/ecle/config/settings.py` | Extended `CPGSettings` with 5 fields | `5b36bcf` |
| `src/ecle/config/loader.py` | Added 5 env-var entries to `_ENV_MAP` | `5b36bcf` |
| `src/ecle/cpg/client.py` | Forwards 5 settings to AMF as `AMF_JOERN_*` env vars | `5b36bcf` |
| `src/ecle/ingestion/job_queue.py` | Pass-through at CPGSettings construction site | `5b36bcf` |
| `AMF/stages/cpg/run.py` | `_build_joern_env`; wire into 3 subprocess sites; combined-mode routing in `process_cpg_pipeline` | `2694dc9`, `dcb3a6b` |
| `AMF/stages/cpg/parsers/joern/parser.py` | `_build_parse_env`; pass `env` to both `subprocess.run` calls | `5b36bcf` |
| `AMF/stages/languages/base_language.py` | `combined_extraction_enabled()`, `get_combined_script()`, `get_batch_script()` | `c52dedb`, `dcb3a6b` |
| `AMF/stages/languages/common/metrics_universal.sc` | NEW — language-agnostic metrics standalone script | `c52dedb` |
| `AMF/stages/languages/common/_metrics_tail.scala_snippet` | NEW — universal metrics tail body (Java/C/C++/Proc) | `dcb3a6b` |
| `AMF/stages/languages/common/_metrics_tail_powerbuilder.scala_snippet` | NEW — PB-rich metrics tail body | `dcb3a6b` |
| `AMF/stages/languages/common/sync_metrics_tail.py` | NEW — sync tool inlining tails into extractor.sc per language | `dcb3a6b` |
| `AMF/stages/languages/{powerbuilder,java,c,cpp,proc}/extractor.sc` | BEGIN/END markers + inlined tail body | `dcb3a6b` |
| `AMF/stages/languages/{powerbuilder,java,c,cpp,proc}/manifest.yaml` | `metrics.enabled` + `combined_extraction.enabled` | `c52dedb`, `dcb3a6b` |

### Phase C — Sharded script batching (⏳ this rev)
| File | Change |
|------|--------|
| `AMF/stages/languages/common/_batch_extract_metrics.scala_snippet` | NEW — universal manifest-loop body (called by all per-file-mode languages) |
| `AMF/stages/languages/common/sync_batch_scripts.py` | NEW — generates `batch_extract_metrics.sc` per language by stitching manifest-loop wrapper + extraction body + metrics tail |
| `AMF/stages/languages/{powerbuilder,c,cpp,proc}/batch_extract_metrics.sc` | NEW (generated) — manifest-loop wrapper around extraction body + metrics tail. Java is project-mode and skipped. |
| `AMF/stages/languages/{powerbuilder,c,cpp,proc}/manifest.yaml` | `batch_extraction.enabled: true` |
| `AMF/stages/cpg/run.py` | `_run_sharded_batch_for_language()` orchestration; chunked work distribution to `ParallelFileProcessor` |
| `ecle-data/config/ecle.yaml` | `cpg.batch_chunk_size` (already added in A; now used by orchestration) |

### Phase D — Adaptive parse mode (⏳ this rev)
| File | Change |
|------|--------|
| `ecle-data/config/ecle.yaml` | `cpg.parse_mode`, `cpg.parse_mode_threshold_files`, `cpg.parse_mode_per_file_mb`, `cpg.parse_mode_baseline_mb`, `cpg.parse_mode_safety_factor`, `cpg.parse_mode_min_files_for_project` |
| `src/ecle/config/settings.py` | Add 6 fields to `CPGSettings` |
| `src/ecle/config/loader.py` | Add 6 env-var entries |
| `src/ecle/cpg/client.py` | Forward 6 settings as `AMF_JOERN_PARSE_MODE*` env vars |
| `src/ecle/ingestion/job_queue.py` | Pass-through |
| `AMF/stages/cpg/run.py` | `_choose_parse_mode()` heuristic; route per-language; OOM-fallback |
| `AMF/stages/languages/base_language.py` | `supports_project_mode()` reading manifest flag |
| `AMF/stages/languages/{c,cpp,proc,powerbuilder}/manifest.yaml` | `parser.supports_project_mode: true` (PB: rev 4) |
| `AMF/stages/languages/{c,cpp,proc,powerbuilder}/extractor.sc` | Add `JOERN_OUTPUT_DIR` branch (mirror Java's pattern) — writes one .facts.json per source file when project mode. PB: rev 4 |
| `AMF/stages/cpg/parsers/powerscript/parser.py` | Add `parse_directory()` method invoking Powerscript2Cpg JAR in directory mode (rev 4) |
| `AMF/stages/languages/common/_metrics_tail*.scala_snippet` | Add `JOERN_METRICS_DIR` branch (when set, write per-file metrics; mirror facts) |
| `requirements.txt` / `pyproject.toml` | Confirm `psutil` is present (used for `virtual_memory()`) |

### Documentation
| File | Change |
|------|--------|
| `docs/AMF_DEEP_PROCESSING_PERF.md` | **New** — narrative doc describing all phases, config surface, expected timings, how to A/B test |

## Tests

| Test | Proves |
|------|--------|
| `test_build_joern_env_injects_fallback_java_opts` | When neither `JAVA_OPTS`, `JOERN_OPTS`, nor `AMF_JOERN_JAVA_OPTS` is set, `_build_joern_env` returns the standalone fallback in `JAVA_OPTS` |
| `test_build_joern_env_respects_user_java_opts` | Caller's existing `JAVA_OPTS` is not overwritten |
| `test_build_joern_env_respects_user_joern_opts` | If `JOERN_OPTS` is set, `JAVA_OPTS` is left untouched |
| `test_build_joern_env_honors_ecle_override` | `AMF_JOERN_JAVA_OPTS` env var (set by ECLE from ecle.yaml) overrides the fallback |
| `test_cpg_settings_loads_java_opts_from_yaml` | `cpg.java_opts` from ecle.yaml lands in `Settings.cpg.java_opts` |
| `test_cpg_client_forwards_java_opts_to_amf_env` | `CPGClient` injects `AMF_JOERN_JAVA_OPTS` into the AMF subprocess env from `settings.cpg.java_opts` |
| `test_env_override_beats_yaml_for_java_opts` | `ECLE_CPG_JAVA_OPTS` env var overrides ecle.yaml value |
| `test_extract_facts_uses_build_joern_env` | `_extract_facts` calls `subprocess.run` with env containing `JAVA_OPTS` |
| `test_generate_metrics_uses_build_joern_env` | Same for `_generate_metrics` |
| `test_export_raw_uses_build_joern_env` | Same for `_export_raw_json` |
| `test_pb_combined_script_exists_and_routes` | When PB language returns a combined script path, run.py picks the combined branch (mock subprocess) |
| `test_pb_combined_script_skipped_when_absent` | When `get_combined_script()` returns `None`, falls back to two-call path |
| `test_pb_combined_output_byte_identical` | Integration: run a small PB fixture through both old and new paths; `.facts.json` and `.metrics.json` must be byte-identical |
| `test_parser_uses_parse_java_opts` | `JoernParser.parse_file` and `parse_directory` pass env with `JAVA_OPTS=JOERN_PARSE_JAVA_OPTS` |

## Acceptance Criteria

### Phase A + B (✅ shipped — verified)
1. ✅ On a fixture PB repo of N ≥ 10 files, total Joern subprocess time drops by ≥ 40% vs. v1.7.1.
2. ✅ All Joern `subprocess.run` calls carry `env` with `JAVA_OPTS` (smoke-tested: 16 GB host, score 79% on simple.cpp).
3. ✅ No regression in non-PB language test suite (37/37 tests passing).
4. ✅ Combined mode routing is opt-in per language via manifest + ecle.yaml policy.

### Phase C (⏳ pending)
5. On a fixture per-file-mode language repo of N ≥ 100 files, sharded batch mode produces all `.facts.json` + `.metrics.json` byte-identical to per-file Phase B.2 output.
6. Sharded batch wall-clock is ≥ 5× faster than per-file Phase B.2 on a 1000-file repo.
7. A chunk failure (simulated by injecting an invalid CPG into a chunk's manifest) does NOT crash other chunks' processing — only the affected chunk reports failures, others complete successfully.
8. `cpg.batch_mode: off` preserves Phase B.2 behaviour exactly (regression test: outputs are byte-identical to current v1.7).

### Phase D (⏳ pending)
9. On a 16 GB host with 200 C files, `_choose_parse_mode()` returns `"project"` (≤ 1675 file threshold) — verified by unit test.
10. On a 16 GB host with 5000 C files, `_choose_parse_mode()` returns `"per_file"` — verified by unit test.
11. ~~PB always returns `"per_file"` regardless of memory or file count~~ — **rev 4: PB now goes through the same heuristic** since the powerscript JAR supports directory mode. Empirical baseline measurement: 15 PB files via per-file = 77s (15 JVMs); via directory mode = 9s (1 JVM) → **8.5× speedup** — verified by smoke test.
12. OOM fallback: when project-mode parse exits with `OutOfMemoryError`, run.py retries the same language in per-file mode, logs a warning, completes successfully — verified by integration test (mock subprocess that emits OOM).
13. C/C++/Proc/PB extractors with `JOERN_OUTPUT_DIR` set produce one `.facts.json` per source file in the directory, byte-identical to per-file mode output.
14. `PowerScriptParser.parse_directory()` exists and is callable; `BaseLanguage.supports_project_mode()` returns `True` for PB after manifest update.

### Cross-phase
14. Output `.facts.json` and `.metrics.json` shapes (top-level keys, schema_version) are byte-identical regardless of which phase is active — verified by A/B fixtures comparing v1.7 baseline vs Phase A+B+C+D.

## Dependencies

- SPEC-049 — Two-phase deep enhancement (deep-merge of structural + Joern facts; combined script must preserve `JOERN_EXISTING_FACTS` handling)
- SPEC-053 — Language common module (combined script may reuse common helpers if they exist; otherwise inlines)
- SPEC-057 — Parallel job workers (combined-call refactor must remain a per-file unit so `ParallelFileProcessor` keeps working unchanged)

## Related

- `docs/PERFORMANCE_OPTIMISATION.md` — sister-project pb_parse perf work; same JVM tax measured, same flags chosen
- `AMF/stages/cpg/parsers/joern/manifest.yaml` — `JOERN_OPTS` field at line 36 (currently documented but unread; this spec keeps it as an honored override)

## Out of Scope

- `joern-export` removed entirely (separate `3dbb84a` cleanup commit) — was a dead code path; cpg_bridge now reads `.facts.json` only.
- Project-mode batch script for Java — Java's extractor.sc already loops over all files inside one JVM. Phase C only adds value to per-file-mode languages.
- ECLE-side ingestion (no Joern subprocesses there) — this spec is AMF-only.
- Cross-language batching (one Joern JVM running mixed-language CPGs in one call) — each language has different schema/idioms; batching is per-language only.
- ~~PB project-mode parsing (was Phase D scope exclusion in rev 3)~~ — **rev 4 correction:** the powerscript JAR supports directory mode natively (`Powerscript2Cpg <directory> <output>`), verified empirically. The blocker is the AMF Python wrapper (`PowerScriptParser.parse_file()` only takes single files). PB is now in scope for Phase D project-mode parsing.
- **Cross-server memory probing:** Phase D's adaptive heuristic uses `psutil.virtual_memory().available` on the LOCAL host running AMF. Distributed/clustered AMF deployments where Joern runs on a different host would need explicit `parse_mode_threshold_files` configuration. Out of scope; covered by the explicit override knob.
- **Heuristic re-tuning at runtime:** the four knobs (`per_file_mb`, `baseline_mb`, `safety_factor`, `min_files_for_project`) are config — not auto-tuned from observation. A future spec could add observation-driven tuning (track real heap usage per project parse, update defaults).
