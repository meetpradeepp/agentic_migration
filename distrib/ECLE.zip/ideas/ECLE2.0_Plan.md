# ECLE 2.0: Enterprise Continuous Learning Engine for Code

## Executive Summary

**ECLE 2.0** is a **federated, event-driven knowledge graph system** that parses enterprise codebases (multiple languages, 1M+ LOC, 10+ repos), automatically detects code patterns/quality issues, learns from developer feedback and deployment outcomes, and delivers personalized, context-aware recommendations. 

**Core principle — FACT:** Every search result, recommendation, and API response must satisfy all four:
- **F**ast — queries resolve in milliseconds, not pipeline hours; ingestion is O(changed_files), not O(corpus); all traversals bounded; no serial cascade staleness
- **A**ccurate — every claim grounded in structural evidence; decomposed 5-dimension confidence profile on every result; zero hallucination; verifiers reject ungrounded claims; never surface stale data as fresh
- **C**omplete — no silent gaps; every entity in every indexed repo is reachable; if knowledge is missing or partial the system says so explicitly with confidence profiles and coverage warnings
- **T**rustworthy — the umbrella guarantee that every answer can be relied upon; enforced by two sub-properties:
  - **Timely:** knowledge reflects the latest commit; no cascade staleness where a single file change must flow through N stages before knowledge is current; incremental ingestion is O(changed_files); `knowledge_current_as_of` on every response
  - **Traceable:** every answer cites its full lineage — source file → parser version → embedding model → index timestamp → query plan; uncited claims are blocked by the Grounding verifier

> Timely and Traceable are both enforced by the Staleness Contract and Grounding Contract respectively. You cannot claim Trustworthy unless both sub-properties pass their CI eval gates.

**Core design philosophy:**
- **Parse once, fan out immediately** — CPG/tree-sitter extraction is ground truth; all downstream layers are projections of those facts, not serial transformations
- **Three backends, one query interface** — structured DB (80% of queries), vector index (20% of queries), topology graph (traversal); routed by the GraphQL query planner
- **Views are queries, not artifacts** — what serial pipelines materialise as JSON files becomes on-demand query functions; always fresh, no pre-materialisation lag
- **Slim vectors, facts in structured DB** — vector payloads hold only routing metadata; full entity facts live in the structured DB; joined by id after ANN search
- **Local-first embedding** — ONNX/OpenVINO; air-gapped compliant by default; cloud embedding APIs are opt-in adapters
- **Contract-first cross-repo linking** — O(C log C) contract matching, not O(N²) entity comparison
- **Graceful degradation with honesty** — classify unresolved links, never crash; always declare partial coverage in response envelope
- **Spec before code** — no implementation begins without a written spec; SDLC and Testing contracts are non-negotiable

## System Architecture (PostgreSQL + Celery Event-Driven)

Each box is a single Celery worker. Each worker has one job. Workers communicate only via events in the PostgreSQL events table — never by direct call.

```
┌─────────────────────────────────────────────────────────────────────────┐
│  API (FastAPI)                                                          │
│  POST /upload (zip) → store zip → emit source.received → 202 Accepted  │
│  POST /sources/git  → validate  → emit source.received → 202 Accepted  │
└──────────────────────────────┬──────────────────────────────────────────┘
                               ↓ event: source.received
┌─────────────────────────────────────────────────────────────────────────┐
│  [scan_source]  SRP: detect repos in the source payload                 │
│  - Unzip / git clone → walk dir tree → identify repo roots             │
│  → emits repo.detected (one per repo found) + source.scanned          │
└──────────────────────────────┬──────────────────────────────────────────┘
                               ↓ event: repo.detected
┌─────────────────────────────────────────────────────────────────────────┐
│  [parse_repo]  SRP: source code → IR artifact files only               │
│  Per file: language detect → tree-sitter grammar →                     │
│    Parser().parse(bytes) [in-process, ~1–5ms] →                       │
│    Extractor walks AST → facts dict                                    │
│  Writes: artifacts/{tenant}/{repo_id}/{file_rel_path}.facts.json       │
│  → emits file.ir_produced (per file) + repo.ir_produced (per repo)    │
│  NOTE: no DB writes, no vector ops, no graph writes                    │
└──────────────────────────────┬──────────────────────────────────────────┘
                               ↓ event: file.ir_produced  ← fans out to all below in parallel
          ┌────────────────────┴────────────────────┐
          ↓                                         ↓
┌─────────────────────────────┐      ┌──────────────────────────────────┐
│  [persist_facts]            │      │  [build_graph]                   │
│  SRP: IR → Structured DB    │      │  SRP: IR → Neo4j graph           │
│  Reads facts.json artifact  │      │  Reads facts.json artifact       │
│  Writes file_facts,         │      │  MERGE function/file nodes,      │
│    function_facts,          │      │    call edges, table-access      │
│    file_tables,             │      │    edges in Neo4j                │
│    function_calls, etc.     │      │  → emits graph.updated           │
│  → emits file.stored        │      └──────────────┬───────────────────┘
└──────────────┬──────────────┘                     ↓ event: graph.updated
               ↓ event: file.stored     ┌──────────────────────────────────┐
     ┌─────────┴──────────┐             │  [compute_topology]              │
     ↓                    ↓             │  SRP: graph → topology edges     │
┌──────────────┐  ┌───────────────────┐ │  Runs 9 signal detectors         │
│ [chunk_file] │  │[detect_dsl_       │ │  Writes topology_edges to DB     │
│ SRP: IR →   │  │ mappings]         │ │  → emits topology.updated        │
│ text chunks  │  │SRP: facts → DSL  │ └──────────────────────────────────┘
│ for embedding│  │tags              │
│ → file.chunked│ │→ dsl.mapped      │
└──────┬───────┘  └────────┬──────────┘
       ↓                   ↓ event: dsl.mapped
┌──────────────┐  ┌──────────────────────┐
│ [batch_embed]│  │ [ontology_enricher]  │
│ SRP: chunks  │  │ SRP: DSL tags →      │
│ → vectors    │  │ ontology enrichment  │
│ ONNX/OpenVINO│  │ → ontology.enriched  │
│ slim vectors │  └──────────────────────┘
│→ file.embedded│
└──────┬───────┘
       ↓ event: file.embedded
┌──────────────┐
│[cluster_     │
│ centroids]   │
│ SRP: update  │
│ Layer 3      │
│ centroids    │
└──────────────┘

event: repo.ir_produced → [build_contract_registry]
event: source.scanned  → [link_contracts]  (after all repos complete)

┌─────────────────────────────────────────────────────────────────────────┐
│  [Federated Search API + GraphQL + MCP]  (query-time, not ingestion)   │
│  Query planner routes: structured → Structured Fact DB (80%)           │
│                        semantic   → Vector Index (20%)                 │
│                        traversal  → Topology Graph                     │
│  FACT envelope (Timely + Traceable) on every response                  │
└─────────────────────────────────────────────────────────────────────────┘
```

### Component Details

**1. Parser Service** (`parse_repo` Celery worker)
- **SRP: source code → IR artifact files. No DB writes. No vector ops. No graph writes.**
- **Triggered by:** `repo.detected` event — never called directly by the API

**Language Pack Registry — dynamic, manifest-driven plugin model:**

At worker startup, `LanguagePackRegistry` scans `language_packs/` and loads every sub-folder that contains a `manifest.yaml`. No code changes are needed to add a new language — drop a folder in and restart the worker.

```
language_packs/
  powerbuilder/   manifest.yaml  fast_extractor.py  schema.py  sanitizer.py
  proc/           manifest.yaml  fast_extractor.py  schema.py  sanitizer.py
  python/         manifest.yaml  fast_extractor.py  schema.py  sanitizer.py
  java/           manifest.yaml  fast_extractor.py  schema.py
  sql/            manifest.yaml  fast_extractor.py  schema.py
  config/         manifest.yaml  fast_extractor.py  schema.py   (.yaml/.json/.toml/.ini/.env)
  xml/            manifest.yaml  fast_extractor.py  schema.py
  document/       manifest.yaml  fast_extractor.py  schema.py   (.md/.rst/.txt)
  image/          manifest.yaml  fast_extractor.py  schema.py   (.png/.jpg — OCR)
  svg/            manifest.yaml  fast_extractor.py  schema.py
  default/        manifest.yaml  fast_extractor.py  schema.py   ← always succeeds, HEURISTIC
```

**How the registry resolves a file:**
```
LanguagePackRegistry.get(extension) → LanguagePack | DefaultPack
  1. Exact extension match in any pack's manifest.yaml extensions.source[]
  2. Shebang sniff if extension is ambiguous (.sh / no-extension scripts)
  3. No match → DefaultPack  (fidelity=HEURISTIC, used_fallback=true)
```

**Execution per file:**
  1. Extension + shebang sniff → `pack = LanguagePackRegistry.get(ext)`
  2. `pack.sanitize(source_bytes)` → `clean_bytes`  (encoding fix, BOM strip, language-specific transforms)
  3. If `pack.manifest.fast_extraction.enabled`:
     - `tree_sitter.Parser()` with `pack.grammar` (in-process, ~1–5ms)
     - `parser.parse(clean_bytes)` → syntax tree
     - `pack.fast_extractor.extract(tree, clean_bytes, file_path)` → facts dict
     - `_extraction_tier = "structural"`
  4. Else (DefaultPack or grammar unavailable):
     - `pack.fast_extractor.extract(clean_bytes, file_path)` → raw text facts
     - `_extraction_tier = "text"`, `fidelity = HEURISTIC`, `used_fallback = true`
  5. IR artifact written to `artifacts/{tenant_id}/{repo_id}/{file_rel_path}.facts.json`
  6. `file.ir_produced` event emitted per file
     - payload: `{artifact_path, file_id, repo_id, language, fidelity, used_fallback, content_hash, commit_sha}`
     - `used_fallback: true` → `extraction_fidelity = HEURISTIC` in `file_facts` → confidence ceiling
- After all files: `repo.ir_produced` event emitted
- Per-repo workers are independent — run in parallel across repos
- **Output contract:** one `facts.json` per source file in the artifact store; nothing else
- Failures: file-level errors recorded in event payload; one bad file does not fail the repo job

**1a. Fact Persistence Service** (`persist_facts` Celery worker)
- **SRP: IR artifact → Structured Fact DB.** Reads nothing from source; writes nothing to graph.
- **Triggered by:** `file.ir_produced` event
- Reads `facts.json` from `artifact_path` in the event payload
- Writes: `file_facts`, `function_facts`, `file_tables`, `function_calls`, `function_table_ops`, `file_entry_points`
- Emits: `file.stored` event (payload: `{file_id, repo_id, table_row_counts}`)

**1b. Graph Builder Service** (`build_graph` Celery worker)
- **SRP: IR artifact → Neo4j graph.** Reads nothing from DB; writes only to graph.
- **Triggered by:** `file.ir_produced` event (parallel with `persist_facts`)
- Reads `facts.json` from `artifact_path`
- Issues `MERGE` statements to Neo4j: function nodes, file nodes, CALL edges, TABLE_ACCESS edges
- Emits: `graph.updated` event (payload: `{file_id, node_count, edge_count}`)

**1c. Chunking Service** (`chunk_file` Celery worker)
- **SRP: structured facts → text chunks for embedding.** No AST access; no vector writes.
- **Triggered by:** `file.stored` event (structured DB must be populated first)
- Reads `function_facts` + `file_facts` for the `file_id` from Structured Fact DB
- Splits into token-budget chunks (semantic boundary: max one function per chunk)
- Writes: `artifacts/{tenant_id}/{repo_id}/{file_id}.chunks.json`
- Emits: `file.chunked` event (payload: `{file_id, chunk_count, artifact_path}`)

---

### Language Pack Contract

A language pack is a self-contained folder under `language_packs/<language_id>/`. Adding a new language requires no changes to `parse_repo` or any other worker — only the new pack folder.

**Folder structure (every field is enforced by the registry loader):**
```
language_packs/<language_id>/
  manifest.yaml          ← required; machine-readable contract for the registry
  fast_extractor.py      ← required; tree-sitter or text extraction logic
  schema.py              ← required; Pydantic model extending CanonicalFactFileBase
  sanitizer.py           ← optional; pre-processing before parsing
```

**`manifest.yaml` fields:**
```yaml
metadata:
  language_id: "powerbuilder"   # used as the key in LanguagePackRegistry
  name: "PowerBuilder"          # human label
  version: "1.0"
  family: "4gl"                 # oo | 4gl | scripting | system | document | config | image

extensions:
  source: [".srw", ".sru", ".srf", ".srm", ".srs", ".srd"]  # registry key lookup
  binary: [".pbl"]              # informational only

fast_extraction:
  enabled: true
  grammar: "tree-sitter-powerbuilder"  # Python package name; null if no grammar
  fidelity: "FULL"              # FULL | PARTIAL | HEURISTIC — propagates to confidence ceiling

preprocessing:
  enabled: true
  sanitizer: "sanitizer.py"    # omit or false to skip
  rules:
    strip_bom: true
    normalize_line_endings: true
    fix_encoding: "utf-8"
    custom: ["remove_powerbuilder_metadata", "normalize_datawindow_syntax"]
```

**`fast_extractor.py` interface (all packs must export this function):**
```python
def extract(
    tree_or_bytes,        # tree_sitter.Tree if grammar enabled; raw bytes if text-only
    source_bytes: bytes,
    file_path: Path,
    language_dir: Path,
) -> dict:
    """
    Returns a dict conforming to CanonicalFactFileBase + any language extensions.
    Must always return a valid dict — never raise. Record errors in a top-level
    'extraction_errors' list field.
    """
```

**`schema.py` — extending `CanonicalFactFileBase`:**
```python
from ecle.language_packs.common.facts_schema import CanonicalFactFileBase

class CanonicalFactFilePowerBuilder(CanonicalFactFileBase):
    datawindow_tables: list[DataWindowTable] = []
    external_functions: list[ExternalFunction] = []
    menu_items: list[dict] = []
    external_service_calls: list[dict] = []  # SOAP / HTTP / EAI
```

**`CanonicalFactFileBase` — shared base (all packs inherit this shape):**
```python
# ecle/language_packs/common/facts_schema.py
class CanonicalFactFileBase(BaseModel):
    filename: str
    language: str
    fidelity: str              # FULL | PARTIAL | HEURISTIC
    used_fallback: bool = False
    _extraction_tier: str      # "structural" (tree-sitter) | "text" (default)
    functions: list = []
    sql_statements: list = []
    dependencies: list = []
    calls: list = []
    entry_points: list = []
    imports: list = []
    struct_definitions: list = []
    global_defs: list = []
    execution_sequence: list = []
    data_writes: list = []
    data_reads: list = []
    framework_calls: list = []
    data_flow_edges: list = []
    control_flow_edges: list = []
    extraction_errors: list = []   # never raises — errors go here
    raw_text_excerpt: str | None = None   # populated by DefaultPack only
```

**Fidelity mapping:**

| `manifest.fast_extraction.fidelity` | `_extraction_tier` | `extraction_fidelity` in DB | Confidence ceiling |
|---|---|---|---|
| `FULL` | `structural` | `FULL` | 1.0 (no ceiling) |
| `PARTIAL` | `structural` | `PARTIAL` | 0.8 |
| `HEURISTIC` | `text` | `HEURISTIC` | 0.6 |
| `HEURISTIC` + `used_fallback=true` | `text` | `HEURISTIC` | 0.5 |

**Adding a new language — checklist:**
1. Create `language_packs/<language_id>/`
2. Write `manifest.yaml` — set `language_id`, `extensions.source`, `fidelity`
3. Write `fast_extractor.py` — implement `extract()` returning base + extension fields
4. Write `schema.py` — extend `CanonicalFactFileBase` with language-specific fields
5. Optionally write `sanitizer.py` if the language needs encoding/transform pre-processing
6. Install any required tree-sitter grammar package (`pip install tree-sitter-<language>`)
7. Restart `parse_repo` workers — registry auto-discovers the new pack

---

**2. PostgreSQL Events Table**
- Schema: (event_type VARCHAR, entity_id, repo_id, payload JSONB, created_at, processed_at)
- Purpose: Immutable append log of all system events
- Used for: Event replay, debugging, incremental processing, audit trail

**3. Celery Workers** — each worker has one job; communicates only via events

| Worker | Consumes | SRP | Emits |
|---|---|---|---|
| `scan_source` | `source.received` | detect repos in payload | `repo.detected`, `source.scanned` |
| `parse_repo` | `repo.detected` | source code → IR artifact files | `file.ir_produced`, `repo.ir_produced` |
| `persist_facts` | `file.ir_produced` | IR artifact → Structured Fact DB | `file.stored` |
| `build_graph` | `file.ir_produced` | IR artifact → Neo4j graph nodes/edges | `graph.updated` |
| `chunk_file` | `file.stored` | structured facts → text chunks | `file.chunked` |
| `detect_dsl_mappings` | `file.stored` | structured facts → DSL concept tags | `dsl.mapped` |
| `batch_embed` | `file.chunked` | text chunks → slim vectors (ONNX/OpenVINO) | `file.embedded` |
| `compute_topology` | `graph.updated` | run 9 signal detectors → topology edges | `topology.updated` |
| `ontology_enricher` | `dsl.mapped` | DSL tags → ontology enrichment | `ontology.enriched` |
| `cluster_centroids` | `file.embedded` | incremental Layer 3 centroid update | — |
| `build_contract_registry` | `repo.ir_produced` | per-repo contract index | `contracts.registered` |
| `link_contracts` | `source.scanned` | cross-repo contract matching | `cross.linked` |
| `learning_analyzer` | `feedback.given` | feedback → recommendation weights | `model.updated` |

**4. Topology Graph** — Structural relationship store (replaces Neo4j as primary graph)
- Stores only edges (not node properties — those live in Structured Fact DB)
- Edge types: FUNCTION_CALL, WRITE_READ, EXECUTION_SEQUENCE, SHARED_TYPE, IMPORT, STATE_FLOW, CROSS_REPO
- Edge attributes: weight (canonical: 3.0/2.5/2.0/1.0/0.5), signal_type, confidence, evidence, commit_sha, is_valid
- **Backend:** Neo4j (enterprise, native Cypher traversal) or PostgreSQL recursive CTEs or SQLite adj-list (single-dev)
- Views are **parameterised graph queries**, not pre-materialised files: database view, security view, API contracts, impact traversal, data flow, service boundary, critical path
- Used for: impact analysis, execution path tracing, data flow tracing, cross-repo dependency

**5. Vector Index** — Semantic similarity only (~20% of queries)
- Stores **slim vectors only**: `{id, vector, repo_id, cluster_id, is_current, model_version, layer}` — NO full entity facts
- Full entity facts live in Structured Fact DB; joined by id after ANN search (two-hop: ~5ms total)
- **Three layers:**
  - **Layer 1** — one vector per file per version; vector IS the behavioral fingerprint (cosine distance = behavioral distance); `version_distance` field enables cosmetic vs. behavioral commit detection
  - **Layer 2** — one vector per function per file version; cross-file relationships emerge from vector proximity (similar behavior → similar vectors)
  - **Layer 3** — cluster/capability centroids; file-to-capability assignment by nearest centroid; staleness tracked by centroid drift
- Embedding model: local ONNX/OpenVINO (air-gapped compliant); `all-MiniLM-L6-v2` (384-dim) baseline; benchmark 768-dim models before Phase 2
- **Backend:** ChromaDB (single-dev, local) or Qdrant (enterprise); swappable via `IVectorStore` interface
- Collection naming: `{tenant}__{repo}__layer1`, `{tenant}__{repo}__layer2`, `{tenant}__cross_repo__capabilities`

**5a. Structured Fact DB** — Workhorse for ~80% of queries
- Normalised relational tables: `file_facts`, `function_facts`, `file_tables`, `function_calls`, `function_table_ops`, `file_entry_points`, `topology_edges`, `clusters`, `capabilities`, `indexing_state`
- Handles: exact-match lookups, range queries, aggregations, joins — all faster than vector payload filters
- Version-aware: every row keyed by `(entity_id, commit_sha)`; `is_current` flag; `superseded_at` timestamp
- **Backend:** SQLite (single-dev) or PostgreSQL (enterprise), same schema; selected via `STRUCTURED_BACKEND` config

**6. DSL Registry** (YAML, versioned in Git)
- Defines: business concepts, synonyms, code patterns, rules
- Example: {concept: "Customer", synonyms: ["Client", "User"], patterns: {class_suffix: ["Customer", "Service"]}}
- Consumed by: DSL aligner (injected on startup)
- Enables: Non-technical stakeholders define business vocabulary

**7. Ontology Store** (Neo4j + OWL)
- Defines: concept hierarchies, semantic relationships, inference rules
- Example: Party → Customer → RetailCustomer; Payment → GDPR_SUBJECT
- Consumed by: Ontology enricher (applied at runtime)
- Enables: Formal knowledge representation + automated reasoning

**8. Feedback Collector**
- Sources: GitHub PR reviews, GitLab MR comments, deployment events, Jira tickets
- Signals: Developer accepts/rejects recommendations, code passes/fails, metrics improve/degrade
- Output: feedback.given events → PostgreSQL → learning engine

**9. Learning/Analytics Engine**
- Inputs: feedback.given events + code analysis results
- Process: Track recommendation acceptance rate, outcome quality, team patterns
- Outputs: Recommendation confidence weights, team-specific heuristics
- ML models: Logistic regression (will developer accept?), outcome predictor (will this improve quality?)

**10. Recommendation Engine**
- Inputs: Code analysis + DSL mapping + ontology tags + learning models
- Process: Generate recommendations with impact scores, effort estimates, confidence weights
- Outputs: Ranked suggestions with rationale
- Integration: GitHub Actions (PR checks), IDE (inline suggestions), Slack (daily digest)

**11. Federated Search API + GraphQL Endpoint**
- Exposes: `/graphql` (Strawberry/Ariadne) — single query interface for all consumers
- Query planner routes by query type: structured lookup → Structured Fact DB; semantic similarity → Vector Index; traversal → Topology Graph; complex → compose all three
- GraphQL chosen because: flexible field selection (MCP tools fetch only what they need), self-documenting schema, introspection for AI agents, single endpoint vs. multiple REST routes
- **FACT enforcement per result:**
  - **Fast:** Query planner routes to cheapest backend first; ANN search capped (ef_search=64); topology traversal depth-capped (default: 4 hops); 2s timeout → return partial with `fast.timed_out: true`
  - **Accurate:** 5-dimension confidence profile on every result (see Confidence Contract); grounding verifier rejects ungrounded LLM claims; `confidence_ceiling` propagated from extraction fidelity (FULL/PARTIAL/HEURISTIC)
  - **Complete:** Pre-query coverage check against `indexing_state` table; missing repos/entities declared in `coverage_warnings`; never silent
  - **Trustworthy:** Every response includes `knowledge_current_as_of` (Timely) and a `lineage` object on every result (Traceable); staleness score drives caveat vs. warning behaviour; uncited claims blocked by grounding verifier (see Staleness Contract + Grounding Contract)

**12. MCP Consumption Layer**
- What: An MCP server that sits in front of the GraphQL endpoint; proven PoC pattern
- Purpose: Expose ECLE's knowledge to AI agents (GitHub Copilot, Claude, Cursor, custom agents) as MCP tools
- Transport: stdio (local dev) or SSE/HTTP (hosted); stateless server
- **Discovery tools** (structured DB — fast exact match):
  - `fact_find_files(repo, filters)` — files by language, table, entry_point flag
  - `fact_find_functions(callee_name, repo)` — callers of a function
  - `fact_find_tables(table_name, operation)` — all files reading/writing a table
- **Semantic tools** (vector index — approximate):
  - `fact_search(query, repo?, layer?)` — semantic similarity across Layer 1/2/3
  - `fact_find_similar(entity_id, top_k)` — behaviorally similar files/functions
  - `fact_find_duplicates(entity_id, threshold)` — semantic clones
- **Traversal tools** (topology graph):
  - `fact_impact(entity_id, hops?, min_weight?)` — impact analysis outward
  - `fact_trace_path(source, target)` — execution path between two points
  - `fact_trace_data(table_name)` — data flow for a table across all files
- **View tools** (on-demand; replaces pre-materialised pipeline artifacts):
  - `fact_view_database` — database lineage view
  - `fact_view_api_contracts` — entry points + their call graphs
  - `fact_view_security` — auth/crypto/validation patterns
- Each tool response is the FACT envelope — agent receives confidence profile, staleness caveat, coverage warnings, and lineage alongside results
- GraphQL schema is the single contract; swapping vector or graph backend requires zero changes to MCP tools

## FACT Search Guarantees

### FACT Search Result Envelope

Every response from the Federated Search API wraps results in this envelope — no raw entity dumps:

```json
{
  "query_id": "q_abc123",
  "query_text": "calculatePayment",
  "executed_at": "2026-05-05T10:00:00Z",
  "fact_status": {
    "fast":      { "latency_ms": 143, "search_backend": "pgvector", "neo4j_hops": 2 },
    "accurate":  { "reranked": true, "min_confidence": 0.61, "avg_confidence": 0.84 },
    "complete":  { "repos_queried": 4, "repos_fully_indexed": 3,
                   "coverage_warnings": [{"repo": "legacy-core", "missing_entities": 142, "reason": "embed_job_pending"}] },
    "traceable": { "query_plan": ["pgvector_ann", "neo4j_enrich", "dsl_overlay", "rerank"], "trace_id": "tr_xyz789" }
  },
  "results": [
    {
      "entity_id": "func_123",
      "entity_type": "function",
      "name": "calculatePayment",
      "repo": "payment-engine",
      "file_path": "src/PaymentService.sru",
      "confidence_score": 0.91,
      "confidence_breakdown": {
        "vector_similarity": 0.95,
        "dsl_match": 0.88,
        "parse_quality": 0.90
      },
      "lineage": {
        "source_file": "src/PaymentService.sru",
        "parsed_at": "2026-05-04T08:12:00Z",
        "parser_version": "tree-sitter-powerbuilder@1.2.0",
        "embedded_at": "2026-05-04T08:15:00Z",
        "embedding_model": "all-MiniLM-L6-v2@local-onnx",
        "indexed_at": "2026-05-04T08:16:00Z",
        "index_version": "v42"
      },
      "dsl_concepts": ["Payment", "Transaction"],
      "ontology_tags": ["GDPR_SUBJECT", "CRITICAL"],
      "relationships": [{ "type": "CALLS", "target": "getCustomerProfile", "resolved": true }]
    }
  ],
  "total_hits": 18,
  "returned": 10
}
```

### How Each FACT Property Is Enforced

| Property | Enforcement Mechanism | Failure Behaviour |
|----------|-----------------------|-------------------|
| **Fast** | Query planner routes to cheapest backend; ANN search (HNSW, ef_search=64); topology depth cap; 2s hard timeout | Timeout → return partial with `fast.timed_out: true` |
| **Accurate** | 5-dimension confidence profile (not a scalar); grounding verifier blocks uncited claims; extraction fidelity caps confidence ceiling | Low confidence → visible in envelope; never hidden or silently dropped |
| **Complete** | Pre-query coverage check against `indexing_state` table; missing repos/entities declared in `coverage_warnings` | Partial coverage → always declared; never silent |
| **Timely** | `knowledge_current_as_of` on every response; staleness score drives behaviour (serve/caveat/warn) per Staleness Contract | Never block on synthesis; always serve with honest staleness declaration |

### Confidence Contract — 5-Dimension Profile

Every result carries a **decomposed** confidence profile, not a scalar. Each dimension degrades independently:

| Dimension | What it measures | Key degradation trigger |
|-----------|-----------------|------------------------|
| `syntactic_freshness` | Parser output is current at this commit | File changed without re-parse |
| `behavioral_accuracy` | Entity facts derived from current parse | Fingerprint changed without re-derivation |
| `contextual_accuracy` | Neighbor state matches when this entity was last analysed | **Neighbours changed** — even if this file didn't |
| `edge_coherence` | Topology edge labels match current facts of both endpoints | Either endpoint updated without re-checking edges |
| `cluster_alignment` | Entity's vector distance from its cluster centroid | Semantic drift over time without centroid recalculation |

```json
"confidence_profile": {
  "syntactic_freshness": 1.0,
  "behavioral_accuracy": 0.91,
  "contextual_accuracy": 0.74,
  "edge_coherence": 0.88,
  "cluster_alignment": 0.82,
  "extraction_fidelity": "FULL",
  "confidence_ceiling": 1.0
}
```

- `extraction_fidelity` (FULL / PARTIAL / HEURISTIC) propagates as a **confidence ceiling** — a HEURISTIC file can never have `behavioral_accuracy > heuristic`
- Confidence voting from learning loop: `new_accuracy = old_accuracy + (vote_delta / sqrt(total_votes))` — diminishing returns on repeated votes
- Nodes decay on a configurable half-life without re-validation; decayed nodes queued for re-derivation

### Indexing State Table (completeness tracking)

```sql
CREATE TABLE indexing_state (
  repo_id              TEXT NOT NULL,
  entity_id            TEXT NOT NULL,
  commit_sha           TEXT NOT NULL,
  content_hash         TEXT NOT NULL,
  parse_status         TEXT CHECK (parse_status IN ('pending','done','failed')),
  embed_status         TEXT CHECK (embed_status IN ('pending','done','failed','stale')),
  index_status         TEXT CHECK (index_status IN ('pending','done','failed')),
  extraction_fidelity  TEXT CHECK (extraction_fidelity IN ('FULL','PARTIAL','HEURISTIC')),
  last_source_change   TIMESTAMP,
  last_indexed_at      TIMESTAMP,
  PRIMARY KEY (repo_id, entity_id, commit_sha)
);
-- Completeness query: count WHERE index_status != 'done' per repo_id
-- Staleness query: files where last_source_change > last_indexed_at
```

---

## Data Model

### Canonical Ingestion Facts — `facts.json` IR Contract

The parser produces one `facts.json` per file. This is the ground truth — deterministic, no LLM, no hallucination possible. Every `facts.json` shares a **base schema**; language-specific extractors add their own **extension fields** on top. Downstream consumers (`persist_facts`, `build_graph`, `chunk_file`) read only the fields they understand and ignore the rest.

#### Base schema (present in every `facts.json` regardless of language)

```json
{
  "file_id":       "<sha256>",
  "filename":      "batch_rating.ppc",
  "language":      "proc",
  "fidelity":      "FULL",
  "used_fallback": false,
  "functions":     [],
  "calls":         [],
  "entry_points":  [],
  "imports":       [],
  "raw_text_excerpt": null
}
```

#### Language extension fields (added on top of base schema)

| Language | Extra fields added to `facts.json` |
|---|---|
| Pro\*C / SQL | `sql_statements[]` (category, sql_text, tables[], host_vars[]), `data_flow_edges[]` |
| PowerBuilder | `windows[]`, `datawindows[]`, `events[]`, `pb_objects[]` |
| Python / Java | `classes[]` (methods, base_classes), `decorators[]`, `annotations[]` |
| Config (YAML/JSON/TOML/INI/ENV) | `config_keys[]` (key, value, is_secret_hint), `schema_ref` |
| XML | `elements[]` (xpath, attributes), `namespaces[]` |
| Markdown / RST | `headings[]`, `links[]`, `code_blocks[]` |
| Image (PNG/JPG) | `ocr_text` (from OCR pass), `image_type` (diagram/screenshot/photo) |
| SVG | `elements[]`, `text_content[]`, `viewBox` |
| **Default (fallback)** | `raw_text_excerpt` (first 2000 chars), `line_count`, `token_count` |

#### Example: Pro\*C file (FULL fidelity)

```json
{
  "file_id": "a3f9...", "filename": "batch_rating.ppc",
  "language": "proc", "fidelity": "FULL", "used_fallback": false,
  "functions": [
    {"id": "107374182403", "name": "db_connect", "returnType": "int",
     "complexity": 2, "args": ["user", "pwd"], "start_line": 38, "end_line": 49}
  ],
  "sql_statements": [
    {"id": "30064771088", "line": 53, "enclosing_method": "open_cdr_cursor",
     "category": "READ", "sql_text": "SELECT CDR_ID FROM UNRATED_CDRS WHERE ...",
     "tables": ["UNRATED_CDRS"], "host_vars": []}
  ],
  "calls": [], "entry_points": [], "imports": []
}
```

#### Example: unknown / unrecognised file (HEURISTIC fidelity — DefaultTextExtractor)

```json
{
  "file_id": "b7c2...", "filename": "DEPLOY_NOTES.log",
  "language": "unknown", "fidelity": "HEURISTIC", "used_fallback": true,
  "functions": [], "calls": [], "entry_points": [], "imports": [],
  "raw_text_excerpt": "Deployed build 4.2.1 to PROD on 2026-03-10...",
  "line_count": 142, "token_count": 890
}
```

`used_fallback: true` propagates as `extraction_fidelity = HEURISTIC` in `file_facts` and becomes the confidence ceiling for all downstream results from this file.

This feeds directly into the three storage backends — no serial FSS → FPS → PVG → KAG stages.

### Structured Fact DB Schema (core tables)

```sql
-- Layer 1: one row per file per version
CREATE TABLE file_facts (
    id               TEXT PRIMARY KEY,  -- SHA256(file_id + commit_sha)
    file_id          TEXT NOT NULL,
    commit_sha       TEXT NOT NULL,
    repo_id          TEXT NOT NULL,
    tenant_id        TEXT NOT NULL,
    branch           TEXT NOT NULL,
    language         TEXT,
    is_current       BOOLEAN DEFAULT TRUE,
    execution_model  TEXT,              -- batch|streaming|event|request
    complexity_max   INTEGER,
    complexity_avg   REAL,
    function_count   INTEGER,
    extraction_fidelity TEXT,           -- FULL|PARTIAL|HEURISTIC
    previous_id      TEXT REFERENCES file_facts(id),
    version_distance REAL,             -- cosine distance from previous version vector
    created_at       TIMESTAMP,
    superseded_at    TIMESTAMP
);
CREATE INDEX idx_file_facts_repo_current ON file_facts(repo_id, is_current);

-- Layer 1: table operations (answers "find all files writing FEES_LEDGER" in O(log n))
CREATE TABLE file_tables (
    file_fact_id TEXT REFERENCES file_facts(id),
    table_name   TEXT NOT NULL,
    operation    TEXT NOT NULL,  -- READ|WRITE
    evidence     TEXT,
    line         INTEGER,
    PRIMARY KEY (file_fact_id, table_name, operation)
);
CREATE INDEX idx_file_tables_name ON file_tables(table_name);

-- Layer 2: one row per function per file version
CREATE TABLE function_facts (
    id            TEXT PRIMARY KEY,  -- SHA256(file_id + fn_name + line + commit_sha)
    file_fact_id  TEXT REFERENCES file_facts(id),
    file_id       TEXT NOT NULL,
    function_name TEXT NOT NULL,
    line_start    INTEGER,
    commit_sha    TEXT NOT NULL,
    repo_id       TEXT NOT NULL,
    complexity    INTEGER,
    return_type   TEXT,
    parameters    TEXT,              -- JSON list
    is_entry_point BOOLEAN DEFAULT FALSE,
    is_current    BOOLEAN DEFAULT TRUE,
    created_at    TIMESTAMP,
    superseded_at TIMESTAMP
);
CREATE INDEX idx_fn_facts_file ON function_facts(file_fact_id);

-- Layer 2: call graph (answers "what calls compute_late_fee?" in O(log n))
CREATE TABLE function_calls (
    caller_id   TEXT REFERENCES function_facts(id),
    callee_name TEXT NOT NULL,
    call_type   TEXT DEFAULT 'DIRECT',  -- DIRECT|VIRTUAL|DYNAMIC
    line        INTEGER
);
CREATE INDEX idx_fn_calls_callee ON function_calls(callee_name);

-- Topology edges
CREATE TABLE topology_edges (
    edge_id          TEXT PRIMARY KEY,
    source_file      TEXT NOT NULL,
    target_file      TEXT NOT NULL,
    source_function  TEXT,
    target_function  TEXT,
    edge_type        TEXT NOT NULL,    -- FUNCTION_CALL|WRITE_READ|EXECUTION_SEQUENCE|SHARED_TYPE|IMPORT|STATE_FLOW|CROSS_REPO
    weight           REAL NOT NULL,    -- canonical: 3.0/2.5/2.0/1.0/0.5
    artifact         TEXT,             -- mediating table/type/flag
    signal_type      TEXT,
    confidence       REAL,
    evidence         TEXT,
    commit_sha       TEXT NOT NULL,
    repo_id          TEXT NOT NULL,
    is_valid         BOOLEAN DEFAULT TRUE,
    created_at       TIMESTAMP,
    invalidated_at   TIMESTAMP
);
CREATE INDEX idx_edges_source ON topology_edges(source_file, is_valid);
CREATE INDEX idx_edges_target ON topology_edges(target_file, is_valid);
CREATE INDEX idx_edges_artifact ON topology_edges(artifact);

-- Layer 3: cluster/capability centroids
CREATE TABLE clusters (
    cluster_id       TEXT PRIMARY KEY,
    cluster_name     TEXT,
    repo_id          TEXT,
    tenant_id        TEXT,
    file_count       INTEGER,
    silhouette_score REAL,
    staleness_score  REAL DEFAULT 0.0,
    model_version    TEXT,
    last_updated     TIMESTAMP
);
```

### Vector Index Schema (slim — routing metadata only)

Vectors store **only what is needed for ANN routing**. Full facts are joined from Structured Fact DB by `id` after search (two-hop: ~5ms total).

```
Layer 1 point:
  id:           SHA256(file_id + commit_sha + model_version)
  vector:       float[384]  (or 768 — pending benchmark ADR)
  payload:      {repo_id, cluster_id, is_current, model_version, layer: 1, analysis_tier, fidelity}

Layer 2 point:
  id:           SHA256(file_id + fn_name + line + commit_sha + model_version)
  vector:       float[384]
  payload:      {repo_id, cluster_id, is_current, model_version, layer: 2}

Layer 3 point (centroid):
  id:           SHA256(cluster_id + model_version)
  vector:       float[384]  (centroid of constituent Layer 1 vectors)
  payload:      {repo_id, cluster_id, entity_type: "CLUSTER", model_version, layer: 3, staleness_score}
```

**Key design principles from ECLE 1.0 constitution:**
- The **vector IS the behavioral fingerprint** — `version_distance = cosine(v_current, v_previous)`; distance < threshold → cosmetic commit, skip downstream; distance ≥ threshold → behavioral change, trigger full re-analysis
- **Slim payload** — 10M points × 50 bytes vs. 10M × 2KB; Qdrant payload filters on 4 fields instead of 7+; ANN search stays fast
- **Local ONNX embedding** (mandatory, air-gapped): `all-MiniLM-L6-v2` (384-dim) baseline; benchmark `all-mpnet-base-v2` / `BAAI/bge-base-en-v1.5` at 768-dim before Phase 2; choose based on silhouette score, not spec assumption
- **Collection naming:** `{tenant}__{repo}__layer1`, `{tenant}__{repo}__layer2`, `{tenant}__cross_repo__capabilities`
- **Backend:** ChromaDB local (single-dev) or Qdrant (enterprise) — swappable via `IVectorStore` interface

```python
class IVectorStore(ABC):
    def get_or_create_collection(self, name: str, vector_size: int, distance: str = "cosine") -> ...: ...
    def upsert(self, collection: str, points: list[VectorPoint]) -> None: ...
    def query(self, collection: str, vector: list[float], top_k: int, filters: dict | None = None) -> list[QueryResult]: ...
    def get_vector(self, collection: str, point_id: str) -> list[float] | None: ...
    def delete(self, collection: str, point_ids: list[str]) -> None: ...
    def count(self, collection: str, filters: dict | None = None) -> int: ...

# Implementations: ChromaDBStore (default, wraps ECLE 1.0 ChromaDB), QdrantStore
# Selected via: VECTOR_BACKEND=chromadb|qdrant
```

**Embedding idempotency key:**
```
key = SHA256(entity_id + content_hash + model_name + model_version)
```
Skip re-embed if key already exists in `indexing_state`. Never re-embed unchanged content.


## Technology Stack

| Layer | Technology | Why |
|-------|-----------|-----|
| **Parsing** | Tree-sitter / Joern (all languages) | Language-agnostic; existing grammars; CPG is ground truth |
| **Structured Facts** | SQLite (single-dev) / PostgreSQL (enterprise) | Same schema, different backend; 80% of queries handled here |
| **Events / Queue** | PostgreSQL events table + Celery + Redis | Simple ACID, queryable, replay-safe; Kafka is overkill |
| **Topology Graph** | SQLite recursive CTEs (single-dev) / Neo4j or PG recursive (enterprise) | Edges-only graph; node facts in structured DB |
| **Vector Index** | ChromaDB local (single-dev) / Qdrant (enterprise) | Slim vectors for ANN only; full facts joined from structured DB |
| **Embeddings** | Local ONNX/OpenVINO — mandatory air-gapped default | No internet dependency; cloud embedding is opt-in adapter |
| **Embedding model** | `all-MiniLM-L6-v2` (384-dim) baseline; benchmark 768-dim before Phase 2 | Empirical silhouette score decides, not spec assumption |
| **Query API** | FastAPI + Strawberry GraphQL | Single endpoint; field selection for MCP tools; self-documenting |
| **MCP Server** | Python MCP SDK (stdio / SSE) | Proven PoC pattern; stateless; GraphQL is the contract |
| **DSL/Ontology** | YAML in Git + Neo4j OWL | Version-controlled; code-reviewed; human-readable |
| **Integrations** | GitHub Actions, VS Code plugin, Slack APIs | Native tooling, direct integration |

## Cross-Repo Linking Strategy

**Lessons from PoC:** N² complexity, memory exhaustion, timeout failures

**Solution: Contract-First (not Entity Matching)**

**Process:**
1. Per-repo extraction (independent): Extract contracts (APIs, schemas, events, packages)
2. Global contract registry (one-time): Index all contracts, group by type + name
3. Contract matching (efficient): Find matching contracts cross-repo
4. Transitive closure (lazy): Compute on-demand, not upfront

**Result:** O(C log C) instead of O(N²), where C = contracts << entities

**Failure Handling:**
- Classify each link: resolved, probable, unresolved_external, unknown
- Job doesn't crash → flags for manual review
- Track which heuristics worked → learning signal

## Embedding Strategy

**Hierarchical Embeddings:**
- Entity-level (primary): Functions, classes, SQL, config blocks
- File-level (secondary): Summary per file (coarse filtering)
- Repo-level (optional): Lightweight repo signature

**Micro-Batching (by Token Budget):**
- MAX_ITEMS: 128
- MAX_TOKENS_PER_BATCH: 32K
- MAX_WAIT_MS: 100
- WORKERS: 4-8, auto-scale by queue lag

**Idempotency:**
- Key = hash(entity_id + content_hash + model_version)
- Skip re-embedding if key exists
- Incremental updates only

**Chunking Large Entities:**
- Split at semantic boundaries
- Embed chunks separately
- Optional centroid vector for parent

## Upload Pipeline: Full Event-Driven Flow (SRP)

Every worker has one job. No worker reaches into another worker's domain. Communication is exclusively via events in the PostgreSQL events table.

```
POST /upload  (zip file)
  └─ store zip to disk
  └─ INSERT events (type='source.received', payload={zip_path, upload_id, tenant_id})
  └─ return 202 Accepted + {upload_id}   ←─ API thread ends here

POST /sources/git  (git URL + credentials)
  └─ validate URL + credentials (reject early — only validation the API ever does)
  └─ INSERT events (type='source.received', payload={git_url, ref, tenant_id})
  └─ return 202 Accepted + {source_id}   ←─ API thread ends here

──── SRP: detect repos ──────────────────────────────────────────────────────────────
[scan_source] Celery ─ consumes: source.received
  └─ unzip / git clone to staging area
  └─ walk directory tree; identify repo roots (build files, VCS markers)
  └─ for each repo: INSERT events (type='repo.detected', payload={repo_id, repo_path, languages[], upload_id})
  └─ INSERT events (type='source.scanned', payload={upload_id, repo_count})

──── SRP: parse source → IR artifacts ──────────────────────────────────────────────
[parse_repo] Celery ─ consumes: repo.detected  (one worker per repo, parallel)
  └─ on startup: LanguagePackRegistry.scan("language_packs/")  ←─ loads all manifest.yaml files
  └─ for each file in repo:
       1. ext + shebang sniff → pack = LanguagePackRegistry.get(ext)
            ├─ exact match in any pack's manifest.yaml extensions.source[]
            ├─ shebang fallback for ambiguous extensions
            └─ no match → DefaultPack  (fidelity=HEURISTIC, used_fallback=true)
       2. clean_bytes = pack.sanitize(source_bytes)
            (encoding fix, BOM strip, language-specific transforms — no-op if sanitizer absent)
       3. if pack.manifest.fast_extraction.enabled:
            tree_sitter.Parser(pack.grammar).parse(clean_bytes)  ←─ in-process, ~1–5ms
            facts = pack.fast_extractor.extract(tree, clean_bytes, file_path)
            facts["_extraction_tier"] = "structural"
          else:  ←─ DefaultPack or grammar package not installed
            facts = pack.fast_extractor.extract(clean_bytes, file_path)
            facts["_extraction_tier"] = "text"
            facts["used_fallback"] = true
       4. write artifacts/{tenant_id}/{repo_id}/{file_rel_path}.facts.json
       5. INSERT events (type='file.ir_produced', payload={
               artifact_path, file_id, repo_id, language,
               fidelity,        ←─ from pack.manifest.fast_extraction.fidelity
               used_fallback,   ←─ true only for DefaultPack
               content_hash, commit_sha})
  └─ INSERT events (type='repo.ir_produced', payload={repo_id, file_count,
          failed_count, fallback_count})
  NO DB writes. NO vector writes. NO graph writes.

──── file.ir_produced fans out — all three fire in parallel ─────────────────────────

──── SRP: IR → Structured Fact DB ──────────────────────────────────────────────────
[persist_facts] Celery ─ consumes: file.ir_produced
  └─ read facts.json from artifact_path in event payload
  └─ INSERT into file_facts, function_facts, file_tables, function_calls,
              function_table_ops, file_entry_points
  └─ INSERT events (type='file.stored', payload={file_id, repo_id})

──── SRP: IR → Neo4j graph ──────────────────────────────────────────────────────────
[build_graph] Celery ─ consumes: file.ir_produced
  └─ read facts.json from artifact_path
  └─ MERGE function nodes, file nodes, CALL edges, TABLE_ACCESS edges in Neo4j
  └─ INSERT events (type='graph.updated', payload={file_id, node_count, edge_count})

──── file.stored fans out — both fire in parallel ───────────────────────────────────

──── SRP: structured facts → text chunks ────────────────────────────────────────────
[chunk_file] Celery ─ consumes: file.stored
  └─ read function_facts + file_facts for file_id from Structured Fact DB
  └─ split by semantic boundary (max one function per chunk) within token budget
  └─ write artifacts/{tenant_id}/{repo_id}/{file_id}.chunks.json
  └─ INSERT events (type='file.chunked', payload={file_id, chunk_count, artifact_path})

──── SRP: structured facts → DSL concept tags ───────────────────────────────────────
[detect_dsl_mappings] Celery ─ consumes: file.stored
  └─ read file_facts / function_facts for file_id from Structured Fact DB
  └─ match entity names against DSL registry YAML
  └─ write dsl_concept tags back to structured DB
  └─ INSERT events (type='dsl.mapped', payload={file_id, concepts[]})

──── SRP: text chunks → vectors ─────────────────────────────────────────────────────
[batch_embed] Celery ─ consumes: file.chunked  (micro-batched by token budget)
  └─ read chunks from artifact_path
  └─ ONNX/OpenVINO local embedding model → float[384] per chunk
  └─ Layer 1: centroid of chunk vectors → upsert one slim vector per file version
  └─ Layer 2: per-function chunk → upsert one slim vector per function version
  └─ INSERT events (type='file.embedded', payload={file_id, model_version, vector_ids[]})

──── SRP: graph → topology signal edges ─────────────────────────────────────────────
[compute_topology] Celery ─ consumes: graph.updated
  └─ run 9 signal detectors against Neo4j neighbourhood for file_id
  └─ upsert topology_edges in Structured Fact DB
       (FUNCTION_CALL, WRITE_READ, EXECUTION_SEQUENCE, SHARED_TYPE, STATE_FLOW, …)
  └─ INSERT events (type='topology.updated', payload={file_id, edge_count})

──── downstream (one-per-repo or one-per-source) ────────────────────────────────────
[ontology_enricher]      Celery ─ consumes: dsl.mapped
[cluster_centroids]      Celery ─ consumes: file.embedded
[build_contract_registry] Celery ─ consumes: repo.ir_produced  (once per repo)
[link_contracts]          Celery ─ consumes: source.scanned    (once all repos done)
```

**The API only knows about:** `source.received`  
**Tree-sitter only runs inside:** `parse_repo` — its only output is `facts.json` artifact files  
**Structured DB is populated by:** `persist_facts` — not by the parser  
**Neo4j is populated by:** `build_graph` — not by the parser  
**Embedding inputs are chunks** produced by `chunk_file` — not raw facts or raw source

**Timeline:**
- Small (1 repo, 100 files): 5–10 min
- Medium (3 repos, 1K files): 15–30 min
- Large (10 repos, 10K files): 30–60 min

## Implementation Phases

> **SDLC rule:** No phase begins without written specs in `specs/phase-N/`. No implementation without a spec. See SDLC Contract.

### Phase 1: Foundation — Interfaces + Structured DB (Weeks 1-3)
**Goal:** Abstract all backends behind interfaces; structured schema working; ECLE 1.0 reference impl usable
- Define and implement `IVectorStore` interface; wrap ECLE 1.0 ChromaDB as `ChromaDBStore`
- Define and implement `IStructuredDB` interface; SQLite implementation as `SQLiteBackend`
- Define `ITopologyGraph` interface; SQLite recursive CTE implementation
- Implement `facts_loader.py`: parse `*.facts.json` → insert into `file_facts`, `function_facts`, `file_tables`, `function_calls`, `topology_edges`
- ZIP upload endpoint + `scan_upload` / `ingest_repo` Celery tasks
- Local ONNX embedding worker (`batch_embed`) — no cloud API, air-gapped
- **Deliverable:** Import a repo; query `fact_find_files`, `fact_find_callers`, `fact_find_tables` via MCP tools returning FACT envelope
- **Verification:** Post-import smoke test: `ecle import` → stats > 0 → `fact_find_callers` returns results → `fact_search` returns results

### Phase 2: Vector Layers + Embedding Benchmark (Weeks 4-5)
**Goal:** Three-layer vector index working; embedding model decided by benchmark
- Run embedding benchmark (ADR-002): `all-MiniLM-L6-v2` vs `all-mpnet-base-v2` vs `BAAI/bge-base-en-v1.5`; measure silhouette score + RAM; write ADR with result
- Implement Layer 1 vectors (file-level): `FSSVectorManager`, `embed_fss()`, version chain (`version_distance`)
- Implement Layer 2 vectors (function-level): function behavioral signature embedding
- Change-detection gate: `version_distance < BEHAVIORAL_THRESHOLD` → skip downstream processing
- Multi-language extractors: Java, JavaScript, SQL, config
- **Deliverable:** `fact_search` uses Layer 1/2 vectors; `fact_find_similar` works; cosmetic commits skip re-embedding
- **Verification:** Refactor Invariance eval — cosmetic rename → `version_distance < 0.05`, no re-embed fired

### Phase 3: Topology + GraphQL Engine (Weeks 6-7)
**Goal:** Graph traversal working; GraphQL endpoint live; query planner routes 80/20
- Topology edge computation from CPG facts (deterministic, 9 signal detectors from ECLE 1.0)
- `ITopologyGraph` PostgreSQL recursive CTE implementation (upgrade from SQLite)
- FastAPI + Strawberry GraphQL endpoint; query planner (structured → vector → graph routing)
- `fact_impact`, `fact_trace_path`, `fact_trace_data` MCP tools
- `indexing_state` table + completeness check on every GraphQL response
- Coverage warnings in FACT envelope
- **Deliverable:** `fact_impact(file_id)` returns multi-hop impact report; GraphQL schema validates

### Phase 4: DSL + Ontology + Cluster Layer 3 (Weeks 8-9)
**Goal:** Business vocabulary layer; Layer 3 cluster/capability vectors
- DSL aligner (entity → concept mapping via YAML registry)
- Ontology enricher (inference rules)
- Layer 3 vectors: `CentroidManager`, incremental centroid updates, `silhouette_score` tracking
- `cluster_alignment` confidence dimension activated
- DSL concept search in MCP + GraphQL
- Staleness Contract implementation: staleness score on every cluster; `staleness_caveat` in envelope
- **Deliverable:** `fact_view_database`, `fact_view_api_contracts` MCP views; DSL concept search works

### Phase 5: Cross-Repo + Grounding + Learning (Weeks 10-11)
**Goal:** Multi-repo linking; grounding verifier; feedback loop
- Cross-repo contract registry + contract-first matching (CROSS_REPO topology edges)
- Grounding verifier: LLM summary sentences verified against structured facts; `HALLUCINATION_BLOCKED` events logged
- Feedback collector (PR reviews, deployment events)
- Learning/analytics engine + recommendation scoring
- GitHub Actions integration (PR check comments)
- **Deliverable:** Cross-repo `fact_impact` works; LLM summaries pass grounding verifier; recommendations appear in PRs

### Phase 6: Scale-Out + Production (Weeks 12+)
**Goal:** Enterprise deployment; Qdrant upgrade path; full observability
- Qdrant backend (`QdrantStore`) via `IVectorStore`; PostgreSQL backend via `IStructuredDB`; Neo4j via `ITopologyGraph`
- `VECTOR_BACKEND` / `STRUCTURED_BACKEND` / `GRAPH_BACKEND` config-driven swap
- User dashboard: ZIP upload, Git repo source configuration, job status, coverage per repo
- IDE plugin (VS Code), Slack/Teams bot
- Production deployment (K8s workers, managed Neo4j Aura)
- Performance optimisation: DataLoader batching in GraphQL, query result caching
- **Deliverable:** Single-machine → enterprise swap via config; full dashboard live

## Critical Decisions & Trade-offs

| Decision | Choice | Rationale | Alternative |
|----------|--------|-----------|-------------|
| **Event backbone** | PostgreSQL + Celery (not Kafka) | Simpler ops, sufficient scale, easier debug | Kafka: overkill complexity |
| **Structured DB** | SQLite (single-dev) / PostgreSQL (enterprise) — same schema | Same code path; no special-casing | Two schemas: maintenance burden |
| **Topology storage** | Edges-only; node facts in structured DB | Graph stays lean; traversal fast; facts always fresh from structured DB | Storing node props in graph: dual source of truth |
| **Search routing** | 80% structured DB / 20% vector; query planner decides | Structured lookups 10–100× faster than vector payload filters | Force everything through vector: slow and wasteful |
| **Vector payload** | Slim (routing only); facts in structured DB | 10M × 50B vs 10M × 2KB; payload filters on 4 fields stay fast | Fat payload: degrades ANN at scale |
| **Embedding default** | Local ONNX/OpenVINO (air-gapped) | Enterprise compliance; no internet dependency; cost-free | Cloud API: blocks air-gapped deployments |
| **Confidence model** | 5-dimension profile (not scalar) | `contextual_accuracy` catches neighbour-change staleness a scalar misses | Scalar blend: hides silent stale answers |
| **Query interface** | GraphQL (not REST) | Field selection flexibility; self-documenting; proven in PoC with MCP; single endpoint | REST: multiple routes, over-fetching |
| **AI consumption** | MCP server over GraphQL | Proven PoC pattern; decouples AI tool interface from backend; agents get FACT-compliant responses | Direct DB access: no contract |
| **Cross-repo linking** | Contract-first (not entity matching) | Avoids N² complexity, learned from PoC | Entity matching: O(N²) fails |
| **Transitive closure** | Lazy (not eager) | Avoid memory explosion, compute on-demand | Eager: exhausts RAM at scale |
| **Failure handling** | Classify (don't crash) | Graceful degradation, enable learning | Crash: blocks pipeline |
| **Embedding unit** | Entity-level primary + file-level secondary | Precision vs speed tradeoff | Entity-only: too granular; file-only: too coarse |
| **Vector payload** | Slim (routing only); facts in structured DB | 10M × 50B vs 10M × 2KB; payload filters on 4 fields stay fast | Fat payload: degrades ANN at scale |
| **Embedding default** | Local ONNX/OpenVINO (air-gapped) | Enterprise compliance; no internet dependency; cost-free | Cloud API: blocks air-gapped deployments |
| **Confidence model** | 5-dimension profile (not scalar) | `contextual_accuracy` catches neighbour-change staleness a scalar misses | Scalar blend: hides silent stale answers |
| **DSL/Ontology** | YAML in Git + Neo4j | Version-controlled, code-reviewed, human-readable | Database-only: hard to version |

---

## Grounding Contract

**Every LLM-generated claim in ECLE MUST cite the structural evidence it was derived from.**

| Layer | What is grounded | Grounded against | Verifier cost |
|-------|-----------------|------------------|--------------|
| CPG/facts.json | File-level facts | Source code (deterministic parse) | Zero LLM — deterministic |
| Structured Fact DB | Function/table claims | `file_facts`, `function_facts` | Zero LLM — relational query |
| DSL mapping | Concept assignments | DSL registry YAML + entity names | Zero LLM — pattern match |
| Topology edges | Relationship labels | facts.json `control_flow_edges`, `data_flow_edges` | Zero LLM — deterministic |
| LLM summaries | Capability narratives | Structured facts + topology | LLM verifier rejects uncited sentences |
| MCP responses | Tool answers | All of the above | Confidence profile always attached |

**Rejection rules:**
1. A claim without a citation → **rejected** by automated verifier → logged as `HALLUCINATION_BLOCKED`
2. A claim whose citation does not exist in the source artifact → **rejected**
3. LLM narrative sentences with no factual citation → replaced with `"⚠ Gap — insufficient evidence"`

**The stack:**
```
Layer 0 (facts.json):  ground truth — deterministic, no LLM, no hallucination possible
Layer 1 (Structured):  LLM-free — relational derivation only
Layer 2 (Topology):    LLM-free — deterministic edge computation from facts
Layer 3 (Summaries):   LLM-generated — grounded in Layer 0-2, verifier rejects uncited
Layer 4 (MCP answers): Composed from Layer 0-3; confidence profile always declared

Hallucination can enter at Layer 3 — it cannot survive the verifier.
```

---

## Staleness Contract

**The system NEVER silently serves a stale answer as if it were fresh.**

Every response includes `knowledge_current_as_of` and a staleness score. Behaviour is determined by score:

| Staleness Score | Action |
|----------------|--------|
| < 0.1 | Serve cached, no caveat |
| 0.1 – 0.3 | Serve with staleness caveat; queue re-synthesis |
| > 0.3 | Serve with WARNING; trigger immediate re-synthesis |
| NEVER | Block response waiting for synthesis — always serve with honest declaration |

**Hard gate: a system returning `confidence = 1.0` on stale knowledge is WORSE than one returning nothing.**
The Staleness Honesty eval is a blocking CI gate. Failure = system is unusable.

```json
"system_status": {
  "degradation_level": "FULL_SERVICE | DEGRADED_FRESHNESS | DEGRADED_SEARCH | DEGRADED_GRAPH | STORAGE_FAILURE",
  "knowledge_current_as_of": "2026-05-05T09:58:00Z",
  "staleness_caveat": "legacy-core repo: embed job pending for 142 files (last commit 8 min ago)"
}
```

**Proportional staleness at cluster level:**
```
staleness_increment = delta_magnitude / total_files_in_cluster
```
Cluster re-synthesis triggers when: accumulated staleness > 30%, OR a query hits this cluster with non-zero staleness, OR a file is explicitly invalidated.

---

## Key Lessons from PoC

**What failed:**
1. **N² complexity kills performance** → Use contracts as indexed lookups
2. **Per-repo coordination** is complex → Make repos independent, link globally
3. **Eager transitive closure** exhausts memory → Compute on-demand + memoize
4. **Job failures block pipeline** → Classify unresolved, don't fail
5. **Kafka overkill** for internal tool → PostgreSQL + Celery simpler
6. **Entity-level embeddings** → balance precision with scale via hierarchy
7. **No team vocabulary** → Add DSL + ontology layers post-parsing

**What worked (carry forward):**
8. **MCP → GraphQL search endpoint** → proven pattern; AI agents consumed code knowledge cleanly via MCP tools backed by GraphQL; retain and formalise in ECLE 2.0

## Success Metrics

- **Ingest:** 1K–10K files/hour; <1% job failure rate; O(changed_files) incremental updates
- **Search:** <500ms p95 for structured queries; <200ms p95 for vector ANN search
- **FACT compliance:** Staleness Honesty eval passes (hard gate); Grounding Coverage eval passes (hard gate)
- **Confidence:** 5-dimension profile present on every result; no result served with `confidence = 1.0` on stale data
- **Completeness:** <5% unresolved entities (classified); coverage warnings present when partial
- **Recommendations:** >70% acceptance rate (tracked via learning loop)
- **Cross-repo linking:** >90% accuracy (spot-checked); O(C log C) matching time
- **Cluster quality:** Silhouette score > 0.65 on cluster cohesion eval
- **Operations:** 99.5% availability; <1min MTTR; zero silent stale answers

---

## SDLC Contract

**Spec before code. Always. No implementation begins without a written spec.**

Every feature follows: `Spec → Implement → Test → Review → Merge`

```
1. PLAN   — Task Planner decomposes work into small dependency-ordered tasks
            Each task maps to one PR, one logical change, completable in 1–3 days
2. SPEC   — Written spec in specs/phase-N/SPEC-NNN-name.md before any code
            Spec defines: interface, behaviour, tests, dependencies
3. BRANCH — phase-{N}/{layer}-{feature}; short-lived (< 1 week); branch from main
4. CODE   — Code + tests together (never tests after); type hints on all public interfaces
            ruff check + ruff format before every commit; no magic numbers
5. PR     — Max 500 lines changed (excluding tests); CI must pass Stage 1 + Stage 2
6. REVIEW — 7-point checklist; no LGTM-only reviews; Security review if new deps/endpoints
7. MERGE  — Squash merge; delete branch; tag at phase completion
```

**Non-negotiable rules (from ECLE 1.0 post-mortems):**
1. No direct commits to main
2. No merge with failing CI
3. No hardcoded values — config or constants
4. No secrets in code — environment variables only
5. No orphan data paths — if a spec creates a table, the ingestion pipeline MUST populate it (schema without writes is a bug)
6. End-to-end smoke test after every import-related change: `ecle import` → stats > 0 → `fact_find_callers` → `fact_search` — empty results = gap
7. Cross-cutting spec review — if Spec A reads from X and Spec B writes to X, both must reference each other; reviewer verifies write path exists before approving read path

---

## Testing Contract

### Test Pyramid

```
     /   E2E   \          10% — Full pipeline, live LLM (nightly only)
    /------------\
   / Integration  \       20% — Cross-layer, real SQLite/ChromaDB (every PR)
  /----------------\
 /   Unit Tests     \     70% — Single module, deterministic, < 100ms (every PR)
/--------------------\
```

### Coverage Requirements

| Code Category | Minimum Coverage |
|---------------|-----------------|
| New code (any module) | 80% line coverage |
| Core interfaces (`IVectorStore`, `IStructuredDB`, `ITopologyGraph`) | 95% |
| Grounding verifiers | 100% — safety-critical, incorrect verification = hallucination passes |
| Existing code | No regression — coverage only goes up |

### Performance Benchmarks (CI-enforced)

| Operation | Target | Gate |
|-----------|--------|------|
| Structured fact lookup (single file) | < 10ms | CI fails if exceeded |
| Topology traversal (2-hop impact) | < 50ms | CI fails if exceeded |
| Vector ANN search (top-10) | < 100ms | CI fails if exceeded |
| Full commit path (no LLM) | < 500ms | CI fails if exceeded |
| Regression tolerance | < 10% degradation from baseline | Alert |

### Eval Suites (Hard CI Gates — not optional)

| Eval | Pass Criteria | When |
|------|--------------|-------|
| **Refactor Invariance** | Cosmetic rename → `version_distance < 0.05`; zero re-embeds fired | Every PR |
| **Semantic Drift** | Logic change → `version_distance ≥ threshold`; downstream processing fires | Every PR |
| **Staleness Honesty** | Zero results with `confidence = 1.0` on stale knowledge | Nightly — **hard gate** |
| **Grounding Coverage** | Zero ungrounded LLM claims pass verifier | Nightly — **hard gate** |
| **Cluster Cohesion** | Silhouette score > 0.65 on reference repo | Nightly |
| **Post-Import Smoke** | `fact_find_callers` + `fact_search` return non-empty after import | Every PR touching ingestion |
```

## Implementation Phases

### Phase 1: Foundation - Knowledge Graph & Static Analysis (Weeks 1-3)
1. Set up Neo4j + create schema (Files, Classes, Functions, CodeSmells, Patterns)
2. Build tree-sitter integration + language-specific extractors
3. Implement rule-based analysis:
   - High coupling detector (functions calling many others)
   - Dead code detector (unreferenced functions)
   - Large function detector (LOC > threshold)
   - Call graph complexity (cyclomatic, dependency depth)
4. Parse one codebase, extract entities + detect smells
5. **Verification:** Dashboard showing all CodeSmells in a project

### Phase 2: Feedback Collection & Learning Infrastructure (Weeks 4-5)
1. Build feedback collection layer:
   - GitHub API integration (parse PR reviews, comments, approvals)
   - Extract sentiment/signals: "This is a bad smell", "I disagree", "LGTM"
   - Map feedback to code entities (which line, function, file)
2. Create feedback schema:
   - `Feedback(text, type[positive|negative|deferred], confidence, reviewer, timestamp)`
   - RESPONDS_TO relationship (Feedback → Recommendation)
3. Build outcome tracking:
   - Monitor deployment success rates
   - Track bug reductions after refactoring
   - Measure performance improvements post-optimization
4. **Verification:** Collect feedback from 10 PRs, verify mapping accuracy

### Phase 3: Pattern Mining & Recommendation Scoring (Weeks 6-7)
1. Implement pattern mining:
   - Cluster similar CodeSmells → identify patterns (e.g., "service layer too fat")
   - Extract successful refactoring patterns from history
   - Find team-specific standards (naming conventions, architecture style)
2. Build recommendation scoring:
   - For each CodeSmell, generate recommendation(s)
   - Score by: impact (severity), effort (LOC to fix), team adoption (% positive feedback)
   - Learn team preferences: Do they prefer small refactorings or big rewrites?
3. Implement basic ML models:
   - Logistic regression: Will developer accept this recommendation? (features: type, impact, team, recent_similar)
   - Outcome predictor: Will this refactoring reduce bugs? (features: codebase history)
4. **Verification:** Generate recommendations for 5 files, validate against team experience

### Phase 4: Integration with Developer Workflow (Weeks 8-9)
1. GitHub Actions integration:
   - PR check: Auto-comment with CodeSmells + recommendations for changed files
   - Trigger on: pull_request_opened, synchronize
   - Format: Markdown comment with severity levels
2. IDE plugin (VS Code):
   - Real-time CodeSmell highlighting
   - Hover to see recommendation + success rate
   - One-click feedback: "This is wrong", "I agree", "Fix it"
3. Slack/Teams bot:
   - Daily digest: "3 high-impact improvements ready for your team"
   - Trend alerts: "Code quality declined this week"
4. Dashboard backend:
   - REST API endpoints for each persona
5. **Verification:** Run full workflow on 1 PR: detection → feedback → learning cycle

### Phase 5: Personalization & Continuous Learning (Weeks 10-11)
1. Implement persona-specific dashboards:
   - **Developer:** My recommendations, feedback history, learning streak
   - **Team Lead:** Team patterns, adoption rate, quality trends, blockers
   - **Architect:** System-wide dependencies, refactoring roadmap, technical debt ROI
   - **DevOps:** Deployment impact metrics, reliability trends
   - **Security:** Vulnerability patterns, compliance gaps
2. Build ML feedback loop:
   - Retrain models weekly on new feedback/outcomes
   - A/B test recommendations (variant A vs B for similar entities)
   - Track "recommendation drift" (does system still match team values?)
3. Implement context-aware scoring:
   - Adjust recommendation urgency based on: sprint velocity, team capacity, project deadline
   - Personalize by: developer skill level, team preferences, project criticality
4. Create learning metrics dashboard:
   - Feedback acceptance rate by recommendation type
   - Outcome improvement rate (% of applied recommendations that reduced technical debt)
   - Team-specific patterns (what works for this team)
5. **Verification:** Team uses dashboard daily, system predicts acceptance with >70% accuracy

### Phase 6: Scale & Automation (Weeks 12+)
1. Production deployment:
   - Managed Neo4j (Aura) + Kafka cluster
   - Multi-codebase ingestion (K8s workers)
   - Model serving (MLflow or SageMaker)
2. Continuous learning loop:
   - Daily: Re-ingest changed files, score recommendations
   - Weekly: Retrain ML models, analyze trends
   - Monthly: Generate refactoring roadmap, team retrospective
3. Advanced features:
   - Anomaly detection (unusual code patterns emerge)
   - Cross-team learning (share successful patterns across orgs)
   - Autonomous suggestions (system proposes full refactorings, awaits approval)
4. Monitoring:
   - Ingestion health, model accuracy, recommendation adoption
   - Business metrics: Technical debt reduction, deployment frequency, bug rate

## Relevant Files to Create/Modify
- `core/data_model.py` - Neo4j schema definitions (labels, constraints)
- `extractors/base.py` - Abstract TreeWalker
- `extractors/powerbuilder.py` - PowerBuilder extractor (reuse grammar_eval.py logic)
- `extractors/python.py`, `extractors/java.py`, etc.
- `ingestion/kafka_producer.py` - Event emission
- `ingestion/kafka_consumer.py` - Event processing
- `ingestion/neo4j_writer.py` - Batched graph writes
- `analysis/migration.py` - Pattern detection, task generation
- `api/neo4j_queries.py` - Cypher query library
- `api/rest_server.py` - Flask/FastAPI REST endpoints
- `docker-compose.yml` - Local dev setup

## Verification Strategy
1. **Unit level:** Verify parser extracts correct entities from test code snippets
2. **Integration level:** Ingest single codebase, run Cypher queries, validate results
3. **End-to-end:** Multi-codebase, multi-language, run migration analysis, manual review
4. **Load test:** Performance on 1M+ LOC (batch ingestion, query times)
5. **Correctness:** Compare extracted call graph to manual code review (spot check)

## Decisions & Trade-offs
1. **Neo4j vs. alternatives:**
   - Neo4j: Native graph DB, excellent for relationship queries + pattern matching
   - Alternative: Postgres + JSON relationships (more familiar, slower on complex paths)
   - Decision: Neo4j (relationship performance is critical for dependency analysis)

2. **Kafka vs. direct writes:**
   - Kafka: Event-driven, async, fault-tolerant, replay capability
   - Alternative: Synchronous batch writes (simpler, less scalable)
   - Decision: Kafka (enables 10+ parallel workers, handles large codebases)

3. **Language coverage:**
   - Start with PowerBuilder + Python (your existing grammar + most migrations use Python)
   - Add Java, JavaScript later (tree-sitter has good grammars)
   - SQL parsing from schema files (not executing)

4. **Call graph resolution:**
   - **Hard problem:** Dynamic dispatch, reflection, polymorphism
   - Strategy: Best-effort (annotate unresolved), flag for manual review
   - For PowerBuilder: Good fit (mostly static, less OOP complexity)

## Further Considerations
1. **Should we build a UI dashboard for visualization?** Recommend: Yes, for exploration. Use D3.js or Cytoscape for graph visualization. Start in Phase 5 as lower priority.

2. **How to handle external dependencies?** Recommend: Version your knowledge graph (git-like snapshots). Store dependency metadata separately, link to online registries (npm, Maven Central) when available.

3. **Incremental updates—should the graph support live code changes?** Recommend: Design for it from start (event-driven). Implement file-watch + re-ingestion in Phase 6 (nice-to-have for initial MVP).
