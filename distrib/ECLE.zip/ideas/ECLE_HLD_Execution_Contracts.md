# ECLE 2.0 — High Level Design: Execution Contracts

## 1. Purpose
Defines system guarantees and deterministic behavior across all components.

---

## 2. Ingestion Contract
- Idempotent processing
- No duplicate states
- Retry-safe execution
- Failure → DLQ

---

## 3. Version Activation Contract
- Version visible only after full sync
- Controlled by consistency barrier

---

## 4. Cross-Store Consistency Contract
- Structured DB, Graph DB, Vector DB must align
- No partial reads allowed

---

## 5. Query Contract
- Must satisfy **FACT** on every response:
  - **Fast:** Bounded latency — ANN search + capped graph traversal; 2s hard timeout returns partial with declaration
  - **Accurate:** 5-dimension confidence profile attached to every result; stale/low-confidence results flagged, never silently included; grounding verifier blocks uncited claims
  - **Complete:** Pre-query coverage check against `indexing_state`; missing entities declared in `coverage_warnings`; no silent gaps
  - **Trustworthy** — umbrella of two sub-properties, both must pass:
    - **Timely:** `knowledge_current_as_of` on every response; staleness score drives serve/caveat/warn; never block — always serve with honest declaration
    - **Traceable:** Every result carries full `lineage` (source → parser → embedding → index); query plan recorded; `trace_id` links full execution chain; missing lineage → result degraded, surfaced in envelope
- Must be version-consistent (no results from partially-activated versions)

---

## 6. Trustworthiness Contract
- **Timely:** system never silently serves stale knowledge as fresh (see Staleness Contract)
- **Traceable:** every response includes lineage; missing trace → reject or degrade, never silently omit
- A system returning `confidence = 1.0` on stale or untraced knowledge fails this contract
- Staleness Honesty eval + Grounding Coverage eval are both hard CI gates for this contract

---

## 7. Change Intelligence Contract
- Every version change produces structured events
- Impact must be computed

---

## 8. Rule Intelligence Contract
- Extract business logic
- Normalize to IF/THEN
- Maintain version history

---

## 9. Interaction Contract
- Every query must be traceable
- Full execution chain recorded
- Replay supported

---

## 10. Orchestration Responsibilities
- Event routing
- Ordering enforcement
- Retry management
- Progress tracking

---

## 11. Consistency Barrier
- facts_written
- edges_written
- vectors_written
- commit_complete

Only then → activate version

---

## 12. Failure Scenarios

### Partial Failure
- Do not activate version

### Replay
- Idempotent processing ensures safety

### Unknown Files
- Process via Tier 0
- Maintain visibility

---

## 13. System Guarantee Statement
ECLE guarantees deterministic, **Trustworthy** (Timely + Traceable), and version-consistent system intelligence under continuous event-driven updates.
