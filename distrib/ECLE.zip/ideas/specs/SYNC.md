# Spec-Code Sync — Keeping Design Intent Alive

## The Problem

Specs capture design intent. Code evolves. They drift. The nuances of WHY something was designed a certain way get lost when the spec says one thing and the code does another.

## The Hybrid Approach

Specs have three sections with different staleness rules:

```
SECTION           | LIVES IN           | SYNCED HOW
──────────────────|────────────────────|──────────────────────────
Purpose + ADRs    | Spec file          | Rarely changes. Updated only on redesign.
Interface         | Spec file + code   | SYNCED: spec lists methods, code has them.
Behavior rules    | Spec file + tests  | SYNCED: spec lists rules, tests prove them.
Decisions/nuances | Spec file ONLY     | Never stale — captures design-time thinking.
Implementation    | Code ONLY          | Spec doesn't track internal implementation.
```

### What Gets Synced (the contract)

The spec's **Interface** section lists public classes and methods. The code must have them. If code adds a new public method, the spec's Interface is updated. If code removes one, spec is updated.

The spec's **Behavior** section lists rules (e.g., "idempotent — same input twice produces same state"). Each rule maps to a test. If a new behavior is added, a rule + test are added to the spec. If a behavior changes, the rule is updated.

### What Doesn't Get Synced (the reasoning)

The spec's **Purpose**, **ADR References**, and **Decisions** sections capture WHY. These don't change when code changes — they change when the design intent changes. That's rare and deliberate (new ADR).

### What Lives Only in Code

Internal implementation details — private methods, helper functions, SQL query specifics, error handling mechanics. The spec doesn't care HOW, only WHAT and WHY.

## Sync Mechanism

### 1. Spec Header — Tracks Sync State

Every spec gets a sync block:

```markdown
## Sync

Last verified: 2026-04-03
Code files: src/ecle/backends/structured/sqlite.py
Interface drift: NONE
Behavior drift: NONE
Enhancements since spec:
  - upsert_many() added for edge recomputation (not in original spec)
  - Split lazy loading for MCP startup performance
```

This is updated whenever code changes. It's a CHANGELOG for the spec — what evolved beyond the original design.

### 2. Module Docstrings — Reference the Spec

Every implementation file starts with:

```python
"""
SQLite backend — structured fact store for single-developer and MVP mode.

Implements SPEC-002. Same schema migrates to PostgreSQL for enterprise (ADR-002).

Enhancements beyond spec:
  - upsert_many(): INSERT OR REPLACE for edge recomputation
  - retire_file()/purge_file(): soft and hard deletion (ADR-014)
"""
```

The "Enhancements beyond spec" section is the bridge. When you read the code, you know what was designed vs what was added during implementation.

### 3. Automated Sync Check

A script that validates:

```
For each SPEC-NNN:
  1. INTERFACE CHECK: every class/method listed in spec → grep in code files
     → PASS: all found
     → DRIFT: spec lists method X, code doesn't have it (or vice versa)

  2. BEHAVIOR CHECK: every test listed in spec → grep in test files
     → PASS: all tests exist
     → DRIFT: spec lists test_X, test file doesn't have it (or has new ones)

  3. FILES CHECK: every file listed in spec → exists on disk
     → PASS: all exist
     → DRIFT: file renamed or moved

Output:
  SPEC-001: SYNCED (interface: 12/12, behavior: 0 tests listed, files: 1/1)
  SPEC-002: DRIFT (interface: +1 upsert_many not in spec, behavior: 18/18, files: 1/1)
  SPEC-003: SYNCED (interface: 4/4, behavior: 18/18, files: 1/1)
  ...
```

### 4. When to Sync

```
DURING implementation (same PR):
  → Adding a public method? Add to spec Interface.
  → Adding a behavior rule? Add to spec Behavior + Tests.
  → Quick fix / internal change? Just note in spec's "Enhancements since spec" block.

BEFORE next phase starts:
  → Run sync check script
  → Update any DRIFT specs
  → This is the "spec reconciliation pass"

ON code review:
  → Code Reviewer checks: "Is the spec updated for this change?"
  → Not line-by-line — just: "Did the interface or behavior change? If yes, is the spec aware?"
```

## What This Preserves

The thing you're worried about — implementation nuances getting lost — is captured in two places:

1. **Spec "Enhancements" section**: what was added beyond the original design and why
2. **Module docstring "Enhancements" section**: same info, right next to the code

Neither goes stale silently because:
- The sync check catches interface/behavior drift automatically
- The "Enhancements" section is append-only (you add, never remove)
- The Code Reviewer asks "is the spec aware?" on every PR

---

## Spec Status Register

**Last verified: 2026-04-07** by code-reviewer agent (26/26 gap items passed).

### Week 1 (Foundation)

| Spec | Title | Status | Verified |
|------|-------|--------|----------|
| SPEC-001 | Structured DB Schema | IMPLEMENTED | 2026-04-01 |
| SPEC-002 | SQLite Backend | IMPLEMENTED | 2026-04-01 |
| SPEC-003 | Facts Loader | IMPLEMENTED | 2026-04-01 |
| SPEC-004 | Topology Edges | IMPLEMENTED | 2026-04-01 |
| SPEC-005 | Behavioral Signature + Vectors | IMPLEMENTED | 2026-04-01 |
| SPEC-006 | GraphQL Schema | IMPLEMENTED | 2026-04-01 |
| SPEC-007 | CLI import + serve | IMPLEMENTED | 2026-04-01 |
| SPEC-008 | MCP Server | IMPLEMENTED | 2026-04-01 |

### Week 2 (Query + UI)

| Spec | Title | Status | Verified |
|------|-------|--------|----------|
| SPEC-009 | Git Repo Onboarding | IMPLEMENTED | 2026-04-06 |
| SPEC-010 | Git Continuous Ingestion | IMPLEMENTED | 2026-04-06 |
| SPEC-011 | Document Onboarding (Tier 3) | IMPLEMENTED | 2026-04-07 — blockers fixed: api_endpoints table, chunker overlap, FK extraction, code blocks |
| SPEC-012 | Web UI | IMPLEMENTED | 2026-04-06 — LLM chat deferred to SPEC-019 |
| SPEC-013 | Settings & Config | IMPLEMENTED | 2026-04-04 |

### Week 3 (Cross-Repo + Clustering)

| Spec | Title | Status | Verified |
|------|-------|--------|----------|
| SPEC-014 | Shared Artifact Registry | IMPLEMENTED | 2026-04-04 |
| SPEC-015 | Cross-Repo MCP Tools | IMPLEMENTED | 2026-04-05 — ADR-027 gaps fixed |
| SPEC-016 | Close Week 2 Gaps | IMPLEMENTED | 2026-04-07 — ConfigLoader wired in all CLI commands |
| SPEC-017 | Error Handling + Observability | IMPLEMENTED | 2026-04-07 — GitConnectorError hierarchy fixed, 4 boundaries wired, typed exceptions raised |
| SPEC-018 | Louvain Clustering | IMPLEMENTED | 2026-04-07 — stabilization.py + capabilities.py built, interface aligned, 10 tests added |
| SPEC-019 | LLM Chat | PARKED | Waiting for API keys |
| SPEC-020 | CI/CD Integration Testing | IMPLEMENTED | 2026-04-07 — TestGitIntegration + TestDocumentOnboarding added |

### Week 4 (Standalone Services)

| Spec | Title | Status | Verified |
|------|-------|--------|----------|
| SPEC-021 | Remote MCP Server (HTTP) | IMPLEMENTED | 2026-04-07 — 13 auth middleware tests added |
| SPEC-022 | GraphQL API Standalone | IMPLEMENTED | 2026-04-07 — CORS middleware added |
| SPEC-023 | Web UI Standalone | IMPLEMENTED | 2026-04-07 — routes.py dual-mode via DataAccess, 5 routes fixed |
| SPEC-024 | Repository Pattern | IMPLEMENTED | 2026-04-04 — SQLAlchemyBackend, IStructuredBackend Protocol |

### Week 5 (Enterprise Features)

| Spec | Title | Status | Verified |
|------|-------|--------|----------|
| SPEC-025 | Webhook Receiver | IMPLEMENTED | 2026-04-05 |
| SPEC-026 | CI Pipeline Templates | IMPLEMENTED | 2026-04-07 — GitHub/GitLab/Azure templates |
| SPEC-027 | Materialize AMF Export | IMPLEMENTED | 2026-04-05 |
| SPEC-028 | Branch-Aware Queries | IMPLEMENTED | 2026-04-07 — Part 1: 3 resolvers. Part 2: centroid updates + 9 tests |
| SPEC-029 | Artifact Store | IMPLEMENTED | 2026-04-06 |
| SPEC-030 | Cross-Repo Query Completeness | IMPLEMENTED | 2026-04-05 — ADR-027, 5 gaps fixed |
| SPEC-031 | Service Call Graph Index | IMPLEMENTED | 2026-04-05 |
| SPEC-032 | Repo Purge | IMPLEMENTED | 2026-04-05 |
| SPEC-033 | Tuxedo Field-Level Extraction | IMPLEMENTED | 2026-04-05 |
| SPEC-034 | Centralized Logging | IMPLEMENTED | 2026-04-06 — 12 modules instrumented |
| SPEC-035 | ECLE_HOME Runtime Directory | IMPLEMENTED | 2026-04-06 |
| SPEC-036 | CPG Extraction Trigger | IMPLEMENTED | 2026-04-06 |
| SPEC-037 | Import Queue + Health | IMPLEMENTED | 2026-04-06 |

### Week 6 (Advanced)

| Spec | Title | Status | Verified |
|------|-------|--------|----------|
| SPEC-038 | Source Vector Layer | IMPLEMENTED | 2026-04-06 |
| SPEC-039 | Java CPG Project Mode | IMPLEMENTED | 2026-04-07 — project-level CPG, multi-file extractor |
| SPEC-040 | Unified Onboard Job Model | IMPLEMENTED | 2026-04-07 — 3-axis UI, config parser, ImportJob extended |
| SPEC-041 | File Upload Onboarding | IMPLEMENTED | 2026-04-08 — zip client-side, HTTP upload, extension filter, tree view |
| SPEC-042 | Service Boundary Architecture | IMPLEMENTED | 2026-04-09 — all 6 phases verified: file upload, API endpoints, UI HTTP-only, MCP API mode, CLI HTTP, auth middleware |
| SPEC-043 | Platform Repository | IMPLEMENTED | 2026-04-08 — __platform__ repo, 8 query methods, 27 tests, is_platform labels |

### Week 7 (Enterprise Intelligence)

| Spec | Title | Status | Verified |
|------|-------|--------|----------|
| SPEC-044 | Two-Phase Extraction Workflow | IMPLEMENTED | — |
| SPEC-045 | AMF Two-Phase Parser Support | IMPLEMENTED | — |
| SPEC-046 | Deployment Packaging | IMPLEMENTED | 2026-04-10 — bundle scripts, Docker, docker-compose, README |
| SPEC-047 | Cross-Tier Linker | IMPLEMENTED | 2026-04-10 — 7 trace methods, 3 MCP enrichments, ecle_trace tool, 20 tests |
| SPEC-048 | Change Intelligence | IMPLEMENTED | 2026-04-10 — 5 methods, ecle_estimate_change MCP + REST, 22 tests |
| SPEC-049 | Two-Phase Deep Enhancement | IMPLEMENTED | 2026-04-10 — merge_facts.py, structural→deep enhancement |
| SPEC-050 | Transparent Prompt Enrichment | IMPLEMENTED | 2026-04-11 — MCP instructions + context resource + /api/enrich |
| SPEC-051 | Auto-Classify Onboarding | IMPLEMENTED | 2026-04-11 — auto_classifier.py, split jobs per bucket, UI default |

### Summary

| Status | Count |
|--------|-------|
| IMPLEMENTED + VERIFIED | 51 |
| PARKED (API keys) | 1 |
| **Total** | **52** |
