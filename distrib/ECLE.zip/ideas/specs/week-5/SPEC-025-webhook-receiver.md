# SPEC-025: Webhook Receiver — VCS Push Event Ingestion

**Status**: Spec
**Owner**: Source Mesh Engineer
**Files**: `src/ecle/connectors/webhook_receiver.py` (new), `src/ecle/query/app.py` (add routes)

## Purpose

Accept push events from GitHub, GitLab, and Azure DevOps webhooks and trigger incremental ingestion. This replaces the polling-only model with event-driven ingestion — code changes are reflected in the knowledge graph within seconds of a push.

## ADR References

- [ADR-012](../../constitution/decisions/ADR-012-facts-folder-sync.md) — Facts sync mechanism
- [SPEC-009](../week-2/SPEC-009-git-onboarding.md) — Git connector foundation
- [SPEC-010](../week-2/SPEC-010-git-integration.md) — Git CI/CD integration

## Architecture

```
GitHub/GitLab/Azure DevOps
    │ POST /api/webhook
    ▼
Webhook Receiver (validates signature, parses payload)
    │ WebhookEvent(repo_url, branch, commit_sha, changed_files, provider)
    ▼
IncrementalIngestor.ingest(commit_sha, changed_files)
    │
    ├──→ Facts reload (changed files only)
    ├──→ Edge recomputation
    └──→ Neighbor re-embedding
```

## Interface

```python
# src/ecle/connectors/webhook_receiver.py

@dataclass
class WebhookEvent:
    """Normalized push event from any VCS provider."""
    provider: str           # "github" | "gitlab" | "azure_devops"
    repo_url: str           # clone URL
    branch: str             # "main", "feature/billing"
    commit_sha: str         # head commit
    changed_files: list[str]  # modified/added/removed file paths
    sender: str             # who pushed
    timestamp: str          # ISO 8601

def parse_github_push(payload: dict, signature: str, secret: str) -> WebhookEvent:
    """Parse GitHub push webhook payload. Validates HMAC-SHA256 signature."""

def parse_gitlab_push(payload: dict, token: str, secret: str) -> WebhookEvent:
    """Parse GitLab push webhook payload. Validates X-Gitlab-Token."""

def parse_azure_push(payload: dict) -> WebhookEvent:
    """Parse Azure DevOps service hook payload."""
```

### REST Endpoint

```python
# Added to app.py api_router

@api_router.post("/webhook/{provider}")
async def webhook_handler(provider: str, request: Request):
    """Receive VCS push webhooks. Provider: github | gitlab | azure_devops."""
    # 1. Validate signature/token
    # 2. Parse payload → WebhookEvent
    # 3. Map repo_url → repo_id (from shared_artifacts or config)
    # 4. Trigger IncrementalIngestor.ingest()
    # 5. Return 200 with summary
```

## Signature Validation

| Provider | Header | Method |
|----------|--------|--------|
| GitHub | `X-Hub-Signature-256` | HMAC-SHA256 of body with webhook secret |
| GitLab | `X-Gitlab-Token` | Static token comparison |
| Azure DevOps | Basic Auth or shared secret | HTTP Basic or payload hash |

Webhook secrets are read from environment variables:
- `ECLE_WEBHOOK_SECRET_GITHUB`
- `ECLE_WEBHOOK_SECRET_GITLAB`
- `ECLE_WEBHOOK_SECRET_AZURE`

## Behavior

### Happy Path
```
1. GitHub pushes to /api/webhook/github with X-Hub-Signature-256
2. Signature validated against ECLE_WEBHOOK_SECRET_GITHUB
3. Payload parsed → WebhookEvent(branch="main", commit="abc123", files=["billing.c"])
4. repo_url mapped to repo_id (lookup or auto-generate from URL)
5. IncrementalIngestor.ingest(commit="abc123", files=["billing.c"])
6. Response: 200 {"status": "ingested", "files_processed": 1, "edges_recomputed": 3}
```

### Ignored Events
- Non-push events (PR opened, issue created) → 200 {"status": "ignored", "reason": "not a push event"}
- Pushes to ignored branches (configurable) → 200 {"status": "ignored", "reason": "branch not tracked"}
- Tag pushes → 200 {"status": "ignored", "reason": "tag push"}

### Errors
- Invalid signature → 401 {"error": "Invalid webhook signature"}
- Unknown provider → 400 {"error": "Unknown provider: bitbucket"}
- Ingest failure → 500 {"error": "Ingestion failed: ...", "commit": "abc123"}

## Configuration

```yaml
# ecle.yaml
webhooks:
  enabled: true
  branches:              # only ingest from these branches (empty = all)
    - main
    - develop
    - "release/*"
  secret_env:
    github: ECLE_WEBHOOK_SECRET_GITHUB
    gitlab: ECLE_WEBHOOK_SECRET_GITLAB
    azure: ECLE_WEBHOOK_SECRET_AZURE
```

## Dependencies

- SPEC-010 (Git integration — existing git_watcher.py)
- SPEC-022 (GraphQL API — `/api/*` REST router)
- `src/ecle/ingestion/incremental.py` (IncrementalIngestor)

## Tests

| Test | What's Verified |
|------|----------------|
| `test_parse_github_push` | GitHub push payload → WebhookEvent with correct fields |
| `test_parse_gitlab_push` | GitLab push payload → WebhookEvent |
| `test_parse_azure_push` | Azure DevOps push payload → WebhookEvent |
| `test_github_signature_valid` | Valid HMAC-SHA256 → accepted |
| `test_github_signature_invalid` | Wrong signature → 401 |
| `test_gitlab_token_valid` | Correct X-Gitlab-Token → accepted |
| `test_non_push_event_ignored` | PR event → 200 ignored |
| `test_branch_filter` | Push to untracked branch → 200 ignored |
| `test_webhook_triggers_ingest` | Valid push → IncrementalIngestor called |
| `test_unknown_provider` | Bad provider → 400 |
