# SPEC-037: Import Queue + Health Reporting

**Status**: Implemented (updated 2026-04-06)
**Owner**: Infrastructure Engineer
**Files**: `src/ecle/ingestion/job_queue.py`, `src/ecle/ui/routes.py`, `src/ecle/ui/templates/health.html`

## Critical Design Rule

**ALL imports go through the queue. No exceptions.**

Every path that writes to the DB (facts import, document onboard, CPG extraction, 
webhook ingest) MUST submit a job to the queue. The queue worker serializes all 
writes — preventing concurrent DB access, memory exhaustion, and data corruption.

| UI Path | Queue Job Type | Worker Action |
|---------|---------------|---------------|
| Code tab (with facts) | `source_type=facts` | Load facts → edges → post-process |
| Code tab (no facts) | `source_type=code` | CPG extraction → load facts → edges → post-process |
| Import Facts tab | `source_type=facts` | Load facts → edges → post-process |
| Documents tab | `source_type=documents` | Store docs → embed → chunk |
| Webhook push | `source_type=facts` | Incremental ingest |
| CLI `ecle import` | Direct (bypasses queue) | Sequential CLI — safe |

The UI NEVER runs import pipelines directly. It submits to queue and returns immediately.
Progress is tracked on the Health Dashboard via AJAX polling (3s active, 10s idle).

## Purpose

Decouple code upload from processing via a file-based job queue. The health dashboard shows real-time status of all repos: loaded, queued, processing, failed.

**Before:**
```
Upload → blocks until import completes (minutes)
Health page → just shows current stats
```

**After:**
```
Upload → queued instantly → returns job ID
Background worker → picks up job → CPG (if needed) → import → post-process
Health page → shows queue status + recent imports + errors
```

## Architecture

```
Frontend (UI / CLI / Webhook)
    │ "import repo X"
    ▼
Job Queue (file-based)
    ecle-data/queue/
      pending/job-abc.json
      processing/job-def.json
      complete/job-ghi.json
      failed/job-xyz.json
    │
    ▼
Queue Worker (background thread or separate process)
    │
    ├── Has .facts.json? → import directly
    ├── No facts + CPG enabled? → run CPG → then import
    └── No facts + CPG disabled? → mark failed with instructions
    │
    ▼
Post-processing (run_post_processing)
```

## Job File Format

```json
// ecle-data/queue/pending/job-abc123.json
{
  "job_id": "abc123",
  "repo_id": "billing-service",
  "source_type": "facts",
  "source_path": "C:/Pradeep/facts/billing",
  "commit_sha": "import",
  "branch": "main",
  "created_at": "2026-04-05T10:30:00Z",
  "status": "pending"
}
```

```json
// ecle-data/queue/processing/job-abc123.json
{
  "job_id": "abc123",
  "repo_id": "billing-service",
  "status": "processing",
  "started_at": "2026-04-05T10:30:02Z",
  "progress": {
    "step": "embedding",
    "message": "Embedding 30/55 files...",
    "pct": 65
  }
}
```

```json
// ecle-data/queue/complete/job-abc123.json
{
  "job_id": "abc123",
  "repo_id": "billing-service",
  "status": "complete",
  "started_at": "2026-04-05T10:30:02Z",
  "completed_at": "2026-04-05T10:32:15Z",
  "duration_ms": 133000,
  "result": {
    "files": 55,
    "new": 55,
    "functions": 420,
    "edges": 180,
    "vectors": 420
  }
}
```

## Health Dashboard

### Current (exists)
```
Knowledge Graph
  argtbanhdr:  410 files | 3,652 functions | 1,534 edges
```

### Extended
```
Knowledge Graph
  argtbanhdr:     410 files | 3,652 functions | 1,534 edges  [Loaded]
  billing-service: 55 files |   420 functions |   180 edges  [Loaded]
  new-repo:        —        |     —           |     —        [Queued - position 1]

Recent Imports
  billing-service   55 files   2m 13s   5 min ago    [Success]
  argtbanhdr       410 files   8m 45s   1 hour ago   [Success]
  broken-repo        0 files      —     2 hours ago  [Failed: No .facts.json]

Queue
  Pending:    1 job
  Processing: 0 jobs
  Workers:    1 active
```

### Health API endpoint

```
GET /ui/health/jobs → {
  "pending": [...],
  "processing": [...],
  "recent": [...],    // last 10 completed/failed
  "workers": 1
}
```

## Queue Worker

### Lite mode (background thread)

```python
# Started by ecle serve
import threading

def _queue_worker(home: str, db_factory, vector_factory):
    """Background thread that processes queued import jobs."""
    queue_dir = Path(home) / "queue"
    while True:
        pending = sorted((queue_dir / "pending").glob("*.json"))
        if not pending:
            time.sleep(2)
            continue
        
        job_path = pending[0]
        job = json.loads(job_path.read_text())
        
        # Move to processing
        processing_path = queue_dir / "processing" / job_path.name
        job_path.rename(processing_path)
        job["status"] = "processing"
        job["started_at"] = _now_iso()
        processing_path.write_text(json.dumps(job))
        
        try:
            # Run import pipeline
            result = _process_job(job, db_factory, vector_factory)
            
            # Move to complete
            job["status"] = "complete"
            job["completed_at"] = _now_iso()
            job["result"] = result
            complete_path = queue_dir / "complete" / job_path.name
            processing_path.rename(complete_path)
            complete_path.write_text(json.dumps(job))
        
        except Exception as e:
            # Move to failed
            job["status"] = "failed"
            job["error"] = str(e)[:500]
            failed_path = queue_dir / "failed" / job_path.name
            processing_path.rename(failed_path)
            failed_path.write_text(json.dumps(job))
```

### Full mode (separate process)

```bash
ecle worker              # runs queue worker as standalone process
ecle worker --workers 4  # 4 parallel workers
```

## CLI Integration

```bash
# Synchronous (existing — blocks until done)
ecle import ./facts --repo-id billing

# Async (new — queues and returns immediately)
ecle import ./facts --repo-id billing --async
# → Job abc123 queued. Track: ecle jobs

# List jobs
ecle jobs
# → PENDING:    new-repo (queued 2m ago)
# → PROCESSING: billing (45%, embedding...)
# → COMPLETE:   argtbanhdr (8m 45s, 1h ago)

# Job details
ecle jobs abc123
# → full job JSON
```

## Dependencies

- SPEC-035 (ECLE_HOME — queue dir under ecle-data/)
- SPEC-036 (CPG trigger — queue worker triggers CPG if needed)
- SPEC-034 (Logging — job events logged)
- `run_post_processing()` — shared post-processing function

## Tests

| Test | What's Verified |
|------|----------------|
| `test_queue_submit` | Job file created in pending/ |
| `test_queue_process` | Job moved pending → processing → complete |
| `test_queue_failure` | Error → job moved to failed/ with error message |
| `test_health_shows_jobs` | /ui/health/jobs returns pending + processing + recent |
| `test_worker_picks_up` | Background worker processes pending job |
| `test_async_import` | --async flag returns job ID immediately |
