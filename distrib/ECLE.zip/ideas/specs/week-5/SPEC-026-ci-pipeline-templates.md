# SPEC-026: CI Pipeline Templates — GitLab CI + Azure DevOps

**Status**: Spec
**Owner**: DevOps Engineer
**Files**: `src/ecle/connectors/git_watcher.py` (extend)

## Purpose

Generate CI/CD pipeline YAML for GitLab CI and Azure DevOps Pipelines, matching the existing GitHub Actions template. These templates auto-ingest code changes into ECLE on every push.

## Current State

`git_watcher.py` already has:
- `generate_hook_script()` — local git post-commit hook
- `generate_github_action()` — `.github/workflows/ecle-ingest.yml`

This spec adds:
- `generate_gitlab_ci()` — `.gitlab-ci.yml` job
- `generate_azure_pipeline()` — `azure-pipelines.yml` stage

## Interface

```python
def generate_gitlab_ci(
    ecle_url: str = "http://localhost:8741",
    repo_id: str = "default",
    branches: list[str] | None = None,
) -> str:
    """Generate a .gitlab-ci.yml job that calls ECLE webhook on push."""

def generate_azure_pipeline(
    ecle_url: str = "http://localhost:8741",
    repo_id: str = "default",
    branches: list[str] | None = None,
) -> str:
    """Generate an azure-pipelines.yml stage that calls ECLE webhook on push."""
```

## Generated Output

### GitLab CI

```yaml
# .gitlab-ci.yml (add to existing or standalone)
ecle-ingest:
  stage: .post
  image: curlimages/curl:latest
  only:
    - main
    - develop
  script:
    - |
      curl -s -X POST "${ECLE_API_URL}/api/webhook/gitlab" \
        -H "Content-Type: application/json" \
        -H "X-Gitlab-Token: ${ECLE_WEBHOOK_SECRET}" \
        -d "{
          \"ref\": \"$CI_COMMIT_REF_NAME\",
          \"checkout_sha\": \"$CI_COMMIT_SHA\",
          \"project\": {\"path_with_namespace\": \"$CI_PROJECT_PATH\"}
        }"
  variables:
    ECLE_API_URL: http://ecle-api:8741
```

### Azure DevOps

```yaml
# azure-pipelines.yml (add as stage)
- stage: ecle_ingest
  displayName: 'ECLE Knowledge Graph Update'
  condition: succeeded()
  jobs:
    - job: ingest
      pool:
        vmImage: 'ubuntu-latest'
      steps:
        - script: |
            curl -s -X POST "$(ECLE_API_URL)/api/webhook/azure_devops" \
              -H "Content-Type: application/json" \
              -d "{
                \"resource\": {
                  \"repository\": {\"remoteUrl\": \"$(Build.Repository.Uri)\"},
                  \"refUpdates\": [{
                    \"name\": \"refs/heads/$(Build.SourceBranchName)\",
                    \"newObjectId\": \"$(Build.SourceVersion)\"
                  }]
                },
                \"eventType\": \"git.push\"
              }"
          displayName: 'Notify ECLE'
          env:
            ECLE_API_URL: $(ECLE_API_URL)
```

## CLI Integration

```bash
# Generate templates
ecle generate --template github-action --repo-id billing
ecle generate --template gitlab-ci --repo-id billing --ecle-url http://ecle:8741
ecle generate --template azure-pipeline --repo-id billing
ecle generate --template hook --repo-id billing
```

## Tests

| Test | What's Verified |
|------|----------------|
| `test_generate_gitlab_ci` | Valid YAML output with correct variables |
| `test_generate_azure_pipeline` | Valid YAML output with correct variables |
| `test_gitlab_branch_filter` | Custom branches reflected in `only:` |
| `test_azure_branch_filter` | Custom branches reflected in `condition:` |
| `test_cli_generate_command` | `ecle generate --template gitlab-ci` works |

## Dependencies

- SPEC-025 (Webhook receiver — the endpoint these templates call)
- SPEC-010 (Git integration — existing `generate_github_action`)
