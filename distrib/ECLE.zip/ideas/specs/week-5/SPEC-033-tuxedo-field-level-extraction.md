# SPEC-033: Tuxedo Field-Level Extraction

**Status**: Spec  
**Owner**: CPG Pipeline Engineer + MCP Tool Engineer  
**Files**:
- `src/ecle/backends/structured/schema.py` — new tables
- `src/ecle/backends/structured/models.py` — SQLAlchemy models
- `src/ecle/backends/structured/sqlalchemy_backend.py` — query methods
- `src/ecle/ingestion/facts_loader.py` — field ingestion logic
- `src/ecle/ingestion/field_extractor.py` — NEW: Tuxedo field parser
- `src/ecle/mcp/server.py` — new MCP tools

## Purpose

Add field-level fact extraction for Tuxedo services so that agents can answer:
- "What are the input fields of service X?"
- "What are the output fields of service X?"
- "What fields are common between service X and service Y?"
- "What fields does view V contain?"

Every answer must be grounded in structural evidence (FML API calls, struct definitions, header declarations) — not inferred from file names.

## ADR References

- **ADR-029**: Tuxedo Field-Level Extraction (architectural decision)
- **ADR-028**: Deterministic Service Index (prerequisite — `service_function_map`)
- **ADR-012**: Idempotent Sync (content hash — re-ingestion safety)
- **ADR-014**: Version Chain (nothing deleted — field facts are versioned)

## Inputs

### Language-Specific Field Availability

The `.facts.json` schema is language-agnostic but not every language produces every field.
The `FieldExtractor` must treat all fields as optional — never assume a field exists.

| facts.json field | C (.c) | Pro*C (.ppc) | C Header (.h) | PowerBuilder (.sru/.srw) | SQL (.srd/.srf) |
|------------------|--------|--------------|----------------|--------------------------|-----------------|
| `framework_calls[]` | Sparse | **Populated** | Empty | **Populated** | Sparse |
| `global_defs[]` | Empty | **Populated** | Empty | Empty | Empty |
| `struct_definitions[]` | Names only (members empty) | Empty | Empty | N/A | N/A |
| `macros[]` | Empty | Empty | Empty | N/A | N/A |
| `includes[]` | Empty | Empty | Empty | N/A | N/A |
| `functions[]` | **Populated** | **Populated** | **Populated** | **Populated** | **Populated** |
| `sql_statements[]` | Sparse | **Populated** | Empty | **Populated** | **Populated** |
| `data_flow_edges[]` | Sparse | Sparse | Empty | Sparse | Empty |

**Implication**: Field-level extraction is primarily useful for **C + Pro*C** (Tuxedo services).
For PowerBuilder, the equivalent is `framework_calls[]` with DataWindow/DataStore methods.
For languages where a field is absent, the extractor silently skips — no error, no placeholder.

### What Already Exists in `.facts.json` (populated, under-ingested)

Two fact categories are **already populated** by the Joern C language pack but not fully exploited:

**1. `framework_calls[]`** — ALREADY POPULATED. Captures system/framework calls including
Tuxedo FML buffer API (`Fget32`, `Fchg32`, `Fadd32`, etc.) as `SYSTEM_OR_FRAMEWORK_CALL`.
The ingestion pipeline already stores these in `function_calls` but does not classify them
by field reference or IO direction.

```json
"framework_calls": [
  {
    "id": "30064771073",
    "line": 45,
    "enclosing_method": "mmUpMemo",
    "call_name": "Fget32",
    "code_snippet": "Fget32(rqst->data, MEMO_ID, 0, memo_dl.memo_id, &len)",
    "category": "SYSTEM_OR_FRAMEWORK_CALL"
  }
]
```

**2. `global_defs[]`** — ALREADY POPULATED for Pro*C. Host variables with `io_`/`i_`/`o_`
prefixes are captured with type info. Not currently analyzed for directional semantics.

```json
"global_defs": [
  {"name": "io_pGnControl", "type": "struct gnControlUi *"},
  {"name": "i_memo_id", "type": "char[11]"}
]
```

### What Needs Joern Enhancement (schema slots exist, currently empty)

Three fact categories have **schema slots in .facts.json but are always empty**:

**3. `struct_definitions[].members[]`** — Joern finds struct names but members array is empty.
Needs enhancement to extract field names, types, and sizes from `_dl.h`, `_nl.h`, `t_*.h`.

```json
{
  "struct_definitions": [
    {
      "name": "pmm_memo_dl",
      "members": [
        {"name": "memo_id", "type": "char", "size": 11, "line": 5},
        {"name": "memo_cd", "type": "char", "size": 3, "line": 6},
        {"name": "memo_txt", "type": "char", "size": 251, "line": 7}
      ],
      "line": 3
    }
  ]
```

**4. `macros[]`** — Always empty. Needs enhancement to extract `#define FIELD ((FLDID32)N)`.

```json
  "macros": [
    {"name": "MEMO_ID", "value": "((FLDID32)167878435)", "line": 2}
  ],
  "framework_calls": [
    {
      "call_name": "Fget32",
      "line": 45,
      "enclosing_method": "mmUpMemo",
      "code_snippet": "Fget32(rqst->data, MEMO_ID, 0, memo_dl.memo_id, &len)",
      "category": "BUFFER_READ",
      "field_ref": "MEMO_ID"
    },
    {
      "call_name": "Fchg32",
      "line": 312,
      "enclosing_method": "mmUpMemo",
      "code_snippet": "Fchg32(rqst->data, SVC_STS, 0, svc_sts, 0)",
      "category": "BUFFER_WRITE",
      "field_ref": "SVC_STS"
    }
  ]
}
```

### From Joern/Language Pack Enhancement (new extraction rules)

The C language pack must be enhanced to:

1. **Parse `#define` macros** matching pattern `#define FIELD_NAME ((FLDID32)...)` → populate `macros[]`
2. **Parse struct members** from `_dl.h`, `_nl.h`, `t_*.h` files → populate `struct_definitions[].fields[]`
3. **Classify `Fget32`/`Fchg32`/`Fadd32`/`Ffind32`** framework calls with `field_ref` extraction → populate `framework_calls[]` with `category: BUFFER_READ|BUFFER_WRITE`

## Outputs

### New Structured DB Tables

#### `fml_fields` — FML32 field definitions

```sql
CREATE TABLE IF NOT EXISTS fml_fields (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    file_fact_id    TEXT NOT NULL REFERENCES file_facts(id),
    field_name      TEXT NOT NULL,
    fml_type        TEXT,              -- FLDID32, STRING, LONG, etc.
    fml_id          TEXT,              -- raw numeric ID from #define
    field_size      INTEGER,
    header_file     TEXT NOT NULL,     -- e.g., 'memoid.h'
    line            INTEGER DEFAULT 0,
    repo_id         TEXT NOT NULL DEFAULT 'default',
    commit_sha      TEXT NOT NULL DEFAULT 'import'
);

CREATE INDEX IF NOT EXISTS idx_fml_name ON fml_fields(field_name);
CREATE INDEX IF NOT EXISTS idx_fml_header ON fml_fields(header_file, repo_id);
CREATE INDEX IF NOT EXISTS idx_fml_file ON fml_fields(file_fact_id);
```

#### `view_fields` — struct/view member definitions

```sql
CREATE TABLE IF NOT EXISTS view_fields (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    file_fact_id    TEXT NOT NULL REFERENCES file_facts(id),
    struct_name     TEXT NOT NULL,     -- e.g., 'pmm_memo_dl', 't_memotp1v'
    field_name      TEXT NOT NULL,
    field_type      TEXT NOT NULL,     -- C type: char, int, long, double
    field_size      INTEGER,           -- array size for char[N]
    field_offset    INTEGER,           -- position in struct (0-based)
    header_file     TEXT NOT NULL,
    line            INTEGER DEFAULT 0,
    repo_id         TEXT NOT NULL DEFAULT 'default',
    commit_sha      TEXT NOT NULL DEFAULT 'import'
);

CREATE INDEX IF NOT EXISTS idx_vf_struct ON view_fields(struct_name, repo_id);
CREATE INDEX IF NOT EXISTS idx_vf_field ON view_fields(field_name);
CREATE INDEX IF NOT EXISTS idx_vf_header ON view_fields(header_file, repo_id);
CREATE INDEX IF NOT EXISTS idx_vf_file ON view_fields(file_fact_id);
```

#### `service_fields` — service-to-field mapping with IO direction

```sql
CREATE TABLE IF NOT EXISTS service_fields (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    service_name    TEXT NOT NULL,
    field_name      TEXT NOT NULL,
    direction       TEXT NOT NULL,     -- INPUT, OUTPUT, INOUT, UNKNOWN
    evidence_type   TEXT NOT NULL,     -- BUFFER_API, PREFIX, LAYOUT_ONLY
    evidence_call   TEXT,              -- e.g., 'Fget32', 'Fchg32'
    evidence_line   INTEGER,
    evidence_file   TEXT,
    confidence      REAL DEFAULT 1.0,
    header_file     TEXT,              -- source FML header
    repo_id         TEXT NOT NULL DEFAULT 'default',
    commit_sha      TEXT NOT NULL DEFAULT 'import'
);

CREATE INDEX IF NOT EXISTS idx_sf_service ON service_fields(service_name, repo_id);
CREATE INDEX IF NOT EXISTS idx_sf_field ON service_fields(field_name, repo_id);
CREATE INDEX IF NOT EXISTS idx_sf_direction ON service_fields(service_name, direction);
```

#### `service_parameters` — host variable parameters with prefix semantics

```sql
CREATE TABLE IF NOT EXISTS service_parameters (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    service_name    TEXT NOT NULL,
    param_name      TEXT NOT NULL,     -- host variable name: io_pGnControl, i_memo_id
    param_prefix    TEXT,              -- io_, i_, o_, or NULL
    inferred_dir    TEXT,              -- INPUT, OUTPUT, INOUT based on prefix
    mapped_field    TEXT,              -- FML field it maps to (if resolvable)
    param_type      TEXT,              -- C type
    declaration_file TEXT,
    declaration_line INTEGER,
    repo_id         TEXT NOT NULL DEFAULT 'default',
    commit_sha      TEXT NOT NULL DEFAULT 'import'
);

CREATE INDEX IF NOT EXISTS idx_sp_service ON service_parameters(service_name, repo_id);
CREATE INDEX IF NOT EXISTS idx_sp_prefix ON service_parameters(param_prefix);
```

### Schema Version

Bump `SCHEMA_VERSION` from `1` to `2`. Migration adds the 4 new tables — no existing tables modified.

## Interface

### FieldExtractor (new module)

```python
# src/ecle/ingestion/field_extractor.py

@dataclass
class FMLField:
    field_name: str
    fml_type: str | None
    fml_id: str | None
    field_size: int | None
    header_file: str
    line: int

@dataclass
class ViewField:
    struct_name: str
    field_name: str
    field_type: str
    field_size: int | None
    field_offset: int
    header_file: str
    line: int

@dataclass
class ServiceField:
    service_name: str
    field_name: str
    direction: str          # INPUT | OUTPUT | INOUT | UNKNOWN
    evidence_type: str      # BUFFER_API | PREFIX | LAYOUT_ONLY
    evidence_call: str | None
    evidence_line: int | None
    evidence_file: str | None
    confidence: float
    header_file: str | None

class FieldExtractor:
    """Extracts field-level facts from parsed .facts.json data."""

    def extract_fml_fields(self, macros: list[dict]) -> list[FMLField]:
        """Parse FML32 field definitions from macros[]."""

    def extract_view_fields(self, struct_defs: list[dict]) -> list[ViewField]:
        """Parse view/struct member definitions from struct_definitions[]."""

    def extract_service_fields(
        self,
        service_name: str,
        framework_calls: list[dict],
        fml_fields: list[FMLField],
    ) -> list[ServiceField]:
        """Determine IO direction from Fget32/Fchg32 patterns."""

    def extract_service_parameters(
        self,
        service_name: str,
        functions: list[dict],
        global_defs: list[dict],
    ) -> list[ServiceParameter]:
        """Extract host variables with io_/i_/o_ prefix semantics."""
```

### Backend Query Methods (added to IStructuredBackend)

```python
def get_service_fields(
    self, service_name: str, repo_id: str, direction: str | None = None,
) -> list[dict]:
    """Return fields for a service, optionally filtered by direction."""

def get_view_fields(
    self, struct_name: str, repo_id: str,
) -> list[dict]:
    """Return all fields in a named view/struct."""

def get_common_fields(
    self, service_a: str, service_b: str, repo_id: str | None = None,
) -> list[dict]:
    """Return fields present in both services with direction comparison."""

def get_fml_field(
    self, field_name: str, repo_id: str,
) -> dict | None:
    """Return FML definition for a named field."""
```

### New MCP Tools

#### `ecle_service_io`

```python
@mcp.tool()
def ecle_service_io(
    service_name: str,
    direction: str | None = None,    # INPUT, OUTPUT, INOUT, or None for all
    repo_id: str = _REPO_ID,
) -> str:
    """Input and output fields for a Tuxedo service.
    Grounded in FML buffer API evidence (Fget32=input, Fchg32=output)."""
```

**Response schema:**
```json
{
  "service": "mmUpMemo",
  "total_fields": 12,
  "inputs": [
    {"field": "MEMO_ID", "header": "memoid.h", "evidence": "Fget32", "line": 45, "confidence": 1.0},
    {"field": "MEMO_CD", "header": "memocd.h", "evidence": "Fget32", "line": 48, "confidence": 1.0}
  ],
  "outputs": [
    {"field": "SVC_STS", "header": "svcsts.h", "evidence": "Fchg32", "line": 312, "confidence": 1.0},
    {"field": "OLN_MSG", "header": "t_oln_msg_1v.h", "evidence": "Fchg32", "line": 320, "confidence": 1.0}
  ],
  "inout": [
    {"field": "DIRECTIVE", "header": "directive.h", "evidence": "Fget32+Fchg32", "confidence": 1.0}
  ],
  "unknown": [
    {"field": "DL_TRX_MODE", "header": "dltrxmode.h", "evidence": "LAYOUT_ONLY", "confidence": 0.5}
  ]
}
```

#### `ecle_view_fields`

```python
@mcp.tool()
def ecle_view_fields(
    view_name: str,                  # struct/view name, e.g., 't_memotp1v' or 'pmm_memo_dl'
    repo_id: str = _REPO_ID,
) -> str:
    """Field breakdown of a Tuxedo view/struct definition."""
```

**Response schema:**
```json
{
  "view": "pmm_memo_dl",
  "header": "pmm_memo_dl.h",
  "total_fields": 8,
  "fields": [
    {"name": "memo_id", "type": "char", "size": 11, "offset": 0},
    {"name": "memo_cd", "type": "char", "size": 3, "offset": 1},
    {"name": "memo_txt", "type": "char", "size": 251, "offset": 2}
  ]
}
```

#### `ecle_common_fields`

```python
@mcp.tool()
def ecle_common_fields(
    service_a: str,
    service_b: str,
    repo_id: str = "*",              # default: cross-repo search
) -> str:
    """Fields common to two services, with direction comparison."""
```

**Response schema:**
```json
{
  "service_a": "csGtWdgtCnfg",
  "service_b": "evRfGtMemTp",
  "common_fields": [
    {"field": "OPER_ID", "dir_a": "INPUT", "dir_b": "INPUT", "header": "operid.h"},
    {"field": "DIRECTIVE", "dir_a": "INPUT", "dir_b": "INOUT", "header": "directive.h"},
    {"field": "SVC_STS", "dir_a": "OUTPUT", "dir_b": "OUTPUT", "header": "svcsts.h"}
  ],
  "only_in_a": ["GN_CONTROL_UI"],
  "only_in_b": ["MEM_CTG"]
}
```

## Behavior

### 1. Ingestion Flow (extends `FactsLoader.load_file()`)

After existing step 10 (mark entry points), add:

```
Step 11: Extract FML fields
    - For each macro in facts["macros"] matching FLDID32 pattern:
      → insert into fml_fields

Step 12: Extract view fields
    - For each struct in facts["struct_definitions"] with non-empty fields[]:
      → insert into view_fields (one row per field)

Step 13: Extract service fields
    - For each entry_point function in the file:
      a. Collect framework_calls where enclosing_method == function_name
      b. Classify: Fget32/CFget32/Ffind32 → INPUT, Fchg32/CFchg32/Fadd32 → OUTPUT
      c. If same field has both GET and CHG → INOUT
      d. Insert into service_fields with evidence

Step 14: Extract service parameters
    - For each entry_point function:
      a. Scan args[] and related global_defs for io_/i_/o_ prefixed variables
      b. Insert into service_parameters with inferred_dir
```

### 2. IO Direction Resolution Algorithm

```python
def resolve_direction(field_name: str, calls: list[dict]) -> tuple[str, float]:
    """
    Returns (direction, confidence) based on buffer API evidence.

    Priority:
    1. Buffer API calls (Fget32/Fchg32) → confidence 1.0
    2. Host variable prefix (io_/i_/o_) → confidence 0.8
    3. Present in data layout but no API evidence → UNKNOWN, confidence 0.5
    """
    has_get = any(
        c["call_name"] in ("Fget32", "CFget32", "Ffind32")
        and c.get("field_ref") == field_name
        for c in calls
    )
    has_chg = any(
        c["call_name"] in ("Fchg32", "CFchg32", "Fadd32")
        and c.get("field_ref") == field_name
        for c in calls
    )

    if has_get and has_chg:
        return "INOUT", 1.0
    if has_get:
        return "INPUT", 1.0
    if has_chg:
        return "OUTPUT", 1.0
    return "UNKNOWN", 0.5
```

### 3. Cross-Repo Field Comparison

`ecle_common_fields` with `repo_id="*"`:
1. Query `service_fields` for service_a across all repos
2. Query `service_fields` for service_b across all repos
3. Inner join on `field_name` → common fields with direction comparison
4. Left/right anti-join → fields only in A or only in B

### 4. External Resolution Enhancement

When `function_calls.is_external = 1`:
1. Query `function_facts.function_name` across all repos in same tenant
2. If exactly one match → resolved (add `resolved_repo_id`, `resolved_file_id`)
3. If multiple matches → ambiguous (log warning, keep as `<external>`)
4. If zero matches → truly external (keep as `<external>`)

Runs as a post-ingestion pass in `ServiceIndexBuilder.build()`.

## Dependencies

| Spec/ADR | Dependency Type |
|----------|----------------|
| SPEC-001 (schema) | Extends — adds 4 new tables |
| SPEC-031 (service index) | Requires — `service_function_map` for service→function mapping |
| SPEC-030 (cross-repo completeness) | Extends — external resolution builds on cross-repo edges |
| ADR-012 (idempotent sync) | Follows — re-ingestion safe via content_hash |
| ADR-014 (version chain) | Follows — field facts are versioned |
| ADR-029 (field extraction) | Implements — this spec is the implementation of ADR-029 |

### Two-Track Implementation

**Track 1 — Immediate (no Joern changes needed):**
- Classify existing `framework_calls[]` entries: detect `Fget32`/`Fchg32`/`Fadd32` call patterns
- Extract `field_ref` from `code_snippet` using regex (e.g., `Fget32(buf, MEMO_ID, ...)` → field_ref=MEMO_ID)
- Analyze existing `global_defs[]` for `io_`/`i_`/`o_` prefix semantics
- Populate `service_fields` and `service_parameters` tables from this evidence
- Deploy 3 new MCP tools with grounded IO direction at confidence 1.0 for buffer API evidence

**Track 2 — Joern enhancement (struct/macro/include):**
The C language pack must be enhanced to populate:
- `struct_definitions[].members[]` — extract struct member declarations (names, types, sizes)
- `macros[]` — extract `#define FIELD ((FLDID32)N)` patterns
- `includes[]` — extract `#include` directives

Once Track 2 lands:
- Populate `fml_fields` table from `macros[]`
- Populate `view_fields` table from `struct_definitions[].members[]`
- `ecle_view_fields` tool becomes fully grounded

**Fallback for Track 2 fields before Joern enhancement:**
- Map header file names to field names using naming convention (lower confidence: 0.5)
- Mark as `evidence_type: HEADER_CONVENTION` instead of `BUFFER_API`

## Tests

| Test | What's Verified |
|------|----------------|
| `test_extract_fml_field_from_macro` | `#define MEMO_ID ((FLDID32)167878435)` → FMLField with correct name, type, id |
| `test_extract_view_fields_from_struct` | Struct with 5 fields → 5 ViewField rows with correct types and sizes |
| `test_direction_from_fget32` | `Fget32(buf, MEMO_ID, ...)` → ServiceField(direction=INPUT, confidence=1.0) |
| `test_direction_from_fchg32` | `Fchg32(buf, SVC_STS, ...)` → ServiceField(direction=OUTPUT, confidence=1.0) |
| `test_direction_inout` | Same field with both Fget32 and Fchg32 → direction=INOUT |
| `test_direction_unknown_layout_only` | Field in `_dl.h` struct but no API calls → direction=UNKNOWN, confidence=0.5 |
| `test_prefix_inference_io` | Host variable `io_pGnControl` → inferred_dir=INOUT, confidence=0.8 |
| `test_prefix_inference_i` | Host variable `i_memo_id` → inferred_dir=INPUT, confidence=0.8 |
| `test_prefix_inference_o` | Host variable `o_svc_sts` → inferred_dir=OUTPUT, confidence=0.8 |
| `test_service_io_tool` | MCP tool returns grouped inputs/outputs/inout/unknown with evidence |
| `test_view_fields_tool` | MCP tool returns ordered field list for a view struct |
| `test_common_fields_tool` | MCP tool returns intersection + exclusive sets between two services |
| `test_common_fields_cross_repo` | Same as above but services are in different repos |
| `test_external_resolution_single_match` | External call resolved to exactly one repo → resolved_repo_id set |
| `test_external_resolution_ambiguous` | External call matches 2+ repos → stays as `<external>` |
| `test_idempotent_reingest` | Ingesting same facts twice produces identical field rows (no duplicates) |
| `test_schema_migration_v1_to_v2` | Existing v1 DB gains 4 new tables without data loss |
| `test_fallback_mode_header_convention` | Without `framework_calls[]`, fields inferred from includes at confidence 0.5 |
