# SPEC-028: Branch-Aware Queries + Incremental Centroid Updates

**Status**: Spec
**Owner**: Graph Engineer
**Files**: `src/ecle/query/schema.py`, `src/ecle/query/app.py`, `src/ecle/clustering/louvain.py`

## Purpose

Enable branch-scoped queries ("show me billing.c on the release/2.4 branch") and incremental cluster updates when files change. Today all queries see only `is_current=1` on the default branch. Tomorrow queries can scope to any branch, and cluster assignments update incrementally.

## Part 1: Branch-Aware Queries

### New GraphQL Fields

```graphql
type Query {
  # Existing (unchanged)
  file(fileId: String!, repoId: String!): FileFact
  
  # New: branch-scoped lookup
  fileOnBranch(fileId: String!, repoId: String!, branch: String!): FileFact
  
  # New: list branches for a repo
  branches(repoId: String!): [BranchInfo!]!
  
  # New: diff between branches
  branchDiff(repoId: String!, base: String!, head: String!): BranchDiff!
}

type BranchInfo {
  branch: String!
  fileCount: Int!
  latestCommit: String
}

type BranchDiff {
  base: String!
  head: String!
  filesOnlyInBase: [String!]!
  filesOnlyInHead: [String!]!
  filesModified: [String!]!    # same file_id, different content hash
}
```

### Backend Methods (IStructuredBackend)

```python
def get_file_on_branch(self, file_id: str, repo_id: str, branch: str) -> Row | None:
    """Get latest version of a file on a specific branch."""

def list_branches(self, repo_id: str) -> list[dict]:
    """Get distinct branches with file counts."""

def branch_diff(self, repo_id: str, base_branch: str, head_branch: str) -> dict:
    """Compare files between two branches."""
```

## Part 2: Incremental Centroid Updates

### When a File Changes

```
File A changes (new commit ingested)
    │
    ├── 1. Check if A's cluster assignment still valid
    │      Compare A's new embedding distance to cluster centroid
    │      If distance > threshold → flag for reassignment
    │
    ├── 2. Recompute affected cluster's centroid
    │      Average of member embeddings (incremental: subtract old, add new)
    │
    └── 3. Check neighbors for cluster drift
           If A moved clusters, check if A's neighbors should too
```

### Interface

```python
# Added to LouvainClusterer

def update_file_cluster(self, file_id: str) -> dict:
    """Check if a file's cluster assignment is still valid after ingestion.
    
    Returns: {file_id, old_cluster, new_cluster, reassigned: bool}
    """

def recompute_cluster_centroid(self, cluster_id: str) -> None:
    """Recompute a cluster's centroid from its current member embeddings."""
```

### Trigger

Called by `IncrementalIngestor` after ingesting a file:

```python
# In incremental.py, after facts + edges + embedding:
if self.clusterer:
    self.clusterer.update_file_cluster(file_id)
```

## Tests

| Test | What's Verified |
|------|----------------|
| `test_file_on_branch` | fileOnBranch query returns correct version |
| `test_list_branches` | branches query returns distinct branches with counts |
| `test_branch_diff` | Diff correctly identifies added/removed/modified files |
| `test_cluster_still_valid` | Unchanged file keeps its cluster |
| `test_cluster_reassignment` | Significantly changed file gets new cluster |
| `test_centroid_recompute` | Cluster centroid updates after member change |

## Dependencies

- SPEC-024 (Repository pattern — new backend methods)
- SPEC-018 (Louvain clustering — base implementation)
- SPEC-003 (Facts loader — branch parameter)
