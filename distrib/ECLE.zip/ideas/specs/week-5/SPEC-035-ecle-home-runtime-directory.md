# SPEC-035: ECLE_HOME — Unified Runtime Directory

**Status**: Implemented + Updated
**Owner**: Infrastructure Engineer
**Files**: `src/ecle/config/settings.py`, `src/ecle/config/loader.py`, `src/ecle/config/factory.py`, `src/ecle/cli.py`, `src/ecle/logging_config.py`

## Purpose

Establish a single root directory (`ECLE_HOME`) under which ECLE runtime data lives — config, database, vectors, artifacts, indexes — while allowing operational logs to live in a dedicated sibling `ecle-logs/` tree for easier control and retention.

**Before:**
```
./ecle.db                    ← DB in working directory
./vectors/                   ← vectors next to DB
(no ecle.yaml)               ← config doesn't exist
(stderr only)                ← logs not persisted
(not stored)                 ← artifacts lost
```

**After:**
```
ecle-data/                   ← ECLE_HOME (single root for runtime data)
  config/
    ecle.yaml                ← auto-generated on first run
  db/
    ecle.db                  ← structured database
  vectors/                   ← ChromaDB collections
  artifacts/                 ← SPEC-029: .facts.json + sources
    {repo_id}/
      {commit_sha}/
        facts/
        sources/

ecle-logs/                   ← sibling operational log root
  api/api.log
  backend/backend.log
  mcp/mcp.log
  ui/ui.log
  worker/worker.log
```

## Resolution Order

```
1. ECLE_HOME env var         (highest — explicit override)
2. --home CLI flag            (per-command override)
3. ecle.yaml home: field      (if ecle.yaml found in cwd)
4. ./ecle-data                (default — current working directory)
```

## Interface

### Environment Variable

```bash
export ECLE_HOME=/opt/ecle-data
ecle import ./facts --repo-id billing
# → DB at /opt/ecle-data/db/ecle.db
# → Vectors at /opt/ecle-data/vectors/
# → Config at /opt/ecle-data/config/ecle.yaml
# → Logs at /opt/ecle-logs/<service>/<service>.log
```

### CLI Flag

```bash
ecle --home /opt/ecle-data import ./facts --repo-id billing
ecle --home /opt/ecle-data serve
```

### ecle.yaml

```yaml
# ecle-data/config/ecle.yaml (auto-generated on first run)

# All paths below are relative to ECLE_HOME
# Override ECLE_HOME with env var or --home flag

features: lite

db:
  backend: sqlite
  path: db/ecle.db             # relative to ECLE_HOME

  # PostgreSQL (remote DB — path ignored):
  # backend: postgresql
  # host: db-server.internal
  # port: 5432
  # database: ecle
  # user: ecle
  # password_env: ECLE_DB_PASSWORD

vector:
  backend: chromadb
  path: vectors                # relative to ECLE_HOME

artifacts:
  path: artifacts              # relative to ECLE_HOME
  store_facts: true
  store_sources: true

logging:
  level: INFO
  format: json                 # json | text
  path: ../ecle-logs           # sibling to ECLE_HOME

server:
  host: 127.0.0.1
  port: 8741

clustering:
  enabled: true
```

## Behavior

### First Run

```
$ ecle import ./facts --repo-id billing

  ECLE_HOME not set, using ./ecle-data
  Creating ecle-data/config/ecle.yaml
  Creating ecle-data/db/
  Creating ecle-data/vectors/
  Logging to sibling ecle-logs/
  Creating ecle-data/artifacts/

  ECLE Import
  Source:  ./facts
  Repo:    billing
  DB:      ecle-data/db/ecle.db
  ...
```

### Subsequent Runs

```
$ ecle serve

  ECLE Query Engine
  Home:      ./ecle-data
  Database:  ecle-data/db/ecle.db (1 repos, 410 files)
  Logs:      ecle-logs/<service>/<service>.log
  ...
```

### Docker

```dockerfile
ENV ECLE_HOME=/data
VOLUME /data
```

```yaml
# docker-compose.yml
services:
  ecle:
    environment:
      ECLE_HOME: /data
    volumes:
      - ecle-data:/data
```

### Backup / Migration

```bash
# Backup everything
tar czf ecle-backup.tar.gz ecle-data/

# Migrate to new server
scp ecle-backup.tar.gz new-server:
ssh new-server "tar xzf ecle-backup.tar.gz && ecle serve"
```

### Start Fresh

```bash
rm -rf ecle-data/
ecle import ./facts --repo-id billing
# → recreates everything from scratch
```

## Implementation

### Settings Changes

```python
# src/ecle/config/settings.py

@dataclass
class Settings:
    home: str = "./ecle-data"    # ECLE_HOME root

    @property
    def db_path(self) -> Path:
        if self.db.backend == "postgresql":
            return Path(self.db.path)  # ignored for remote DB
        return Path(self.home) / self.db.path

    @property
    def vector_path(self) -> Path:
        return Path(self.home) / self.vector.path

    @property
    def artifacts_path(self) -> Path:
        return Path(self.home) / "artifacts"

    @property
    def log_path(self) -> Path:
        return Path(self.home) / "logs" / "ecle.log"

    @property
    def config_path(self) -> Path:
        return Path(self.home) / "config" / "ecle.yaml"
```

### Loader Changes

```python
# src/ecle/config/loader.py

def resolve_home() -> str:
    """Resolve ECLE_HOME from env var, CLI flag, or default."""
    return os.getenv("ECLE_HOME", "./ecle-data")

def ensure_home(home: str) -> None:
    """Create ECLE_HOME directory structure if it doesn't exist."""
    root = Path(home)
    for subdir in ("config", "db", "vectors", "artifacts", "logs"):
        (root / subdir).mkdir(parents=True, exist_ok=True)

    # Auto-generate ecle.yaml if missing
    config_path = root / "config" / "ecle.yaml"
    if not config_path.exists():
        config_path.write_text(DEFAULT_YAML, encoding="utf-8")
```

### CLI Changes

```python
# Global --home flag on all commands
parser.add_argument("--home", default=None, help="ECLE_HOME directory")

# In _create_db_from_config:
home = args.home or os.getenv("ECLE_HOME", "./ecle-data")
ensure_home(home)
settings = ConfigLoader.load(home=home, cli_args=args)
```

### Path Resolution

All paths in `ecle.yaml` are relative to `ECLE_HOME`:

```python
# db.path = "db/ecle.db"  → ECLE_HOME/db/ecle.db
# vector.path = "vectors"  → ECLE_HOME/vectors
# logging.path = "logs/ecle.log" → ECLE_HOME/logs/ecle.log
```

Absolute paths override: if `db.path = /opt/shared/ecle.db`, it's used as-is.

### Backward Compatibility

If `ecle.db` exists in the current directory (old layout), ECLE detects it and works in legacy mode:

```python
if Path("ecle.db").exists() and not Path("ecle-data").exists():
    # Legacy mode — use current directory layout
    home = "."
    settings.db.path = "ecle.db"
    settings.vector.path = "vectors"
```

## What Moves Where

| Item | Old location | New location |
|------|-------------|-------------|
| Database | `./ecle.db` | `ecle-data/db/ecle.db` |
| Vectors | `./vectors/` | `ecle-data/vectors/` |
| Config | (didn't exist) | `ecle-data/config/ecle.yaml` |
| Logs | stderr only | `ecle-data/logs/ecle.log` + stderr |
| Artifacts | (not stored) | `ecle-data/artifacts/{repo}/{commit}/` |

## Tests

| Test | What's Verified |
|------|----------------|
| `test_default_home` | No env var → uses ./ecle-data |
| `test_env_home` | ECLE_HOME=/tmp/test → uses /tmp/test |
| `test_cli_home` | --home /tmp/test → uses /tmp/test |
| `test_ensure_home_creates_dirs` | All subdirs created |
| `test_config_auto_generated` | ecle.yaml created on first run |
| `test_relative_paths` | db.path=db/ecle.db resolved to ECLE_HOME/db/ecle.db |
| `test_absolute_paths` | db.path=/opt/ecle.db used as-is |
| `test_legacy_mode` | ./ecle.db exists → works without migration |
| `test_backup_restore` | Copy ecle-data → works on new path |

## Dependencies

- SPEC-013 (Settings & Config — adds home field)
- SPEC-029 (Artifact Store — uses ECLE_HOME/artifacts/)
- SPEC-034 (Logging — uses ECLE_HOME/logs/)
- ADR-017 (Deployment modes — Docker/K8s use ECLE_HOME env var)
