# SPEC-027: Materialize — AMF Stage Output from Structured DB

**Status**: Spec (revised)
**Owner**: Integration Engineer
**Files**: `src/ecle/ingestion/materialization.py` (new), `src/ecle/cli.py` (add command)

## Purpose

Produce AMF-compatible stage outputs (FSS, FPS, PVG, KAG) from ECLE's structured DB so existing AMF agents (business-analyst-summarizer, technical-summarizer, migration-planner) can consume ECLE-produced knowledge without modification.

**What materialize does NOT do:**
- Does NOT reconstruct `.facts.json` — those are the INPUT from CPG, kept in the artifact store (SPEC-029)
- Does NOT regenerate `cpg.bin` — that's Joern's job, intentionally dropped

**What materialize does:**
- Produces the OUTPUT that AMF's serial pipeline stages (FSS → FPS → PVG → KAG) would have generated
- Reads from structured DB + vector index → writes to `output/` directory in AMF format

## ADR References

- [ADR-001](../../constitution/decisions/ADR-001-fact-replaces-serial-pipeline.md) — FACT replaces serial pipeline
- [ADR-011](../../constitution/decisions/ADR-011-cpg-storage-and-amf-reuse.md) — AMF reuse strategy
- CLAUDE.md: "What PVG/KAG/SOL produced is now on-demand views"

## Architecture

```
AMF serial pipeline (old):
  CPG → FSS stage → FPS stage → PVG stage → KAG stage → MIG stage
         ↓            ↓            ↓            ↓
       .fss.json   .flow.json   .pv.json    summary.md

ECLE materialize (new):
  Structured DB ──→ ecle materialize --format amf ──→ same output files
       ↑                                                    ↓
  All data already                              AMF agents read these
  in DB tables
```

## Output Structure

```
output/
├── fss/                              ← FSS: per-file behavioral summaries
│   ├── billing.c.fss.json
│   ├── batch_rating.ppc.fss.json
│   └── ...
├── fps/                              ← FPS: topology edges as flow graphs
│   ├── billing.c.flow.json
│   └── edges.json                    ← consolidated edge list
├── pvg/                              ← PVG: projection views (21 types)
│   ├── system_map.pv.json
│   ├── database.pv.json
│   ├── data_model.pv.json
│   ├── cross_file.pv.json
│   └── ...
├── kag/                              ← KAG: knowledge summaries
│   └── md/
│       ├── summary.md
│       ├── catalog.md
│       └── data_dictionary.md
└── stats.json                        ← overall stats
```

## What Maps Where

| AMF Stage | ECLE Source | Materialize Logic |
|-----------|-----------|-------------------|
| **FSS** (.fss.json) | `file_facts` + `function_facts` + `file_tables` | Per-file: aggregate functions, tables, complexity, execution model |
| **FPS** (.flow.json) | `topology_edges` + `function_calls` | Per-file: outbound edges, call chains. Consolidated: all edges |
| **PVG system_map** | `file_facts` + `clusters` | Component inventory, cluster assignments, language distribution |
| **PVG database** | `file_tables` + `function_table_ops` | Table list, CRUD operations per table, which files touch them |
| **PVG data_model** | `file_tables` cross-joined | Table relationships inferred from shared access patterns |
| **PVG cross_file** | `topology_edges` | Dependency graph, edge weights, signal types |
| **KAG summary** | `get_stats()` + `clusters` | System overview, metrics, cluster summary |
| **KAG catalog** | `file_facts` listing | File inventory with language, complexity, function count |
| **KAG data_dictionary** | `file_tables` + DDL documents | Table definitions, operations, relationships |

## Interface

```python
# src/ecle/ingestion/materialization.py

class Materializer:
    """Produce AMF-compatible stage outputs from ECLE structured DB."""

    def __init__(self, db, vector_store=None, repo_id: str = "default"):
        self.db = db
        self.vector_store = vector_store
        self.repo_id = repo_id

    def materialize_amf(self, output_dir: Path) -> dict:
        """Full AMF output directory. Returns counts per stage."""

    # ── FSS (per-file behavioral summary) ──────────────────
    def materialize_fss(self, output_dir: Path) -> int:
        """Produce output/fss/{file_id}.fss.json for all current files."""

    def export_fss(self, file_id: str) -> dict:
        """Single file FSS summary."""

    # ── FPS (topology edges as flows) ──────────────────────
    def materialize_fps(self, output_dir: Path) -> int:
        """Produce output/fps/ edge files."""

    # ── PVG (projection views) ─────────────────────────────
    def materialize_pvg(self, output_dir: Path) -> int:
        """Produce output/pvg/*.pv.json projection views."""

    # ── KAG (knowledge summaries) ──────────────────────────
    def materialize_kag(self, output_dir: Path) -> int:
        """Produce output/kag/md/*.md knowledge summaries."""
```

## FSS Output Format

```json
// output/fss/billing.c.fss.json
{
  "file_id": "billing.c",
  "version": 2,
  "commit_sha": "def456",
  "language": "c",
  "execution_model": "batch",
  "complexity_max": 15,
  "complexity_avg": 6.2,
  "function_count": 12,
  "sql_count": 8,
  "functions": [
    {"name": "compute_late_fee", "complexity": 15, "is_entry_point": true,
     "calls": ["sql_error", "log_transaction"],
     "tables": [{"name": "FEES_LEDGER", "op": "WRITE"}]}
  ],
  "tables_accessed": ["FEES_LEDGER", "RATED_CDRS"],
  "table_operations": {
    "FEES_LEDGER": ["READ", "WRITE"],
    "RATED_CDRS": ["READ"]
  },
  "edges_out": [
    {"target": "batch_rating.ppc", "type": "WRITE_READ", "weight": 2.5, "artifact": "RATED_CDRS"}
  ],
  "cluster_id": "cluster_billing_0"
}
```

## CLI

```bash
# Full AMF export
ecle materialize --format amf --repo-id billing-svc --output ./output

# Single stage
ecle materialize --format amf --stage fss --repo-id billing-svc --output ./output
ecle materialize --format amf --stage fps --repo-id billing-svc --output ./output
ecle materialize --format amf --stage pvg --repo-id billing-svc --output ./output
ecle materialize --format amf --stage kag --repo-id billing-svc --output ./output

# Single file FSS (for debugging)
ecle materialize --format amf --stage fss --file billing.c --repo-id billing-svc
```

## Tests

| Test | What's Verified |
|------|----------------|
| `test_fss_export_single` | Single file FSS has all required fields |
| `test_fss_export_all` | All current files get FSS output |
| `test_fps_edges_export` | Topology edges exported in flow format |
| `test_pvg_system_map` | system_map.pv.json has components and clusters |
| `test_pvg_database` | database.pv.json has tables and operations |
| `test_kag_summary` | summary.md has stats and overview |
| `test_kag_catalog` | catalog.md lists all files |
| `test_kag_data_dictionary` | data_dictionary.md lists all tables |
| `test_full_materialize` | Full output directory with correct structure |
| `test_amf_agent_can_read` | Technical-summarizer can parse materialized PVG/FSS |

## Dependencies

- SPEC-029 (Artifact store — .facts.json kept there, not here)
- SPEC-001 (SQLite backend — data source)
- SPEC-004 (Topology — edges source for FPS)
- SPEC-018 (Clustering — cluster assignments for PVG)

## Phasing

| Priority | Stage | Effort | Needed by |
|----------|-------|--------|-----------|
| **P0** | FSS | Small | Technical summarizer reads all FSS |
| **P0** | FPS | Small | Business analyst reads FPS flows |
| **P1** | PVG (system_map, database, cross_file, data_model) | Medium | All agents read PVG |
| **P2** | KAG (summary, catalog, data_dictionary) | Medium | All agents read KAG |
| **P3** | PVG (remaining 17 projections) | Large | Technical summarizer reads all 21 |
