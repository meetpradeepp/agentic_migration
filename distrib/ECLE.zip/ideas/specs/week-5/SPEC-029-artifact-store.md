# SPEC-029: Artifact Store — Versioned Source + Facts Repository

**Status**: Spec
**Owner**: Infrastructure Engineer
**Files**: `src/ecle/ingestion/artifact_store.py` (new), `src/ecle/ingestion/facts_loader.py` (modify), `src/ecle/config/settings.py` (add config)

## Purpose

Provide a versioned artifact repository that stores original source files and their `.facts.json` alongside every version in the knowledge graph. This ensures:

1. **Traceability** — every DB record links back to the original source + facts
2. **Reproducibility** — re-import or re-extract from stored artifacts anytime
3. **Diff capability** — compare source/facts across versions
4. **No data loss** — source code available for display, search, and migration planning

`cpg.bin` (Joern binary graph) is intentionally **not stored** — it's large (~100MB+) and regenerable from source.

## ADR References

- [ADR-014](../../constitution/decisions/ADR-014-version-chain-everything-is-kept.md) — Version chain, nothing deleted
- [ADR-012](../../constitution/decisions/ADR-012-facts-folder-sync.md) — Facts sync mechanism

## Architecture

### Storage Layout

```
{artifact_root}/
  {repo_id}/
    {commit_sha}/
      sources/                        ← original source files (code)
        billing.c
        batch_rating.ppc
        billing_defs.h
      facts/                          ← CPG-extracted .facts.json
        billing.c.facts.json
        batch_rating.ppc.facts.json
        billing_defs.h.facts.json
```

### What Gets Stored

| Artifact | Stored? | Size | Reason |
|----------|---------|------|--------|
| Source file (.c, .ppc, .sru, etc.) | Yes | Small (1-100KB) | Needed for diff, display, migration |
| `.facts.json` | Yes | Small (10-50KB) | Structured CPG output, ECLE input |
| `cpg.bin` | **No** | Large (100MB+) | Regenerable from source via Joern |
| Embeddings | **No** | In vector DB | Recomputable from facts |
| Edges | **No** | In structured DB | Recomputable from facts |

### DB Link

New column on `file_facts`:

```sql
ALTER TABLE file_facts ADD COLUMN artifact_path TEXT;
-- e.g. "billing-svc/abc123/facts/billing.c.facts.json"
```

## Interface

```python
# src/ecle/ingestion/artifact_store.py

class ArtifactStore:
    """Versioned artifact repository for source files and facts."""

    def __init__(self, root_path: str | Path):
        self.root = Path(root_path)

    def store_facts(
        self, repo_id: str, commit_sha: str, file_id: str, facts_bytes: bytes
    ) -> str:
        """Store a .facts.json file. Returns relative artifact path."""

    def store_source(
        self, repo_id: str, commit_sha: str, file_id: str, source_bytes: bytes
    ) -> str:
        """Store original source file. Returns relative artifact path."""

    def get_facts(self, repo_id: str, commit_sha: str, file_id: str) -> bytes | None:
        """Retrieve stored .facts.json for a specific version."""

    def get_source(self, repo_id: str, commit_sha: str, file_id: str) -> bytes | None:
        """Retrieve stored source file for a specific version."""

    def list_versions(self, repo_id: str, file_id: str) -> list[str]:
        """List all commit SHAs that have artifacts for this file."""

    def get_artifact_path(self, repo_id: str, commit_sha: str, file_id: str,
                          artifact_type: str = "facts") -> Path:
        """Get the full filesystem path to an artifact."""

    def cleanup_commit(self, repo_id: str, commit_sha: str) -> int:
        """Delete all artifacts for a commit (used by purge). Returns files deleted."""

    def disk_usage(self, repo_id: str | None = None) -> dict:
        """Report disk usage by repo. Returns {repo_id: {sources_mb, facts_mb, total_mb}}."""
```

## Integration with Import Pipeline

### Current flow (no artifact store):
```
ecle import ./facts/
    → reads .facts.json from user's directory
    → decomposes into DB
    → original files stay wherever user put them (may be deleted)
```

### New flow (with artifact store):
```
ecle import ./facts/
    → copies .facts.json to artifact store (before DB insert)
    → decomposes into DB
    → records artifact_path in file_facts
    → user can delete their copy — ECLE has it
```

### Code change in facts_loader.py:

```python
def load_file(self, facts_path, commit_sha, ...):
    raw_bytes = facts_path.read_bytes()
    
    # Store artifact BEFORE DB insert (crash-safe)
    if self.artifact_store:
        artifact_path = self.artifact_store.store_facts(
            self.repo_id, commit_sha, file_id, raw_bytes
        )
    
    # ... existing DB insert logic ...
    file_facts_data["artifact_path"] = artifact_path
```

### Source file storage (during git onboarding):

```python
# In git connector, after cloning:
for source_file in connector.list_source_files():
    source_bytes = (repo_path / source_file).read_bytes()
    artifact_store.store_source(repo_id, commit_sha, source_file, source_bytes)
```

## Configuration

```yaml
# ecle.yaml
artifacts:
  backend: local                 # local | s3 | minio
  path: ./ecle-data/artifacts    # local filesystem path
  store_sources: true            # keep source files (disable to save space)
  store_facts: true              # keep .facts.json (always recommended)

  # S3 (uncomment for cloud):
  # backend: s3
  # bucket: ecle-artifacts
  # prefix: artifacts/
  # region: us-east-1

  # MinIO (uncomment for on-prem object store):
  # backend: minio
  # endpoint: http://minio:9000
  # bucket: ecle-artifacts
  # access_key_env: MINIO_ACCESS_KEY
  # secret_key_env: MINIO_SECRET_KEY
```

## CLI

```bash
# View artifact for current version
ecle artifact get billing.c --repo-id billing-svc

# View artifact for specific version/commit
ecle artifact get billing.c --repo-id billing-svc --version 2
ecle artifact get billing.c --repo-id billing-svc --commit abc123

# View source file
ecle artifact get billing.c --repo-id billing-svc --type source

# Diff facts between versions
ecle artifact diff billing.c --repo-id billing-svc --v1 1 --v2 2

# Disk usage report
ecle artifact usage
ecle artifact usage --repo-id billing-svc

# Re-extract facts from stored source (if Joern available)
ecle artifact re-extract billing.c --repo-id billing-svc --commit abc123
```

## Version Change Handling

```
Commit abc123: billing.c first imported
    ├── artifact_store: repo/abc123/facts/billing.c.facts.json (stored)
    ├── artifact_store: repo/abc123/sources/billing.c (stored)
    └── file_facts: version=1, commit_sha=abc123, content_hash=hash1

Commit def456: billing.c modified
    ├── fast gate: hash1 ≠ hash2 → new version
    ├── artifact_store: repo/def456/facts/billing.c.facts.json (stored)
    ├── artifact_store: repo/def456/sources/billing.c (stored)
    └── file_facts: version=2, commit_sha=def456, previous_id→v1

Commit ghi789: billing.c unchanged
    ├── fast gate: hash2 == hash2 → skip
    └── no new artifact stored (deduplication via content hash)
```

## Deduplication

If two commits produce identical `.facts.json` (same content hash), the second import is skipped entirely (existing fast gate). No duplicate artifact is stored. The version chain only grows when content actually changes.

## Interaction with purge_file()

When `purge_file()` is called (hard delete):
1. Delete all DB rows (existing behavior)
2. Delete all artifacts for that file: `artifact_store.cleanup_file(repo_id, file_id)`

When `retire_file()` is called (soft delete):
1. Mark DB rows as not current (existing behavior)
2. Artifacts are **kept** — history preserved (ADR-014)

## Tests

| Test | What's Verified |
|------|----------------|
| `test_store_facts` | Facts file stored at correct path |
| `test_store_source` | Source file stored at correct path |
| `test_retrieve_facts` | Stored facts retrievable by repo+commit+file |
| `test_retrieve_source` | Stored source retrievable |
| `test_version_creates_new_artifact` | Modified file → new artifact under new commit |
| `test_unchanged_skips_artifact` | Unchanged file → no new artifact (fast gate) |
| `test_artifact_path_in_db` | file_facts.artifact_path populated after import |
| `test_purge_deletes_artifacts` | purge_file removes artifacts |
| `test_retire_keeps_artifacts` | retire_file preserves artifacts |
| `test_disk_usage` | Usage report returns correct sizes |
| `test_list_versions` | All versions listed for a file |

## REST API Layer

Artifacts are always accessed via the API — never directly by clients.
This ensures the architecture works whether ECLE is local or remote.

### Endpoints (added to api_router)

```
GET /api/artifacts/{repo_id}/{file_id}/facts?commit=import
  → Returns .facts.json content as JSON

GET /api/artifacts/{repo_id}/{file_id}/source?commit=import
  → Returns source file content as text

GET /api/artifacts/{repo_id}/{file_id}/search?pattern=Fget32&commit=import
  → Searches stored facts/source for regex pattern, returns matches with line numbers

GET /api/artifacts/{repo_id}?commit=import
  → Lists all stored files for a repo+commit
```

### MCP Fallback Tool

When structured DB queries return empty, MCP tools can fall back to
reading stored artifacts via the API:

```python
@mcp.tool()
def ecle_source_lookup(
    file_id: str, pattern: str, repo_id: str = "*"
) -> str:
    """Search stored source/facts for a pattern when DB doesn't have the answer.
    
    Falls back to artifact store. Returns matches with file, line, context.
    Use for: field extraction, API signature lookup, configuration patterns.
    """
```

### Fallback Priority

```
Question → DB lookup (fast, pre-computed, high confidence)
    ↓ empty?
Artifact store → read stored .facts.json → parse on demand (medium confidence)
    ↓ still empty?
Artifact store → read stored source → regex search (lower confidence)
```

## Dependencies

- SPEC-003 (Facts loader — modified to store artifacts)
- SPEC-009 (Git onboarding — source file storage)
- ADR-014 (Version chain — artifacts follow same immutability)
- SPEC-013 (Settings — artifact store config)
- SPEC-022 (GraphQL API — REST endpoints for artifact access)

## Not In Scope

- `cpg.bin` storage (intentionally excluded — too large, regenerable)
- Embedding artifact storage (lives in vector DB)
- Remote artifact retrieval over HTTP (future: when artifact store is S3/MinIO)
