# SPEC-036: CPG Extraction Trigger — Backend Service Integration

**Status**: Spec
**Owner**: CPG Pipeline Engineer
**Files**: `src/ecle/cpg/client.py` (new), `src/ecle/ingestion/post_process.py` (extend), `src/ecle/onboarding/pipeline.py` (extend), `src/ecle/config/settings.py` (add cpg config)

## Purpose

When source code is uploaded without `.facts.json`, the backend automatically triggers CPG extraction, waits for results, and ingests the generated facts. The frontend never deals with CPG — it sees the same import progress regardless of whether facts existed or had to be generated.

**Before:**
```
Code without facts → "No .facts.json found" → STOP
User must manually run Joern, then re-upload
```

**After:**
```
Code without facts → backend triggers CPG → facts generated → ingested
User sees: "Extracting code structure... 45%"
```

## Architecture

```
Frontend (UI / CLI / Webhook)
    │ "onboard repo X"
    ▼
Onboarding Pipeline (backend)
    │
    ├── .facts.json found? → ingest directly (existing path)
    │
    └── No facts? → CPG Client
                      │
                      ├── Mode A: Local process
                      │   subprocess.run(cpg_command, source_dir, output_dir)
                      │   → .facts.json produced locally
                      │
                      ├── Mode B: HTTP service
                      │   POST {cpg_url}/extract {source_dir, repo_id}
                      │   → poll GET {cpg_url}/status/{job_id}
                      │   → GET {cpg_url}/artifacts/{job_id} → .facts.json
                      │
                      └── Mode C: Not configured
                          → clear error: "CPG extraction not configured. 
                             Provide .facts.json or configure cpg in ecle.yaml"
```

## Configuration

```yaml
# ecle.yaml
cpg:
  enabled: false                   # true to auto-trigger CPG
  mode: local                      # local | service | disabled

  # Local mode: ECLE runs CPG as a subprocess
  local:
    command: python                 # executable
    script: stages/cpg/run.py      # path to extraction script
    timeout: 600                   # max seconds per repo

  # Service mode: ECLE calls an HTTP API
  service:
    url: http://cpg-service:9000   # CPG extraction service URL
    timeout: 600
    poll_interval: 5               # seconds between status checks

  # Language packs to use
  languages:
    - c
    - proc
    - powerbuilder
```

## Interface

### CPG Client

```python
# src/ecle/cpg/client.py

class CPGClient:
    """Triggers CPG extraction via local process or HTTP service."""

    def __init__(self, settings: CPGSettings):
        self.settings = settings

    def extract(
        self, source_dir: Path, output_dir: Path, 
        progress_callback: Callable | None = None
    ) -> CPGResult:
        """Extract facts from source code.
        
        Returns CPGResult with facts_dir pointing to generated .facts.json files.
        Blocks until extraction completes (with progress updates).
        """

    def _extract_local(self, source_dir, output_dir, progress_callback) -> CPGResult:
        """Run CPG as a subprocess."""

    def _extract_service(self, source_dir, output_dir, progress_callback) -> CPGResult:
        """Call CPG HTTP service, poll for completion."""


@dataclass
class CPGResult:
    status: str            # "success" | "failed" | "not_configured"
    facts_dir: Path | None
    files_extracted: int
    duration_ms: int
    error: str | None
```

### Integration with Onboarding Pipeline

```python
# In onboarding/pipeline.py

def onboard_from_git(self, repo_url_or_path, ...):
    # ... clone repo ...
    
    facts_dir = self._resolve_facts_dir(repo_path)
    
    if not facts_dir:
        # No facts found — try CPG extraction
        if self.cpg_client and self.cpg_client.settings.enabled:
            cpg_result = self.cpg_client.extract(
                source_dir=repo_path,
                output_dir=self.artifact_store.root / repo_id / "cpg_output",
                progress_callback=progress_callback,
            )
            if cpg_result.status == "success":
                facts_dir = cpg_result.facts_dir
            else:
                result.errors.append(f"CPG extraction failed: {cpg_result.error}")
                return result
        else:
            result.errors.append(
                "No .facts.json found. Either:\n"
                "  1. Provide facts via --facts-dir\n"
                "  2. Enable CPG extraction in ecle.yaml (cpg.enabled: true)\n"
                "  3. Run Joern manually: python stages/cpg/run.py"
            )
            return result
    
    # Continue with normal ingestion...
    return self.onboard_from_facts(facts_dir=facts_dir, ...)
```

## Local Mode

### Subprocess Execution

```python
def _extract_local(self, source_dir, output_dir, progress_callback):
    import subprocess
    
    cmd = [
        self.settings.local.command,
        self.settings.local.script,
        "--source", str(source_dir),
        "--output", str(output_dir),
    ]
    
    process = subprocess.Popen(
        cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE
    )
    
    # Stream progress from stdout
    for line in process.stdout:
        if progress_callback:
            progress_callback("cpg", line.decode().strip())
    
    returncode = process.wait(timeout=self.settings.local.timeout)
    
    if returncode != 0:
        error = process.stderr.read().decode()[:500]
        return CPGResult(status="failed", error=error, ...)
    
    facts_files = list(output_dir.rglob("*.facts.json"))
    return CPGResult(
        status="success",
        facts_dir=output_dir,
        files_extracted=len(facts_files),
    )
```

## Service Mode

### HTTP API Contract

The CPG service exposes:

```
POST /extract
  Body: {source_dir: "/data/repo", languages: ["c", "proc"]}
  Response: {job_id: "abc123", status: "queued"}

GET /status/{job_id}
  Response: {status: "running", progress: 45, message: "Processing file 12/27"}

GET /artifacts/{job_id}
  Response: ZIP file containing .facts.json files

DELETE /jobs/{job_id}
  Response: {status: "cleaned"}
```

### Polling

```python
def _extract_service(self, source_dir, output_dir, progress_callback):
    import httpx
    
    # Submit job
    r = httpx.post(f"{self.url}/extract", json={
        "source_dir": str(source_dir),
        "languages": self.settings.languages,
    })
    job_id = r.json()["job_id"]
    
    # Poll until complete
    while True:
        time.sleep(self.settings.poll_interval)
        status = httpx.get(f"{self.url}/status/{job_id}").json()
        
        if progress_callback:
            progress_callback("cpg", status.get("message", "Extracting..."))
        
        if status["status"] == "complete":
            break
        if status["status"] == "failed":
            return CPGResult(status="failed", error=status.get("error"))
    
    # Download artifacts
    r = httpx.get(f"{self.url}/artifacts/{job_id}")
    # ... extract ZIP to output_dir ...
    
    return CPGResult(status="success", facts_dir=output_dir, ...)
```

## Behavior

### User experience (UI)

```
Upload code → "Analyzing code structure..." (CPG running)
             → "Extracting 12/27 files..." (progress from CPG)
             → "Loading facts..." (normal import)
             → "Computing edges..."
             → "Embedding vectors..."
             → "Import Complete"
```

The user never sees "CPG" or "Joern" — they see "Analyzing code structure."

### User experience (CLI)

```bash
ecle onboard ./my-code --repo-id my-app

  ECLE Onboard
  Source:  ./my-code
  Repo:   my-app

  No .facts.json found. Running code analysis...
  Analyzing: 12/27 files processed...
  Analysis complete: 27 files, 342 functions extracted.

  Facts:   27 new, 0 updated
  Edges:   45 computed
  Vectors: 342 embedded

  Knowledge graph ready.
```

### Disabled mode

```bash
ecle onboard ./my-code --repo-id my-app

  Error: No .facts.json found and CPG extraction not configured.

  Options:
    1. Provide facts: ecle import ./facts/ --repo-id my-app
    2. Enable CPG: set cpg.enabled: true in ecle-data/config/ecle.yaml
    3. Manual extraction: python stages/cpg/run.py --source ./my-code/
```

## Tests

| Test | What's Verified |
|------|----------------|
| `test_local_extract` | subprocess called with correct args, facts dir returned |
| `test_local_timeout` | subprocess killed after timeout |
| `test_local_failure` | non-zero exit → CPGResult with error |
| `test_service_extract` | HTTP POST + polling + artifact download |
| `test_service_failure` | service returns error → CPGResult with error |
| `test_not_configured` | cpg.enabled=false → clear error message |
| `test_onboard_auto_cpg` | code without facts → CPG triggered → facts ingested |
| `test_onboard_with_facts` | code with facts → CPG NOT triggered |

## Dependencies

- SPEC-029 (Artifact store — CPG output stored in artifacts/)
- SPEC-035 (ECLE_HOME — CPG output goes under ecle-data/)
- SPEC-009 (Git onboarding — source files available for CPG)
- AMF `stages/cpg/run.py` — the actual extraction script

## Not In Scope

- Building or modifying Joern / CPG engine itself
- Language pack development
- Distributed CPG extraction (multiple workers)
- Incremental CPG (only re-extract changed files) — future optimization

## v1.3 Implementation Notes (2026-04-11)

**Status**: Implemented

### Changes from original spec

| Area | Spec Said | Implementation |
|------|-----------|---------------|
| Subprocess stderr | Separate `stderr=PIPE` | Merged: `stderr=subprocess.STDOUT` |
| Workspace root | Not specified | `PROJECT_ROOT` env var set to workspace dir (`client.py:165`) |
| Source dir | Not specified | `CODE_REPO` env var set to source dir (`client.py:166`) |
| Two-phase | Not specified | `--phase structural\|deep` passed to `run.py` (`client.py:224`). `STRUCTURAL_FACTS_DIR` env var for merge (`client.py:170`) |
| AMF venv | Single `.venv/` probe | 4-location probe: `.venv` + named `AMF` venv, Windows + Linux (`client.py:191-196`) |
| Windows Joern | `shutil.which("joern")` only | Also scans for `joern.bat`/`joern.cmd` via manual PATH search (`validators.py:220-231`) |
| Validators | Check workspace subdirs only | Falls back to `CODE_REPO` env var for uploaded code (`validators.py` BUG-007) |
| Structural phase | Not addressed | Missing `.cpg.bin` is warning (not error) when `EXTRACTION_PHASE=structural` (`validators.py` BUG-008) |
| Error truncation | Full error shown | `output_tail`: 2000 chars, `error`: 1000 chars (`client.py:276,282` BUG-014) |
| Path validation | Not specified | Spaces in source path → error on Windows (Joern limitation) (`client.py:125-133`) |
| Encoding | Not specified | `PYTHONIOENCODING=utf-8` set for AMF subprocess (`client.py:168`) |
| Process options | Basic Popen | Added `encoding="utf-8"`, `errors="replace"`, `cwd=amf_root` |
