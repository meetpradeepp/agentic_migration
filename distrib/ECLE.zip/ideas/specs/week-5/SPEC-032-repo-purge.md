# SPEC-032: Repo Purge — Complete Repo Removal

**Status**: Implemented
**Owner**: Infrastructure Engineer
**Files**: `src/ecle/backends/structured/sqlalchemy_backend.py`, `src/ecle/cli.py`

## Purpose

Provide a single command to completely remove a repo from the knowledge graph — all files, functions, edges, clusters, shared artifacts, service index, documents, and vector collections. No traces left.

Use cases:
- Re-onboarding a repo from scratch after CPG re-extraction
- Removing test/demo data
- GDPR / data compliance — right to deletion
- Cleaning up after a repo is decommissioned

## Interface

### CLI

```bash
# Nuke everything for a repo
ecle remove --repo-id billing-service --nuke-repo --db ecle.db

# Still works: remove specific files (existing behavior)
ecle remove billing.c batch_rating.ppc --repo-id billing-service --db ecle.db
ecle remove billing.c --repo-id billing-service --hard --db ecle.db
```

### Backend Method

```python
def purge_repo(self, repo_id: str) -> dict[str, Any]:
    """HARD DELETE an entire repo — all files, functions, edges, artifacts, indexes.
    
    Returns: {repo_id, status, files, functions, edges, shared_artifacts}
    """
```

## What Gets Deleted

| Table | What's removed | FK order |
|-------|---------------|----------|
| `function_calls` | All calls from functions in this repo | 1st (leaf) |
| `function_table_ops` | All function-table ops in this repo | 1st (leaf) |
| `file_tables` | All file-table ops in this repo | 2nd |
| `file_includes` | All includes in this repo | 2nd |
| `file_definitions` | All definitions in this repo | 2nd |
| `function_facts` | All functions in this repo | 3rd |
| `file_facts` | All file versions in this repo (ALL history) | 4th |
| `topology_edges` | All edges in this repo | 5th |
| `clusters` | All clusters in this repo | 5th |
| `shared_artifacts` | All shared artifacts from this repo | 5th |
| `service_function_map` | All service index entries for this repo | 5th |
| `documents` | All documents in this repo | 5th |
| `document_chunks` | All document chunks in this repo | 5th (before documents) |
| **Vector collections** | `{repo_id}__fss`, `{repo_id}__fn`, `{repo_id}__centroid`, `{repo_id}__docs` | Last |

## Behavior

```
$ ecle remove --repo-id billing-service --nuke-repo

  Purging ALL data for repo 'billing-service'...
  Vector collections deleted.
  Purged: 18 files, 154 functions, 45 edges, 250 shared artifacts
  Repo 'billing-service' is completely gone. No traces.
```

After purge:
- `ecle stats --repo-id billing-service` → 0 files, 0 functions, 0 edges
- `ecle_repos_tool()` → billing-service not listed
- `ecle_search("billing", repo_id="billing-service")` → empty
- `ecle_service_callers(any_function, repo_id="billing-service")` → empty

## Tests

| Test | What's Verified |
|------|----------------|
| `test_purge_repo_deletes_all` | Stats = 0 after purge |
| `test_purge_repo_leaves_other_repos` | Other repos untouched |
| `test_purge_repo_cleans_artifacts` | shared_artifacts empty for purged repo |
| `test_purge_repo_cleans_service_index` | service_function_map empty for purged repo |
| `test_purge_then_reimport` | Purge → re-import → correct stats |

## Dependencies

- SPEC-031 (Service index — service_function_map cleaned)
- SPEC-030 (Shared artifacts — shared_artifacts cleaned)
- ADR-014 (Version chain — purge overrides "nothing deleted" for explicit user action)
