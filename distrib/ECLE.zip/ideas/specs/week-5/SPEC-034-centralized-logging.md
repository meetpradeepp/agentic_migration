# SPEC-034: Centralized Structured Logging

**Status**: Implemented + Verified
**Owner**: Infrastructure Engineer
**Files**: All modules — every module gets its own logger

## Purpose

Add structured JSON logging to every ECLE module so that:
1. Every user action is traceable (who did what, when, how long)
2. Every error has context (which file, which repo, what failed)
3. Horizontal scaling works — logs from multiple pods/processes are distinguishable
4. Learning loop has data — queries, answers, latencies feed into Phase 5 analytics

Currently: **6 log statements in 1 file.** Should be: every ingestion, query, MCP call, and error logged.

## Architecture

### Centralized Configuration

```python
# Each module gets its logger via:
from ecle.logging_config import get_logger
logger = get_logger("ingestion.facts_loader")
```

### Log Output Format (JSON per line)

```json
{"timestamp": "2026-04-05T10:30:00Z", "level": "INFO", "component": "ecle.ingestion.facts_loader", "message": "Import complete", "repo_id": "argtbanhdr", "files": 410, "duration_ms": 3200, "instance_id": "pod-abc123"}
```

### Instance ID for Horizontal Scaling

Each ECLE process generates a unique `instance_id` at startup. This is included in every log line so that when 5 pods write to the same log aggregator (ELK, CloudWatch, Grafana Loki), you can filter by instance.

```python
# In logging_config.py
import uuid
INSTANCE_ID = str(uuid.uuid4())[:8]

class StructuredFormatter:
    def format(self, record):
        log_entry = {
            ...
            "instance_id": INSTANCE_ID,
        }
```

## What Gets Logged

### Tier 1: Always Log (INFO)

| Module | Event | Fields |
|--------|-------|--------|
| **cli** | Command started | command, args, db_path |
| **cli** | Command completed | command, duration_ms, result_summary |
| **facts_loader** | File imported | repo_id, file_id, status (new/updated/unchanged), version |
| **facts_loader** | Directory import complete | repo_id, new, updated, unchanged, errors, duration_ms |
| **topology** | Edges computed | repo_id, files_processed, edges_created, duration_ms |
| **embedding_pipeline** | Embedding complete | repo_id, files, functions, vectors, duration_ms |
| **service_index** | Index built | repo_id, services, paths, max_depth, duration_ms |
| **artifact_registry** | Backfill complete | counts_by_type, duration_ms |
| **field_extractor** | Fields extracted | repo_id, service_fields, parameters, fml, views |
| **query/app** | Server started | host, port, component, repos, db_url |
| **query/app** | Request handled | method, path, status_code, duration_ms |
| **chat_router** | Question answered | repo_id, method, template, confidence, duration_ms |
| **mcp/server** | Tool called | tool_name, params, result_count, duration_ms |
| **webhook** | Event received | provider, repo_url, branch, commit, status |
| **ui/routes** | Import triggered | repo_id, facts_dir, job_id |
| **ui/routes** | Import completed | repo_id, job_id, files, duration_ms |

### Tier 2: Warn on Degradation (WARNING)

| Event | Fields |
|-------|--------|
| Vector store unavailable | status, vector_dir, error |
| Embedding skipped | repo_id, reason |
| Backfill skipped | error |
| Service index skipped | error |
| File import error | repo_id, file_id, error_type, error_msg |

### Tier 3: Error (ERROR)

| Event | Fields |
|-------|--------|
| DB connection failed | db_url, error |
| Import crashed | repo_id, error_type, traceback |
| MCP tool exception | tool_name, error_type, error_msg |
| Webhook signature invalid | provider, error |

### Never Log

- Source code content
- Secret tokens, API keys, passwords
- Full file contents or SQL result sets
- User PII (if applicable in future)

## Implementation

### Pattern per Module

```python
# At top of each module:
from ecle.logging_config import get_logger
logger = get_logger("module_name")

# Usage:
logger.info("Import complete", extra={"context": {
    "repo_id": repo_id, "files": 18, "duration_ms": 3200
}})

logger.warning("Vectors skipped", extra={"context": {
    "repo_id": repo_id, "reason": "ChromaDB unavailable"
}})

logger.error("Import failed", exc_info=True, extra={"context": {
    "repo_id": repo_id, "file_id": file_id
}})
```

### Modules to Instrument

| Module | Logger name | Priority |
|--------|------------|----------|
| `cli.py` | `ecle.cli` | P0 |
| `ingestion/facts_loader.py` | `ecle.ingestion.facts_loader` | P0 |
| `ingestion/topology.py` | `ecle.ingestion.topology` | P0 |
| `ingestion/embedding_pipeline.py` | `ecle.ingestion.embedding` | P0 |
| `ingestion/service_index.py` | `ecle.ingestion.service_index` | P0 |
| `ingestion/field_extractor.py` | `ecle.ingestion.fields` | P1 |
| `ingestion/artifact_registry.py` | `ecle.ingestion.artifacts` | P1 |
| `ingestion/incremental.py` | `ecle.ingestion.incremental` | P1 |
| `query/app.py` | `ecle.query.app` | P0 |
| `query/chat_router.py` | `ecle.query.chat` | P0 |
| `mcp/server.py` | `ecle.mcp` | P0 |
| `mcp/cross_repo.py` | `ecle.mcp.cross_repo` | P1 |
| `connectors/webhook_receiver.py` | `ecle.connectors.webhook` | P0 |
| `connectors/git.py` | `ecle.connectors.git` | P1 |
| `ui/routes.py` | `ecle.ui` | P0 |
| `ui/progress.py` | `ecle.ui.progress` | P1 |
| `clustering/louvain.py` | `ecle.clustering` | P1 |
| `backends/sqlalchemy_backend.py` | `ecle.backends.db` | P2 (slow queries only) |

### Configuration

```yaml
# ecle.yaml
logging:
  level: INFO              # DEBUG | INFO | WARNING | ERROR
  format: json             # json | text (text for local dev)
  output: both             # stderr | file | both | off
  path: ../ecle-logs       # sibling to ECLE_HOME, not inside runtime data
  max_size_mb: 25          # per-service rotation size
  backup_count: 5          # number of rotated files to keep
```

### File Layout

```text
ecle-logs/
  api/api.log
  backend/backend.log
  mcp/mcp.log
  ui/ui.log
  worker/worker.log
```

Bucket routing is based on the logger/component name so uploads, queue work, jobs, and MCP events land in durable service-specific files.

## Dependencies

- SPEC-017 (Error handling — existing StructuredFormatter)
- Phase 5: Learning Loop — query logs feed interaction ledger
