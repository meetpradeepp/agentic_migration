# SPEC-031: Service Call Graph Index — Deterministic Answers for All Question Classes

**Status**: Spec
**Owner**: Graph Engineer
**Files**: `src/ecle/ingestion/service_index.py` (new), `src/ecle/backends/structured/models.py` (add table), `src/ecle/backends/structured/sqlalchemy_backend.py` (add methods)

## Purpose

Pre-compute a `service_function_map` during ingestion that traces every entry-point service's complete call chain. This single index eliminates agent-dependent reasoning for ALL question classes — "who calls X", "what's impacted if Y changes", "why are files A and B connected", "which services share table T".

**The problem it solves:** Two sessions asked "which Tuxedo services call pgn_gt_full_message" and got different answers. The MCP tools returned the same raw data, but the agent INTERPRETED it differently each time. The system must own the answer, not the agent.

## ADR References

- [ADR-027](../../constitution/decisions/ADR-027-cross-repo-query-completeness.md) — Cross-repo gaps
- CLAUDE.md: FACT quality standard — Accurate: "every claim grounded in structural evidence, zero hallucination"

## Architecture

### What Gets Built During Import

```
For each entry_point function (is_entry_point = 1):
    BFS through function_calls table
    Record every function + file reachable from this entry point
    Store in service_function_map
```

### The Index

```sql
CREATE TABLE IF NOT EXISTS service_function_map (
    service_name    TEXT NOT NULL,       -- entry point function name
    service_file    TEXT NOT NULL,       -- file containing the entry point
    callee_name     TEXT NOT NULL,       -- reachable function name
    callee_file     TEXT NOT NULL,       -- file containing the callee
    call_depth      INTEGER NOT NULL,    -- hops from entry point
    repo_id         TEXT NOT NULL,
    PRIMARY KEY(service_name, callee_name, callee_file, repo_id)
);

CREATE INDEX idx_sfm_callee ON service_function_map(callee_name, repo_id);
CREATE INDEX idx_sfm_callee_file ON service_function_map(callee_file, repo_id);
CREATE INDEX idx_sfm_service ON service_function_map(service_name, repo_id);
```

### Scale

| Metric | Typical | Max (1000-file repo) |
|--------|---------|---------------------|
| Entry points per repo | 20-50 | 200 |
| Avg reachable functions per entry point | 30-80 | 500 |
| Total rows per repo | 1,000-4,000 | 100,000 |
| Build time per repo | 1-3 seconds | 30 seconds |
| Storage per repo | 100KB-400KB | 10MB |

## Interface

```python
# src/ecle/ingestion/service_index.py

class ServiceIndexBuilder:
    """Builds the service_function_map by BFS from each entry point."""

    def __init__(self, db, repo_id: str):
        self.db = db
        self.repo_id = repo_id

    def build(self) -> dict:
        """Build the complete service function map for this repo.

        1. Get all entry point functions
        2. For each, BFS through function_calls
        3. Store reachable set in service_function_map
        4. Return stats

        Returns: {services, total_mappings, max_depth, build_time_ms}
        """

    def _bfs_from_entry_point(
        self, entry_fn_name: str, entry_file_id: str
    ) -> list[dict]:
        """BFS from one entry point. Returns list of reachable functions.

        Handles:
        - Cycle detection (visited set)
        - Max depth limit (10)
        - Cross-file calls (callee_name matched to function_facts)
        - Same-name functions in different files (scoped by call chain context)
        """
```

### Backend Methods

```python
# Added to SQLAlchemyBackend / IStructuredBackend

def get_service_callers(self, callee_name: str, repo_id: str = "*") -> list[dict]:
    """Which services reach this function through their call chain?

    Returns: [{service_name, service_file, callee_file, call_depth, repo_id}]
    """

def get_service_files(self, service_name: str, repo_id: str) -> list[dict]:
    """Which files does this service touch (transitively)?

    Returns: [{callee_file, call_depth, function_count}]
    """

def get_file_services(self, file_id: str, repo_id: str = "*") -> list[dict]:
    """Which services depend on this file?

    Returns: [{service_name, service_file, min_depth, repo_id}]
    """

def get_service_tables(self, service_name: str, repo_id: str) -> list[dict]:
    """Which tables does this service access transitively?

    Derived: JOIN service_function_map with function_table_ops.
    Returns: [{table_name, operation, via_function, via_file, call_depth}]
    """
```

### MCP Tools

```python
@mcp.tool()
def ecle_service_callers(function_name: str, repo_id: str = "*") -> str:
    """Which Tuxedo services invoke this function (directly or transitively)?

    Returns deterministic list: same answer every time, no agent interpretation.
    """

@mcp.tool()
def ecle_service_impact(target: str, target_type: str = "function",
                        repo_id: str = "*") -> str:
    """Change impact: what services are affected if this function/file/table changes?

    target_type: "function" | "file" | "table"
    Returns: services affected, with call depth and file paths.
    """

@mcp.tool()
def ecle_service_files(service_name: str, repo_id: str = "*") -> str:
    """Which files does this service touch? Full transitive dependency list."""
```

## Question Classes Answered

### 1. "Which services call X?"
```
ecle_service_callers("pgn_gt_full_message")
→ SELECT DISTINCT service_name, service_file, repo_id, MIN(call_depth)
  FROM service_function_map
  WHERE callee_name = 'pgn_gt_full_message'
  GROUP BY service_name, service_file, repo_id
→ 5 services. Same answer. Every time.
```

### 2. "What's the impact if X changes?"
```
ecle_service_impact("pgn_gt_full_message", target_type="function")
→ SELECT DISTINCT service_name, repo_id, MIN(call_depth) as distance
  FROM service_function_map
  WHERE callee_name = 'pgn_gt_full_message'
  GROUP BY service_name, repo_id
  ORDER BY distance
→ 5 services impacted, sorted by distance from change point
```

### 3. "Why is file A connected to file B?"
```
ecle_service_callers with file filter:
→ SELECT service_name, callee_name, call_depth
  FROM service_function_map
  WHERE service_file = 'par_ban_10.c' AND callee_file = 'pgn_gen_funcs_4.c'
→ "par_ban_10.c connects to pgn_gen_funcs_4.c because arGtDailyBal.arUpBan
    calls pgn_gt_full_message at depth 2"
```

### 4. "If RATED_CDRS schema changes, what services are affected?"
```
ecle_service_impact("RATED_CDRS", target_type="table")
→ JOIN service_function_map sfm
   JOIN function_table_ops fto ON sfm.callee_name = fto function linkage
   WHERE fto.table_name = 'RATED_CDRS'
→ All services that transitively access RATED_CDRS
```

### 5. "Which files does arGtDailyBal depend on?"
```
ecle_service_files("arGtDailyBal")
→ SELECT DISTINCT callee_file, MIN(call_depth), COUNT(*) as fn_count
  FROM service_function_map
  WHERE service_name = 'arGtDailyBal'
  GROUP BY callee_file
→ par_ban_10.c (depth 0), pgn_gen_funcs_4.c (depth 2), billing_defs.h (depth 2)
```

## Build Trigger

The index is built AFTER facts + edges are loaded:

```python
# In cli.py cmd_import and ui/progress.py, after topology edges:

# Step 5: Build service call graph index
from ecle.ingestion.service_index import ServiceIndexBuilder
builder = ServiceIndexBuilder(db, repo_id=repo_id)
index_result = builder.build()
print(f"  Services: {index_result['services']} indexed, "
      f"{index_result['total_mappings']} call paths")
```

Also available as CLI:
```bash
ecle build-service-index --db ecle.db --repo-id argtbanhdr
ecle build-service-index --db ecle.db   # all repos
```

## BFS Algorithm

```python
def _bfs_from_entry_point(self, entry_fn_name, entry_file_id):
    """BFS from entry point through function_calls."""
    queue = deque([(entry_fn_name, entry_file_id, 0)])  # (fn_name, file_id, depth)
    visited = set()
    results = []

    while queue:
        fn_name, file_id, depth = queue.popleft()

        if (fn_name, file_id) in visited:
            continue
        visited.add((fn_name, file_id))

        if depth > 0:  # don't include the entry point itself
            results.append({
                "service_name": entry_fn_name,
                "service_file": entry_file_id,
                "callee_name": fn_name,
                "callee_file": file_id,
                "call_depth": depth,
                "repo_id": self.repo_id,
            })

        if depth >= 10:  # max depth guard
            continue

        # Find functions called by this function
        callees = self.db.get_function_callees(fn_name, file_id, self.repo_id)
        for callee in callees:
            callee_name = callee["callee_name"]
            # Resolve callee to file (may be in same file or different file)
            callee_files = self.db.resolve_function_file(callee_name, self.repo_id)
            for cf in callee_files:
                queue.append((callee_name, cf["file_id"], depth + 1))

    return results
```

## New Backend Methods for BFS

```python
def get_function_callees(self, fn_name: str, file_id: str, repo_id: str) -> list[dict]:
    """Get all functions called by a specific function in a specific file."""
    # function_facts WHERE function_name = fn_name AND file_id = file_id
    # JOIN function_calls ON caller_id = function_facts.id
    # Return callee_name list

def resolve_function_file(self, fn_name: str, repo_id: str) -> list[dict]:
    """Find which file(s) define a function (by name, within repo)."""
    # function_facts WHERE function_name = fn_name AND repo_id = repo_id AND is_current = 1
    # Return [{file_id, function_id}]
```

## Tests

| Test | What's Verified |
|------|----------------|
| `test_bfs_simple_chain` | A→B→C produces map with depths 1,2 |
| `test_bfs_cycle_detection` | A→B→A doesn't loop forever |
| `test_bfs_max_depth` | Chain deeper than 10 is truncated |
| `test_bfs_cross_file` | A(file1)→B(file2) records cross-file connection |
| `test_service_callers_deterministic` | Same query returns same results every time |
| `test_service_impact_function` | Change to function → correct services listed |
| `test_service_impact_file` | Change to file → correct services listed |
| `test_service_impact_table` | Change to table → correct services via join |
| `test_service_files` | Service → all transitive file deps listed |
| `test_cross_repo_service_callers` | repo_id="*" spans all repos |
| `test_build_after_import` | CLI import triggers index build |
| `test_rebuild_idempotent` | Rebuilding produces identical results |

## Index Lifecycle

| Event | Action | Cost |
|-------|--------|------|
| `ecle import` | Auto-build for imported repo | Seconds |
| `ecle remove --nuke-repo` | Delete all entries for repo | Instant |
| `ecle remove <file> --hard` | Delete entries where callee_file or service_file = removed file | Instant |
| `ecle remove <file>` (retire) | Same — delete entries referencing the file | Instant |
| `ecle build-service-index` | Full rebuild (for already-loaded repos or after manual changes) | Seconds per repo |

Both `retire_file()` and `purge_file()` clean the service index automatically:
```python
# In retire_file and purge_file:
DELETE FROM service_function_map
WHERE (callee_file = :file_id OR service_file = :file_id) AND repo_id = :repo_id
```

No manual rebuild needed after file removal.

## Dependencies

- SPEC-003 (Facts loader — provides function_facts + function_calls)
- SPEC-004 (Topology — provides the graph structure)
- SPEC-024 (IStructuredBackend — new methods added to interface)
- SPEC-030 (Cross-repo fixes — entry points and shared artifacts populated)
- ADR-026 (SQLAlchemy — new table + methods on SQLAlchemyBackend)

## What This Does NOT Solve

- **Natural language understanding** — "how does billing work" still needs LLM to route to the right query
- **Narrative generation** — turning rows into prose still needs LLM (when available) or templates
- **Indirect effects** — if a table's semantics change (column meaning), structural analysis can't detect that
- **Dynamic dispatch** — function pointers, virtual methods, reflection are invisible to CPG

These are acknowledged limitations. What it DOES solve: every structural question has one deterministic answer, regardless of which session or agent asks it.
