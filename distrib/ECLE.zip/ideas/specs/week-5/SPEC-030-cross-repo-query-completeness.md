# SPEC-030: Cross-Repo Query Completeness — Fix MCP Tool Gaps

**Status**: Draft
**Owner**: MCP Tool Engineer + CPG Pipeline Engineer
**Phase**: Week 5
**Files**: `src/ecle/mcp/server.py` (modify), `src/ecle/mcp/cross_repo.py` (modify), `src/ecle/backends/structured/sqlite.py` (modify), `src/ecle/ingestion/artifact_registry.py` (modify), `src/ecle/cli/import_cmd.py` or equivalent (modify)

## Purpose

Close 5 compounding failures that prevent cross-repo MCP tools from working. Discovered in a live session on 2026-04-04 where `ecle_find_callers("pgn_gt_full_message")` returned empty despite 58 call sites existing across 5 onboarded repos.

## ADR References

- [ADR-027](../../constitution/decisions/ADR-027-cross-repo-query-completeness.md) — the decision record for these fixes
- [ADR-019](../../constitution/decisions/ADR-019-shared-artifact-registry.md) — shared artifact registry design
- [ADR-020](../../constitution/decisions/ADR-020-cross-repo-mcp-tools.md) — cross-repo MCP tool definitions
- [ADR-021](../../constitution/decisions/ADR-021-error-handling-and-observability.md) — error handling principles

## Inputs

- Existing `ecle.db` with 6 onboarded repos and populated `file_facts`, `function_facts`, `function_calls`, `file_tables`
- Existing MCP server code (`src/ecle/mcp/server.py`, `src/ecle/mcp/cross_repo.py`)
- Existing backend code (`src/ecle/backends/structured/sqlite.py`)
- Existing ingestion code (`src/ecle/ingestion/artifact_registry.py`)

## Outputs

- All 6 cross-repo MCP tools return correct results
- All repo-scoped tools support `repo_id="*"` wildcard
- `shared_artifacts` table populated from existing facts
- `ecle_repos_tool` no longer crashes
- Vector store status is diagnosable

---

## Fix 1: Resilient Lazy Initialization

### Problem

`_ensure_db()` in `server.py:51-60` sets `_db_ready = True` (line 54) before `_db` is assigned (line 59). If `connect()` throws, `_db` stays `None` but `_db_ready` is `True`, so all subsequent calls skip initialization and call methods on `None`.

### Changes

**File: `src/ecle/mcp/server.py`**

```python
# BEFORE (buggy):
def _ensure_db():
    global _db, _db_ready
    if _db_ready:
        return
    _db_ready = True                          # ← flag set BEFORE assignment
    from ecle.backends.structured.sqlite import SQLiteBackend
    _db = SQLiteBackend(_DB_PATH)
    _db.connect()

# AFTER (fixed):
def _ensure_db():
    global _db, _db_ready
    if _db_ready:
        return
    try:
        from ecle.backends.structured.sqlite import SQLiteBackend
        backend = SQLiteBackend(_DB_PATH)
        backend.connect()
        _db = backend                         # assign FIRST
        _db_ready = True                      # flag AFTER success
    except Exception as e:
        import logging
        logging.getLogger("ecle.mcp").error("Failed to initialize DB: %s", e)
        raise
```

**File: `src/ecle/mcp/cross_repo.py`**

Add None guard in `_get_db()`:

```python
def _get_db():
    from ecle.mcp.server import _db, _ensure_db
    _ensure_db()
    if _db is None:
        raise RuntimeError(
            "ECLE database not initialized. Check ECLE_DB path and database file."
        )
    return _db
```

### Tests

1. `_ensure_db()` with valid DB path → `_db` is not None, `_db_ready` is True
2. `_ensure_db()` with invalid DB path → raises, `_db_ready` stays False, retry works
3. `ecle_repos_tool()` with broken DB → returns structured error JSON, not NoneType crash

---

## Fix 2: `repo_id="*"` Wildcard Support

### Problem

All repo-scoped tools default to `repo_id="billing-service"`. No way to query across repos. Agent must know repo IDs in advance (which requires `ecle_repos_tool`, blocked by Fix 1).

### Changes

**File: `src/ecle/backends/structured/sqlite.py`**

Modify all repo-scoped query methods to support wildcard:

```python
def find_callers_of(self, callee_name: str, repo_id: str = "default") -> list[sqlite3.Row]:
    """Find current functions that call a given function name.
    
    Pass repo_id="*" to search across all repos.
    """
    sql = """
        SELECT fn.*, fc.line as call_line, fc.call_type
        FROM function_facts fn
        JOIN function_calls fc ON fn.id = fc.caller_id
        WHERE fc.callee_name = ? AND fn.is_current = 1
    """
    params: list[Any] = [callee_name]
    if repo_id != "*":
        sql += " AND fn.repo_id = ?"
        params.append(repo_id)
    return self.fetchall(sql, tuple(params))
```

Apply the same pattern to these methods:
- `list_files_filtered()` — add conditional `repo_id` clause
- `list_functions_filtered()` — add conditional `repo_id` clause
- `find_files_by_table()` — add conditional `repo_id` clause
- `impact_traversal()` — add conditional `repo_id` clause (with performance LIMIT for "*")
- `get_file_history()` — add conditional `repo_id` clause
- `get_stats()` — when `repo_id="*"`, aggregate across all repos

**File: `src/ecle/mcp/server.py`**

Update tool descriptions to document wildcard:

```python
@mcp.tool()
def ecle_find_callers(function_name: str, repo_id: str = _REPO_ID) -> str:
    """Find all functions that call a given function name.
    function_name: e.g. 'sql_error', 'compute_late_fee'.
    repo_id: specific repo or '*' for all repos.
    NOT a file name -- use ecle_file for file lookups."""
```

**Performance guardrail:** When `repo_id="*"`, add `LIMIT 500` to prevent unbounded result sets. Include `"truncated": true` in response if limit was hit.

### Methods to Modify

| Method | File | Line | Change |
|--------|------|------|--------|
| `find_callers_of` | sqlite.py | 203 | Conditional `repo_id` WHERE clause |
| `list_files_filtered` | sqlite.py | ~160 | Conditional `repo_id` WHERE clause |
| `list_functions_filtered` | sqlite.py | ~170 | Conditional `repo_id` WHERE clause |
| `find_files_by_table` | sqlite.py | 188 | Conditional `repo_id` WHERE clause |
| `impact_traversal` | sqlite.py | 215 | Conditional `repo_id` WHERE clause + LIMIT |
| `get_file_history` | sqlite.py | ~260 | Conditional `repo_id` WHERE clause |
| `get_stats` | sqlite.py | ~280 | Conditional aggregation |

### Tests

1. `find_callers_of("pgn_gt_full_message", repo_id="*")` → returns 58 rows across 5 repos
2. `find_callers_of("pgn_gt_full_message", repo_id="argtbanhdr")` → returns only argtbanhdr callers
3. `list_functions_filtered(repo_id="*")` → returns functions from all repos, each row includes `repo_id`
4. Wildcard with LIMIT → `truncated: true` in response when limit exceeded
5. `ecle_stats(repo_id="*")` → aggregated counts across all repos

---

## Fix 3: Shared Artifact Backfill in Ingestion Pipeline

### Problem

The `shared_artifacts` table exists (SPEC-014 schema) and backfill functions exist (`sqlite.py:820-870`), but the ingestion pipeline never calls them. Table has 0 rows.

### Changes

**File: `src/ecle/ingestion/artifact_registry.py`**

Add a top-level `backfill_all_artifacts()` that chains the individual backfills:

```python
def backfill_all_artifacts(
    db: SQLiteBackend,
    repo_id: str,
    tenant_id: str = "default",
) -> dict[str, int]:
    """Populate shared_artifacts from existing facts for a repo.
    
    Called after fact ingestion completes (import, onboard, re-ingest).
    Returns counts of artifacts registered per type.
    """
    counts = {}
    counts["TABLE"] = db.backfill_table_artifacts(repo_id, tenant_id)
    counts["TUXEDO_SERVICE_CALL"] = db.backfill_service_artifacts(repo_id, tenant_id)
    counts["TUXEDO_SERVICE_IMPL"] = db.backfill_entry_point_artifacts(repo_id, tenant_id)
    counts["FUNCTION"] = db.backfill_function_artifacts(repo_id, tenant_id)  # Fix 4
    return counts
```

**File: `src/ecle/cli/import_cmd.py`** (or wherever `ecle import` is implemented)

Add backfill call after fact ingestion:

```python
# After all file ingestion for the repo completes:
from ecle.ingestion.artifact_registry import backfill_all_artifacts
counts = backfill_all_artifacts(db, repo_id, tenant_id)
logger.info("Shared artifacts backfilled: %s", counts)
```

**New CLI command: `ecle backfill-artifacts`**

For retroactively populating shared_artifacts for already-onboarded repos:

```python
@cli.command()
def backfill_artifacts():
    """Populate shared_artifacts table from existing facts (all repos)."""
    db = get_db()
    repos = db.get_repos()
    for repo in repos:
        counts = backfill_all_artifacts(db, repo["repo_id"])
        click.echo(f"  {repo['repo_id']}: {counts}")
```

### Tests

1. After `ecle import <folder>`, `shared_artifacts` has rows for tables and services in that folder
2. `ecle backfill-artifacts` populates shared_artifacts for all existing repos
3. Re-running backfill is idempotent — same counts, no duplicates
4. Backfill correctly handles `is_current = 1` filter (only current facts)

---

## Fix 4: FUNCTION Artifact Type

### Problem

ADR-019 defines TABLE, TUXEDO_SERVICE, API_ENDPOINT, MESSAGE_QUEUE, SHARED_HEADER, FML_BUFFER. It does not define FUNCTION. When `pgn_gt_full_message` is called from 5 repos, there's no artifact tracking this cross-repo function dependency.

### Changes

**File: `src/ecle/backends/structured/sqlite.py`**

Add new backfill method:

```python
def backfill_function_artifacts(
    self, repo_id: str, tenant_id: str = "default"
) -> int:
    """Register cross-repo function calls as shared artifacts.
    
    A function is registered as a FUNCTION artifact if it is called from
    multiple repos. Operations: CALL (this repo calls it), DEFINE (this repo
    defines it as a function_fact).
    """
    now = _now_iso()
    
    # Step 1: Find function names called from this repo that are also called
    # from at least one OTHER repo
    cross_repo_callees = self.fetchall(
        """
        SELECT DISTINCT fc.callee_name
        FROM function_calls fc
        JOIN function_facts fn ON fc.caller_id = fn.id
        WHERE fn.repo_id = ? AND fn.is_current = 1
          AND fc.callee_name IN (
            SELECT fc2.callee_name
            FROM function_calls fc2
            JOIN function_facts fn2 ON fc2.caller_id = fn2.id
            WHERE fn2.is_current = 1 AND fn2.repo_id != ?
          )
        """,
        (repo_id, repo_id),
    )
    
    count = 0
    for row in cross_repo_callees:
        callee = row["callee_name"]
        
        # Register CALL entries: files in this repo that call this function
        callers = self.fetchall(
            """
            SELECT DISTINCT fn.file_id, fc.line
            FROM function_calls fc
            JOIN function_facts fn ON fc.caller_id = fn.id
            WHERE fc.callee_name = ? AND fn.repo_id = ? AND fn.is_current = 1
            """,
            (callee, repo_id),
        )
        for caller in callers:
            self.execute(
                """
                INSERT OR IGNORE INTO shared_artifacts
                    (tenant_id, artifact_type, artifact_name, repo_id, file_id,
                     operation, line_number, commit_sha, is_current, created_at)
                VALUES (?, 'FUNCTION', ?, ?, ?, 'CALL', ?, 'backfill', 1, ?)
                """,
                (tenant_id, callee, repo_id, caller["file_id"],
                 caller["line"], now),
            )
            count += 1
        
        # Register DEFINE entries: if this repo defines the function
        definitions = self.fetchall(
            """
            SELECT DISTINCT fn.file_id, fn.line_start
            FROM function_facts fn
            WHERE fn.function_name = ? AND fn.repo_id = ? AND fn.is_current = 1
            """,
            (callee, repo_id),
        )
        for defn in definitions:
            self.execute(
                """
                INSERT OR IGNORE INTO shared_artifacts
                    (tenant_id, artifact_type, artifact_name, repo_id, file_id,
                     operation, line_number, commit_sha, is_current, created_at)
                VALUES (?, 'FUNCTION', ?, ?, ?, 'DEFINE', ?, 'backfill', 1, ?)
                """,
                (tenant_id, callee, repo_id, defn["file_id"],
                 defn["line_start"], now),
            )
            count += 1
    
    self.commit()
    return count
```

### Tests

1. 2 repos both call `pgn_gt_full_message` → FUNCTION artifact created with CALL operations for both repos
2. 1 repo defines `pgn_gt_full_message` → FUNCTION artifact with DEFINE operation
3. Function called within only 1 repo → NOT registered (not cross-repo)
4. `ecle_shared_artifacts_tool(artifact_name="pgn_gt_full_message", artifact_type="FUNCTION")` → returns both repos
5. `ecle_cross_repo_edges_tool(repo_id="argtbanhdr")` → includes FUNCTION edges to other repos
6. `ecle_service_map_tool` extended to also show shared function dependencies (optional)

---

## Fix 5: Vector Store Status Reporting

### Problem

`_ensure_vectors()` catches all exceptions silently (`except Exception: pass`). `ecle_search` returns `{"error": "Semantic search not available (no vector store)"}` with no diagnostic info.

### Changes

**File: `src/ecle/mcp/server.py`**

```python
_vector_status = "not_initialized"

def _ensure_vectors():
    global _vector_store, _vector_ready, _vector_status
    if _vector_ready:
        return
    _vector_ready = True
    if not Path(_VECTOR_DIR).exists():
        _vector_status = "no_directory"
        return
    try:
        from ecle.backends.vector.chromadb_store import ChromaDBStore
        _vector_store = ChromaDBStore(_VECTOR_DIR)
        _vector_status = "ready"
    except ImportError:
        _vector_status = "chromadb_not_installed"
    except Exception as e:
        _vector_status = f"error: {e}"
```

Update `ecle_search` to include status:

```python
if not _vector_store:
    return json.dumps({
        "error": "Semantic search not available",
        "status": _vector_status,
        "vector_dir": _VECTOR_DIR,
        "hint": "Run 'ecle embed-all' to generate vectors, or check ECLE_VECTORS path."
    })
```

### Tests

1. Vector dir doesn't exist → `ecle_search` returns `status: "no_directory"`
2. ChromaDB not installed → `status: "chromadb_not_installed"`
3. Model loading fails → `status: "error: ..."` with exception message
4. Happy path → `status: "ready"`, search works

---

## Integration Test: End-to-End Cross-Repo Discovery

After all 5 fixes, this scenario must work:

```
1. ecle_repos_tool()
   → Returns 6 repos with stats (no crash)

2. ecle_find_callers("pgn_gt_full_message", repo_id="*")
   → Returns 58 call sites across 5 repos

3. ecle_shared_artifacts_tool(artifact_name="pgn_gt_full_message", artifact_type="FUNCTION")
   → Returns 5 repos with CALL operations, files, line numbers

4. ecle_cross_repo_edges_tool(repo_id="argtbanhdr")
   → Returns connections to other repos via shared functions and tables

5. ecle_cross_repo_impact_tool(artifact_name="pgn_gt_full_message", artifact_type="FUNCTION")
   → Returns all 5 repos as directly affected, with file-level detail
```

**Zero raw SQL. Zero guessing. All via MCP.**

---

## Files Changed

| File | Change | Fixes |
|------|--------|-------|
| `src/ecle/mcp/server.py` | Fix `_ensure_db()` ordering, vector status, tool descriptions | 1, 2, 5 |
| `src/ecle/mcp/cross_repo.py` | Add None guard in `_get_db()` | 1 |
| `src/ecle/backends/structured/sqlite.py` | `repo_id="*"` in 7 methods, `backfill_function_artifacts()` | 2, 4 |
| `src/ecle/ingestion/artifact_registry.py` | `backfill_all_artifacts()` orchestrator | 3 |
| `src/ecle/cli/import_cmd.py` | Call backfill after import | 3 |
| `tests/test_cross_repo_completeness.py` | **New** — end-to-end cross-repo test suite | All |

## Dependencies

- **SPEC-014** (Shared Artifact Registry) — Fix 3 calls its backfill functions; Fix 4 extends the artifact type set
- **SPEC-015** (Cross-Repo MCP Tools) — Fixes 1, 3, 4 make these tools functional
- **SPEC-002** (SQLite Backend) — Fix 2 modifies query methods
- **SPEC-008** (MCP Server) — Fixes 1, 2, 5 modify server initialization and tool signatures

## Priority

**Critical** — without these fixes, the entire cross-repo tool suite (SPEC-015) is non-functional. This blocks enterprise-scale discovery, which is ECLE's core value proposition over single-repo AMF.
