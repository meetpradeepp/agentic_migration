# SPEC-038: Source Vector Layer — Code-Level Semantic Search

**Status**: Spec
**Owner**: CPG Pipeline Engineer + Graph Engineer
**Files**: `src/ecle/ingestion/source_embedder.py` (new), `src/ecle/ingestion/post_process.py` (extend), `src/ecle/mcp/server.py` (extend), `src/ecle/ui/templates/health.html` (extend)

## Purpose

Embed actual source code into per-repo vector collections so that:
1. No file is ever "too large" to search
2. Code-level questions get answers when the structured DB is empty
3. Version diffs are answerable from vector history
4. Every language works — the model embeds text, chunking is language-aware

This is the ground truth fallback layer. When pre-computed facts don't have the answer, source vectors do.

## ADR References

- [ADR-028](../../constitution/decisions/ADR-028-deterministic-answers-service-index.md) — Deterministic answers
- [ADR-024](../../constitution/decisions/ADR-024-artifact-store-source-plus-facts.md) — Artifact store keeps source
- CLAUDE.md: FACT quality standard — Complete: "no silent gaps"

## Architecture

### Vector Collections (per repo)

```
{repo_id}__fss        ← Layer 1: file-level fact embeddings (existing)
{repo_id}__fn         ← Layer 2: function-level fact embeddings (existing)
{repo_id}__source     ← Layer 3: source code chunks (NEW)
```

### Chunk Strategy

| Language | File size | Chunk method | Avg chunks/file |
|----------|----------|-------------|----------------|
| C / Pro*C | 1K-10K lines | Function boundaries | 10-100 |
| PowerBuilder (.sru, .srw) | 100-500 lines | Method/event boundaries | 1-5 |
| Headers (.h) | 50-200 lines | Whole file | 1 |
| SQL (.srd, .srf) | 20-100 lines | Whole file | 1 |
| Large (>200 lines, no function info) | Any | Fixed 100-line with 20-line overlap | varies |

### Chunk Metadata

```json
{
  "id": "{repo_id}__{file_id}__{start}_{end}__{commit}",
  "text": "actual source code lines...",
  "metadata": {
    "repo_id": "mmupmemo",
    "file_id": "pmm_memo_4.c",
    "language": "proc",
    "function_name": "mmUpMemo",
    "start_line": 45,
    "end_line": 145,
    "commit_sha": "def456",
    "version": 2,
    "is_current": true,
    "chunk_type": "function_body"
  }
}
```

## Interface

### Source Embedder

```python
# src/ecle/ingestion/source_embedder.py

class SourceEmbedder:
    """Embeds source code chunks into per-repo vector collections."""

    def __init__(self, db, vector_store, artifact_store, repo_id):
        self.db = db
        self.vector_store = vector_store
        self.artifact_store = artifact_store
        self.repo_id = repo_id
        self.collection = f"{repo_id}__source"

    def embed_file(self, file_id: str, commit_sha: str) -> dict:
        """Chunk and embed a single source file."""

    def embed_changed(self, changed_file_ids: list[str], commit_sha: str) -> dict:
        """Embed only changed files (incremental)."""

    def embed_all(self, commit_sha: str) -> dict:
        """Embed all current files (first import)."""

    def chunk_source(self, source: str, file_id: str, language: str) -> list[Chunk]:
        """Split source into chunks using language-aware boundaries."""

    def mark_stale(self, file_id: str) -> int:
        """Mark previous version chunks as is_current=false."""
```

### Chunker

```python
@dataclass
class SourceChunk:
    text: str
    file_id: str
    start_line: int
    end_line: int
    function_name: str | None = None
    chunk_type: str = "code"  # function_body | header | full_file | fixed

def chunk_by_functions(source: str, file_id: str, functions: list[dict]) -> list[SourceChunk]:
    """Split by function boundaries from function_facts."""

def chunk_fixed_size(source: str, file_id: str, chunk_lines: int = 100, overlap: int = 20) -> list[SourceChunk]:
    """Fixed-size chunks with overlap for files without function info."""
```

## Integration with Import Pipeline

Added to `run_post_processing()`:

```python
# Step 4 (NEW): Embed source chunks
if artifact_store and vector_store:
    from ecle.ingestion.source_embedder import SourceEmbedder
    embedder = SourceEmbedder(db, vector_store, artifact_store, repo_id)
    source_result = embedder.embed_changed(changed_file_ids, commit_sha)
```

## Version Handling

### On new import (version N):
```
1. Mark previous chunks for changed files: is_current=false
2. Chunk new source
3. Embed with metadata: version=N, commit=xyz, is_current=true
4. Old chunks preserved (ADR-014) for temporal queries
```

### Incremental (only changed files):
```
Import 5 changed files out of 400:
  → Mark 5 files' old chunks stale
  → Re-chunk 5 files
  → Embed ~50 new chunks (not 4000)
  Cost: ~3s, not 40s
```

### Query filtering:
```python
# Current code:
results = vector_store.query(
    f"{repo_id}__source", question,
    top_k=10,
    where={"is_current": True}           # only latest version
)

# Historical:
results = vector_store.query(
    f"{repo_id}__source", question,
    top_k=10,
    where={"commit_sha": "abc123"}       # specific version
)
```

## MCP Tool Changes

### `ecle_source_lookup` (updated)

```python
@mcp.tool()
def ecle_source_lookup(file_id, pattern, repo_id="*"):
    """Search source code for a pattern.
    
    Uses vector search (fast, semantic) not regex (slow, literal).
    Works on any file size. Returns actual code with line numbers."""

    # Vector search — O(1) regardless of file size
    results = vector_store.query(
        f"{repo_id}__source",
        pattern,  # semantic, not regex
        top_k=10,
        where={"file_id": file_id, "is_current": True}
    )
    # Returns code chunks with line numbers, function context
```

### `ecle_search` (enhanced)

```python
# Today: searches fact embeddings only
# After: searches facts THEN source if needed

results = vector_store.query(f"{repo_id}__fss", question, top_k=5)
if not results or max_score < 0.4:
    # Fallback to source vectors for code-level detail
    source_results = vector_store.query(f"{repo_id}__source", question, top_k=5)
    results.extend(source_results)
```

### `ecle_service_io` (enhanced with source fallback)

```python
@mcp.tool()
def ecle_service_io(service_name, repo_id):
    # Try DB first (pre-computed, high confidence)
    fields = db.get_service_field_io(service_name, repo_id)
    if fields:
        return format_fields(fields, confidence=1.0)

    # Fallback: search source for Fget32/Fchg32 patterns
    source_results = vector_store.query(
        f"{repo_id}__source",
        f"Fget32 Fchg32 {service_name}",
        top_k=20,
        where={"function_name": service_name}
    )
    # Parse Fget32/Fchg32 from matched chunks
    return format_source_fields(source_results, confidence=0.8)
```

## Health Dashboard — Version & Source Coverage

### REST API

```
GET /ui/health/stats → {
    "argtbanhdr": {
        "files": 410,
        "functions": 3652,
        "edges": 1534,
        "table_ops": 965,
        "versions": 2,
        "latest_commit": "def456",
        "latest_import": "2026-04-05T10:30:00Z",
        "source_chunks": 12450,
        "source_coverage": 100
    }
}
```

### Health Page Display

```
Knowledge Graph

argtbanhdr
  410 Files | 3,652 Functions | 1,534 Edges | 965 Table Ops
  Versions: 2 (latest: def456, 2h ago)
  Source: 12,450 chunks | 100% coverage

mmupmemo
  38 Files | 180 Functions | 45 Edges | 120 Table Ops
  Versions: 1 (import)
  Source: 1,200 chunks | 100% coverage

Import Jobs
  Recent: mmupmemo — 38 files, 2m 13s [Complete]

Cross-Repo
  Services: 3,693 | Call paths: 29,319
  Shared: 250 tables | 2,506 functions | 3,683 services
```

## Scale

| Metric | 50 files | 400 files | 1000 files |
|--------|---------|----------|-----------|
| Source chunks | 2,000 | 15,000 | 40,000 |
| Embed time (first) | 10s | 40s | 120s |
| Embed time (5 changed) | 3s | 3s | 3s |
| Storage (ChromaDB) | 5MB | 40MB | 100MB |
| Query time | <100ms | <100ms | <100ms |

ChromaDB handles up to ~100K vectors well. Beyond that → Qdrant (Phase 4).

## Tests

| Test | What's Verified |
|------|----------------|
| `test_chunk_c_by_functions` | C file split at function boundaries |
| `test_chunk_pb_by_methods` | PowerBuilder split at event/method |
| `test_chunk_header_whole_file` | Small header → single chunk |
| `test_chunk_large_fixed_size` | Large file without functions → 100-line chunks with overlap |
| `test_embed_file` | Source chunks in vector collection with correct metadata |
| `test_embed_changed_incremental` | Only changed files re-embedded, old marked stale |
| `test_version_query_current` | is_current filter returns latest version |
| `test_version_query_historical` | commit_sha filter returns specific version |
| `test_source_lookup_mcp` | ecle_source_lookup returns code chunks |
| `test_service_io_fallback` | ecle_service_io falls back to source vectors when DB empty |
| `test_health_shows_coverage` | Health page shows source chunk count and coverage % |

## Dependencies

- SPEC-029 (Artifact store — source files stored during import)
- SPEC-005 (Embedding pipeline — same ONNX model reused)
- SPEC-031 (Service index — function_name metadata from service_function_map)
- ADR-014 (Version chain — old chunks preserved, not deleted)
- ADR-026 (SQLAlchemy — metadata queries for function boundaries)

## Phasing

| Phase | What | When |
|-------|------|------|
| P0 | Fixed-size chunking + embedding + source_lookup MCP | Immediate |
| P1 | Language-aware chunking (function boundaries) | After P0 tested |
| P2 | ecle_service_io source fallback | After P1 |
| P3 | ecle_search source fallback | After P2 |
| P4 | Version diff from source vectors | Phase 5+ |
| P5 | Health dashboard source coverage | With P0 |
