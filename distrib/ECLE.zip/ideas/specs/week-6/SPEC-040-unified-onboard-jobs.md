# SPEC-040: Unified Onboard Job Model

**Status**: Draft
**Owner**: Platform Architect + Onboarding Engineer
**Supersedes**: Portions of SPEC-009 (git onboarding), SPEC-011 (document onboarding)
**Modifies**: SPEC-037 (job queue), SPEC-023 (UI), SPEC-022 (API)
**Updates**: ADR-008 (Tier 3 from git), ADR-010 (onboarding modes)

## Problem Statement

The current onboarding system conflates **two orthogonal dimensions** into a single axis:

| Current Tab | Actual Content Type | Actual Source | Problem |
|-------------|-------------------|---------------|---------|
| Code | code | local folder | Type + source mixed |
| Git | code | git repo | Source pretending to be a content type |
| Documents | documents | local folder only | Why can't docs come from git? |
| Import Facts | facts (pre-extracted code) | local folder | A format variant, not a content type |

"Git" is not a content type — it's a source. "Import Facts" is pre-extracted code, not a separate type. Documents can live in git repos but the UI forces them through a local-folder-only path. Config scripts (shell, YAML, `.cfg`) — which are executable operational knowledge — have no home at all.

## Design Principle: Three Orthogonal Axes

```
AXIS 1: Content Type (WHAT)    →  determines extraction pipeline + target tier
AXIS 2: Source (WHERE)          →  determines how we get the files
AXIS 3: Schedule (WHEN)         →  determines one-time vs recurring vs re-run
```

Every combination of (content_type, source, schedule) is valid. The UI, CLI, and API all express these three axes independently.

---

## Content Types

| Content Type | Extraction Pipeline | Target Tier | File Extensions |
|-------------|-------------------|-------------|-----------------|
| **code** | CPG (Joern/LSP) → CanonicalFactFileBase | Tier 1 structured DB + Tier 2 vectors (layers 1, 2) | `.c`, `.cpp`, `.h`, `.ppc`, `.pc`, `.java`, `.py`, `.go`, `.js`, `.ts`, `.sru`, `.srf`, `.srw`, `.srd` |
| **config** | Config Parser → CanonicalConfigBase | Tier 1 structured DB + Tier 2 vectors (layers 1, 2) | `.sh`, `.ksh`, `.cfg`, `.yaml`, `.yml`, `.properties`, `.xml` (app config), `.ini`, `.env`, `.conf`, `Makefile`, `*.config` |
| **data** | Schema Parser → structured DB rows | **Tier 1** structured DB only (no vectors — 100% exact lookup) | `.xml` (domain defs), `.txt` (service desc), `.list`, `.tsv` (structured data) |
| **data-sql** | SQL/DDL/RQL Parser → structured DB rows | **Tier 1** structured DB (tables, columns, constraints, stored procs) | `.sql`, `.ddl`, `.rql`, `.pls`, `.pkb`, `.pks` (PL/SQL packages) |
| **documents** | Doc Parser → CanonicalDocBase (chunk + entity extract) | Tier 3 structured DB + vectors (layer 4) | `.md`, `.txt` (prose), `.rst`, `.html`, `.htm`, `.pdf`, `.docx`, `.csv` (data dict), `.xlsx`, `.pptx` |
| **facts** | None (pre-extracted) → direct load into ingestion | Tier 1 + Tier 2 (same as code, skip CPG) | `.facts.json` |

### HTML as Document Type

HTML files (`.html`, `.htm`) are ingested as documents. The reader strips tags, preserves heading structure (`<h1>`–`<h6>` → section hierarchy), extracts text content from `<p>`, `<li>`, `<td>` elements, and discards scripts/styles. Same chunking strategy as markdown.

### Data as Tier 1 (Structured Schema Files)

Structured data files — Tuxedo domain XMLs, service descriptions, field lists, service-to-source mappings — are NOT documents. They are the system's **type system and API specification** in a non-code format. Embedding and chunking them destroys their structure. They need deterministic parsing into exact structured DB rows.

Example: 5,056 Tuxedo domain XML files define every field in the API surface (name, type, length, valid values, subject area). 640 service description files define every service contract (inputs, outputs, error codes, flow). These are **Tier 1 authority** — as definitive as CPG-extracted code facts.

### Data-SQL as Tier 1 (SQL/DDL/RQL Schema Files)

SQL schema files (`.sql`, `.ddl`) contain CREATE TABLE, CREATE INDEX, ALTER TABLE, stored procedure definitions. RQL files (`.rql`) are query definitions used by reporting and ETL tools. PL/SQL package specs (`.pks`) and bodies (`.pkb`) define Oracle stored procedure interfaces.

These are parsed into `db_tables`, `db_columns`, `db_indexes`, `db_constraints`, `stored_procedures` tables in the structured DB. They link directly to code facts via table name matches (`file_tables.table_name = db_tables.table_name`).

**Data-SQL is separated from Documents** because `.sql` files have dual personality — they can be DDL schemas (structured, Tier 1) or ad-hoc queries in documentation (prose, Tier 3). The content_type selector resolves this ambiguity explicitly rather than guessing from extension.

### Config as Tier 1

Config files control runtime behavior as much as compiled code. Examples from real billing systems:

- `blpool.config` — maps 133 jobs to 11 execution pools
- `UBBCONFIG` — Tuxedo server definitions, MIN/MAX instances
- `application.cfg` — build targets, server groups, compile flags
- Shell scripts (`blsre_*`, `blbn_*`) — orchestration logic
- `tlg_profile` — environment variables controlling billing behavior
- `.properties`, `.yaml` — Spring/Java application config

These get Tier 1 treatment: extracted into structured DB facts (parameters, values, env vars, dependencies), embedded into Tier 2 vectors for semantic search.

## Sources

| Source | How It Works | What It Provides |
|--------|-------------|-----------------|
| **git** | Clone/pull via GitConnector → file enumeration → change detection via commits | `commit_sha`, `branch`, diff history, ChangeEvent stream |
| **local** | Scan directory → file enumeration → content hash for change detection | No commit history; snapshot semantics with content-hash-based change detection |

Any content type can come from either source. All 8 combinations are valid:

| | Git | Local |
|---|---|---|
| **code** | Primary flow (clone, CPG extract, ingest, watch for commits) | Air-gapped/legacy (scan, CPG extract, ingest, manual re-run) |
| **config** | Same as code (configs live alongside code in git) | Exported configs from production systems |
| **documents** | Docs repo in git (analysis, quality assessments, system maps) | OneDrive, shared drives, downloaded exports |
| **facts** | Pre-generated facts checked into a repo | Joern exports on local disk |

## Schedules

| Schedule | Behavior | Use Case |
|----------|----------|----------|
| **once** | Run once, complete, done | Initial onboarding, snapshot import |
| **recurring** | Watch for changes, re-trigger automatically | Git webhook/poll for code repos; periodic re-scan for local folders |
| **re-run** | Manual trigger to redo a completed/failed job | After fixing extraction issues, updated config, retry on failure |

### Recurring Behavior by Source

**Git + recurring:**
- Poll interval (default 15 min) or webhook trigger
- On trigger: `git pull` → diff since `last_commit_sha` → changed files only → extract → ingest
- Preserves FACT's O(changed_files) guarantee

**Local + recurring:**
- Re-scan interval (default 60 min)
- On trigger: directory scan → compare content hashes with previous run → changed/new files → extract → ingest; deleted files → mark `is_current=false`

---

## Service Architecture

The onboarding redesign respects ECLE's service boundaries. Each service scales independently and communicates over REST.

### Service Boundaries

```
┌────────────────────┐     ┌──────────────────────────┐     ┌───────────────────┐
│   UI Service       │     │   API Service             │     │   Worker Service   │
│   (port 8742)      │     │   (port 8741)             │     │   (1..N instances) │
│                    │     │                            │     │                   │
│   Onboard Page     │────→│  POST /api/onboard         │────→│  Job Queue        │
│   (AJAX SPA)       │     │  GET  /api/onboard/jobs    │     │  (poll pending/)  │
│                    │     │  GET  /api/onboard/jobs/:id │     │                   │
│   Jobs Dashboard   │←────│  POST /api/onboard/jobs/:id│     │  Extraction       │
│   (AJAX poll)      │     │       /retry               │     │  (CPG, Config,    │
│                    │     │  POST /api/onboard/jobs/:id│     │   Doc parsing)    │
│                    │     │       /cancel               │     │                   │
│                    │     │  DELETE /api/onboard/jobs/:id    │  FACT Ingestion   │
│                    │     │                            │     │  (3 backends)     │
│                    │     │  GET  /api/onboard/options  │     │                   │
│                    │     │  GET  /api/repos            │     │                   │
└────────────────────┘     └──────────────────────────┘     └───────────────────┘
         │                            │                              │
         │ (no DB access)             │ (DB owner)                   │ (DB access for writes)
         │                            ▼                              ▼
         │                    ┌──────────────────┐          ┌──────────────────┐
         │                    │ Structured DB     │          │ Vector Index      │
         │                    │ (PostgreSQL/      │          │ (Qdrant/          │
         │                    │  SQLite)          │          │  ChromaDB)        │
         │                    └──────────────────┘          └──────────────────┘
         │
         │ In Lite mode: UI calls API in-process (no HTTP hop)
         │ In Full mode: UI calls API over HTTP via ECLEApiClient
```

### Horizontal Scaling

| Service | Scaling Strategy | State |
|---------|-----------------|-------|
| **UI Service** | Stateless, N replicas behind load balancer | Zero state — all state in API |
| **API Service** | Stateless read replicas + single write primary | DB connection pool; read replicas for GET endpoints |
| **Worker Service** | N workers competing for jobs from queue | File-based queue (Lite) or Redis queue (Full) with distributed lock per repo_id |
| **MCP Server** | N replicas, each calls API over HTTP | Stateless — reads from API |

**Worker scaling constraint:** One active job per `repo_id` at a time (prevents concurrent writes to same repo's data). Multiple workers can process different repos concurrently.

---

## REST API Contract

### Submit Onboard Job

```
POST /api/onboard
Content-Type: application/json

{
  "repo_id": "billing-service",
  
  "content_type": "code",                          // code | config | data | data-sql | documents | facts
  "source": "git",                                  // git | local
  
  "source_path": "https://github.com/org/repo.git", // URL (git) or directory path (local)
  "branch": "main",                                  // git only
  "auth_type": "token",                              // git only: none | token | ssh | system
  "auth_token": "ghp_...",                            // git + token only (never logged, never stored)
  
  "schedule": "once",                                // once | recurring
  "poll_interval_min": 0,                            // recurring only (0 = webhook)
  
  "facts_dir": null,                                 // code/config: pre-generated facts location
  "entity_dictionary": null,                          // documents: domain dictionary yaml path
  "linked_repos": ["billing-service"],                // documents: repos to resolve entities against
  "content_patterns": ["docs/**/*.md", "docs/**/*.html"]  // optional file filter globs
}

Response 201:
{
  "job_id": "abc12345",
  "status": "pending",
  "repo_id": "billing-service",
  "content_type": "code",
  "source": "git",
  "created_at": "2026-04-07T10:30:00Z"
}
```

### List Jobs

```
GET /api/onboard/jobs?repo_id=billing-service&status=pending,processing

Response 200:
{
  "jobs": [
    {
      "job_id": "abc12345",
      "repo_id": "billing-service",
      "content_type": "code",
      "source": "git",
      "schedule": "recurring",
      "status": "processing",
      "progress": {
        "phase": "edges",
        "message": "Computing topology edges...",
        "pct": 65,
        "files_done": 342,
        "files_total": 526
      },
      "created_at": "2026-04-07T10:30:00Z",
      "started_at": "2026-04-07T10:30:02Z"
    }
  ]
}
```

### Job Details

```
GET /api/onboard/jobs/{job_id}

Response 200:
{
  "job_id": "abc12345",
  ... full job object including result/error ...
}
```

### Retry Failed Job

```
POST /api/onboard/jobs/{job_id}/retry

Response 200:
{ "job_id": "abc12345", "status": "pending", "message": "Re-queued" }
```

### Cancel / Remove Job

```
POST /api/onboard/jobs/{job_id}/cancel    // cancel processing or pending
DELETE /api/onboard/jobs/{job_id}          // remove from history
```

### Options (for UI dropdowns)

```
GET /api/onboard/options

Response 200:
{
  "repos": ["billing-service", "billing-docs", "payments"],
  "content_types": ["code", "config", "data", "data-sql", "documents", "facts"],
  "sources": ["git", "local"],
  "schedules": ["once", "recurring"],
  "supported_extensions": {
    "code": [".c", ".cpp", ".h", ".ppc", ".pc", ".java", ".py", ".go", ".js", ".ts", ".sru", ".srf", ".srw", ".srd"],
    "config": [".sh", ".ksh", ".cfg", ".yaml", ".yml", ".properties", ".xml", ".ini", ".env", ".conf"],
    "data": [".xml", ".txt", ".list", ".tsv"],
    "data-sql": [".sql", ".ddl", ".rql", ".pls", ".pkb", ".pks"],
    "documents": [".md", ".txt", ".rst", ".html", ".htm", ".pdf", ".docx", ".csv", ".xlsx", ".pptx"],
    "facts": [".facts.json"]
  }
}
```

---

## OnboardJob Model

Replaces `ImportJob` in `job_queue.py`:

```python
@dataclass
class OnboardJob:
    """A unified onboarding job — content_type x source x schedule."""

    job_id: str = ""
    repo_id: str = ""

    # Axis 1: Content Type (WHAT)
    content_type: str = "code"      # code | config | data | data-sql | documents | facts

    # Axis 2: Source (WHERE)
    source: str = "local"           # git | local
    source_path: str = ""           # URL (git) or directory path (local)
    branch: str = "main"            # git only
    auth_type: str = "none"         # git only: none | token | ssh | system

    # Axis 3: Schedule (WHEN)
    schedule: str = "once"          # once | recurring
    poll_interval_min: int = 0      # recurring only (0 = webhook-driven)

    # Content-type-specific options
    facts_dir: str | None = None            # code/config: pre-generated facts
    entity_dictionary: str | None = None    # documents: domain dictionary yaml
    linked_repos: list[str] | None = None   # documents: repos for entity resolution
    content_patterns: list[str] | None = None  # file filter globs

    # Execution state
    status: str = "pending"         # pending | processing | complete | failed | cancelled
    commit_sha: str = ""            # populated after source resolution
    last_commit_sha: str = ""       # recurring: commit we're up to date with
    last_run_at: str | None = None  # recurring: when last completed
    created_at: str = ""
    started_at: str | None = None
    completed_at: str | None = None
    duration_ms: int | None = None
    progress: dict | None = None    # {phase, message, pct, files_done, files_total}
    result: dict | None = None      # final stats
    error: str | None = None
```

### Backward Compatibility

The old `ImportJob` fields map cleanly:

| Old ImportJob | New OnboardJob |
|--------------|----------------|
| `source_type="facts"` | `content_type="facts"`, `source="local"` |
| `source_type="code"` | `content_type="code"`, `source="local"` |
| `source_type="git"` | `content_type="code"`, `source="git"` |
| `source_type="documents"` | `content_type="documents"`, `source="local"` |
| (new) | `content_type="data"`, `source="local"` or `source="git"` |
| (new) | `content_type="data-sql"`, `source="local"` or `source="git"` |

Migration: on queue worker startup, any pending/failed `ImportJob` files are read and converted to `OnboardJob` format.

---

## Worker Processing Pipeline

```python
def process_job(job: OnboardJob) -> None:
    """Route by content_type after source resolution."""

    # Phase 1: Source Resolution (common for all content types)
    files = resolve_source(job)
    #   git:   clone/pull → file list → commit_sha
    #   local: scan dir → file list → content hash

    # Phase 2: Filter files by content_patterns (if specified)
    if job.content_patterns:
        files = apply_glob_filters(files, job.content_patterns)

    # Phase 3: Route by content_type
    match job.content_type:
        case "code":
            extract_cpg(files)           # Joern/LSP → CanonicalFactFileBase
            ingest_code(facts)           # → Tier 1 structured DB + Tier 2 vectors + edges

        case "config":
            extract_config(files)        # Config parser → CanonicalConfigBase
            ingest_config(config_facts)  # → Tier 1 structured DB + Tier 2 vectors
            compute_config_edges()       # → CONFIG_CONTROLS, CONFIG_SOURCES edges

        case "data":
            extract_data(files)          # Schema parser → CanonicalDataBase
            ingest_data(data_facts)      # → Tier 1 structured DB (tuxedo_fields, tuxedo_services, etc.)
            compute_data_edges()         # → SERVICE_CONTRACT, FIELD_DOMAIN edges

        case "data-sql":
            extract_sql_schema(files)    # DDL/RQL parser → tables, columns, constraints, stored procs
            ingest_sql_schema(schema)    # → Tier 1 structured DB (db_tables, db_columns, etc.)
            compute_schema_edges()       # → TABLE_SCHEMA edges linking DDL to code file_tables

        case "documents":
            extract_docs(files)          # Doc parser → CanonicalDocBase (chunk + entity extract)
            ingest_docs(doc_chunks)      # → Tier 3 structured DB + layer 4 vectors
            compute_doc_edges()          # → DOC_DESCRIBES cross-repo edges

        case "facts":
            load_facts(files)            # Direct load, skip extraction
            ingest_code(facts)           # Same as code from this point

    # Phase 4: Post-processing (common)
    run_post_processing(job)
    #   topology edges (code/config)
    #   artifact registry backfill
    #   service index rebuild
```

---

## CLI Changes

### Before (3 separate commands)

```bash
ecle import /path/to/facts --repo-id billing
ecle onboard https://github.com/org/repo.git --branch main --repo-id billing
ecle onboard-docs /path/to/docs --repo-id billing
```

### After (1 unified command with explicit axes)

```bash
# Code from git (replaces: ecle onboard <url>)
ecle onboard --type code --source git \
    --path https://github.com/org/repo.git \
    --branch main --repo-id billing

# Code from local folder (replaces: ecle onboard <path>)
ecle onboard --type code --source local \
    --path /path/to/code --repo-id billing

# Config from local folder (NEW)
ecle onboard --type config --source local \
    --path /path/to/configs --repo-id billing \
    --patterns "*.cfg" "*.sh" "*.yaml"

# Documents from git (NEW — previously impossible)
ecle onboard --type documents --source git \
    --path https://github.com/org/billing-docs.git \
    --repo-id billing-docs \
    --linked-repos billing-service \
    --entity-dict /path/to/billing-domain.yaml

# Documents from local folder with HTML (replaces: ecle onboard-docs)
ecle onboard --type documents --source local \
    --path "/c/Users/PPatil53/OneDrive - T-Mobile USA/Downloads/billing-agents-main-docs/docs" \
    --repo-id billing-docs \
    --patterns "**/*.md" "**/*.html"

# Data layer (Tuxedo domains, service descriptions)
ecle onboard --type data --source local \
    --path "/path/to/tuxedo/data" --repo-id billing-data \
    --patterns "domxml/*.xml" "desc/*.txt" "*.list"

# SQL/DDL schemas
ecle onboard --type data-sql --source git \
    --path https://github.com/org/billing-ddl.git \
    --repo-id billing-schema \
    --patterns "**/*.sql" "**/*.ddl" "**/*.rql"

# Facts import (replaces: ecle import)
ecle onboard --type facts --source local \
    --path /path/to/joern-exports/facts --repo-id billing

# Recurring code watch from git
ecle onboard --type code --source git \
    --path https://github.com/org/repo.git \
    --repo-id billing --schedule recurring --poll-interval 15

# Re-run a failed job
ecle onboard --rerun <job-id>

# List jobs
ecle onboard --list
ecle onboard --list --status failed
```

### Smart Defaults

The CLI infers axes when unambiguous:

```bash
# Path looks like a URL → source=git, type=code
ecle onboard https://github.com/org/repo.git --repo-id billing

# Path is a directory with .facts.json files → type=facts, source=local
ecle onboard /path/to/facts/ --repo-id billing

# Path is a directory with .md/.html files → type=documents, source=local
ecle onboard /path/to/docs/ --repo-id billing-docs

# Explicit always wins
ecle onboard --type config --path /path/to/mixed/ --repo-id billing
```

### Backward Compatibility

Old commands remain as aliases:

```bash
ecle import <path>        →  ecle onboard --type facts --source local --path <path>
ecle onboard <url>        →  ecle onboard --type code --source git --path <url>
ecle onboard-docs <path>  →  ecle onboard --type documents --source local --path <path>
```

Aliases emit a deprecation notice pointing to the unified command. Removed in Phase 5.

---

## UI Design (AJAX-First)

The onboard page is a **single-page AJAX form**, not tab-based. Sections reveal/hide dynamically based on selections. All interactions are AJAX — no full page reloads.

### Page Layout

```
┌─────────────────────────────────────────────────────────────────┐
│  Onboard                                                [Jobs ↗]│
│                                                                  │
│  ── Repository ──────────────────────────────────────────────── │
│  Repository ID: [ billing-service    ▼ ] [ + New ]              │
│                                                                  │
│  ── What are you onboarding? ────────────────────────────────── │
│  Content Type: [ Code                        ▼ ]  ← dropdown   │
│                  Code                                           │
│                  Config (.sh, .cfg, .yaml)                      │
│                  Data (Tuxedo domains, service desc)             │
│                  Data - SQL/DDL/RQL schemas                      │
│                  Documents (.md, .html, .pdf)                    │
│                  Facts (pre-extracted .facts.json)               │
│                                                                  │
│  ── Where is it? ────────────────────────────────────────────── │
│  ┌────────────────┐ ┌──────────────┐                            │
│  │ Git Repository │ │ Local Folder │           ← radio cards    │
│  └────────────────┘ └──────────────┘                            │
│                                                                  │
│  [--- Source fields (AJAX swap based on source selection) ---]   │
│  URL:    [ https://github.com/org/repo.git         ]            │
│  Branch: [ main                                     ]            │
│  Auth:   [ None ▼ ]  [Token field if token selected]            │
│                                                                  │
│  ── Schedule ────────────────────────────────────────────────── │
│  (•) One-time    ( ) Recurring                                   │
│  [if recurring: poll interval field]                             │
│                                                                  │
│  ── Options ─── (collapsed, click to expand) ────────────────── │
│  [if code/config: facts dir field]                               │
│  [if documents: entity dictionary, linked repos, patterns]       │
│  [if config: file patterns]                                      │
│                                                                  │
│  [ Start Onboarding ]                                            │
│                                                                  │
│  ── Active Jobs ─────────────────────── (AJAX poll, 3s) ─────── │
│  ┌─────────────────────────────────────────────────────────────┐│
│  │ billing-service │ code │ git │ processing │ ████████░░ 78% ││
│  │ ↳ Computing topology edges... (413/526 files)               ││
│  ├─────────────────────────────────────────────────────────────┤│
│  │ billing-docs │ documents │ local │ pending │ queued         ││
│  ├─────────────────────────────────────────────────────────────┤│
│  │ payments │ code │ git │ complete │ 2m 14s │ 1,247 facts    ││
│  │                                            [Re-run] [Remove]││
│  ├─────────────────────────────────────────────────────────────┤│
│  │ infra-config │ config │ local │ failed │ Parse error        ││
│  │                                          [Retry]   [Remove]││
│  └─────────────────────────────────────────────────────────────┘│
└─────────────────────────────────────────────────────────────────┘
```

### AJAX Interactions

All via htmx — no custom JavaScript framework needed:

| Interaction | Trigger | AJAX Call | Target |
|-------------|---------|-----------|--------|
| Select content type | `hx-get` on dropdown change | `GET /ui/onboard/fields?content_type=config` | `#options-section` — swaps in type-specific fields |
| Select source | `hx-get` on radio change | `GET /ui/onboard/fields?source=git` | `#source-fields` — swaps in git or local fields |
| Select schedule | `hx-get` on radio change | `GET /ui/onboard/fields?schedule=recurring` | `#schedule-fields` — shows/hides interval |
| Auth type change | `hx-get` on select change | inline swap | `#auth-extra` — shows/hides token field |
| Create new repo | `hx-get` on "+ New" click | inline swap | `#repo-field` — replaces dropdown with text input |
| Submit form | `hx-post` | `POST /api/onboard` (via UI proxy) | `#job-result` — shows "Job queued" confirmation |
| Active jobs list | `hx-get` with `hx-trigger="load, every 3s"` | `GET /api/onboard/jobs?status=pending,processing,complete,failed&limit=10` | `#active-jobs` — refreshes job list |
| Retry job | `hx-post` on button click | `POST /api/onboard/jobs/{id}/retry` | inline swap — status changes to "pending" |
| Remove job | `hx-delete` on button click | `DELETE /api/onboard/jobs/{id}` | `hx-swap="outerHTML"` — row disappears |
| Progress bar | included in jobs poll | progress data in job JSON | CSS width on progress bar element |

### UI Service Endpoints (thin proxies to API)

```
GET  /ui/onboard                      → render onboard page (static shell + AJAX)
GET  /ui/onboard/fields               → return HTML fragment for dynamic form sections
POST /ui/onboard                      → proxy to POST /api/onboard → return result HTML
GET  /ui/onboard/jobs                 → proxy to GET /api/onboard/jobs → return jobs HTML table
POST /ui/onboard/jobs/{id}/retry      → proxy to API → return updated row HTML
DELETE /ui/onboard/jobs/{id}          → proxy to API → return empty (htmx removes row)
```

**Key:** The UI service returns **HTML fragments**, not JSON. htmx swaps fragments directly into the DOM. The API service returns JSON. The UI service bridges the two.

---

## Config Extraction Pipeline (New)

### CanonicalConfigBase

```python
@dataclass
class CanonicalConfigBase:
    """Extracted facts from a config file."""
    filename: str
    content_type: str = "config"
    config_format: str = ""         # key_value | shell | yaml | xml | properties | ini
    commit_sha: str = ""

    parameters: list[ConfigParam] = field(default_factory=list)
    functions: list[ConfigFunction] = field(default_factory=list)    # shell scripts only
    env_vars: list[ConfigEnvVar] = field(default_factory=list)
    sources: list[ConfigSource] = field(default_factory=list)       # source/include directives

@dataclass
class ConfigParam:
    name: str
    value: str
    line: int
    context: str = ""           # section name, group, or parent key path

@dataclass
class ConfigFunction:
    name: str
    line_start: int
    line_end: int
    calls: list[str] = field(default_factory=list)
    reads_env: list[str] = field(default_factory=list)

@dataclass
class ConfigEnvVar:
    name: str
    value: str = ""
    action: str = "set"         # set | read | export
    line: int = 0

@dataclass
class ConfigSource:
    file: str
    line: int
    directive: str = "source"   # source | include | import
```

### Config Readers (by format)

| Format | Detection | Parser | Examples |
|--------|-----------|--------|---------|
| Shell / KSH | `.sh`, `.ksh`, shebang `#!/bin/` | Regex: `export`, `=`, function defs, `source` | `blsre_*.sh`, `gn_env_sh`, `vst_env_sh` |
| Key-Value | `.cfg`, `.config`, `.conf` | Split on `=` or whitespace, section headers `[section]` | `blpool.config`, `TWSConfig.mas` |
| YAML | `.yaml`, `.yml` | `yaml.safe_load` → flatten key paths | `ecle.yaml`, Spring `application.yml` |
| Properties | `.properties` | Split on `=`, respect `\` continuation | Java `.properties` files |
| XML | `.xml` | ElementTree → extract attributes/text | `UBBCONFIG`, `pom.xml`, `web.xml` |
| INI | `.ini` | `configparser` | `setup.cfg`, INI-style configs |

### Structured DB Tables for Config

```sql
CREATE TABLE config_facts (
    id              TEXT PRIMARY KEY,   -- SHA256(file_id + commit_sha)
    file_id         TEXT NOT NULL,
    commit_sha      TEXT NOT NULL,
    repo_id         TEXT NOT NULL,
    tenant_id       TEXT NOT NULL DEFAULT 'default',
    branch          TEXT NOT NULL DEFAULT 'main',
    config_format   TEXT NOT NULL,      -- shell | key_value | yaml | xml | properties | ini
    param_count     INTEGER DEFAULT 0,
    function_count  INTEGER DEFAULT 0,
    env_var_count   INTEGER DEFAULT 0,
    is_current      BOOLEAN DEFAULT TRUE,
    previous_id     TEXT,
    created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE config_parameters (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    config_fact_id  TEXT NOT NULL REFERENCES config_facts(id),
    param_name      TEXT NOT NULL,
    param_value     TEXT,
    line            INTEGER,
    context         TEXT,               -- section/group/key path
    UNIQUE(config_fact_id, param_name, context)
);

CREATE TABLE config_env_vars (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    config_fact_id  TEXT NOT NULL REFERENCES config_facts(id),
    var_name        TEXT NOT NULL,
    var_value       TEXT,
    action          TEXT NOT NULL,       -- set | read | export
    line            INTEGER
);

CREATE TABLE config_sources (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    config_fact_id  TEXT NOT NULL REFERENCES config_facts(id),
    sourced_file    TEXT NOT NULL,
    line            INTEGER,
    directive       TEXT DEFAULT 'source'  -- source | include | import
);
```

### Config Edge Types (Signals 10-12)

| Signal | Name | Source | Target | Weight | Confidence |
|--------|------|--------|--------|--------|------------|
| 10 | CONFIG_CONTROLS | config file declares param matching a code entity | code file that entity maps to | 2.0 | 0.8 |
| 11 | CONFIG_SOURCES | config file sources/includes another config | sourced config file | 1.5 | 1.0 |
| 12 | DOC_DESCRIBES | document mentions a code/config entity | referenced code/config file | 1.5 | 0.7 |

CONFIG_CONTROLS resolution uses entity matching: parameter names are matched against file names, function names, job names, and table names in the structured DB. Confidence is 0.8 (not 1.0) because the match is heuristic.

---

## Data Extraction Pipeline (New) — Schema Detection + Extractor Registry

### The Problem: Schema Diversity

Structured data files vary across repos, evolve over time, and share file extensions (`.xml` can be Tuxedo domain, Spring config, Maven POM, or Kubernetes manifest). A hardcoded parser per schema is fragile — any variation crashes or silently loses data.

### Design: Two-Phase Adaptive Extraction

**Phase 1: Schema Detection (classify, never crash)**

Probe the first ~2KB of each file and classify it by structure, not extension:

```python
class SchemaDetector:
    """Classify structured data files by probing content. Never crashes."""

    def detect(self, path: Path) -> list[SchemaMatch]:
        """Return candidate schemas ranked by confidence (0.0-1.0)."""
        probe = FileProbe(path, max_lines=50)

        if probe.is_xml:
            root_tag = probe.xml_root_element     # <domain>, <beans>, <project>, etc.
            return self._match_xml_schemas(root_tag, probe)
        elif probe.first_line_matches(r"^service \w+"):
            return [SchemaMatch("tuxedo_service_desc", 1.0)]
        elif probe.is_delimited:                  # consistent comma/pipe/tab columns
            return [SchemaMatch("delimited", 0.8)]
        elif probe.is_key_value:                  # key=value lines
            return [SchemaMatch("key_value", 0.7)]
        else:
            return [SchemaMatch("unknown", 0.0)]  # → falls to documents pipeline

    def _match_xml_schemas(self, root_tag: str, probe: FileProbe) -> list[SchemaMatch]:
        known = {
            "domain":    "tuxedo_domain",
            "beans":     "spring_config",
            "project":   "maven_pom",
            "UBBCONFIG": "tuxedo_ubb",
            "Configuration": "app_config",
        }
        if root_tag in known:
            return [SchemaMatch(known[root_tag], 1.0)]
        return [SchemaMatch("generic_xml", 0.5)]


@dataclass
class SchemaMatch:
    schema_id: str
    confidence: float           # 0.0-1.0
```

**Phase 2: Schema-Specific Extractors (pluggable registry)**

```python
class DataExtractorRegistry:
    """Registry of schema-specific extractors. Adding a new schema = one new class."""

    _extractors: dict[str, DataExtractor] = {}

    def register(self, schema_id: str, extractor: DataExtractor) -> None:
        self._extractors[schema_id] = extractor

    def extract(self, path: Path, schema_match: SchemaMatch) -> ExtractionResult:
        extractor = self._extractors.get(schema_match.schema_id)
        if extractor is None:
            extractor = self._extractors.get("generic_xml", GenericXmlExtractor())

        try:
            result = extractor.extract(path)
            result.detection_confidence = schema_match.confidence
            return result
        except Exception as e:
            # Extractor failed → log, return partial via generic fallback
            return ExtractionResult(
                status="failed",
                schema_id=schema_match.schema_id,
                error=str(e),
                entities=_generic_best_effort(path),
            )
```

### The Extractor Interface

```python
class DataExtractor(ABC):
    """Base class. One per schema type. Small, focused, independently testable."""

    @abstractmethod
    def schema_id(self) -> str: ...

    @abstractmethod
    def detect(self, probe: FileProbe) -> float:
        """Confidence 0.0-1.0 that this file matches."""

    @abstractmethod
    def extract(self, path: Path) -> ExtractionResult:
        """Parse file into schema-agnostic ExtractionResult."""

    @abstractmethod
    def target_tables(self) -> list[str]:
        """Which structured DB tables this writes to (for docs + migration)."""
```

### Schema-Agnostic ExtractionResult

The critical design: extractors produce a **generic intermediate form**, not direct DB writes. This prevents schema changes from breaking ingestion.

```python
@dataclass
class ExtractionResult:
    status: str                          # full | partial | failed
    schema_id: str
    detection_confidence: float = 1.0
    error: str | None = None

    entities: list[ExtractedEntity] = field(default_factory=list)
    relationships: list[ExtractedRelationship] = field(default_factory=list)
    properties: list[ExtractedProperty] = field(default_factory=list)


@dataclass
class ExtractedEntity:
    """One thing defined in the file — a field, a service, a table, a bean."""
    entity_id: str                       # ACTIVITYCODE, ARADJBAN, etc.
    entity_type: str                     # field_definition | service_contract | etc.
    name: str
    attributes: dict[str, str]           # all schema-specific key/value pairs


@dataclass
class ExtractedRelationship:
    """A link between entities — valid values, field→service, dependency."""
    source_id: str
    target_id: str
    relationship_type: str               # has_valid_value | uses_field | depends_on
    attributes: dict[str, str] = field(default_factory=dict)


@dataclass
class ExtractedProperty:
    """A standalone property not tied to an entity."""
    key: str
    value: str
    context: str = ""
    line: int = 0
```

### Built-in Extractors (Phase 1)

| Schema ID | Detects On | Entity Types | Example Files |
|-----------|-----------|-------------|---------------|
| `tuxedo_domain` | `<domain>` root | `field_definition` + `valid_value` relationships | `activitycode.xml`, `abano.xml` |
| `tuxedo_service_desc` | Line 1: `service XXXX` | `service_contract` + `service_field` + `service_error` | `ARADJBAN.txt`, `CSACTVSUB.txt` |
| `tuxedo_service_list` | CSV: `service,view,source` pattern | `service_source_map` | `services.list` |
| `tuxedo_field_list` | CSV: `service,field` pattern | `mandatory_field` | `mandatory.list`, `treatnull.list` |
| `generic_xml` | Any XML not matching known schemas | `xml_{root}_{child}` | Unknown XML files |

### How Extractors Handle Schema Evolution

**New XML element added:** `findtext()` with default `""` — unknown children silently ignored. No crash.

```python
class TuxedoDomainExtractor(DataExtractor):
    def extract(self, path: Path) -> ExtractionResult:
        tree = ET.parse(path)
        root = tree.getroot()

        entity = ExtractedEntity(
            entity_id=root.findtext("dmid", ""),
            entity_type="field_definition",
            name=root.findtext("dmname", ""),
            attributes={
                "data_type": root.findtext("dattyp", ""),
                "data_length": root.findtext("datlen", ""),
                "subject_area": root.findtext("subjarea", ""),
                "dict_check": root.findtext("dictcheck", ""),
                "create_constraint": root.findtext("creconstr", ""),
                # Future fields: added here when known, silently "" until then
            },
        )

        # Valid values → relationships
        relationships = []
        for vv in root.findall("validvalues"):
            relationships.append(ExtractedRelationship(
                source_id=entity.entity_id,
                target_id=vv.findtext("id/vvname", ""),
                relationship_type="has_valid_value",
                attributes={
                    "value": vv.findtext("vvvalue", ""),
                    "seq": vv.findtext("seqno", "0"),
                },
            ))

        return ExtractionResult(
            status="full", schema_id="tuxedo_domain",
            entities=[entity], relationships=relationships,
        )
```

**Schema changes between repos:** Different repo registers different extractors for the same extension. The manifest's `content_type` routes to the correct extractor registry per repo.

**Completely unknown XML:** `GenericXmlExtractor` walks top-level children, extracts `id`/`name`/`class` attributes, stores as `attributes` dict. Status = `"partial"`. Nothing crashes. Data is queryable via `data_entities` table.

### Data Layer Ingestion: ExtractionResult → DB Tables

```python
class DataLoader:
    """Routes schema-agnostic ExtractionResult to appropriate DB tables."""

    _entity_loaders: dict[str, Callable] = {
        "field_definition":   _load_tuxedo_field,
        "service_contract":   _load_tuxedo_service,
        "service_field":      _load_tuxedo_service_field,
        "service_error":      _load_tuxedo_service_error,
        "service_source_map": _load_tuxedo_service_source,
        "mandatory_field":    _load_tuxedo_mandatory,
    }

    _relationship_loaders: dict[str, Callable] = {
        "has_valid_value":    _load_field_valid_value,
        "uses_field":         _load_service_field_usage,
    }

    def load(self, result: ExtractionResult, repo_id: str, commit_sha: str) -> LoadResult:
        loaded, generic = 0, 0

        for entity in result.entities:
            loader = self._entity_loaders.get(entity.entity_type)
            if loader:
                loader(entity, repo_id, commit_sha)
                loaded += 1
            else:
                self._load_generic(entity, repo_id, commit_sha)
                generic += 1

        for rel in result.relationships:
            loader = self._relationship_loaders.get(rel.relationship_type)
            if loader:
                loader(rel, repo_id, commit_sha)

        return LoadResult(loaded=loaded, generic=generic, schema=result.schema_id)
```

### Structured DB Tables for Data Layer

```sql
-- Tuxedo field definitions (from domxml/*.xml)
CREATE TABLE tuxedo_fields (
    field_id        TEXT NOT NULL,
    field_name      TEXT,
    data_type       TEXT,
    data_length     INTEGER,
    subject_area    TEXT,
    dict_check      TEXT,
    create_constraint TEXT,
    repo_id         TEXT NOT NULL,
    commit_sha      TEXT,
    is_current      BOOLEAN DEFAULT TRUE,
    PRIMARY KEY(field_id, repo_id)
);

CREATE TABLE tuxedo_field_values (
    field_id        TEXT NOT NULL,
    value_name      TEXT NOT NULL,
    value           TEXT,
    seq             INTEGER,
    repo_id         TEXT NOT NULL,
    PRIMARY KEY(field_id, value_name, repo_id)
);

-- Tuxedo service contracts (from desc/*.txt)
CREATE TABLE tuxedo_services (
    service_name    TEXT NOT NULL,
    description     TEXT,
    service_flow    TEXT,
    input_count     INTEGER,
    output_count    INTEGER,
    error_count     INTEGER,
    repo_id         TEXT NOT NULL,
    commit_sha      TEXT,
    is_current      BOOLEAN DEFAULT TRUE,
    PRIMARY KEY(service_name, repo_id)
);

CREATE TABLE tuxedo_service_fields (
    service_name    TEXT NOT NULL,
    direction       TEXT NOT NULL,           -- input | output
    field_name      TEXT NOT NULL,
    description     TEXT,
    default_value   TEXT,
    validation      TEXT,
    mandatory       BOOLEAN DEFAULT FALSE,
    repo_id         TEXT NOT NULL,
    PRIMARY KEY(service_name, direction, field_name, repo_id)
);

CREATE TABLE tuxedo_service_errors (
    service_name    TEXT NOT NULL,
    error_code      TEXT,
    error_text      TEXT,
    severity        TEXT,
    repo_id         TEXT NOT NULL
);

CREATE TABLE tuxedo_service_source (
    service_name    TEXT NOT NULL,
    view_file       TEXT,
    source_file     TEXT,
    repo_id         TEXT NOT NULL,
    PRIMARY KEY(service_name, repo_id)
);

-- Generic fallback for unknown entity types
CREATE TABLE data_entities (
    id              TEXT PRIMARY KEY,
    file_id         TEXT NOT NULL,
    repo_id         TEXT NOT NULL,
    commit_sha      TEXT NOT NULL,
    schema_id       TEXT NOT NULL,
    entity_id       TEXT NOT NULL,
    entity_type     TEXT NOT NULL,
    name            TEXT,
    attributes      TEXT,                    -- JSON blob
    is_current      BOOLEAN DEFAULT TRUE,
    created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_data_entities_type ON data_entities(entity_type, repo_id);
CREATE INDEX idx_data_entities_name ON data_entities(name, repo_id);
```

### Data Edge Types (Signals 13-14)

| Signal | Name | Source | Target | Weight | Confidence |
|--------|------|--------|--------|--------|------------|
| 13 | SERVICE_CONTRACT | Service desc declares I/O fields | Source file implementing the service (via services.list) | 2.5 | 1.0 |
| 14 | FIELD_DOMAIN | Service uses a field | Domain XML defining that field's valid values | 1.0 | 1.0 |

### Three Guarantees

1. **Never crash** — unknown schemas degrade to `generic_xml` or documents pipeline
2. **Never lose data** — worst case: `data_entities` table with JSON `attributes` blob
3. **Always improvable** — new extractor = one class + one registry entry + one test file

---

## HTML Document Reader (New)

Added to the existing `DocumentReaderRegistry`:

```python
class HTMLReader(DocumentReader):
    """Read HTML files, strip tags, preserve heading structure."""

    extensions = [".html", ".htm"]

    def read(self, path: Path) -> DocumentContent:
        from html.parser import HTMLParser
        # 1. Parse HTML, extract text nodes
        # 2. Map <h1>-<h6> to section hierarchy (same as markdown # levels)
        # 3. Extract text from <p>, <li>, <td>, <th>, <dd>, <dt>
        # 4. Discard <script>, <style>, <nav>, <footer> content
        # 5. Preserve <pre>/<code> blocks as-is (may contain code snippets)
        # 6. Extract <a href> targets as entity references
        # Return: DocumentContent with sections + text chunks
```

**Dependencies:** stdlib `html.parser` only. No BeautifulSoup or lxml dependency (Lite mode constraint). Can optionally use BeautifulSoup in Full mode for better table extraction.

**Priority:** P0 (same as markdown) — HTML is common for exported Confluence pages, Tuxedo service catalogs (like `csActSub.md` which appears to be an HTML export), and generated documentation.

---

## Impact on Existing Specs

### SPEC-009 (Git Onboarding) — Partially Superseded

What survives:
- `GitConnector` implementation (clone, auth, file enumeration) — unchanged
- Source-to-facts validation logic — unchanged
- CPG client integration — unchanged

What changes:
- No longer a standalone onboarding path — becomes the `source=git` resolver called by the unified pipeline
- CLI `ecle onboard <url>` becomes an alias for `ecle onboard --type code --source git --path <url>`

### SPEC-011 (Document Onboarding) — Partially Superseded

What survives:
- `DocumentReaderRegistry` and all reader implementations — unchanged
- Chunking strategy — unchanged
- Entity extraction and cross-referencing — unchanged
- `document_embedder.py` — unchanged

What changes:
- No longer a standalone onboarding path — becomes the `content_type=documents` pipeline called by the unified worker
- Can now receive files from git sources (not just local folders)
- HTML reader added to registry
- CLI `ecle onboard-docs <path>` becomes an alias

### SPEC-037 (Job Queue) — Modified

- `ImportJob` → `OnboardJob` (new fields, backward-compatible migration)
- Queue conflict check uses `repo_id + content_type` (not just `repo_id`) — allows parallel code + docs jobs for same repo
- Worker dispatch routes on `content_type` instead of `source_type`
- Recurring jobs: worker checks `schedule` field; if "recurring", job stays in `complete/` and worker re-triggers on poll interval

### SPEC-023 (UI) — Modified

- Onboard page rebuilt as AJAX-first single form (replaces 4-tab layout)
- Active jobs panel at bottom of onboard page (replaces separate health dashboard for jobs)
- All interactions via htmx AJAX — no full page reloads
- UI service returns HTML fragments to htmx, proxies JSON API underneath

### SPEC-022 (API) — Modified

- New endpoint group: `POST /api/onboard`, `GET /api/onboard/jobs`, etc.
- Old endpoints `POST /api/import` remain as aliases → internally create OnboardJob

---

## Crash Recovery & Resume

### Problem

If the system crashes mid-ingestion (300/500 files loaded), the current behavior on retry is:
1. `recover_stale()` marks the interrupted job as failed
2. User clicks Retry → job re-queues
3. Worker starts from scratch — re-reads, re-parses, re-hashes all 300 already-loaded files
4. `load_file()` detects each as "unchanged" via content hash → skips DB write
5. Then processes files 301-500 normally

**Not destructive** (idempotent), but **wasteful** — re-reading 300 files from disk costs seconds to minutes in large repos.

### Design: DB-Driven Resume (Zero Extra State)

The DB already knows which files were loaded. On resume, query it once and skip them entirely:

```python
# Worker on retry:
if job.resume:
    existing_ids = db.get_loaded_file_ids(job.repo_id, job.commit_sha)
    logger.info(f"Resuming: {len(existing_ids)} already loaded, skipping")
else:
    existing_ids = set()

loader.load_directory(facts_dir, ..., skip_ids=existing_ids)
```

**Why DB-driven (not checkpoint file):**
- Zero extra state to corrupt or go stale
- Works even if job JSON was corrupted during crash
- Works across all content types (code, config, data, documents)
- One DB query (~100KB for 10K file IDs) vs re-reading thousands of files from disk

### Resume by Pipeline Phase

Each phase has its own resume strategy:

| Phase | Crash After | Already Persisted | Resume Strategy |
|-------|------------|-------------------|-----------------|
| **Source resolution** | Clone started | Partial clone dir | Re-clone (git handles partial), or re-scan (local) |
| **Facts loading** | 300/500 files | 300 rows in `file_facts` | Query `file_facts` for loaded IDs → skip them |
| **Edge computation** | Edges for 300 files | Edges in `topology_edges` | Recompute all — fast, idempotent, O(loaded_files) |
| **Embedding** | Vectors for 200 files | Vectors in ChromaDB | Query vector store for existing IDs → embed only missing |
| **Doc chunking** | 50/100 docs | 50 rows in `documents` | Query `documents` for loaded IDs → skip them |
| **Data extraction** | 2000/5000 XMLs | 2000 rows in `tuxedo_fields` | Query `tuxedo_fields` for loaded IDs → skip them |
| **Post-processing** | Partial artifacts | Some artifacts stored | Backfill is already idempotent — safe to re-run |

### OnboardJob Resume Fields

```python
@dataclass
class OnboardJob:
    # ... existing fields ...

    # Resume support (set on retry of failed/crashed job)
    resume: bool = False
```

### Queue Behavior on Crash

```
Normal flow:
  pending/ → processing/ → complete/

Crash during processing:
  processing/job-abc.json survives on disk (file system durable)

Server restart:
  recover_stale() → moves processing/job-abc.json to failed/
  Job retains all fields: repo_id, content_type, source, source_path, etc.

User clicks Retry:
  retry(job_id) → sets job.resume = True → moves to pending/
  Worker picks it up → sees resume=True → queries DB for loaded state → skips done files
```

### Worker Resume Logic

```python
def _process_job(self, job: OnboardJob) -> None:
    # ... source resolution ...

    # Build skip set from DB if resuming
    skip_ids: set[str] = set()
    if job.resume:
        skip_ids = set(db.get_loaded_file_ids(job.repo_id, job.commit_sha))
        if skip_ids:
            logger.info(f"Resuming: skipping {len(skip_ids)} already-loaded files")

    match job.content_type:
        case "code" | "facts":
            loader.load_directory(facts_dir, ..., skip_ids=skip_ids)
            topo.compute_all_edges()              # idempotent — safe to re-run
            run_post_processing(..., skip_existing=True)

        case "documents":
            embedder.embed_directory(source_path, skip_ids=skip_ids)

        case "data":
            data_loader.load_directory(source_path, skip_ids=skip_ids)
            compute_data_edges()                  # idempotent

        case "config":
            config_parser.parse_directory(source_path, skip_ids=skip_ids)
```

### `load_directory()` Skip Logic

```python
def load_directory(self, facts_dir, ..., skip_ids: set[str] | None = None):
    facts_files = sorted(facts_dir.rglob("*.facts.json"))

    if skip_ids:
        before = len(facts_files)
        facts_files = [f for f in facts_files if f.stem not in skip_ids]
        logger.info(f"Skip set: {before - len(facts_files)} files skipped, "
                     f"{len(facts_files)} remaining")

    for facts_path in facts_files:
        result = self.load_file(facts_path, ...)
        # ... existing logic unchanged ...
```

### Commit Granularity

The current code wraps `load_directory()` in a single `db.transaction()` block. This means a crash at file 300 either commits all 300 or none — depending on whether the DB committed before the crash.

For resume to work reliably, we need **periodic commits** within the loop:

```python
COMMIT_BATCH_SIZE = 50  # commit every 50 files

for i, facts_path in enumerate(facts_files):
    result = self.load_file(facts_path, ...)

    # Periodic commit — makes progress durable
    if (i + 1) % COMMIT_BATCH_SIZE == 0:
        db.conn.commit()
        _progress("loading", f"Loaded {i+1}/{len(facts_files)}",
                  pct=int(30 + 25 * (i+1) / len(facts_files)))
```

This ensures that on crash, at most 50 files of work are lost — not 300.

### Guarantees

1. **Resume never produces duplicates** — `load_file()` is already idempotent via content hash check
2. **Resume never skips files** — `skip_ids` is intersection of (DB state) and (file list). New files not in DB are always processed.
3. **Resume never serves stale data** — edges and embeddings are recomputed for all loaded files, not just new ones. Idempotent recomputation is cheap.
4. **Resume works across all content types** — every loader accepts `skip_ids`. The DB query is type-specific (`file_facts` for code, `documents` for docs, `tuxedo_fields` for data).

---

## Testing Requirements

### Unit Tests

- `OnboardJob` serialization/deserialization (JSON round-trip)
- `ImportJob` → `OnboardJob` migration
- Config extraction for each format (shell, key_value, yaml, xml, properties)
- HTML reader (tag stripping, heading hierarchy, script/style exclusion)
- Content type inference from file extensions
- CLI argument parsing (all combinations of axes)
- Job conflict detection (`repo_id + content_type` uniqueness)

### Crash Recovery & Resume Tests

- `load_directory(skip_ids={file1, file2})` skips those files, processes the rest
- `load_directory(skip_ids=set())` processes all files (fresh start)
- `load_directory(skip_ids=full_set)` processes zero files (fully resumed, no-op)
- Periodic commit: load 120 files with COMMIT_BATCH_SIZE=50 → crash at file 110 → DB has 100 files (2 commits), not 110
- `recover_stale()` on startup marks processing jobs as failed, preserves all fields
- `retry(job_id)` sets `resume=True`, moves to pending
- Worker with `resume=True` queries DB, builds skip set, skips loaded files
- Resume after crash produces same final DB state as uninterrupted run (idempotency)
- Resume with changed file list (file added/removed between crash and retry) → handles gracefully

### Integration Tests

- Submit job via REST API → job appears in queue → worker picks up → completes
- Git source + documents content type → clone → chunk → embed → cross-repo edges
- Config source + local → parse → structured DB → CONFIG_CONTROLS edges
- Recurring job: submit → complete → wait → auto-re-trigger
- UI AJAX: submit form → poll jobs → see progress → retry failed

### Backward Compatibility Tests

- Old CLI commands (`ecle import`, `ecle onboard <url>`, `ecle onboard-docs`) still work
- Old `ImportJob` JSON files in queue/ are processed correctly
- `POST /api/import` still works (internally creates OnboardJob)

---

## Phasing

| Phase | Deliverable |
|-------|-------------|
| **1 (now)** | `OnboardJob` model, unified REST API, CLI refactor, UI redesign (AJAX), HTML reader |
| **2 (next)** | Config extraction pipeline (shell, key_value, yaml), CONFIG_CONTROLS edges |
| **3** | Recurring jobs (git poll, local re-scan), entity dictionary support |
| **4** | Config extraction (xml, properties, ini), DOC_DESCRIBES cross-repo edges |

---

## Dependencies

| Dependency | Status |
|-----------|--------|
| htmx (already in UI) | Available — no new dependency |
| `html.parser` (stdlib) | Available — no new dependency |
| `yaml` (already used for ecle.yaml) | Available |
| `configparser` (stdlib) | Available |
| `xml.etree.ElementTree` (stdlib) | Available |
| Entity dictionary loader | New — simple YAML reader, no external dep |

---

## Files Changed

```
Modified:
  src/ecle/ingestion/job_queue.py        ImportJob → OnboardJob
  src/ecle/cli.py                        Unified ecle onboard command
  src/ecle/query/app.py                  POST /api/onboard + job endpoints
  src/ecle/ui/routes.py                  New onboard page routes (AJAX fragments)
  src/ecle/ui/templates/onboard.html     Complete rewrite (AJAX-first)
  src/ecle/ui/api_client.py              New methods for onboard API
  src/ecle/onboarding/pipeline.py        Route by content_type

New:
  src/ecle/ingestion/config_extractor.py     Config file parsers
  src/ecle/ingestion/config_loader.py        Config facts → structured DB
  src/ecle/ingestion/data_extractor.py       Tuxedo domain XML + service desc parsers
  src/ecle/ingestion/data_loader.py          Data facts → structured DB (tuxedo_fields, tuxedo_services)
  src/ecle/ingestion/sql_schema_extractor.py DDL/RQL parser → tables, columns, stored procs
  src/ecle/ingestion/sql_schema_loader.py    SQL schema → structured DB (db_tables, db_columns)
  src/ecle/ingestion/readers/html_reader.py  HTML document reader
  src/ecle/backends/structured/config_tables.py  SQLAlchemy models for config_facts etc.
  src/ecle/backends/structured/data_tables.py    SQLAlchemy models for tuxedo_fields, tuxedo_services etc.

Unchanged:
  src/ecle/connectors/git.py                 Still handles git clone/pull/auth
  src/ecle/ingestion/document_embedder.py    Still handles doc chunking/embedding
  src/ecle/ingestion/document_chunker.py     Still handles chunking strategy
  src/ecle/ingestion/facts_loader.py         Still handles .facts.json loading
  src/ecle/ingestion/topology.py             Gains signals 10-12, existing 1-9 unchanged
  src/ecle/ingestion/embedding_pipeline.py   Gains config embedding, existing code embedding unchanged
```

## v1.3 Implementation Notes (2026-04-11)

**Status**: Implemented

### Job lifecycle flags (BUG-003, BUG-004)

| Flag | Purpose | Set when |
|------|---------|----------|
| `_job_succeeded` | Gates source cleanup — temp dirs preserved on failure for retry | `True` immediately before each `self.queue.complete()` call |
| `_deep_job_submitted` | Structural job defers cleanup to deep job | `True` after `self.queue.submit(deep_job)` succeeds |
| `cleanup_source` option | Deep job inherits cleanup responsibility from structural | Propagated in deep job `options` dict |

**Cleanup ownership:**
- Job fails → nobody cleans → source preserved for retry
- Structural succeeds, no deep → structural cleans up
- Structural succeeds, deep submitted → deep cleans up on its own success

### Dynamic code extensions

File extensions for the `code` content type are loaded from AMF language pack manifests (`stages/languages/*/manifest.yaml → extensions.source`) at startup via `settings.py:get_code_extensions()`. Config extensions in `ecle.yaml` are merged (union) with language pack extensions. No more hardcoded extension lists.

Implementation: `loader.py` calls `get_code_extensions(amf_root)` during `ConfigLoader.load()`. The `/ui/extensions` API returns the merged set to the browser for client-side filtering.
