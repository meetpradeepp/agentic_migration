# SPEC-042: Service Boundary Architecture — All Components Communicate via API

**Status**: Spec (Phase 1 partially implemented)
**Owner**: Platform Architect
**Files**: All `src/ecle/` modules — architectural enforcement across entire codebase
**Supersedes**: All implicit assumptions about local filesystem access or direct module imports

## The Principle

**Every component communicates via HTTP/API. No exceptions.**

- Browser → API over HTTPS
- CLI → API over HTTP (CLI runs on server but talks to API, not to DB directly)
- Web UI → API over HTTP (UI is a thin rendering layer)
- MCP Server → API over HTTP (both stdio and streamable-http modes)
- DB is behind an API endpoint — no component imports DB modules directly except the API service itself

This applies to ALL deployment modes: lite, single server, Docker, enterprise. "Lite mode" does NOT mean "everything in one process with direct imports". It means "fewer infrastructure dependencies" — but the communication pattern is identical.

## Architecture

```
┌──────────────────────────────────────────────────────────────────┐
│  CLIENT SIDE (browser, CLI, IDE, CI/CD)                          │
│                                                                   │
│  Browser ──── HTTPS ────┐                                        │
│  CLI ────── HTTP ───────┤                                        │
│  IDE (MCP) ── stdio ────┤  (stdio wraps HTTP internally)        │
│  CI/CD ──── HTTP ───────┤                                        │
│                          │                                        │
└──────────────────────────┼────────────────────────────────────────┘
                           │
                    ═══════╪═══════  NETWORK BOUNDARY  ═══════════
                           │
┌──────────────────────────┼────────────────────────────────────────┐
│  ECLE SERVER                                                      │
│                          │                                        │
│  ┌───────────────────────▼───────────────────────────────────┐   │
│  │  API Layer (the ONLY thing that touches storage)           │   │
│  │                                                            │   │
│  │  ┌──────────────────────────────────────────────────────┐ │   │
│  │  │  API Gateway (FastAPI)                                │ │   │
│  │  │  - Authentication (Bearer token / session)            │ │   │
│  │  │  - Rate limiting                                      │ │   │
│  │  │  - Input validation                                   │ │   │
│  │  │  - CORS                                               │ │   │
│  │  ├──────────────────────────────────────────────────────┤ │   │
│  │  │  /graphql  — GraphQL queries + mutations              │ │   │
│  │  │  /api/*    — REST endpoints (upload, ingest, cluster) │ │   │
│  │  │  /mcp      — MCP tool protocol (streamable-http)      │ │   │
│  │  └──────────────┬───────────────────────────────────────┘ │   │
│  │                  │ (internal only — never exposed)         │   │
│  │  ┌──────────────▼───────────────────────────────────────┐ │   │
│  │  │  Core Services                                        │ │   │
│  │  │  Ingestion │ Query Engine │ Clustering │ Job Queue    │ │   │
│  │  └──────────────┬───────────────────────────────────────┘ │   │
│  │                  │                                         │   │
│  │  ┌──────────────▼───────────────────────────────────────┐ │   │
│  │  │  Storage Layer                                        │ │   │
│  │  │  Structured DB │ Vector Index │ File Store │ Queue    │ │   │
│  │  └──────────────────────────────────────────────────────┘ │   │
│  └────────────────────────────────────────────────────────────┘   │
│                                                                    │
│  ┌────────────────────────────────────────────────────────────┐   │
│  │  Web UI (separate process / container)                      │   │
│  │  - Serves HTML/CSS/JS to browser                            │   │
│  │  - Proxies all data requests to API Layer over HTTP         │   │
│  │  - ZERO backend imports — pure HTTP client                  │   │
│  └────────────────────────────────────────────────────────────┘   │
└──────────────────────────────────────────────────────────────────────┘
```

### Key difference from previous version

- **Web UI is OUTSIDE the API Layer** — it's a separate process that talks to the API over HTTP
- **CLI talks to API over HTTP** — it does NOT import DB modules directly
- **MCP in stdio mode** wraps HTTP calls internally — same communication pattern
- **DB is behind the API** — only the API Layer touches storage directly
- Core Services + Storage are internal implementation details of the API Layer

## Boundary Rules

### Rule 1: Browser uploads files, never sends paths

Files travel over HTTP as zip archives (SPEC-041). The server never reads from the user's filesystem.

### Rule 2: Web UI is a pure HTTP proxy

The UI renders HTML and proxies all data requests to the API. It never imports:
- `ecle.backends.*`
- `ecle.ingestion.*`
- `ecle.query.app.get_context`
- `ecle.clustering.*`

It only imports:
- `ecle.ui.api_client.ECLEApiClient` — its HTTP client to the API

### Rule 3: CLI communicates via API

CLI runs on the server machine but uses HTTP to talk to the API:

```python
# CLI import command
def cmd_import(args):
    # Upload files to API
    with open(args.facts_dir / "*.facts.json") as f:
        requests.post(f"{api_url}/api/upload", files=f)
    
    # NOT: loader = FactsLoader(db); loader.load_directory(path)
```

**Exception for v1**: CLI may use direct imports as a transitional step while the API upload endpoints are being built. This is technical debt, not architecture.

### Rule 4: MCP Server uses API for data access

Both stdio and streamable-http modes call the GraphQL/REST API:

| Mode | Transport | Data Access |
|------|-----------|-------------|
| stdio (IDE local) | stdin/stdout for MCP protocol | HTTP to API for data |
| streamable-http (shared) | HTTP for MCP protocol | HTTP to API for data |

### Rule 5: All storage paths are server-internal

No API response ever contains filesystem paths. Storage locations (`ecle-data/`) are implementation details of the API Layer.

### Rule 6: Authentication on all endpoints

- Bearer token: API, MCP (SPEC-021 done)
- Session cookie: Web UI
- No anonymous access

### Rule 7: Path traversal protection

All path construction from user input uses `_safe_path()` validation (implemented in ArtifactStore).

## What's Implemented vs What's Not

### Done
- [x] File upload over HTTP — `POST /ui/upload` (SPEC-041)
- [x] Client-side zip + extension filtering
- [x] Old path-based UI routes removed (`/ui/onboard`, `/ui/import`, `/ui/onboard-docs`, `/ui/onboard-config`)
- [x] Path traversal protection in ArtifactStore
- [x] ReDoS protection in search endpoint
- [x] CORS middleware on API (SPEC-022)
- [x] MCP HTTP transport + Bearer auth (SPEC-021)
- [x] UI DataAccess abstraction (SPEC-023) — partial, some routes still use `get_context()`
- [x] **API upload endpoint** — `POST /api/upload` for non-browser callers (CI/CD, CLI) (Phase 2)
- [x] **API chat endpoint** — `POST /api/chat` for programmatic chat (Phase 2)
- [x] **API stats endpoint** — `GET /api/stats` for all-repo stats (Phase 2)
- [x] **Deprecation warnings** — `POST /api/import` and `POST /api/ingest` include `_deprecated` flag (Phase 2)
- [x] **UI full HTTP-only** — routes.py has ZERO imports from ecle.query.app, ecle.backends.*, ecle.clustering.* (Phase 3)
- [x] **ECLEApiClient expanded** — search(), chat(), upload(), get_all_repo_stats() methods (Phase 3)

- [x] **MCP HTTP data access** — MCP tools call GraphQL/REST API when ECLE_API_URL is set; direct imports as fallback (Phase 4)
- [x] **MCPApiClient** — `src/ecle/mcp/api_client.py` with GraphQL + REST helpers for all 16 tools (Phase 4)
- [x] **Service REST endpoints** — 7 new REST endpoints in app.py for service/view/field queries (Phase 4)

- [x] **CLI HTTP migration** — `CLIApiClient` in `cli_client.py`, `--api-url` flag on import/stats/jobs commands (Phase 5)
- [x] **Bearer auth middleware** — `BearerAuthMiddleware` on API endpoints, conditional on `ECLE_API_TOKEN` (Phase 6)
- [x] **Session auth middleware** — `SessionAuthMiddleware` on UI routes, conditional on `ECLE_UI_PASSWORD` (Phase 6)

### Not Done
- [ ] **Cross-repo REST endpoints** — cross-repo tools fall back to direct DB in API mode
- [ ] **Vector search over API** — ecle_source_lookup vector strategy not available in API mode
- [ ] **Rate limiting** — not implemented

## Migration Phases

### Phase 1: File Upload + Path Removal (DONE)
Browser no longer sends filesystem paths. Files uploaded via HTTP multipart zip.

### Phase 2: API Upload Endpoint (DONE)
- `POST /api/upload` — multipart upload for API callers (CI/CD, CLI)
- `POST /api/chat` — programmatic chat endpoint
- `GET /api/stats` — per-repo stats for all repositories
- Deprecate `POST /api/import` (path-based) — `_deprecated` flag in response
- Deprecate `POST /api/ingest` (path-based) — `_deprecated` flag in response

### Phase 3: UI Full HTTP-Only (DONE)
- Removed all `get_context()` calls from `routes.py`
- All data access via `DataAccess` -> `ECLEApiClient` -> HTTP API
- `routes.py` imports only: `ecle.ui.api_client`, `ecle.config.loader`, `ecle.ingestion.job_queue`, `ecle.logging_config`
- DataAccess tries HTTP first, falls back to local DB in bundled mode (transitional)
- UI works identically whether bundled or standalone

### Phase 4: MCP HTTP Data Access (DONE)
- `MCPApiClient` in `src/ecle/mcp/api_client.py` — typed helpers for all 16 MCP tools
- All MCP tools check `_api_mode` flag (set when ECLE_API_URL is present)
- Core tools (file, files, functions, callers, impact, search, history, stats) use GraphQL
- Service tools (service_callers, service_impact, service_files, service_io) use new REST endpoints
- Field tools (view_fields, common_fields) use new REST endpoints
- `ecle_source_lookup` uses REST artifact search endpoint
- Cross-repo tools (`ecle_repos_tool`) use REST; remaining 5 fall back to direct DB (no REST endpoints yet)
- Direct backend imports preserved as fallback when ECLE_API_URL is not set
- 7 new REST endpoints added to `app.py` for service/view/field queries
- Both stdio and streamable-http modes use same data access path

### Phase 5: CLI HTTP Migration (DONE)
- `CLIApiClient` in `src/ecle/cli_client.py` — upload_files, get_repos, get_stats, get_jobs, health, trigger_cluster
- `--api-url` flag added to import, stats, jobs subcommands
- HTTP mode branches: when API URL set, uses CLIApiClient; otherwise falls back to direct imports
- Zip compression for file upload (same as browser path)

### Phase 6: Authentication + Security (DONE)
- `BearerAuthMiddleware` — validates `Authorization: Bearer <token>` on API/GraphQL routes, skips /health, /docs, /ui/*
- `SessionAuthMiddleware` — validates `ecle_session` cookie on /ui/* routes, handles /ui/login and /ui/logout
- Conditional: auth disabled when env vars not set (local dev), enabled when `ECLE_API_TOKEN` and/or `ECLE_UI_PASSWORD` set
- Both middlewares layered independently (Bearer for API, Session for UI)
- Rate limiting — not yet implemented (future)

## Deployment Modes After Full Migration

| Mode | Components | Communication |
|------|-----------|---------------|
| **Lite** | Single process: API + UI + MCP | Internal HTTP (localhost), same port different paths |
| **Single Server** | Separate processes: API, UI, MCP | HTTP between processes on same host |
| **Docker** | Separate containers | HTTP between containers via Docker network |
| **Enterprise** | Separate services + load balancers | HTTPS between services, external auth provider |

The communication pattern is **identical** across all modes. Only the deployment topology changes.

## v1.3 Implementation Notes (2026-04-11)

### AMF venv discovery (BUG-006)

`cpg/client.py` probes 4 locations for AMF's Python interpreter:
1. `{amf_root}/.venv/Scripts/python.exe` — Windows standard
2. `{amf_root}/.venv/bin/python` — Linux/Mac standard  
3. `{amf_root}/AMF/Scripts/python.exe` — Windows named venv
4. `{amf_root}/AMF/bin/python` — Linux/Mac named venv

Falls back to `sys.executable` (ECLE's Python) with a warning if none found.
