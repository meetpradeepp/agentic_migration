# SPEC-043: Platform Repository — Cross-Cutting Shared Data

**Status**: Spec
**Owner**: Platform Architect
**Files**: `src/ecle/ui/templates/onboard.html`, `src/ecle/ui/routes.py`, `src/ecle/mcp/server.py`, `src/ecle/backends/structured/sqlalchemy_backend.py`

## Problem Statement

Enterprise systems have data that cuts across all repositories:

- **Tuxedo domain XMLs** (5,056 files) — field definitions used by every service
- **Service descriptions** (640 files) — API contracts referenced across repos
- **Database schemas** (DDL) — shared tables accessed by multiple codebases
- **Config templates** — environment variables, pool configs used system-wide

Today this data must be uploaded to a specific `repo_id`. When querying repo-A, you can't see the domain definitions unless they were uploaded to repo-A. Cross-repo queries (`repo_id=*`) find them but don't know they're authoritative platform data vs just another repo's local facts.

## Design: Platform Repository

A reserved `repo_id = "__platform__"` that holds cross-cutting reference data. When querying ANY repo, platform data is automatically included.

### Onboard UI — Scope Selection

```
This data applies to:
  (●) Specific repository    ( ) All repositories (platform)
  [billing-service ▼]        Shared across all repos — queryable from any context.
```

When "All repositories (platform)" is selected:
- `repo_id` is set to `__platform__`
- Repo dropdown is hidden
- Files are uploaded and stored under `__platform__` namespace

### Query Behavior

```python
# When user queries repo "billing-service":
# 1. Search billing-service facts
# 2. ALSO search __platform__ facts
# 3. Merge results, platform data labeled as "platform" source

def get_file_tables(file_fact_id, include_platform=True):
    tables = db.query("... WHERE repo_id = :repo")
    if include_platform:
        tables += db.query("... WHERE repo_id = '__platform__'")
    return tables
```

### MCP Tool Behavior

All MCP tools that accept `repo_id` automatically include `__platform__`:
- `ecle_files(repo_id="billing")` → returns billing files + platform files
- `ecle_find_by_table(table="UNRATED_CDRS")` → finds in billing AND platform
- `ecle_service_io(service="svcCharge")` → checks platform for field definitions

### Cross-Repo Impact

Platform data changes affect ALL repos:
- `ecle_cross_repo_impact(artifact="OPERID")` → shows every repo using that field
- Platform data has `confidence=1.0` (authoritative reference data)

## What Gets Uploaded as Platform

| Content Type | Example | Why Platform |
|-------------|---------|-------------|
| Data (structured) | Tuxedo domain XMLs, service descriptions | Define API contracts for all services |
| Data-SQL | Shared database schemas (DDL) | Tables accessed by multiple repos |
| Config | Environment templates, pool configs | Runtime config affecting all services |
| Documents | Architecture docs, runbooks | Cross-cutting reference material |

Code and facts are always repo-specific — they belong to the repo that produced them.

## Implementation

### Phase 1: UI + Storage (DONE)
- [x] Scope toggle on onboard form (repo vs platform)
- [x] `__platform__` repo_id in upload handler
- [x] Platform data visible in health dashboard stats — labeled "Platform (shared)" with PLATFORM badge

### Phase 2: Query Integration
- [x] All `repo_id`-scoped queries auto-include `__platform__`
- [x] MCP tools include platform data (via backend query changes)
- [x] GraphQL resolvers include platform data (via backend query changes)
- [x] Platform results labeled with `is_platform: true` in responses

### Phase 3: Platform Management
- [ ] Platform data versioning (track which version of domain defs is active)
- [ ] Platform data diff (what changed between domain def versions)
- [ ] Platform data lineage (which repos depend on which platform definitions)

## v1.3 Implementation Notes (2026-04-11)

**Status**: Phase 1 + Phase 2 Implemented

### ecle_search document vector inclusion

`ecle_search` now queries both code and document vector collections:
- `{repo_id}__fss` — code embeddings (file + function)
- `{repo_id}.docs` — document chunk embeddings (via `_safe_collection_name()`)
- `platform.docs` — auto-included for platform overlay

Wildcard search (`repo_id="*"`) iterates all `__fss` AND `.docs` collections.

Implementation: `server.py` lines 858-898. Uses `from ecle.ingestion.document_embedder import _safe_collection_name` for repo-specific doc collection naming.

### ecle_source_read platform fallback

5-location search order:
1. `{repo}/import/code_repo/source_clean/**/{file_id}` — legacy import
2. `{repo}/{commit_sha}/sources/{file_id}` — versioned source
3. `{repo}/documents/{file_id}` — documents
4. `{repo}/**/{file_id}` — recursive fallback
5. `__platform__/documents/{file_id}` — **platform fallback** (new in v1.3)

If file not found in the specified repo, automatically searches `__platform__` documents + recursive. Implementation: `server.py` lines 2122-2136.

### Platform docs collection naming

`__platform__` → sanitized to `platform.docs` for ChromaDB (which rejects leading underscores). Handled by `_safe_collection_name("__platform__", "docs")` in `document_embedder.py`.
