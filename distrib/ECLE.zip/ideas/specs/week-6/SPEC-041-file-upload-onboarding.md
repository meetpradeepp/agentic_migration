# SPEC-041: File Upload Onboarding — Browser-to-Server File Transfer

**Status**: Spec
**Owner**: Onboarding Engineer + Web UI Engineer
**Files**: `src/ecle/ui/templates/onboard.html`, `src/ecle/ui/routes.py`, `src/ecle/ingestion/job_queue.py`
**Supersedes**: Path-based file input in Web UI

## Problem Statement

The current Web UI asks users to type a **server-side path** (`C:\path\to\source`). This is fundamentally broken:

1. **Browser security**: Browsers cannot read local filesystem paths. A text input with a path is useless — the server has no access to the user's machine.
2. **Deployment model**: Even in "lite mode", ECLE could be on AWS, a data center, or a Docker container. The server and user's browser are always separate.
3. **CLI is different**: `ecle import /local/path` works because CLI runs on the same machine as the server process. Web UI does not.

## Architecture

```
User's Browser                              ECLE Server
    │                                           │
    │  <input type="file" webkitdirectory>      │
    │  User selects folder from OS picker       │
    │                                           │
    │  POST /ui/upload (multipart/form-data)    │
    │  Files streamed over HTTP ───────────►    │
    │                                           │  Saves to ecle-data/uploads/{job_id}/
    │                                           │  Creates ImportJob
    │                                           │  Worker processes from uploads dir
    │  { "Queued: job_id" }                     │
    │  ◄─────────────────────────────────────   │
```

## UI Changes

### Replace path text input with folder upload

```html
<!-- For code/config/data/documents -->
<label class="form-label">Select files</label>
<input type="file" name="files" webkitdirectory multiple
       id="file-upload" onchange="updateFileCount(this)">
<small id="file-count" style="color:var(--tmobile-gray-dark)"></small>

<!-- For facts (.facts.json only) -->
<label class="form-label">Select .facts.json files</label>
<input type="file" name="files" multiple accept=".json"
       id="facts-upload" onchange="updateFileCount(this)">
```

### `webkitdirectory` behavior

- Supported in Chrome, Edge, Firefox (covers 95%+ of enterprise browsers)
- Shows OS native folder picker dialog
- Returns ALL files in the selected folder (recursively)
- File objects include `webkitRelativePath` preserving directory structure

### File count feedback + extension filtering

Files are filtered client-side by content-type-specific extensions (loaded from `/ui/extensions` endpoint, configured in `ecle.yaml` under `extensions:`). After selection:

- Summary shows: **"5055 files selected (5.6 MB) — [view details](#)"**
- "view details" opens a **folder tree modal** with collapsed pass/fail grouping:
  - ✅ All-pass folders collapsed: `✅ src/main/java/ (52 files)`
  - ❌ All-fail folders collapsed: `❌ src/resources/ (3 files)`
  - ⚠️ Mixed folders expanded one level showing sub-groups
- **Copy** button copies the tree as text
- **Close** button and click-outside close the modal

### Client-side zip compression

Files are zipped in-browser using JSZip (vendored locally at `/static/jszip.min.js`) before upload:
1. Only files matching allowed extensions are added to the zip
2. Progress bar shows compression % then upload %
3. Single `.zip` blob sent via HTTP multipart — avoids 5000-file multipart overhead
4. Server extracts zip, re-validates extensions (defense in depth), submits job

### Git source — no upload needed

When "Git Repository" is selected, the URL/branch/auth fields remain as text inputs. The server clones the repo directly. No file upload.

## Server Changes

### Upload endpoint

```python
@router.post("/upload")
async def upload_files(
    request: Request,
    content_type: str = Form("code"),
    repo_id: str = Form("default"),
    new_repo_id: str = Form(""),
    files: list[UploadFile] = File(...),
):
    """Receive uploaded files, store in uploads dir, submit job."""
    repo_id = _resolve_repo_id(repo_id, new_repo_id, "")

    # Create upload directory
    upload_dir = settings.home / "uploads" / f"{repo_id}_{uuid4().hex[:8]}"
    upload_dir.mkdir(parents=True, exist_ok=True)

    # Save files preserving directory structure
    for f in files:
        # webkitRelativePath gives "folder/subfolder/file.c"
        rel_path = f.filename  # FastAPI uses filename from multipart
        dest = upload_dir / rel_path
        dest.parent.mkdir(parents=True, exist_ok=True)
        with open(dest, "wb") as out:
            content = await f.read()
            out.write(content)

    # Submit job pointing to upload directory
    job = ImportJob(
        repo_id=repo_id,
        source_type=content_type,
        source_path=str(upload_dir),
        content_type=content_type,
    )
    queue.submit(job)
```

### Upload size limits

- Default max: 500MB per upload (configurable in ecle.yaml)
- FastAPI/Starlette: set `max_request_size` on the app
- Large repos should use CLI or Git source instead

### Cleanup

After job completes (or fails), the upload directory is cleaned up:
```python
# In QueueWorker._process_job(), after completion:
if str(source_path).startswith(str(settings.home / "uploads")):
    shutil.rmtree(source_path, ignore_errors=True)
```

## What Changes Per Content Type

| Content Type | Upload Input | Accept Filter | Notes |
|-------------|-------------|---------------|-------|
| Code | `webkitdirectory` | All files | Full folder upload |
| Config | `webkitdirectory` | All files | Full folder upload |
| Data | `webkitdirectory` | All files | Full folder upload |
| Data-SQL | `webkitdirectory` or `multiple` | `.sql, .ddl, .rql` | Can be individual files |
| Documents | `webkitdirectory` or `multiple` | `.md, .pdf, .docx, .csv` | Can be individual files |
| Facts | `multiple` | `.json` | Only .facts.json files |

## What Stays the Same

- **CLI**: `ecle import /path` still works (CLI runs on server, has filesystem access)
- **Git source**: URL-based, no upload needed
- **Job queue**: Same ImportJob model, just source_path points to uploads dir
- **Processing pipeline**: Unchanged — reads from source_path regardless of how files got there

## Browser Compatibility

| Browser | `webkitdirectory` | `multiple` |
|---------|-------------------|-----------|
| Chrome 49+ | Yes | Yes |
| Edge 14+ | Yes | Yes |
| Firefox 50+ | Yes | Yes |
| Safari 11.1+ | Yes | Yes |

## Migration

- Remove path text input from onboard.html
- Remove `/ui/browse` endpoint (already removed)
- Add `/ui/upload` endpoint
- Add `ecle-data/uploads/` directory to ECLE_HOME structure
- Update SPEC-035 (ECLE_HOME) to include `uploads/` directory
