# SPEC-039: Java CPG Extraction — Project-Level Parsing

**Status**: Spec
**Owner**: CPG Pipeline Engineer
**Files**: `AMF/stages/languages/java/extractor.sc` (rewrite assembly), `AMF/stages/cpg/parsers/joern/parser.py` (add directory mode), `AMF/stages/cpg/run.py` (batch Java files), `AMF/stages/languages/java/manifest.yaml` (project-mode config)

## Problem Statement

48 out of 66 Java facts files are **completely empty** after CPG extraction. The extraction pipeline reports `Return Code: 0` for all files, masking silent failures.

### Root Cause (Two compounding bugs)

**Bug 1: Per-file CPG parsing breaks Java type resolution**

AMF calls `joern-parse <single_file> --language javasrc` for each Java file. But `javasrc2cpg` is designed to parse an entire source directory:

```
Usage: javasrc2cpg [options] input-dir
  input-dir                source directory
```

When parsing a single file, the javasrc frontend cannot resolve types from other project files. For 48/66 files, `joern-parse` creates a structurally valid but **content-empty** CPG binary — zero TypeDecl nodes, zero Method nodes.

**Evidence from extraction logs:**

| Behavior | Working (18 files) | Empty (48 files) |
|----------|-------------------|-------------------|
| Overlay status | `Overlay dataflowOss already exists - skipping` | `Adding default overlays to base CPG` |
| TypeDeclStubCreator | N/A (overlays already present) | `0 + 0 changes committed` |
| MethodStubCreator | N/A (overlays already present) | `0 + 0 changes committed` |
| `-> Processing:` line | Present | Missing |
| Facts output | Classes, functions, annotations extracted | All arrays empty |

Working files are those with minimal cross-file dependencies (main class, constants, simple JDK-only models).

**Bug 2: `headOption` limits output to first file**

`extractor.sc` line 303:
```scala
val fileData = filesData.headOption.getOrElse(Obj())
```

Even when a project-level CPG contains all files, only the first file's data is written. The per-file iteration loop (lines 137-300) correctly processes all files, but the assembly discards everything except the first.

**Bug 3: Global scope for classes/annotations/spring_components**

`classDecls` (line 69), `allAnnotations` (line 119), and `springComponents` (line 122) are extracted from the entire CPG — not scoped to the current file. In multi-file mode, every facts file would contain ALL classes from the project instead of just the ones declared in that file.

## Architecture

### Current (Broken)
```
66 Java files
  ↓ (per-file)
joern-parse file.java --language javasrc → file.cpg.bin
  ↓ (per-file)
joern --script extractor.sc → file.facts.json
  ↓
48 empty, 18 have data
```

### Fixed
```
Source directory (66 Java files)
  ↓ (ONE call)
joern-parse /src/ --language javasrc → project.cpg.bin
  ↓ (ONE call)
joern --script extractor.sc → 66 .facts.json files (one per source file)
```

### javasrc2cpg-specific Options (future enhancement)

**IMPORTANT**: `joern-parse` does NOT forward language-specific flags. Options like
`--fetch-dependencies`, `--delombok-mode` are `javasrc2cpg`-direct CLI flags. To use
them, the parser must call `javasrc2cpg` directly instead of `joern-parse`.

| Option | Purpose | Requires |
|--------|---------|----------|
| `--fetch-dependencies` | Auto-fetch Maven/Gradle deps for type info | Direct `javasrc2cpg` call |
| `--delombok-mode default` | Handle Lombok annotations | Direct `javasrc2cpg` call |
| `--inference-jar-paths` | Extra jars for type resolution | Direct `javasrc2cpg` call |

For Phase 1 of this fix, `joern-parse --language javasrc` on the directory is sufficient
to resolve cross-file types. The additional flags are a Phase 2 enhancement.

## Changes Required

### 1. Java Manifest — Add project-mode config

**File**: `AMF/stages/languages/java/manifest.yaml`

```yaml
parser:
  parser_id: "joern"
  parse_mode: "project"    # NEW: "file" (default) or "project"
  args: ["--language", "javasrc", "--fetch-dependencies", "--delombok-mode", "default"]
```

### 2. AMF Parser — Directory mode

**File**: `AMF/stages/cpg/parsers/joern/parser.py`

Add `parse_directory(input_dir, output_file, args)` method alongside existing `parse_file()`.

### 3. AMF Run — Batch Java files

**File**: `AMF/stages/cpg/run.py`

When `parse_mode == "project"`:
1. Collect all Java files
2. Call `parser.parse_directory(source_dir, project_cpg, args)` once
3. Call extractor.sc once with `JOERN_OUTPUT_DIR` env var
4. Map output facts files back to source files

### 4. Extractor.sc — Multi-file output mode

**File**: `AMF/stages/languages/java/extractor.sc`

#### 4a. File-scoped class/annotation extraction

Move `classDecls`, `allAnnotations`, `springComponents` inside the per-file loop, scoped by `file.typeDecl` instead of `appCpg.typeDecl`:

```scala
// Inside the per-file loop:
val fileTypeDecls = file.typeDecl
  .filterNot(_.isExternal)
  .filterNot(t => t.name.startsWith("<") || t.name == "ANY")

val fileClassDecls = fileTypeDecls.map { t => /* ... existing class extraction ... */ }.l
val fileAnnotations = /* ... scoped to this file's types and methods ... */
val fileSpringComponents = /* ... scoped to this file's types ... */
```

#### 4b. Multi-file output loop

Replace `headOption` + single-file assembly with per-file output:

```scala
val outputDir = sys.env.get("JOERN_OUTPUT_DIR")

if (outputDir.isDefined) {
    // Project-mode: one facts file per source file
    validFiles.foreach { file =>
        val relName = file.name
        val flatName = relName.replace("/", "__").replace("\\", "__")

        // Extract file-scoped data
        val fileData = extractFileData(file)  // existing per-file logic
        val fileClasses = extractFileClasses(file)
        val fileAnnotations = extractFileAnnotations(file)
        val fileSpring = extractFileSpringComponents(file)

        val payload = assemblePayload(relName, fileData, fileClasses, fileAnnotations, fileSpring)
        val outPath = s"${outputDir.get}/$flatName.facts.json"
        writeJson(outPath, payload)
        println(s"  -> Wrote: $outPath")
    }
} else {
    // Legacy single-file mode (backward compatible with per-file CPGs)
    val fileData = filesData.headOption.getOrElse(Obj())
    // ... existing single-file assembly ...
}
```

#### 4c. Assembly function (reusable)

```scala
def assemblePayload(filename: String, fileData: Obj,
    classes: List[Obj], annotations: List[Obj], spring: List[Obj]): Obj = {
    val structDefs = classes.map(cls => Obj("name" -> cls("name"), "members" -> ujson.Arr()))
    Obj(
        "filename"               -> filename,
        "language"               -> "java",
        "global_defs"            -> ujson.Arr(),  // file-scoped (usually empty per-file)
        "struct_definitions"     -> structDefs,
        "functions"              -> fileData.obj.getOrElse("functions", ujson.Arr()),
        "local_variables"        -> fileData.obj.getOrElse("local_variables", ujson.Arr()),
        // ... all other fields ...
        "classes"                -> classes,
        "annotations"            -> annotations,
        "spring_components"      -> spring
    )
}
```

## Backward Compatibility

- **`JOERN_OUTPUT_PATH` (existing)**: Single-file mode unchanged — per-file CPGs still work for C, PowerBuilder
- **`JOERN_OUTPUT_DIR` (new)**: Multi-file mode — project CPGs produce per-file facts
- The two modes are selected by which env var is set
- AMF's system_linker, bridge, and gap_analysis stages receive the same facts format

## ECLE Integration

SPEC-036 (`CPGClient`) already handles the AMF subprocess call. The change is transparent to ECLE:
- CPG client calls AMF's `run.py` the same way
- More facts files are produced (48 → 66)
- Facts format is identical

## Validation

### Before Fix
```
Total Java files: 66
Facts with content: 18 (27%)
Empty facts: 48 (73%)
```

### After Fix (Expected)
```
Total Java files: 66
Facts with content: ~63+ (95%+)
Empty facts: ~3 (interface-only files, package-info.java)
```

### Test Plan

1. **Regression**: Run existing C/PowerBuilder extraction — per-file mode unchanged
2. **Java project**: Re-extract bulk-charges-adjustments-ms with project-mode
3. **Verify**: All 66 facts files should have classes array populated
4. **Controller test**: `CreateAdjustmentChargesController.java` should have functions, annotations, spring_components
5. **Model test**: `AddressInfo.java` should have class declaration and fields
6. **Lombok test**: Check if `--delombok-mode default` extracts generated getters/setters
7. **Compare**: Count of functions, classes, edges before vs after

## Dependencies

- Joern 4.x installed at `JOERN_HOME`
- Java 17+ (for delombok)
- Maven/Gradle wrapper in project (for `--fetch-dependencies`)

## Risk

- **Performance**: Project-level CPG takes longer to create than per-file CPGs individually, but total time should be LESS because type resolution succeeds on first pass
- **Memory**: Large Java projects may need more heap for project CPG. Monitor with `-J-Xmx` flag.
- **Backward compat**: Legacy per-file mode preserved via env var switch
