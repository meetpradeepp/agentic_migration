# SPEC-044: Two-Phase Extraction Workflow (ECLE Side)

**Status**: Implemented
**Owner**: Onboarding Engineer / Platform Architect
**ADR**: ADR-030 (Two-Phase CPG Extraction)
**Related**: SPEC-045 (AMF side), SPEC-037 (job queue), SPEC-040 (unified onboard), SPEC-036 (CPG trigger)
**Files**:
  - `src/ecle/ingestion/job_queue.py` — ImportJob + QueueWorker changes
  - `src/ecle/cpg/client.py` — CPGClient phase parameter
  - `src/ecle/ingestion/facts_loader.py` — extraction_tier column
  - `src/ecle/backends/structured/sqlite.py` — schema + stats
  - `src/ecle/backends/structured/sqlalchemy_backend.py` — schema + stats
  - `src/ecle/ui/routes.py` — API endpoints for phase visibility
  - `src/ecle/cli.py` — CLI onboard flow

## Problem Statement

Onboarding a 3,000-file codebase takes ~31 hours because Joern CPG extraction blocks the entire pipeline. The knowledge graph is unusable until Joern finishes ALL files. ADR-030 introduces two-phase extraction: structural (Tree-sitter, minutes) then deep (Joern, hours). This spec defines the ECLE-side workflow — job lifecycle, DB schema, API, and UI changes.

**The AMF-side changes (run.py --phase, TreeSitterParser, fast_extractor.py) are in SPEC-045.** This spec assumes AMF accepts `--phase structural|deep` and produces `.facts.json` files in both modes.

## Architecture

### Job Lifecycle

Every onboard creates ONE structural job. On its completion, the worker auto-creates a deep job.

```
User: "Onboard billing-service"
  │
  ▼
ImportJob(phase="structural") → pending
  │
  ▼ (worker picks up)
Phase 1: structural → processing → complete
  │  Tree-sitter → .facts.json → FactsLoader → edges → vectors
  │  Knowledge graph LIVE (~10 min)
  │
  ▼ (worker auto-creates on completion)
ImportJob(phase="deep", parent_job_id=structural.job_id) → pending
  │
  ▼ (worker picks up)
Phase 2: deep → processing → complete
  │  Joern → .facts.json (overwrites) → hash gate → re-ingest enriched
  │  Knowledge graph deepened (~hours)
  │
  ▼
Both jobs visible in dashboard with independent status/duration
```

### Job States

No new states. Existing: `pending → processing → complete | failed`.

The deep job does not exist until structural completes. This means:
- No orphaned deep jobs on structural failure
- Duplicate-repo guard works unchanged (one active job per repo)
- Retry of failed structural re-creates structural only (user retries deep separately if needed)
- Retry of failed deep works independently — structural results preserved

## Interface Changes

### 1. ImportJob Dataclass

```python
# src/ecle/ingestion/job_queue.py

@dataclass
class ImportJob:
    # ... all existing fields unchanged ...

    # NEW fields (ADR-030)
    phase: str = ""                    # "structural" | "deep" | "" (legacy)
    parent_job_id: str | None = None   # deep job → points to structural job
```

**Backward compatibility:** `phase=""` means legacy single-phase job (existing Joern-only behavior). The worker treats `phase=""` identically to `phase="deep"` — runs existing code path unchanged.

### 2. CPGClient.extract() — Phase Parameter

```python
# src/ecle/cpg/client.py

class CPGClient:
    def extract(
        self,
        source_dir: Path,
        output_dir: Path,
        progress_callback: Callable | None = None,
        phase: str = "deep",                          # NEW
    ) -> CPGResult:
```

In `_extract_local()`, the phase is passed to AMF:

```python
subprocess.Popen(
    [str(amf_python), str(run_script), "--phase", phase],
    env=env,
    cwd=str(amf_root),
    # ... rest unchanged ...
)
```

### 3. QueueWorker._process_job() — Phase Routing

The code/facts path in `_process_job()` changes to pass `job.phase` through:

```python
# In _try_cpg_extraction():
result = client.extract(
    source_dir, output_dir, progress_callback,
    phase=job.phase or "deep"    # "" or missing → legacy deep
)
```

On successful structural completion, auto-submit deep job:

```python
# At end of code/facts processing in _process_job(), after queue.complete():
if job.phase == "structural":
    deep_job = ImportJob(
        repo_id=job.repo_id,
        phase="deep",
        source_type=job.source_type,
        content_type=job.content_type,
        source_path=job.source_path,
        facts_dir=job.facts_dir,
        commit_sha=job.commit_sha,
        branch=job.branch,
        parent_job_id=job.job_id,
    )
    try:
        self.queue.submit(deep_job)
        logger.info(
            "Deep job auto-submitted",
            extra={"context": {
                "structural_job": job.job_id,
                "deep_job": deep_job.job_id,
                "repo_id": job.repo_id,
            }},
        )
    except ValueError:
        # Duplicate-repo guard fired — another job active. Log and skip.
        logger.warning("Deep job not submitted — repo has active job")
```

### 4. Onboard Submission — Create Structural Job

All entry points (UI, CLI, API) create a structural job instead of the current default:

```python
# CLI: ecle onboard
job = ImportJob(
    repo_id=repo_id,
    phase="structural",         # NEW — was absent (legacy)
    source_path=str(source_dir),
    # ... rest unchanged ...
)
queue.submit(job)
```

**Legacy compatibility:** `ecle import --facts-dir` (pre-existing Joern facts) still creates a job with `phase=""` — goes straight through existing code path, no structural/deep distinction.

### 5. DB Schema — extraction_tier Column

```sql
-- file_facts table: add column
ALTER TABLE file_facts ADD COLUMN extraction_tier TEXT DEFAULT 'full';
```

Values:
- `"structural"` — Phase 1 completed, Phase 2 not yet processed
- `"full"` — Phase 2 completed, or legacy Joern-only import

Set by `FactsLoader.load_file()` based on `_extraction_tier` field in `.facts.json`:

```python
# In FactsLoader.load_file(), after building file_facts_data:
file_facts_data["extraction_tier"] = facts.get("_extraction_tier", "full")
```

The `_extraction_tier` field is written by AMF's extractors (SPEC-045):
- Tree-sitter fast_extractor.py sets `"_extraction_tier": "structural"`
- Joern extractor.sc does not set it → defaults to `"full"`

### 6. Stats — Extraction Tier Breakdown

```python
# In get_stats():
def get_stats(self, repo_id):
    stats = {
        # ... existing stats unchanged ...
        "structural_files": self.count(
            "file_facts",
            "repo_id = ? AND is_current = 1 AND extraction_tier = 'structural'",
            (repo_id,),
        ),
        "full_files": self.count(
            "file_facts",
            "repo_id = ? AND is_current = 1 AND extraction_tier = 'full'",
            (repo_id,),
        ),
    }
    return stats
```

### 7. Health API — Phase Visibility

```python
# GET /health/jobs — enhanced response
"recent": [
    {
        "job_id": j.job_id,
        "repo_id": j.repo_id,
        "status": j.status,
        "phase": j.phase,                    # NEW
        "parent_job_id": j.parent_job_id,    # NEW
        "source_type": j.source_type,
        "content_type": j.content_type,
        "duration_ms": j.duration_ms,
        # ... rest unchanged ...
    }
]
```

```python
# GET /health/stats/{repo_id} — enhanced response
{
    "files": 3000,
    "functions": 2847,
    "edges": 156,
    "table_ops": 89,
    "structural_files": 1753,    # NEW — files at structural depth
    "full_files": 1247,          # NEW — files at full depth
}
```

### 8. Confidence Profile — extraction_fidelity

When building query responses, `extraction_tier` maps to confidence:

| extraction_tier | extraction_fidelity | Rationale |
|----------------|---------------------|-----------|
| `"structural"` | 0.70 | Structural facts present; type resolution and DFG pending |
| `"full"` | 0.95 | Complete CPG analysis |

This is consumed by MCP tools when assembling confidence profiles. The mapping is a simple lookup — no new infrastructure needed.

## Behavior

### Scenario 1: Normal Onboard (code upload)

```
1. User uploads code via UI → ImportJob(phase="structural") submitted
2. Worker: Tree-sitter extraction via run.py --phase structural
3. Worker: FactsLoader loads 3,000 .facts.json files
4. Worker: TopologyBuilder computes 156 edges
5. Worker: EmbeddingPipeline generates 4,201 vectors
6. Worker: Job complete (12 min). Knowledge graph LIVE.
7. Worker: Auto-submits ImportJob(phase="deep", parent_job_id=step1.job_id)
8. Worker: Joern extraction via run.py --phase deep
9. Worker: FactsLoader re-ingests (hash gate skips 2,153 unchanged files)
10. Worker: TopologyBuilder recomputes edges for 847 enriched files (+89 edges)
11. Worker: EmbeddingPipeline re-embeds 847 files + neighbors
12. Worker: Deep job complete (6 hours). Knowledge graph deepened.
```

### Scenario 2: Import Existing Facts (AMF output)

```
1. User: ecle import --facts-dir ./joern-exports/facts/ --repo billing
2. ImportJob(phase="", source_type="facts") submitted
3. Worker: Existing code path — no CPG extraction
4. Worker: FactsLoader loads facts, extraction_tier defaults to "full"
5. No deep job created (phase="" → legacy path)
```

### Scenario 3: Structural Succeeds, Deep Fails

```
1. Structural job completes. Knowledge graph LIVE.
2. Deep job submitted, starts processing.
3. Joern crashes on file #847. Deep job fails.
4. User sees: Structural ✅ Complete | Deep ❌ Failed
5. User clicks "Retry" on deep job → new deep job created
6. Knowledge graph remains queryable at structural depth throughout.
```

### Scenario 4: Structural Fails

```
1. Structural job starts.
2. Tree-sitter extraction fails (disk full, permissions, etc.)
3. Structural job fails. No deep job created.
4. User sees: Structural ❌ Failed
5. User fixes the issue, clicks "Retry" → new structural job.
```

## Tests

### Unit Tests

1. **ImportJob serialization** — phase and parent_job_id round-trip through JSON
2. **Worker routing** — phase="structural" calls CPGClient with phase="structural"
3. **Worker routing** — phase="deep" calls CPGClient with phase="deep"
4. **Worker routing** — phase="" calls CPGClient with phase="deep" (legacy)
5. **Auto-submit** — successful structural job creates deep job with correct parent_job_id
6. **Auto-submit** — failed structural job does NOT create deep job
7. **extraction_tier** — FactsLoader reads _extraction_tier from facts JSON, stores in DB
8. **extraction_tier default** — missing _extraction_tier defaults to "full"
9. **Stats** — get_stats returns structural_files and full_files counts
10. **Hash gate** — re-loading same .facts.json with different extraction_tier but same content → skipped (hash unchanged)
11. **Hash gate** — re-loading enriched .facts.json with additional data_flow_edges → re-ingested (hash changed)

### Integration Tests

1. **Full two-phase cycle** — submit structural → completes → deep auto-created → completes. Verify extraction_tier transitions from "structural" to "full" for enriched files.
2. **Structural-only** — submit structural → completes → deep created but simulate failure → verify knowledge graph queryable at structural depth.
3. **Legacy path** — submit phase="" job → verify existing behavior unchanged.
4. **Retry deep** — fail deep job → retry → verify structural facts preserved, only deep re-runs.

## Dependencies

- **SPEC-045** (AMF side): `run.py --phase structural|deep`, `TreeSitterParser` plugin, `fast_extractor.py` per language. Without this, Phase 1 falls back to existing parsers (still functional but not faster).
- **ADR-030**: Architecture decision this spec implements.
- **SPEC-037**: Job queue foundation this spec extends.

## Migration

- **DB migration**: `ALTER TABLE file_facts ADD COLUMN extraction_tier TEXT DEFAULT 'full'`
- Existing data gets `extraction_tier = 'full'` (correct — all existing facts came from Joern)
- No data migration needed — default handles it
- New column is nullable-safe — old code that doesn't set it gets the default

## Rollout

1. Add `extraction_tier` column and ImportJob fields (backward compatible, no behavior change)
2. Add phase routing in worker + CPGClient (no-op until SPEC-045 provides TreeSitterParser)
3. Add auto-submit of deep job on structural completion
4. Add stats + API changes for UI visibility
5. SPEC-045 delivers AMF side → Phase 1 starts using Tree-sitter
