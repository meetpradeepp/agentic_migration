# SPEC-047: Cross-Tier Linker — Connecting Code, Config, Schema, and Data

**Status**: Implemented
**Owner**: Platform Architect
**Files**: `src/ecle/ingestion/cross_tier_linker.py`, `src/ecle/backends/structured/sqlite.py`, `src/ecle/backends/structured/sqlalchemy_backend.py`, `src/ecle/mcp/server.py`, `src/ecle/query/app.py`, `src/ecle/ingestion/job_queue.py`

## Problem Statement

ECLE ingests 6 content types (code, facts, config, documents, data, data-sql) but they exist in separate silos:

- **Code** knows which tables it reads/writes, but not which database those tables belong to
- **DDL schemas** define table columns, but don't know which code accesses them
- **Config** has database connection strings, but nothing links them to schemas or code
- **Data** (Tuxedo domains) defines fields, but nothing links fields to table columns
- **Documents** mention table names and services, but cross-references are shallow

The user asks: "Show me everything about UNRATED_CDRS" — today they get partial answers from each silo. The full picture requires cross-tier edges.

## Design: Cross-Tier Edge Types

### Edge Types

| Edge | From | To | How Detected |
|------|------|----|-------------|
| `CONFIG_DB_CONNECTION` | Config key (db.url) | Database name | Parse JDBC/connection string patterns |
| `DB_OWNS_TABLE` | Database name | Table (db_tables) | DDL schema prefix or config mapping |
| `TABLE_HAS_COLUMN` | Table (db_tables) | Column (db_columns) | Already exists in DDL extraction |
| `CODE_READS_TABLE` | Code file | Table | Already exists (file_tables, operation=READ) |
| `CODE_WRITES_TABLE` | Code file | Table | Already exists (file_tables, operation=WRITE) |
| `CODE_USES_COLUMN` | Code file/function | Column | NEW: match SELECT/WHERE column names to db_columns |
| `FIELD_MAPS_COLUMN` | Domain field (data) | Column (db_columns) | NEW: name match (OPERID → OPERID column) |
| `SERVICE_USES_FIELD` | Service definition | Domain field | NEW: service IO fields → domain field names |
| `CONFIG_SETS_PARAM` | Config key | Service/code parameter | NEW: property name → code constant match |
| `DOC_REFERENCES_TABLE` | Document chunk | Table | Name match in doc text → db_tables |
| `DOC_REFERENCES_FILE` | Document chunk | Code file | Name match in doc text → file_facts |
| `DOC_REFERENCES_SERVICE` | Document chunk | Service | Name match in doc text → service names |
| `DOC_REFERENCES_COLUMN` | Document chunk | Column | NEW: column name mentions in docs → db_columns |
| `DOC_REFERENCES_CONFIG` | Document chunk | Config key | NEW: config key mentions in docs |

### What's Already Connected (Tier 1)

```
Code ←→ Tables (via file_tables — operation-level: READ/WRITE)
Code ←→ Functions (via function_facts — call graph)
Code ←→ Code (via topology_edges — FUNCTION_CALL, IMPORT, etc.)
DDL ←→ Columns (via db_tables + db_columns)
Docs ←→ Tables/Files (via document_references — name match)
```

### What's Missing (This Spec)

```
Config → Database → Tables → Columns → Code (full chain)
Data fields → Columns → Code (field-to-column mapping)
Services → Fields → Columns → Code (service IO tracing)
Config params → Code constants (configuration impact)
```

## Implementation

### Phase 1: Column-Level Code Linking

Match SQL column references in code to `db_columns` entries.

```python
class CrossTierLinker:
    """Discovers and creates edges between different content tiers."""
    
    def link_code_to_columns(self, repo_id: str) -> dict:
        """Match SQL column names in code to DDL column definitions.
        
        Scans file_tables for table operations, then checks if the SQL text
        references specific column names defined in db_columns.
        """
        # For each file that touches a table:
        #   1. Get the SQL text from file_tables.evidence
        #   2. Get the columns for that table from db_columns
        #   3. Check which column names appear in the SQL
        #   4. Create CODE_USES_COLUMN edges
```

### Phase 2: Config-to-Database Linking

Parse connection strings from config to identify database names.

```python
    def link_config_to_databases(self, repo_id: str) -> dict:
        """Extract database names from config connection strings.
        
        Patterns recognized:
          - jdbc:oracle:thin:@host:port:DBNAME
          - jdbc:oracle:thin:@host:port/SERVICE_NAME
          - postgresql://user:pass@host:port/DBNAME
          - mongodb://host:port/DBNAME
          - Server=host;Database=DBNAME;
          - db.name=DBNAME, db.url=..., spring.datasource.url=...
        """
```

### Phase 3: Field-to-Column Mapping

Match Tuxedo domain field names to database column names.

```python
    def link_fields_to_columns(self, repo_id: str) -> dict:
        """Match domain field definitions to database columns by name.
        
        Tuxedo fields (from data tier) often have the same name as
        database columns. OPERID in the domain maps to OPERID column
        in the database.
        """
```

### Phase 4: Service-to-Field-to-Code Chain

Trace from service definition → field IO → column → code.

```python
    def trace_service_data_flow(self, service_name: str, repo_id: str) -> dict:
        """Full data flow trace for a service.
        
        Returns:
          {
            "service": "svcCharge",
            "input_fields": ["OPERID", "AMOUNT", "ACCTNO"],
            "output_fields": ["CHARGE_ID", "STATUS"],
            "tables_accessed": {
              "UNRATED_CDRS": {"columns": ["CDR_ID", "AMOUNT"], "operation": "READ"},
              "RATED_CDRS": {"columns": ["CDR_ID", "RATED_AMT"], "operation": "WRITE"}
            },
            "config": {
              "db.url": "jdbc:oracle:thin:@billing-db:1521/BILLINGDB",
              "service.timeout": "30"
            },
            "code_files": ["charge.cbl", "rate_engine.c"],
            "database": "BILLINGDB"
          }
        """
```

## Storage

### New Table: `cross_tier_edges`

```sql
CREATE TABLE IF NOT EXISTS cross_tier_edges (
    id TEXT PRIMARY KEY,
    edge_type TEXT NOT NULL,     -- CONFIG_DB_CONNECTION, CODE_USES_COLUMN, etc.
    source_type TEXT NOT NULL,   -- config, code, data, data-sql
    source_id TEXT NOT NULL,     -- file_id or config key or field name
    target_type TEXT NOT NULL,   -- table, column, database, service
    target_id TEXT NOT NULL,     -- table name, column name, db name
    confidence REAL DEFAULT 1.0, -- 1.0 exact match, 0.8 case-insensitive, 0.6 fuzzy
    evidence TEXT,               -- what matched: "SQL: SELECT CDR_ID FROM..."
    repo_id TEXT NOT NULL,
    created_at TEXT NOT NULL
);
```

### New Table: `databases`

```sql
CREATE TABLE IF NOT EXISTS databases (
    database_name TEXT NOT NULL,
    connection_string TEXT,
    source_config_file TEXT,     -- which config file defined this
    source_config_key TEXT,      -- which config key (e.g., db.url)
    repo_id TEXT NOT NULL,
    PRIMARY KEY (database_name, repo_id)
);
```

## MCP Tools

### Enhanced existing tools:

- `ecle_find_by_table` — also returns columns, config connections, domain fields
- `ecle_service_io` — also returns database name, config params
- `ecle_impact` — traverses cross-tier edges (changing a column affects code + config)

### New tool:

- `ecle_trace_data_flow` — full chain: service → fields → tables → columns → code → config → database

## Platform Repo Integration (SPEC-043)

The cross-tier linker is **platform-aware**. When linking, it always includes `__platform__` data:

- DDL schemas uploaded to `__platform__` → linked to code in ANY repo that touches those tables
- Config in `__platform__` → linked to databases used by ANY repo
- Domain fields in `__platform__` → linked to columns in ANY repo's DDL
- Documents in `__platform__` → cross-references found against ALL repos' entities

This means: upload Tuxedo domain XMLs to `__platform__`, upload DDL to `__platform__`, and every repo's code automatically gets linked to those definitions. The picture builds across repos without duplicating data.

```
__platform__ repo:
  ├── domain_defs/     (5,056 Tuxedo field definitions)
  ├── db_schemas/      (DDL for shared databases)
  └── env_configs/     (shared environment configs)
      │
      └──→ cross_tier_edges link to:
           ├── billing-service code (uses OPERID, AMOUNT)
           ├── payment-service code (uses ACCTNO, AMOUNT)
           └── reporting-service code (reads all tables)
```

## When Cross-Tier Linking Runs

**Two modes: materialized on ingest + real-time on query.**

### On ingest (materialized cache)

After EVERY onboard job completes (any content type, any repo including `__platform__`), the linker materializes edges into `cross_tier_edges` table:

```python
# In job_queue.py — runs after post-processing, before queue.complete():
from ecle.ingestion.cross_tier_linker import CrossTierLinker
linker = CrossTierLinker(db)
linker.materialize_for_repo(repo_id)
```

`materialize_for_repo()` runs three detection passes:
1. **Config → Database**: parse connection strings, store `CONFIG_DB_CONNECTION` edges
2. **Fields → Columns**: match domain field names to db_columns, store `FIELD_MAPS_COLUMN` edges
3. **Code → Tables**: link file_tables to table names, store `CODE_READS_TABLE` edges

This runs for ALL job types: code, facts, config, documents, data, data-sql.

### On query (real-time trace)

When a user or agent asks `ecle_trace("UNRATED_CDRS")`, the linker:
1. Reads materialized edges from `cross_tier_edges` (fast, pre-computed)
2. ALSO runs real-time queries for anything not yet materialized (e.g., document mentions via name search)
3. Merges both into the response

This means: **fast queries from cache, always fresh after each ingest, no stale gaps.**

### Why both?

| Approach | Pro | Con |
|----------|-----|-----|
| Ingest-only | Fast queries | New data not visible until next ingest |
| Query-only | Always fresh | Slow at scale (50K tables × 100 repos) |
| **Both** | **Fast + fresh** | Slightly more code |

This means uploading a DDL schema automatically links to existing code. Uploading config automatically links to existing schemas. The picture builds incrementally.

## Example Query: "Tell me everything about UNRATED_CDRS"

```
Table: UNRATED_CDRS
  Database: BILLINGDB (from config: db.url in application.properties)
  
  Columns (from DDL):
    CDR_ID    NUMBER       PK
    SUB_ID    NUMBER       FK → SUBSCRIBERS.SUB_ID
    AMOUNT    DECIMAL(10,2)
    BILL_DATE DATE
    STATUS    VARCHAR(20)
  
  Domain Fields (from Tuxedo data):
    CDR_ID    type=long    subject=billing
    AMOUNT    type=decimal subject=billing
  
  Code Access:
    batch_rating.ppc  → READ  (SELECT CDR_ID, AMOUNT WHERE STATUS='NEW')
    charge_engine.c   → WRITE (INSERT INTO UNRATED_CDRS)
    billing_report.c  → READ  (SELECT * WHERE BILL_DATE > :start)
  
  Config:
    db.url = jdbc:oracle:thin:@billing-db:1521/BILLINGDB
    batch.pool.size = 10
    billing.retry.max = 3
  
  Services:
    svcCharge → reads AMOUNT, CDR_ID
    svcReport → reads all columns
  
  Impact: 6 files, 2 services, 1 database
```

## Implementation Status

### Phase 1: Core linker + DB tables (DONE)
- [x] `CrossTierLinker` class — 7 trace methods + auto-detect dispatcher
- [x] `trace_table()`, `trace_service()`, `trace_column()`, `trace_config_key()`
- [x] `extract_database_from_config()` — JDBC, PostgreSQL, MongoDB, MSSQL, Spring patterns
- [x] `find_code_column_usage()` — SQL column matching
- [x] `cross_tier_edges` table in both SQLite + SQLAlchemy backends
- [x] `databases` table in both backends

### Phase 2: Field matching + MCP tools (DONE)
- [x] `match_fields_to_columns()` — domain fields ↔ columns by name
- [x] `ecle_trace` MCP tool with `_api_mode` branch
- [x] `GET /api/trace` REST endpoint
- [x] `ecle_find_by_table` enriched with cross-tier block
- [x] `ecle_service_io` enriched with cross-tier block
- [x] `ecle_impact` enriched with cross-tier block
- [x] 20 unit tests

### Phase 3: Materialization on ingest + platform (DONE)
- [x] `materialize_for_repo()` — runs after every onboard job
- [x] Wired into job_queue.py for ALL content types (code, facts, config, documents, data, data-sql)
- [x] Platform repo (`__platform__`) edges visible from all repos
- [x] `create_cross_tier_edge()` + `get_cross_tier_edges()` for cache reads
