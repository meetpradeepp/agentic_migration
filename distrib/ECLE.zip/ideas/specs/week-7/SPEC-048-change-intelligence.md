# SPEC-048: Change Intelligence — Learn from History, Estimate Future

**Status**: Implemented
**Owner**: Platform Architect + Migration Solution Engineer
**Depends**: SPEC-047 (Cross-Tier Linker), SPEC-043 (Platform Repo), SPEC-031 (Service Call Graph)

## Problem Statement

Enterprise teams make hundreds of changes per year. Each change touches code, schemas, configs, services. But when planning the NEXT change, they start from scratch — no institutional memory of what similar changes required.

ECLE already has all the structural knowledge. SPEC-047 connects the tiers. What's missing is the **temporal intelligence**: reading past change documents, tracing what actually changed, building effort patterns, and projecting onto future changes.

## The Vision

```
Input:  "I need to add a new field DISCOUNT_CODE to the billing system"

Output:
  Based on 23 similar field-addition changes in your change history:

  WHAT needs to change:
  ├── Database: RATED_CDRS, UNRATED_CDRS (2 tables, ~4 columns each)
  ├── Domain:   DISCOUNT_CODE field definition (Tuxedo domain XML)
  ├── Code:     batch_rating.ppc, charge_engine.c, billing_report.c (3 files, ~8 functions)
  ├── Service:  svcCharge IO update (input + output)
  ├── Config:   billing.discount.enabled (feature flag)
  └── Docs:     API spec, runbook update

  HOW LONG (based on 23 similar changes):
  ├── DDL + domain:     0.5 days  (median from history)
  ├── Code changes:     3.0 days  (scaled by function count × complexity)
  ├── Service IO:       0.5 days
  ├── Config + docs:    0.5 days
  ├── Testing:          2.0 days  (scaled by files affected)
  └── Total estimate:   6.5 days  (P50), 9 days (P80)

  SEQUENCE (dependency-ordered):
  1. DDL migration script (no code dependency)
  2. Domain field definition (parallel with DDL)
  3. Code: charge_engine.c (depends on DDL)
  4. Code: batch_rating.ppc (depends on charge_engine)
  5. Service: svcCharge IO (depends on code)
  6. Config: enable flag (last — feature gate)
  7. Test: integration + regression

  RISKS:
  - UNRATED_CDRS has 50M rows — DDL migration needs downtime window
  - charge_engine.c has complexity 47 — highest risk file
  - svcCharge is called by 14 upstream services — IO change is breaking
```

## Architecture

### Three capabilities:

```
1. LEARN    — Parse change documents, trace through knowledge graph, build patterns
2. ESTIMATE — Given a new change description, project effort from patterns
3. SEQUENCE — Order the work based on dependency graph
```

### Data Flow

```
Change History Documents
  │ (CR docs, Jira tickets, release notes, incident reports)
  │
  ▼
Document Parser + Entity Extraction
  │ Extracts: table names, file names, service names, field names
  │
  ▼
Cross-Tier Linker (SPEC-047)
  │ Traces each mention through the knowledge graph
  │ Builds: change_scope = {tables, columns, files, functions, services, configs}
  │
  ▼
Change Pattern Store
  │ Stores: change_type, scope, effort_actual, sequence, complexity
  │
  ▼
Estimation Engine
  │ Input: new change description
  │ Match: find similar past changes by scope overlap
  │ Scale: adjust by complexity, file count, table size
  │ Output: effort estimate + sequence + risks
```

## Phase 1: Change Scope Extraction

### Parse a change document and trace everything it touched

```python
class ChangeIntelligence:
    """Learn from past changes, estimate future ones."""

    def __init__(self, db, linker: CrossTierLinker):
        self.db = db
        self.linker = linker

    def analyze_change_document(self, doc_text: str, repo_id: str) -> ChangeScope:
        """Parse a change document and trace all entities through the knowledge graph.
        
        Returns a ChangeScope with every table, column, file, function, service,
        config key, and domain field that was mentioned or transitively affected.
        """

    def analyze_change_from_diff(self, file_diffs: list[FileDiff], repo_id: str) -> ChangeScope:
        """Analyze an actual code diff (git commit or PR) to build scope.
        
        More accurate than document analysis — uses actual changed files
        and traces their dependencies.
        """
```

### ChangeScope dataclass

```python
@dataclass
class ChangeScope:
    """Everything a change touches across all tiers."""
    
    # Direct mentions (from document or diff)
    tables: list[TableChange]       # table name, operation (ADD_COLUMN, MODIFY, etc.)
    columns: list[ColumnChange]     # table.column, change type
    files: list[FileChange]         # file_id, functions modified, complexity
    services: list[ServiceChange]   # service name, IO changes
    configs: list[ConfigChange]     # config key, old value, new value
    fields: list[FieldChange]       # domain field name, change type
    
    # Transitive impact (from knowledge graph traversal)
    impacted_files: list[str]       # files affected by edge traversal
    impacted_services: list[str]    # services affected transitively
    
    # Metadata
    change_type: str                # "add_field", "modify_table", "new_service", etc.
    complexity_score: float         # weighted sum of all changes
    risk_factors: list[str]         # high-complexity files, breaking IO changes, large tables
```

## Phase 2: Pattern Learning

### Store change patterns from analyzed history

```python
    def learn_from_history(self, documents: list[str], repo_id: str) -> list[ChangePattern]:
        """Analyze multiple change documents and build patterns.
        
        For each document:
          1. Extract scope (tables, files, services, etc.)
          2. Classify change type (add_field, modify_service, new_feature, etc.)
          3. Extract actual effort if mentioned (days, hours, sprint points)
          4. Store as a ChangePattern for future estimation
        """
```

### ChangePattern storage

```sql
CREATE TABLE IF NOT EXISTS change_patterns (
    id TEXT PRIMARY KEY,
    change_type TEXT NOT NULL,           -- add_field, modify_table, new_service, refactor, etc.
    source_document TEXT,                -- which document this was learned from
    tables_count INTEGER,
    columns_count INTEGER,
    files_count INTEGER,
    functions_count INTEGER,
    services_count INTEGER,
    configs_count INTEGER,
    complexity_score REAL,
    effort_days REAL,                    -- actual effort (if known from document)
    sequence_json TEXT,                  -- ordered list of change steps
    scope_json TEXT,                     -- full ChangeScope as JSON
    repo_id TEXT NOT NULL,
    created_at TEXT NOT NULL
);
```

## Phase 3: Estimation Engine

### Given a new change, estimate effort from patterns

```python
    def estimate_change(self, description: str, repo_id: str) -> ChangeEstimate:
        """Estimate effort for a new change based on historical patterns.
        
        1. Parse description → extract mentioned entities
        2. Trace through knowledge graph → build projected scope
        3. Find similar past changes by scope overlap (Jaccard on entity sets)
        4. Scale effort by: complexity ratio, file count ratio, table size
        5. Return estimate with confidence interval
        """
```

### ChangeEstimate output

```python
@dataclass
class ChangeEstimate:
    scope: ChangeScope                          # what needs to change
    
    effort: EffortBreakdown                     # time estimates per category
    sequence: list[SequenceStep]                # dependency-ordered steps
    risks: list[Risk]                           # high-risk items
    
    similar_changes: list[ChangePattern]        # past changes used as basis
    confidence: float                           # 0-1, based on pattern match quality
    
@dataclass
class EffortBreakdown:
    ddl_days: float
    code_days: float
    service_days: float
    config_days: float
    testing_days: float
    total_days_p50: float                       # median estimate
    total_days_p80: float                       # conservative estimate

@dataclass
class SequenceStep:
    order: int
    category: str                               # ddl, domain, code, service, config, test
    description: str
    files: list[str]
    depends_on: list[int]                       # step numbers this depends on
    estimated_days: float
    risk_level: str                             # low, medium, high
```

## Phase 4: MCP Tool

### `ecle_estimate_change` — the flagship tool

```
Input:  "Add DISCOUNT_CODE field to billing"
Output: Full ChangeEstimate as structured text

Input:  "What would it take to add a new payment method?"
Output: Scope analysis + effort estimate + sequence + risks
```

This is the tool that makes ECLE worth deploying. Every other tool feeds into this.

## On-Demand, Not On-Ingest

This is NOT a pipeline that runs on every upload. The data is already in the knowledge graph from ingestion (code facts, DDL tables, config keys, domain fields, documents). The intelligence happens **at query time**:

```
User asks: "What would it take to add DISCOUNT_CODE to billing?"
  │
  ├── ECLE searches knowledge graph in real-time:
  │   ├── Find tables matching "billing" → RATED_CDRS, UNRATED_CDRS
  │   ├── Find columns in those tables → trace schema
  │   ├── Find code files that touch those tables → file_tables
  │   ├── Find services that call those functions → service_function_map
  │   ├── Find config that connects to those databases → config entries
  │   ├── Find documents mentioning similar past changes → vector search
  │   └── Aggregate into ChangeScope
  │
  └── No pre-computation needed — all data already indexed
```

The only thing that runs at upload time is what already runs: facts loading, edge computation, embedding. The cross-tier tracing and change estimation are pure query-time operations against existing indexes.

## How It Builds Over Time

```
Day 1:   Upload code → knowledge graph has structure
Day 2:   Upload DDL → knowledge graph has schemas
Day 3:   Upload config → knowledge graph has connections
Day 4:   Upload domain defs → knowledge graph has field definitions
Day 5:   Upload change history docs → knowledge graph has patterns
Day 6:   Ask "estimate adding X" → ECLE traces real-time, no pre-computation
```

## Grounding Contract — Zero Hallucination

Every claim in a change estimate MUST cite structural evidence:

```
GROUNDED (OK):
  "RATED_CDRS will need a new column"
  Evidence: 3 code files write to RATED_CDRS (file_tables, operation=WRITE)
  Evidence: similar field-addition CR-2024-1847 added column to RATED_CDRS

NOT GROUNDED (rejected):
  "This change will take 5 days"
  → Only allowed if based on similar past changes with known effort
  → If no similar patterns exist: "Insufficient history to estimate effort"

GAPS ARE EXPLICIT:
  "Config impact: UNKNOWN — no config files found referencing BILLINGDB"
  "Domain field mapping: GAP — no Tuxedo domain data uploaded for this repo"
  "Effort estimate: LOW CONFIDENCE — only 2 similar changes in history"
```

The FACT quality standard applies:
- **Fast** — real-time trace, no pre-computation
- **Accurate** — every connection grounded in structural evidence
- **Complete** — gaps stated explicitly, never filled with guesses
- **Timely** — uses latest ingested data, not stale snapshots

If the data isn't connected enough to answer, ECLE says exactly what's missing:
```
"To estimate this change I need:
  ✅ Code structure (uploaded)
  ✅ Table definitions (uploaded as DDL)
  ❌ Config files (not uploaded — cannot determine database connections)
  ❌ Domain field definitions (not uploaded — cannot map fields to columns)
  ❌ Change history (no past CR documents uploaded — cannot estimate effort)
  
  Upload the missing data types to improve the estimate."
```

## Platform Repo Impact

Change history documents uploaded to `__platform__` are patterns that apply to ALL repos. A field-addition pattern learned from billing-service helps estimate field additions in payment-service.

## Implementation Phases

### Phase 1: Change scope extraction
- [ ] `ChangeIntelligence` class
- [ ] `analyze_change_document()` — parse + trace
- [ ] `ChangeScope` dataclass
- [ ] Integration with CrossTierLinker (SPEC-047)

### Phase 2: Pattern learning
- [ ] `learn_from_history()` — batch document analysis
- [ ] `change_patterns` table
- [ ] Change type classification (heuristic, not LLM)

### Phase 3: Estimation engine
- [ ] `estimate_change()` — scope projection + effort scaling
- [ ] Similarity matching (Jaccard on entity sets)
- [ ] Effort scaling formulas
- [ ] Sequence generation from topology edges

### Phase 4: MCP tool + UI
- [ ] `ecle_estimate_change` MCP tool
- [ ] UI page: "Estimate Change" with description input
- [ ] History view: past changes with actual vs estimated
