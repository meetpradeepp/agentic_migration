# SPEC-049: Two-Phase Deep Enhancement — Enhance, Don't Regenerate

**Status**: Implemented
**Owner**: CPG Pipeline Engineer
**Related**: SPEC-044 (ECLE workflow), SPEC-045 (AMF parser support), ADR-030
**Bug**: BUG-001 (deep phase wasted time re-extracting unchanged files)

## Problem Statement

The two-phase extraction workflow had a flaw: the `deep` phase completely regenerated facts that the `structural` phase already produced. This wasted time and provided no incremental value.

```
Before (broken):
  Phase 1 (structural): TreeSitter → 69 .facts.json files (fast, ~2m)
  Phase 2 (deep):       Joern → 69 .facts.json files (slow, ~21m)
                         Facts loader: "69 skipped" (same content hash)
                         Result: 21 minutes wasted

After (fixed):
  Phase 1 (structural): TreeSitter → 69 .facts.json (structs, macros, names)
  Phase 2 (deep):       Joern → enhanced facts merged with structural
                         merge_facts.py: keeps structs + adds types/dataflow
                         Facts loader: "69 updated" (different hash = enhanced)
                         Result: richer facts, no wasted re-extraction
```

## What Each Extractor Produces

| Fact Type | TreeSitter (structural) | Joern (deep) | Merge Strategy |
|-----------|:---:|:---:|:---:|
| Function names | Yes | Yes | Keep either (same) |
| Function complexity | Basic (nesting) | Full (cyclomatic) | **Replace** with Joern |
| Function parameters | Names only | Names + types | **Replace** with Joern |
| Local variables | No | Yes | **Add** from Joern |
| SQL statements | Basic (string) | Full (classified) | **Replace** with Joern |
| Table operations | Partial | Full (READ/WRITE) | **Replace** with Joern |
| Dependencies | Yes | Yes | **Merge** (union) |
| Call graph | Static (name) | Resolved (types) | **Replace** with Joern |
| Struct definitions | Yes | No | **Keep** TreeSitter |
| Macro definitions | Yes (SPEC-045 v1.7.x) | No | **Keep** TreeSitter |
| Typedefs | Yes (SPEC-045 v1.7.x) | No | **Keep** TreeSitter |
| Preprocessor branches | Yes (SPEC-045 v1.7.x) | No | **Keep** TreeSitter |
| Data flow edges | No | Yes | **Add** from Joern |
| Control flow edges | No | Yes | **Add** from Joern |
| Comments | File-read | CPG-extracted | **Replace** with Joern |
| Execution sequence | Basic | With data flow | **Replace** with Joern |

> **v1.7.x merge implementation note**: the merge logic in [`merge_facts.py`](../../AMF/stages/cpg/merge_facts.py) was rewritten as a *dynamic union* in v1.7.2 — every key from either side is preserved, dicts merge field-wise, lists dedup by identity (`id` > `(name, line, ...)` > content fingerprint). New top-level fields like `macros`, `typedefs`, `preprocessor_branches` are picked up automatically without touching the merge code; the table above documents the *intent*, not a hardcoded set of fields.

## Implementation

### Flow — Two-directory merge

Structural and deep facts live in **separate directories**. No renames, no temp files.

```
ECLE job_queue.py (structural job completes)
  │
  ├── Facts loader copies structural facts to artifact store:
  │     artifacts/{repo}/import/facts/*.facts.json
  │
  └── Auto-submits deep job with:
      options.structural_facts_dir = artifacts/{repo}/import/facts/
      (artifact store copy — NOT the workspace joern_exports/facts/)

ECLE cpg/client.py (deep job runs)
  │
  └── Sets env var: STRUCTURAL_FACTS_DIR=artifacts/{repo}/import/facts/
      Calls AMF: run.py --phase deep

AMF run.py (deep extraction)
  │
  ├── Validates: STRUCTURAL_FACTS_DIR ≠ JOERN_FACTS (aborts merge if same)
  ├── Joern extractor → writes foo.facts.json to joern_exports/facts/
  ├── Reads structural from STRUCTURAL_FACTS_DIR/foo.facts.json (artifact store)
  ├── merge_facts(structural, deep) → overwrites joern_exports/facts/foo.facts.json
  │
  └── Output: .facts.json with _extraction_tier="enhanced"

ECLE facts_loader.py (deep job loads facts)
  │
  ├── Hash differs from structural (merged content is richer)
  ├── Status: "updated" (supersedes structural version)
  └── extraction_tier: "enhanced" stored in file_facts
```

**Key invariant:** `STRUCTURAL_FACTS_DIR` (artifact store: `facts/`) and `JOERN_FACTS`
(workspace: `joern_exports/facts/`) are ALWAYS different directories. `run.py` validates
this at startup and disables merge if they resolve to the same path.

### Files Changed

**ECLE side:**

| File | Change |
|------|--------|
| `src/ecle/ingestion/job_queue.py` | Deep job includes `structural_facts_dir` in options |
| `src/ecle/cpg/client.py` | Accepts `structural_facts_dir` param, sets `STRUCTURAL_FACTS_DIR` env var |
| `src/ecle/ingestion/facts_loader.py` | No changes needed — `extraction_tier` already read from facts JSON |

**AMF side:**

| File | Change |
|------|--------|
| `AMF/stages/cpg/run.py` | Reads `STRUCTURAL_FACTS_DIR` env var. After Joern extraction, renames output to `*.deep.facts.json`, merges with structural, deletes intermediate. Both per-file and project-mode paths. |
| `AMF/stages/cpg/merge_facts.py` | **NEW** — Python script that merges two facts files. Keeps TreeSitter structs/macros, replaces with Joern types/complexity/data flow. |

### merge_facts.py Strategy

```python
def merge_facts(structural: dict, deep: dict) -> dict:
    merged = dict(structural)  # Start with structural as base
    merged["_extraction_tier"] = "enhanced"

    # Functions: keep structural, overlay deep types + complexity
    for each function:
        if in both: keep structural base + replace complexity/types from deep
        if only structural: keep (TreeSitter found it, Joern missed it)
        if only deep: add (Joern found it, TreeSitter missed it)

    # SQL: replace with deep (better classification)
    # Struct defs: keep structural (Joern doesn't extract)
    # Dependencies: merge (union)
    # Execution sequence: replace with deep (has data flow)
    # Comments: replace with deep (CPG-extracted)
```

### Environment Variables

| Variable | Set By | Read By | Purpose |
|----------|--------|---------|---------|
| `STRUCTURAL_FACTS_DIR` | ECLE `cpg/client.py` | AMF `run.py` | Directory containing structural .facts.json files |
| `JOERN_EXISTING_FACTS` | AMF `run.py` (per file) | AMF `_extract_facts()` | Path to specific structural facts file for this source file |

### How Facts Loader Handles It

No special merge logic in the loader. The merge happens on the AMF side:

1. Joern extracts deep facts → `joern_exports/facts/{file}.facts.json` (overwrites structural there)
2. `run.py` reads structural from `STRUCTURAL_FACTS_DIR/{file}.facts.json` (artifact store copy — untouched)
3. `merge_facts(structural, deep)` → writes merged back to `joern_exports/facts/{file}.facts.json`
4. Merged facts have different `content_hash` (more content = different hash)
5. Facts loader sees different hash → treats as "updated" → supersedes structural version
6. `extraction_tier` field set to "enhanced" in the merged JSON → stored in `file_facts.extraction_tier`

### Same-directory validation

`run.py` validates at startup that `STRUCTURAL_FACTS_DIR` and `JOERN_FACTS` resolve to different
directories. If they're the same, the merge is disabled with an error message — Joern would overwrite
structural facts before the merge could read them. This was the root cause of the "69 skipped" bug.

No `*.deep.facts.json` intermediate files are created. No glob filters needed. No orphan cleanup.
The two-directory approach is inherently safe — each directory serves one purpose.

## Future Enhancements (Not Implemented)

### Phase 3: Enhancement manifest
Per-language configuration of what deep should enhance vs skip:

```yaml
# AMF/stages/languages/c/manifest.yaml
deep_extraction:
  enhance: [complexity, function_parameters, local_variables, sql_classification, data_flow_edges]
  preserve: [struct_definitions, macro_definitions]
```

### Decision engine
Before running deep, check if it would add value:
- If structural already has types (e.g., Java with full classpath) → skip deep
- If structural has structs but no types (C/Pro*C) → run deep for types
- If file has 0 functions → skip deep

### Metrics
After merge, report what deep actually added:
```
Deep enhancement: +47 type resolutions, +12 data flow edges, +3 complexity upgrades
```

## v1.3 Bug Fixes

### BUG-003: Source cleanup on job failure
`_job_succeeded` flag added to `job_queue.py`. Temp directories only cleaned on success. Failed jobs preserve source for retry.

### BUG-004: Deep phase source preservation  
`_deep_job_submitted` flag added. When structural job submits a deep job, it defers source cleanup via `cleanup_source: True` option. Deep job inherits cleanup responsibility.
