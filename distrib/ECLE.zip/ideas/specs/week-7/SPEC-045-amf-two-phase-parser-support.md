# SPEC-045: AMF Two-Phase Parser Support

**Status**: Implemented
**Owner**: CPG Pipeline Engineer / Backend Team
**ADR**: ADR-030 (Two-Phase CPG Extraction)
**Related**: SPEC-044 (ECLE workflow side), SPEC-039 (Java project-mode)
**Files**:
  - `AMF/stages/cpg/run.py` — `--phase` CLI argument, parser routing
  - `AMF/stages/cpg/parsers/treesitter/` — NEW TreeSitterParser plugin
  - `AMF/stages/languages/*/manifest.yaml` — `fast_extraction` section
  - `AMF/stages/languages/*/fast_extractor.py` — NEW per-language Tree-sitter extractors

## Problem Statement

AMF's CPG pipeline (`run.py`) always uses Joern for extraction. For 3,000 files this takes ~31 hours — 84% of which is JVM startup + Joern parsing. ECLE needs a fast structural extraction mode using Tree-sitter (<100ms/file) alongside the existing Joern deep extraction.

**This spec covers the AMF-side changes only.** ECLE's job lifecycle, DB schema, and UI changes are in SPEC-044.

## Architecture

### The `--phase` Argument

`run.py` accepts a new CLI argument that controls which parser is selected per language:

```
python stages/cpg/run.py --phase structural    # Tree-sitter (fast)
python stages/cpg/run.py --phase deep           # Joern (existing)
python stages/cpg/run.py                        # default: deep (backward compat)
```

### Parser Selection Logic

```
run.py --phase structural:
  For each file:
    1. Read language manifest
    2. Check manifest.fast_extraction.enabled
    3. If True:  parser_id = manifest.fast_extraction.parser_id  ("treesitter")
    4. If False: parser_id = manifest.parser.parser_id           (existing: "proc", "powerscript")
    5. ParserRegistry.get_parser(parser_id)
    6. parser.parse_file() → .facts.json

run.py --phase deep:
    (Existing behavior — parser_id = manifest.parser.parser_id, always Joern or custom)
```

**Languages without Tree-sitter grammars:** Pro\*C and PowerBuilder have no native Tree-sitter grammar. However:

- **Pro\*C** gets fast extraction via a two-step approach: the existing sanitizer (`sanitizer.py`) converts `EXEC SQL` blocks to `__JOERN_SQL_WRAPPER("SQL text", &host_vars)` calls — valid C. Then `tree-sitter-c` parses the sanitized output. A Pro\*C-specific `fast_extractor.py` recognizes the `__JOERN_SQL_WRAPPER` pattern to extract SQL statements, tables, and host variables. **Result: zero JVM, 100% function and SQL match vs Joern baseline.** This works because `run.py` sanitizes files BEFORE calling the parser — the TreeSitterParser receives clean C, not raw `.ppc`.

- **PowerBuilder** has no fast path. Phase structural falls back to the existing `powerscript` parser (PowerScript2CPG JAR — requires JVM). This is acceptable: PowerBuilder files are typically a small fraction of enterprise codebases, and the PowerScript parser is already per-file.

### How TreeSitterParser Differs From JoernParser

| Aspect | JoernParser | TreeSitterParser |
|--------|-------------|------------------|
| Input | Source file | Source file |
| Output | `.cpg.bin` → `joern --script extractor.sc` → `.facts.json` | `.facts.json` directly (no intermediate) |
| Process | 2 JVM starts per file (parse + extract) | 1 Python call (tree-sitter + fast_extractor.py) |
| Speed | 30-60s/file | <100ms/file |
| Dependencies | joern-cli on PATH | `tree-sitter` Python package + language grammars |
| Per-file | Varies (Java needs project-mode) | Always per-file |

## Interface Changes

### 1. run.py — CLI Argument

Add to the argument parsing section at the top of `run.py`:

```python
import argparse

def parse_args():
    parser = argparse.ArgumentParser(description="AMF CPG Extraction Pipeline")
    parser.add_argument(
        "--phase",
        choices=["structural", "deep"],
        default="deep",
        help="Extraction phase: structural (Tree-sitter, fast) or deep (Joern, full CPG)",
    )
    return parser.parse_args()
```

**Note:** `run.py` currently uses environment variables and positional logic, not argparse. The `--phase` arg must be added without breaking existing invocation patterns. If `run.py` is called without `--phase`, it defaults to `"deep"` — identical to current behavior.

### 2. run.py — Parser Selection in File Processing Loop

In the per-file processing function (`_process_single_file_worker` and the main orchestrator loop), add phase-aware parser selection:

```python
# Current code (simplified):
parser_id = language.get_parser_id()   # always returns manifest.parser.parser_id
parser = parser_registry.get_parser(parser_id)

# New code:
if phase == "structural":
    fast_config = language.manifest.get("fast_extraction", {})
    if fast_config.get("enabled", False):
        parser_id = fast_config["parser_id"]
    else:
        parser_id = language.get_parser_id()   # fallback to existing parser
else:
    parser_id = language.get_parser_id()        # deep always uses existing parser

parser = parser_registry.get_parser(parser_id)
```

### 3. Language Manifests — fast_extraction Section

Add to each language that has a Tree-sitter grammar:

```yaml
# c/manifest.yaml
fast_extraction:
  enabled: true
  parser_id: "treesitter"
  grammar: "tree-sitter-c"
  extractor: "fast_extractor.py"

# java/manifest.yaml
fast_extraction:
  enabled: true
  parser_id: "treesitter"
  grammar: "tree-sitter-java"
  extractor: "fast_extractor.py"

# python/manifest.yaml
fast_extraction:
  enabled: true
  parser_id: "treesitter"
  grammar: "tree-sitter-python"
  extractor: "fast_extractor.py"

# cpp/manifest.yaml
fast_extraction:
  enabled: true
  parser_id: "treesitter"
  grammar: "tree-sitter-cpp"
  extractor: "fast_extractor.py"

# go/manifest.yaml
fast_extraction:
  enabled: true
  parser_id: "treesitter"
  grammar: "tree-sitter-go"
  extractor: "fast_extractor.py"

# javascript/manifest.yaml
fast_extraction:
  enabled: true
  parser_id: "treesitter"
  grammar: "tree-sitter-javascript"
  extractor: "fast_extractor.py"

# csharp/manifest.yaml
fast_extraction:
  enabled: true
  parser_id: "treesitter"
  grammar: "tree-sitter-c-sharp"
  extractor: "fast_extractor.py"

# proc/manifest.yaml — uses sanitizer + tree-sitter-c (no native grammar needed)
fast_extraction:
  enabled: true
  parser_id: "treesitter"
  grammar: "tree-sitter-c"           # parses SANITIZED output (.ppc → .c by sanitizer.py)
  extractor: "fast_extractor.py"     # Pro*C-specific: extracts SQL from __JOERN_SQL_WRAPPER calls

# powerbuilder/manifest.yaml — NO fast_extraction (no Tree-sitter grammar, no workaround)
# Falls back to existing powerscript parser (JVM) in structural phase
```

### 4. TreeSitterParser Plugin

New parser plugin at `AMF/stages/cpg/parsers/treesitter/`:

```
parsers/treesitter/
  ├── manifest.yaml      # parser plugin manifest
  ├── __init__.py
  └── parser.py          # TreeSitterParser class
```

**parsers/treesitter/manifest.yaml:**
```yaml
metadata:
  parser_id: "treesitter"
  name: "Tree-sitter Structural Parser"
  version: "1.0"

capabilities:
  supported_languages:
    - "c"
    - "cpp"
    - "java"
    - "python"
    - "go"
    - "javascript"
    - "csharp"
  output_formats:
    - "facts-json"

interface:
  type: "library"
  runtime: "python"
```

**parsers/treesitter/parser.py:**

```python
"""
Tree-sitter structural parser — produces .facts.json directly from AST.

No intermediate .cpg.bin. No JVM. Per-file, <100ms.
"""
from pathlib import Path
from typing import List, Optional
import json

from parsers.base_parser import BaseParser, ParseResult


class TreeSitterParser(BaseParser):
    """Fast structural parser using Tree-sitter."""

    def __init__(self, manifest, parser_dir):
        super().__init__(manifest, parser_dir)
        self._ts = None          # lazy-loaded tree_sitter module
        self._languages = {}     # grammar_name → Language object cache

    def is_available(self) -> bool:
        """Check if tree-sitter Python package is installed."""
        try:
            import tree_sitter
            return True
        except ImportError:
            return False

    def parse_file(
        self, input_file: Path, output_file: Path, args: Optional[List[str]] = None
    ) -> ParseResult:
        """Parse source file → .facts.json (no .cpg.bin intermediate).

        Args:
            input_file: sanitized source file
            output_file: expected .cpg.bin path (ignored — we write .facts.json instead)
            args: [grammar_name, extractor_path, language_dir]
                  Passed by run.py from manifest.fast_extraction config.

        Returns:
            ParseResult with facts_file set (cpg_file is None).
        """
        if not args or len(args) < 3:
            return ParseResult(
                success=False, cpg_file=None,
                errors=["TreeSitterParser requires args: [grammar, extractor_path, language_dir]"],
            )

        grammar_name = args[0]       # e.g. "tree-sitter-java"
        extractor_path = Path(args[1])  # e.g. languages/java/fast_extractor.py
        language_dir = Path(args[2])    # e.g. languages/java/

        # Determine facts output path (parallel to .cpg.bin convention)
        facts_dir = output_file.parent.parent / "facts"
        facts_dir.mkdir(parents=True, exist_ok=True)
        base_name = output_file.stem.replace(".cpg", "")
        facts_file = facts_dir / f"{base_name}.facts.json"

        try:
            # Step 1: Parse with Tree-sitter
            tree, source_bytes = self._parse_tree(input_file, grammar_name)

            # Step 2: Check error node ratio
            error_count, total_count = self._count_errors(tree.root_node)
            error_ratio = error_count / max(total_count, 1)

            if error_ratio > 0.05:
                return ParseResult(
                    success=False, cpg_file=None,
                    errors=[
                        f"Tree-sitter error ratio {error_ratio:.1%} exceeds 5% threshold "
                        f"({error_count}/{total_count} nodes). File needs Joern."
                    ],
                )

            # Step 3: Run language-specific extractor
            facts = self._run_extractor(
                extractor_path, tree, source_bytes, input_file, language_dir
            )

            # Step 4: Write .facts.json
            facts_file.write_text(
                json.dumps(facts, indent=2, ensure_ascii=False),
                encoding="utf-8",
            )

            return ParseResult(
                success=True,
                cpg_file=None,       # no .cpg.bin produced
                facts_file=facts_file,
            )

        except Exception as e:
            return ParseResult(
                success=False, cpg_file=None,
                errors=[f"Tree-sitter extraction failed: {e}"],
            )

    def _parse_tree(self, file_path, grammar_name):
        """Parse file with Tree-sitter, return (tree, source_bytes)."""
        import tree_sitter
        import tree_sitter_languages  # grammar package

        if grammar_name not in self._languages:
            # Map grammar name to tree-sitter-languages identifier
            lang_id = grammar_name.replace("tree-sitter-", "").replace("-", "_")
            self._languages[grammar_name] = tree_sitter_languages.get_language(lang_id)

        if self._ts is None:
            self._ts = tree_sitter.Parser()

        self._ts.language = self._languages[grammar_name]

        source_bytes = file_path.read_bytes()
        tree = self._ts.parse(source_bytes)
        return tree, source_bytes

    def _count_errors(self, node):
        """Count ERROR and MISSING nodes in AST."""
        error_count = 0
        total_count = 0

        def _walk(n):
            nonlocal error_count, total_count
            total_count += 1
            if n.type == "ERROR" or n.is_missing:
                error_count += 1
            for child in n.children:
                _walk(child)

        _walk(node)
        return error_count, total_count

    def _run_extractor(self, extractor_path, tree, source_bytes, file_path, language_dir):
        """Load and run the language-specific fast_extractor.py."""
        import importlib.util

        spec = importlib.util.spec_from_file_location("fast_extractor", str(extractor_path))
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)

        return mod.extract(tree, source_bytes, file_path, language_dir)
```

### 5. fast_extractor.py Contract

Each language provides a `fast_extractor.py` in its language directory. It must implement:

```python
def extract(tree, source_bytes: bytes, file_path: Path, language_dir: Path) -> dict:
    """Extract CanonicalFactFileBase from Tree-sitter AST.

    Args:
        tree: tree_sitter.Tree — parsed AST
        source_bytes: raw file content as bytes
        file_path: path to source file (for filename)
        language_dir: language plugin directory (for supplementary data)

    Returns:
        dict matching CanonicalFactFileBase schema.
        Must include _extraction_tier: "structural".
    """
```

**Required output fields** (CanonicalFactFileBase):

```json
{
  "filename": "BillingProcessor.java",
  "language": "java",
  "_extraction_tier": "structural",

  "functions": [
    {
      "name": "calculateFee",
      "returnType": "double",
      "complexity": 4,
      "args": ["amount", "rate"],
      "variables": [],
      "start_line": 15,
      "end_line": 42,
      "return_statements": []
    }
  ],

  "sql_statements": [
    {
      "line": 28,
      "enclosing_method": "calculateFee",
      "category": "READ",
      "sql_text": "SELECT rate FROM fee_schedule WHERE type = ?",
      "tables": ["fee_schedule"],
      "host_vars": []
    }
  ],

  "dependencies": [
    {"name": "calculateTax", "line": 35}
  ],

  "comments": [
    {"text": "// Apply late penalty", "line": 30, "column": 0, "file": "BillingProcessor.java", "contains_sql": false}
  ],

  "literals": [
    {"value": "100", "type": "number", "line": 22}
  ],

  "execution_sequence": [],
  "global_defs": [],
  "struct_definitions": [],
  "includes": [],
  "framework_calls": [],

  "data_flow_edges": [],
  "control_flow_edges": []
}
```

**Rules for fast_extractor.py:**

1. `_extraction_tier` MUST be `"structural"` — this tells ECLE the facts came from Tree-sitter
2. `data_flow_edges` and `control_flow_edges` MUST be empty `[]` — Tree-sitter cannot produce these
3. `functions[].complexity` = count of branching nodes (`if`, `for`, `while`, `switch`, `case`, `catch`, `&&`, `||`) + 1
4. `sql_statements` extracted by scanning string literals for SQL keywords (`SELECT`, `INSERT`, `UPDATE`, `DELETE`, `CREATE`, `ALTER`, `DROP`, `COMMIT`, `ROLLBACK`)
5. `dependencies` are syntactic call names — NOT type-resolved. `foo.bar()` → `{"name": "bar", "line": 28}`
6. `includes` extracted from `#include` directives (C/C++) or `import` statements (Java/Python/Go)
7. All lists MUST be sorted deterministically (by name or line number) for consistent hashing

### 6. C Language fast_extractor.py (Reference Implementation)

The C extractor is the reference implementation — start here, then adapt for other languages.

```
AMF/stages/languages/c/fast_extractor.py
```

**What it extracts from Tree-sitter C AST:**

| CanonicalFactFileBase Field | Tree-sitter Node Types | Notes |
|----------------------------|------------------------|-------|
| `functions[]` | `function_definition` | name from `function_declarator`, returnType from first child, complexity from branch count |
| `sql_statements[]` | `string_literal` containing SQL keywords | Scan all string literals, classify READ/WRITE/TRANSACTION |
| `dependencies[]` | `call_expression` | callee name from `identifier` child |
| `comments[]` | `comment` | Both `//` and `/* */` |
| `literals[]` | `string_literal`, `number_literal` | |
| `includes[]` | `preproc_include` | Extract path from `string_literal` or `system_lib_string` child |
| `global_defs[]` | `declaration` at file scope | Variable declarations outside functions |
| `struct_definitions[]` | `struct_specifier`, `enum_specifier`, `union_specifier` | |
| `execution_sequence[]` | Ordered `call_expression` nodes per function | |
| `framework_calls[]` | Subset of call_expression matching known system calls | Optional |

### 7. Java Language fast_extractor.py

```
AMF/stages/languages/java/fast_extractor.py
```

**Java-specific extractions beyond C baseline:**

| Field | Tree-sitter Node Types | Notes |
|-------|------------------------|-------|
| `classes[]` | `class_declaration`, `interface_declaration`, `enum_declaration` | kind, name, line, implements, extends, annotations |
| `annotations[]` | `annotation`, `marker_annotation` | name, line |
| `spring_components[]` | Annotation nodes matching `@Controller`, `@Service`, etc. | Pattern match against SPRING_STEREOTYPES set |
| `jdbc_calls[]` | `method_invocation` where method name ∈ JDBC_METHODS | `executeQuery`, `prepareStatement`, etc. |

**Java does NOT need project-mode for Tree-sitter.** Tree-sitter parses each file independently (syntax only, no type resolution). This eliminates the core Java problem that SPEC-039 addressed for Joern.

### 7b. Pro\*C fast_extractor.py

```
AMF/stages/languages/proc/fast_extractor.py
```

**Key insight:** Pro\*C has no Tree-sitter grammar, but the existing `sanitizer.py` converts raw `.ppc` files to valid C by replacing `EXEC SQL ... ;` blocks with `__JOERN_SQL_WRAPPER("SQL text", &host_var)` function calls. Tree-sitter C parser handles the sanitized output with **zero error nodes**.

**Pipeline:** `raw .ppc` → `sanitizer.py` (Python, no JVM) → `clean .c` → `tree-sitter-c` → `proc/fast_extractor.py` → `.facts.json`

**Pro\*C-specific extraction beyond C baseline:**

| Field | Source | Notes |
|-------|--------|-------|
| `sql_statements[]` | `call_expression` where callee = `__JOERN_SQL_WRAPPER` | First `string_literal` arg is SQL text; `pointer_expression` args are host variables |
| `dependencies[]` | All `call_expression` EXCEPT `__JOERN_SQL_WRAPPER` | Filter out the synthetic wrapper — it's not a real function |
| `language` | Overridden to `"proc"` | C extractor would set `"c"` |

**Validated against Joern baseline** (`batch_rating.ppc`):

| Metric | Tree-sitter (sanitized) | Joern | Match |
|--------|------------------------|-------|-------|
| Functions | 8 | 8 | Exact |
| SQL statements | 11 | 11 | Exact |
| Tables extracted | RATED_CDRS, UNRATED_CDRS | RATED_CDRS, UNRATED_CDRS | Exact |
| Host variables | Captured with `&` prefix | Captured with `&` prefix | Exact |
| Error nodes | 0 | N/A | Clean parse |

### 8. Error-Node Fallback

When `TreeSitterParser._count_errors()` finds >5% error nodes, `parse_file()` returns `success=False`. The orchestrator in `run.py` must handle this gracefully:

```python
# In run.py per-file processing:
result = parser.parse_file(input_file, cpg_file, args)

if not result.success and phase == "structural":
    # Tree-sitter couldn't handle this file — fall back to existing parser
    fallback_parser_id = language.get_parser_id()  # "joern", "proc", "powerscript"
    fallback_parser = parser_registry.get_parser(fallback_parser_id)
    if fallback_parser and fallback_parser.is_available():
        result = fallback_parser.parse_file(input_file, cpg_file, language.get_parser_args())
        # This file gets full depth even in structural phase
```

Files that fall back to Joern in Phase 1 will have `_extraction_tier: "full"` — Phase 2 skips them automatically (content hash unchanged).

## run.py Integration — Detailed Changes

### Argument Parsing

`run.py` currently has no argparse. It uses environment variables (`CODE_REPO`, `PROJECT_ROOT`, etc.) and a hardcoded entry point. The `--phase` argument must be added without breaking existing invocation:

```python
# At top of run.py, after imports:
import argparse

def _parse_phase_arg():
    """Parse --phase arg. Tolerates being called without it (backward compat)."""
    parser = argparse.ArgumentParser(add_help=False)
    parser.add_argument("--phase", choices=["structural", "deep"], default="deep")
    args, _ = parser.parse_known_args()
    return args.phase

EXTRACTION_PHASE = _parse_phase_arg()
```

Using `parse_known_args()` ensures any other arguments or environment-variable-based invocation patterns still work.

### Parser Args for TreeSitterParser

When phase is structural and TreeSitterParser is selected, `run.py` passes the grammar name, extractor path, and language directory as args:

```python
if phase == "structural" and parser_id == "treesitter":
    fast_config = language.manifest.get("fast_extraction", {})
    parser_args = [
        fast_config["grammar"],                                    # "tree-sitter-java"
        str(language.language_dir / fast_config["extractor"]),     # "languages/java/fast_extractor.py"
        str(language.language_dir),                                # "languages/java/"
    ]
else:
    parser_args = language.get_parser_args()
```

### Skip Logic Compatibility

The existing 3-level skip logic (`mtime` checks for `.cpg.bin` and `.facts.json`) must work with Tree-sitter output:

- Tree-sitter does NOT produce `.cpg.bin` — skip level 1 (CPG freshness check) is irrelevant
- Tree-sitter DOES produce `.facts.json` — skip level 2 (facts freshness check) works if facts exist and are newer than source
- For Phase structural: check if `.facts.json` exists and mtime > source mtime → skip

```python
# Modified skip check for structural phase:
if phase == "structural" and not force_regenerate:
    facts_file = joern_facts / f"{flat_stem}.facts.json"
    if facts_file.exists() and input_file.exists():
        if facts_file.stat().st_mtime > input_file.stat().st_mtime:
            return {'file': str(file_path.name), 'success': True,
                    'skipped': True, 'reason': 'Structural facts up-to-date'}
```

### Project-Mode Not Used for Structural

For structural phase, ALL languages use per-file mode. Java's `parse_mode: "project"` applies only to Joern (deep phase). Tree-sitter is always per-file.

```python
# In run.py project-mode decision:
if phase == "deep" and language.get_parse_mode() == "project":
    # Batch all files for project-level Joern CPG (existing behavior)
    ...
else:
    # Per-file processing (structural always, deep for non-project languages)
    ...
```

## Dependencies

### Python Packages (AMF side)

```
tree-sitter>=0.23.0          # Core parser library
tree-sitter-languages>=1.10  # Pre-compiled grammars (66+ languages)
```

These are lightweight packages. `tree-sitter` is a C library with Python bindings (~2MB). `tree-sitter-languages` bundles pre-compiled grammars (~15MB).

**Air-gapped deployment:** Both packages have no network dependencies at runtime. Grammars are compiled into the package. Compatible with ECLE's air-gapped requirement.

### No Changes Required in Existing Parsers

- `JoernParser` — unchanged, used by deep phase
- `ProcParser` — unchanged, used by deep phase only (structural uses sanitizer + Tree-sitter)
- `PowerScriptParser` — unchanged, used by both phases for PowerBuilder (no fast path available)

## Tests

### Unit Tests

1. **TreeSitterParser.is_available()** — returns True when tree-sitter installed, False otherwise
2. **TreeSitterParser.parse_file()** — produces valid .facts.json for simple C file
3. **TreeSitterParser.parse_file()** — returns success=False when error ratio >5%
4. **Error node counting** — verify count on intentionally broken file
5. **C fast_extractor** — extract functions from C AST, verify names/lines/complexity
6. **C fast_extractor** — extract SQL from string literals
7. **C fast_extractor** — extract includes from preproc_include nodes
8. **Java fast_extractor** — extract classes, annotations, Spring components
9. **Java fast_extractor** — extract per-file (no project-mode dependency)
10. **_extraction_tier** — structural extractor sets "structural", Joern extractor defaults to absent (→ "full")
11. **Deterministic output** — same file parsed twice produces identical .facts.json (byte-identical)

### Validation Tests (Tree-sitter vs Joern)

For each language, run both extractors on the same files and compare:

1. **Function count match** — Tree-sitter and Joern find same number of functions
2. **Function names match** — identical function name sets
3. **SQL statements match** — same tables extracted, same categories
4. **Dependency count close** — Tree-sitter may find more (syntactic) than Joern (filtered)
5. **Include/import match** — identical

Use existing files from `AMF/joern-exports/facts/` as Joern baseline. Run Tree-sitter on corresponding source files and compare field-by-field.

### Performance Tests

1. **Per-file latency** — Tree-sitter parse + extract < 200ms for files up to 5,000 lines
2. **Batch throughput** — 3,000 files structural extraction < 15 minutes
3. **Memory usage** — Tree-sitter parser RSS < 50MB throughout batch

## Deliverables

| # | Component | Location | Priority | Status |
|---|-----------|----------|----------|--------|
| 1 | `--phase` CLI arg in `run.py` | `AMF/stages/cpg/run.py` | P0 | Done |
| 2 | `TreeSitterParser` plugin | `AMF/stages/cpg/parsers/treesitter/` | P0 | Done |
| 3 | C `fast_extractor.py` | `AMF/stages/languages/c/` | P0 | Done |
| 4 | C++ `fast_extractor.py` | `AMF/stages/languages/cpp/` | P0 | Done |
| 5 | Java `fast_extractor.py` | `AMF/stages/languages/java/` | P0 | Done |
| 6 | Pro\*C `fast_extractor.py` | `AMF/stages/languages/proc/` | P0 | Done — sanitizer + tree-sitter-c |
| 7 | Manifest updates (9 languages + template) | `AMF/stages/languages/*/manifest.yaml` | P0 | Done |
| 8 | Validation test suite | `AMF/tests/test_treesitter_vs_joern.py` | P0 | Done — 16 pass |
| 9 | Python `fast_extractor.py` | `AMF/stages/languages/python/` | P1 | |
| 10 | Go `fast_extractor.py` | `AMF/stages/languages/go/` | P1 | |
| 11 | JavaScript `fast_extractor.py` | `AMF/stages/languages/javascript/` | P1 | |
| 12 | C# `fast_extractor.py` | `AMF/stages/languages/csharp/` | P1 | |

**P0 deliverables (1-8) enable the full two-phase workflow for C, C++, Java, and Pro\*C — the four enterprise-critical languages.** All validated against Joern baseline output. P1 deliverables add remaining languages incrementally. PowerBuilder has no fast path — uses existing JVM parser in both phases.

## v1.3 Implementation Notes (2026-04-11)

### PowerBuilder Fast Extraction — Now Implemented

The original spec stated "PowerBuilder has no fast path." This is no longer true as of v1.3.

**Custom grammar:** `tree-sitter-powerbuilder` — built internally, shipped as `tree-sitter-powerbuilder.zip` in the AMF bundle. Install: `pip install tree-sitter-powerbuilder.zip --no-deps`.

**Manifest update:** `languages/powerbuilder/manifest.yaml` now includes:
```yaml
fast_extraction:
  enabled: true
  parser_id: "treesitter"
  grammar: "tree-sitter-powerbuilder"
  extractor: "fast_extractor.py"
```

**PB-specific extraction** (`languages/powerbuilder/fast_extractor.py`):
- `function_decl` / `function_prototype` → functions (including subroutines)
- `event_decl` / `on_block` → event handlers as functions
- `sql_statement` → embedded SQL as first-class AST node (no string matching)
- `call_stmt` → dependencies
- `variable_decl` → local variables
- `global_type_decl` → type definitions (windows, datawindows, user objects)
- DECLARE/OPEN/FETCH/CLOSE → cursor lifecycle tracking with validity check
- Host variables extracted from SQL (`:var_name` pattern)

**Validation:** 15 real PB files, 0% parse errors, 135 functions, 35 SQL statements, 220 dependencies extracted.

**Parser registry:** `parsers/treesitter/parser.py` `_GRAMMAR_PACKAGES` updated with `"tree-sitter-powerbuilder": "tree_sitter_powerbuilder"`.

### Updated deliverables

| # | Deliverable | Status |
|---|-------------|--------|
| P0-9 | PowerBuilder `fast_extractor.py` | DONE (v1.3) |
| P0-10 | `tree-sitter-powerbuilder` grammar | DONE (v1.3, custom build) |
| P0-11 | PB manifest `fast_extraction` section | DONE (v1.3) |

## Enhancement v1.7.x — Preprocessor & Typedef Coverage for C/C++/Pro\*C

**Status**: Implemented + Tested
**Owner**: CPG Pipeline Engineer
**Discovered**: 2026-05-09 — `mmUpMemo` repo, header-heavy Pro*C/C codebase
**Implemented**: 2026-05-09 — E1-E8 landed; 13 new tests + 2 facts-loader rollup tests pass
**Bug evidence**: [`operid.h`](#) defines 13 macros + 2 typedefs + an `#ifdef IDL` branch; structural extraction produces `functions: 0, struct_definitions: 0, includes: 1, comments: 1` — **the file's entire semantic content is invisible to FACT**.

### Problem Statement

The structural extractor for C / C++ / Pro\*C does not capture preprocessor or typedef facts. SPEC-049's merge table (lines 40-41) **promises** "Macro definitions: TreeSitter — Yes" but the schema has no `macros` slot and no `extract_c_macros()` function exists. Joern's deep extraction also drops these because Joern's CPG operates on the post-preprocessor AST.

For C codebases dominated by constants headers (telecom, banking, ERP — `mmUpMemo` is the canonical example), this means:

- `#define CONST 100` — invisible. Lost as a knowable constant.
- `#define MACRO(x) ...` — invisible. Lost as an abstraction the codebase relies on.
- `typedef long OPERID_C_T;` — invisible. Lost as a type-alias relationship.
- `#ifdef IDL / #else / #endif` — invisible. The reader can't tell which branch was conditionally compiled.

Files like `operid.h`, `memocd.h`, `memoid.h`, `applid.h`, `svcsts.h`, `yesnoind.h` collectively define the constant + type vocabulary of the codebase. Extracting zero facts from them means cross-file dependency resolution, capability discovery, and migration impact analysis all miss this layer entirely.

### Why This Lives in SPEC-045 (not a new spec)

This is a coverage gap in the existing structural-extraction contract — same architecture, same fast_extractor.py contract, same Tree-sitter parser plugin. We're adding three node-type traversals to the existing extractor library, not changing the two-phase model. Treating it as an enhancement keeps the contract evolution traceable in one place.

### What We Add

#### 1. Schema additions — [`stages/languages/common/schema_builder.py`](#)

Add three new fields to `empty_fact_file()`:

```python
return {
    # ... existing fields ...
    "macros": [],                      # NEW
    "typedefs": [],                    # NEW
    "preprocessor_branches": [],       # NEW (optional but recommended)
}
```

Field schemas:

**`macros[]`**
```json
{
  "name": "OPERID_C_SZ",
  "kind": "object",                    // "object" | "function" | "undef"
  "value": "4",                        // raw expansion text; null for #undef and function-style without single-line value
  "params": [],                        // ["x"] for function-style #define MACRO(x), [] for object-like
  "line": 14,
  "end_line": 14,                      // multi-line macros (with line-continuation \) span multiple lines
  "is_multiline": false,
  "is_header_guard": false,            // true for #ifndef X / #define X / ... / #endif pattern
  "enclosing_branch_id": "br_3"        // FK to preprocessor_branches[].id, null if at top level
}
```

**`typedefs[]`**
```json
{
  "name": "OPERID_C_T",
  "underlying_type": "gi_long",
  "line": 16,
  "is_function_pointer": false,
  "enclosing_branch_id": null
}
```

**`preprocessor_branches[]`** (one entry per `#if`/`#ifdef`/`#ifndef` block — captures what was conditionally compiled)
```json
{
  "id": "br_3",
  "kind": "ifdef",                     // "if" | "ifdef" | "ifndef"
  "condition": "IDL",                  // raw text; for #if, the full expression
  "start_line": 4,
  "else_line": 9,                      // null if no #else / #elif
  "end_line": 33,
  "parent_id": null                    // for nested branches
}
```

Naming convention: `enclosing_branch_id` references `preprocessor_branches[].id`. Items inside `#ifdef IDL ... #else ... #endif` carry the branch id so consumers can answer "which macros are defined when IDL is set?" without re-parsing the file.

#### 2. New extractor functions — [`stages/languages/common/c_family_extractors.py`](#)

```python
def extract_c_macros(root, source_bytes) -> list[dict]:
    """Walk preproc_def + preproc_function_def + preproc_undef nodes."""

def extract_c_typedefs(root, source_bytes) -> list[dict]:
    """Walk type_definition nodes — capture name + underlying type."""

def extract_c_preprocessor_branches(root, source_bytes) -> list[dict]:
    """Walk preproc_if / preproc_ifdef nodes — emit a branch tree.

    Implements a single AST pass that:
      - assigns stable br_N ids based on document order
      - captures condition text from the operator child
      - tracks else_line from the optional preproc_else child
      - tags nested branches via parent_id
    Returns the flat list of branches; the caller decorates macros/typedefs
    with their enclosing_branch_id by line-range lookup.
    """
```

Tree-sitter C grammar reference:
- `#define X 100` → `preproc_def` with children `(#define identifier preproc_arg)`
- `#define MACRO(x) (x*2)` → `preproc_function_def` with `preproc_params`
- `#undef X` → `preproc_call` with directive `#undef`
- `#ifdef X / #ifndef X` → `preproc_ifdef` (operator child distinguishes `#ifdef` vs `#ifndef`)
- `#if expr` → `preproc_if`
- `typedef long X;` → `type_definition`

#### 3. Wire into [`c/fast_extractor.py`](#), [`cpp/fast_extractor.py`](#), [`proc/fast_extractor.py`](#)

```python
from common.c_family_extractors import (
    # ... existing imports ...
    extract_c_macros, extract_c_typedefs, extract_c_preprocessor_branches,
)

def extract(tree, source_bytes, file_path, language_dir) -> dict:
    root = tree.root_node
    # ... existing extractions ...
    macros = extract_c_macros(root, source_bytes)
    typedefs = extract_c_typedefs(root, source_bytes)
    preprocessor_branches = extract_c_preprocessor_branches(root, source_bytes)
    # Decorate macros + typedefs with enclosing_branch_id by line lookup
    _attach_branch_ids(macros, typedefs, preprocessor_branches)

    return {
        # ... existing fields ...
        "macros": macros,
        "typedefs": typedefs,
        "preprocessor_branches": preprocessor_branches,
    }
```

Pro\*C inherits the C extractor logic — `.ppc` files post-sanitization are valid C, and the sanitizer doesn't alter `#define`/`#ifdef`/`typedef`. So all three new extractors work unchanged on sanitized Pro\*C output.

#### 4. PowerBuilder, Java, Python — out of scope

PowerBuilder, Java, Python don't have C-style preprocessor. Java's `static final int X = …;` is captured today by `global_defs`. Python's module-level constants likewise. No schema change needed for these.

#### 5. merge_facts.py — no change needed

The dynamic merge_facts already picks up new top-level keys automatically (this is exactly why we made it dynamic in v1.7.2). When deep produces no `macros` / `typedefs` (Joern still doesn't extract preprocessor), the merge keeps structural's contributions verbatim. ✓

#### 6. FACT downstream — `file_facts.macros_count` & `file_facts.typedefs_count`

Add two roll-up columns to the structured DB schema (SPEC-001) so users can query "files with macro density > N" without reading the JSON. Population is by the facts loader — same pattern as existing `functions_count`, `sql_statements_count`.

```sql
ALTER TABLE file_facts ADD COLUMN macros_count INTEGER NOT NULL DEFAULT 0;
ALTER TABLE file_facts ADD COLUMN typedefs_count INTEGER NOT NULL DEFAULT 0;
```

### Behavior Rules

1. **Header-guard detection**: a macro is `is_header_guard=true` when it's the FIRST `#define` inside an `#ifndef` branch and the branch wraps the rest of the file. Implementation walks the branch tree once to mark these — they're noise for capability discovery but worth keeping flagged so consumers can filter.

2. **Multi-line macros** (those with `\` continuation):
   - `is_multiline=true`, `end_line > line`
   - `value` field captures the full text with line continuations stripped, whitespace normalized.

3. **Function-like macros**: `kind="function"`, `params` populated. Treat the body as `value` (raw text).

4. **`#undef`**: `kind="undef"`, `value=null`. Emit so consumers can detect macros that are scoped/temporary.

5. **Conditional compilation context**:
   - Every macro/typedef inside an `#ifdef`/`#ifndef`/`#if` block carries `enclosing_branch_id`.
   - When `#else` is present, items in the else arm carry the same `enclosing_branch_id` but consumers can detect arm membership via line range vs `else_line`.

6. **Determinism**: `macros[]` and `typedefs[]` sorted by `line` (existing convention). `preprocessor_branches[]` sorted by `start_line`. Stable for content hashing.

7. **No semantic evaluation**: the extractor records facts, not interpretation. We do NOT evaluate `#if defined(X) && Y > 5` — `condition` is the raw expression text. Capability discovery downstream can interpret if needed.

### Tests

Add to [`AMF/tests/test_language_common_module.py`](#) (or new `test_preprocessor_extraction.py`):

1. **Macros — object-like**: parse a header with 5 `#define X 100` lines → 5 macros, each `kind="object"`.
2. **Macros — function-like**: `#define MAX(a,b) ((a)>(b)?(a):(b))` → `kind="function"`, `params=["a","b"]`.
3. **Macros — multi-line**: 3-line macro with `\` continuation → `is_multiline=true`, `end_line=line+2`, value continuations removed.
4. **Header guard detection**: file with `#ifndef _X_H / #define _X_H / ... / #endif` → first define has `is_header_guard=true`, others false.
5. **Typedefs**: `typedef long X; typedef struct Foo *FooP;` → 2 typedefs with correct underlying_type.
6. **Preprocessor branches**: `#ifdef IDL / x / #else / y / #endif` → 1 branch, kind=ifdef, condition="IDL", else_line correct.
7. **Nested branches**: `#ifdef A / #ifdef B / x / #endif / #endif` → 2 branches, inner has `parent_id` = outer.
8. **enclosing_branch_id attachment**: macro at line 10 inside branch spanning lines 4-33 → carries that branch id.
9. **Pro*C inheritance**: sanitized `.ppc` with `#define` outside `EXEC SQL` block → macro extracted exactly as C.
10. **Operid.h regression test**: full `operid.h` content → 13 macros, 2 typedefs, 1 branch, header guard flagged. (Use as fixture.)
11. **Determinism**: parse same file twice → byte-identical `macros`, `typedefs`, `preprocessor_branches`.
12. **FACT loader roll-up**: facts file with N macros → `file_facts.macros_count = N` after load.

### Acceptance Criteria

- [ ] `operid.h` extraction produces ≥13 macros, ≥2 typedefs, 1 preprocessor branch, header guard flagged.
- [ ] All 38 mmUpMemo files re-extracted post-fix show non-zero `macros_count` for header files (~30 of 33).
- [ ] No regression in existing tests (`functions`, `struct_definitions`, `sql_statements`, `dependencies`, `data_flow_edges` after merge).
- [ ] Merge still produces `_extraction_tier: enhanced` with macros + typedefs preserved from structural side.
- [ ] DB schema migration applies cleanly to existing repos (default 0 for older facts).
- [ ] Doc: SPEC-049's merge strategy table updated to add `macros` / `typedefs` rows so the contract is documented in both specs.

### Deliverables

| # | Component | Location | Priority |
|---|-----------|----------|----------|
| E1 | Schema fields in `empty_fact_file()` | `AMF/stages/languages/common/schema_builder.py` | P0 |
| E2 | `extract_c_macros()` | `AMF/stages/languages/common/c_family_extractors.py` | P0 |
| E3 | `extract_c_typedefs()` | `AMF/stages/languages/common/c_family_extractors.py` | P0 |
| E4 | `extract_c_preprocessor_branches()` + `_attach_branch_ids()` | `AMF/stages/languages/common/c_family_extractors.py` | P0 |
| E5 | Wire into c/cpp/proc `fast_extractor.py` | 3 files | P0 |
| E6 | `file_facts.macros_count` / `typedefs_count` columns + facts loader fill | `src/ecle/backends/structured/`, `src/ecle/ingestion/facts_loader.py` | P1 |
| E7 | Test suite (12 cases above) + `operid.h` fixture | `AMF/tests/` | P0 |
| E8 | SPEC-049 update — add `macros` / `typedefs` rows to the merge strategy table | `specs/week-7/SPEC-049-two-phase-deep-enhancement.md` | P1 |

### Out of Scope (explicitly deferred)

- **Macro expansion / semantic evaluation** — we record raw `value` text; we do NOT evaluate or expand macros. Building a full preprocessor would re-implement what `cpp` does.
- **`#include` graph from preprocessor view** — already covered by `includes[]`; conditional includes inside `#ifdef` arms get `enclosing_branch_id` for free, no new field.
- **Cross-file macro resolution** — knowing that `mmUpMemo_4.c` uses `OPERID_C_SZ` defined in `operid.h` is a downstream FACT-side join (file → uses → macro → defined-in → file). This spec captures the local facts; the join is already supported by existing `dependencies` machinery once `macros[]` exists as a target.
- **Java / Python / PowerBuilder** — different language families, no C-style preprocessor; their schemas already cover the equivalent (annotations, decorators, type declarations).

