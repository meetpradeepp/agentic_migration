# SPEC-050: Transparent Prompt Enrichment — Context Before Tools

**Status**: Implemented (Phase 1)
**Owner**: Platform Architect + MCP Tool Engineer
**ADR**: ADR-031 (Transparent Prompt Enrichment)
**Files**: `src/ecle/mcp/server.py`, `src/ecle/query/app.py`

## Problem Statement

AI agents connecting to ECLE via MCP make blind tool calls — they guess which tool to use and what parameters to pass. This leads to:
- Empty results from wrong tools
- Multiple wasted calls before finding the right data
- Questions that go unanswered despite the data existing in the knowledge graph

The knowledge graph already knows where the answers are. The agent just doesn't get that context before it starts reasoning.

## Solution: Three-Layer Enrichment

### Layer 1: MCP Instructions (Connection-Time)

Delivered once when the agent connects. Contains:
- **Rules**: Grounding contract, no guessing, state gaps
- **Tool selection guide**: "What does X do?" → ecle_file + ecle_source_read
- **Fallback chain**: ecle_service_io empty → try ecle_source_read on header
- **Known gaps**: Semantic search may fail, C struct fields not in DB
- **Response format**: Lead with facts, cite evidence, list gaps

**Implementation**: `FastMCP(instructions=...)` in `server.py`

### Layer 2: Context Resource (Per-Question)

Read automatically by the agent before each answer. The MCP server:

1. **Extracts entities** from the question using regex tokenization
2. **Matches against knowledge graph**:
   - Table names → `db.get_table_names("*")`
   - File names → `db.list_current_file_ids("*")`
   - Function/service names → `db.find_callers_of(word, "*")`
3. **Returns structured context**:
   ```json
   {
     "question": "How is paperless bill set for employee BANs?",
     "tables": [{"name": "BILLING_ACCOUNT", "accessed_by": ["par_ban_1.c"], "operations": ["READ", "WRITE"]}],
     "files": [{"file_id": "par_ban_1.c", "language": "c", "functions": 15}],
     "services": [{"name": "arSvBilPrm", "callers": [{"name": "arInCstBan", "file": "par_ban_1.c"}]}],
     "gaps": ["No DDL schema for BILLING_ACCOUNT"]
   }
   ```
4. **Agent uses this** to make precise tool calls instead of blind searches

**Implementation**: `@mcp.resource("ecle://context/{question}")` in `server.py`

**URI**: `ecle://context/{url_encoded_question}`

### Layer 3: REST API (Non-MCP Consumers)

Same enrichment for browser, CLI, or any HTTP client.

**Endpoint**: `GET /api/enrich?question=...&repo_id=*`

**Response**: Same JSON as the MCP resource

**Implementation**: `@api_router.get("/enrich")` in `app.py`

## Entity Extraction Strategy

Keyword-based extraction from the question text:
```python
words = re.findall(r"[A-Za-z_][A-Za-z0-9_]{2,}", question)
```

Matched against three indexes:
1. `get_table_names("*")` — known table names across all repos + platform
2. `list_current_file_ids("*")` — known file names
3. `find_callers_of(word, "*")` — known function/service names

**Not semantic** — exact name matching only. Fast (~10ms), deterministic, no vector DB dependency.

**Limitation**: Won't match abbreviations ("pprls" for "paperless"), synonyms, or business terms not in the code. Future: add semantic vector search as a second pass.

## Instructions Content

The MCP instructions contain:

| Section | Purpose |
|---------|---------|
| RULES | Grounding contract — never guess, state gaps |
| TOOL SELECTION GUIDE | Which tool for which question type |
| FALLBACK CHAIN | What to try when primary tool returns empty |
| KNOWN GAPS | Honest about current limitations |
| CONTEXT ENRICHMENT | "Read ecle://context/{question} before answering" |
| RESPONSE FORMAT | Lead with facts, cite evidence, list gaps |

## What Changes for the Agent

**Before (blind):**
```
User: "How is paperless bill set for employee BANs?"
Agent: ecle_search("paperless bill") → error
Agent: ecle_find_by_table("PAPERLESS") → empty
Agent: ecle_find_callers("paperless") → empty
Agent: "I couldn't find information about paperless billing."
```

**After (enriched):**
```
User: "How is paperless bill set for employee BANs?"
[Auto] Read ecle://context/... → {tables: ["BILLING_ACCOUNT"], services: ["arSvBilPrm"]}
Agent: ecle_source_read("par_ban_1.c", start_line=15621, end_line=17923) → actual code
Agent: "arSvBilPrm in par_ban_1.c (lines 15621-17923) handles billing parameters including
       paperless settings. The function has complexity 230 and touches BILLING_ACCOUNT table.
       Gap: No DDL schema for BILLING_ACCOUNT — column definitions unknown."
```

## Implementation Status

### Phase 1: Basic enrichment (DONE)
- [x] MCP instructions with rules, tool guide, fallbacks, gaps, format
- [x] `ecle://context/{question}` resource — entity extraction + graph matching
- [x] `GET /api/enrich` REST endpoint
- [x] Instructions tell agent to read context resource before answering

### Phase 1.5: Mandatory tool-based enrichment (DONE — v1.3)

**Problem with Phase 1:** Context resource (`ecle://context/{question}`) is opt-in — agents sometimes read it, sometimes don't. MCP clients don't guarantee resource reads.

**Fix:** Exposed enrichment as `ecle_enrich(question)` tool. Agents reliably call tools. Instructions changed from "read the resource" to "ALWAYS call ecle_enrich FIRST before any other tool."

- [x] `ecle_enrich(question, repo_id)` — MCP tool wrapping the same enrichment logic
- [x] Returns: tables, files, services, **suggested_tools** (actionable next calls), gaps
- [x] `suggested_tools` tells the agent exactly what to call next based on matched entities
- [x] Instructions updated: "MANDATORY FIRST CALL — Do NOT skip ecle_enrich"
- [x] `ecle://context/{question}` resource kept as fallback for clients that support resources

**Flow after Phase 1.5:**
```
User: "How is paperless bill set for employee BANs?"
Agent: ecle_enrich("How is paperless bill set for employee BANs?")
  → tables: BILLING_ACCOUNT (accessed by par_ban_1.c)
  → services: arSvBilPrm (called by arInCstBan)
  → suggested_tools: ecle_trace("BILLING_ACCOUNT"), ecle_source_read("par_ban_1.c")
Agent: ecle_trace("BILLING_ACCOUNT")
  → columns, code access, config, domain fields, documents, gaps
Done. Two calls. Right answer.
```

### Phase 2: Semantic enrichment (DONE — v1.3)

- [x] Vector search as second pass when keyword matching finds nothing
- [x] Searches both code vectors (`{repo}__fss`) and document vectors (`{repo}.docs`)
- [x] Returns semantic matches with confidence scores + `match: "semantic"` flag
- [x] Document chunk matches included in `documents` field
- [x] Cache enrichment results (TTL 5 minutes, max 100 entries, auto-eviction)
- [ ] Match business terms to technical entities ("paperless" → BILL_DELIVERY_TYPE) — Phase 3

**Enrichment flow (Phase 2):**
```
ecle_enrich("How is paperless bill set?")
  │
  ├── Pass 1: Keyword matching (~10ms)
  │   tables: check get_table_names() — exact name match
  │   files: check list_current_file_ids() — stem match
  │   services: check find_callers_of() — function name match
  │
  ├── Pass 2: Semantic search (only if Pass 1 found nothing) (~50ms)
  │   code: query {repo}__fss vector collection
  │   docs: query {repo}.docs vector collection
  │   Returns top 3 matches with scores
  │
  ├── Suggest tools based on what was found
  │
  └── Cache result (TTL 5 minutes)
```

**Why two passes:** Keyword matching is fast (~10ms) and precise. Semantic search is slower (~50ms) but handles synonyms and business terms. Running both always would double latency for no gain when keywords match. Two-pass keeps the common case fast.

### Phase 2.5: Intent-aware query plan (DONE — v1.5)

**Problem with Phase 2:** `suggested_tools` was a flat list of 2–3 tools with no sequencing. The agent could call them and stop, missing callers, impact, and source verification. Tools were also gated by `elif` — if a repo matched, table/file suggestions were skipped entirely.

**Fix:** Replaced `suggested_tools` construction with a `query_plan` — a phased, parallel-aware sequence returned from every `ecle_enrich` call.

- [x] `query_plan` field added to every `ecle_enrich` response
- [x] Three phases per plan: breadth (parallel), depth (parallel after phase 1), verify (source read)
- [x] Intent detection from question keywords — 5 intents: `impact`, `caller`, `understand`, `table`, `debug`
- [x] `ecle_impact` injected into phase 2 when `impact` intent detected
- [x] `ecle_find_callers`, `ecle_search`, `ecle_find_by_table`, `ecle_trace` always present at the right phase
- [x] Removed `elif` gating — repos + tables can both appear in the plan
- [x] `suggested_tools` kept as backward-compatible flat list (phase-1 tools only)
- [x] Document chunk hits appended to phase-1 when vector doc search returns results

**`query_plan` structure:**
```json
{
  "query_plan": [
    {
      "phase": 1,
      "label": "Repo breadth — run in parallel",
      "tools": [
        "ecle_stats(repo_id=\"csActvSubs\") -- size, languages, edge count",
        "ecle_functions(repo_id=\"csActvSubs\", min_complexity=100, entry_points_only=True)",
        "ecle_search(query=\"<key topic>\", repo_id=\"csActvSubs\")"
      ]
    },
    {
      "phase": 2,
      "label": "Depth — after phase 1, run in parallel on discovered entry points",
      "tools": [
        "ecle_file(\"<entry_point_file>\", repo_id=\"csActvSubs\") -- function list + outbound edges",
        "ecle_find_callers(\"<key_function>\", repo_id=\"*\") -- who calls each entry point (cross-repo)"
      ]
    },
    {
      "phase": 3,
      "label": "Verify — read source of 2-3 highest-complexity functions",
      "tools": [
        "ecle_source_read(file_id=\"<file>\", repo_id=\"<repo>\", start_line=<N>, end_line=<M>)"
      ]
    }
  ]
}
```

**Protocol enforced in docstring and MCP instructions:**
1. Call `ecle_enrich` first
2. Execute ALL phase-1 tools in parallel
3. Use phase-1 results to fill `<placeholders>` in phase-2 tools, then run in parallel
4. For critical functions, run phase-3 source reads to verify behavioral claims

**Enrichment flow (Phase 2.5):**
```
ecle_enrich("understanding of csActvSubs")
  │
  ├── Match: repo=csActvSubs, intent=understand
  │
  ├── Phase 1 (parallel): ecle_stats, ecle_functions, ecle_search
  │
  ├── Phase 2 (parallel, after phase 1):
  │     ecle_file(<each entry point>), ecle_find_callers(<each key fn>)
  │
  └── Phase 3: ecle_source_read(<highest complexity fns>)
```

### Phase 3: Learning enrichment (FUTURE)
- [ ] Track which tool calls succeeded after enrichment → improve entity extraction
- [ ] Learn synonyms from successful queries ("paperless" always leads to arSvBilPrm)
- [ ] Suggest missing data uploads based on failed enrichments
- [ ] Promote frequently used `<placeholder>` patterns into concrete suggestions based on past queries

## Metrics (Future)

| Metric | What It Measures |
|--------|-----------------|
| Enrichment hit rate | % of questions where entities matched the graph |
| Tool call precision | % of first tool calls that return non-empty (before vs after enrichment) |
| Answer completeness | Average # of gaps per answer (lower = better) |
| Enrichment latency | Time to extract entities + query graph (target: <100ms) |
