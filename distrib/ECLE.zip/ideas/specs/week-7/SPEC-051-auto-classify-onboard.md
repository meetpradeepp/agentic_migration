# SPEC-051: Auto-Classify Onboarding — One Folder, All Content Types

**Status**: Implemented
**Owner**: Onboarding Engineer
**Related**: SPEC-040 (unified onboard), SPEC-041 (file upload)

## Problem Statement

Today the user must manually select a content type (code, config, data, documents, facts) before uploading. If a repo contains all of these (which most do), the user must upload multiple times with different selections. This is tedious and error-prone — upload Java as code, then re-upload yaml as config, then re-upload docs separately.

A real repo folder looks like:
```
bulk-charges-adjustments-ms-v1/
├── src/main/java/**/*.java         ← code
├── src/main/resources/
│   ├── application.yml             ← config
│   ├── application.properties      ← config
│   └── logback.xml                 ← config
├── pom.xml                         ← data (dependencies)
├── sql/
│   ├── schema.sql                  ← data-sql
│   └── migration_v2.sql            ← data-sql
├── docs/
│   ├── README.md                   ← documents
│   └── architecture.html           ← documents
└── joern_exports/facts/*.facts.json ← facts (if pre-extracted)
```

The user should point to the root folder ONCE. ECLE classifies each file and routes it to the right pipeline.

## Design: Auto-Classification

### New Content Type: `auto`

```
What are you onboarding? [Auto-detect (recommended)]
```

When `auto` is selected, ECLE:
1. Scans all files in the upload
2. Classifies each by extension + content sniffing
3. Groups into content type buckets
4. Shows a preview: "Found: 69 code, 3 config, 2 DDL, 1 doc"
5. User confirms or adjusts
6. Submits as a SINGLE job that runs multiple pipelines

### Classification Rules

| Extension | Content Type | Pipeline |
|-----------|-------------|----------|
| `.java`, `.c`, `.cpp`, `.h`, `.py`, `.go`, `.js`, `.ts`, `.sru`, `.srf`, `.srw`, `.ppc`, `.pc` | code | CPG extraction |
| `.yaml`, `.yml`, `.properties`, `.cfg`, `.conf`, `.ini`, `.env`, `.sh`, `.ksh` | config | Config parser + document embedder |
| `.xml` | **content-sniff** | Tuxedo domain → data; Spring config → config; pom.xml → data; WSDL → data; generic → documents |
| `.sql`, `.ddl`, `.rql`, `.pls`, `.pkb`, `.pks` | data-sql | DDL parser + document embedder |
| `.md`, `.txt`, `.rst`, `.html`, `.htm`, `.pdf`, `.docx`, `.csv`, `.xlsx` | documents | Document embedder |
| `.json` with `.facts.json` suffix | facts | Direct load |
| `.json` (other) | documents | Document embedder |
| Unknown extension | skip | Logged but not processed |

### XML Content Sniffing

Already built in `XMLReader` — root tag detection:
- `<fieldtable>`, `<fml>`, `<fml32>` → data (Tuxedo domain)
- `<beans>`, `<configuration>` → config (Spring)
- `<definitions>` → data (WSDL)
- `<project>` with `<modelVersion>` → data (Maven POM)
- Other → documents (generic XML)

### Job Execution

Single job, multiple pipelines in sequence:

```
AutoClassifyJob:
  1. Classify all files → buckets
  2. code bucket → CPG extraction → facts → DB → edges → embeddings
  3. config bucket → config parser → document embedder → vectors
  4. data-sql bucket → document embedder (DDL extraction) → vectors
  5. data bucket → document embedder (XML reader) → vectors
  6. documents bucket → document embedder → vectors
  7. facts bucket → direct load → DB → edges → embeddings
  8. Cross-tier linking
  9. Complete — report counts per bucket
```

All under the SAME `repo_id`. All in the SAME job (one progress bar).

### UI Changes

**Onboard page:**
- Add `auto` as first option in "What are you onboarding?" dropdown
- Make it the default selection
- After file selection (before upload), show preview:
  ```
  Auto-classified 75 files:
  ├── 69 code files (.java)
  ├── 3 config files (.yml, .properties)
  ├── 2 SQL schemas (.sql)
  └── 1 document (.md)
  ```
- User can adjust (move files between buckets) or confirm

### Progress Reporting

```
Processing bulk-charges-adjustments-ms-v1 (auto-detect)
  [1/6] Code: Extracting 69 Java files...          45%
  [2/6] Config: Parsing 3 config files...           done
  [3/6] SQL schemas: Extracting 2 DDL files...      done
  [4/6] Documents: Embedding 1 file...              done
  [5/6] Cross-tier linking...                       done
  [6/6] Complete: 69 code + 3 config + 2 DDL + 1 doc
```

## Implementation

### Phase 1: Backend classifier + multi-pipeline job
- [ ] `src/ecle/ingestion/auto_classifier.py` — classifies files by extension + content sniffing
- [ ] `src/ecle/ingestion/job_queue.py` — `content_type="auto"` triggers multi-pipeline execution
- [ ] Each bucket runs its existing pipeline (no new extraction logic)

### Phase 2: UI preview + adjustment
- [ ] Client-side classification preview after file selection (using extension rules in JS)
- [ ] Show bucket counts before upload
- [ ] Allow user to adjust (drag files between buckets)

### Phase 3: Smart defaults
- [ ] Remember classification per repo (second upload uses same rules)
- [ ] Custom classification rules in ecle.yaml per repo
