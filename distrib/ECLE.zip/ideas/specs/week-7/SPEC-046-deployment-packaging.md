# SPEC-046: Deployment Packaging — Bundle, Scripts, and Mode Switching

**Status**: Spec
**Owner**: DevOps Engineer
**Files**: `deploy/`, `Dockerfile`, `docker-compose.yml`, `k8s/`, `scripts/`

## Problem Statement

Starting ECLE requires knowing which Python modules to run, which env vars to set, and which ports map to which components. There's no single entry point, no bundled distribution, and switching between single-machine / Docker / Kubernetes requires manual reconfiguration.

## Design: One Bundle, Three Modes

```
ecle-bundle/
├── scripts/
│   ├── start-all.sh          # Single machine: starts everything
│   ├── start-api.sh          # Start API server only
│   ├── start-ui.sh           # Start UI server only
│   ├── start-mcp.sh          # Start MCP server only
│   ├── start-worker.sh       # Start job queue worker only
│   └── stop-all.sh           # Stop everything
├── docker/
│   ├── Dockerfile             # Multi-stage build
│   ├── docker-compose.yml     # All services as containers
│   ├── docker-compose.dev.yml # Dev overrides (volumes, debug)
│   └── .env.example           # Template env vars
├── k8s/
│   ├── namespace.yaml
│   ├── api-deployment.yaml
│   ├── ui-deployment.yaml
│   ├── mcp-deployment.yaml
│   ├── worker-deployment.yaml
│   ├── configmap.yaml
│   ├── secrets.yaml
│   └── ingress.yaml
├── ecle.yaml.example          # Config template
└── README.md                  # Quick start guide
```

## Scripts

### start-all.sh (Single Machine Mode)

```bash
#!/bin/bash
# ECLE — Single Machine Mode
# Starts all components in one process

export ECLE_HOME=${ECLE_HOME:-./ecle-data}
export ECLE_API_TOKEN=${ECLE_API_TOKEN:-}
export ECLE_UI_PASSWORD=${ECLE_UI_PASSWORD:-}

echo "Starting ECLE (single machine mode)..."
echo "  API + UI + MCP: http://localhost:8741"
echo "  ECLE_HOME: $ECLE_HOME"

exec python -m ecle.cli serve --host 0.0.0.0 --port 8741
```

### start-api.sh (API Only)

```bash
#!/bin/bash
# ECLE API Server — serves GraphQL, REST, handles all data access
export ECLE_HOME=${ECLE_HOME:-./ecle-data}
export ECLE_API_TOKEN=${ECLE_API_TOKEN:-}

echo "Starting ECLE API server..."
echo "  GraphQL: http://localhost:8741/graphql"
echo "  REST:    http://localhost:8741/api/*"
echo "  Health:  http://localhost:8741/health"

exec python -m ecle.cli serve --component api --host 0.0.0.0 --port 8741
```

### start-ui.sh (UI Only)

```bash
#!/bin/bash
# ECLE Web UI — thin HTML server, calls API over HTTP
export ECLE_API_URL=${ECLE_API_URL:-http://localhost:8741}
export ECLE_UI_PASSWORD=${ECLE_UI_PASSWORD:-}

echo "Starting ECLE UI server..."
echo "  UI:      http://localhost:8742"
echo "  API:     $ECLE_API_URL"

exec python -m ecle.cli serve --component ui --host 0.0.0.0 --port 8742 --api-url $ECLE_API_URL
```

### start-mcp.sh (MCP Server Only)

```bash
#!/bin/bash
# ECLE MCP Server — tool protocol for agents/IDEs
export ECLE_MCP_TRANSPORT=streamable-http
export ECLE_MCP_HOST=0.0.0.0
export ECLE_MCP_PORT=${ECLE_MCP_PORT:-8080}
export ECLE_MCP_AUTH_TOKEN=${ECLE_MCP_AUTH_TOKEN:?Set ECLE_MCP_AUTH_TOKEN}
export ECLE_API_URL=${ECLE_API_URL:-http://localhost:8741}

echo "Starting ECLE MCP server..."
echo "  MCP:  http://localhost:$ECLE_MCP_PORT/mcp"
echo "  API:  $ECLE_API_URL"

exec python -m ecle.mcp.server
```

### start-worker.sh (Job Queue Worker Only)

```bash
#!/bin/bash
# ECLE Job Queue Worker — processes onboarding jobs
export ECLE_HOME=${ECLE_HOME:-./ecle-data}

echo "Starting ECLE job queue worker..."
exec python -m ecle.cli worker
```

### stop-all.sh

```bash
#!/bin/bash
echo "Stopping ECLE processes..."
pkill -f "ecle.cli serve" 2>/dev/null
pkill -f "ecle.mcp.server" 2>/dev/null
pkill -f "ecle.cli worker" 2>/dev/null
echo "Done."
```

## Docker

### Dockerfile (Multi-stage)

```dockerfile
FROM python:3.11-slim AS base
WORKDIR /app
COPY pyproject.toml .
RUN pip install --no-cache-dir .

FROM base AS api
COPY src/ src/
COPY ecle.yaml.example ecle.yaml
ENV ECLE_HOME=/data
EXPOSE 8741
CMD ["python", "-m", "ecle.cli", "serve", "--component", "api", "--host", "0.0.0.0"]

FROM base AS ui
COPY src/ src/
ENV ECLE_API_URL=http://api:8741
EXPOSE 8742
CMD ["python", "-m", "ecle.cli", "serve", "--component", "ui", "--host", "0.0.0.0", "--port", "8742", "--api-url", "http://api:8741"]

FROM base AS mcp
COPY src/ src/
ENV ECLE_MCP_TRANSPORT=streamable-http
ENV ECLE_API_URL=http://api:8741
EXPOSE 8080
CMD ["python", "-m", "ecle.mcp.server"]

FROM base AS worker
COPY src/ src/
ENV ECLE_HOME=/data
CMD ["python", "-m", "ecle.cli", "worker"]
```

### docker-compose.yml

```yaml
version: '3.8'

services:
  api:
    build: { context: ., target: api }
    ports: ["8741:8741"]
    volumes:
      - ecle-data:/data
    environment:
      - ECLE_HOME=/data
      - ECLE_API_TOKEN=${ECLE_API_TOKEN:-}

  ui:
    build: { context: ., target: ui }
    ports: ["8742:8742"]
    environment:
      - ECLE_API_URL=http://api:8741
      - ECLE_UI_PASSWORD=${ECLE_UI_PASSWORD:-}
    depends_on: [api]

  mcp:
    build: { context: ., target: mcp }
    ports: ["8080:8080"]
    environment:
      - ECLE_API_URL=http://api:8741
      - ECLE_MCP_AUTH_TOKEN=${ECLE_MCP_AUTH_TOKEN:?Set ECLE_MCP_AUTH_TOKEN}
    depends_on: [api]

  worker:
    build: { context: ., target: worker }
    volumes:
      - ecle-data:/data
    environment:
      - ECLE_HOME=/data
    depends_on: [api]

volumes:
  ecle-data:
```

## Kubernetes

### Minimal manifests for each component

Each component is a separate Deployment with its own Service:

| Component | Replicas | Port | Volume | Env |
|-----------|----------|------|--------|-----|
| api | 1-3 | 8741 | ecle-data PVC | ECLE_HOME, ECLE_API_TOKEN |
| ui | 1-3 | 8742 | none | ECLE_API_URL |
| mcp | 1-2 | 8080 | none | ECLE_API_URL, ECLE_MCP_AUTH_TOKEN |
| worker | 1 | none | ecle-data PVC | ECLE_HOME |

Ingress routes:
- `/` → ui service
- `/api/*`, `/graphql` → api service
- `/mcp` → mcp service

## Mode Switching

### Single command to switch modes

```bash
# Single machine (default)
./scripts/start-all.sh

# Docker
docker compose up -d

# Docker (dev mode with local source)
docker compose -f docker-compose.yml -f docker-compose.dev.yml up -d

# Kubernetes
kubectl apply -f k8s/
```

### Environment template (.env.example)

```bash
# ECLE Configuration
ECLE_HOME=./ecle-data

# API Server
ECLE_API_TOKEN=          # Set for production. Empty = no auth (dev only)

# Web UI
ECLE_UI_PASSWORD=        # Set for production. Empty = no auth (dev only)

# MCP Server
ECLE_MCP_AUTH_TOKEN=     # Required for remote MCP
ECLE_MCP_PORT=8080

# API URL (for UI, MCP, CLI when not bundled)
ECLE_API_URL=http://localhost:8741

# Database
# ECLE_DB_BACKEND=sqlite   # sqlite | postgresql
# ECLE_DB_HOST=localhost    # PostgreSQL only
# ECLE_DB_PORT=5432
# ECLE_DB_NAME=ecle
# ECLE_DB_USER=ecle
# ECLE_DB_PASSWORD=         # Never commit this

# Logging
ECLE_LOG_FORMAT=json     # json | text
ECLE_LOG_LEVEL=INFO
```

## Worker Command

Need a `ecle worker` CLI command that runs the job queue worker as a standalone process:

```python
# In cli.py
def cmd_worker(args):
    """Run the job queue worker as a standalone process."""
    from ecle.config.loader import ConfigLoader
    from ecle.ingestion.job_queue import JobQueue, QueueWorker

    settings = ConfigLoader.load(cli_args=args)
    queue = JobQueue(settings.home)
    worker = QueueWorker(queue, settings)
    
    print(f"ECLE Worker started. Watching {settings.home}/queue/")
    worker.run_forever()  # blocks, processes jobs as they arrive
```

## Implementation Plan

### Phase 1: Scripts + .env
- [ ] Create `deploy/scripts/` with all start/stop scripts
- [ ] Create `deploy/.env.example`
- [ ] Create `deploy/ecle.yaml.example`
- [ ] Add `ecle worker` CLI command

### Phase 2: Docker
- [ ] Create `deploy/docker/Dockerfile` (multi-stage)
- [ ] Create `deploy/docker/docker-compose.yml`
- [ ] Create `deploy/docker/docker-compose.dev.yml`
- [ ] Test: `docker compose up` starts all 4 services

### Phase 3: Kubernetes
- [ ] Create `deploy/k8s/` manifests
- [ ] Test with minikube or kind
- [ ] Document in README

## v1.3 Enhancements (2026-04-11)

### Bundle Script (`bundle.bat` / `bundle.ps1` / `bundle.sh`)

| Feature | Implementation |
|---------|---------------|
| **Versioned naming** | `-v VERSION` flag. Output: `ECLE-v1.3-20260411.zip`. Auto-reads from `pyproject.toml` if not provided. |
| **`--models` flag** | Opt-in embedding model (~174MB). Default bundle is ~4MB without models. |
| **`--help` flag** | Shows usage, options, examples. |
| **Secrets sanitization** | `ecle.yaml`: tokens/passwords → `CHANGE-ME`. AMF `.env`: absolute paths → relative, tokens → `CHANGE-ME`. |
| **`RELEASE_NOTES.md`** | Shipped in every bundle. Per-version features, bug fixes, deployment changes with spec traceability. |
| **`requirements.txt`** | Both ECLE and AMF pinned deps included. `-e .` / `-e ".[mcp]"` at top for package registration. |
| **`init-db.py`** | Creates empty DB with all tables on install. No dev data ships. Auto-runs on first `start-all.bat`. |
| **AMF `README.md`** | Included — fixes `pip install -e .` error from missing `readme` in `pyproject.toml`. |
| **`tree-sitter-powerbuilder.zip`** | Custom grammar bundled with AMF. |
| **No `__pycache__`** | Cleaned from bundle during packaging. Start scripts also clear on every launch. |
| **No double-nesting** | `Compress-Archive -Path $tmp/*` zips contents, not directory. |

### Install Order

AMF first (dependency), then ECLE:
```
1. Unzip
2. cd into bundle
3-9.   AMF venv + requirements + PB grammar
10-12. ECLE venv + requirements
13.    python deploy/scripts/init-db.py
14-15. Start
```

### Named Virtual Environments

| Component | Venv Name | Activation |
|-----------|-----------|------------|
| AMF | `AMF/AMF/` | `cd AMF && AMF\Scripts\activate` |
| ECLE | `ECLE/` | `ECLE\Scripts\activate` |

Start scripts probe both named (`ECLE/`, `AMF/AMF/`) and standard (`.venv/`) layouts.

### No-Cache HTTP Headers

All `/ui/*` and `/api/*` responses include:
```
Cache-Control: no-cache, no-store, must-revalidate
Pragma: no-cache
```
Jinja2 templates: `auto_reload = True`.

### Embedding Model Location

Models stored under `ecle-data/models/` (resolved via `ECLE_HOME`). ECLE reads path from `ecle.yaml → embedding.model_path`, resolves to absolute, passes to AMF subprocess via `AMF_LOCAL_MODEL_PATH` env var. One copy, no relative path hacks.

### Status clarification

- Scripts + Bundle: **Implemented** (v1.3)
- Docker: **Spec only** — `deploy/docker/Dockerfile` and `docker-compose.yml` described but not yet created
- Kubernetes: **Spec only** — `deploy/k8s/` manifests described but not yet created
- `bundle.sh` (Linux): Present and working

## v1.4 Enhancements (2026-04-14)

### `.mcp.json` Venv Path Override During Bundle

**Problem:** Dev `.mcp.json` hard-codes `.venv/Scripts/python.exe` (standard venv). Bundled installs use named venv `ECLE/` (not `.venv/`). Shipping dev `.mcp.json` as-is causes MCP server to fail immediately on a clean install — Python not found.

**Fix:** Bundle scripts rewrite the `command` path in `.mcp.json` before zipping.

| Script | Substitution |
|--------|-------------|
| `bundle.ps1` | `-replace '\.venv[/\\]Scripts[/\\]python\.exe', 'ECLE/Scripts/python.exe'` |
| `bundle.ps1` | `-replace '\.venv[/\\]bin[/\\]python', 'ECLE/bin/python'` |
| `bundle.sh` | `sed 's|\.venv/Scripts/python\.exe|ECLE/Scripts/python.exe|g'` |
| `bundle.sh` | `sed 's|\.venv/bin/python|ECLE/bin/python|g'` |

**Dev env unchanged:** `.mcp.json` in the repo always keeps `.venv/Scripts/python.exe` — only the copy inside the zip is rewritten.

**Result in bundle:**
```json
{
  "mcpServers": {
    "ecle-mcp-server": {
      "type": "stdio",
      "command": "ECLE/Scripts/python.exe",   ← Windows
      "command": "ECLE/bin/python",            ← Linux/Mac
      "args": ["-m", "ecle.mcp.server"]
    }
  }
}
```

**Rule:** Any future venv name change must update both bundle scripts AND this spec.
