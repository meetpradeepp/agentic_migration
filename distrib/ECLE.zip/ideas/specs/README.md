# ECLE Specs

**HARD RULE: Spec before code. Always.** No implementation begins without a written spec. The spec defines the interface, behavior, tests, and dependencies. The agent implements against the spec. The reviewer validates against the spec.

## Spec Format

```
specs/{week-N}/SPEC-{NNN}-{short-name}.md

Sections:
  Purpose        — what this component does and why
  ADR References — which decisions it implements
  Inputs         — what data it reads
  Outputs        — what data it produces
  Interface      — public classes, methods, signatures
  Behavior       — rules, invariants, edge cases
  Files          — source files this spec maps to
  Tests          — what the tests prove
  Dependencies   — what other specs/components this requires
  Status         — spec | implemented | tested
```

## Workflow

```
Task Planner → writes spec
Platform Architect → validates spec against constitution
Domain Agent → implements spec
Test Engineer → writes tests from spec's "Tests" section
Code Reviewer → validates code against spec + coding standards
```

## Handling Bugs & Enhancements

**Bugs:** Write a failing test first (proves the bug). Fix the code. Review against the original spec's intended behavior. No full spec needed — the test IS the documentation.

**Enhancements:** Update the existing spec with the new behavior (marked "Enhancement"). Implement against the updated spec. Add tests.

**New features:** Full new spec (SPEC-NNN). Always.

## Index

### Week 1 — Foundation (SPEC-001 through SPEC-008)

| Spec | Component | Owner | Status |
|------|-----------|-------|--------|
| [SPEC-001](week-1/SPEC-001-structured-db-schema.md) | Structured DB schema (12 tables) | Backend Engineer | Implemented + Tested |
| [SPEC-002](week-1/SPEC-002-sqlite-backend.md) | SQLite backend (CRUD, queries, traversal, retire/purge) | Backend Engineer | Implemented + Tested |
| [SPEC-003](week-1/SPEC-003-facts-loader.md) | Facts loader (ingestion, sync, versioning, removal) | FACT Ingestion Engineer | Implemented + Tested |
| [SPEC-004](week-1/SPEC-004-topology-edges.md) | Topology edges (10 signal detectors as SQL) | FACT Ingestion Engineer | Implemented + Tested |
| [SPEC-005](week-1/SPEC-005-behavioral-signature.md) | Behavioral signature + vector embeddings (ChromaDB) | FACT Ingestion Engineer | Implemented + Tested |
| [SPEC-006](week-1/SPEC-006-graphql-schema.md) | GraphQL schema + resolvers | Query Engine Engineer | Implemented + Tested |
| [SPEC-007](week-1/SPEC-007-cli-import-serve.md) | CLI: ecle import + ecle serve + ecle stats + ecle remove | FACT Ingestion + Query Engine | Implemented + Tested |
| [SPEC-008](week-1/SPEC-008-mcp-server.md) | MCP server for VS Code (10 tools, FastMCP + stdio) | Query Engine Engineer | Implemented + Tested |

### Week 2 — Onboarding + Integration (SPEC-009 through SPEC-012)

| Spec | Component | Owner | Status |
|------|-----------|-------|--------|
| [SPEC-009](week-2/SPEC-009-git-onboarding.md) | Git repo onboarding (clone → CPG → ingest + auth) | Source Mesh + FACT Ingestion | Implemented + Tested |
| [SPEC-010](week-2/SPEC-010-git-integration.md) | Git integration (continuous ingestion + auth) | Source Mesh + FACT Ingestion | Spec |
| [SPEC-011](week-2/SPEC-011-document-onboarding.md) | Document onboarding (reader plugins: md, DDL, PDF, DOCX, OpenAPI, Excel) | FACT Ingestion | Spec |
| [SPEC-012](week-2/SPEC-012-web-ui.md) | Web UI (4-tab onboard, chat, health dashboard, T-Mobile theme) | Query Engine | Spec |
| [SPEC-013](week-2/SPEC-013-settings-config.md) | Settings & Config (ecle.yaml, Lite/Full modes, backend factory) | Backend Engineer | Spec |

### Week 3 — Hardening + Clustering + Cross-Repo (SPEC-014 through SPEC-020)

| Spec | Component | Owner | Status |
|------|-----------|-------|--------|
| [SPEC-014](week-3/SPEC-014-shared-artifact-registry.md) | Shared Artifact Registry (schema + ingestion + cross-repo edges) | Backend + FACT Ingestion | Implemented + Tested |
| [SPEC-015](week-3/SPEC-015-cross-repo-mcp-tools.md) | Cross-Repo MCP Tools (6 tools) | Query Engine + MCP Tool | Implemented + Tested |
| [SPEC-016](week-3/SPEC-016-close-gaps.md) | Close Week 2 gaps (CLI wiring, config, spec sync) | FACT Ingestion + Backend | Spec |
| [SPEC-017](week-3/SPEC-017-error-handling.md) | Error handling + observability (ADR-021) | Backend | Spec |
| [SPEC-018](week-3/SPEC-018-louvain-clustering.md) | Louvain clustering + capability discovery | Clustering Engineer | Spec |
| [SPEC-019](week-3/SPEC-019-smart-chat-router.md) | Smart chat router (embedding-based + LLM-ready) | Query Engine | Spec |
| [SPEC-020](week-3/SPEC-020-cicd-integration.md) | CI/CD integration testing | DevOps + Test Engineer | Spec |

### Week 8 — Guardrails + Cross-Tier Completion (SPEC-053 onward)

| Spec | Component | Owner | Status |
|------|-----------|-------|--------|
| [SPEC-053](week-8/SPEC-053-language-common-module.md) | Language common module cleanup | Platform Architect | Implemented |
| [SPEC-054](week-8/SPEC-054-query-performance-guards.md) | Query performance guards | Platform Architect | Implemented |
| [SPEC-055](week-8/SPEC-055-non-code-artifact-promotion.md) | Promote document, config, and DDL evidence into shared artifacts | FACT Ingestion + Query Engine | Implemented |
| [SPEC-056](week-8/SPEC-056-service-index-child-jobs.md) | Expose service indexing as a first-class child job in the portal and queue | Onboarding Engineer + FACT Ingestion | Implemented |
| [SPEC-057](week-8/SPEC-057-parallel-job-workers.md) | Parallel job worker pool with per-repo exclusivity and CPG slot cap | Ingestion Platform | Implemented |
| [SPEC-058](week-8/SPEC-058-queue-start-mode.md) | Queue start mode control (manual/delayed/auto) with pause/resume API | Ingestion Platform | Implemented |
| [SPEC-059](week-8/SPEC-059-configurable-runtime-limits.md) | Configurable runtime limits (service index depth/cap, CPG phases, MCP response size) | Platform Architect | Implemented |
| [SPEC-060](week-8/SPEC-060-pipeline-performance.md) | Pipeline performance: batch embedding, per-detector timing, cross-tier linker timing | Platform Architect | Implemented |
| [SPEC-061](week-8/SPEC-061-auto-job-handoff.md) | Auto job handoff — classify-then-submit (free worker thread, fix UI dual-processing) | Platform Architect | Spec |

### Dependency Chain

```
Week 1 (done):
  SPEC-001 → SPEC-002 → SPEC-003 → SPEC-004 → SPEC-005 → SPEC-006 → SPEC-007 → SPEC-008

Week 2 (done):
  SPEC-013 → SPEC-009 → SPEC-010 + SPEC-011 (parallel) → SPEC-012

Week 3:
  SPEC-014 (artifact registry)     ← DONE
  SPEC-015 (cross-repo tools)      ← DONE
  SPEC-016 (close gaps)            ← no deps, do first
  SPEC-017 (error handling)        ← parallel with 016
  SPEC-018 (Louvain clustering)    ← needs 016 done (settings wired)
  SPEC-019 (smart chat router)     ← needs 018 (clusters for better answers)
  SPEC-020 (CI/CD integration)     ← needs 016 done

  Build order: SPEC-016 + SPEC-017 (parallel) → SPEC-018 → SPEC-019 + SPEC-020 (parallel)

Week 4 (service separation — ADR-017):
  SPEC-021 (remote MCP)           ← already exists from other session
  SPEC-022 (GraphQL API service)  ← standalone API with REST + health endpoints
  SPEC-023 (Web UI service)       ← standalone UI calling API over HTTP

  Build order: SPEC-022 → SPEC-023 (UI depends on API being separable)
  SPEC-021 already implemented.
```
