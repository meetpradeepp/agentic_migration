# SPEC-018: Louvain Clustering + Capability Discovery

**Status**: Spec
**Owner**: Clustering Engineer
**Files**: src/ecle/clustering/louvain.py (new), src/ecle/clustering/stabilization.py (new), src/ecle/clustering/capabilities.py (new)

## Purpose

Discover emergent file clusters from the topology graph using Louvain community detection. This is the "structural grouping" layer — files with dense mutual edges (FUNCTION_CALL, WRITE_READ) form natural clusters. Required for 50K file scale (ADR-016, ADR-017).

Also discovers capabilities — business functions that span clusters, identified by hierarchical clustering on cluster centroids.

## ADR References

- [ADR-016](../../constitution/decisions/ADR-016-hierarchy-repo-cluster-version.md) — repo=namespace, cluster=structural, version=temporal
- [ADR-007](../../constitution/decisions/ADR-007-resolved-open-questions.md) — clustering included in Lite mode
- [ADR-017](../../constitution/decisions/ADR-017-deployment-modes-lite-full-enterprise.md) — Lite handles 50K files with clustering

## Inputs

- `topology_edges` table — weighted edges between files (from SPEC-004)
- `file_facts` table — file metadata for cluster assignment
- Vector embeddings (Layer 1) — for semantic validation of clusters

## Outputs

- `clusters` table populated — cluster_id, name, file_count, silhouette_score
- `file_facts.cluster_id` updated — each file assigned to a cluster
- `capabilities` table populated (optional) — discovered business capabilities

## Interface

```python
class LouvainClusterer:
    """Discovers file clusters from topology graph using Louvain algorithm."""

    def __init__(self, db: SQLiteBackend, repo_id: str, min_cluster_size: int = 3)

    def build_graph(self) -> dict:
        """Build adjacency graph from topology_edges.
        Returns: {file_id: {neighbor_id: weight, ...}, ...}
        """

    def run_louvain(self) -> dict[str, str]:
        """Run Louvain community detection.
        Returns: {file_id: cluster_id, ...}
        """

    def assign_clusters(self, assignments: dict[str, str]) -> int:
        """Write cluster assignments to file_facts.cluster_id.
        Also populates clusters table.
        Returns: number of clusters created.
        """

    def cluster_all(self) -> ClusterResult:
        """Full pipeline: build graph → Louvain → assign → stats."""


class ClusterStabilizer:
    """Applies stabilization rules to prevent cluster oscillation."""

    MIN_DELTA_TO_REASSIGN = 1.5   # from architecture doc
    MIN_CLUSTER_LIFETIME = 10     # commits
    MAX_CLUSTER_SIZE = 500        # files

    def stabilize(self, proposed: dict[str, str],
                  current: dict[str, str]) -> dict[str, str]:
        """Apply stabilization rules to proposed cluster assignments."""


class CapabilityDiscoverer:
    """Discovers capabilities from cluster centroids using hierarchical clustering."""

    def __init__(self, db: SQLiteBackend, vector_store: ChromaDBStore | None,
                 repo_id: str)

    def discover(self, min_clusters: int = 2) -> list[dict]:
        """Discover capabilities from cluster centroid proximity.
        Returns: list of {capability_name, cluster_ids, file_count}
        """


@dataclass
class ClusterResult:
    clusters_created: int
    files_assigned: int
    singletons: int        # files not in any cluster (< min_size)
    largest_cluster: int   # file count
    avg_cluster_size: float
    silhouette_score: float | None  # overall quality metric
```

## Behavior

### Louvain Algorithm

```
1. Build weighted adjacency graph from topology_edges WHERE is_valid = 1
2. Run python-louvain (community.best_partition)
   → produces: {file_id: community_number}
3. Filter: communities with < min_cluster_size files → singletons (no cluster_id)
4. Assign cluster_id = f"cluster_{repo_id}_{community_number}"
5. Update file_facts SET cluster_id = ? WHERE file_id = ?
6. Populate clusters table: cluster_id, file_count, dominant_language
```

### Stabilization Rules (from architecture doc)

```yaml
min_delta_to_reassign: 1.5    # file only moves if weight-sum toward new > old by this margin
min_cluster_lifetime: 10       # commits before split/merge allowed
max_cluster_size: 500          # split-eligible above this
oscillation_detection: true    # file flipped 2x in 20 commits → freeze
```

For first-time onboarding: stabilization rules are relaxed (no history to stabilize against).
For incremental updates: compare proposed vs current assignments, apply rules.

### Cluster Naming

```
Auto-generate from dominant characteristics:
  - Most common language in cluster → "c-batch-processing"
  - Most common table operations → "billing-db-access"
  - Entry point function names → "settlement-pipeline"

For MVP: use simple "cluster_{N}" naming. Smarter naming in Phase 4.
```

### Silhouette Score (quality metric)

```
For each file: compare intra-cluster edge weight sum vs nearest-cluster edge weight sum.
Score > 0.65 = good cluster. Score < 0.4 = questionable cluster.
Overall score = mean across all files.
```

### CLI Integration

```bash
# Run clustering on a repo
ecle cluster --repo-id billing-service

# Show cluster assignments
ecle stats --repo-id billing-service --clusters
```

### When Clustering Runs

```
1. After onboarding (ecle onboard, ecle import): if > 10 files, auto-cluster
2. On demand: ecle cluster --repo-id X
3. After incremental updates: if > 20 files changed since last clustering
4. Periodically: weekly batch (enterprise mode)
```

## Dependencies

- SPEC-001 (schema — clusters table, file_facts.cluster_id)
- SPEC-002 (SQLite backend)
- SPEC-004 (topology edges — the graph to cluster)
- SPEC-005 (vector store — for silhouette/capability discovery)
- `python-louvain>=0.16` (already in pyproject.toml)

## Tests

| Test | What's Verified |
|------|----------------|
| `test_build_graph` | Adjacency graph built from topology_edges with correct weights |
| `test_louvain_basic` | 2+ clusters discovered from connected components |
| `test_small_clusters_filtered` | Communities < min_cluster_size become singletons |
| `test_cluster_assignment` | file_facts.cluster_id populated, clusters table has entries |
| `test_cluster_stats` | file_count, dominant_language correct per cluster |
| `test_stabilization_min_delta` | File doesn't move if delta < 1.5 |
| `test_first_time_no_stabilization` | First clustering has no stabilization (no history) |
| `test_max_cluster_size` | Cluster > 500 files flagged for split |
| `test_silhouette_score` | Score computed and reasonable (0-1 range) |
| `test_cluster_all_pipeline` | Full pipeline: edges → Louvain → assign → stats |
| `test_cli_cluster` | `ecle cluster` command works |
