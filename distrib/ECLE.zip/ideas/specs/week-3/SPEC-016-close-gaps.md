# SPEC-016: Close Week 2 Gaps

**Status**: Spec
**Owner**: FACT Ingestion Engineer + Backend Engineer
**Files**: src/ecle/cli.py, src/ecle/query/app.py, src/ecle/mcp/server.py

## Purpose

Close implementation gaps from Week 2 where code was built but not fully wired:
1. `ecle onboard-docs` CLI command — missing from cli.py
2. Settings/Config wiring — Settings class exists (SPEC-013) but CLI/server still hardcode backends
3. Spec status updates — SPEC-009 through SPEC-015 need status updated to match reality
4. Spec sync run — verify all specs match code

## What to Build

### 1. Wire `ecle onboard-docs` CLI command

```python
# In cli.py — add cmd_onboard_docs + argparse registration
def cmd_onboard_docs(args):
    """Onboard documents (markdown, DDL, text, DOCX) into Tier 3."""
    from ecle.ingestion.document_embedder import DocumentEmbedder
    # ... read docs_dir, create embedder, embed_directory(), print results

# Argparse:
p_docs = subparsers.add_parser("onboard-docs", help="Onboard documents")
p_docs.add_argument("docs_dir", help="Directory containing documents")
p_docs.add_argument("--repo-id", help="Repository ID")
p_docs.add_argument("--db", default="ecle.db")
```

### 2. Wire Settings into CLI and Server

```python
# In cli.py — all commands read from Settings
settings = ConfigLoader.load(cli_args=args)
db = BackendFactory.create_db(settings)
vector = BackendFactory.create_vector(settings)

# In query/app.py — create_app reads from Settings
def create_app(settings: Settings | None = None):
    if settings is None:
        settings = ConfigLoader.load()
    db = BackendFactory.create_db(settings)
    vector = BackendFactory.create_vector(settings)
    ...

# In mcp/server.py — read Settings for backend selection
settings = ConfigLoader.load()
```

### 3. Generate default ecle.yaml on first run

```python
# If ecle.yaml doesn't exist when ecle serve or ecle import runs:
def _ensure_config():
    if not Path("ecle.yaml").exists():
        default = """# ECLE Configuration
features: lite
db:
  backend: sqlite
  path: ./ecle.db
vector:
  backend: chromadb
  path: ./vectors
clustering:
  enabled: true
server:
  host: 127.0.0.1
  port: 8741
"""
        Path("ecle.yaml").write_text(default)
```

### 4. Update spec statuses

| Spec | Current Status | Correct Status |
|------|---------------|----------------|
| SPEC-009 | Spec | Implemented + Tested |
| SPEC-010 | Spec | Implemented + Tested |
| SPEC-011 | Spec | Implemented + Tested |
| SPEC-012 | Spec | Implemented + Tested |
| SPEC-013 | Spec | Implemented + Tested |
| SPEC-014 | Spec | Implemented + Tested |
| SPEC-015 | Spec | Implemented + Tested |

## Tests

| Test | What's Verified |
|------|----------------|
| `test_cli_onboard_docs` | `ecle onboard-docs` command processes markdown + DDL fixtures |
| `test_settings_wired_in_cli` | CLI reads from ecle.yaml when present |
| `test_default_yaml_generated` | First run creates ecle.yaml if missing |
| `test_server_uses_settings` | `create_app()` accepts Settings object |

## Dependencies

- SPEC-011 (document embedder — already built)
- SPEC-013 (settings — already built)
