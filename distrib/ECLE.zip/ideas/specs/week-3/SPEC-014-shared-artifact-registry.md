# SPEC-014: Shared Artifact Registry

**Status**: Implemented + Tested
**Owner**: Backend Engineer + FACT Ingestion Engineer
**Files**: `src/ecle/backends/structured/schema.py` (schema addition), `src/ecle/ingestion/artifact_registry.py` (new), `src/ecle/backends/structured/sqlite.py` (new queries)

## Purpose

Add a `shared_artifacts` table that registers every externally-visible artifact (tables, services, APIs, queues) with the repos and files that touch them. This is the structured join key for cross-repo discovery — answering "which repos touch table X?" as an indexed query instead of scanning every repo.

Populated during existing Layer 1 FACT ingestion at zero additional extraction cost. No new CPG work. No LLM. No vector operations.

## ADR References

- [ADR-019](../../constitution/decisions/ADR-019-shared-artifact-registry.md) — full design, schema, population algorithm, cross-repo edge derivation
- [ADR-002](../../constitution/decisions/ADR-002-hybrid-storage-not-vector-only.md) — structured DB serves 80% of queries
- [ADR-014](../../constitution/decisions/ADR-014-version-chain-everything-is-kept.md) — version chain pattern reused for artifact versioning

## Inputs

- `CanonicalFactFileBase` (CIM) — already produced during ingestion. Specifically:
  - `data_flows[]` where `artifact_type = DB_TABLE` → table READ/WRITE operations
  - `external_calls[]` → service calls (RPC, HTTP, MQ)
  - `functions[]` where `is_entry_point = true` → service implementations
- `file_tables` rows (already in structured DB) — backup source for table names
- `function_calls` rows where `is_external = true` — backup for external service calls

## Outputs

- `shared_artifacts` table in structured DB
- `cross_repo_edges` derived from the registry (inserted into `topology_edges` with `edge_type = 'CROSS_REPO'`)

## Interface

### Schema Addition (in `schema.py`)

```python
SHARED_ARTIFACTS_DDL = """
CREATE TABLE IF NOT EXISTS shared_artifacts (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    tenant_id       TEXT NOT NULL DEFAULT 'default',
    artifact_type   TEXT NOT NULL,       -- TABLE, TUXEDO_SERVICE, API_ENDPOINT,
                                         -- MESSAGE_QUEUE, SHARED_HEADER
    artifact_name   TEXT NOT NULL,       -- normalized name (uppercase, no schema prefix)
    repo_id         TEXT NOT NULL,
    file_id         TEXT NOT NULL,       -- references file_facts.file_id
    operation       TEXT NOT NULL,       -- READ, WRITE, CALL, IMPLEMENT,
                                         -- PUBLISH, CONSUME, INCLUDE
    line_number     INTEGER,
    commit_sha      TEXT NOT NULL,
    is_current      BOOLEAN NOT NULL DEFAULT 1,
    created_at      TEXT NOT NULL DEFAULT (datetime('now')),
    superseded_at   TEXT,

    UNIQUE(tenant_id, artifact_type, artifact_name, repo_id, file_id,
           operation, commit_sha)
);

CREATE INDEX IF NOT EXISTS idx_sa_lookup
    ON shared_artifacts(tenant_id, artifact_type, artifact_name, is_current);

CREATE INDEX IF NOT EXISTS idx_sa_repo
    ON shared_artifacts(tenant_id, repo_id, artifact_type, is_current);

CREATE INDEX IF NOT EXISTS idx_sa_file
    ON shared_artifacts(tenant_id, file_id, is_current);
"""
```

### Artifact Registry Module (`artifact_registry.py`)

```python
from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class SharedArtifact:
    """A single artifact reference extracted from CIM."""
    artifact_type: str       # TABLE, TUXEDO_SERVICE, API_ENDPOINT, MESSAGE_QUEUE
    artifact_name: str       # normalized
    operation: str           # READ, WRITE, CALL, IMPLEMENT, PUBLISH, CONSUME
    line_number: int | None = None


def normalize_artifact_name(raw_name: str, artifact_type: str) -> str:
    """Normalize artifact names for consistent cross-repo joining.

    Rules:
    - Strip schema prefixes for tables: 'schema1.MY_TABLE' → 'MY_TABLE'
    - Uppercase all table names: 'billing_account' → 'BILLING_ACCOUNT'
    - Preserve case for service names (they are case-sensitive in Tuxedo)
    - Strip trailing/leading whitespace
    """
    ...


def extract_shared_artifacts(
    cim: dict,
    repo_id: str,
    file_id: str,
) -> list[SharedArtifact]:
    """Extract shared artifacts from a CIM fact file.

    Reads: cim['data_flows'], cim['external_calls'], cim['functions'].
    Returns: list of SharedArtifact instances.
    No LLM. No vector. Pure field extraction.
    """
    ...


def register_artifacts(
    backend: StructuredBackend,
    tenant_id: str,
    repo_id: str,
    file_id: str,
    commit_sha: str,
    artifacts: list[SharedArtifact],
) -> int:
    """Upsert artifacts into shared_artifacts table.

    Returns: number of rows inserted/updated.
    Idempotent — same (tenant, type, name, repo, file, op, commit) = no-op.
    """
    ...


def derive_cross_repo_edges(
    backend: StructuredBackend,
    tenant_id: str,
) -> list[dict]:
    """Derive cross-repo edges from the artifact registry.

    Finds all artifacts shared by 2+ repos and creates CROSS_REPO
    topology edges for WRITE→READ (tables) and CALL→IMPLEMENT (services).

    Returns: list of edge dicts ready for topology_edges insertion.
    """
    ...
```

### SQLite Backend Additions (in `sqlite.py`)

```python
# New query methods on SQLiteBackend:

def get_shared_artifacts(
    self,
    tenant_id: str,
    artifact_name: str | None = None,
    artifact_type: str | None = None,
    repo_id: str | None = None,
    is_current: bool = True,
) -> list[dict]:
    """Query shared_artifacts with optional filters."""
    ...


def get_artifact_summary(
    self,
    tenant_id: str,
    artifact_type: str | None = None,
    min_repo_count: int = 2,
) -> list[dict]:
    """Aggregate shared artifacts: group by (type, name), count repos."""
    ...


def get_cross_repo_edges(
    self,
    tenant_id: str,
    repo_id: str,
    edge_type: str | None = None,
) -> dict:
    """Return inbound + outbound cross-repo connections for a repo."""
    ...


def get_repos(
    self,
    tenant_id: str,
) -> list[dict]:
    """List all repos with aggregate stats (file count, function count, etc.)."""
    ...
```

## Behavior

### Population Rules

1. **Triggered during Layer 1 ingestion** — after CIM normalization, before topology edge computation. Piggybacks on existing `ingest_file()` pipeline.
2. **Idempotent** — re-ingesting the same file+commit produces no duplicates (UNIQUE constraint).
3. **Versioned** — when a file is re-ingested at a new commit, old artifact rows get `is_current = FALSE, superseded_at = now()`. New rows inserted with `is_current = TRUE`.
4. **Normalized names** — `normalize_artifact_name()` ensures consistent joining:
   - Tables: `schema.TABLE_NAME` → `TABLE_NAME`, always uppercase
   - Services: preserved as-is (Tuxedo names are case-sensitive)
   - APIs: URL paths normalized (strip trailing slash, lowercase)

### Cross-Repo Edge Derivation

1. **Runs after any repo onboarding completes** — as a post-ingestion batch step, not on the per-file path.
2. **Also runs periodically** — weekly batch window, catches any edges missed by incremental updates.
3. **Edge types derived:**
   - TABLE: repo A WRITE + repo B READ → `CROSS_REPO` edge, weight 2.5 (WRITE_READ)
   - TUXEDO_SERVICE: repo A CALL + repo B IMPLEMENT → `CROSS_REPO` edge, weight 3.0 (FUNCTION_CALL)
   - MESSAGE_QUEUE: repo A PUBLISH + repo B CONSUME → `CROSS_REPO` edge, weight 2.0 (EXECUTION_SEQUENCE)
4. **Edges inserted into `topology_edges`** with `edge_type = 'CROSS_REPO'` and `signal_type` indicating the artifact type.

### Fallback Population (for repos already onboarded without CIM)

For repos onboarded before this feature, populate from existing structured DB:

```sql
-- Backfill from file_tables (already has table names)
INSERT INTO shared_artifacts (tenant_id, artifact_type, artifact_name, repo_id,
                              file_id, operation, commit_sha, is_current)
SELECT 'default', 'TABLE', UPPER(ft.table_name), ff.repo_id,
       ff.file_id, ft.operation, ff.commit_sha, ff.is_current
FROM file_tables ft
JOIN file_facts ff ON ft.file_fact_id = ff.id
ON CONFLICT DO NOTHING;

-- Backfill from function_calls where is_external = true
INSERT INTO shared_artifacts (tenant_id, artifact_type, artifact_name, repo_id,
                              file_id, operation, commit_sha, is_current)
SELECT 'default', 'TUXEDO_SERVICE', fc.callee_name, ff.repo_id,
       ff.file_id, 'CALL', ff.commit_sha, ff.is_current
FROM function_calls fc
JOIN function_facts fn ON fc.caller_id = fn.id
JOIN file_facts ff ON fn.file_fact_id = ff.id
WHERE fc.is_external = 1
ON CONFLICT DO NOTHING;

-- Backfill entry points as service implementations
INSERT INTO shared_artifacts (tenant_id, artifact_type, artifact_name, repo_id,
                              file_id, operation, commit_sha, is_current)
SELECT 'default', 'TUXEDO_SERVICE', fn.function_name, ff.repo_id,
       ff.file_id, 'IMPLEMENT', ff.commit_sha, ff.is_current
FROM function_facts fn
JOIN file_facts ff ON fn.file_fact_id = ff.id
WHERE fn.is_entry_point = 1
ON CONFLICT DO NOTHING;
```

## Files

| File | Change |
|------|--------|
| `src/ecle/backends/structured/schema.py` | Add `SHARED_ARTIFACTS_DDL` to schema creation |
| `src/ecle/backends/structured/sqlite.py` | Add `get_shared_artifacts()`, `get_artifact_summary()`, `get_cross_repo_edges()`, `get_repos()` |
| `src/ecle/ingestion/artifact_registry.py` | **New** — `SharedArtifact`, `normalize_artifact_name()`, `extract_shared_artifacts()`, `register_artifacts()`, `derive_cross_repo_edges()` |
| `src/ecle/ingestion/layer1.py` | Add call to `register_artifacts()` after CIM processing |

## Tests

### Unit Tests (`tests/test_artifact_registry.py`)

1. **Normalization:**
   - `schema1.MY_TABLE` → `MY_TABLE`
   - `billing_account` → `BILLING_ACCOUNT`
   - `SCHEMA2.MY_TABLE` → `MY_TABLE`
   - Service names preserved as-is

2. **Extraction from CIM:**
   - CIM with 3 table reads + 2 table writes → 5 SharedArtifact instances
   - CIM with external_calls (RPC) → TUXEDO_SERVICE artifacts
   - CIM with entry_point functions → IMPLEMENT artifacts
   - CIM with no data_flows → empty list (not an error)

3. **Idempotency:**
   - Register same artifacts twice → row count unchanged
   - Register at new commit → old rows superseded, new rows current

4. **Cross-repo edge derivation:**
   - Repo A writes TABLE_X, Repo B reads TABLE_X → 1 CROSS_REPO edge
   - Repo A calls SERVICE_Y, Repo B implements SERVICE_Y → 1 CROSS_REPO edge
   - Same repo writes and reads TABLE_Z → 0 CROSS_REPO edges (intra-repo, not cross)
   - 3 repos share TABLE_X → 2 CROSS_REPO edges (A→B, A→C) or (all pairs depending on direction)

5. **Backfill:**
   - Existing repo with file_tables → backfill produces correct shared_artifacts rows
   - Backfill is idempotent — running twice produces same result

### Integration Tests

6. **End-to-end ingestion:**
   - Import a .facts.json file → shared_artifacts populated
   - Query `get_shared_artifacts(artifact_name="BILLING_ACCOUNT")` → returns correct repos/files

7. **Multi-repo:**
   - Import two repos that share a table → `get_artifact_summary(min_repo_count=2)` returns it
   - `get_cross_repo_edges(repo_id="repo_A")` returns connection to repo_B

### Performance

8. **Bulk insert:** 10,000 artifacts in < 2 seconds (SQLite)
9. **Lookup latency:** `get_shared_artifacts()` by name < 10ms with index

## Dependencies

- **SPEC-001** (Structured DB Schema) — adding a table to the schema
- **SPEC-002** (SQLite Backend) — adding query methods
- **SPEC-003** (Facts Loader) — integration point in ingestion pipeline
- **SPEC-004** (Topology Edges) — cross-repo edges inserted as topology edges
