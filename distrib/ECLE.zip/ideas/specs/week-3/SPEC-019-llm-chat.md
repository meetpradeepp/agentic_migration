# SPEC-019: LLM-Powered Chat (Full Mode)

**Status**: Spec
**Owner**: Query Engine Engineer
**Files**: src/ecle/query/llm_router.py (new), src/ecle/query/llm_summarizer.py (new), src/ecle/ui/routes.py (update)

## Purpose

Add Claude API integration for natural language chat in Full mode. Currently chat uses pattern matching (Lite mode — structured answers only). Full mode adds:
1. **LLM tool routing**: interpret question → select the right MCP tools / GraphQL queries
2. **LLM summarization**: structured facts → natural language response with evidence

Lite mode continues to work with structured answers (no API calls).

## ADR References

- [ADR-007](../../constitution/decisions/ADR-007-resolved-open-questions.md) — LLM at query time only: tool routing + answer summarization
- [ADR-017](../../constitution/decisions/ADR-017-deployment-modes-lite-full-enterprise.md) — Lite: no LLM. Full: Claude API.

## Interface

```python
class LLMRouter:
    """Interprets NL question and selects tools/queries to answer it."""

    def __init__(self, api_key: str | None = None, model: str = "claude-sonnet-4-20250514"):
        self.client = None
        if api_key:
            from anthropic import Anthropic
            self.client = Anthropic(api_key=api_key)

    def route(self, question: str, repo_id: str,
              available_tools: list[str]) -> list[ToolCall]:
        """
        Send question + tool descriptions to Claude.
        Claude selects which tools to call and with what parameters.
        Returns: list of ToolCall(tool_name, params)
        """

    @property
    def is_available(self) -> bool:
        return self.client is not None


class LLMSummarizer:
    """Synthesizes human-readable answers from structured query results."""

    def __init__(self, api_key: str | None = None, model: str = "claude-sonnet-4-20250514"):
        ...

    def summarize(self, question: str, tool_results: list[dict],
                  repo_id: str) -> str:
        """
        Takes structured results from MCP tools/GraphQL and produces
        a grounded natural language response.

        Rules:
        - Every claim must reference evidence (tool result)
        - Unknown = "I don't have evidence for that"
        - Never hallucinate beyond what the tools returned
        """

    @property
    def is_available(self) -> bool:
        return self.client is not None
```

## Behavior

### Chat Flow (Full Mode)

```
User: "How does billing work and what changed between v2.3 and v2.4?"

Step 1: LLM Router
  → Claude sees: question + list of available tools
  → Claude selects: [ecle_search("billing"), ecle_file_history("batch_rating.ppc")]
  → Returns: [ToolCall("ecle_search", {"query": "billing"}),
              ToolCall("ecle_file_history", {"file_id": "batch_rating.ppc"})]

Step 2: Execute Tools
  → Run each selected tool against the knowledge graph
  → Collect structured results

Step 3: LLM Summarizer
  → Claude receives: question + tool results
  → Claude produces: grounded narrative with evidence citations
  → "The billing subsystem consists of 5 files centered on batch_rating.ppc.
     It reads UNRATED_CDRS and writes RATED_CDRS.
     Evidence: [ecle_search: score 0.52] [ecle_file: batch_rating.ppc]"
```

### Chat Flow (Lite Mode — unchanged)

```
User: "How many tables?"
  → Pattern matching in _route_and_answer() (existing code)
  → Structured DB query
  → Direct answer (no LLM)
```

### Mode Selection

```python
# In chat route:
if settings.llm.enabled and router.is_available:
    # Full mode: LLM routes + summarizes
    tool_calls = router.route(question, repo_id, tool_list)
    results = [execute_tool(tc) for tc in tool_calls]
    answer = summarizer.summarize(question, results, repo_id)
else:
    # Lite mode: pattern matching (existing _route_and_answer)
    answer = _route_and_answer(ctx, question, repo_id)
```

### API Key Configuration

```yaml
# ecle.yaml
llm:
  enabled: true                  # false in Lite mode
  provider: anthropic
  model: claude-sonnet-4-20250514
  api_key_env: ANTHROPIC_API_KEY   # read from env var, never from config file
```

## Dependencies

- SPEC-008 (MCP tools — tool descriptions for routing)
- SPEC-013 (settings — llm.enabled flag)
- SPEC-016 (gaps closed — settings wired into server)
- `anthropic>=0.40.0` (Full mode only — optional dependency)

## Tests

| Test | What's Verified |
|------|----------------|
| `test_lite_mode_no_llm` | LLM disabled → pattern matching used, no API calls |
| `test_router_selects_tools` | Question → correct tool selection (mock LLM) |
| `test_summarizer_grounds_answer` | Answer references tool results, no hallucination |
| `test_api_key_from_env` | Reads ANTHROPIC_API_KEY from environment |
| `test_no_api_key_graceful` | Missing key → Lite mode fallback, no crash |
| `test_chat_full_mode_e2e` | Question → route → execute → summarize (mock LLM) |

## Status Update (2026-04-11)

**Status**: Parked — waiting for LLM API keys. Chat UI removed from web interface in v1.3. MCP tools are the primary query interface. Will re-enable when API keys are available.
