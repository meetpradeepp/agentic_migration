# SPEC-015: Cross-Repo MCP Tools

**Status**: Implemented + Tested (partial — see SPEC-030 for 5 gaps discovered 2026-04-04)
**Owner**: Query Engine Engineer + MCP Tool Engineer
**Files**: `src/ecle/mcp/cross_repo.py` (new), `src/ecle/query/resolvers/cross_repo.py` (new), `src/ecle/query/schema.py` (extension)

## Purpose

Add 6 MCP tools that operate above repo scope — answering enterprise-wide questions about shared artifacts, cross-repo connections, service maps, and cross-repo impact analysis. These tools consume the Shared Artifact Registry (SPEC-014) and expose it through the existing MCP server + GraphQL engine.

## ADR References

- [ADR-020](../../constitution/decisions/ADR-020-cross-repo-mcp-tools.md) — tool definitions, GraphQL queries, routing logic
- [ADR-019](../../constitution/decisions/ADR-019-shared-artifact-registry.md) — the data foundation (shared_artifacts table)
- [ADR-003](../../constitution/decisions/ADR-003-graphql-query-engine.md) — GraphQL as the query layer between MCP tools and backends

## Inputs

- `shared_artifacts` table (SPEC-014)
- `topology_edges` table (cross-repo edges, from SPEC-014 derivation)
- `file_facts`, `function_facts`, `file_tables` (existing structured DB)

## Outputs

- 6 new MCP tools registered on the ECLE MCP server
- 6 new GraphQL query fields + associated types
- 6 new GraphQL resolvers

## Interface

### MCP Tools

Each tool follows the existing pattern: thin function → GraphQL query → resolver → backend.

```python
from __future__ import annotations

from mcp_server import server


@server.tool("ecle_repos")
async def ecle_repos(
    tenant_id: str = "default",
) -> str:
    """List all onboarded repos with aggregate stats."""
    ...


@server.tool("ecle_shared_artifacts")
async def ecle_shared_artifacts(
    artifact_name: str,
    artifact_type: str | None = None,
    tenant_id: str = "default",
) -> str:
    """Find all repos that touch a named artifact (table, service, queue, API)."""
    ...


@server.tool("ecle_artifact_summary")
async def ecle_artifact_summary(
    artifact_type: str | None = None,
    min_repo_count: int = 2,
    tenant_id: str = "default",
) -> str:
    """List all shared artifacts across the enterprise, ranked by sharing breadth."""
    ...


@server.tool("ecle_cross_repo_edges")
async def ecle_cross_repo_edges(
    repo_id: str,
    edge_type: str | None = None,
    tenant_id: str = "default",
) -> str:
    """Show all cross-repo connections (inbound + outbound) for a repo."""
    ...


@server.tool("ecle_cross_repo_impact")
async def ecle_cross_repo_impact(
    artifact_name: str,
    artifact_type: str,
    change_type: str = "SCHEMA_CHANGE",
    tenant_id: str = "default",
) -> str:
    """Assess impact of changing a shared artifact across all repos."""
    ...


@server.tool("ecle_service_map")
async def ecle_service_map(
    service_name: str,
    tenant_id: str = "default",
) -> str:
    """Full map of a service: who implements, who calls, what tables, what it calls."""
    ...
```

### GraphQL Schema Additions

```graphql
extend type Query {
  repos(tenantId: String!): [RepoSummary!]!
  sharedArtifacts(tenantId: String!, artifactName: String!, artifactType: ArtifactType): SharedArtifactResult!
  artifactSummary(tenantId: String!, artifactType: ArtifactType, minRepoCount: Int = 2): ArtifactSummaryResult!
  crossRepoEdges(tenantId: String!, repoId: String!, edgeType: CrossRepoEdgeType): CrossRepoEdgeResult!
  crossRepoImpact(tenantId: String!, artifactName: String!, artifactType: ArtifactType!, changeType: ChangeType!): CrossRepoImpactResult!
  serviceMap(tenantId: String!, serviceName: String!): ServiceMapResult!
}
```

Full type definitions are in `fact-query-engine.md` (already updated by ADR-020).

### GraphQL Resolvers (`resolvers/cross_repo.py`)

```python
from __future__ import annotations

from ecle.backends.structured.sqlite import SQLiteBackend


async def resolve_repos(
    tenant_id: str,
    backend: SQLiteBackend,
) -> list[dict]:
    """Resolver for repos() query.

    Backend: structured DB only.
    Query: SELECT repo_id, COUNT(*) ... FROM file_facts GROUP BY repo_id
    """
    ...


async def resolve_shared_artifacts(
    tenant_id: str,
    artifact_name: str,
    artifact_type: str | None,
    backend: SQLiteBackend,
) -> dict:
    """Resolver for sharedArtifacts() query.

    Backend: structured DB (shared_artifacts table, indexed lookup).
    Joins: shared_artifacts → file_facts for file details.
    Also derives cross-repo links inline from the registry.
    """
    ...


async def resolve_artifact_summary(
    tenant_id: str,
    artifact_type: str | None,
    min_repo_count: int,
    backend: SQLiteBackend,
) -> dict:
    """Resolver for artifactSummary() query.

    Backend: structured DB.
    Query: GROUP BY (artifact_type, artifact_name) HAVING COUNT(DISTINCT repo_id) >= N
    """
    ...


async def resolve_cross_repo_edges(
    tenant_id: str,
    repo_id: str,
    edge_type: str | None,
    backend: SQLiteBackend,
) -> dict:
    """Resolver for crossRepoEdges() query.

    Backend: topology_edges (CROSS_REPO type) + shared_artifacts for enrichment.
    Returns: { outbound: [...], inbound: [...], connectedRepos: N }
    """
    ...


async def resolve_cross_repo_impact(
    tenant_id: str,
    artifact_name: str,
    artifact_type: str,
    change_type: str,
    backend: SQLiteBackend,
) -> dict:
    """Resolver for crossRepoImpact() query.

    Backend: shared_artifacts → topology_edges (bounded traversal, max 2 hops) → file_facts.
    Returns: directly affected repos/files + transitively affected (via cross-repo edges).
    """
    ...


async def resolve_service_map(
    tenant_id: str,
    service_name: str,
    backend: SQLiteBackend,
) -> dict:
    """Resolver for serviceMap() query.

    Backend: shared_artifacts (TUXEDO_SERVICE) + function_facts + file_tables + topology_edges.
    Composes: implementors, callers, outbound service calls, tables touched.
    """
    ...
```

## Behavior

### Tool Routing

| Tool | Primary Backend | Secondary | Latency Target |
|------|----------------|-----------|----------------|
| `ecle_repos` | Structured DB | — | < 50ms |
| `ecle_shared_artifacts` | Structured DB (indexed) | — | < 50ms |
| `ecle_artifact_summary` | Structured DB (aggregation) | — | < 100ms |
| `ecle_cross_repo_edges` | Structured DB + Topology Graph | — | < 100ms |
| `ecle_cross_repo_impact` | Structured DB + Topology Graph | Structured DB (enrichment) | < 500ms |
| `ecle_service_map` | Structured DB + Topology Graph | — | < 200ms |

### Response Format

All tools return JSON matching the GraphQL type definitions. Example for `ecle_shared_artifacts`:

```json
{
  "artifactName": "BILLING_ACCOUNT",
  "artifactType": "TABLE",
  "repos": [
    {
      "repoId": "argtbanhdr",
      "operation": "WRITE",
      "files": [
        { "fileId": "dar_ban_ol.ppc", "lineNumber": 881 },
        { "fileId": "dar_banus.ppc", "lineNumber": 458 }
      ]
    },
    {
      "repoId": "billing-batch",
      "operation": "READ",
      "files": [
        { "fileId": "bl_cycle.ppc", "lineNumber": 220 }
      ]
    }
  ],
  "crossRepoEdges": [
    {
      "writerRepo": "argtbanhdr",
      "readerRepo": "billing-batch",
      "edgeType": "WRITE_READ",
      "fileCount": 3,
      "totalWeight": 7.5
    }
  ]
}
```

### Traversal Bounds (for `ecle_cross_repo_impact`)

- **Max hops:** 2 (through cross-repo edges)
- **Max repos in result:** 50 (if more, return top 50 by weight + count note)
- **Timeout:** 5 seconds — if graph traversal exceeds this, return partial results with `"truncated": true`

### Error Handling

- Artifact not found → return empty repos list, not an error
- Repo not found → return `{ "error": "repo not found", "repoId": "..." }`
- No cross-repo edges → return empty outbound/inbound lists (valid state for single-repo deployments)

## Files

| File | Change |
|------|--------|
| `src/ecle/mcp/cross_repo.py` | **New** — 6 MCP tool functions |
| `src/ecle/query/resolvers/cross_repo.py` | **New** — 6 resolver functions |
| `src/ecle/query/schema.py` | Add cross-repo types and query fields |
| `src/ecle/mcp/server.py` | Import and register cross-repo tools |

## Tests

### Unit Tests (`tests/test_cross_repo_tools.py`)

1. **ecle_repos:**
   - 0 repos → empty list
   - 2 repos → both listed with correct stats
   - Stats match: file_count, function_count from structured DB

2. **ecle_shared_artifacts:**
   - Table in 1 repo → returns 1 repo entry, 0 cross-repo edges
   - Table in 3 repos (1 writer, 2 readers) → 3 repo entries, 2 cross-repo edges
   - Nonexistent artifact → empty repos list
   - Filter by artifact_type → only matching types returned

3. **ecle_artifact_summary:**
   - min_repo_count=2 → only shared artifacts returned
   - min_repo_count=1 → all artifacts returned
   - Filter by artifact_type=TABLE → only tables

4. **ecle_cross_repo_edges:**
   - Repo with 0 cross-repo edges → empty inbound/outbound
   - Repo connected to 3 others → correct inbound + outbound split
   - Filter by edge_type → only matching edge type

5. **ecle_cross_repo_impact:**
   - Table written by 1 repo, read by 2 → directlyAffected has 3 repos
   - 2-hop transitive: repo A→table→repo B→service→repo C → transitivelyAffected includes repo C
   - Traversal bound: more than 50 repos affected → truncated result

6. **ecle_service_map:**
   - Service implemented by 1 repo, called by 2 → correct implementedBy + calledBy
   - Service with table operations → tables listed
   - Service that calls other services → callsOut populated
   - Unknown service → empty implementedBy

### Integration Tests

7. **Full pipeline:** Import 2 repos with shared table → `ecle_shared_artifacts` returns both
8. **MCP server registration:** All 6 tools appear in `server.list_tools()` response
9. **GraphQL execution:** Each query field resolves without error on empty DB

### Performance Tests

10. **ecle_repos** with 50 repos: < 50ms
11. **ecle_shared_artifacts** with 1000 artifacts: < 50ms
12. **ecle_cross_repo_impact** with 10 cross-repo hops: < 500ms

## Dependencies

- **SPEC-014** (Shared Artifact Registry) — the data source for all 6 tools
- **SPEC-006** (GraphQL Schema) — extending the existing schema
- **SPEC-008** (MCP Server) — registering new tools on the existing server
