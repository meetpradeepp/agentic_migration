# SPEC-017: Error Handling + Observability

**Status**: Spec
**Owner**: Backend Engineer
**Files**: src/ecle/errors.py (new), updates across all modules

## Purpose

Implement the error handling and observability model from ADR-021 and the coding standards. Currently errors are caught ad-hoc with bare `except Exception`. This spec adds:
1. Typed exception hierarchy per layer
2. Error propagation model (fail fast at boundaries, graceful inside)
3. Structured logging (JSON, no sensitive data)
4. Graceful degradation levels (vector DB down → structured queries still work)

## ADR References

- [ADR-021](../../constitution/decisions/ADR-021-error-handling-and-observability.md) — error handling and observability design
- [ADR-017](../../constitution/decisions/ADR-017-deployment-modes-lite-full-enterprise.md) — degradation levels per mode

## Interface

### Exception Hierarchy

```python
# src/ecle/errors.py

class ECLEError(Exception):
    """Base exception for all ECLE errors."""

class ConnectorError(ECLEError):
    """Error in source connectors (git, filesystem, document)."""

class ExtractionError(ECLEError):
    """Error during CPG extraction or CIM normalization."""

class IngestionError(ECLEError):
    """Error during FACT ingestion (facts loading, topology, embedding)."""

class QueryError(ECLEError):
    """Error during query execution (GraphQL, MCP tool)."""

class ConfigError(ECLEError):
    """Error in configuration (missing config, invalid values)."""

class StorageError(ECLEError):
    """Error in storage backends (SQLite, ChromaDB, PostgreSQL)."""
```

### Structured Logger

```python
# src/ecle/logging.py

import logging
import json

class StructuredFormatter(logging.Formatter):
    """JSON structured log formatter."""
    def format(self, record):
        return json.dumps({
            "timestamp": self.formatTime(record),
            "level": record.levelname,
            "component": getattr(record, 'component', 'ecle'),
            "message": record.getMessage(),
            **getattr(record, 'context', {}),
        })

def get_logger(component: str) -> logging.Logger:
    """Get a logger for a component. Never logs source code content or secrets."""
```

### Degradation Model

```python
class SystemStatus:
    """Tracks current system health for response annotations."""
    
    FULL_SERVICE = "full"           # all backends operational
    DEGRADED_VECTORS = "degraded_vectors"  # ChromaDB down, search disabled
    DEGRADED_GRAPH = "degraded_graph"      # topology queries fail
    STORAGE_ERROR = "storage_error"        # DB not accessible

    @classmethod
    def check(cls, db, vector_store) -> str:
        """Return current degradation level."""
```

## Behavior

### Where Exceptions Are Raised

| Layer | Exception | When |
|-------|-----------|------|
| Connectors | `ConnectorError` | Git clone fails, auth fails, path not found |
| CPG | `ExtractionError` | Joern fails, facts parsing fails |
| Ingestion | `IngestionError` | DB insert fails, edge computation fails |
| Query | `QueryError` | GraphQL resolver fails, MCP tool fails |
| Config | `ConfigError` | Invalid ecle.yaml, missing required config |
| Storage | `StorageError` | SQLite connection fails, ChromaDB unavailable |

### Error Propagation

```
Boundaries (fail fast):
  CLI command → catch ECLEError → print message + exit code 1
  MCP tool → catch ECLEError → return JSON error message
  GraphQL resolver → catch ECLEError → return GraphQL error
  Web UI route → catch ECLEError → return HTML error card

Inside processing (graceful):
  Facts loader → single file fails → log + continue with next file
  Topology builder → single edge fails → log + continue
  Embedding pipeline → single file fails → log + continue
  Document reader → single doc fails → log + continue
```

### Logging Rules (from coding standards)

```
NEVER log: source code content, secrets, tokens, full file contents, SQL text
SAFE to log: file_ids, function names, table names, commit_shas, counts, latencies
Levels: DEBUG (dev only), INFO (operations), WARNING (degradation), ERROR (failures)
```

## Tests

| Test | What's Verified |
|------|----------------|
| `test_exception_hierarchy` | All exceptions inherit from ECLEError |
| `test_connector_error_no_secrets` | ConnectorError message never contains token |
| `test_ingestion_continues_on_single_failure` | 10 files, 1 bad → 9 ingested, 1 error |
| `test_cli_error_exit_code` | ECLEError in CLI → exit code 1 + message |
| `test_mcp_error_json` | ECLEError in MCP → JSON error response |
| `test_degradation_no_vectors` | ChromaDB unavailable → status = degraded_vectors |
| `test_structured_log_format` | Log output is valid JSON |

## Dependencies

- All existing modules (retrofit error types)
- ADR-021
