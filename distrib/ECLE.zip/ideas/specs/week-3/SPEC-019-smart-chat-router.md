# SPEC-019: Smart Chat Router (Embedding-Based + LLM-Ready)

**Status**: Spec
**Owner**: Query Engine Engineer
**Files**: src/ecle/query/chat_router.py (new), src/ecle/ui/routes.py (update)

## Purpose

Replace the keyword-based chat router with an embedding-based smart router that:
1. Classifies questions by comparing against pre-defined query templates using the existing ONNX embedding model
2. Handles compound questions by chaining multiple tools
3. Composes answers from templates filled with structured data
4. Is designed as a drop-in replacement surface for LLM routing when API keys become available

Covers ~80% of question types. Air-gapped. Zero API dependency.

## ADR References

- [ADR-007](../../constitution/decisions/ADR-007-resolved-open-questions.md) — LLM at query time only
- [ADR-017](../../constitution/decisions/ADR-017-deployment-modes-lite-full-enterprise.md) — Lite: no LLM. Full: Claude API.

## Architecture

```
User question
    │
    ▼
EmbeddingRouter (Lite mode — always available)
    │ embed question → compare against template embeddings
    │ classify: SIMPLE | COMPOUND | UNKNOWN
    │
    ├── SIMPLE (single tool)
    │   "How many tables?" → ecle_stats-like query → template answer
    │
    ├── COMPOUND (tool chain)
    │   "How does billing work?" → search + file detail + edges → composed answer
    │
    └── UNKNOWN
        → semantic search fallback + help text

    ─── When API keys available (Full mode) ───

LLMRouter (drop-in replacement)
    │ question + tool descriptions → Claude selects tools
    │ execute tools → Claude summarizes results
    ▼
Natural language answer with evidence
```

## Interface

```python
class QueryTemplate:
    """A pre-defined question type with tools and answer template."""
    name: str                          # "table_count", "file_lookup", etc.
    description: str                   # template text for embedding comparison
    category: str                      # "simple" | "compound"
    tools: list[ToolStep]              # ordered list of tool calls
    answer_template: str               # format string for composing answer
    extract_params: Callable           # extract parameters from question


@dataclass
class ToolStep:
    tool_name: str                     # "ecle_stats", "ecle_file", etc.
    params: dict[str, str]             # {param_name: "{placeholder}" or literal}
    depends_on: str | None = None      # previous step's output to use


class EmbeddingRouter:
    """Routes questions using embedding similarity against templates."""

    def __init__(self, db: SQLiteBackend, vector_store: ChromaDBStore | None):
        self.db = db
        self.vector_store = vector_store
        self.templates: list[QueryTemplate] = self._build_templates()
        self.template_embeddings: dict[str, list[float]] = {}
        self._warm_embeddings()

    def route(self, question: str, repo_id: str) -> ChatResponse:
        """
        1. Embed the question
        2. Find best matching template by cosine similarity
        3. If similarity > threshold: execute template's tool chain
        4. If below threshold: semantic search fallback
        5. Compose answer from template + tool results
        """

    def _warm_embeddings(self):
        """Pre-compute embeddings for all templates at startup."""

    def _extract_entities(self, question: str, repo_id: str) -> dict:
        """Extract file names, table names, function names from question text.
        Matches against known entities in the DB.
        """


class ChatRouter:
    """Unified router — embedding for Lite, LLM for Full."""

    def __init__(self, db, vector_store, settings):
        self.embedding_router = EmbeddingRouter(db, vector_store)
        self.llm_router = None
        if settings.llm.enabled:
            api_key = os.getenv(settings.llm.api_key_env)
            if api_key:
                self.llm_router = LLMRouter(api_key, settings.llm.model)

    def answer(self, question: str, repo_id: str) -> ChatResponse:
        if self.llm_router and self.llm_router.is_available:
            return self.llm_router.route_and_answer(question, repo_id)
        return self.embedding_router.route(question, repo_id)


@dataclass
class ChatResponse:
    answer: str
    evidence: list[str]         # tool names / DB sources used
    confidence: float           # template match score
    method: str                 # "embedding" | "llm" | "fallback"
```

## Query Templates

```python
TEMPLATES = [
    # ── Simple queries (single tool) ──
    QueryTemplate(
        name="table_count",
        description="How many tables do we have? Count tables. List all tables. Table summary.",
        category="simple",
        tools=[ToolStep("db_query", {"type": "table_summary"})],
        answer_template="{count} distinct tables, {total_ops} operations:\n{table_list}",
    ),
    QueryTemplate(
        name="file_lookup",
        description="What does this file do? Tell me about file X. Describe file.",
        category="simple",
        tools=[ToolStep("db_query", {"type": "file_detail", "file_id": "{entity}"})],
        answer_template="{file_id} ({language}, {execution_model})\n"
                        "Reads: {read_tables}\nWrites: {write_tables}\n"
                        "Functions: {fn_list}\nComplexity: {complexity}",
    ),
    QueryTemplate(
        name="table_lookup",
        description="What files touch table X? Who reads or writes this table?",
        category="simple",
        tools=[ToolStep("db_query", {"type": "table_files", "table_name": "{entity}"})],
        answer_template="Files that touch {table_name}:\n{file_list}",
    ),
    QueryTemplate(
        name="function_callers",
        description="What calls this function? Find callers of function X.",
        category="simple",
        tools=[ToolStep("db_query", {"type": "callers", "function_name": "{entity}"})],
        answer_template="Callers of {function_name}:\n{caller_list}",
    ),
    QueryTemplate(
        name="entry_points",
        description="What are the entry points? Main functions. Where does execution start?",
        category="simple",
        tools=[ToolStep("db_query", {"type": "entry_points"})],
        answer_template="{count} entry points:\n{entry_list}",
    ),
    QueryTemplate(
        name="overview",
        description="Overview of the codebase. Summary. Stats. How big is this repo?",
        category="simple",
        tools=[ToolStep("db_query", {"type": "stats"})],
        answer_template="Knowledge graph for {repo_id}:\n"
                        "  Files: {files}\n  Functions: {functions}\n"
                        "  Edges: {edges}\n  Table ops: {table_ops}",
    ),
    QueryTemplate(
        name="impact",
        description="Impact of changing file X. What's affected? Blast radius.",
        category="simple",
        tools=[ToolStep("db_query", {"type": "impact", "file_id": "{entity}"})],
        answer_template="Impact of changing {file_id}: {count} files affected\n{impact_list}",
    ),
    QueryTemplate(
        name="version_history",
        description="What changed? Version history. How has this file evolved?",
        category="simple",
        tools=[ToolStep("db_query", {"type": "history", "file_id": "{entity}"})],
        answer_template="Version history for {file_id}:\n{version_list}",
    ),

    # ── Cross-repo queries ──
    QueryTemplate(
        name="shared_artifact",
        description="Which repos share this table? Cross-repo connections for artifact.",
        category="simple",
        tools=[ToolStep("db_query", {"type": "shared_artifacts", "artifact_name": "{entity}"})],
        answer_template="{artifact} shared by {repo_count} repos:\n{repo_list}",
    ),
    QueryTemplate(
        name="cross_repo_impact",
        description="Cross-repo impact. What repos are affected by changing this table/service?",
        category="simple",
        tools=[ToolStep("db_query", {"type": "cross_repo_impact", "artifact_name": "{entity}"})],
        answer_template="Cross-repo impact of {artifact}:\n{impact_list}",
    ),

    # ── Compound queries (multi-tool chain) ──
    QueryTemplate(
        name="capability_overview",
        description="How does billing work? Explain the settlement process. Describe this capability.",
        category="compound",
        tools=[
            ToolStep("search", {"query": "{topic}"}),
            ToolStep("db_query", {"type": "file_detail", "file_id": "{search_result_0}"},
                     depends_on="search"),
            ToolStep("db_query", {"type": "edges", "file_id": "{search_result_0}"},
                     depends_on="search"),
        ],
        answer_template="The {topic} subsystem:\n\nKey files:\n{file_summaries}\n\n"
                        "Data flow:\n{edge_summary}\n\nTables involved: {table_list}",
    ),
    QueryTemplate(
        name="data_flow",
        description="Data flow for X. How does data move through the system? Trace the pipeline.",
        category="compound",
        tools=[
            ToolStep("search", {"query": "{topic}"}),
            ToolStep("db_query", {"type": "table_files", "table_name": "{extracted_table}"},
                     depends_on="search"),
        ],
        answer_template="Data flow for {topic}:\n{flow_description}",
    ),
]
```

## Entity Extraction

```python
def _extract_entities(self, question: str, repo_id: str) -> dict:
    """
    Find known entities mentioned in the question.
    
    1. Scan for file names (contains "." + matches file_facts.file_id)
    2. Scan for table names (ALL CAPS words matching file_tables.table_name)
    3. Scan for function names (words with "_" matching function_facts.function_name)
    4. Extract topic words (nouns after removing stop words)
    """
```

## LLM Integration (future — when API keys available)

```yaml
# ecle.yaml — just flip the flag
llm:
  enabled: true
  provider: anthropic
  model: claude-sonnet-4-20250514
  api_key_env: ANTHROPIC_API_KEY  # reads from os.getenv("ANTHROPIC_API_KEY")
```

```python
class LLMRouter:
    """Drop-in replacement for EmbeddingRouter when API keys available."""

    def __init__(self, api_key: str, model: str):
        from anthropic import Anthropic
        self.client = Anthropic(api_key=api_key)
        self.model = model

    @property
    def is_available(self) -> bool:
        return self.client is not None

    def route_and_answer(self, question: str, repo_id: str) -> ChatResponse:
        """
        1. Send question + tool descriptions to Claude
        2. Claude selects tools (tool_use)
        3. Execute selected tools
        4. Send results back to Claude for summarization
        5. Return grounded narrative
        """
```

**API key security rules:**
- Key read from env var only — never from config file, never from DB
- Key never logged at any level
- Key never appears in error messages
- Key never sent to browser (server-side only)
- `.env` file must be in `.gitignore`

## Dependencies

- SPEC-005 (ChromaDB — for embedding questions against templates)
- SPEC-008 (MCP tools — tool execution)
- SPEC-013 (settings — llm.enabled flag)
- SPEC-015 (cross-repo tools — for cross-repo query templates)

## Tests

| Test | What's Verified |
|------|----------------|
| `test_template_matching_exact` | "How many tables" → matches table_count template |
| `test_template_matching_fuzzy` | "Tell me about the tables in this system" → matches table_count |
| `test_entity_extraction_file` | "What does batch_rating.ppc do?" → extracts file_id |
| `test_entity_extraction_table` | "Who writes to BILLING_ACCOUNT?" → extracts table name |
| `test_entity_extraction_function` | "Find callers of sql_error" → extracts function name |
| `test_simple_query_execution` | Template matched → tool executed → answer formatted |
| `test_compound_query_chain` | Multi-tool template → tools execute in order → composed answer |
| `test_unknown_question_fallback` | Unrecognized question → semantic search + help text |
| `test_chat_router_lite_mode` | settings.llm.enabled=false → embedding router used |
| `test_chat_router_full_mode` | settings.llm.enabled=true + key → LLM router used (mock) |
| `test_api_key_from_env` | Reads key from os.getenv, not from config |
| `test_api_key_never_logged` | No logging output contains the key string |
