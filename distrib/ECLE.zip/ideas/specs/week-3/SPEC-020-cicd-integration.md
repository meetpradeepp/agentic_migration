# SPEC-020: CI/CD Integration Testing

**Status**: Spec
**Owner**: DevOps Engineer + Test Engineer
**Files**: tests/integration/, .github/workflows/

## Purpose

End-to-end testing for the continuous integration pipeline:
1. Test `ecle watch` with a real git repo
2. Test `ecle ingest --commit` with actual git diffs
3. Test the GitHub Action template works
4. Test the full pipeline: import → onboard → ingest → query

## What to Build

### Integration Test Suite

```python
# tests/integration/test_full_pipeline.py

class TestFullPipeline:
    """End-to-end: import facts → edges → vectors → query → correct answers."""

    def test_import_then_query(self):
        """Import 18 AMF files → GraphQL query returns correct data."""

    def test_import_then_mcp(self):
        """Import → MCP tool call returns correct data."""

    def test_import_docs_then_cross_tier(self):
        """Import code + docs → cross-tier query finds references."""

    def test_incremental_update(self):
        """Import v1 → modify file → import v2 → version chain correct."""

    def test_remove_and_reimport(self):
        """Import → remove file → reimport → file restored."""


class TestGitIntegration:
    """End-to-end git operations (requires a real git repo)."""

    def test_onboard_local_git_repo(self, tmp_git_repo):
        """Onboard a real git repo → provenance correct."""

    def test_ingest_commit(self, tmp_git_repo):
        """Make a commit → ecle ingest → new version created."""

    def test_watch_detects_commit(self, tmp_git_repo):
        """Start watcher → make commit → watcher picks it up."""


class TestDocumentOnboarding:
    """End-to-end document pipeline."""

    def test_onboard_docs_cli(self):
        """ecle onboard-docs ./fixtures/sample_docs/ → docs in DB + vectors."""

    def test_cross_reference_detection(self):
        """Doc mentions UNRATED_CDRS → cross-reference to batch_rating.ppc found."""
```

### GitHub Action Validation

```yaml
# .github/workflows/ecle-test.yml
name: ECLE Test
on: [push, pull_request]
jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-python@v5
        with:
          python-version: '3.11'
      - run: pip install -e ".[dev]"
      - run: python -m pytest tests/ -v
      - run: python -m ruff check src/ tests/
```

### Performance Benchmarks

```python
# tests/benchmarks/test_scale.py

def test_import_410_files():
    """410 files import in < 60 seconds."""

def test_query_latency():
    """GraphQL query on 410-file DB in < 50ms."""

def test_mcp_tool_latency():
    """MCP tool call on 410-file DB in < 100ms (excluding vector init)."""
```

## Dependencies

- All SPEC-001 through SPEC-018 (tests exercise the full stack)

## Tests

This IS the test spec — the tests are the deliverable.
