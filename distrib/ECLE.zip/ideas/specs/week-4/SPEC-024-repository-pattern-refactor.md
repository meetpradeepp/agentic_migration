# SPEC-024: Repository Pattern — Eliminate Raw SQL from Domain Code

**Status**: Spec
**Owner**: Platform Architect
**ADR**: [ADR-023](../../constitution/decisions/ADR-023-repository-pattern-for-data-access.md)

## Purpose

Move all raw SQL out of domain modules into the structured backend. Domain code calls named, typed methods only. This makes the backend swappable (SQLite → PostgreSQL) without touching domain logic.

## Current State (the problem)

```
Domain module                    Raw SQL calls   Should be
─────────────────────────────────────────────────────────
topology.py                      22              0
artifact_registry.py             15              0
document_embedder.py             14              0
chat_router.py                   10              0
app.py (GraphQL resolvers)        8              0
facts_loader.py                   8              0
embedding_pipeline.py             5              0
louvain.py                        5              0
mcp/server.py + cross_repo.py    5              0
routes.py (UI)                    3              0
incremental.py                    3              0
─────────────────────────────────────────────────────────
Total                            ~98             0
```

## Architecture

### Layer 1: Interface Definition

```python
# src/ecle/backends/structured/interface.py

from typing import Protocol, runtime_checkable

@runtime_checkable
class IStructuredBackend(Protocol):
    """Abstract interface for all structured data access.
    
    Domain code depends on this interface, never on a concrete backend.
    SQLiteBackend and PostgreSQLBackend both implement this.
    """

    # ── Connection lifecycle ──────────────────────────────────────
    def connect(self) -> None: ...
    def close(self) -> None: ...

    # ── File facts ────────────────────────────────────────────────
    def get_current_file(self, file_id: str, repo_id: str) -> dict | None: ...
    def get_file_by_id(self, fact_id: str) -> dict | None: ...
    def get_file_history(self, file_id: str, repo_id: str) -> list[dict]: ...
    def get_stats(self, repo_id: str) -> dict: ...
    def list_files(self, repo_id: str, *, language: str | None = None, 
                   limit: int = 100, offset: int = 0) -> list[dict]: ...
    def list_repos(self) -> list[str]: ...
    def get_file_tables(self, file_fact_id: str) -> list[dict]: ...
    def get_file_includes(self, file_fact_id: str) -> list[dict]: ...
    def get_file_definitions(self, file_fact_id: str) -> list[dict]: ...

    # ── Function facts ────────────────────────────────────────────
    def get_functions_for_file(self, file_fact_id: str) -> list[dict]: ...
    def get_function_by_id(self, function_id: str) -> dict | None: ...
    def get_function_table_ops(self, function_id: str) -> list[dict]: ...
    def get_function_calls(self, caller_id: str) -> list[dict]: ...
    def find_callers_of(self, callee_name: str, repo_id: str) -> list[dict]: ...

    # ── Table operations ──────────────────────────────────────────
    def find_files_by_table(self, table_name: str, *, repo_id: str) -> list[dict]: ...
    def get_table_names(self, repo_id: str) -> list[str]: ...
    def count_distinct_tables(self, repo_id: str) -> int: ...

    # ── Topology / edges ──────────────────────────────────────────
    def get_topology_edges(self, repo_id: str) -> list[dict]: ...
    def get_edges_for_file(self, file_id: str, repo_id: str) -> list[dict]: ...
    def get_neighbors(self, file_id: str, repo_id: str, *, 
                      min_weight: float = 0.0, max_hops: int = 1) -> list[dict]: ...
    def impact_traversal(self, file_id: str, *, max_hops: int = 3,
                         min_weight: float = 0.5, repo_id: str) -> list[dict]: ...
    def upsert_edge(self, edge: dict) -> None: ...
    def delete_edges_for_file(self, file_id: str, repo_id: str) -> int: ...

    # ── Clustering ────────────────────────────────────────────────
    def get_files_for_clustering(self, repo_id: str) -> list[dict]: ...
    def get_cluster_languages(self, file_ids: list[str], repo_id: str) -> list[dict]: ...
    def update_file_cluster(self, file_fact_id: str, cluster_id: str) -> None: ...
    def upsert_cluster(self, cluster: dict) -> None: ...
    def get_clusters(self, repo_id: str) -> list[dict]: ...

    # ── Documents ─────────────────────────────────────────────────
    def get_document(self, doc_id: str) -> dict | None: ...
    def upsert_document(self, doc: dict) -> None: ...
    def get_document_chunks(self, doc_id: str) -> list[dict]: ...
    def insert_document_chunk(self, chunk: dict) -> None: ...
    def find_cross_references(self, repo_id: str, ref_type: str) -> list[dict]: ...

    # ── Shared artifacts ──────────────────────────────────────────
    def register_artifact(self, artifact: dict) -> None: ...
    def find_shared_artifacts(self, *, artifact_type: str | None = None,
                              tenant_id: str = "default") -> list[dict]: ...
    def find_cross_repo_edges(self, tenant_id: str) -> list[dict]: ...

    # ── Ingestion internals ───────────────────────────────────────
    def upsert_file_facts(self, data: dict) -> None: ...
    def supersede_file(self, file_fact_id: str, superseded_by: str, at: str) -> None: ...
    def supersede_functions(self, file_fact_id: str) -> None: ...
    def cleanup_retired_children(self, file_fact_id: str) -> None: ...
    def insert_file_tables(self, rows: list[dict]) -> None: ...
    def insert_functions(self, rows: list[dict]) -> None: ...
    def insert_function_table_ops(self, rows: list[dict]) -> None: ...
    def insert_function_calls(self, rows: list[dict]) -> None: ...
    def insert_file_includes(self, rows: list[dict]) -> None: ...
    def insert_file_definitions(self, rows: list[dict]) -> None: ...
    def mark_entry_points(self, function_ids: list[str]) -> None: ...
```

### Layer 2: SQLite Implementation

Existing `SQLiteBackend` already implements ~15 of these methods. The refactor adds the remaining ~35 by extracting SQL from domain modules.

```python
# src/ecle/backends/structured/sqlite.py (additions)

class SQLiteBackend:
    # ... existing methods stay ...

    # NEW: from topology.py
    def get_topology_edges(self, repo_id: str) -> list[dict]:
        return self._fetchall(
            "SELECT * FROM topology_edges WHERE repo_id = ? ORDER BY weight DESC",
            (repo_id,),
        )

    def get_files_for_clustering(self, repo_id: str) -> list[dict]:
        return self._fetchall(
            "SELECT id, file_id FROM file_facts WHERE repo_id = ? AND is_current = 1",
            (repo_id,),
        )

    # NEW: from chat_router.py
    def count_distinct_tables(self, repo_id: str) -> int:
        row = self._fetchone(
            "SELECT COUNT(DISTINCT ft.table_name) as cnt "
            "FROM file_tables ft JOIN file_facts ff ON ft.file_fact_id = ff.id "
            "WHERE ff.repo_id = ? AND ff.is_current = 1",
            (repo_id,),
        )
        return row["cnt"] if row else 0

    # NEW: from facts_loader.py
    def cleanup_retired_children(self, file_fact_id: str) -> None:
        """Delete all child rows for a retired file (FK-safe order)."""
        self._execute(
            "DELETE FROM function_calls WHERE caller_id IN "
            "(SELECT id FROM function_facts WHERE file_fact_id = ?)",
            (file_fact_id,),
        )
        self._execute(
            "DELETE FROM function_table_ops WHERE function_id IN "
            "(SELECT id FROM function_facts WHERE file_fact_id = ?)",
            (file_fact_id,),
        )
        for table in ("function_facts", "file_tables", "file_includes", "file_definitions"):
            self._execute(f"DELETE FROM {table} WHERE file_fact_id = ?", (file_fact_id,))
```

### Layer 3: Domain Code Migration

Each domain module stops writing SQL and calls backend methods:

```python
# BEFORE (topology.py):
rows = self.db.fetchall(
    "SELECT DISTINCT ft.table_name FROM file_tables ft "
    "JOIN file_facts ff ON ft.file_fact_id = ff.id "
    "WHERE ff.repo_id = ? AND ff.is_current = 1 AND ft.operation = 'SELECT'",
    (self.repo_id,),
)

# AFTER (topology.py):
rows = self.db.get_table_readers(self.repo_id)
```

```python
# BEFORE (louvain.py):
edges = self.db.fetchall(
    "SELECT source_file, target_file, weight "
    "FROM topology_edges WHERE repo_id = ?",
    (self.repo_id,),
)

# AFTER (louvain.py):
edges = self.db.get_topology_edges(self.repo_id)
```

### Layer 4: Make Low-Level Methods Private

After all domain code is migrated:

```python
# execute()  → _execute()   (backend-internal only)
# fetchall() → _fetchall()  (backend-internal only)
# fetchone() → _fetchone()  (backend-internal only)
# insert()   → _insert()    (backend-internal only)
```

## Migration Plan (incremental, one PR per module)

| PR | Module | SQL calls to migrate | Depends on |
|----|--------|---------------------|------------|
| 1 | Interface definition (`interface.py`) | 0 (defines Protocol) | None |
| 2 | `topology.py` | 22 | PR 1 |
| 3 | `artifact_registry.py` | 15 | PR 1 |
| 4 | `document_embedder.py` | 14 | PR 1 |
| 5 | `chat_router.py` | 10 | PR 1 |
| 6 | `app.py` (GraphQL) | 8 | PR 1 |
| 7 | `facts_loader.py` | 8 | PR 1 |
| 8 | `embedding_pipeline.py` | 5 | PR 1 |
| 9 | `louvain.py` | 5 | PR 1 |
| 10 | `mcp/server.py + cross_repo.py` | 5 | PR 1 |
| 11 | `routes.py` (UI) | 3 | PR 1 |
| 12 | `incremental.py` | 3 | PR 1 |
| 13 | Make low-level methods private | All | PRs 2-12 |

Each PR is independently mergeable. Tests pass at every step.

## Naming Conventions

Methods follow a consistent naming pattern:

| Pattern | Example | Use |
|---------|---------|-----|
| `get_{entity}` | `get_current_file(file_id, repo_id)` | Single lookup by key |
| `list_{entities}` | `list_files(repo_id, limit, offset)` | Paginated listing |
| `find_{entities}_by_{criteria}` | `find_files_by_table(table_name)` | Search by attribute |
| `count_{entities}` | `count_distinct_tables(repo_id)` | Aggregation |
| `upsert_{entity}` | `upsert_file_facts(data)` | Create or replace |
| `insert_{entities}` | `insert_functions(rows)` | Batch insert |
| `delete_{entities}_for_{parent}` | `delete_edges_for_file(file_id)` | Cascade delete |
| `{action}_{entity}` | `supersede_file(id)`, `mark_entry_points(ids)` | State transitions |

## Tests

| Test | What's Verified |
|------|----------------|
| `test_interface_compliance` | SQLiteBackend implements all IStructuredBackend methods |
| `test_topology_uses_interface` | topology.py has zero raw SQL calls |
| `test_migration_per_module` | Each migrated module passes existing tests without change |
| `test_mock_backend` | Domain logic works with a mock IStructuredBackend |
| `test_private_methods` | `execute`, `fetchall`, `fetchone` are not called from outside backend |

## Dependencies

- ADR-023 (Repository pattern decision)
- ADR-002 (Hybrid storage — PostgreSQL is the Phase 4 target)
- SPEC-001 (SQLite backend — the module being extended)

## Not In Scope

- PostgreSQL implementation — that's a separate spec when Phase 4 begins
- Vector backend interface — ChromaDB/Qdrant already have a clean `IVectorStore` pattern
- Graph backend interface — deferred until Neo4j integration
