# SPEC-023: Web UI Service — Standalone Deployment

**Status**: Spec
**Owner**: Query Engine Engineer
**Files**: src/ecle/ui/routes.py (refactor), src/ecle/ui/api_client.py (new)

## Purpose

Make the Web UI deployable as a standalone service that communicates with the GraphQL API over HTTP. Today the UI imports DB connections directly. Tomorrow it calls the API endpoint — making it a pure frontend service that can be scaled, cached, and deployed independently.

## ADR References

- [ADR-017](../../constitution/decisions/ADR-017-deployment-modes-lite-full-enterprise.md) — Deployment modes
- [SPEC-022](SPEC-022-graphql-api-service.md) — GraphQL API as the data access point

## Architecture

### UI as HTTP Client to GraphQL API

```
User's browser
    │ HTML + htmx
    ▼
Web UI Service (port 8742)
    │ GraphQL over HTTP
    ▼
GraphQL API Service (port 8741)
    │
    ├──→ Structured DB
    ├──→ Vector Index
    └──→ Topology Graph
```

### API Client Module

```python
# src/ecle/ui/api_client.py

class ECLEApiClient:
    """Client for the GraphQL API. Used by UI routes when running separately."""

    def __init__(self, api_url: str = "http://localhost:8741"):
        self.api_url = api_url.rstrip("/")

    async def query(self, graphql_query: str, variables: dict = None) -> dict:
        """Execute a GraphQL query against the API."""
        import httpx
        async with httpx.AsyncClient() as client:
            r = await client.post(
                f"{self.api_url}/graphql",
                json={"query": graphql_query, "variables": variables or {}},
                timeout=30.0,
            )
            r.raise_for_status()
            return r.json()

    async def get_stats(self, repo_id: str) -> dict:
        """Get knowledge graph stats for a repo."""
        result = await self.query(
            '{ stats(repoId: "%s") { files functions edges tableOps vectors } }' % repo_id
        )
        return result.get("data", {}).get("stats", {})

    async def get_repos(self) -> list[str]:
        """Get list of repo IDs."""
        result = await self.query(
            '{ files(limit: 0) { fileId } }'  # placeholder — needs repos query
        )
        # For now, get distinct repo_ids from the REST endpoint
        import httpx
        async with httpx.AsyncClient() as client:
            r = await client.get(f"{self.api_url}/")
            data = r.json()
            return list(data.get("repositories", {}).keys())

    async def search(self, query: str, repo_id: str, top_k: int = 5) -> list[dict]:
        """Semantic search."""
        result = await self.query(
            '{ search(query: "%s", repoId: "%s", topK: %d) { score fileId functionName layer } }'
            % (query, repo_id, top_k)
        )
        return result.get("data", {}).get("search", [])

    async def import_facts(self, facts_dir: str, repo_id: str) -> dict:
        """Trigger import via REST API."""
        import httpx
        async with httpx.AsyncClient() as client:
            r = await client.post(
                f"{self.api_url}/api/import",
                json={"facts_dir": facts_dir, "repo_id": repo_id},
                timeout=300.0,
            )
            return r.json()
```

### Dual-Mode Pattern for UI Routes

```python
# src/ecle/ui/routes.py — each route works in both modes

async def _get_data(request: Request):
    """Get data access — local or remote depending on deployment mode."""
    # Check if we have a local context (all-in-one mode)
    try:
        from ecle.query.app import get_context
        ctx = get_context()
        if ctx and ctx.db:
            return LocalDataAccess(ctx)
    except Exception:
        pass

    # Remote mode — use API client
    api_url = os.getenv("ECLE_API_URL", "http://localhost:8741")
    return RemoteDataAccess(api_url)


class LocalDataAccess:
    """Direct DB access (Lite mode, all-in-one)."""
    def __init__(self, ctx):
        self.ctx = ctx
    async def get_stats(self, repo_id):
        return self.ctx.db.get_stats(repo_id)
    async def get_repos(self):
        rows = self.ctx.db.fetchall(
            "SELECT DISTINCT repo_id FROM file_facts WHERE is_current = 1"
        )
        return [r["repo_id"] for r in rows]


class RemoteDataAccess:
    """GraphQL API access (Full/Enterprise mode, separate services)."""
    def __init__(self, api_url):
        self.client = ECLEApiClient(api_url)
    async def get_stats(self, repo_id):
        return await self.client.get_stats(repo_id)
    async def get_repos(self):
        return await self.client.get_repos()
```

## Configuration

```yaml
# ecle.yaml — when running UI separately
server:
  component: ui
  port: 8742

api:
  url: http://localhost:8741    # GraphQL API endpoint
  # or: http://ecle-api:8741   (Docker)
  # or: http://ecle-api.ecle.svc:8741  (K8s)
```

```bash
# CLI
ecle serve --component ui --port 8742 --api-url http://localhost:8741

# Docker
docker run -e ECLE_API_URL=http://ecle-api:8741 -p 8742:8742 ecle-ui

# Environment variable
export ECLE_API_URL=http://localhost:8741
ecle serve --component ui
```

## Behavior

### Lite Mode (default — all-in-one)
```
ecle serve → create_full_app()
  UI routes use LocalDataAccess → direct DB reads → zero HTTP overhead
  Same behavior as today. No config needed.
```

### Full/Enterprise Mode (separate services)
```
ecle serve --component ui → create_ui_app()
  UI routes use RemoteDataAccess → GraphQL API over HTTP
  ECLE_API_URL must be set
  UI service is stateless — no DB connection, no vector store
  Can be cached, load-balanced, CDN-fronted
```

### Fallback
```
If ECLE_API_URL is set but API is unreachable:
  → UI shows error: "Cannot connect to ECLE API at {url}"
  → Health endpoint returns: {"status": "api_unreachable"}
  → Does NOT fall back to local DB (that would be a config error)
```

## Dependencies

- SPEC-022 (GraphQL API service — the backend)
- SPEC-012 (Web UI — existing routes and templates)
- SPEC-013 (Settings — api.url config)
- `httpx` (already in deps — for async HTTP client)

## Tests

| Test | What's Verified |
|------|----------------|
| `test_local_data_access` | LocalDataAccess reads DB directly (Lite mode) |
| `test_remote_data_access` | RemoteDataAccess calls GraphQL API (mock HTTP) |
| `test_ui_standalone` | create_ui_app() serves /ui/* but NOT /graphql |
| `test_api_url_from_env` | ECLE_API_URL env var used for remote mode |
| `test_api_unreachable` | Clear error when API is down |
| `test_backward_compat` | create_full_app() still works (all-in-one) |
