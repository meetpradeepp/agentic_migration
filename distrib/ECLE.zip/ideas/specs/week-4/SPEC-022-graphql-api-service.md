# SPEC-022: GraphQL API Service — Standalone Deployment

**Status**: Spec
**Owner**: Query Engine Engineer
**Files**: src/ecle/query/app.py (refactor), src/ecle/server.py (new standalone entry)

## Purpose

Make the GraphQL API deployable as a standalone service with its own endpoint, independent of the Web UI and MCP server. Today all three are bundled in `ecle serve`. Tomorrow they can run as separate processes/containers, each with their own port, scaling, and health checks.

```
TODAY (bundled):
  ecle serve → port 8741
    ├── /graphql
    ├── /ui/*
    └── MCP (stdio, separate process)

TOMORROW (separable):
  ecle serve --component api     → port 8741  (GraphQL + REST API only)
  ecle serve --component ui      → port 8742  (Web UI only, calls API)
  ecle serve --component mcp     → port 8080  (MCP HTTP, calls API)
  ecle serve                     → port 8741  (all-in-one, backward compat)
```

## ADR References

- [ADR-017](../../constitution/decisions/ADR-017-deployment-modes-lite-full-enterprise.md) — Deployment modes
- [ADR-003](../../constitution/decisions/ADR-003-graphql-query-engine.md) — GraphQL as the query layer

## Architecture

### The Key Change: API as the Single Data Access Point

```
Current:
  Web UI  → imports get_context() → reads DB directly
  MCP     → imports _db → reads DB directly
  GraphQL → reads DB directly

Target:
  Web UI  → HTTP calls to GraphQL API → reads DB
  MCP     → HTTP calls to GraphQL API → reads DB
  GraphQL → reads DB directly (the ONLY thing that touches storage)
```

This means:
- Only the GraphQL API needs DB connection config
- UI and MCP are stateless HTTP clients
- API can be scaled with read replicas
- UI and MCP can be scaled independently

### Component Interfaces

```
GraphQL API (SPEC-022 — this spec):
  Port: 8741 (configurable)
  Endpoints:
    POST /graphql          — GraphQL queries
    GET  /graphql          — GraphQL playground
    GET  /                 — server status + repo list
    GET  /health           — health check (for K8s probes)
    POST /api/import       — trigger import (REST)
    POST /api/ingest       — trigger incremental ingest (REST)
    POST /api/cluster      — trigger clustering (REST)
    GET  /api/repos        — list repos (REST)

Web UI (SPEC-023):
  Port: 8742 (configurable)
  Endpoints:
    GET  /ui/*             — all UI routes
    POST /ui/onboard       — triggers import via API
    POST /ui/chat/ask      — routes question via API
  Backend:
    Calls GraphQL API at ECLE_API_URL (default: http://localhost:8741)

MCP Server (SPEC-021, already exists):
  Port: 8080 (HTTP) or stdio (VS Code)
  Backend:
    Lite: reads DB directly (same process)
    Full/Enterprise: calls GraphQL API at ECLE_API_URL
```

## Interface

### GraphQL API Entry Point

```python
# src/ecle/server.py

def create_api_app(settings: Settings) -> FastAPI:
    """Create the GraphQL API app (no UI routes)."""
    db = create_db(settings)
    vector = create_vector(settings)
    set_context(QueryContext(db=db, vector_store=vector))

    app = FastAPI(title="ECLE API", version="0.1.0")

    # GraphQL
    schema = strawberry.Schema(query=Query)
    app.include_router(GraphQLRouter(schema), prefix="/graphql")

    # REST endpoints for operations
    app.include_router(api_router)

    # Health check
    @app.get("/health")
    def health():
        status = SystemStatus.check(db, vector)
        return {"status": status, "db": "connected", "vector": "connected" if vector else "none"}

    return app


def create_full_app(settings: Settings) -> FastAPI:
    """Create the all-in-one app (API + UI). Backward compatible with ecle serve."""
    app = create_api_app(settings)

    # Mount UI routes on the same app
    from ecle.ui.routes import router as ui_router
    app.include_router(ui_router)

    return app
```

### CLI Integration

```bash
# All-in-one (backward compat, default)
ecle serve

# Standalone API only
ecle serve --component api --port 8741

# Standalone UI only (connects to API)
ecle serve --component ui --port 8742 --api-url http://localhost:8741

# All components with custom ports
ecle serve --component all --port 8741
```

### Configuration

```yaml
# ecle.yaml additions
server:
  host: 127.0.0.1
  port: 8741
  component: all       # all | api | ui

api:
  url: http://localhost:8741   # used by UI and MCP when running separately
```

## Behavior

### Lite Mode (single process)
```
ecle serve → runs create_full_app()
  All components in one process, one port
  DB accessed directly (in-process)
  No HTTP overhead between components
```

### Full Mode (docker compose)
```
docker compose up
  ecle-api:   ecle serve --component api --port 8741
  ecle-ui:    ecle serve --component ui --port 8742 --api-url http://ecle-api:8741
  ecle-mcp:   ECLE_MCP_TRANSPORT=streamable-http --port 8080
  postgresql: port 5432
  qdrant:     port 6334
```

### Enterprise Mode (K8s)
```
API pods:    N replicas, autoscaled by latency
UI pods:     N replicas, stateless
MCP pods:    N replicas, autoscaled by connections
Each pod connects to shared PostgreSQL + Qdrant
```

## What Changes in Existing Code

### Web UI Routes (src/ecle/ui/routes.py)

```python
# Today: imports get_context() → reads DB directly
from ecle.query.app import get_context
ctx = get_context()
ctx.db.get_stats(repo_id)

# Tomorrow: calls GraphQL API over HTTP (when running separately)
import httpx

async def _query_api(graphql_query: str) -> dict:
    """Call GraphQL API — in-process or HTTP depending on deployment."""
    if _api_is_local():
        # Same process — call directly (Lite mode, zero overhead)
        from ecle.query.app import get_context
        ctx = get_context()
        return execute_locally(ctx, graphql_query)
    else:
        # Separate process — HTTP call (Full/Enterprise mode)
        api_url = settings.api.url
        async with httpx.AsyncClient() as client:
            r = await client.post(f"{api_url}/graphql", json={"query": graphql_query})
            return r.json()
```

### MCP Server (src/ecle/mcp/server.py)

```python
# Today: reads _db directly
_ensure_db()
rows = _db.get_stats(repo_id)

# Tomorrow: option to call API instead of DB directly
if settings.api.url:
    # Remote mode — call GraphQL API
    result = httpx.post(f"{settings.api.url}/graphql", json={"query": stats_query})
else:
    # Local mode — read DB directly (current behavior, Lite mode)
    _ensure_db()
    rows = _db.get_stats(repo_id)
```

## Dependencies

- SPEC-006 (GraphQL schema — already covers all queries)
- SPEC-013 (Settings — add server.component and api.url config)
- SPEC-017 (Error handling — health check uses SystemStatus)

## Tests

| Test | What's Verified |
|------|----------------|
| `test_api_app_standalone` | create_api_app() serves /graphql but NOT /ui/* |
| `test_full_app_has_ui` | create_full_app() serves both /graphql AND /ui/* |
| `test_health_endpoint` | GET /health returns status + backend info |
| `test_api_rest_import` | POST /api/import triggers import, returns result |
| `test_component_flag` | --component api starts API only |
| `test_ui_calls_api_http` | UI routes call GraphQL over HTTP when api.url is set |
| `test_backward_compat` | ecle serve (no flags) works exactly as before |
