# SPEC-021: Remote MCP Server — Streamable HTTP Transport with Static Auth

**Status**: Draft
**Owner**: MCP Tool Engineer
**Files**: `src/ecle/mcp/server.py`, `.mcp.json`, `.vscode/mcp.json`

## Purpose

Enable the ECLE MCP server to run as a shared backend service over HTTP, so multiple agents, IDEs, and CI/CD pipelines can query the same knowledge graph without local DB setup. Adds `streamable-http` transport alongside existing `stdio`, with static Bearer token authentication.

## ADR References

- [ADR-022](../../constitution/decisions/ADR-022-remote-mcp-transport.md) — Decision: streamable-http + static auth
- [ADR-017](../../constitution/decisions/ADR-017-deployment-modes-lite-full-enterprise.md) — Deployment modes (Docker/K8s need remote MCP)
- [SPEC-008](../week-1/SPEC-008-mcp-server.md) — Original MCP server (stdio only)

## Inputs

- Environment variables controlling transport and auth:

| Variable | Default | Description |
|----------|---------|-------------|
| `ECLE_MCP_TRANSPORT` | `stdio` | Transport: `stdio` or `streamable-http` |
| `ECLE_MCP_HOST` | `0.0.0.0` | Bind address (HTTP only) |
| `ECLE_MCP_PORT` | `8080` | Listen port (HTTP only) |
| `ECLE_MCP_AUTH_TOKEN` | _(none)_ | Required for HTTP. Server refuses to start without it. |
| `ECLE_DB` | `ecle.db` | SQLite path (unchanged) |
| `ECLE_VECTORS` | `./vectors` | ChromaDB path (unchanged) |
| `ECLE_REPO_ID` | `billing-service` | Default repo (unchanged) |

## Outputs

- HTTP endpoint at `http://{host}:{port}/mcp` serving MCP protocol over streamable-http
- All 15 existing tools available over both transports (identical signatures and responses)
- 401 Unauthorized for missing/invalid Bearer token on HTTP requests

## Interface

### Transport Selection (server.py entry point)

```python
if __name__ == "__main__":
    transport = os.getenv("ECLE_MCP_TRANSPORT", "stdio")
    if transport == "streamable-http":
        token = os.getenv("ECLE_MCP_AUTH_TOKEN", "")
        if not token:
            sys.exit("ECLE_MCP_AUTH_TOKEN is required for streamable-http transport")
        host = os.getenv("ECLE_MCP_HOST", "0.0.0.0")
        port = int(os.getenv("ECLE_MCP_PORT", "8080"))
        mcp.run(transport="streamable-http", host=host, port=port)
    else:
        mcp.run(transport="stdio")
```

### Auth Middleware (Starlette)

FastMCP's `streamable-http` transport creates a Starlette ASGI app internally. We inject auth middleware via FastMCP's `custom_starlette_app` pattern or by wrapping the ASGI app.

```python
from starlette.middleware import Middleware
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.responses import JSONResponse

class BearerAuthMiddleware(BaseHTTPMiddleware):
    """Validates static Bearer token on every HTTP request."""

    def __init__(self, app, token: str):
        super().__init__(app)
        self.token = token

    async def dispatch(self, request, call_next):
        auth = request.headers.get("Authorization", "")
        if auth != f"Bearer {self.token}":
            return JSONResponse(
                {"error": "Unauthorized"},
                status_code=401,
            )
        return await call_next(request)
```

### Client Configuration

**Remote (HTTP)** — `.mcp.json`:
```json
{
  "mcpServers": {
    "ecle-mcp-server": {
      "type": "http",
      "url": "http://localhost:8080/mcp",
      "headers": {
        "Authorization": "Bearer ${ECLE_MCP_TOKEN}"
      }
    }
  }
}
```

**Local (stdio)** — `.vscode/mcp.json` (unchanged):
```json
{
  "servers": {
    "ecle-mcp-server": {
      "type": "stdio",
      "command": "${workspaceFolder}/.venv/Scripts/python.exe",
      "args": ["-m", "ecle.mcp.server"],
      "env": { ... }
    }
  }
}
```

**Both side-by-side** — `.mcp.json` can have two entries:
```json
{
  "mcpServers": {
    "ecle-local": {
      "type": "stdio",
      "command": ".venv/Scripts/python.exe",
      "args": ["-m", "ecle.mcp.server"],
      "env": { "ECLE_DB": "ecle.db", "ECLE_VECTORS": "vectors", "ECLE_REPO_ID": "billing-service", "PYTHONPATH": "src" }
    },
    "ecle-remote": {
      "type": "http",
      "url": "http://ecle-server.internal:8080/mcp",
      "headers": {
        "Authorization": "Bearer ${ECLE_MCP_TOKEN}"
      }
    }
  }
}
```

## Behavior

### Startup — stdio (unchanged)
```
python -m ecle.mcp.server
  → ECLE_MCP_TRANSPORT not set → defaults to "stdio"
  → mcp.run(transport="stdio")
  → Background thread pre-warms vector store
  → Ready for IDE connection via stdin/stdout
```

### Startup — streamable-http
```
ECLE_MCP_TRANSPORT=streamable-http \
ECLE_MCP_AUTH_TOKEN=secret123 \
python -m ecle.mcp.server
  → Validates ECLE_MCP_AUTH_TOKEN is set (exits if missing)
  → Injects BearerAuthMiddleware into FastMCP's ASGI app
  → mcp.run(transport="streamable-http", host="0.0.0.0", port=8080)
  → Background thread pre-warms vector store
  → Listening on http://0.0.0.0:8080/mcp
```

### Auth Flow
```
Client → POST /mcp (Authorization: Bearer secret123)
  → BearerAuthMiddleware checks header
  → Match → forward to FastMCP handler → tool execution → JSON response
  → No match → 401 {"error": "Unauthorized"}

Client → POST /mcp (no Authorization header)
  → 401 {"error": "Unauthorized"}
```

### Safety: No Open Remote Servers
- If `ECLE_MCP_TRANSPORT=streamable-http` and `ECLE_MCP_AUTH_TOKEN` is empty/unset → `sys.exit` with clear error message.
- stdio transport ignores `ECLE_MCP_AUTH_TOKEN` entirely — no auth check for local process.

### Docker Compose Example
```yaml
services:
  ecle-mcp:
    image: ecle:latest
    command: python -m ecle.mcp.server
    environment:
      ECLE_MCP_TRANSPORT: streamable-http
      ECLE_MCP_HOST: "0.0.0.0"
      ECLE_MCP_PORT: "8080"
      ECLE_MCP_AUTH_TOKEN: "${ECLE_MCP_AUTH_TOKEN}"
      ECLE_DB: /data/ecle.db
      ECLE_VECTORS: /data/vectors
    ports:
      - "8080:8080"
    volumes:
      - ecle-data:/data
```

## Dependencies

- SPEC-008 (original MCP server — this spec extends it)
- `mcp[cli]>=1.5.0` — already supports `streamable-http` transport (uses Starlette + uvicorn internally)
- `starlette` — already a transitive dependency of `mcp[cli]` and `fastapi`
- No new pip dependencies required

## Tests

| Test | What's Verified |
|------|----------------|
| `test_transport_default_stdio` | No env var → transport defaults to stdio |
| `test_http_requires_token` | `streamable-http` without `ECLE_MCP_AUTH_TOKEN` → exit with error |
| `test_auth_valid_token` | Valid Bearer token → 200, tool response returned |
| `test_auth_missing_token` | No Authorization header → 401 |
| `test_auth_wrong_token` | Wrong Bearer token → 401 |
| `test_auth_skipped_stdio` | stdio transport → no auth check, tools work |
| `test_tools_identical_both_transports` | Same tool call returns same JSON via stdio and HTTP |
| `test_host_port_config` | Custom `ECLE_MCP_HOST` and `ECLE_MCP_PORT` are respected |
| `test_transport_security_defaults` | Default config: `enable_dns_rebinding_protection=False`, empty lists |
| `test_transport_security_yaml_override` | YAML allowlist values round-trip through `ConfigLoader.load()` |

## DNS Rebinding Protection (BUG-038)

MCP SDK v1.24+ ships `TransportSecurityMiddleware` which rejects `Host` headers that are not `localhost` / `127.0.0.1` by default. This is correct security behaviour for a personal server, but breaks remote deployments where clients connect via hostname or reverse proxy.

### Problem
Connecting from `dpolwsbil0000b.gsm1900.org:8080` returns `421 Invalid Host Header` because the SDK's default allowlist only contains loop-back addresses.

### Solution
ECLE exposes three fields under `mcp.transport_security` in `ecle.yaml` that map 1:1 to the SDK's `TransportSecuritySettings`:

| Field | Type | Default | Effect |
|-------|------|---------|--------|
| `enable_dns_rebinding_protection` | bool | `false` | `false` disables the check entirely; `true` enables it and uses the lists below |
| `allowed_hosts` | list[str] | `[]` | Extra allowed `Host` values (e.g. `["myserver.example.com:*"]`). Only used when protection is enabled. |
| `allowed_origins` | list[str] | `[]` | Extra allowed `Origin` values. Only used when protection is enabled. |

### ecle.yaml configuration
```yaml
mcp:
  transport_security:
    enable_dns_rebinding_protection: false   # set true + allowlists for locked-down deployments
    allowed_hosts: []
    allowed_origins: []
```

### Locked-down deployment (allowlist approach)
```yaml
mcp:
  transport_security:
    enable_dns_rebinding_protection: true
    allowed_hosts:
      - "dpolwsbil0000b.gsm1900.org:*"
      - "ecle-server.internal:*"
    allowed_origins:
      - "https://ecle-server.internal"
```

### Code path
`src/ecle/config/settings.py` → `TransportSecurityConfig` dataclass  
`src/ecle/config/loader.py` → `_apply_yaml` nested-dataclass merge  
`src/ecle/mcp/server.py` → `_run_http()` applies `TransportSecuritySettings` before `mcp.streamable_http_app()`

### Reference
MCP SDK issue [#1798](https://github.com/modelcontextprotocol/python-sdk/issues/1798) — official SDK guidance on DNS rebinding protection configuration.

## Migration

- **No breaking changes.** Default behavior is unchanged (`stdio`).
- Existing `.vscode/mcp.json` and `.mcp.json` configs work without modification.
- To switch to remote: set env vars on server, update client `.mcp.json` to `type: "http"`.
- **v1.5 change:** `MCPSettings.allowed_hosts` flat field replaced by `MCPSettings.transport_security: TransportSecurityConfig`. If you had `mcp.allowed_hosts` in an older `ecle.yaml`, move it to `mcp.transport_security.allowed_hosts` and set `enable_dns_rebinding_protection: true`.

## Sync

Last verified: 2026-04-16
