# SPEC-059: Configurable Runtime Limits

**Status**: Spec
**Owner**: Platform Architect
**Date**: 2026-04-21
**Triggered by**: Production observations — MAX_DEPTH=10 caused combinatorial BFS explosion on large repos; cross_repo_edges 100 KB guard is hardcoded; deep CPG phase unconditionally auto-submitted

## Problem Statement

Three runtime limits are hardcoded and cannot be tuned per deployment:

1. **`MAX_DEPTH = 10`** (`service_index.py:20`) — BFS depth cap for the service call graph.  
   On repos with deep call chains this creates O(n^depth) expansions. Default of 10 is too aggressive; most meaningful chains end within 5 hops.

2. **`_CROSS_REPO_EDGES_RESPONSE_LIMIT = 100_000`** (`cross_repo.py:151`) — Response size cap before `ecle_cross_repo_edges` collapses to summary.  
   100 KB is conservative; LLMs with 200 K+ context windows can handle more. Should be configurable per deployment.

3. **Deep CPG auto-submit** (`job_queue.py:958`) — After a structural CPG completes during auto-classify, a deep Joern job is always submitted.  
   Single-dev environments with no Joern installation would benefit from `structural`-only mode. Full pipelines want `structural+deep` (default).

## Design Principle

Every limit that depends on corpus size or LLM context capacity must be configurable in `ecle.yaml`. Defaults are conservative and safe. No code changes required to adjust for a new deployment.

## ADR References

- ADR-013 — Configuration layering (ecle.yaml → env vars → CLI flags)
- ADR-028 — Deterministic service index
- ADR-030 — Two-phase CPG extraction

## Inputs

Three new fields in `ecle.yaml` (defaults listed below).

### `ingest.service_index_max_depth` (default: `5`)

BFS depth cap for `ServiceIndexBuilder._bfs_from_entry_point()`.  
Valid range: 1–20. 0 is not valid (BFS would never traverse).  
Reducing from 10 → 5 eliminates the long tail of deep chains while covering >99% of meaningful service boundaries.

### `ingest.service_index_per_service_cap` (default: `500`, `0` = no cap)

Maximum reachable-function rows per entry point.  
When a "god function" is an entry point, BFS can produce millions of rows.  
Once `len(results) >= cap`, the BFS for that entry point stops early.  
0 disables the cap entirely (not recommended for large repos).

### `cpg.phases` (default: `["structural", "deep"]`)

Controls which CPG phases auto-classify code uploads submit.  

| Value | Behaviour |
|-------|-----------|
| `["structural", "deep"]` | Structural CPG runs inline; deep Joern job auto-submitted after. **Default.** |
| `["structural"]` | Structural only; no deep job submitted. For environments without Joern. |
| `["deep"]` | Deep only; no structural inline phase. Rare — must have pre-built facts. |

### `mcp.cross_repo_response_limit_kb` (default: `100`)

Maximum serialised response size (kilobytes) for `ecle_cross_repo_edges_tool` before the response collapses to a per-repo summary.  
Raise for LLMs with large context windows (e.g., 500 for a 200 K token model).

## Interface

### `src/ecle/config/settings.py`

Add to `IngestSettings`:

```python
@dataclass
class IngestSettings:
    workers: int = 0
    cpg_parallel: int = 1
    queue_start_mode: str = "manual"
    startup_delay_seconds: int = 0
    service_index_max_depth: int = 5
    # BFS depth cap for ServiceIndexBuilder. Higher = more complete but slower.
    # v1.6 default was 10; 5 covers >99% of meaningful chains.
    service_index_per_service_cap: int = 500
    # Max reachable-function rows per entry point. 0 = no cap.
```

Add to `CPGSettings`:

```python
@dataclass
class CPGSettings:
    enabled: bool = False
    mode: str = "local"
    amf_root: str = ""
    joern_home: str = "c:/pradeep/joern-cli"
    timeout: int = 600
    service_url: str = ""
    poll_interval: int = 5
    phases: list = field(default_factory=lambda: ["structural", "deep"])
    # Controls which phases auto-classify code jobs submit.
    # ["structural", "deep"] — structural inline + deep Joern auto-submit (default)
    # ["structural"]          — structural only; no deep job submitted
    # ["deep"]                — skip structural; deep job submitted directly
```

Add to `MCPSettings`:

```python
@dataclass
class MCPSettings:
    transport: str = "stdio"
    host: str = "0.0.0.0"
    port: int = 8080
    transport_security: TransportSecurityConfig = field(default_factory=TransportSecurityConfig)
    limit_concurrency: int | None = None
    timeout_keep_alive: int = 5
    cross_repo_response_limit_kb: int = 100
    # Max serialised response size for ecle_cross_repo_edges_tool before the
    # output collapses to a per-repo summary. Raise for large-context LLMs.
```

### `src/ecle/config/loader.py`

Extend `DEFAULT_YAML` `ingest:` block to include new fields:

```yaml
ingest:
  workers: 0
  cpg_parallel: 1
  queue_start_mode: manual
  startup_delay_seconds: 0
  service_index_max_depth: 5       # BFS depth cap (was hardcoded 10)
  service_index_per_service_cap: 500  # max rows per entry point; 0 = no cap
```

Extend `cpg:` comment block:

```yaml
# cpg:
#   phases: ["structural", "deep"]   # or ["structural"] for no-Joern environments
```

Extend `mcp:` comment block (or add if not present):

```yaml
# mcp:
#   cross_repo_response_limit_kb: 100  # raise for large-context LLMs
```

Add `ingest.service_index_max_depth` and `ingest.service_index_per_service_cap` to `_ENV_MAP`:

```python
"ECLE_SERVICE_INDEX_MAX_DEPTH": ("ingest", "service_index_max_depth", int),
"ECLE_SERVICE_INDEX_PER_SERVICE_CAP": ("ingest", "service_index_per_service_cap", int),
"ECLE_MCP_CROSS_REPO_LIMIT_KB": ("mcp", "cross_repo_response_limit_kb", int),
```

### `src/ecle/ingestion/service_index.py`

Replace module-level constant with constructor parameter:

```python
# Remove: MAX_DEPTH = 10

class ServiceIndexBuilder:
    def __init__(self, db: Any, repo_id: str, max_depth: int = 5, per_service_cap: int = 500):
        self.db = db
        self.repo_id = repo_id
        self._max_depth = max_depth
        self._per_service_cap = per_service_cap
```

In `_bfs_from_entry_point()`:
- Replace `if depth >= MAX_DEPTH:` → `if depth >= self._max_depth:`
- Add cap check after `results.append(...)`:
  ```python
  if self._per_service_cap > 0 and len(results) >= self._per_service_cap:
      break
  ```

### `src/ecle/ingestion/job_queue.py`

Three call sites for `ServiceIndexBuilder` — each must pass settings values:

```python
# In _process_job code path (line ~1056):
result = ServiceIndexBuilder(
    db,
    repo_id=rid,
    max_depth=self._settings.ingest.service_index_max_depth,
    per_service_cap=self._settings.ingest.service_index_per_service_cap,
).build()
```

For deep CPG auto-submit (line ~958), gate on `cpg.phases`:

```python
cpg_phases = getattr(self._settings.cpg, "phases", ["structural", "deep"])
if "deep" in cpg_phases and _changed:
    # ... existing deep job submission ...
```

### `src/ecle/ingestion/post_process.py`

Pass settings to `ServiceIndexBuilder` (line ~107). The `run_post_processing()` function already receives `settings`:

```python
builder = ServiceIndexBuilder(
    db,
    repo_id=repo_id,
    max_depth=getattr(settings.ingest, "service_index_max_depth", 5),
    per_service_cap=getattr(settings.ingest, "service_index_per_service_cap", 500),
)
```

### `src/ecle/cli.py`

Pass settings to `ServiceIndexBuilder` (line ~1302). The `cmd_service_index` command has access to `settings`:

```python
builder = ServiceIndexBuilder(
    db,
    repo_id=rid,
    max_depth=settings.ingest.service_index_max_depth,
    per_service_cap=settings.ingest.service_index_per_service_cap,
)
```

### `src/ecle/mcp/cross_repo.py`

Replace hardcoded constant with settings-sourced value:

```python
# Remove: _CROSS_REPO_EDGES_RESPONSE_LIMIT = 100_000

# In ecle_cross_repo_edges():
settings = _get_settings()
_response_limit = getattr(settings.mcp, "cross_repo_response_limit_kb", 100) * 1024

if len(serialized) > _response_limit:
    # ... existing collapse logic ...
```

Add `_get_settings()` helper (alongside `_get_db()`):

```python
def _get_settings():
    import ecle.mcp.server as srv
    return getattr(srv, "_settings", None) or Settings()
```

Ensure `_settings` is set on the server module in `src/ecle/mcp/server.py` during startup (next to `_db`).

## Files

| File | Change |
|------|--------|
| `src/ecle/config/settings.py` | Add `service_index_max_depth`, `service_index_per_service_cap` to `IngestSettings`; add `phases` to `CPGSettings`; add `cross_repo_response_limit_kb` to `MCPSettings` |
| `src/ecle/config/loader.py` | Extend `DEFAULT_YAML` `ingest:` block; add 3 env var entries to `_ENV_MAP` |
| `src/ecle/ingestion/service_index.py` | Remove `MAX_DEPTH` constant; add `max_depth` + `per_service_cap` constructor params; apply both in `_bfs_from_entry_point()` |
| `src/ecle/ingestion/job_queue.py` | Pass settings to `ServiceIndexBuilder`; gate deep job on `cpg.phases` |
| `src/ecle/ingestion/post_process.py` | Pass settings to `ServiceIndexBuilder` |
| `src/ecle/cli.py` | Pass settings to `ServiceIndexBuilder` |
| `src/ecle/mcp/cross_repo.py` | Replace `_CROSS_REPO_EDGES_RESPONSE_LIMIT` constant with settings-sourced value |
| `src/ecle/mcp/server.py` | Store `_settings` on module alongside `_db` |

## Tests

| Test | Proves |
|------|--------|
| `test_service_index_respects_max_depth` | `ServiceIndexBuilder(max_depth=2)` does not return any mapping with `call_depth > 2` |
| `test_service_index_default_max_depth_is_5` | `ServiceIndexBuilder(db, "r")` has `._max_depth == 5` |
| `test_service_index_per_service_cap_limits_rows` | `per_service_cap=3` returns at most 3 rows per entry point |
| `test_service_index_cap_zero_is_no_cap` | `per_service_cap=0` does not truncate (small graph) |
| `test_cpg_phases_structural_only_no_deep_job` | When `cpg.phases = ["structural"]`, no deep `ImportJob` is submitted after structural completes |
| `test_cpg_phases_structural_and_deep_submits_job` | When `cpg.phases = ["structural", "deep"]` (default), deep job IS submitted |
| `test_cross_repo_response_limit_from_settings` | Setting `mcp.cross_repo_response_limit_kb = 1` collapses even small responses |
| `test_settings_ingest_defaults` | `IngestSettings()` has `service_index_max_depth=5`, `per_service_cap=500` |
| `test_settings_cpg_phases_default` | `CPGSettings()` has `phases=["structural", "deep"]` |
| `test_settings_mcp_limit_default` | `MCPSettings()` has `cross_repo_response_limit_kb=100` |

## Dependencies

- SPEC-013 — Settings & Config (ecle.yaml, layered config)
- SPEC-031 — Service call graph index (`ServiceIndexBuilder`)
- SPEC-044 — Two-phase extraction workflow (structural/deep phases)
- SPEC-058 — Queue start mode (`IngestSettings` dataclass this spec extends)

## Related

- BUG-073 — Cross-repo edges 748 KB fix (introduced `_CROSS_REPO_EDGES_RESPONSE_LIMIT` this spec makes configurable)
- `PIPELINE_PERFORMANCE_ANALYSIS 1.md` — P2a (MAX_DEPTH), P2b (per-service cap) identified here
