# SPEC-061: Auto Job Handoff — Classify-Then-Submit

**Status**: Spec
**Owner**: Platform Architect
**Date**: 2026-04-21
**Triggered by**: UI observation — `auto` parent job and `code structural child` job shown simultaneously in Processing state; parent occupies a worker thread for the entire CPG duration.

## Problem Statement

### Current behaviour

When a user uploads a directory and ECLE creates an `auto` classification job, the queue worker:

1. Classifies files (`classify_directory`) — fast, ~seconds
2. Spawns one **child tracking job** per bucket by writing directly to `processing/` (never a real queue job, so no worker picks it up — the parent drives it inline)
3. Runs Phase A (non-code buckets) in a `ThreadPoolExecutor` **inside the parent's worker thread**
4. Runs Phase B (code/CPG) serially inside the same thread
5. Submits the deep CPG job to `pending/` while still running (race: a free worker can pick up the deep job before the parent completes CrossTierLinker)
6. Runs CrossTierLinker, then completes

**Consequences:**

| Problem | Impact |
|---------|--------|
| Parent worker thread is blocked for the full CPG duration (minutes to hours) | One fewer worker available to all other repos |
| Child jobs in `processing/` while parent is also in `processing/` | UI shows two "Processing" rows for the same CPG work — confusing and misleading |
| Deep job submitted to `pending/` while parent still running | A free worker can start Joern deep extraction before CrossTierLinker has committed structural links — data race |
| Phase A buckets run as sub-threads of parent's thread, not as true queue workers | No independent retry, no per-bucket `failed/` record if the process crashes mid-run |

### Root cause

`create_child_job()` writes directly to `processing/` so the tracking row appears immediately in the UI. The parent drives the child inline. This was a shortcut to get progress reporting; it hard-codes the parent as the executor of all children.

## Design

### New behaviour — classify-and-submit

The `auto` worker does **three things only**:

1. Classify the upload directory → list of `(content_type, [files])` buckets
2. Copy each bucket into a durable temp directory (per current logic)
3. Submit each bucket as a **real `ImportJob`** to `pending/` with `parent_job_id` set
4. **Complete immediately** (`queue.complete(job.job_id, {summary})`)

Each submitted child job is then picked up by the next free worker and executed independently. The deep CPG job is submitted by the **structural child** when it completes — exactly as the non-auto structural path already does (line ~1350).

### Parallelism model (after fix)

```
Worker A: auto job — classify (seconds) → submit N children → DONE
Worker B: code structural child — CPG → topology → post-processing → submit deep → DONE
Worker C: documents child — embed → DONE
Worker D: config child — parse + embed → DONE
Worker E (later): code deep child — Joern → merge → DONE
```

- Non-code children start as soon as a worker is free. True parallelism.
- Deep CPG only starts after structural completes and CrossTierLinker has run — no race.
- Parent worker freed in seconds, not hours.

### Child job routing

The bucket job's `content_type` drives existing routing in `_process_job()`. No new routing needed:
- `code` + `phase="structural"` → existing CPG path (lines ~1050–1350)
- `documents` / `data` / `data-sql` / `config` → existing non-code path

### Summary result

The `auto` job completes with a lightweight summary:
```json
{
  "auto_classify": { ... classification.summary ... },
  "buckets": { "code": 247, "documents": 12 },
  "child_jobs": { "code": "abc12345", "documents": "def67890" }
}
```

Result details (facts loaded, embeddings written) live on each child's completion record, which is how non-auto uploads already work.

### CrossTierLinker placement

CrossTierLinker runs at the **end of each bucket job**, not in the auto parent. This matches existing behaviour for the code path (structural job already runs it at line ~1184). Non-code bucket jobs must also run it at their end — currently they do not. This spec adds that.

## Files Changed

| File | Change |
|------|--------|
| `src/ecle/ingestion/job_queue.py` | Replace inline Phase A + Phase B execution with submit-only loop; remove `ThreadPoolExecutor` from auto path; add CrossTierLinker call to non-code bucket job completion |
| `src/ecle/ingestion/job_queue.py` | Remove `create_child_job()` usage from auto path (method kept for potential future use) |

## Interface

No public interface changes. `ImportJob` dataclass unchanged. `submit()` and `complete()` unchanged.

The auto job's `_process_job()` branch changes from ~300 lines of inline execution to ~40 lines of classify + submit.

## Behaviour Rules

1. **Auto job completes in < 30 seconds** for any upload size. Classification + file copy is the only work.
2. **No child job written to `processing/` by the parent.** All children go to `pending/` and are picked up by workers.
3. **Deep job is submitted by the structural child only**, after structural CPG + CrossTierLinker complete. The auto parent never submits a deep job.
4. **Each child job is independently retryable** via the existing Retry button (child job_id is in the auto summary).
5. **CrossTierLinker runs at the end of every bucket child** (code structural already does; non-code buckets get it added).
6. **Bucket temp dirs are NOT deleted by the auto parent.** Each child job owns its `source_path` and deletes it after completion (existing cleanup logic already does this for non-auto jobs).

## Tests

| Test | What it proves |
|------|---------------|
| `test_auto_job_completes_without_running_cpg` | `_process_job()` on an auto job with a code bucket does NOT call `_try_cpg_extraction()` — CPG is not executed inline |
| `test_auto_job_submits_children_to_pending` | After processing an auto job, `pending/` contains one job file per bucket (not `processing/`) |
| `test_auto_job_completes_immediately` | Auto job reaches `complete/` before any child job completes |
| `test_auto_child_inherits_parent_job_id` | Each child `ImportJob` has `parent_job_id == auto_job.job_id` |
| `test_auto_no_deep_job_in_pending` | After auto processing completes, no deep job exists in `pending/` — deep is submitted by structural child only |
| `test_non_code_child_runs_cross_tier_linker` | Documents bucket child calls `CrossTierLinker.materialize_for_repo()` at completion |

## Dependencies

- SPEC-037 (job queue)
- SPEC-051 (auto-classifier)
- ADR-030 (two-phase CPG extraction)

## Status

Spec
