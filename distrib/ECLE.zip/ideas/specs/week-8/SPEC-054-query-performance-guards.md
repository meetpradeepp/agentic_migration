# SPEC-054: Query Performance Guards -- Prevent System Hangs at Scale

**Status**: Implemented (v1.3)
**Owner**: Platform Architect
**Triggered by**: csActvSubs repo (2839 files, 14238 functions, 148351 edges) caused ecle_impact to hang

## Problem Statement

ECLE queries were designed for small repos (50-200 files). When a large enterprise repo (2839 files, 148351 topology edges) was onboarded, several queries became performance bombs:

- `ecle_impact` hung for minutes (recursive CTE on 1078 outgoing edges)
- `ecle_enrich` loaded ALL 2839 file IDs into memory on every call
- `get_repos()` fired N+1 queries (separate `get_stats()` per repo)
- `get_edges_from()` returned 1000+ rows with no LIMIT
- Wildcard vector search iterated all ChromaDB collections

## Design Principle

**Every query has a cap.** No unbounded SELECT, no unbounded traversal, no N+1 loops. If a query could return more than 200 rows, it must have a LIMIT. If a loop fires queries, it must be batched.

## Fixes Applied

### P0 -- System Hangs

| Issue | Root Cause | Fix | File |
|-------|-----------|-----|------|
| N+1 get_repos/get_stats | Per-repo `get_stats()` in loop (40+ queries) | Batch edge/table counts with GROUP BY (2 queries total) | sqlalchemy_backend.py:1113 |
| Unbounded file iteration in ecle_enrich | `list_current_file_ids("*")` loads all 2839 IDs, loops | Replaced with `search_file_ids()` -- targeted SQL ILIKE with LIMIT 5 | server.py:444 |
| Same in ecle_context_resource | Same unbounded loop | Same targeted query fix | server.py:314 |
| Recursive CTE fan-out in impact_traversal | CTE expands all edges before LIMIT applies | Added `LIMIT 200` on result set + batch platform labeling (1 query, not N) | sqlalchemy_backend.py:661 |

### P1 -- Slow (>5s)

| Issue | Root Cause | Fix | File |
|-------|-----------|-----|------|
| get_edges_from unbounded | No LIMIT on edge query | Added `limit=200` parameter | sqlalchemy_backend.py:565 |
| get_edges_to unbounded | Same | Added `limit=200` parameter | sqlalchemy_backend.py:572 |
| N+1 platform labeling in impact_traversal | Per-row SELECT for is_platform | Batch query with IN clause | sqlalchemy_backend.py:668 |

### P2 -- Slow (>1s)

| Issue | Root Cause | Fix | File |
|-------|-----------|-----|------|
| get_topology_edges unbounded | Returns all 148351 edges | Added `limit=5000` parameter | sqlalchemy_backend.py:579 |
| Vector search iterates all collections | Loops over every ChromaDB collection for wildcard | Capped at 50 collections max | server.py:1105 |

## New Backend Method

```python
def search_file_ids(self, pattern: str, repo_id: str = "*", limit: int = 5) -> list[tuple]:
    """Search file IDs by pattern (ILIKE). Returns [(file_id, language, function_count)]."""
```

Replaces the pattern of loading all file IDs then looping. Single SQL query with ILIKE + LIMIT.

## Default Limits

| Query | Default Limit | Configurable |
|-------|--------------|-------------|
| impact_traversal results | 200 rows | Yes (LIMIT in SQL) |
| get_edges_from / get_edges_to | 200 edges | Yes (limit param) |
| get_topology_edges | 5000 edges | Yes (limit param) |
| search_file_ids | 5 matches | Yes (limit param) |
| Vector collection iteration | 50 collections | Hardcoded |
| ecle_enrich word minimum length | 3 chars (files), 4 chars (services) | Hardcoded |

## Testing Criteria

| Test | Validates |
|------|-----------|
| ecle_impact on 1000+ edge file returns in <2s | CTE LIMIT works |
| ecle_enrich on csActvSubs returns in <500ms | No full file list scan |
| get_repos() with 10+ repos returns in <1s | No N+1 stats queries |
| Wildcard ecle_search with 50+ repos returns in <10s | Collection cap works |
| ecle_file on 1078-edge file returns top 200 edges | Edge LIMIT works |

## v1.4 Additions (2026-04-14)

### Response Size Guards

| Issue | Root Cause | Fix | BUG |
|-------|-----------|-----|-----|
| ecle_enrich matched "P" as table | No min length, substring match | Min 4 chars, exact match, 10 table cap | BUG-018 |
| ecle_find_by_table returned 930KB | Unbounded rows + N+1 get_file_tables | 50 file cap + cross-tier capped | BUG-019 |
| ecle_trace returned 905KB | BILLING_ACCOUNT touches 200+ files | 100KB guard → summary only | BUG-020 |
| ecle_search SSL error | No local model → HuggingFace download | Return empty if no embedding fn | BUG-021 |
| MCP stdout corruption | rich logging to stdout | `logging.basicConfig(stream=stderr)` | BUG-023 |
| ecle_enrich DB crash killed connection | StorageError not caught | try/except returns graceful JSON | BUG-024 |

### Summary Block Pattern

All trace methods now return a `summary` dict at the top level:
```json
{
  "summary": {
    "column_count": 45,
    "code_files": 200,
    "services": 3
  },
  "columns": [...capped...],
  "code_access": [...capped at 50...],
  "gaps": [...]
}
```

If response exceeds 100KB, only summary is returned with a pointer to detail tools.

### Response Caps

| Field | Cap | Reason |
|-------|-----|--------|
| code_access | 50 entries | High-connectivity tables touch 100s of files |
| columns | 100 entries | Wide tables |
| domain_fields | 20 entries | |
| document_mentions | 20 entries | |
| services | 20 entries | |
| find_by_table files | 50 files | N+1 get_file_tables per row |
| trace cross-tier columns | 30 entries | Prevent nested bloat |
| ecle_enrich tables | 10 matches | Prevent noisy matching |
| ecle_enrich query_plan phases | 3 phases max | Breadth → depth → verify; each phase capped at 6 tools |
| ecle_trace total response | 100KB | Summary fallback if exceeded |
