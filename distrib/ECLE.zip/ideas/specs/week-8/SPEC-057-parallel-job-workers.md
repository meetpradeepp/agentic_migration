# SPEC-057: Parallel Job Worker Pool

**Status**: Implemented  
**Owner**: Ingestion Platform  
**Date**: 2026-04-17  
**Enhancement**: Replace the single-threaded queue worker with a configurable parallel worker pool that processes jobs for different repos concurrently while safely gating CPG/Joern jobs to prevent JVM memory exhaustion.

## Purpose

ECLE's import queue (`SPEC-037`) previously ran one job at a time in a single daemon thread. This created two problems in production:

1. **Long CPG jobs blocked everything else.** A 600-second Joern extraction for repo A caused repo B's lightweight facts upload to wait 10 minutes.
2. **Independent repos had no reason to be serialized.** Each repo has its own DB rows, artifact directory, and vector collection — they share nothing at runtime.

This spec makes the worker pool wide enough to handle concurrent repos while protecting system RAM from simultaneous JVM startup.

## Design

### Concurrency model

```
max_workers      = N daemon threads (one picks one pending job at a time)
max_cpg_workers  = M ≤ N (subset of those threads allowed to run Joern)
```

Two invariants, enforced atomically:

1. **Per-repo exclusivity** — a repo that is being processed is never picked up by a second worker thread. This prevents concurrent writes to the same `file_facts` rows and topology edges.
2. **CPG slot limit** — only `max_cpg_workers` threads may run a CPG (`content_type=code`) job simultaneously. This caps JVM count and peak RAM.

### Thread behavior

Each worker thread:
1. Calls `queue.get_pending()` → list of all pending jobs, oldest first.
2. Iterates the list in order, calls `_try_claim(job)` for each.
3. Processes the first claimable job; skips (with `time.sleep`) if none is available.
4. Calls `_release(job)` in the `finally` block — always, even on crash.

`_try_claim` and `_release` both hold `self._lock` (a `threading.Lock`) so the claim set is always consistent across threads.

### Why per-repo, not per-job-type

Serializing by repo rather than by content type is simpler and handles the most common dangerous case: two CPG jobs for the same repo would race to write the same structured-DB rows. Two CPG jobs for *different* repos are safe and can run in parallel (each has its own `artifacts/{repo_id}/` workspace).

### Effect on non-CPG jobs

`facts`, `config`, `documents`, `data-sql` uploads are not CPG jobs. They do not consume a CPG slot. If `max_workers=4, max_cpg=1`, three workers can each process a lightweight facts upload while the fourth runs Joern — all in parallel.

## Configuration

```yaml
ingest:
  workers: 4        # 0 = auto (cpu_count capped at 4)
  cpg_parallel: 1   # max simultaneous Joern JVMs (default 1)
```

`workers: 0` auto-detects `os.cpu_count()` capped at 4.

Full mode (`features: full`) applies `_apply_full_defaults`:
- `workers = 4`
- `cpg_parallel = 4`

## Implementation

| File | Change |
|---|---|
| `src/ecle/ingestion/job_queue.py` | `QueueWorker` rewritten — `max_workers` threads, `_try_claim`, `_release`, `_active_repos`, `_active_cpg_count` |
| `src/ecle/config/settings.py` | `IngestSettings.workers` and `IngestSettings.cpg_parallel` (pre-existing fields, now used) |
| `src/ecle/config/loader.py` | `ingest` section in YAML `section_map`; `_apply_full_defaults` sets Full-mode defaults (pre-existing, unchanged) |
| `src/ecle/cli.py` | Startup prints `N parallel worker(s), M CPG slot(s)` |

## Safety guarantees

| Scenario | Behavior |
|---|---|
| Two jobs for same repo | Second is skipped by every worker until first completes |
| Two CPG jobs, `cpg_parallel=1` | Second CPG job skips until first Joern finishes; lighter jobs (facts) proceed unblocked |
| Worker thread crashes during job | `finally` always calls `_release` → repo and CPG slot freed |
| Server restart with stale `processing/` jobs | `recover_stale()` moves them to `failed/` before any worker starts — same as before |

## Related

- SPEC-037 — import queue and health reporting
- SPEC-040 — unified onboard job types
- SPEC-044 — two-phase CPG extraction (structural + deep)
- SPEC-058 — queue start mode control (manual/delayed/auto pause, UI button) — enhancement of this spec
- BUG-039 — duplicate file_id collision fix (same session)
- BUG-040 — cross-repo edge bleed fix (same session)
