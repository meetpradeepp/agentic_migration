# SPEC-060: Pipeline Performance Instrumentation + Batch Embedding

**Status**: Spec
**Owner**: Platform Architect
**Date**: 2026-04-21
**Triggered by**: `PIPELINE_PERFORMANCE_ANALYSIS 1.md` — P1, P3a, P3b identified as unresolved after v1.7.0

## Problem Statement

Three performance gaps identified in production profiling remain unaddressed:

### P1 — Single-vector embedding upserts

`EmbeddingPipeline.embed_file()` calls `vector_store.upsert(collection, [point])` — a list of one.  
`EmbeddingPipeline.embed_functions()` does the same per function — one call per function.  

For a file with 50 functions, `embed_functions()` fires 51 separate upsert round-trips to ChromaDB.  
Batching to 50 vectors per call reduces round-trips by ~50x for typical files.

### P3a — No per-detector timing in topology

`TopologyComputer._process_file()` calls 6 `_detect_*` methods in sequence with no individual timing.  
When one detector is slow on a particular repo (e.g., `_detect_write_read` on a repo with 50K table refs),  
there is no data to identify it. The total elapsed covers all 6 — no breakdown visible in logs.

### P3b — No timer around CrossTierLinker.materialize_for_repo()

`CrossTierLinker(db).materialize_for_repo(job.repo_id)` is called at 3 points in `job_queue.py` (lines 998, 1123, 1184) and once in the deep path (line 1282) with no surrounding timing log.  
On the csActSub repo (148K edges), this was the slowest post-processing step and was invisible.

## Design Principle

**Measure before you optimize.** This spec adds the timing instrumentation that enables evidence-based future optimizations. The batch embedding change (P1) is a safe, independent improvement that does not require profiling first.

## Changes

### P1 — Batch embedding in `embedding_pipeline.py`

**`embed_file(file_fact_id)` — unchanged batch size = 1**  
One file = one point. No change needed (already `[point]`).

**`embed_functions(file_fact_id)` — collect all points, then batch upsert**

Current:
```python
for fn in functions:
    # ... build point ...
    self.vector_store.upsert(self.collection_name, [point])   # one at a time
```

New:
```python
EMBED_BATCH_SIZE = 50

points: list[VectorPoint] = []
for fn in functions:
    # ... build point ...
    points.append(point)
    if len(points) >= EMBED_BATCH_SIZE:
        self.vector_store.upsert(self.collection_name, points)
        points = []

if points:
    self.vector_store.upsert(self.collection_name, points)
```

`EMBED_BATCH_SIZE = 50` is a module-level constant (not configurable — ChromaDB handles up to 5000 per call; 50 is a safe default that avoids memory pressure on large files).

### P3a — Per-detector timing in `topology.py`

In `_process_file()` (the inner closure), wrap each `_detect_*` call with `time.monotonic()`:

```python
def _process_file(fid: str) -> list[dict[str, Any]]:
    file_fact_id = ...
    timings: dict[str, float] = {}
    edges: list[dict] = []

    for detector_name, detector_fn in [
        ("write_read",          lambda: self._detect_write_read(fid, file_fact_id)),
        ("function_delegation", lambda: self._detect_function_delegation(fid, file_fact_id)),
        ("include_dependency",  lambda: self._detect_include_dependency(fid, file_fact_id, all_file_ids)),
        ("type_dependency",     lambda: self._detect_type_dependency(fid, file_fact_id)),
        ("global_dependency",   lambda: self._detect_global_dependency(fid, file_fact_id)),
        ("datawindow_bridge",   lambda: self._detect_datawindow_bridge(fid, file_fact_id)),
    ]:
        t = time.monotonic()
        detected = detector_fn()
        timings[detector_name] = round((time.monotonic() - t) * 1000, 2)
        edges.extend(detected)

    # Only log if any detector exceeded 100 ms (avoids log spam on fast files)
    slow = {k: v for k, v in timings.items() if v > 100}
    if slow:
        logger.debug(
            "Slow detectors",
            extra={"context": {"file_id": fid, "slow_detectors_ms": slow}},
        )

    return edges
```

The existing topology total-time log at the end of `compute()` is kept unchanged.

### P3b — Timer around `CrossTierLinker.materialize_for_repo()` in `job_queue.py`

At all 4 call sites, wrap with timing:

```python
import time
_t0 = time.monotonic()
CrossTierLinker(db).materialize_for_repo(job.repo_id)
_link_ms = round((time.monotonic() - _t0) * 1000)
logger.info(
    "CrossTierLinker complete",
    extra={"context": {"repo_id": job.repo_id, "duration_ms": _link_ms}},
)
```

All 4 call sites use the same pattern (lines 998, 1123, 1184, 1282).

## Files

| File | Change |
|------|--------|
| `src/ecle/ingestion/embedding_pipeline.py` | Add `EMBED_BATCH_SIZE = 50`; refactor `embed_functions()` to collect then batch-upsert |
| `src/ecle/ingestion/topology.py` | Per-detector timing in `_process_file()`; log slow detectors at DEBUG |
| `src/ecle/ingestion/job_queue.py` | Timing wrapper at all 4 `CrossTierLinker.materialize_for_repo()` call sites |

## Tests

| Test | Proves |
|------|--------|
| `test_embed_functions_batches_upsert_calls` | For a file with 60 functions, `vector_store.upsert` is called exactly 2 times (50+10), not 60 |
| `test_embed_functions_single_batch` | For a file with 30 functions, `vector_store.upsert` is called exactly 1 time |
| `test_embed_functions_empty` | No upsert called when file has no functions |
| `test_topology_per_detector_timing_logged` | A mock detector that sleeps >100 ms produces a DEBUG log with `slow_detectors_ms` |
| `test_topology_fast_detectors_not_logged` | Fast detectors (<100 ms) do not produce the slow log |

## Dependencies

- SPEC-005 — Behavioral signature + vector embeddings (EmbeddingPipeline)
- SPEC-004 — Topology edges (TopologyComputer)
- SPEC-047 — Cross-tier linker (CrossTierLinker.materialize_for_repo)

## Related

- `PIPELINE_PERFORMANCE_ANALYSIS 1.md` — P1 (batch embeddings), P3a (per-detector timing), P3b (cross-tier linker timing)
- SPEC-054 — Query performance guards (same measurement-first principle)
