# SPEC-058: Queue Start Mode Control

**Status**: Implemented  
**Owner**: Ingestion Platform  
**Date**: 2026-04-17  
**Enhancement of**: SPEC-057 (Parallel Job Worker Pool)

## Purpose

ECLE's worker pool (`SPEC-057`) begins polling the queue and processing pending jobs immediately on startup. This is unsafe in production — the system (DB, vector store, upstream services) may not be ready yet, or the operator may want to review the queue before committing to a long processing run.

This spec adds a three-mode startup control:

| Mode | Behaviour |
|---|---|
| `manual` | Worker threads start but do not poll the queue. Operator explicitly starts processing via UI button or CLI. **Default for production.** |
| `delayed` | Worker polls after a configurable warm-up delay (`ingest.startup_delay_seconds`). For scheduled-boot scenarios where dependent services need time to initialise. |
| `auto` | Current behaviour — polling begins immediately. Default for CI / single-dev environments. |

The mode is surfaced on the health page as a status banner with a Start/Pause toggle button.

## ADR References

- ADR-013 — Configuration layering (`ecle.yaml` → env vars → CLI flags)

## Inputs

- `ingest.queue_start_mode` — string, one of `manual | delayed | auto` (default `manual`)
- `ingest.startup_delay_seconds` — integer ≥ 0, only meaningful when `queue_start_mode: delayed` (default `0`)
- Runtime: operator clicking "Start Queue" / "Pause Queue" button in UI, or `ecle queue start/pause` CLI

## Outputs

- `GET /api/queue/status` — JSON: `{paused, mode, pending, active_repos, workers}`
- `POST /api/queue/start` — resumes polling; returns `{ok, paused: false}`
- `POST /api/queue/pause` — suspends polling; returns `{ok, paused: true}`
- Health page queue banner — visible above the Import Jobs table, shows state and pending count with toggle button

## Interface

### `IngestSettings` (`src/ecle/config/settings.py`)

```python
@dataclass
class IngestSettings:
    workers: int = 0
    cpg_parallel: int = 1
    queue_start_mode: str = "manual"       # manual | delayed | auto
    startup_delay_seconds: int = 0         # only used when mode=delayed
```

### `QueueWorker` (`src/ecle/ingestion/job_queue.py`)

New attributes on `__init__`:

```python
self._paused: bool           # True when polling is suspended
self._queue_start_mode: str  # mode read from settings at startup
self._startup_delay: int     # seconds, 0 by default
```

New / modified methods:

```python
def start(self) -> None:
    """Start worker threads. Respects queue_start_mode."""

def pause(self) -> None:
    """Suspend polling. In-flight jobs complete; no new jobs picked up."""

def resume(self) -> None:
    """Resume polling. Idempotent — safe to call when already running."""

def queue_status(self) -> dict:
    """Return {paused, mode, pending, active_repos, workers}."""
```

### API endpoints (`src/ecle/query/app.py`)

```
GET  /api/queue/status   → QueueWorker.queue_status()
POST /api/queue/start    → QueueWorker.resume()  + {ok, paused: false}
POST /api/queue/pause    → QueueWorker.pause()   + {ok, paused: true}
```

Worker instance accessed via `request.app.state.worker` (set by `cmd_serve` in `cli.py`).

### CLI (`src/ecle/cli.py`)

`cmd_serve` stores the worker on `app.state` after `worker.start()` so API routes can reach it:

```python
app.state.worker = worker
```

## Behaviour

### `start()` — mode-driven initialisation

1. If `queue_start_mode == "manual"`: set `_paused = True`, spawn threads (they idle-poll in paused loop).
2. If `queue_start_mode == "auto"`: set `_paused = False`, spawn threads (begin polling immediately — existing behaviour).
3. If `queue_start_mode == "delayed"` and `startup_delay_seconds > 0`: set `_paused = True`, spawn threads, spawn an additional daemon timer thread that sleeps `startup_delay_seconds` then calls `resume()` and logs `"Queue auto-started after startup delay"`.
4. If `queue_start_mode == "delayed"` and `startup_delay_seconds == 0`: treat as `auto`.

### `_run_loop()` — paused state handling

When `_paused` is `True`, each worker thread sleeps one `poll_interval` then re-checks. This keeps threads alive and preserves the `_running` loop without consuming CPU or touching the queue directory.

```
while self._running:
    if self._paused:
        time.sleep(self.poll_interval)
        continue
    # ... existing claim / process / release logic ...
```

### `pause()` / `resume()`

- Both are **immediate** — set `_paused` and log. No lock needed (bool write is atomic in CPython).
- In-flight jobs that have already been claimed **continue to completion** — `pause()` prevents new claims, not active processing.
- `resume()` is idempotent. Calling it when already running has no effect.

### `queue_status()`

```python
{
    "paused": self._paused,
    "mode": self._queue_start_mode,
    "pending": len(self.queue.get_pending()),
    "active_repos": list(self._active_repos),   # snapshot under _lock
    "workers": self._max_workers,
}
```

If no worker is attached to `app.state` (test or minimal server mode), the endpoint returns a safe default:
`{paused: False, mode: "auto", pending: 0, active_repos: [], workers: 0}`

### Health page queue banner

Located above the Import Jobs section. Polling interval: 5 s (piggybacks on `loadJobs()` cycle).

**When paused (mode=manual, no jobs active):**
```
⏸  Queue paused — N jobs waiting   [▶ Start Queue]
```

**When paused (mode=delayed, countdown active):**
```
⏳  Queue starting in Xs — N jobs waiting   [▶ Start Now]
```

**When running:**
```
▶  Queue running — N active, M pending   [⏸ Pause Queue]
```

**When running and idle (pending=0, active=0):**
Banner hidden (no status noise when everything is done).

The Start/Pause button calls `POST /api/queue/start` or `POST /api/queue/pause` then immediately refreshes status.

## Configuration

`ecle.yaml` default block (added to `DEFAULT_YAML` in `loader.py`):

```yaml
# ── Ingestion worker ─────────────────────────────────────────────
ingest:
  workers: 0            # 0 = auto-detect (cpu_count capped at 4)
  cpg_parallel: 1       # max simultaneous Joern JVMs
  queue_start_mode: manual   # manual | delayed | auto
                             # manual  = queue paused on startup; press Start in UI
                             # delayed = auto-starts after startup_delay_seconds
                             # auto    = starts immediately (CI/dev default)
  startup_delay_seconds: 0   # only used when queue_start_mode: delayed
```

## Files

| File | Change |
|---|---|
| `src/ecle/config/settings.py` | Add `queue_start_mode: str = "manual"` and `startup_delay_seconds: int = 0` to `IngestSettings` |
| `src/ecle/config/loader.py` | Add full `ingest:` block to `DEFAULT_YAML` |
| `src/ecle/ingestion/job_queue.py` | `QueueWorker.__init__` reads new fields; `start()` branches on mode; `_run_loop()` checks `_paused`; add `pause()`, `resume()`, `queue_status()` |
| `src/ecle/cli.py` | `app.state.worker = worker` after `worker.start()` |
| `src/ecle/query/app.py` | Add `GET /api/queue/status`, `POST /api/queue/start`, `POST /api/queue/pause` routes |
| `src/ecle/ui/templates/health.html` | Queue status banner above Import Jobs; JS polls `/api/queue/status`; Start/Pause button |

## Tests

| Test | Proves |
|---|---|
| `test_queue_start_mode_manual` | Worker starts with `_paused=True`; `get_pending()` returns jobs but none are claimed after 0.5 s |
| `test_queue_start_mode_auto` | Worker starts with `_paused=False`; a pending job is claimed and processed immediately |
| `test_queue_start_mode_delayed` | Worker starts paused; after `startup_delay_seconds` elapses, a pending job is claimed |
| `test_pause_stops_new_claims` | `pause()` called mid-run; in-flight job completes; next pending job is not claimed |
| `test_resume_restarts_claims` | `pause()` then `resume()`; pending job is then claimed |
| `test_queue_status_paused` | `queue_status()` returns `{paused: True, pending: N, ...}` when paused |
| `test_queue_status_running` | `queue_status()` returns `{paused: False, active_repos: [...], ...}` while job runs |
| `test_api_queue_endpoints` | `GET /api/queue/status` → 200; `POST /api/queue/start` → `{ok, paused: false}`; `POST /api/queue/pause` → `{ok, paused: true}` |
| `test_api_no_worker` | Endpoints return safe defaults when `app.state.worker` is absent |

## Dependencies

- SPEC-037 — import queue and job lifecycle
- SPEC-057 — parallel worker pool (`QueueWorker`, `IngestSettings`, `_try_claim`, `_release`)
- SPEC-042 — service boundary architecture (API router structure this spec adds routes to)

## Related

- `docs/FUTURE-IDEAS.md` — "Queue auto-start control" (this spec implements that idea)
- SPEC-057 → Related section updated to reference this spec
