# SPEC-056: Portal-Visible Service Index Child Jobs

**Status**: Implemented
**Owner**: Onboarding Engineer + FACT Ingestion  
**Date**: 2026-04-14  
**Enhancement**: Service indexing must appear as its own queued job in the portal instead of being hidden inside code post-processing.

## Purpose

Make service-index execution explicit, trackable, and user-visible.

Today, the system already builds the deterministic service index during code post-processing, but the portal only shows the parent code jobs. This creates avoidable confusion:

- users do not see a separate service-index row
- summaries may incorrectly conclude that service indexing never ran
- operators cannot distinguish code ingestion success from service-index success

This spec promotes service indexing into a first-class child job while preserving the same deterministic backend behavior.

## Why a Separate Spec

This change is a queue lifecycle and portal UX enhancement. It does **not** alter the architecture of the service index itself.

- ADR-028 still governs the deterministic service index
- SPEC-031 still governs `service_function_map`
- SPEC-055 still governs non-code artifact promotion

Because the concern here is job orchestration and visibility, a dedicated spec is clearer than expanding SPEC-055 further.

## Related

- ADR-028 — deterministic service index
- SPEC-031 — service call graph index
- SPEC-037 — import queue and health reporting
- SPEC-040 — unified onboard jobs
- SPEC-044 — two-phase extraction workflow
- SPEC-055 — non-code artifact promotion

## Current Gap

### Current behavior

For code and facts onboarding, the worker does this:

1. load facts
2. compute topology edges
3. run post-processing
   - embeddings
   - shared artifact backfill
   - service index build
4. mark the parent code job complete

### User-visible problem

Only the parent code job is shown on the portal. Service indexing is buried in the result payload and is not visible as a separate row.

For a repo load, the user should be able to answer these questions directly from the portal:

- Did service indexing run?
- Is it still pending or processing?
- Did it complete with zero services or with actual mappings?
- Did it fail independently of code ingestion?

## Decision

**After every successful code or facts ingest that updates repo facts, ECLE will queue a dedicated `service-index` child job.**

The child job:

- has its own `job_id`
- carries the parent `repo_id`
- sets `content_type = "service-index"`
- retains `parent_job_id`
- inherits `phase` from the parent when applicable
- is displayed in the health dashboard and active jobs UI like any other queued job

This makes service indexing observable without changing the underlying evidence model.

## Architecture

### Job lifecycle

#### Single-phase / legacy import

```text
code-or-facts job complete
  → auto-submit service-index child job
  → service-index job processing
  → service-index job complete
```

#### Two-phase import

```text
structural code job complete
  → auto-submit deep child job
  → auto-submit service-index child job (phase=structural)

deep code job complete
  → auto-submit service-index child job (phase=deep, only if facts changed)
```

This keeps visibility timely after structural load while still allowing a refreshed index after deep enrichment.

## Queue Rules

### 1. Child-job allowance

The duplicate-job guard in the queue currently blocks multiple active jobs for the same repo. That must be relaxed for system-created child jobs.

Allowed combinations for the same repo:

- `code(structural)` + its auto-created `code(deep)` child
- completed code job + pending `service-index` child
- completed deep job + pending refresh `service-index` child

Rule:

- user-submitted duplicate jobs remain blocked
- worker-created child jobs with `parent_job_id` are allowed
- service-index child jobs stay serialized by the existing worker and do not introduce concurrent DB writes

### 2. Trigger conditions

Queue a `service-index` child when all are true:

1. parent job is `content_type in ("code", "facts")`
2. parent job completed successfully
3. facts were loaded or updated for the repo

Do **not** queue it for pure document/config/data jobs, since those do not rebuild `service_function_map` directly.

### 3. No hidden indexing inside completion path

The visible child job becomes the authoritative execution path for portal-triggered service indexing.

The code job may still collect lightweight summary metadata, but the actual user-visible service-index completion must come from the child job row.

## Service-Index Job Contract

### Input

The child job reads already-ingested repo facts from the structured DB.

It must **not**:

- rerun CPG extraction
- reread uploaded documents from disk unnecessarily
- infer service links from LLM output

### Output

The completed job JSON should include a dedicated summary:

```json
{
  "service_index": {
    "services_indexed": 150,
    "rows_written": 230,
    "callers_linked": 17,
    "shared_artifact_hits": 8,
    "index_status": "ready"
  }
}
```

### Progress steps

Recommended progress stages for portal visibility:

- `discover` — scanning repo functions and shared artifacts
- `map` — building service → function mappings
- `persist` — writing `service_function_map`
- `summarize` — computing totals for UI/API response

## UI / API Requirements

### Health API

`GET /ui/health/jobs` and related onboard job APIs must expose:

- `content_type`
- `phase`
- `parent_job_id`
- active progress step/message/pct

### Portal rendering

The jobs table must show:

- Type: `service-index`
- optional phase badge: `structural` or `deep`
- parent linkage to the originating code job if available
- final counts when complete

### Status semantics

If zero services are found, the job should still complete visibly with a truthful result such as:

- `services_indexed = 0`
- `index_status = "empty"`

This is better than silently omitting the job.

## Invariants

1. `service_function_map` remains deterministic and code-backed
2. non-code uploads can still improve `shared_artifacts` via SPEC-055, but they do not directly replace the service-index child job
3. repeated service-index child jobs are idempotent
4. portal visibility must reflect reality: queued, processing, complete, failed, or empty

## Files Expected to Change

- `src/ecle/ingestion/job_queue.py`
- `src/ecle/cli.py`
- `src/ecle/ui/routes.py`
- `src/ecle/ui/templates/health.html`
- `tests/unit/test_unified_onboard_jobs.py`
- `tests/unit/test_web_ui_service.py`
- `tests/test_two_phase_workflow.py`

## Acceptance Criteria

1. A new portal code import shows a distinct `service-index` job row
2. The row exposes live progress while indexing runs
3. Completed job details show counts for indexed services and mappings written
4. If indexing finds nothing, the portal still shows a completed `service-index` row with zero counts
5. Structural and deep workflows remain backward compatible
6. Existing CLI `build-service-index --queue` behavior remains valid and aligns with the same job contract

## Out of Scope

- changing the deterministic logic of the service index itself
- using documents/config to populate `service_function_map`
- altering the topology edge model

Those concerns remain covered by ADR-028, SPEC-031, and SPEC-055.
