# SPEC-055: Non-Code Artifact Promotion for Cross-Repo Discovery

**Status**: Implemented
**Owner**: FACT Ingestion + Query Engine
**Date**: 2026-04-14
**Enhancement**: Documents, config, domain data, and DDL should influence the cross-repo map deterministically

## Purpose

Promote grounded service and table references from non-code uploads into the shared artifact registry so that portal uploads of:

- documents
- configuration
- domain data
- DDL / SQL schema files

can improve cross-repo discovery, service ownership mapping, and database context.

This spec closes the gap where non-code evidence was searchable but did not materially update the enterprise fabric.

## ADR References

- ADR-008 — grounded knowledge engine beyond code
- ADR-019 — shared artifact registry
- ADR-027 — cross-repo completeness
- ADR-028 — service index stays deterministic
- ADR-034 — platform repo shared data layer
- ADR-037 — non-code evidence promoted to artifacts

## Inputs

### Structured DB inputs
- `documents`
- `document_chunks`
- existing `shared_artifacts`

### Content sources
- Markdown and design docs
- Config files parsed and stored through document onboarding path
- Tuxedo domain and service description uploads
- SQL / DDL uploads

## Outputs

### Structured DB
New rows in `shared_artifacts` with artifact types and operations:

- `TUXEDO_SERVICE` / `CALL`
- `TUXEDO_SERVICE` / `IMPLEMENT`
- `TABLE` / `DEFINE`
- `TABLE` / `READ`
- `TABLE` / `WRITE`

### Graph effects
Existing cross-repo edge derivation continues to use the registry:

- service caller repo → service implementor repo
- table writer repo → table reader repo

## Interface

### New / enhanced functions

In [src/ecle/ingestion/artifact_registry.py](src/ecle/ingestion/artifact_registry.py):

```python
extract_shared_artifacts_from_text(text: str) -> list[SharedArtifact]
backfill_document_artifacts(db, tenant_id: str = "default", repo_id: str | None = None) -> int
backfill_from_existing(db, tenant_id: str = "default", repo_id: str | None = None) -> int
```

### Trigger points

In portal and queue ingestion paths:

- document jobs call artifact promotion after chunk storage
- config jobs call artifact promotion after parsing/embedding
- data and data-sql jobs call artifact promotion after ingestion
- code/facts jobs continue to run full backfill as before

## Behavior

### Deterministic extraction only
The extractor must use regex/rule-based detection only.

No LLM calls are allowed on the ingestion path.

### Supported v1 patterns

#### Services
- `tpcall("SERVICE")`
- `tpacall("SERVICE")`
- phrases like:
  - `calls service X`
  - `invokes X`
  - `implements service X`
  - `service_name = X`

#### Tables
- `CREATE TABLE X`
- `ALTER TABLE X`
- `SELECT ... FROM X`
- `UPDATE X`
- `INSERT INTO X`
- `DELETE FROM X`
- phrases like:
  - `reads table X`
  - `writes to X`
  - `updates X`

### Normalization rules
- table names are normalized to uppercase and stripped of schema prefix
- service names preserve case
- SQL keywords such as `WHERE`, `TABLE`, `SELECT` must be filtered out

### Invariants
1. Idempotent — same source text twice must not duplicate rows
2. Provenance preserved — repo and source file remain attached
3. Non-code evidence supplements, never replaces, code-backed facts
4. `service_function_map` remains code-only

## Files

- [src/ecle/ingestion/artifact_registry.py](src/ecle/ingestion/artifact_registry.py)
- [src/ecle/ingestion/job_queue.py](src/ecle/ingestion/job_queue.py)
- [tests/unit/test_artifact_registry.py](tests/unit/test_artifact_registry.py)
- [constitution/decisions/ADR-037-non-code-evidence-promoted-to-artifacts.md](constitution/decisions/ADR-037-non-code-evidence-promoted-to-artifacts.md)

## Tests

### Required tests
- design doc mentioning `calls service arSvBilPrm` creates `CALL`
- design doc mentioning `implements service csGtWdgtCnfg` creates `IMPLEMENT`
- DDL text with `CREATE TABLE BILLING_ACCOUNT` creates `DEFINE`
- design/schema text with `reads table X` creates `READ`
- text with `updates Y` creates `WRITE`
- backfill remains idempotent
- cross-repo edge derivation works from non-code-backed shared artifacts

## Dependencies

- SPEC-011 — document onboarding
- SPEC-014 — shared artifact registry
- SPEC-015 — cross-repo MCP tools
- SPEC-047 — cross-tier linker
- SPEC-056 — portal-visible service-index child jobs for explicit queue/UX visibility

## Acceptance Criteria

1. Uploading design docs through the portal can add service and table artifacts
2. Uploading DDL through the portal can add table definition artifacts
3. Cross-repo tools show those artifacts without needing code re-upload
4. Regression tests prove the behavior end-to-end at unit level
