# SPEC-053: Language Plugin Common Module — No Cross-Language Imports

**Status**: Implemented
**Owner**: CPG Pipeline Engineer
**Related**: SPEC-045 (AMF two-phase parser), ADR-030 (two-phase extraction)

## Problem Statement

Language plugins violate isolation by importing directly from sibling plugins:

```
cpp/fast_extractor.py   → importlib.import(c/fast_extractor.py)  # cross-language import
proc/fast_extractor.py  → importlib.import(c/fast_extractor.py)  # cross-language import
java/fast_extractor.py  → copy-pasted SQL regex from C            # duplication
```

This creates:
- **Hidden coupling**: C extractor changes silently break C++ and Pro*C
- **Plugin violation**: languages are supposed to be self-contained plugins
- **Duplication**: Java copied SQL patterns instead of sharing them

## Solution

Create `stages/languages/common/` with shared tree-sitter utilities and SQL patterns. Each language imports ONLY from `common/`, never from siblings.

```
stages/languages/
  common/                         # NEW — shared module
    __init__.py
    treesitter_helpers.py         # _find_all, _find_child, _text, _find_all_types
    sql_patterns.py               # SQL regex, classification, table extraction
    schema_builder.py             # CanonicalFactFileBase template builder
  c/
    fast_extractor.py             # imports from common/, NOT from siblings
  cpp/
    fast_extractor.py             # imports from common/, has own extract()
  proc/
    fast_extractor.py             # imports from common/, has own extract()
  java/
    fast_extractor.py             # imports from common/, no more copy-paste
```

## What Moves to Common

### `common/treesitter_helpers.py` — AST traversal

| Function | Current Location | Used By |
|----------|-----------------|---------|
| `_find_all(node, type)` | `c/fast_extractor.py:338` | C, C++, Pro*C |
| `_find_all_types(node, types)` | `c/fast_extractor.py:350` | C, C++ |
| `_find_child(node, type)` | `c/fast_extractor.py:362` | C, C++, Pro*C |
| `_text(node, source_bytes)` | `c/fast_extractor.py:370` | C, C++, Pro*C |

These are pure tree-sitter helpers with zero language-specific logic.

### `common/sql_patterns.py` — SQL detection and classification

| Pattern | Current Location | Used By |
|---------|-----------------|---------|
| `SQL_KEYWORDS` | `c/fast_extractor.py:16` | C, Pro*C, Java (duplicated) |
| `SQL_READ` | `c/fast_extractor.py:20` | C, Pro*C, Java (duplicated) |
| `SQL_WRITE` | `c/fast_extractor.py:21` | C, Pro*C, Java (duplicated) |
| `SQL_TRANSACTION` | `c/fast_extractor.py:24` | C, Pro*C, Java (duplicated) |
| `SQL_DDL` | `c/fast_extractor.py:25` | C, Pro*C, Java (duplicated) |
| `SQL_TABLE` | `c/fast_extractor.py:28` | C, Pro*C, Java (duplicated) |
| `classify_sql(text)` | inline in each extractor | C, Pro*C, Java |
| `extract_tables(text)` | inline in each extractor | C, Pro*C, Java |

### `common/schema_builder.py` — CanonicalFactFileBase template

```python
def empty_fact_file(filename: str, language: str) -> dict:
    """Return a blank CanonicalFactFileBase dict."""
    return {
        "filename": filename,
        "language": language,
        "_extraction_tier": "structural",
        "functions": [],
        "sql_statements": [],
        "dependencies": [],
        "comments": [],
        "literals": [],
        "execution_sequence": [],
        "global_defs": [],
        "struct_definitions": [],
        "includes": [],
        "framework_calls": [],
        "data_flow_edges": [],
        "control_flow_edges": [],
    }
```

## What Stays in Each Language

### C (`c/fast_extractor.py`)
- `_BRANCH_TYPES` — C-specific branching node types
- `_NOISE_FUNCS` — C-specific noise functions
- `_extract_functions()` — C function_definition parsing
- `_extract_struct_defs()` — C struct_specifier parsing
- `_extract_includes()` — C preproc_include parsing
- `_extract_dependencies()` — C call_expression parsing
- `_extract_comments()`, `_extract_literals()`, `_extract_global_defs()`
- `_extract_sql()` — calls `common.sql_patterns` for classification
- `extract()` — C-specific assembly

### C++ (`cpp/fast_extractor.py`)
- **Currently**: Imports and calls C's `extract()`, adds class/namespace extraction
- **After**: Has its OWN `extract()` that:
  - Uses `common.treesitter_helpers` for AST traversal
  - Uses `common.sql_patterns` for SQL classification
  - Has C++ specific: `_extract_classes_and_methods()`, namespace handling
  - Reuses C-family patterns for functions, structs, includes (C++ tree-sitter grammar shares these node types with C)
  - Does NOT delegate to C's `extract()`

### Pro*C (`proc/fast_extractor.py`)
- **Currently**: Imports C's extractor, enhances SQL extraction for `__JOERN_SQL_WRAPPER`
- **After**: Has its OWN `extract()` that:
  - Uses `common.treesitter_helpers` for AST traversal
  - Uses `common.sql_patterns` for SQL classification
  - Has Pro*C specific: `_extract_exec_sql()` for JOERN_SQL_WRAPPER calls
  - C-family function/struct/include extraction (same tree-sitter-c grammar)
  - Does NOT delegate to C's `extract()`

### Java (`java/fast_extractor.py`)
- **Currently**: Duplicates SQL regex patterns from C
- **After**: Imports `common.sql_patterns` — no duplication
- Everything else stays Java-specific (classes, annotations, Spring components, JDBC)

## C-Family Shared Extraction

C, C++, and Pro*C all use tree-sitter grammars that share the same node types for:
- `function_definition` → function extraction
- `struct_specifier` / `union_specifier` / `enum_specifier` → struct extraction
- `preproc_include` → include extraction
- `call_expression` → dependency extraction
- `string_literal` → SQL extraction
- `comment` → comment extraction

Rather than each language reimplementing these, add to common:

### `common/c_family_extractors.py` — shared C-family extraction

```python
def extract_c_functions(root, source_bytes, branch_types):
    """Extract function_definition nodes — works for C, C++, Pro*C."""

def extract_c_structs(root, source_bytes):
    """Extract struct/union/enum definitions."""

def extract_c_includes(root, source_bytes):
    """Extract #include directives."""

def extract_c_dependencies(root, source_bytes, noise_funcs):
    """Extract call_expression dependencies."""

def extract_c_comments(root, source_bytes, filename, sql_keywords):
    """Extract comments with SQL detection."""

def extract_c_literals(root, source_bytes, sql_keywords):
    """Extract string and number literals, excluding SQL strings."""

def extract_c_globals(root, source_bytes):
    """Extract file-scope variable declarations."""
```

Each C-family language calls these with its own constants:
```python
# In c/fast_extractor.py:
functions = c_family.extract_c_functions(root, source_bytes, C_BRANCH_TYPES)

# In cpp/fast_extractor.py:
functions = c_family.extract_c_functions(root, source_bytes, CPP_BRANCH_TYPES)
# + C++ specific class method extraction
```

## Import Rules (enforced)

```
✓ c/fast_extractor.py     → from common.treesitter_helpers import ...
✓ c/fast_extractor.py     → from common.sql_patterns import ...
✓ cpp/fast_extractor.py   → from common.treesitter_helpers import ...
✓ cpp/fast_extractor.py   → from common.c_family_extractors import ...
✓ proc/fast_extractor.py  → from common.c_family_extractors import ...
✓ java/fast_extractor.py  → from common.sql_patterns import ...

✗ cpp/fast_extractor.py   → from c.fast_extractor import ...     # BANNED
✗ proc/fast_extractor.py  → from c.fast_extractor import ...     # BANNED
✗ java/fast_extractor.py  → copy-paste from c/fast_extractor.py  # BANNED
```

## Files Changed

| File | Change |
|------|--------|
| `stages/languages/common/__init__.py` | **NEW** — package marker |
| `stages/languages/common/treesitter_helpers.py` | **NEW** — extracted from `c/fast_extractor.py` |
| `stages/languages/common/sql_patterns.py` | **NEW** — extracted from `c/fast_extractor.py` |
| `stages/languages/common/schema_builder.py` | **NEW** — `empty_fact_file()` template |
| `stages/languages/common/c_family_extractors.py` | **NEW** — shared C/C++/Pro*C extraction |
| `stages/languages/c/fast_extractor.py` | **MODIFIED** — imports from common, removes helpers |
| `stages/languages/cpp/fast_extractor.py` | **REWRITTEN** — own extract(), imports from common |
| `stages/languages/proc/fast_extractor.py` | **REWRITTEN** — own extract(), imports from common |
| `stages/languages/java/fast_extractor.py` | **MODIFIED** — imports SQL patterns from common |

## Tests

| Test | Validates |
|------|-----------|
| `test_no_cross_language_imports` | No `fast_extractor.py` imports from sibling language dirs |
| `test_c_extraction_unchanged` | C extractor produces identical output after refactor |
| `test_cpp_extraction_unchanged` | C++ extractor produces identical output after refactor |
| `test_proc_extraction_unchanged` | Pro*C extractor produces identical output after refactor |
| `test_java_extraction_unchanged` | Java extractor produces identical output after refactor |
| `test_common_helpers_work` | `treesitter_helpers` functions work standalone |
| `test_sql_classification` | `sql_patterns.classify_sql()` matches all categories |

## Migration

Pure refactor — no behavior change. Every extractor produces byte-identical `.facts.json` output.
Run existing test fixtures through both old and new extractors and diff the output.
