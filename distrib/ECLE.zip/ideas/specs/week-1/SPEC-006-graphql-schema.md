# SPEC-006: GraphQL Schema + Resolvers

**Status**: Implemented + Tested
**Owner**: Query Engine Engineer
**Files**: src/ecle/query/app.py, src/ecle/query/schema.py

## Purpose

The query engine. A single GraphQL endpoint that composes queries across all three backends (structured DB, vector index, topology graph). Every MCP tool and web UI query goes through this. Agents never touch backends directly.

## ADR References

- [ADR-003](../../constitution/decisions/ADR-003-graphql-query-engine.md) — GraphQL engine between MCP tools and backends
- [ADR-002](../../constitution/decisions/ADR-002-hybrid-storage-not-vector-only.md) — routes to correct backend per query type
- [ADR-015](../../constitution/decisions/ADR-015-cross-version-discovery-queries.md) — temporal queries (fileHistory, releaseDiff)

## Inputs

- Structured DB (SQLiteBackend) — for exact lookups, aggregations, version queries
- ChromaDB (ChromaDBStore) — for semantic search (returns IDs → enriched from structured DB)
- Topology edges (in structured DB for MVP) — for impact traversal via recursive CTE

## Outputs

- GraphQL endpoint at `/graphql` (served by FastAPI + Strawberry)
- GraphQL Playground UI at `/graphql` (development mode)
- JSON responses matching the schema types

## Interface

### Strawberry Types (MVP subset)

```python
@strawberry.type
class FileFact:
    file_id: str
    language: str | None
    execution_model: str | None
    complexity_max: int
    function_count: int
    sql_count: int
    commit_sha: str
    branch: str
    is_current: bool
    version_number: int
    version_distance: float | None
    source_path: str | None

    # Resolved relations (DataLoader batched)
    tables: list[TableOperation]
    functions: list[FunctionFact]
    includes: list[str]
    edges_out: list[Edge]
    edges_in: list[Edge]

    # Computed
    previous_version: FileFact | None
    history: list[FileFact]

    # Semantic (hits vector DB)
    similar: list[SimilarResult]

@strawberry.type
class FunctionFact:
    function_name: str
    file_id: str
    line_start: int
    line_end: int
    complexity: int
    return_type: str | None
    is_entry_point: bool
    calls: list[FunctionCall]
    table_ops: list[TableOperation]

@strawberry.type
class TableOperation:
    table_name: str
    operation: str           # READ | WRITE
    evidence: str | None
    line: int | None
    function_name: str | None

@strawberry.type
class FunctionCall:
    callee_name: str
    call_type: str
    line: int | None
    is_external: bool

@strawberry.type
class Edge:
    source_file: str
    target_file: str
    edge_type: str
    weight: float
    artifact: str | None
    signal_type: str | None
    confidence: float

@strawberry.type
class ImpactReport:
    source_file: str
    total_files_impacted: int
    impacted_files: list[ImpactedFile]

@strawberry.type
class ImpactedFile:
    file: FileFact
    distance: int
    impact_types: str
    artifacts: str

@strawberry.type
class SimilarResult:
    file_id: str
    score: float

@strawberry.type  
class Stats:
    files: int
    functions: int
    edges: int
    table_ops: int
```

### Queries (MVP subset)

```python
@strawberry.type
class Query:
    # Single file lookup
    file(file_id: str, repo_id: str = "default",
         commit_sha: str | None = None) -> FileFact | None

    # File listing with filters
    files(repo_id: str = "default", language: str | None = None,
          has_table: str | None = None,
          min_complexity: int | None = None,
          limit: int = 50, offset: int = 0) -> list[FileFact]

    # Function queries
    functions(repo_id: str = "default",
              callee: str | None = None,      # functions that call this name
              table: str | None = None,        # functions that touch this table
              is_entry_point: bool | None = None,
              min_complexity: int | None = None,
              limit: int = 50) -> list[FunctionFact]

    # Semantic search (→ vector DB)
    search(query: str, repo_id: str = "default",
           top_k: int = 10) -> list[SimilarResult]

    # Impact traversal (→ recursive CTE)
    impact(file_id: str, repo_id: str = "default",
           hops: int = 2, min_weight: float = 2.0) -> ImpactReport

    # Version queries
    file_history(file_id: str, repo_id: str = "default",
                 limit: int = 20) -> list[FileFact]

    # Stats
    stats(repo_id: str = "default") -> Stats
```

### DataLoaders (planned — deferred to Phase 2)

DataLoaders will batch N+1 queries within a single GraphQL request. In MVP, resolvers
use direct DB queries. The planned interface:

- file_tables: DataLoader keyed by file_fact_id, batches SELECT from file_tables
- file_functions: DataLoader keyed by file_fact_id, batches SELECT from function_facts
- function_calls: DataLoader keyed by function_id, batches SELECT from function_calls
- function_table_ops: DataLoader keyed by function_id, batches SELECT from function_table_ops
- edges_out: DataLoader keyed by file_id, batches SELECT from topology_edges (source)
- edges_in: DataLoader keyed by file_id, batches SELECT from topology_edges (target)

## Behavior

### Query Routing

| Query | Primary Backend | Secondary |
|-------|----------------|-----------|
| `file()`, `files()`, `functions()` | Structured DB | — |
| `search()` | Vector DB | Structured DB (enrich results with facts) |
| `impact()` | Structured DB (recursive CTE) | — |
| `file_history()` | Structured DB | — |
| `stats()` | Structured DB | — |
| `FileFact.similar` | Vector DB | Structured DB (enrich) |
| `FileFact.tables` | Structured DB (DataLoader) | — |
| `FileFact.functions` | Structured DB (DataLoader) | — |

### DataLoader Batching

```
Agent queries 3 files in one request:
  file(file_id: "a") { tables { ... } functions { ... } }
  file(file_id: "b") { tables { ... } functions { ... } }
  file(file_id: "c") { tables { ... } functions { ... } }

Without DataLoader: 6 DB queries (3 × tables + 3 × functions)
With DataLoader:    2 DB queries:
  SELECT * FROM file_tables WHERE file_fact_id IN ('a', 'b', 'c')
  SELECT * FROM function_facts WHERE file_fact_id IN ('a', 'b', 'c')
```

### FastAPI Mount

```python
# src/ecle/query/app.py
app = FastAPI(title="ECLE Query Engine")
schema = strawberry.Schema(query=Query)
graphql_app = GraphQLRouter(schema, context_getter=get_context)
app.include_router(graphql_app, prefix="/graphql")
```

## Dependencies

- SPEC-001 (schema)
- SPEC-002 (SQLite backend)
- SPEC-005 (ChromaDB store — for search() resolver)
- FastAPI, Strawberry, uvicorn

## Tests

Verified via CLI integration (ecle serve + manual GraphQL queries). Dedicated unit tests planned.

| Test (planned) | What's Verified |
|----------------|----------------|
| file_query | Single file lookup returns correct facts |
| files_filter_language | Language filter works |
| files_filter_table | has_table filter joins file_tables correctly |
| functions_callee_filter | Callee filter joins function_calls correctly |
| functions_entry_points | Entry point filter returns only entry points |
| impact_traversal | Impact query returns correct hops + distance |
| file_history | Version chain returned newest-first |
| stats | Stats match direct DB counts |
| dataloader_batching | N files resolved with 1 DB query per relation (not N) |
| search_returns_results | Semantic search returns ranked results (requires ChromaDB) |
| graphql_playground | GET /graphql returns playground HTML |

## Sync

Last verified: 2026-04-03
Enhancements since spec:
  - QueryContext class: holds backend connections (db + vector_store) for resolvers
  - set_context() / get_context(): module-level context management for Strawberry resolvers
  - create_app(): FastAPI app factory that wires up DB, vector store, schema, and routes
  - Root endpoint (GET /): returns server status and per-repo stats as JSON
  - DataLoaders deferred to future PR (resolvers use direct DB queries in MVP)
