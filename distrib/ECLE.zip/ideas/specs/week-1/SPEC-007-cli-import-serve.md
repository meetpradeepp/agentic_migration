# SPEC-007: CLI — ecle import + ecle serve

**Status**: Implemented + Tested
**Owner**: FACT Ingestion Engineer + Query Engine Engineer
**Files**: src/ecle/cli.py

## Purpose

The two entry points for MVP:
1. `ecle import` — load facts into the knowledge graph
2. `ecle serve` — start the GraphQL query engine

These are the commands that make the demo work:
```bash
ecle import ./joern-exports/facts/ --repo-id billing-service
ecle serve
# → GraphQL playground at http://localhost:8741/graphql
```

## ADR References

- [ADR-010](../../constitution/decisions/ADR-010-mvp-scope-and-techstack.md) — MVP scope and tech stack
- [ADR-011](../../constitution/decisions/ADR-011-cpg-storage-and-amf-reuse.md) — ecle import reuses AMF artifacts
- [ADR-012](../../constitution/decisions/ADR-012-facts-folder-sync.md) — sync semantics for import

## Interface

### CLI Commands (MVP)

```bash
# Import facts files into knowledge graph
ecle import <facts-dir> [options]
  --repo-id TEXT        Repository identifier (default: "default")
  --commit TEXT         Commit SHA to tag these facts with (default: "import")
  --branch TEXT         Branch name (default: "main")
  --db PATH             Path to SQLite DB (default: "./ecle.db")
  --sync                Retire files NOT in the folder (full sync mode)

# Start the query engine server
ecle serve [options]
  --db PATH             Path to SQLite DB (default: "./ecle.db")
  --host TEXT           Bind address (default: "127.0.0.1")
  --port INT            Port (default: 8741)
  --reload              Auto-reload on code changes (development mode)

# Show knowledge graph stats
ecle stats [options]
  --db PATH             Path to SQLite DB (default: "./ecle.db")
  --repo-id TEXT        Repository identifier (default: "default")

# Remove files from knowledge graph
ecle remove <file-ids...> [options]
  --repo-id TEXT        Repository identifier (default: "default")
  --db PATH             Path to SQLite DB (default: "./ecle.db")
  --hard                Permanently delete all history (default: soft retire)
```

### Output Format

```
$ ecle import ./joern-exports/facts/ --repo-id billing-service

ECLE Import
  Source:    ./joern-exports/facts/
  Repo:     billing-service
  Commit:   import
  
  Scanning...     18 files found
  Ingesting...    18 new, 0 updated, 0 unchanged
  Embedding...    18 files, 87 functions → 105 vectors
  Edges...        142 topology edges computed

  Knowledge graph ready:
    Files:        18
    Functions:    87
    Edges:        142
    Table ops:    54
  
  Database: ./ecle.db (2.3 MB)
  Time: 4.2 seconds

$ ecle serve

ECLE Query Engine
  Database: ./ecle.db (18 files, 87 functions, 142 edges)
  GraphQL:  http://127.0.0.1:8741/graphql
  
  Press Ctrl+C to stop.
```

## Behavior

### `ecle import`

```
1. Validate facts_dir exists and contains .facts.json files
2. Create/open SQLite DB at --db path
3. Create/open ChromaDB at {db_dir}/vectors/
4. Load facts via FactsLoader.load_directory() (SPEC-003)
   → populates structured DB (file_facts, function_facts, file_tables, etc.)
5. Compute topology edges via TopologyBuilder (SPEC-004)
   → populates topology_edges table
6. Embed via EmbeddingPipeline (SPEC-005)
   → populates ChromaDB with Layer 1 + Layer 2 vectors
   → computes version_distance for updated files
7. If --sync: run FactsLoader.sync_directory() to retire missing files
8. Print summary stats
```

### `ecle serve`

```
1. Open SQLite DB (read-only mode for queries)
2. Open ChromaDB
3. Create Strawberry schema with resolvers (SPEC-006)
4. Mount on FastAPI at /graphql
5. Start uvicorn on --host:--port
6. Serve until Ctrl+C
```

### `ecle stats`

```
1. Open SQLite DB
2. Call db.get_stats(repo_id)
3. Print formatted stats
```

### `ecle remove`

```
1. Open SQLite DB
2. Call FactsLoader.remove_files(file_ids, hard=args.hard)
3. Print what was retired/purged
```

## Dependencies

- SPEC-002 (SQLite backend)
- SPEC-003 (facts loader)
- SPEC-004 (topology builder) — for edge computation during import
- SPEC-005 (embedding pipeline) — for vector generation during import
- SPEC-006 (GraphQL schema) — for the serve command

## Tests

Verified via manual CLI execution. Dedicated unit tests planned.

| Test (planned) | What's Verified |
|----------------|----------------|
| cli_import | Import command loads fixtures, DB populated, exit code 0 |
| cli_import_stats | Stats command shows correct counts after import |
| cli_import_idempotent | Second import shows 0 new, all unchanged |
| cli_import_sync | --sync mode retires files not in folder |
| cli_remove | Remove command retires specified files |
| cli_remove_hard | --hard flag purges completely |
| cli_serve_starts | Server starts, /graphql returns 200, Ctrl+C stops |
| cli_serve_query | After import + serve, GraphQL query returns correct data |

## Sync

Last verified: 2026-04-03
Enhancements since spec:
  - Embedding step is wrapped in try/except with graceful degradation (skips if ONNX model unavailable)
  - Server command resolves vector_dir automatically from db_path parent
  - All commands implemented as module-level functions (cmd_import, cmd_serve, cmd_stats, cmd_remove) with argparse dispatch
