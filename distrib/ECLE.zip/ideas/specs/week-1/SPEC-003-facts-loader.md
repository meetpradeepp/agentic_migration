# SPEC-003: Facts Loader

**Status**: Implemented + Tested
**Owner**: FACT Ingestion Engineer
**Files**: src/ecle/ingestion/facts_loader.py

## Purpose

The primary ingestion path. Reads `.facts.json` files (produced by AMF's CPG stage or ECLE's own CPG) and populates the structured DB. Handles single files, directories, sync with removal detection, idempotent re-imports, and version chain management.

## ADR References

- [ADR-004](../../constitution/decisions/ADR-004-fps-slicer-absorbed-into-layer2.md) — facts are ingested directly, no FSS/FPS stages
- [ADR-005](../../constitution/decisions/ADR-005-amf-baseline-tech-stack.md) — reads AMF's CanonicalFactFileBase schema
- [ADR-011](../../constitution/decisions/ADR-011-cpg-storage-and-amf-reuse.md) — reuses existing AMF .facts.json outputs
- [ADR-012](../../constitution/decisions/ADR-012-facts-folder-sync.md) — content hash fast gate, directory sync, idempotency
- [ADR-013](../../constitution/decisions/ADR-013-source-to-fact-relation.md) — source provenance on each file
- [ADR-014](../../constitution/decisions/ADR-014-version-chain-everything-is-kept.md) — version chain, nothing deleted

## Inputs

| Input | Source | Format |
|-------|--------|--------|
| `.facts.json` files | `joern-exports/facts/` (AMF) or any folder | JSON matching `CanonicalFactFileBase` schema |

### Facts JSON Fields Consumed

From real AMF files (18 files examined in `joern-exports/facts/`):

| Field | Used For | Target Table |
|-------|----------|-------------|
| `filename` | file_id (basename extracted) | `file_facts.file_id` |
| `language` | language classification | `file_facts.language` |
| `functions[]` | function inventory | `function_facts` |
| `functions[].name/complexity/returnType/args/start_line/end_line` | function properties | `function_facts` columns |
| `sql_statements[]` | table operations | `file_tables` + `function_table_ops` |
| `sql_statements[].tables/category/enclosing_method/sql_text/line/host_vars` | SQL detail | columns on file_tables |
| `dependencies[]` | call relationships | `function_calls` |
| `dependencies[].name/line/args_code/external` | call detail | columns on function_calls |
| `framework_calls[]` | framework/system calls | `function_calls` (call_category set) |
| `framework_calls[].call_name/code_snippet/enclosing_method/category` | call detail | columns on function_calls |
| `datawindow_tables[]` | PowerBuilder DataWindow table refs | `file_tables` (source="DataWindow") |
| `global_defs[]` | global variable definitions | `file_definitions` (def_type="GLOBAL") |
| `struct_definitions[]` | struct/type definitions | `file_definitions` (def_type="STRUCT") |
| `includes[]` | C/C++ include directives | `file_includes` |

### Fields NOT Consumed (by design)

| Field | Why Not |
|-------|---------|
| `execution_sequence[]` | Too large (50+ AST nodes/file). Re-extract from facts on demand. |
| `local_variables[]` | Too granular for cross-file analysis. |
| `literals[]` | No cross-file value. |
| `comments[]` | Not stored (unless contains_sql=true, future). |
| `data_reads[]` / `data_writes[]` | PowerBuilder variable-level flow — too granular. |

## Outputs

Populates these tables in the structured DB:

| Table | What Gets Written |
|-------|------------------|
| `file_facts` | One row per file version with aggregate stats |
| `file_tables` | One row per (file, table, operation) from SQL statements |
| `function_facts` | One row per function |
| `function_calls` | One row per call from dependencies + framework_calls |
| `function_table_ops` | One row per (function, table, operation) from SQL scoped by enclosing_method |
| `file_includes` | One row per include/import |
| `file_definitions` | One row per global/struct definition |

## Interface

```python
class FactsLoader:
    def __init__(self, db: SQLiteBackend, repo_id: str = "default")

    # Single file
    def load_file(self, facts_path: Path, commit_sha: str = "import",
                  branch: str = "main", source_path: str | None = None,
                  source_type: str = "import", repo_url: str | None = None,
                  ) -> dict[str, Any]
    # Returns: {"file_id", "status": "new"|"updated"|"unchanged", "skipped", 
    #           "functions", "table_ops", "calls", "includes", "definitions",
    #           "version_number"}

    # Directory (batch)
    def load_directory(self, facts_dir: Path, commit_sha, branch,
                       source_type, repo_url) -> dict[str, Any]
    # Returns: {"new", "updated", "unchanged", "errors", "files": [...], "stats"}

    # Remove
    def remove_files(self, file_ids: list[str], reason: str = "removed",
                     hard: bool = False) -> dict[str, Any]
    # Returns: {"retired"/"purged", "not_found", "details": [...]}

    # Full sync (load + detect removals)
    def sync_directory(self, facts_dir: Path, ...) -> dict[str, Any]
    # Returns: load_directory result + {"removed", "removed_files": [...]}
```

## Behavior

### Fast Gate (ADR-012)
```
On each file:
  1. Compute SHA256 of facts JSON content
  2. Compare against stored facts_content_hash in file_facts
  3. If identical → return {status: "unchanged", skipped: true}
  4. If different → proceed with full ingestion
```

### Version Chain (ADR-014)
```
On file change:
  1. Mark old file_facts row: is_current=0, superseded_at=now, superseded_by=new_id
  2. Mark old function_facts rows: is_current=0
  3. Insert new file_facts with previous_id → old id, version_number incremented
  4. Insert new function_facts, function_calls, file_tables for new version
  5. Old data preserved — queryable via get_file_history()
```

### Filename Normalization
```
facts["filename"] can be:
  - Bare name: "batch_rating.ppc" → file_id = "batch_rating.ppc"
  - Absolute path: "C:\...\batch_rating.ppc" → file_id = "batch_rating.ppc" (basename extracted)

Always stored as bare filename. Original path preserved in source_path if available.
```

### SQL Category Normalization
```
READ/SELECT → "READ"
WRITE/INSERT/UPDATE/DELETE → "WRITE"
TRANSACTION → "TRANSACTION" (not stored in file_tables)
OTHER → "OTHER" (not stored in file_tables)
```

### Entry Point Detection
```
After all functions and calls loaded for a file:
  A function is an entry point if no other function IN THIS FILE calls it.
  Cross-file callers are handled by topology edges (SPEC-004, future).
```

### Execution Model Inference
```
"batch"   — has CURSOR + COMMIT in SQL, or has main() function
"event"   — has on_* or ue_* event handler functions (PowerBuilder)
"request" — default
```

### Sync Directory (ADR-012 full sync)
```
1. Load new/changed files (same as load_directory)
2. Find file_ids in DB that are NOT in the folder
3. Retire those files (soft delete — history preserved)
4. Return combined result: new + updated + unchanged + removed
```

### PowerBuilder-Specific Handling
- `datawindow_tables[]` → `file_tables` with source="DataWindow", operation="READ"
- `framework_calls[].enclosing_method` used to scope calls to specific functions
- SQL keywords in `dependencies[].name` (SELECT, INSERT, etc.) filtered out
- DataWindow files (.srd) have SQL but no functions — this is valid, not an error

## Dependencies

- SPEC-001 (structured DB schema)
- SPEC-002 (SQLite backend)

## Tests

18 tests in `tests/unit/test_facts_loader.py`:

| Test Class | Count | What's Verified |
|-----------|-------|-----------------|
| `TestSingleFileLoad` | 5 | Pro*C, PowerBuilder function, DataWindow, C header, rich SQL extraction |
| `TestIdempotency` | 1 | Same file twice → skipped on second load |
| `TestVersionChain` | 1 | Modified file creates v1→v2 linked chain |
| `TestDirectoryLoad` | 2 | All 18 fixtures loaded; second run all skipped |
| `TestRemoveFiles` | 5 | Soft retire (history preserved), edge invalidation, hard purge, nonexistent file, multiple files |
| `TestSyncDirectory` | 1 | Partial folder syncs: 2 kept, rest retired |
| `TestQueries` | 3 | find_files_by_table, find_callers_of, stats |

### Test Data

All tests use AMF's real 18 `.facts.json` files from `tests/fixtures/sample_facts/`:
- Pro*C: `batch_rating.ppc` (SQL cursors, bulk insert, host vars)
- C header: `billing_defs.h` (function declarations, no SQL)
- C++: `billing_engine.cpp`
- PowerBuilder functions: `fn_transfer_table.srf`, `f_checkmodify.srf`, `f_test_sql_extraction.srf`
- PowerBuilder windows: `w_base.srw`, `w_misth_final_form_create.srw`
- PowerBuilder objects: `u_dw.sru`, `u_searchbox.sru`, `u_button.sru`, `u_tab_base.sru`, `n_base.sru`, `n_string.sru`
- PowerBuilder DataWindows: `dw_misth_ypal_list.srd`
- PowerBuilder structures: `str_arm.srs`, `str_sql_ret.srs`
- PowerBuilder menu: `m_menu.srm`

## Sync

Last verified: 2026-04-03
Enhancements since spec:
  - (none)
