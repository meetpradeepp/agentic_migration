# SPEC-001: Structured DB Schema

**Status**: Implemented + Tested
**Owner**: Backend Engineer
**Files**: src/ecle/backends/structured/schema.py

## Purpose

Define all tables that store the knowledge graph's structured facts. This is the ground truth — vectors and graphs are derived from this data, not the other way around.

## ADR References

- [ADR-002](../../constitution/decisions/ADR-002-hybrid-storage-not-vector-only.md) — structured DB serves 80% of queries
- [ADR-005](../../constitution/decisions/ADR-005-amf-baseline-tech-stack.md) — schema grounded in real AMF .facts.json files
- [ADR-013](../../constitution/decisions/ADR-013-source-to-fact-relation.md) — source provenance fields on file_facts
- [ADR-014](../../constitution/decisions/ADR-014-version-chain-everything-is-kept.md) — version chain: previous_id, superseded_by, version_number

## Schema

12 tables organized by purpose:

### Layer 1: File-level facts

| Table | Purpose | Key Fields |
|-------|---------|-----------|
| `file_facts` | One row per file version. The primary entity. | `id`, `file_id`, `commit_sha`, `repo_id`, `branch`, `language`, `execution_model`, `complexity_max`, `function_count`, `is_current`, `previous_id`, `version_number`, `facts_content_hash`, `source_path`, `source_type` |
| `file_tables` | Table operations per file version. From `sql_statements[].tables`. | `file_fact_id`, `table_name`, `operation` (READ/WRITE), `evidence`, `line`, `function_name`, `sql_text` |
| `file_includes` | Include/import relationships. | `file_fact_id`, `target_name`, `directive`, `line` |
| `file_definitions` | Types, macros, globals, structs defined in a file. | `file_fact_id`, `def_type`, `name`, `type_info` |

### Layer 2: Function-level facts

| Table | Purpose | Key Fields |
|-------|---------|-----------|
| `function_facts` | One row per function per file version. | `id`, `file_fact_id`, `function_name`, `line_start`, `line_end`, `complexity`, `return_type`, `param_count`, `is_entry_point`, `is_current` |
| `function_calls` | Call relationships from a function. From `dependencies[]` + `framework_calls[]`. | `caller_id`, `callee_name`, `call_type`, `call_category`, `code_snippet`, `is_external` |
| `function_table_ops` | SQL operations scoped to a specific function. From `sql_statements[].enclosing_method`. | `function_id`, `table_name`, `operation`, `sql_text`, `line` |

### Topology

| Table | Purpose | Key Fields |
|-------|---------|-----------|
| `topology_edges` | Cross-file relationships (replaces FPS flow graph). | `edge_id`, `source_file`, `target_file`, `edge_type`, `weight`, `artifact`, `signal_type`, `confidence`, `evidence`, `is_valid`, `invalidated_at` |

### Layer 3 + Metadata

| Table | Purpose | Key Fields |
|-------|---------|-----------|
| `clusters` | Emergent file groupings. | `cluster_id`, `cluster_name`, `file_count`, `silhouette_score` |
| `release_tags` | Version tag → commit mapping. | `tag_name`, `commit_sha`, `repo_id` |
| `documents` | Tier 3: ingested documents. | `document_id`, `title`, `doc_type`, `content_hash` |
| `document_chunks` | Chunked document content for vector search. | `chunk_id`, `document_id`, `section_title`, `content_text` |
| `schema_meta` | Schema version tracking. | `key`, `value` |

### Indexes

Every table has targeted indexes for the queries it serves:
- `file_facts`: current files by repo, file history, commit lookup, language filter
- `file_tables`: table name lookup (the core "find files by table" query)
- `function_facts`: function name lookup, current functions, entry points
- `function_calls`: callee name lookup (the core "find callers of X" query)
- `topology_edges`: source/target file lookup, artifact lookup, edge type filter

### Design Rules

1. **All tables support versioning.** `is_current` flag separates active from historical. Nothing deleted.
2. **Version chain via `previous_id` → `superseded_by`.** Linked list per file.
3. **`facts_content_hash`** on `file_facts` enables the fast gate (ADR-012).
4. **Source provenance** (`source_path`, `source_type`, `repo_url`) on `file_facts` (ADR-013).
5. **Composite primary keys avoided** — SQLite < 3.31 doesn't support expressions in PKs. Use AUTOINCREMENT or deterministic hash IDs.

## Dependencies

None — this is the foundation. All other specs depend on this.

## Tests

Schema creation tested implicitly through every test that creates a `SQLiteBackend` — the `connect()` method runs all DDL.

## Sync

Last verified: 2026-04-03
Enhancements since spec:
  - (none)
