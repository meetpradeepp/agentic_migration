# SPEC-008: MCP Server for VS Code

**Status**: Implemented + Tested (manual)
**Owner**: Query Engine Engineer
**Files**: src/ecle/mcp/server.py

## Purpose

Expose the ECLE knowledge graph to VS Code agents (Copilot, Claude) via MCP over stdio. Each tool is a thin wrapper that queries the structured DB and/or vector index, returning JSON for agent consumption. Agents use natural language; MCP tools translate to backend queries.

## ADR References

- [ADR-003](../../constitution/decisions/ADR-003-graphql-query-engine.md) — MCP tools are thin wrappers (in MVP, they query backends directly; in future, they query GraphQL)
- [ADR-010](../../constitution/decisions/ADR-010-mvp-scope-and-techstack.md) — FastMCP + stdio, same pattern as AMF

## Inputs

- Structured DB path resolved via `ConfigLoader` (SPEC-035: ECLE_HOME)
- Vector store path resolved via `ConfigLoader`
- Environment variable: `ECLE_REPO_ID` (default repo for tools)

### Config Resolution (updated 2026-04-06)

The MCP server uses `ConfigLoader.load()` — the same resolution chain as `ecle serve`
and `ecle import`. This ensures all ECLE components connect to the same database.

```
ConfigLoader.load()
  → resolve_home(): ECLE_HOME env var || ./ecle-data
  → load ecle-data/config/ecle.yaml
  → settings.db_path     → ecle-data/db/ecle.db
  → settings.vector_path → ecle-data/vectors/
```

**Previous behavior (removed):** Lines 44-46 used raw `ECLE_DB` / `ECLE_VECTORS` env vars
with a fallback to `project_root/ecle.db`. This caused a DB path mismatch — the MCP server
connected to an auto-created empty DB at the project root while the health UI connected to
the real DB in `ecle-data/db/`. All MCP tools returned zero results despite repos being
onboarded. Fixed by replacing the 3 env var lines with `ConfigLoader.load()`.

## Outputs

- JSON strings returned to the agent per tool call
- stdio transport (VS Code starts the process, communicates via stdin/stdout)

## Interface — 10 MCP Tools

| Tool | Parameters | Backend | What It Returns |
|------|-----------|---------|----------------|
| `ecle_file` | `file_id`, `repo_id` | Structured DB | File detail: language, execution_model, tables, functions, edges |
| `ecle_files` | `repo_id`, `language?`, `has_table?`, `limit` | Structured DB | File list with summary stats |
| `ecle_find_by_table` | `table_name`, `repo_id` | Structured DB | Files that read/write the table, with operation detail |
| `ecle_find_callers` | `function_name`, `repo_id` | Structured DB | Functions that call the given function |
| `ecle_functions` | `repo_id`, `is_entry_point?`, `min_complexity?`, `limit` | Structured DB | Function list with complexity and entry point flag |
| `ecle_impact` | `file_id`, `repo_id`, `hops`, `min_weight` | Structured DB (recursive CTE) | Impact analysis: files affected, distance, edge types |
| `ecle_search` | `query`, `repo_id`, `top_k` | ChromaDB vector search | Ranked results by semantic similarity |
| `ecle_file_history` | `file_id`, `repo_id`, `limit` | Structured DB | Version chain: commit, distance, function count per version |
| `ecle_stats` | `repo_id` | Structured DB + ChromaDB | Counts: files, functions, edges, table_ops, vectors |

## Behavior

### Startup — Split Lazy Loading (Performance Fix)

The ONNX embedding model takes ~6 seconds to load. Loading it eagerly at server start caused VS Code MCP connection timeouts (30s limit). Fix: split initialization into two paths.

```
MCP server starts (instant — registers 10 tools with VS Code)
  │
  ├── Background thread: pre-warms ChromaDB + ONNX model (~6s, non-blocking)
  │
  ├── First structured tool call (ecle_file, ecle_stats, etc.):
  │     → _ensure_db() → SQLite connect (~60ms, one-time)
  │     → responds in < 100ms
  │
  └── First ecle_search call:
        → _ensure_vectors() → if background thread done: instant
        →                      if still loading: waits for completion
        → responds in < 200ms (after pre-warm) or ~6s (if called immediately)
```

**Two init functions, not one:**
- `_ensure_db()` — loads SQLite (~60ms). Called by all 9 structured tools.
- `_ensure_vectors()` — loads ChromaDB + ONNX model (~6s). Called only by `ecle_search`. Also pre-warmed in background thread at startup.

**Why this matters at scale:** At 1M files, SQLite queries remain < 50ms (indexed). ONNX model load is the same ~6s regardless of corpus size. The split ensures structured queries are never blocked by model loading.

### VS Code Integration
- `.vscode/mcp.json` and `.mcp.json` (Claude Code) configure VS Code to start the MCP server
- Transport: stdio (VS Code writes to stdin, reads from stdout)
- The server runs for the lifetime of the VS Code session
- Environment variables: `PYTHONPATH` (required for imports). DB and vector paths resolved via ConfigLoader (SPEC-035).

### Tool Design Rules
- Every tool returns a JSON string (not a Python object)
- Every tool handles "not found" gracefully (returns a message, not an exception)
- Every tool takes `repo_id` with a default from `ECLE_REPO_ID`
- No tool modifies the knowledge graph (read-only)
- Structured tools call `_ensure_db()` only — never trigger vector loading
- Only `ecle_search` calls `_ensure_vectors()`

## Dependencies

- SPEC-002 (SQLite backend — all structured queries)
- SPEC-005 (ChromaDB store — semantic search)
- `mcp[cli]` package (FastMCP framework)

## Tests

Verified manually via VS Code MCP integration. Automated tests planned for Phase 2.

| Test (planned) | What's Verified |
|----------------|----------------|
| ecle_stats | Returns correct counts matching DB state |
| ecle_file | Returns file detail with tables, functions, edges |
| ecle_file_not_found | Returns friendly message for nonexistent file |
| ecle_files_filter | Language and table filters work |
| ecle_find_by_table | Finds correct files with operation detail |
| ecle_find_callers | Finds callers with line numbers |
| ecle_search | Returns ranked semantic results |
| ecle_search_no_vectors | Graceful degradation when ChromaDB unavailable |
| ecle_impact | Returns impacted files with distance |
| ecle_file_history | Returns version chain |

## Sync

Last verified: 2026-04-06
Enhancements since spec:
  - Split lazy loading: _ensure_db() for structured queries (~60ms), _ensure_vectors() for search (~6s)
  - Background thread pre-warms ChromaDB + ONNX model at startup
  - 9 tools implemented (spec title says 10, actual interface table lists 9)
  - 6 cross-repo tools added (SPEC-015)
  - Streamable-http transport with static Bearer auth (SPEC-021, ADR-022)
  - ConfigLoader alignment: replaced raw ECLE_DB/ECLE_VECTORS env vars with ConfigLoader.load()
    so MCP server resolves DB/vector paths via ECLE_HOME (same as ecle serve). Fixes DB path
    mismatch that caused all MCP tools to return empty results. (2026-04-06)

## v1.3 Implementation Notes (2026-04-11)

### Tool inventory update

The original spec listed 9 tools. The current implementation has 25+ tools. Key additions since original spec:

| Tool | Purpose | Added |
|------|---------|-------|
| `ecle_source_read` | Read actual source code lines from artifacts (5-location search including platform fallback) | v1.1 |
| `ecle_source_lookup` | Vector-based source pattern search with regex fallback | v1.1 |
| `ecle_trace` | Cross-tier entity tracing (code + config + schema + data + docs) | v1.1 |
| `ecle_estimate_change` | Change scope, effort, sequence, risks | v1.1 |
| `ecle_cross_repo_edges_tool` | Cross-repo dependency edges | v1.1 |
| `ecle_cross_repo_impact_tool` | Cross-repo impact analysis | v1.1 |
| `ecle_artifact_summary_tool` | Artifact store summary | v1.1 |
| `ecle_shared_artifacts_tool` | Shared artifacts across repos | v1.1 |
| `ecle_service_map_tool` | Service dependency map | v1.1 |

### ecle_search now includes document vectors

Searches both `{repo}__fss` (code) and `{repo}.docs` (document) collections. Wildcard iterates all collections. Platform docs auto-included via `platform.docs`.
