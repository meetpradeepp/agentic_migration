# SPEC-005: Behavioral Signature + Vector Embeddings

**Status**: Implemented + Tested
**Owner**: FACT Ingestion Engineer
**Files**: src/ecle/ingestion/behavioral_sig.py, src/ecle/backends/vector/chromadb_store.py, src/ecle/ingestion/embedding_pipeline.py

## Purpose

Produce embedding text for each file and function, then embed into ChromaDB. The behavioral signature is a dense, fact-grounded text that captures what a file/function DOES — enabling semantic search ("find files related to billing") and behavioral change detection (cosine distance between versions).

Ported from AMF's `stages/fps/fps_slicer.py:_generate_behavioral_signature()` (ADR-004).

## ADR References

- [ADR-004](../../constitution/decisions/ADR-004-fps-slicer-absorbed-into-layer2.md) — port behavioral_signature logic from FPS slicer
- [ADR-002](../../constitution/decisions/ADR-002-hybrid-storage-not-vector-only.md) — vector stores SLIM points (embedding + 5 routing fields), full facts in structured DB
- [ADR-006](../../constitution/decisions/ADR-006-embedding-model-deferred.md) — use AMF's all-MiniLM-L6-v2 (384-dim) for MVP, benchmark later
- [ADR-007](../../constitution/decisions/ADR-007-resolved-open-questions.md) — behavioral fingerprint as fast gate; vector distance IS the fingerprint

## Inputs

| Input | Source | Used For |
|-------|--------|----------|
| `file_facts` row | Structured DB (SPEC-002) | File-level embedding text |
| `file_tables` rows | Structured DB | Tables read/written for embedding text |
| `function_facts` rows | Structured DB | Function-level embedding text |
| `function_calls` rows | Structured DB | Callees for embedding text |

**Key:** Embedding text is assembled from STRUCTURED DB, not raw facts JSON. This ensures the embedding always reflects what's actually stored — no divergence.

## Outputs

| Output | Destination | Schema |
|--------|-------------|--------|
| Layer 1 vector points | ChromaDB collection `{repo_id}__fss` | `{id, vector[384], payload: {repo_id, cluster_id, is_current, model_version, layer: 1}}` |
| Layer 2 vector points | ChromaDB collection `{repo_id}__fss` | `{id, vector[384], payload: {repo_id, cluster_id, is_current, model_version, layer: 2}}` |
| `version_distance` | Structured DB `file_facts.version_distance` | Cosine distance from previous version's embedding |

## Interface

```python
# --- Embedding text assembly ---

def assemble_file_embedding_text(
    file_facts: dict, file_tables: list[dict], functions: list[dict]
) -> str:
    """
    Build Layer 1 embedding text from structured facts.
    
    Template:
      File: {file_id} ({language})
      Execution model: {execution_model}
      Functions: {fn1, fn2, fn3}
      Entry points: {ep1, ep2}
      Reads tables: {t1, t2}
      Writes tables: {t3, t4}
      External calls: {c1, c2}
      SQL operations: {count} ({READ: n, WRITE: m})
      Max complexity: {complexity_max}
    """

def assemble_function_embedding_text(
    function_facts: dict, function_calls: list[dict], 
    function_table_ops: list[dict], file_language: str
) -> str:
    """
    Build Layer 2 embedding text (behavioral signature) from structured facts.
    
    Ported from fps_slicer.py:_generate_behavioral_signature()
    
    Template:
      Function '{name}' is a computational unit with cyclomatic complexity {n}.
      It executes database reads against tables: {t1, t2}.
      It performs state-modifying writes to tables: {t3}.
      It relies on framework calls including: {c1, c2, c3}.
    
    Priority for SQL sources (same as FPS slicer):
      function_table_ops scoped to this function
    
    Priority for calls:
      function_calls where caller_id = this function
    """

# --- ChromaDB store ---

class ChromaDBStore:
    """Vector index backend for MVP."""
    
    def __init__(self, persist_dir: str | Path)
    def get_or_create_collection(self, name: str, metadata: dict) -> Collection
    def upsert(self, collection_name: str, points: list[VectorPoint]) -> None
    def query(self, collection_name: str, query_vector: list[float], 
              top_k: int, filters: dict | None) -> list[QueryResult]
    def get_vector(self, collection_name: str, point_id: str) -> list[float] | None
    def set_payload(self, collection_name: str, point_id: str, payload: dict) -> None
    def delete(self, collection_name: str, point_ids: list[str]) -> None

# --- Embedding pipeline ---

class EmbeddingPipeline:
    """Orchestrates: structured DB → embedding text → vector → ChromaDB."""
    
    def __init__(self, db: SQLiteBackend, vector_store: ChromaDBStore,
                 embedding_model: EmbeddingModel, repo_id: str)
    
    def embed_file(self, file_fact_id: str) -> EmbedResult
    def embed_functions(self, file_fact_id: str) -> list[EmbedResult]
    def compute_version_distance(self, file_fact_id: str) -> float | None
    def embed_directory(self, repo_id: str) -> BatchEmbedResult
```

## Behavior

### Embedding Text Assembly Rules

1. **All text from structured DB** — never re-read facts JSON. The DB is the source of truth.
2. **Lists are sorted** before joining — ensures deterministic text for deterministic embeddings.
3. **Empty fields omitted** — if a file has no external calls, that line is not in the text.
4. **Truncated at 512 tokens** — embedding model max. Prioritize: tables > functions > calls.

### Version Distance (ADR-007 decision 1)

```
On file ingestion:
  1. After embedding new version → get old version's embedding from ChromaDB
  2. Compute: version_distance = 1.0 - cosine_similarity(new, old)
  3. Store in file_facts.version_distance
  
  distance < 0.05  → cosmetic change (formatting, comments)
  distance 0.05-0.2 → minor behavioral change
  distance > 0.2   → significant behavioral change
```

### Slim Vector Payloads (ADR-002)

```
Vector point payload — ONLY routing fields:
  repo_id:       str   (scoping)
  cluster_id:    str   (scoping, null initially)
  is_current:    bool  (filter current vs historical)
  model_version: str   (cross-version guard)
  layer:         int   (1=file, 2=function)

NO facts in payload. Full facts retrieved from structured DB by joining on point ID.
```

### Embedding Model

```
MVP: all-MiniLM-L6-v2 (384-dim) via ONNX runtime
Same model as AMF (models/embeddings.py)
Port AMF's LocalEmbeddingFunction — ONNX/OpenVINO, air-gapped, no internet
```

## Dependencies

- SPEC-001 (schema — for field names)
- SPEC-002 (SQLite backend — reads facts from DB)
- SPEC-003 (facts loader — facts must be loaded before embedding)
- AMF `models/embeddings.py` (embedding model code to port)
- AMF `stages/fps/fps_slicer.py:176-281` (behavioral_signature logic to port)

## Tests

Verified via integration testing (ecle import exercises full pipeline). Dedicated unit tests planned.

| Test (planned) | What's Verified |
|----------------|----------------|
| assemble_file_text | Embedding text contains file_id, language, tables, functions |
| assemble_file_text_sorted | Lists in embedding text are sorted (deterministic) |
| assemble_file_text_empty_fields | Empty fields (no external calls) omitted from text |
| assemble_function_text | Behavioral signature matches FPS slicer output format |
| assemble_function_text_with_sql | SQL reads/writes scoped to enclosing function |
| embed_file | File embedding created in ChromaDB with correct slim payload |
| embed_functions | Function embeddings created with layer=2 |
| version_distance | Distance computed between two versions of same file |
| version_distance_identical | Same content → distance ≈ 0.0 |
| chromadb_upsert_query | Round-trip: upsert vector, query by similarity, get results |
| slim_payload | Vector payload has only 5 fields, no facts data |

## Sync

Last verified: 2026-04-03
Enhancements since spec:
  - ChromaDBStore.count(): returns point count for a collection (used by stats and CLI)
  - EmbeddingPipeline.embed_all(): replaces spec's embed_directory() with simpler name, embeds all current files and functions in one call
  - VectorPoint and QueryResult dataclasses: concrete types for vector store I/O (spec showed abstract signatures)
  - ChromaDB query accepts query_text string instead of query_vector float list (ChromaDB handles embedding internally)
