# SPEC-002: SQLite Backend

**Status**: Implemented + Tested
**Owner**: Backend Engineer
**Files**: src/ecle/backends/structured/sqlite.py

## Purpose

Provide the structured fact store for MVP and single-developer mode. All knowledge graph queries for exact lookups, aggregations, joins, and graph traversal run against this backend. Same interface migrates to PostgreSQL for enterprise.

## ADR References

- [ADR-002](../../constitution/decisions/ADR-002-hybrid-storage-not-vector-only.md) — structured DB is the primary query backend (80% of queries)
- [ADR-010](../../constitution/decisions/ADR-010-mvp-scope-and-techstack.md) — SQLite for MVP, zero infrastructure
- [ADR-014](../../constitution/decisions/ADR-014-version-chain-everything-is-kept.md) — retire (soft delete) preserves history

## Inputs

- Schema DDL from `schema.py` (SPEC-001)
- Data dicts from callers (facts loader, topology builder, etc.)

## Outputs

- `ecle.db` SQLite file (WAL mode, foreign keys enabled)
- `sqlite3.Row` objects from queries (dict-like access by column name)

## Interface

```python
class SQLiteBackend:
    def __init__(self, db_path: str | Path = "ecle.db")
    def connect(self) -> None
    def close(self) -> None
    def transaction(self) -> ContextManager      # commit/rollback

    # Generic CRUD
    def execute(self, sql, params) -> Cursor
    def executemany(self, sql, params_list) -> Cursor
    def fetchone(self, sql, params) -> Row | None
    def fetchall(self, sql, params) -> list[Row]
    def insert(self, table, data: dict) -> None
    def insert_many(self, table, rows: list[dict]) -> int
    def count(self, table, where, params) -> int

    # Domain queries
    def get_current_file(self, file_id, repo_id) -> Row | None
    def get_file_tables(self, file_fact_id) -> list[Row]
    def get_functions(self, file_fact_id) -> list[Row]
    def get_function_calls(self, function_id) -> list[Row]
    def get_edges_from(self, file_id, valid_only) -> list[Row]
    def get_edges_to(self, file_id, valid_only) -> list[Row]
    def get_file_history(self, file_id, repo_id, limit) -> list[Row]
    def find_files_by_table(self, table_name, operation, repo_id) -> list[Row]
    def find_callers_of(self, callee_name, repo_id) -> list[Row]
    def impact_traversal(self, file_id, max_hops, min_weight, repo_id) -> list[Row]

    # Bulk upsert (for edge recomputation)
    def upsert_many(self, table, rows: list[dict]) -> int

    # Retire / Remove
    def retire_file(self, file_id, repo_id, reason) -> dict
    def retire_files(self, file_ids, repo_id, reason) -> dict
    def purge_file(self, file_id, repo_id) -> dict

    # Stats
    def get_stats(self, repo_id) -> dict
```

## Behavior

### Connection
- SQLite WAL mode for concurrent reads during writes
- Foreign keys enabled (`PRAGMA foreign_keys=ON`)
- Busy timeout 5 seconds (avoids "database locked" errors)
- Schema auto-created on first `connect()`

### Transactions
- `with db.transaction():` — commits on success, rolls back on exception
- Bulk operations (load_directory) wrapped in single transaction for atomicity

### Impact Traversal
- Recursive CTE starting from a file, following outbound edges
- Bounded by `max_hops` (default 2) and `min_weight` (default 2.0)
- Returns: file_id, distance (hops), impact_types, artifacts
- Groups by file_id to deduplicate paths

### Retire vs Purge
- **retire_file()**: soft delete — sets `is_current=0`, invalidates edges. History preserved. Used for normal operations.
- **purge_file()**: hard delete — removes ALL versions, ALL functions, ALL calls, ALL edges. History destroyed. Used only for "ingested by mistake" cases.

### PostgreSQL Migration Path
When we move to PostgreSQL in Phase 4:
- Same method signatures
- SQL syntax differences handled in the backend (e.g., `?` → `%s` for parameters)
- Recursive CTE syntax is identical between SQLite and PostgreSQL
- `AUTOINCREMENT` → `SERIAL`
- Same indexes, same query patterns

## Dependencies

- SPEC-001 (structured DB schema)

## Tests

Tested through `test_facts_loader.py` — every test creates a fresh `SQLiteBackend`, exercises CRUD, queries, traversal, retire, and purge.

| Test Area | What's Verified |
|-----------|----------------|
| Schema creation | Tables and indexes created on `connect()` |
| Insert + fetch | `insert()`, `fetchone()`, `fetchall()` work correctly |
| `get_current_file()` | Returns latest version, None for nonexistent |
| `find_files_by_table()` | Finds files by table name with optional operation filter |
| `find_callers_of()` | Joins function_facts → function_calls correctly |
| `get_file_history()` | Returns version chain newest-first |
| `retire_file()` | Sets is_current=0, invalidates edges, preserves history |
| `purge_file()` | Deletes all versions and dependent rows |
| `get_stats()` | Counts current files, functions, edges, table ops |
| Transaction rollback | Implicit via test isolation (each test gets fresh DB) |

## Sync

Last verified: 2026-04-03
Enhancements since spec:
  - upsert_many(): INSERT OR REPLACE for bulk edge recomputation (used by TopologyBuilder)
