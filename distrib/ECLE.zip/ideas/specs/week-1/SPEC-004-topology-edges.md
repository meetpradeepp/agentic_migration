# SPEC-004: Topology Edge Computation

**Status**: Implemented + Tested
**Owner**: FACT Ingestion Engineer
**Files**: src/ecle/ingestion/topology.py

## Purpose

Compute cross-file relationships (edges) from structured facts in the DB. This replaces AMF's FPS stage — same 9 signal detectors, but implemented as SQL index lookups instead of in-memory graph operations.

Each edge represents a structural dependency between two files: data flow, control flow, type sharing, or include relationships.

## ADR References

- [ADR-001](../../constitution/decisions/ADR-001-fact-replaces-serial-pipeline.md) — edges computed during ingestion, not a separate FPS stage
- [ADR-005](../../constitution/decisions/ADR-005-amf-baseline-tech-stack.md) — same 9 signal detectors as AMF FPS
- [ADR-014](../../constitution/decisions/ADR-014-version-chain-everything-is-kept.md) — old edges invalidated, not deleted

## Inputs

| Input | Source | Used For |
|-------|--------|----------|
| `file_facts` | Structured DB | Source/target file identification |
| `file_tables` | Structured DB | WRITE_READ signal: tables read/written per file |
| `function_facts` | Structured DB | FUNCTION_DELEGATION: functions defined per file |
| `function_calls` | Structured DB | FUNCTION_DELEGATION: functions called per file |
| `file_includes` | Structured DB | INCLUDE_DEPENDENCY: include relationships |
| `file_definitions` | Structured DB | TYPE/MACRO/GLOBAL_DEPENDENCY: definitions per file |

## Outputs

| Output | Destination |
|--------|-------------|
| Topology edges | `topology_edges` table in structured DB |

## Interface

```python
class TopologyBuilder:
    """Computes cross-file edges from structured facts using signal detectors."""

    # Canonical edge weights (from architecture doc)
    WEIGHTS = {
        "FUNCTION_CALL": 3.0,
        "WRITE_READ": 2.5,
        "EXECUTION_SEQUENCE": 2.0,
        "SHARED_TYPE": 1.0,
        "IMPORT": 0.5,
    }

    def __init__(self, db: SQLiteBackend, repo_id: str = "default")

    def compute_edges_for_file(self, file_id: str) -> list[dict]:
        """
        Compute all outbound edges FROM a file + inbound edges TO this file.
        Called during ingestion after a file's facts are loaded.
        
        1. Invalidate old edges involving this file
        2. Run all signal detectors
        3. Insert new edges
        4. Return list of edges created
        """

    def compute_all_edges(self, repo_id: str) -> dict:
        """
        Compute edges for ALL current files in a repo.
        Called during initial import/onboarding.
        
        Returns: {"edges_created": int, "files_processed": int}
        """

    # Individual signal detectors (private, each returns list of edge dicts)
    def _detect_write_read(self, file_id: str, file_fact_id: str) -> list[dict]
    def _detect_function_delegation(self, file_id: str, file_fact_id: str) -> list[dict]
    def _detect_type_dependency(self, file_id: str, file_fact_id: str) -> list[dict]
    def _detect_include_dependency(self, file_id: str, file_fact_id: str) -> list[dict]
    def _detect_macro_dependency(self, file_id: str, file_fact_id: str) -> list[dict]
    def _detect_global_dependency(self, file_id: str, file_fact_id: str) -> list[dict]
    def _detect_flag_continuity(self, file_id: str, file_fact_id: str) -> list[dict]
    def _detect_datawindow_bridge(self, file_id: str, file_fact_id: str) -> list[dict]
    def _detect_financial_dependency(self, file_id: str, file_fact_id: str) -> list[dict]
```

## Signal Detectors — Reimplemented as SQL

Each detector in AMF's `stages/fps/signals/` becomes a SQL query against the structured DB. 10 detectors total (from AMF code research).

### Summary Table

| # | Detector | Signal Type | Edge Type | Weight | Confidence | Evidence | AMF Fields | ECLE Table |
|---|----------|-------------|-----------|--------|------------|----------|------------|------------|
| 1 | WriteRead | WRITE_READ | DATA_FLOW | 2.5 | 0.8 | E1 | node.writes / node.reads | file_tables (operation=WRITE ↔ READ) |
| 2 | FunctionDelegation | FUNCTION_DELEGATION | CONTROL_FLOW | 3.0 | 0.9 | E1 | external_calls, framework_calls / functions_defined | function_calls ↔ function_facts |
| 3 | TypeDependency | TYPE_DEPENDENCY | STRUCTURAL | 1.0 | 1.0 | E1 | types_used / types_defined | file_definitions (def_type=STRUCT/TYPE) |
| 4 | IncludeDependency | INCLUDE_DEPENDENCY | STRUCTURAL | 0.5 | 1.0 | E1 | includes_categorized["user_headers"] / file basename | file_includes ↔ file_facts.file_id |
| 5 | MacroDependency | MACRO_DEPENDENCY | STRUCTURAL | 1.0 | 1.0 | E1 | macros_used / macros_defined | file_definitions (def_type=MACRO) |
| 6 | GlobalDependency | GLOBAL_DEPENDENCY | DATA_FLOW or STATE_FLOW | 1.0 | 0.95 | E1 | globals_accessed (both nodes) | file_definitions (def_type=GLOBAL) |
| 7 | FlagContinuity | FLAG_CONTINUITY | STATE_FLOW | 2.0 | 1.0 | E1 | states_written / states_read | (parsed from file_tables patterns) |
| 8 | StructuralSequence | STRUCTURAL_SEQUENCE | STRUCTURAL | 0.5 | 0.6 | E2 | file extensions, compilation_unit | file_facts.file_id + extension matching |
| 9 | FinancialDependency | FINANCIAL_DEPENDENCY | DATA_FLOW | 2.5 | 0.7 | E2 | writes / reads (financial keyword filter) | file_tables + financial keyword check |
| 10 | DataWindowBridge | DATAWINDOW_BRIDGE | STRUCTURAL | 0.5 | 0.95 | E1 | declared_dataobjects / .srd file | file_definitions ↔ file_facts (.srd) |

### Signal 1: WRITE_READ (highest value — most cross-file edges)

```
AMF logic: SQLTableExtractor extracts table names from node.writes and node.reads.
           Set intersection finds shared tables.

ECLE SQL:
  SELECT DISTINCT 
    ff_writer.file_id AS source_file,
    ff_reader.file_id AS target_file,
    ft_writer.table_name AS artifact
  FROM file_tables ft_writer
  JOIN file_tables ft_reader ON ft_writer.table_name = ft_reader.table_name
  JOIN file_facts ff_writer ON ft_writer.file_fact_id = ff_writer.id
  JOIN file_facts ff_reader ON ft_reader.file_fact_id = ff_reader.id
  WHERE ff_writer.id = :this_file_fact_id
    AND ft_writer.operation = 'WRITE'
    AND ft_reader.operation = 'READ'
    AND ff_reader.is_current = 1
    AND ff_reader.file_id != ff_writer.file_id

Edge: type=WRITE_READ, weight=2.5, artifact=table_name, confidence=0.8, evidence=E1
Also detects reverse: who WRITES to tables I READ → edge writer→me
```

### Signal 2: FUNCTION_DELEGATION (strongest coupling — weight 3.0)

```
AMF logic: Matches source.external_calls[].name against target.functions_defined[].name.
           Validates call is NOT internal to source. Boosts to 0.95 if in system_map.

ECLE SQL:
  SELECT DISTINCT
    ff_caller.file_id AS source_file,
    ff_target.file_id AS target_file,
    fc.callee_name AS artifact
  FROM function_calls fc
  JOIN function_facts fn_caller ON fc.caller_id = fn_caller.id
  JOIN file_facts ff_caller ON fn_caller.file_fact_id = ff_caller.id
  JOIN function_facts fn_target ON fn_target.function_name = fc.callee_name
                                 AND fn_target.is_current = 1
  JOIN file_facts ff_target ON fn_target.file_fact_id = ff_target.id
                             AND ff_target.is_current = 1
  WHERE ff_caller.id = :this_file_fact_id
    AND ff_target.file_id != ff_caller.file_id

Edge: type=FUNCTION_CALL, weight=3.0, artifact=callee_name, confidence=0.9, evidence=E1
```

### Signal 3: TYPE_DEPENDENCY

```
AMF logic: Exact match source.types_used vs target.types_defined (case-sensitive).

ECLE SQL:
  SELECT DISTINCT
    ff_user.file_id AS source_file,
    ff_definer.file_id AS target_file,
    fd_definer.name AS artifact
  FROM file_definitions fd_user
  JOIN file_definitions fd_definer ON fd_user.name = fd_definer.name
  JOIN file_facts ff_user ON fd_user.file_fact_id = ff_user.id
  JOIN file_facts ff_definer ON fd_definer.file_fact_id = ff_definer.id
  WHERE ff_user.id = :this_file_fact_id
    AND fd_user.def_type IN ('STRUCT', 'TYPE')     -- this file USES this type
    AND fd_definer.def_type IN ('STRUCT', 'TYPE')   -- other file DEFINES it
    AND ff_definer.is_current = 1
    AND ff_definer.file_id != ff_user.file_id

Edge: type=SHARED_TYPE, weight=1.0, confidence=1.0, evidence=E1
Note: In MVP, file_definitions stores both definitions and usages.
      May need a usage_type field to distinguish. Alternatively, treat
      shared name across files as dependency (conservative, catches all cases).
```

### Signal 4: INCLUDE_DEPENDENCY

```
AMF logic: Matches includes_categorized["user_headers"] against target file basename.
           Normalizes: strips quotes/brackets, matches stem/extension variants.

ECLE SQL:
  SELECT DISTINCT
    ff_source.file_id AS source_file,
    ff_target.file_id AS target_file,
    fi.target_name AS artifact
  FROM file_includes fi
  JOIN file_facts ff_source ON fi.file_fact_id = ff_source.id
  JOIN file_facts ff_target ON (
    ff_target.file_id = fi.target_name  -- exact match
    OR ff_target.file_id LIKE '%' || fi.target_name  -- basename match
  )
  WHERE ff_source.id = :this_file_fact_id
    AND ff_target.is_current = 1
    AND ff_target.file_id != ff_source.file_id

Edge: type=IMPORT, weight=0.5, confidence=1.0, evidence=E1
```

### Signal 5: MACRO_DEPENDENCY

```
AMF logic: Exact match macros_used vs macros_defined. Filters system macros
           (starting with __, _, NULL, EOF, TRUE, FALSE, MAX, MIN, etc.).

ECLE SQL: Same pattern as TYPE_DEPENDENCY but with def_type='MACRO'.
          Filter system macros in Python before creating edge.

Edge: type=SHARED_TYPE, weight=1.0, confidence=1.0, evidence=E1
```

### Signal 6: GLOBAL_DEPENDENCY

```
AMF logic: Intersection of globals_accessed between two files.
           Edge type = DATA_FLOW if global in source.writes AND target.reads,
           otherwise STATE_FLOW.

ECLE SQL: Same pattern as TYPE_DEPENDENCY but with def_type='GLOBAL'.
          Both files must have the same global name in file_definitions.

Edge: type=DATA_FLOW or STATE_FLOW, weight=1.0, confidence=0.95, evidence=E1
```

### Signal 7: FLAG_CONTINUITY

```
AMF logic: Parses states_written ("field NULL → 'value'") and 
           states_read ("field='value'"). Matches field (case-insensitive)
           and value (case-sensitive).

ECLE: In MVP, this comes from file_tables where artifacts look like state fields.
      Low priority for MVP — flag/state patterns are rare in the test fixtures.
      Stub the detector, implement fully when we have state-heavy codebases.

Edge: type=EXECUTION_SEQUENCE, weight=2.0, confidence=1.0, evidence=E1
```

### Signal 8: STRUCTURAL_SEQUENCE

```
AMF logic: Three strategies:
  1. Header (.h) before source (.c) with matching basenames
  2. Target includes source via includes_categorized
  3. Link dependency via compilation_unit

ECLE SQL (strategy 1 — header/source pairing):
  SELECT ff_source.file_id AS source_file, ff_target.file_id AS target_file
  FROM file_facts ff_source, file_facts ff_target
  WHERE ff_source.id = :this_file_fact_id
    AND ff_source.file_id LIKE '%.h'
    AND ff_target.file_id LIKE '%.c'  -- or .cpp, .cc
    AND REPLACE(ff_source.file_id, '.h', '') = REPLACE(ff_target.file_id, '.c', '')
    AND ff_target.is_current = 1

Edge: type=IMPORT, weight=0.5, confidence=0.6, evidence=E2
```

### Signal 9: FINANCIAL_DEPENDENCY

```
AMF logic: Same as WRITE_READ but filtered to financial artifacts.
           Keywords: amount, balance, charge, credit, debit, fee, price, rate,
           total, tax, invoice, payment, transaction, billing, revenue, cost,
           premium, discount, refund, account, ledger.

ECLE: Run WRITE_READ detector, then filter artifacts against financial keywords.
      If artifact matches → create FINANCIAL_DEPENDENCY edge (lower confidence).

Edge: type=WRITE_READ, weight=2.5, confidence=0.7, evidence=E2
```

### Signal 10: DATAWINDOW_BRIDGE (PowerBuilder-specific)

```
AMF logic: Source declares dataobject "dw_X" → target is dw_X.srd file.
           Case-insensitive match on stem.

ECLE SQL:
  SELECT DISTINCT
    ff_source.file_id AS source_file,
    ff_target.file_id AS target_file,
    fd.name AS artifact
  FROM file_definitions fd
  JOIN file_facts ff_source ON fd.file_fact_id = ff_source.id
  JOIN file_facts ff_target ON LOWER(ff_target.file_id) = LOWER(fd.name || '.srd')
                             AND ff_target.is_current = 1
  WHERE ff_source.id = :this_file_fact_id
    AND fd.def_type = 'STRUCT'  -- dataobjects stored as struct definitions
    AND ff_target.file_id LIKE '%.srd'

Edge: type=IMPORT, weight=0.5, confidence=0.95, evidence=E1
```

### MVP Priority

For the first implementation, prioritize detectors by value:

```
P0 (implement first — highest edge yield):
  Signal 1: WRITE_READ         — the primary data flow signal
  Signal 2: FUNCTION_DELEGATION — the primary control flow signal
  Signal 4: INCLUDE_DEPENDENCY  — structural coupling

P1 (implement second — fills in structural picture):
  Signal 3: TYPE_DEPENDENCY
  Signal 6: GLOBAL_DEPENDENCY
  Signal 10: DATAWINDOW_BRIDGE (if PB files present)

P2 (implement later — lower value or rare):
  Signal 5: MACRO_DEPENDENCY
  Signal 7: FLAG_CONTINUITY
  Signal 8: STRUCTURAL_SEQUENCE
  Signal 9: FINANCIAL_DEPENDENCY
```

## Behavior

### Edge Computation During Import

```
ecle import ./facts/:
  1. FactsLoader loads all files → structured DB populated
  2. TopologyBuilder.compute_all_edges() runs:
     For each current file:
       Run all 9 signal detectors (each is a SQL query)
       Collect edges, deduplicate by (source, target, type, artifact)
       Insert into topology_edges
```

### Edge Computation During Incremental Update

```
File X changed:
  1. TopologyBuilder.compute_edges_for_file("X"):
     a. Invalidate all existing edges WHERE source_file = "X" OR target_file = "X"
     b. Run all 9 detectors for file X
     c. Insert new edges
  2. Neighbors don't need edge recomputation — only X's edges change
     (Neighbor RE-EVALUATION happens in embedding pipeline, not topology)
```

### Edge Deduplication

```
Same two files may be connected by multiple signals:
  File A writes TABLE_X (WRITE_READ) AND calls function_F in File B (FUNCTION_CALL)
  → TWO edges, different types and weights
  
Same signal may find multiple artifacts:
  File A writes TABLE_X AND TABLE_Y, both read by File B
  → TWO WRITE_READ edges, different artifacts
  
Dedup key: (source_file, target_file, edge_type, artifact)
If same key appears from multiple detectors → keep highest confidence
```

### Edge ID Generation

```python
def _edge_id(source: str, target: str, edge_type: str, artifact: str, commit: str) -> str:
    return _sha256(f"{source}:{target}:{edge_type}:{artifact}:{commit}".encode())[:24]
```

## Dependencies

- SPEC-001 (schema — topology_edges table)
- SPEC-002 (SQLite backend — insert, query)
- SPEC-003 (facts loader — facts must be loaded first)

## Tests

| Test | What's Verified |
|------|----------------|
| `test_write_read_edges_created` | Files sharing table via WRITE/READ get WRITE_READ edge |
| `test_write_read_shared_table` | Cross-file edges from shared table operations |
| `test_function_call_edges` | File calling function defined in another file gets FUNCTION_CALL edge |
| `test_no_self_edges` | A file never has an edge to itself |
| `test_include_edge` | File including another gets IMPORT edge |
| `test_include_edge_weight` | IMPORT edges have weight 0.5 |
| `test_weights_match_spec` | FUNCTION_CALL=3.0, WRITE_READ=2.5, IMPORT=0.5 |
| `test_invalidation_on_recompute` | On file re-import, old edges invalidated, new edges created |
| `test_invalidation_preserves_old_when_different` | Recomputing one file preserves other files' edges |
| `test_compute_all` | All 18 fixtures processed, edges created between related files |
| `test_edges_queryable_after_compute` | After computing edges, impact_traversal works |
| `test_impact_traversal` | Import + compute edges → impact query returns correct results |
| `test_no_duplicate_edges` | Same (source, target, type, artifact) → only one edge |

## Sync

Last verified: 2026-04-03
Enhancements since spec:
  - Constructor takes commit_sha parameter (used for edge ID generation and invalidation tracking)
  - compute_all_edges() uses self.repo_id instead of repo_id parameter (simplified API)
