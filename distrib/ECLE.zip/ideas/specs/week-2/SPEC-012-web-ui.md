# SPEC-012: Web UI — Onboarding + Chat

**Status**: Implemented + Tested
**Owner**: Query Engine Engineer
**Files**: `src/ecle/ui/routes.py`, `src/ecle/ui/templates/*.html`, `src/ecle/query/llm_router.py`, `src/ecle/query/llm_summarizer.py`

## Purpose

Browser-based interface for three workflows:
1. **Onboarding**: point at a folder/repo/docs → see progress → knowledge graph ready
2. **Chat**: ask questions in natural language → get grounded answers with evidence
3. **System Health**: spec-code sync status, knowledge graph stats, drift monitoring

The UI is served by the same FastAPI server as the GraphQL endpoint.

## ADR References

- [ADR-007](../../constitution/decisions/ADR-007-resolved-open-questions.md) — LLM at query time only: tool routing + answer summarization
- [ADR-010](../../constitution/decisions/ADR-010-mvp-scope-and-techstack.md) — HTML + htmx, no JS build pipeline, SSE for streaming

## Inputs

| Input | Source |
|-------|--------|
| User's natural language question | Chat input box |
| Onboarding parameters (path, repo_id, type) | Onboarding form |

## Outputs

| Output | Where |
|--------|-------|
| HTML pages | Browser at `http://localhost:8741/` |
| SSE events | Streaming progress + chat responses |
| Grounded answers | Chat responses with evidence links |

## Interface

### Routes

```python
# Served by FastAPI (same app as GraphQL)

# Onboarding
GET  /                   → redirect to /ui/
GET  /ui/                → onboarding page (default)
POST /ui/onboard         → trigger onboarding (returns SSE progress stream)

# Chat
GET  /ui/chat            → chat page
GET  /ui/chat/{repo_id}  → chat page scoped to a repo
POST /ui/chat/ask        → ask a question (returns SSE answer stream)

# System Health
GET  /ui/health          → system health dashboard
GET  /ui/health/specs    → spec-code sync status
GET  /ui/health/repos    → per-repo knowledge graph stats
POST /ui/health/sync     → trigger spec sync check (returns results)

# API (JSON)
GET  /ui/status          → current knowledge graph status (JSON)
GET  /api/specs/sync     → spec sync check results (JSON, for CI/scripts)
```

### Onboarding Page — Tabbed by Source Type

```
┌────────────────────────────────────────────────────────────┐
│  ECLE — Onboard                                             │
│                                                              │
│  ┌──────────┬──────────┬──────────────┬──────────────────┐  │
│  │  Code    │  Git     │  Documents   │  Import Facts    │  │
│  └──────────┴──────────┴──────────────┴──────────────────┘  │
│                                                              │
│  ═══ TAB: Code (local folder) ═══════════════════════════   │
│                                                              │
│  Source folder: [_____________________________] [Browse]     │
│  Repo ID:       [billing-service______________]              │
│                                                              │
│  [Start Onboarding]                                          │
│                                                              │
│  ═══ TAB: Git ═══════════════════════════════════════════   │
│                                                              │
│  Repository:    [https://github.com/acme/billing] or        │
│                 [git@github.com:acme/billing.git]            │
│  Branch:        [main____________________________]           │
│  Repo ID:       [billing-service_________________]           │
│  Auth:          ○ None (public)                              │
│                 ○ Token  [_______________________]           │
│                 ○ SSH (system keys)                           │
│                 ○ System git credentials                      │
│                                                              │
│  [Start Onboarding]                                          │
│                                                              │
│  ═══ TAB: Documents ════════════════════════════════════    │
│                                                              │
│  Source:        ○ Local folder  ○ URL (Confluence/Wiki)      │
│  Path/URL:      [_____________________________] [Browse]     │
│  Repo ID:       [billing-service______________]              │
│                                                              │
│  Auto-detected types:                                        │
│    ✓ Markdown (.md)          12 files found                  │
│    ✓ SQL/DDL (.sql, .ddl)     3 files found                  │
│    ✓ Plain text (.txt)        2 files found                  │
│    ○ PDF (.pdf)               1 file found  [needs pymupdf]  │
│    ○ Word (.docx)             0 files found                  │
│    ○ OpenAPI (.yaml)          1 file found                   │
│    ○ Excel (.xlsx, .csv)      0 files found                  │
│                                                              │
│  Type override: [auto-detect ▼]  (force specific reader)    │
│                                                              │
│  [Start Onboarding]                                          │
│                                                              │
│  ═══ TAB: Import Facts ═════════════════════════════════    │
│                                                              │
│  Facts folder:  [_____________________________] [Browse]     │
│  Repo ID:       [billing-service______________]              │
│  ☐ Sync mode (retire files not in folder)                    │
│                                                              │
│  [Import]                                                    │
│                                                              │
│  ─── Progress (SSE live, shown for all tabs) ────────────   │
│  ████████████████████████████░░░  88%                       │
│                                                              │
│  Code:   18 files, 154 functions                             │
│  Docs:   15 documents, 47 chunks                             │
│  DDL:    3 schemas, 24 tables, 186 columns                   │
│  Edges:  27 topology + 34 cross-references                   │
│  Vectors: 172 code + 47 doc = 219 total                      │
│                                                              │
│  ✓ Knowledge graph ready                                     │
│                                                              │
│  [Open Chat →]  [View Health →]                              │
└────────────────────────────────────────────────────────────┘
```

### Onboarding Progress — Combined View

When code + docs are onboarded together, the progress shows both:

```
Progress breakdown:
  Phase 1: Code ingestion
    Facts:     18 new, 0 updated
    Edges:     27 computed
    Vectors:   172 embedded (18 files + 154 functions)

  Phase 2: Document ingestion
    Documents: 15 processed (12 markdown, 3 DDL)
    Chunks:    47 created
    Vectors:   47 embedded
    DDL:       3 schemas → 24 tables, 186 columns extracted
    Cross-refs: 34 entity references found
      - 12 table name matches (code ↔ docs)
      - 18 file name matches
      - 4 function name matches

  Total knowledge graph:
    Code:      18 files, 154 functions, 27 edges
    Documents: 15 docs, 47 chunks, 34 cross-references
    DDL:       24 tables, 186 columns
    Vectors:   219 total (172 code + 47 docs)
```

### Chat Page

```
┌────────────────────────────────────────────────────────┐
│  ECLE — billing-service                                  │
│  18 files │ 154 functions │ 27 edges │ 172 vectors      │
│                                                          │
│  ┌──────────────────────────────────────────────────┐   │
│  │ You: What does batch_rating.ppc do?               │   │
│  │                                                    │   │
│  │ ECLE: batch_rating.ppc is a Pro*C batch            │   │
│  │ processor that:                                    │   │
│  │ • Reads from UNRATED_CDRS (open_cdr_cursor, L53)  │   │
│  │ • Calculates cost via calculate_cost()             │   │
│  │ • Writes to RATED_CDRS (bulk_insert, L116)         │   │
│  │ • Updates UNRATED_CDRS status (L124)               │   │
│  │                                                    │   │
│  │ 8 functions, max complexity 5.                     │   │
│  │ Execution model: batch                              │   │
│  │                                                    │   │
│  │ Evidence: [file_facts] [file_tables] [topology]    │   │
│  └──────────────────────────────────────────────────┘   │
│                                                          │
│  [Ask a question...                          ] [Send]    │
└────────────────────────────────────────────────────────┘
```

## Behavior

### LLM Router (question → GraphQL queries)
```python
class LLMRouter:
    """Interprets a natural language question and selects GraphQL queries."""

    def route(self, question: str, repo_id: str) -> list[QueryPlan]:
        """
        Uses LLM (Claude API) to decompose question into backend queries.
        
        Example: "What does batch_rating.ppc do?"
        → QueryPlan: [file(fileId: "batch_rating.ppc")]
        
        Example: "What files touch FEES_LEDGER?"
        → QueryPlan: [files(hasTable: "FEES_LEDGER")]
        
        Example: "What's the impact of changing the billing module?"
        → QueryPlan: [search("billing"), impact(fileId: top_result)]
        """
```

### LLM Summarizer (structured facts → human answer)
```python
class LLMSummarizer:
    """Synthesizes a human-readable answer from structured query results."""

    def summarize(self, question: str, query_results: dict,
                  repo_id: str) -> str:
        """
        Takes structured facts and produces a grounded narrative.
        
        Every claim must reference the evidence source.
        Unknown = "I don't have evidence for that" (never guess).
        """
```

### Streaming (SSE)
```
Both onboarding progress and chat answers stream via Server-Sent Events:

Onboarding: POST /ui/onboard → SSE stream
  event: progress  data: {"phase": "facts", "count": 12, "total": 18}
  event: progress  data: {"phase": "edges", "count": 27}
  event: progress  data: {"phase": "vectors", "count": 172}
  event: complete  data: {"stats": {...}}

Chat: POST /ui/chat/ask → SSE stream
  event: thinking  data: {"step": "routing query..."}
  event: thinking  data: {"step": "querying structured DB..."}
  event: token     data: {"text": "batch_rating.ppc is a "}
  event: token     data: {"text": "Pro*C batch processor..."}
  event: done      data: {"evidence": [...]}
```

### System Health Dashboard

```
Screen 3: System Health
┌────────────────────────────────────────────────────────────┐
│  ECLE — System Health                                       │
│                                                              │
│  ─── Knowledge Graph ──────────────────────────────────     │
│                                                              │
│  Repository          Files  Functions  Edges  Vectors  Status│
│  billing-service       18       154      27     172    Active│
│                                                              │
│  ─── Spec-Code Sync ──────────────────────────────────      │
│                                                              │
│  Spec                          Interface  Tests   Status     │
│  SPEC-001 Structured DB schema  ✓ 12/12    —      SYNCED    │
│  SPEC-002 SQLite backend        ✓ 22/22   18/18   SYNCED    │
│  SPEC-003 Facts loader          ✓  4/4    18/18   SYNCED    │
│  SPEC-004 Topology edges        ✓  3/3    13/13   SYNCED    │
│  SPEC-005 Behavioral sig        ✓  5/5     —      SYNCED    │
│  SPEC-006 GraphQL schema        ✓  8/8     —      SYNCED    │
│  SPEC-007 CLI                   ✓  4/4     —      SYNCED    │
│  SPEC-008 MCP server            ✓ 10/10    —      SYNCED    │
│  SPEC-009 Git onboarding        —          —      PENDING   │
│  SPEC-010 Git integration       —          —      PENDING   │
│  SPEC-011 Document onboarding   —          —      PENDING   │
│  SPEC-012 Web UI                —          —      PENDING   │
│                                                              │
│  Last sync check: 2026-04-03 14:30 UTC                      │
│  [Run Sync Check]                                            │
│                                                              │
│  ─── Enhancements Log ─────────────────────────────────     │
│                                                              │
│  SPEC-002: + upsert_many() for edge recomputation            │
│  SPEC-005: + count(), query accepts text, VectorPoint class  │
│  SPEC-006: + QueryContext, create_app() factory              │
│  SPEC-007: + graceful embedding degradation                  │
│  SPEC-008: + split lazy loading, background pre-warm         │
│                                                              │
│  ─── Constitution ─────────────────────────────────────     │
│                                                              │
│  ADRs: 16 (all accepted)                                     │
│  Contracts: 10                                               │
│  Coding standards: enforced (ruff clean)                     │
│  Tests: 31 passing                                           │
│                                                              │
└────────────────────────────────────────────────────────────┘
```

### Spec Sync Detail View (click on a spec row)

```
┌────────────────────────────────────────────────────────────┐
│  SPEC-002: SQLite Backend                                    │
│  Status: Implemented + Tested     Last verified: 2026-04-03 │
│                                                              │
│  ─── Interface ────────────────────────────────────────     │
│  File: src/ecle/backends/structured/sqlite.py                │
│                                                              │
│  Method                  In Spec?  In Code?                  │
│  connect()                 ✓         ✓                       │
│  close()                   ✓         ✓                       │
│  insert()                  ✓         ✓                       │
│  insert_many()             ✓         ✓                       │
│  upsert_many()             —         ✓  (enhancement)        │
│  fetchone()                ✓         ✓                       │
│  fetchall()                ✓         ✓                       │
│  count()                   ✓         ✓                       │
│  get_current_file()        ✓         ✓                       │
│  retire_file()             ✓         ✓                       │
│  purge_file()              ✓         ✓                       │
│  impact_traversal()        ✓         ✓                       │
│  ...                                                         │
│                                                              │
│  ─── Enhancements ─────────────────────────────────────     │
│  upsert_many(): INSERT OR REPLACE for bulk edge recomputation│
│  (Added during SPEC-004 implementation — edges need upsert)  │
│                                                              │
│  ─── Tests ────────────────────────────────────────────     │
│  18 tests in tests/unit/test_facts_loader.py                 │
│  13 tests in tests/unit/test_topology.py                     │
│  All passing ✓                                               │
│                                                              │
│  [View Spec File]  [View Source File]  [View Tests]          │
└────────────────────────────────────────────────────────────┘
```

### Spec Sync API (for CI/automation)

```python
class SpecSyncChecker:
    """Runs spec-code sync validation. Used by UI and CI."""

    def __init__(self, project_root: Path)

    def check_all(self) -> SpecSyncReport
        """
        Run full sync check across all specs.
        Returns structured report for UI rendering or JSON API.
        """

    def check_spec(self, spec_name: str) -> SpecStatus
        """Check a single spec against its code files."""

@dataclass
class SpecSyncReport:
    specs: list[SpecStatus]
    total_synced: int
    total_drift: int
    total_enhanced: int
    total_pending: int
    checked_at: str

@dataclass
class SpecStatus:
    name: str                           # "SPEC-002"
    title: str                          # "SQLite Backend"
    status: str                         # SYNCED | DRIFT | ENHANCED | PENDING
    files: list[str]                    # source files
    interface_match: int                # methods in spec that exist in code
    interface_total: int                # total methods in spec
    interface_additions: list[str]      # methods in code not in spec
    test_match: int                     # tests in spec that exist in test files
    test_total: int                     # total tests in spec
    enhancements: list[str]             # from spec's Sync section
    last_verified: str                  # ISO8601
```

### Technology
```
HTML templates: Jinja2 (built into FastAPI/Starlette)
Interactivity: htmx (partial page updates, SSE handling)
Styling: classless CSS (simple, no build step) — e.g., Water.css or Pico CSS
LLM: Claude API via anthropic Python SDK (or configurable provider)
Spec sync: scripts/spec_sync_check.py (imported as library)
No React, no npm, no build pipeline.
```

## Dependencies

- SPEC-006 (GraphQL schema — chat queries go through same resolvers)
- SPEC-007 (CLI / FastAPI app — UI routes added to same server)
- SPEC-008 (MCP tools — chat uses same query logic)
- SPEC-009 (git onboarding — onboard form triggers same pipeline)
- SPEC-011 (document onboarding — docs tab in onboard form)
- `scripts/spec_sync_check.py` (sync validation engine — refactored into importable module)
- `anthropic` SDK (for LLM router + summarizer)
- `jinja2` (template rendering)

## Tests

### Onboarding UI
| Test | What's Verified |
|------|----------------|
| `test_ui_onboard_page_tabs` | GET /ui/ returns HTML with 4 tabs (Code, Git, Documents, Import) |
| `test_ui_onboard_code_tab` | Code tab has folder path + repo ID fields |
| `test_ui_onboard_git_tab` | Git tab has URL + branch + auth options (None/Token/SSH/System) |
| `test_ui_onboard_docs_tab` | Docs tab has path + auto-detected file types with counts |
| `test_ui_onboard_docs_type_detection` | Folder scan shows per-extension file counts |
| `test_ui_onboard_docs_type_override` | Type override dropdown forces specific reader |
| `test_ui_onboard_docs_missing_reader` | PDF shown as "needs pymupdf" if dependency not installed |
| `test_ui_onboard_import_tab` | Import Facts tab has folder path + sync checkbox |
| `test_ui_onboard_trigger` | POST /ui/onboard returns SSE stream with progress |
| `test_ui_onboard_progress_combined` | Progress shows code + docs + DDL stats combined |

### Chat UI
| Test | What's Verified |
|------|----------------|
| `test_ui_chat_page` | GET /ui/chat returns HTML with chat interface |
| `test_ui_chat_ask_simple` | POST /ui/chat/ask with simple question returns answer |
| `test_ui_chat_cross_tier` | "What do the docs say about billing?" returns doc chunks + code files |
| `test_llm_router_file_question` | "What does X do?" routes to file() query |
| `test_llm_router_table_question` | "What touches table X?" routes to files(hasTable) query |
| `test_llm_router_impact_question` | "What's affected by X?" routes to impact() query |
| `test_llm_router_doc_question` | "What does the architecture doc say about X?" routes to doc search |
| `test_llm_summarizer_grounded` | Answer references evidence, no hallucination |

### System Health UI
| Test | What's Verified |
|------|----------------|
| `test_ui_health_page` | GET /ui/health returns dashboard with repo stats + spec sync |
| `test_ui_health_knowledge_graph` | Shows per-repo stats: files, functions, edges, docs, vectors |
| `test_ui_health_specs` | GET /ui/health/specs shows all specs with sync status |
| `test_ui_health_sync_trigger` | POST /ui/health/sync runs sync check, returns results |
| `test_api_specs_sync` | GET /api/specs/sync returns JSON report (for CI) |
| `test_spec_sync_report_structure` | Report has per-spec status, interface/test counts |
| `test_ui_status` | GET /ui/status returns JSON stats including doc counts |

## v1.3 Implementation Notes (2026-04-11)

**Status**: Implemented (Chat UI removed)

### Breaking changes from original spec

- **Chat UI removed** — `/ui/chat` routes commented out. MCP is the primary query interface. SPEC-019 (LLM Chat) parked pending API keys.
- **Onboard UI redesigned** — 4-tab layout replaced by SPEC-040 unified form with three-axis dropdowns (content type, source, scope). Original tab descriptions are obsolete.
- **LLMRouter / LLMSummarizer** — not active. Chat behavior section describes removed functionality.

### New features not in original spec

| Feature | Location |
|---------|----------|
| No-cache headers on `/ui/*` + `/api/*` | `app.py` NoCacheMiddleware |
| Jinja2 `auto_reload = True` | `routes.py:37` |
| Repo name auto-fill from folder name | `onboard.html:326` — extracts folder name from `webkitRelativePath`, auto-fills or auto-selects matching repo |
| Spaces → hyphens in repo name | `onboard.html:79` `oninput` handler |
| Dynamic code extensions from language packs | `onboard.html` `_CODE_EXTS` built from `/ui/extensions` API |

### Tests to update

| Original Test | Status |
|--------------|--------|
| `test_ui_chat_page` | Remove — chat UI removed |
| `test_ui_chat_ask_simple` | Remove — chat UI removed |
| `test_ui_chat_cross_tier` | Remove — chat UI removed |
| `test_ui_onboard_page_tabs` | Update — no tabs, unified form |
