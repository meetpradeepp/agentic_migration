# SPEC-009: Git Repository Onboarding

**Status**: Partially Superseded by SPEC-040 (unified onboard model). Git is now a `source` axis, not a standalone onboarding path. GitConnector implementation unchanged.
**Owner**: Source Mesh Engineer + FACT Ingestion Engineer
**Files**: `src/ecle/connectors/git.py`, `src/ecle/onboarding/pipeline.py`, `src/ecle/cli.py`, `src/ecle/ingestion/validation.py` (new)

## Purpose

Onboard a git repository: clone → enumerate files → run CPG (or read existing facts) → FACT ingestion → knowledge graph ready. Extends the current `ecle import` (which reads a facts folder) to handle git repos directly.

## ADR References

- [ADR-010](../../constitution/decisions/ADR-010-mvp-scope-and-techstack.md) — 4 onboarding modes: local folder, git repo, git integration, documents
- [ADR-011](../../constitution/decisions/ADR-011-cpg-storage-and-amf-reuse.md) — reuse existing facts if available, CPG only for files without facts
- [ADR-013](../../constitution/decisions/ADR-013-source-to-fact-relation.md) — full git provenance (repo_url, commit_sha, branch, source_path)

## Inputs

| Input | Source | Example |
|-------|--------|---------|
| Git repo URL | User (CLI/UI) | `https://github.com/acme/billing.git` |
| Local repo path | User (CLI) | `/path/to/already-cloned-repo` |
| Branch | User (default: main) | `main`, `develop` |
| Existing facts dir | Optional | `--facts-dir /path/to/joern-exports/facts/` |

## Outputs

| Output | Where |
|--------|-------|
| Cloned repo | `{ecle_data}/repos/{repo_id}/source/` |
| Facts files | `{ecle_data}/repos/{repo_id}/cpg/facts/` |
| Knowledge graph | `ecle.db` + `vectors/` (same as `ecle import`) |

## Interface

### CLI

```bash
# Onboard from git URL (clone + analyze)
ecle onboard https://github.com/acme/billing.git --branch main --repo-id billing

# Onboard from local already-cloned repo
ecle onboard /path/to/repo --branch main --repo-id billing

# Onboard with existing facts (skip CPG for files with facts)
ecle onboard /path/to/repo --facts-dir ./joern-exports/facts/ --repo-id billing
```

### CLI (with authentication)

```bash
# Public repo — no auth needed
ecle onboard https://github.com/acme/public-repo.git --repo-id demo

# HTTPS with Personal Access Token (GitHub, GitLab, Azure DevOps)
ecle onboard https://github.com/acme/private-repo.git --repo-id billing \
    --token $GITHUB_TOKEN

# HTTPS with token from environment variable (auto-detected)
export ECLE_GIT_TOKEN=ghp_xxxxxxxxxxxx
ecle onboard https://github.com/acme/private-repo.git --repo-id billing

# SSH (uses system SSH agent / ~/.ssh keys — no ECLE config needed)
ecle onboard git@github.com:acme/private-repo.git --repo-id billing

# Azure DevOps (PAT-based)
ecle onboard https://dev.azure.com/org/project/_git/repo --repo-id billing \
    --token $AZURE_DEVOPS_PAT

# GitLab (PAT or OAuth token)
ecle onboard https://gitlab.com/acme/private-repo.git --repo-id billing \
    --token $GITLAB_TOKEN

# Use system git credential manager (whatever git is configured with)
ecle onboard https://github.com/acme/private-repo.git --repo-id billing \
    --use-system-credentials
```

### Python

```python
class GitConnector:
    """Clone/open a git repo and enumerate source files."""

    def __init__(self, repo_url_or_path: str, branch: str = "main",
                 clone_dir: Path | None = None,
                 token: str | None = None,
                 use_system_credentials: bool = False)

    def clone_or_open(self) -> Path
        """Clone if URL, or validate if local path. Returns repo root."""

    def get_head_commit(self) -> str
        """Return HEAD commit SHA of the current branch."""

    def list_source_files(self, extensions: set[str] | None = None) -> list[Path]
        """List all source files in the repo (filtered by extension)."""

    def get_file_content(self, file_path: Path) -> str
        """Read file content at current HEAD."""


class OnboardingPipeline:
    """Orchestrates: source → CPG → facts → FACT ingestion."""

    def __init__(self, db: SQLiteBackend, vector_store: ChromaDBStore,
                 repo_id: str)

    def onboard(self, repo_path: Path, branch: str = "main",
                facts_dir: Path | None = None,
                repo_url: str | None = None) -> OnboardResult
        """
        Full onboarding:
        1. Enumerate source files
        2. For each file: check if facts exist → if yes, reuse; if no, run CPG
        3. Load all facts via FactsLoader
        4. Compute topology edges
        5. Embed into ChromaDB
        6. Return summary
        """
```

## Behavior

### Authentication Strategy
```
ECLE never stores credentials. It uses one of these methods (in priority order):

1. --token flag or ECLE_GIT_TOKEN env var (HTTPS PAT)
   → Injects token into clone URL: https://{token}@github.com/org/repo.git
   → Works with: GitHub PAT, GitLab PAT, Azure DevOps PAT
   → Token is NOT stored in ecle.db or any config file
   → Token is NOT logged (security: never log credentials)

2. SSH URL (git@github.com:...)
   → Uses system SSH agent or ~/.ssh/id_rsa
   → No ECLE configuration needed — relies on system git/ssh setup
   → Works with: GitHub deploy keys, SSH agent forwarding

3. --use-system-credentials flag
   → Delegates to git credential manager (git credential-manager, osxkeychain, etc.)
   → Whatever `git clone` would use natively, ECLE uses too
   → Works with: corporate credential managers, SSO-integrated setups

4. No auth (public repos)
   → Plain HTTPS clone, no token needed

For continuous ingestion (SPEC-010):
   → Token must be available at runtime (env var, not --flag)
   → Git hooks run as the developer (their credentials)
   → GitHub Actions use ${{ secrets.GITHUB_TOKEN }} (repo-scoped, auto-provided)
```

### Clone Strategy
```
If input is a URL (starts with http/https/git@):
  1. Resolve authentication (token → URL injection, or SSH, or system credentials)
  2. Clone to {ecle_data}/repos/{repo_id}/source/
  3. Checkout --branch {branch}
  4. Record repo_url (WITHOUT token), commit_sha, branch in provenance
     IMPORTANT: strip token from URL before storing. Never persist credentials.

If input is a local path:
  1. Validate it's a directory (or a git repo)
  2. If it's a git repo: read remote URL, HEAD commit, branch
  3. If it's a plain directory: source_type = "local", no git provenance
```

### CPG Strategy (when --facts-dir not provided)
```
For MVP: use existing Joern/parsers from AMF
  - Import AMF's stages/cpg/run.py as a library
  - Or: shell out to `python stages/cpg/run.py` with the source dir

For each source file:
  1. Check if {facts_dir}/{filename}.facts.json exists AND is newer than source
  2. If yes → reuse (skip CPG)
  3. If no → run CPG extraction → produce .facts.json
```

### Facts Ingestion (after CPG)
```
Same as ecle import, but with full provenance:
  - source_type = "git" (not "import")
  - repo_url = git remote URL
  - commit_sha = HEAD commit
  - branch = current branch
  - source_path = relative path within repo
```

### Supported Source Extensions (MVP)
```
C/C++:       .c, .cpp, .cc, .cxx, .h, .hpp, .hh
Pro*C:       .ppc, .pc
PowerBuilder: .sru, .srf, .srw, .srm, .srd, .srs
Java:        .java
Python:      .py
Go:          .go
JavaScript:  .js, .ts
```

## Dependencies

- SPEC-002 (SQLite backend)
- SPEC-003 (facts loader — with provenance)
- SPEC-004 (topology builder)
- SPEC-005 (embedding pipeline)
- AMF `stages/cpg/run.py` (CPG extraction engine)
- `subprocess` for git clone (no gitpython dependency for MVP)

## Tests

| Test | What's Verified |
|------|----------------|
| `test_git_connector_local_repo` | Opens a local git repo, lists files, reads HEAD commit |
| `test_git_connector_list_files` | Filters by source extension |
| `test_git_connector_token_url_injection` | Token injected into HTTPS URL correctly |
| `test_git_connector_token_stripped_from_provenance` | Token NOT stored in repo_url in DB |
| `test_git_connector_ssh_url` | SSH URL passed through without modification |
| `test_git_connector_env_token` | ECLE_GIT_TOKEN env var picked up when --token not provided |
| `test_git_connector_auth_failure` | Clear error when auth fails (not a stacktrace) |
| `test_onboard_with_existing_facts` | Reuses facts, doesn't run CPG |
| `test_onboard_provenance` | file_facts have repo_url (no token), commit_sha, branch, source_path |
| `test_onboard_full_pipeline` | Source → facts → structured DB → edges → vectors |
| `test_cli_onboard_command` | `ecle onboard` CLI works end-to-end |
