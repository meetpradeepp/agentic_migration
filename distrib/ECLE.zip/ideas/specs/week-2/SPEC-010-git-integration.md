# SPEC-010: Git Integration — Continuous Ingestion on Commit

**Status**: Implemented + Tested
**Owner**: Source Mesh Engineer + FACT Ingestion Engineer
**Files**: `src/ecle/connectors/git_watcher.py`, `src/ecle/ingestion/incremental.py`, `src/ecle/cli.py` (new `watch` + `ingest` commands)

## Purpose

After a repo is onboarded, keep the knowledge graph current. When a developer commits, ECLE detects the change and ingests only the changed files. Three trigger mechanisms: polling, git hook, GitHub Action.

This is the "Timely" in FACT — knowledge reflects the latest commit.

## ADR References

- [ADR-007](../../constitution/decisions/ADR-007-resolved-open-questions.md) — behavioral fingerprint as fast gate: skip unchanged files
- [ADR-010](../../constitution/decisions/ADR-010-mvp-scope-and-techstack.md) — git integration: polling, hooks, GitHub Actions
- [ADR-014](../../constitution/decisions/ADR-014-version-chain-everything-is-kept.md) — version chain: old facts preserved, new facts linked

## Inputs

| Input | Source | When |
|-------|--------|------|
| New commit SHA | Git poll / hook / API call | On every push |
| Changed file list | `git diff --name-only {old_sha} {new_sha}` | Derived from commit |
| Source content | Git repo (cloned or local) | Read changed files |

## Outputs

| Output | Where |
|--------|-------|
| Updated facts (changed files only) | `ecle.db` file_facts (new version, old preserved) |
| Updated edges (recomputed for changed files) | `ecle.db` topology_edges |
| Updated vectors (re-embedded changed files) | `vectors/` ChromaDB |
| Neighbor re-evaluation | Embeddings refreshed for high-weight neighbors |

## Interface

### CLI

```bash
# Ingest a specific commit (called by hook or CI)
ecle ingest --commit abc123 --repo-id billing --db ecle.db

# Watch a repo for new commits (polling)
ecle watch /path/to/repo --repo-id billing --interval 60 --db ecle.db

# Generate a git hook script
ecle hook --repo-id billing --db /absolute/path/ecle.db > .git/hooks/post-commit
chmod +x .git/hooks/post-commit
```

### REST API (for GitHub Actions to call)

```
POST /api/ingest
{
  "repo_id": "billing",
  "commit_sha": "abc123",
  "changed_files": ["src/fee_calculator.c", "src/billing_defs.h"]  // optional
}
```

### Python

```python
class IncrementalIngestor:
    """Ingest only changed files from a new commit."""

    def __init__(self, db: SQLiteBackend, vector_store: ChromaDBStore,
                 repo_id: str, repo_path: Path)

    def ingest_commit(self, commit_sha: str,
                      changed_files: list[str] | None = None) -> IngestResult
        """
        1. If changed_files not provided: git diff to get them
        2. For each changed file:
           a. Run CPG extraction → new .facts.json
           b. Fast gate: compare facts_content_hash with stored
           c. If unchanged → skip
           d. If changed → FactsLoader.load_file() (creates version chain)
        3. Recompute topology edges for changed files
        4. Re-embed changed files + their high-weight neighbors
        5. Return summary
        """

class GitWatcher:
    """Poll a git repo for new commits and trigger ingestion."""

    def __init__(self, repo_path: Path, repo_id: str, db: SQLiteBackend,
                 vector_store: ChromaDBStore, interval_seconds: int = 60)

    def watch(self) -> None
        """
        Loop:
        1. git fetch origin
        2. Compare local HEAD with remote HEAD
        3. If different: git pull, get new commits, ingest each
        4. Sleep interval_seconds
        5. Repeat until Ctrl+C
        """

    def get_new_commits(self) -> list[str]
        """Return commit SHAs since last processed commit."""
```

## Behavior

### Incremental Ingestion Flow
```
Commit abc123 changes: [fee_calculator.c, billing_defs.h]

For each file:
  1. CPG extraction → fee_calculator.c.facts.json (new version)
  2. facts_content_hash = SHA256(new facts JSON)
  3. Compare with stored hash in file_facts
     - billing_defs.h: hash unchanged (only comment added) → SKIP
     - fee_calculator.c: hash changed → proceed
  4. FactsLoader.load_file() → creates version chain (v2, previous_id → v1)
  5. TopologyBuilder.compute_edges_for_file("fee_calculator.c")
     → invalidate old edges, compute new ones
  6. EmbeddingPipeline.embed_file(new_file_fact_id)
     → new Layer 1 + Layer 2 vectors

Neighbor re-evaluation:
  7. Query: SELECT target_file FROM topology_edges
     WHERE source_file = 'fee_calculator.c' AND weight >= 2.0 AND is_valid = 1
     → returns neighbors with strong coupling
  8. For each neighbor: re-embed (their "called_by" context changed)
     → no new facts, just refreshed embeddings
```

### Authentication for Continuous Ingestion

```
Continuous ingestion runs UNATTENDED — no human to type a password.
Authentication must be pre-configured and non-interactive.

Git Hook (post-commit):
  → Runs as the developer who committed
  → Uses their git credentials (already authenticated — they just pushed)
  → No ECLE auth config needed. If they can push, they can ingest.

Polling (ecle watch):
  → Runs as a background process / service
  → Needs credentials for `git fetch origin`
  → Uses ECLE_GIT_TOKEN env var (set when starting the watcher)
  → Or: system git credential manager (if configured)
  → Or: SSH key (if repo was cloned via SSH)

GitHub Action:
  → Uses ${{ secrets.GITHUB_TOKEN }} (auto-provided by GitHub, repo-scoped)
  → Or: ${{ secrets.ECLE_PAT }} for cross-repo access
  → Token scoped to read-only (contents: read) — ingestion doesn't push

Azure DevOps Pipeline:
  → Uses $(System.AccessToken) (auto-provided, scoped to repo)
  → Or: service connection token

GitLab CI:
  → Uses $CI_JOB_TOKEN (auto-provided, scoped to project)
  → Or: $ECLE_GITLAB_TOKEN for cross-project access

SECURITY RULES:
  → Tokens NEVER logged, even at DEBUG level
  → Tokens NEVER stored in ecle.db or any file
  → Tokens NEVER appear in error messages
  → If auth fails: "Authentication failed for {repo_url}" (no token in message)
  → Token is stripped from any URL before storing in provenance
```

### Git Hook (post-commit)
```bash
#!/bin/bash
# Generated by: ecle hook --repo-id billing --db /path/ecle.db
# Runs as the committing developer — uses their git credentials
COMMIT=$(git rev-parse HEAD)
CHANGED=$(git diff --name-only HEAD~1 HEAD)
/path/to/.venv/Scripts/python.exe -m ecle.cli ingest \
  --commit "$COMMIT" \
  --repo-id billing \
  --db /path/ecle.db \
  --files $CHANGED
```

### GitHub Action Template
```yaml
# Generated by: ecle github-action --repo-id billing
name: ECLE Ingest
on:
  push:
    branches: [main, develop]
jobs:
  ingest:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - run: pip install ecle
      - run: ecle ingest --commit ${{ github.sha }} --repo-id billing
        env:
          ECLE_GIT_TOKEN: ${{ secrets.GITHUB_TOKEN }}  # auto-provided, read-only
```

### Polling (ecle watch)
```
Startup:
  Requires: ECLE_GIT_TOKEN env var OR SSH access OR system git credentials
  Validates: can `git fetch origin` succeed? If not → fail fast with clear auth error.

Loop:
  1. Record last_processed_commit from DB
  2. git fetch origin (uses pre-configured credentials)
  3. git log --oneline last_processed..origin/branch → list of new commits
  4. For each new commit (oldest first):
     a. git diff --name-only {prev} {current} → changed files
     b. ingest_commit(commit_sha, changed_files)
  5. Update last_processed_commit in DB
  6. Sleep interval
  7. Repeat
```

## Dependencies

- SPEC-002 (SQLite backend)
- SPEC-003 (facts loader — version chain)
- SPEC-004 (topology builder — edge recomputation)
- SPEC-005 (embedding pipeline — re-embed changed files + neighbors)
- SPEC-009 (git onboarding — GitConnector, CPG extraction)

## Tests

| Test | What's Verified |
|------|----------------|
| `test_ingest_commit_changed_file` | Changed file creates new version, old preserved |
| `test_ingest_commit_unchanged_skipped` | Unchanged file (same hash) skipped |
| `test_ingest_commit_edges_recomputed` | Old edges invalidated, new edges for changed file |
| `test_ingest_commit_vectors_updated` | New embedding for changed file |
| `test_neighbor_reevaluation` | High-weight neighbors get re-embedded |
| `test_git_watcher_detects_new_commits` | Watcher finds commits since last processed |
| `test_git_watcher_auth_failure_on_start` | Watcher fails fast with clear error if fetch auth fails |
| `test_git_watcher_token_from_env` | ECLE_GIT_TOKEN used for fetch when set |
| `test_token_never_logged` | Token doesn't appear in any log output or error message |
| `test_cli_ingest_command` | `ecle ingest --commit` works |
| `test_cli_watch_command` | `ecle watch` starts and processes commits |
| `test_github_action_template` | Generated YAML includes ECLE_GIT_TOKEN from secrets |
