# SPEC-011: Document Onboarding (Tier 3)

**Status**: Partially Superseded by SPEC-040 (unified onboard model). Documents is now a `content_type` axis, can come from git or local. Reader implementations unchanged.
**Owner**: FACT Ingestion Engineer
**Files**: src/ecle/connectors/document.py, src/ecle/ingestion/document_chunker.py, src/ecle/ingestion/document_embedder.py, src/ecle/ingestion/readers/, src/ecle/cli.py

## Purpose

Ingest non-code documents alongside code facts. Enterprise codebases have architecture docs, design specs, DB schemas, API specs, runbooks, data dictionaries, and presentations — all containing knowledge that enriches code discovery.

ECLE needs to read DIFFERENT file types, extract text intelligently, chunk it, embed it, and cross-reference it with code entities. The reader must handle each format's quirks without losing structure.

This is Tier 3 knowledge (ADR-008) — separately ingested, same grounding principle.

## ADR References

- [ADR-008](../../constitution/decisions/ADR-008-ecle-as-knowledge-engine.md) — Tier 3 non-code knowledge
- [ADR-010](../../constitution/decisions/ADR-010-mvp-scope-and-techstack.md) — document onboarding in MVP

## Inputs

| Type | Extensions | Reader | What's Extracted | Priority |
|------|-----------|--------|-----------------|----------|
| **Markdown** | `.md` | Direct text parse | Headings → section structure, text → chunks | P0 (MVP) |
| **Plain text** | `.txt`, `.rst`, `.log` | Direct text | Paragraphs → chunks | P0 (MVP) |
| **DDL / SQL** | `.ddl`, `.sql` | SQL statement splitter | Statements → chunks; table/column names → structured metadata | P0 (MVP) |
| **PDF** | `.pdf` | `pymupdf` or `pdfplumber` | Page text extraction → chunks | P1 |
| **Word** | `.docx` | `python-docx` | Paragraphs + tables → text → chunks | P1 |
| **OpenAPI** | `.yaml`, `.json` (with `openapi:` field) | YAML/JSON parse | Endpoints, methods, schemas → structured DB + text chunks | P1 |
| **Excel** | `.xlsx`, `.csv` | `openpyxl` / `csv` | Rows → text (data dictionaries, mapping tables) | P2 |
| **Confluence** | URL (API) | REST API → HTML → text | Pages → sections → chunks | P2 |
| **PowerPoint** | `.pptx` | `python-pptx` | Slide text → chunks (diagrams lost) | P2 |
| **Mermaid / PlantUML** | `.mmd`, `.puml` (or embedded in `.md`) | Parse → nodes + edges | Architecture graph → structured DB (not vector) | P2 |

**MVP builds P0 (markdown, text, DDL/SQL). P1 and P2 are the reader plugin architecture that makes adding new types trivial.**

## Outputs

| Output | Where |
|--------|-------|
| Document metadata | `documents` table in structured DB |
| Document chunks | `document_chunks` table in structured DB |
| Chunk embeddings | ChromaDB collection `{repo_id}__fss` with `layer: 4` |
| Entity cross-references | `document_references` table (links doc mentions to code entities) |
| Structured extractions (DDL, OpenAPI) | `db_tables`, `db_columns`, `api_endpoints` tables (ADR-008) |

## Interface

### CLI

```bash
# Onboard documents from a folder (auto-detects types by extension)
ecle onboard-docs /path/to/docs/ --repo-id billing

# Onboard a single document
ecle onboard-docs /path/to/architecture.md --repo-id billing

# Onboard with type hint (when extension is ambiguous)
ecle onboard-docs /path/to/api-spec.yaml --repo-id billing --type openapi

# Onboard from URL (Confluence, wiki)
ecle onboard-docs --url https://confluence.acme.com/display/BILLING/Architecture \
    --repo-id billing --type confluence --token $CONFLUENCE_TOKEN
```

### Python — Reader Plugin Architecture

```python
class DocumentReader(ABC):
    """Base class for all document type readers."""

    @abstractmethod
    def can_read(self, path: Path) -> bool:
        """Return True if this reader can handle this file type."""

    @abstractmethod
    def read(self, path: Path) -> DocumentContent:
        """Read file and extract structured text content."""

    @abstractmethod
    def supported_extensions(self) -> set[str]:
        """Return file extensions this reader handles."""


@dataclass
class DocumentContent:
    path: Path
    title: str              # extracted from content (first heading, filename, etc.)
    doc_type: str           # markdown | text | ddl | pdf | docx | openapi | excel | confluence
    sections: list[DocumentSection]  # structured content with hierarchy
    content_hash: str       # SHA256 for change detection
    metadata: dict          # type-specific metadata (page count, table count, etc.)


@dataclass
class DocumentSection:
    title: str | None       # section heading (None for untitled sections)
    level: int              # heading level (1=H1, 2=H2, etc.) or 0 for no heading
    content: str            # text content of this section
    subsections: list[DocumentSection]  # nested sections
    # Structured extractions (type-specific):
    tables_defined: list[str] | None    # for DDL: table names
    columns_defined: list[dict] | None  # for DDL: column definitions
    endpoints: list[dict] | None        # for OpenAPI: endpoint definitions


class DocumentReaderRegistry:
    """Registry of document readers. Auto-discovers readers by extension."""

    def __init__(self):
        self._readers: list[DocumentReader] = []

    def register(self, reader: DocumentReader) -> None:
        self._readers.append(reader)

    def get_reader(self, path: Path) -> DocumentReader | None:
        """Find a reader that can handle this file type."""
        for reader in self._readers:
            if reader.can_read(path):
                return reader
        return None

    def supported_extensions(self) -> set[str]:
        """All extensions handled by registered readers."""
        exts = set()
        for reader in self._readers:
            exts.update(reader.supported_extensions())
        return exts
```

### Concrete Readers (P0 — MVP)

```python
class MarkdownReader(DocumentReader):
    """Reads .md files. Splits by headings into sections."""

    def supported_extensions(self) -> set[str]:
        return {".md"}

    def read(self, path: Path) -> DocumentContent:
        """
        Parse markdown into sections:
        1. Split by heading lines (# / ## / ###)
        2. Each heading starts a new section at its level
        3. Content between headings = section content
        4. Nested headings = subsections
        5. Title = first H1 or filename
        """


class PlainTextReader(DocumentReader):
    """Reads .txt, .rst, .log files. Splits by paragraphs."""

    def supported_extensions(self) -> set[str]:
        return {".txt", ".rst", ".log"}

    def read(self, path: Path) -> DocumentContent:
        """
        Parse plain text into sections:
        1. Split by double newlines (paragraphs)
        2. Each paragraph = one section (level=0, no title)
        3. RST: detect underline headings (====, ----) for section structure
        4. Title = first line or filename
        """


class DDLReader(DocumentReader):
    """Reads .ddl, .sql files. Extracts table/column definitions."""

    def supported_extensions(self) -> set[str]:
        return {".ddl", ".sql"}

    def read(self, path: Path) -> DocumentContent:
        """
        Parse DDL/SQL into sections:
        1. Split by semicolons (statement boundaries)
        2. Each CREATE TABLE = one section
           - title = table name
           - content = full CREATE statement
           - tables_defined = [table_name]
           - columns_defined = [{name, type, nullable, pk, fk}]
        3. ALTER TABLE, CREATE INDEX = separate sections
        4. Comments and non-DDL statements = generic text sections
        5. INSERT/UPDATE/DELETE = data operations (section, no table extraction)
        """
```

### Concrete Readers (P1 — Post-MVP)

```python
class PDFReader(DocumentReader):
    """Reads .pdf files. Extracts page text."""

    def supported_extensions(self) -> set[str]:
        return {".pdf"}

    def read(self, path: Path) -> DocumentContent:
        """
        Uses pymupdf (fitz) or pdfplumber:
        1. Extract text per page
        2. Detect headings by font size / bold (heuristic)
        3. Tables extracted as text grids
        4. Images → skip (log as "image at page N, not extracted")
        5. Each page = one section (or split by detected headings)
        
        Known limitations:
        - Scanned PDFs (images of text) → not supported without OCR
        - Complex layouts (multi-column) → may interleave text
        - Embedded diagrams → lost (noted in metadata)
        """
    # Dependency: pymupdf>=1.24.0 or pdfplumber>=0.11.0


class DocxReader(DocumentReader):
    """Reads .docx files. Extracts paragraphs and tables."""

    def supported_extensions(self) -> set[str]:
        return {".docx"}

    def read(self, path: Path) -> DocumentContent:
        """
        Uses python-docx:
        1. Iterate paragraphs — detect heading styles (Heading 1, Heading 2, etc.)
        2. Each heading starts a new section at its level
        3. Tables → flattened to text rows ("| col1 | col2 | col3 |")
        4. Images → skip (noted in metadata)
        5. Track lists, bold, italic → stripped to plain text for embedding
        
        Known limitations:
        - Embedded Excel charts → not extracted
        - Track changes / comments → not extracted in MVP
        """
    # Dependency: python-docx>=1.1.0


class OpenAPIReader(DocumentReader):
    """Reads OpenAPI/Swagger specs (.yaml, .json)."""

    def supported_extensions(self) -> set[str]:
        return {".yaml", ".yml", ".json"}  # only if content has "openapi:" field

    def can_read(self, path: Path) -> bool:
        """Check if file is actually OpenAPI (not just any YAML)."""
        try:
            content = path.read_text()[:200]
            return "openapi:" in content or '"openapi"' in content
        except Exception:
            return False

    def read(self, path: Path) -> DocumentContent:
        """
        Parse OpenAPI spec:
        1. Each path+method = one section
           - title = "GET /api/billing/invoices"
           - content = description + parameters + response schema
           - endpoints = [{path, method, parameters, response_schema}]
        2. Schema definitions = sections with table-like structure
           - title = schema name
           - columns_defined = [{name, type, required}]
        3. Info/description = overview section
        """
    # Dependency: pyyaml (already in deps)


class ExcelReader(DocumentReader):
    """Reads .xlsx, .csv files (data dictionaries, mapping tables)."""

    def supported_extensions(self) -> set[str]:
        return {".xlsx", ".csv"}

    def read(self, path: Path) -> DocumentContent:
        """
        For CSV: read rows, first row = headers
        For XLSX: each sheet = one section
        
        1. First row = column headers
        2. Each subsequent row = text: "column1: value1, column2: value2, ..."
        3. If columns look like data dictionary (name, type, description) →
           extract as columns_defined
        4. Sheet name = section title
        
        Heuristic: if a column is named "table", "column", "type", "description"
        → treat as data dictionary and extract structured metadata
        """
    # Dependency: openpyxl>=3.1.0 (for xlsx), csv (stdlib)
```

### Chunker — Type-Aware

```python
class DocumentChunker:
    """Split documents into chunks for embedding. Strategy varies by type."""

    def __init__(self, max_chunk_tokens: int = 500, overlap_tokens: int = 50)

    def chunk(self, doc: DocumentContent) -> list[DocumentChunk]:
        """
        Chunks based on document's section structure:
        
        1. Walk sections recursively
        2. If section fits in max_chunk_tokens → one chunk
        3. If section too large → split by subsections
        4. If no subsections → split by paragraphs
        5. If paragraph too large → split by sentences
        6. Each chunk carries: section_title, chunk_index, parent section hierarchy
        
        For DDL sections with tables_defined:
           → chunk also produces structured extraction → db_tables / db_columns
        
        For OpenAPI sections with endpoints:
           → chunk also produces structured extraction → api_endpoints
        """

    def _estimate_tokens(self, text: str) -> int:
        """Rough token estimate: len(text) / 4 (good enough for chunking)."""
```

### Entity Cross-Referencing

```python
class EntityExtractor:
    """Extract references to code entities from document text."""

    def __init__(self, db: SQLiteBackend, repo_id: str)

    def extract_references(self, chunk_text: str) -> list[EntityReference]:
        """
        Scan chunk text for mentions of known entities:
        
        1. Get all file_ids from file_facts → case-insensitive search in text
        2. Get all table_names from file_tables → case-insensitive search in text
        3. Get all function_names from function_facts → case-insensitive search
        4. For DDL: table names in CREATE TABLE → link to file_tables entries
        5. For OpenAPI: endpoint paths → link to function entry points
        
        Returns matches with surrounding context (20 chars before/after).
        """

@dataclass
class EntityReference:
    entity_name: str        # "FEES_LEDGER", "batch_rating.ppc", "compute_late_fee"
    entity_type: str        # FILE | TABLE | FUNCTION | SERVICE | API_ENDPOINT
    mention_context: str    # surrounding text (for display in UI)
    confidence: float       # 1.0 for exact match, 0.8 for case-insensitive, 0.6 for partial
```

## Behavior

### Reader Selection
```
1. User provides path (file or folder)
2. DocumentReaderRegistry iterates registered readers
3. For each file:
   a. Match by extension first (fast)
   b. If ambiguous (.yaml → could be OpenAPI or config), check can_read() (content sniff)
   c. If no reader matches → skip with warning ("unsupported: config.yaml")
4. User can override with --type flag (forces specific reader)
```

### Chunking Strategy (per type)
```
Markdown:
  Section tree from headings → each section = chunk (or split if too large)
  Code blocks (```...```) kept intact in chunks (don't split mid-code)
  
Plain text / RST:
  Paragraphs (double newline) → merge small paragraphs → split large ones
  
DDL / SQL:
  Statement (;) boundaries → each CREATE TABLE is one chunk
  Also: extract table/column metadata → db_tables / db_columns tables
  
PDF:
  Page boundaries → then heading detection → section-based chunking
  
Word:
  Heading styles → section tree → same as Markdown
  Tables → flattened to |-delimited text within their section's chunk

OpenAPI:
  Each path+method = one chunk
  Each schema = one chunk
  Also: extract endpoint metadata → api_endpoints table

Excel / CSV:
  Each sheet = one section
  Rows grouped into chunks of max_chunk_tokens
  Data dictionary heuristic → extract column metadata
```

### What Gets Stored Where
```
ALL document types:
  documents table       → metadata (title, type, hash, chunk count)
  document_chunks table → text content per chunk
  ChromaDB (layer=4)    → embeddings for semantic search
  document_references   → cross-links to code entities

DDL documents additionally:
  db_tables table       → table name, column count, source file
  db_columns table      → column name, type, nullable, PK/FK
  (These link to file_tables via table_name — enabling cross-tier queries)

OpenAPI documents additionally:
  api_endpoints table   → path, method, handler file/function
  (These link to function_facts via handler matching)
```

### Structured DB Schema

Existing (from SPEC-001):
```sql
documents:        document_id, title, doc_type, source_url, content_hash, chunk_count
document_chunks:  chunk_id, document_id, section_title, chunk_index, content_text, token_count
```

New tables needed:
```sql
CREATE TABLE IF NOT EXISTS document_references (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    document_id     TEXT NOT NULL REFERENCES documents(document_id),
    chunk_id        TEXT REFERENCES document_chunks(chunk_id),
    entity_name     TEXT NOT NULL,
    entity_type     TEXT NOT NULL,  -- FILE | TABLE | FUNCTION | SERVICE | API_ENDPOINT
    mention_context TEXT,
    confidence      REAL DEFAULT 1.0
);
CREATE INDEX idx_dr_entity ON document_references(entity_name, entity_type);
CREATE INDEX idx_dr_doc ON document_references(document_id);

-- DDL extractions (from ADR-008)
CREATE TABLE IF NOT EXISTS db_tables (
    table_name      TEXT PRIMARY KEY,
    schema_name     TEXT,
    source_file     TEXT,           -- which DDL file defined this
    repo_id         TEXT,
    column_count    INTEGER,
    last_ddl_change TEXT
);

CREATE TABLE IF NOT EXISTS db_columns (
    table_name      TEXT REFERENCES db_tables(table_name),
    column_name     TEXT,
    data_type       TEXT,
    nullable        BOOLEAN,
    is_pk           BOOLEAN DEFAULT 0,
    is_fk           BOOLEAN DEFAULT 0,
    fk_references   TEXT,
    PRIMARY KEY(table_name, column_name)
);

-- API extractions (from OpenAPI specs)
CREATE TABLE IF NOT EXISTS api_endpoints (
    endpoint_id     TEXT PRIMARY KEY,
    path            TEXT,
    method          TEXT,           -- GET | POST | PUT | DELETE
    source_file     TEXT,           -- which spec file defined this
    handler_file_id TEXT,           -- linked code file (matched from function entry points)
    handler_function TEXT,
    parameters      TEXT,           -- JSON
    response_schema TEXT,           -- JSON
    repo_id         TEXT
);
```

### Vector Payloads (Layer 4)
```python
VectorPoint(
    id=chunk_id,
    text=chunk_content_text,
    metadata={
        "repo_id": repo_id,
        "document_id": doc_id,
        "doc_type": doc_type,           # markdown | ddl | pdf | docx | openapi
        "section_title": section_title,
        "layer": 4,
        "is_current": True,
    }
)
```

## Dependencies

- SPEC-001 (schema — documents, document_chunks, plus new tables)
- SPEC-002 (SQLite backend)
- SPEC-005 (ChromaDB store — for embedding chunks)
- P0: no extra dependencies (markdown/text/DDL parsed with stdlib)
- P1: `pymupdf` or `pdfplumber` (PDF), `python-docx` (Word), `pyyaml` (OpenAPI)
- P2: `openpyxl` (Excel), `requests` (Confluence API), `python-pptx` (PowerPoint)

## Tests

| Test | What's Verified |
|------|----------------|
| `test_reader_registry_selects_correct_reader` | .md → MarkdownReader, .sql → DDLReader, .pdf → PDFReader |
| `test_reader_registry_ambiguous_yaml` | .yaml with "openapi:" → OpenAPIReader; without → skipped |
| `test_markdown_reader_sections` | Splits by headings, preserves hierarchy |
| `test_markdown_reader_code_blocks` | Code blocks not split mid-block |
| `test_plaintext_reader_paragraphs` | Splits by double newlines |
| `test_ddl_reader_create_table` | Extracts table name, columns, types, PK/FK |
| `test_ddl_reader_multi_statement` | Multiple CREATE TABLEs → multiple sections |
| `test_chunker_respects_max_tokens` | No chunk exceeds max_chunk_tokens |
| `test_chunker_preserves_section_title` | Each chunk carries its section's heading |
| `test_entity_extractor_finds_tables` | Known table names found in doc text |
| `test_entity_extractor_finds_files` | Known file names found in doc text |
| `test_entity_extractor_case_insensitive` | "fees_ledger" matches "FEES_LEDGER" in DB |
| `test_embed_document` | Chunks stored in DB + vectors in ChromaDB with layer=4 |
| `test_cross_tier_query` | Search "FEES_LEDGER" returns both code files AND doc chunks |
| `test_ddl_populates_db_tables` | DDL file → db_tables and db_columns populated |
| `test_cli_onboard_docs` | `ecle onboard-docs` CLI works end-to-end |
| `test_idempotent_doc_import` | Same doc twice → skipped (content_hash unchanged) |
| `test_unsupported_file_skipped` | Unknown extension → warning, not error |
