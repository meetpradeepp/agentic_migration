# SPEC-013: Settings & Config — Mode-Driven Configuration

**Status**: Implemented + Tested
**Owner**: Backend Engineer
**Files**: src/ecle/config/settings.py, src/ecle/config/loader.py, src/ecle/config/factory.py

## Purpose

Single configuration system that drives everything — which backends are active, which features are enabled, how components are wired. A developer types `ecle serve` and gets Lite mode. An operator sets `features: full` in `ecle.yaml` and gets LLM chat, all doc readers, and async workers. K8s reads env vars and gets enterprise mode.

No component should hardcode backends. Every component reads from `Settings`.

## ADR References

- [ADR-017](../../constitution/decisions/ADR-017-deployment-modes-lite-full-enterprise.md) — Two axes: Features (Lite/Full) × Platform (Single/Docker/K8s)
- [ADR-002](../../constitution/decisions/ADR-002-hybrid-storage-not-vector-only.md) — Backend selection: SQLite vs PostgreSQL, ChromaDB vs Qdrant

## Inputs

| Source | Priority | Example |
|--------|----------|---------|
| Defaults | Lowest | Lite mode, SQLite, ChromaDB |
| `ecle.yaml` | Medium | `features: full`, `db.backend: postgresql` |
| Environment variables | High | `ECLE_FEATURES=full`, `ECLE_DB_BACKEND=postgresql` |
| CLI flags | Highest | `--mode full`, `--db ecle.db`, `--port 8741` |

Resolution order: CLI flags > env vars > ecle.yaml > defaults

## Outputs

A `Settings` object that every component reads. Never raw config dicts.

## Interface

```python
@dataclass
class DBSettings:
    backend: str = "sqlite"         # sqlite | postgresql
    path: str = "./ecle.db"         # sqlite file path
    host: str = "localhost"         # postgresql host
    port: int = 5432
    database: str = "ecle"
    user: str = "ecle"
    password_env: str = "ECLE_DB_PASSWORD"
    pool_size: int = 20
    read_replicas: list[str] = field(default_factory=list)

@dataclass
class VectorSettings:
    backend: str = "chromadb"       # chromadb | qdrant
    path: str = "./vectors"         # chromadb persist dir
    host: str = "localhost"         # qdrant host
    grpc_port: int = 6334

@dataclass
class EmbeddingSettings:
    backend: str = "onnx"           # onnx | openvino
    model_path: str = "./models/data"

@dataclass
class QueueSettings:
    backend: str = "sync"           # sync | redis
    host: str = "localhost"
    port: int = 6379

@dataclass
class LLMSettings:
    enabled: bool = False
    provider: str = "anthropic"     # anthropic | openai | local
    model: str = "claude-sonnet-4-20250514"
    api_key_env: str = "ANTHROPIC_API_KEY"

@dataclass
class ReaderSettings:
    markdown: bool = True
    plaintext: bool = True
    ddl: bool = True
    openapi: bool = True
    pdf: bool = False               # Full only
    docx: bool = False
    excel: bool = False
    confluence: bool = False
    pptx: bool = False

@dataclass
class ClusteringSettings:
    enabled: bool = True            # YES in both Lite and Full
    algorithm: str = "louvain"
    min_cluster_size: int = 3

@dataclass
class AuthSettings:
    enabled: bool = False
    backend: str = "none"           # none | api_key | oidc
    key_env: str = "ECLE_API_KEY"

@dataclass
class ServerSettings:
    host: str = "127.0.0.1"
    port: int = 8741

@dataclass
class MonitoringSettings:
    enabled: bool = False

@dataclass
class IngestSettings:
    workers: int = 0                # 0 = sync (Lite), N = async workers
    cpg_parallel: int = 1

@dataclass
class Settings:
    """Resolved configuration. All components read from this."""
    features: str = "lite"          # lite | full
    db: DBSettings = field(default_factory=DBSettings)
    vector: VectorSettings = field(default_factory=VectorSettings)
    embedding: EmbeddingSettings = field(default_factory=EmbeddingSettings)
    queue: QueueSettings = field(default_factory=QueueSettings)
    llm: LLMSettings = field(default_factory=LLMSettings)
    readers: ReaderSettings = field(default_factory=ReaderSettings)
    clustering: ClusteringSettings = field(default_factory=ClusteringSettings)
    auth: AuthSettings = field(default_factory=AuthSettings)
    server: ServerSettings = field(default_factory=ServerSettings)
    monitoring: MonitoringSettings = field(default_factory=MonitoringSettings)
    ingest: IngestSettings = field(default_factory=IngestSettings)

    @classmethod
    def lite(cls) -> Settings:
        """Factory for Lite mode defaults."""
        return cls(features="lite")

    @classmethod
    def full(cls) -> Settings:
        """Factory for Full mode defaults."""
        return cls(
            features="full",
            llm=LLMSettings(enabled=True),
            readers=ReaderSettings(pdf=True, docx=True, excel=True,
                                   confluence=True, pptx=True),
            queue=QueueSettings(backend="redis"),
            ingest=IngestSettings(workers=4, cpg_parallel=4),
            auth=AuthSettings(enabled=True, backend="api_key"),
            monitoring=MonitoringSettings(enabled=True),
        )

    @classmethod
    def from_file(cls, path: Path) -> Settings:
        """Load from ecle.yaml, apply env var overrides."""

    @classmethod
    def from_env(cls) -> Settings:
        """Load purely from environment variables."""

    @classmethod
    def from_args(cls, args: argparse.Namespace, base: Settings | None = None) -> Settings:
        """Apply CLI flag overrides on top of base settings."""
```

### Factory — Creates backends from Settings

```python
class BackendFactory:
    """Creates the right backend implementation based on Settings."""

    @staticmethod
    def create_db(settings: Settings) -> SQLiteBackend | PostgresBackend:
        if settings.db.backend == "sqlite":
            from ecle.backends.structured.sqlite import SQLiteBackend
            db = SQLiteBackend(settings.db.path)
            db.connect()
            return db
        elif settings.db.backend == "postgresql":
            from ecle.backends.structured.postgres import PostgresBackend
            return PostgresBackend(
                host=settings.db.host, port=settings.db.port,
                database=settings.db.database, user=settings.db.user,
                password=os.getenv(settings.db.password_env, ""),
                pool_size=settings.db.pool_size,
            )

    @staticmethod
    def create_vector(settings: Settings) -> ChromaDBStore | QdrantStore | None:
        if settings.vector.backend == "chromadb":
            from ecle.backends.vector.chromadb_store import ChromaDBStore
            return ChromaDBStore(settings.vector.path)
        elif settings.vector.backend == "qdrant":
            from ecle.backends.vector.qdrant_store import QdrantStore
            return QdrantStore(
                host=settings.vector.host,
                grpc_port=settings.vector.grpc_port,
            )
        return None

    @staticmethod
    def create_queue(settings: Settings):
        if settings.queue.backend == "sync":
            from ecle.queue.sync_queue import SyncQueue
            return SyncQueue()
        elif settings.queue.backend == "redis":
            from ecle.queue.redis_queue import RedisQueue
            return RedisQueue(host=settings.queue.host, port=settings.queue.port)
```

### Config File Loader

```python
class ConfigLoader:
    """Loads and merges configuration from ecle.yaml + env vars + CLI flags."""

    @staticmethod
    def load(
        config_path: Path | None = None,
        cli_args: argparse.Namespace | None = None,
    ) -> Settings:
        """
        Resolution order:
        1. Start with defaults (Lite mode)
        2. If ecle.yaml exists: overlay its values
        3. If ECLE_* env vars set: overlay those
        4. If CLI flags provided: overlay those (highest priority)
        """
        # Start with defaults
        settings = Settings.lite()

        # Layer 1: config file
        if config_path and config_path.exists():
            settings = ConfigLoader._apply_yaml(settings, config_path)
        elif Path("ecle.yaml").exists():
            settings = ConfigLoader._apply_yaml(settings, Path("ecle.yaml"))

        # Layer 2: env vars
        settings = ConfigLoader._apply_env(settings)

        # Layer 3: CLI flags
        if cli_args:
            settings = ConfigLoader._apply_cli(settings, cli_args)

        # Apply mode presets
        if settings.features == "full":
            settings = ConfigLoader._apply_full_defaults(settings)

        return settings
```

## Behavior

### Mode Presets

```
When features=lite (default):
  db.backend defaults to sqlite
  vector.backend defaults to chromadb
  queue.backend defaults to sync
  llm.enabled defaults to false
  readers: only markdown, plaintext, ddl, openapi
  clustering.enabled = true (Lite supports clustering!)
  auth.enabled = false
  monitoring.enabled = false
  ingest.workers = 0 (synchronous)

When features=full:
  Everything in lite PLUS:
  llm.enabled = true
  readers: ALL enabled
  queue.backend = redis (if not overridden)
  ingest.workers = 4
  auth.enabled = true
  monitoring.enabled = true
  (db and vector backends can still be sqlite/chromadb — full doesn't force postgresql)
```

### Environment Variable Mapping

```
ECLE_FEATURES          → features (lite | full)
ECLE_DB_BACKEND        → db.backend
ECLE_DB_PATH           → db.path
ECLE_DB_HOST           → db.host
ECLE_DB_PASSWORD       → db.password (direct value, not env var name)
ECLE_VECTOR_BACKEND    → vector.backend
ECLE_VECTOR_PATH       → vector.path
ECLE_QUEUE_BACKEND     → queue.backend
ECLE_LLM_ENABLED       → llm.enabled
ECLE_LLM_PROVIDER      → llm.provider
ECLE_SERVER_HOST       → server.host
ECLE_SERVER_PORT       → server.port
ECLE_REPO_ID           → (used by MCP and CLI, not stored in Settings)
```

### How Components Use Settings

```python
# In CLI (ecle serve):
settings = ConfigLoader.load(cli_args=args)
db = BackendFactory.create_db(settings)
vector = BackendFactory.create_vector(settings)
app = create_app(db=db, vector_store=vector, settings=settings)

# In MCP server:
settings = ConfigLoader.load()  # reads ecle.yaml + env vars
db = BackendFactory.create_db(settings)
vector = BackendFactory.create_vector(settings)

# In onboarding pipeline:
settings = ConfigLoader.load()
db = BackendFactory.create_db(settings)
vector = BackendFactory.create_vector(settings)
pipeline = OnboardingPipeline(db, vector, repo_id=repo_id)

# Checking feature availability:
if settings.readers.pdf:
    registry.register(PDFReader())
if settings.llm.enabled:
    router = LLMRouter(provider=settings.llm.provider)
```

### Default ecle.yaml (generated on first run)

```yaml
# ECLE Configuration
# See: constitution/decisions/ADR-017 for mode details

features: lite    # lite | full

db:
  backend: sqlite
  path: ./ecle.db

vector:
  backend: chromadb
  path: ./vectors

embedding:
  model_path: ./models/data

clustering:
  enabled: true

server:
  host: 127.0.0.1
  port: 8741
```

## Dependencies

- `pyyaml` (for ecle.yaml parsing — already in deps)
- No other new dependencies

## Tests

| Test | What's Verified |
|------|----------------|
| `test_settings_lite_defaults` | Lite mode has correct defaults (sqlite, chromadb, no LLM, clustering=true) |
| `test_settings_full_defaults` | Full mode enables LLM, all readers, redis queue, auth |
| `test_settings_from_yaml` | ecle.yaml values override defaults |
| `test_settings_env_override` | ECLE_* env vars override yaml |
| `test_settings_cli_override` | CLI flags override everything |
| `test_settings_resolution_order` | CLI > env > yaml > defaults |
| `test_factory_creates_sqlite` | BackendFactory.create_db returns SQLiteBackend for lite |
| `test_factory_creates_chromadb` | BackendFactory.create_vector returns ChromaDBStore for lite |
| `test_lite_clustering_enabled` | Lite mode has clustering.enabled = true |
| `test_full_does_not_force_postgresql` | features=full with db.backend=sqlite still uses sqlite |
| `test_reader_availability` | Lite: pdf=false, Full: pdf=true |
| `test_default_yaml_generated` | First run generates ecle.yaml if not exists |
