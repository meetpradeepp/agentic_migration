# SDLC Contract — How We Build ECLE

## The Build Process

Every feature follows this lifecycle:
```
Spec → Implement → Test → Review → Merge → Release
```

No step is skippable. No shortcuts.

**HARD RULE: Spec before code. Always.**

No implementation begins without a written spec in `specs/week-N/SPEC-NNN-name.md`. The spec defines the interface, behavior, tests, and dependencies. The agent implements against the spec. The reviewer validates against the spec. Code without a spec is unauthorized code.

## Code Change Lifecycle

```
1. PLAN
   Task Planner decomposes work into small, dependency-ordered tasks
   Each task maps to one PR, one logical change, completable in 1-3 days

2. BRANCH
   Create branch: phase-{N}/{layer}-{feature}
   Branch from main, keep short-lived (< 1 week)

3. IMPLEMENT
   Write code + tests together (not tests after)
   Type hints on all public interfaces
   Structured logging, typed exceptions, config-driven values
   Run ruff check + ruff format locally before commit

4. COMMIT
   Conventional Commits: feat(layer0): add FilesystemConnector [Phase 1]
   Atomic: one logical change per commit
   Pre-commit hooks enforce: ruff + pytest on staged files

5. PR
   Description: what changed, which layer/phase, architecture doc section link
   Max 500 lines changed (excluding tests and auto-generated)
   CI must pass: Stage 1 (lint + unit) + Stage 2 (integration)

6. REVIEW
   Code Reviewer applies 7-point checklist (no LGTM reviews)
   Security Auditor reviews if: new dependencies, new endpoints, auth changes
   Platform Architect reviews if: cross-layer changes, schema changes

7. MERGE
   Squash merge to main (clean history)
   Delete feature branch after merge

8. RELEASE
   Phase completion → tag v0.{phase}.0
   Changelog generated from conventional commits
   All docs verified against current phase
```

## Quality Gates

| Gate | When | What | Who |
|------|------|------|-----|
| Pre-commit | Every commit | ruff check + pytest (staged files) | Automated |
| CI Stage 1 | Every PR | Lint + unit tests + coverage check | Automated |
| CI Stage 2 | Every PR | Integration tests | Automated |
| Code Review | Every PR | 7-point checklist | Code Reviewer |
| Security Review | New deps/endpoints/auth | Security checklist | Security Auditor |
| Architecture Review | Cross-layer/schema changes | Spec conformance | Platform Architect |
| Eval Suite | Nightly | Full evals with live LLM | Automated |
| Release Gate | Phase completion | All tests + evals + docs | All agents |

## Non-Negotiable Rules

1. **No direct commits to main** — all changes via PR
2. **No merge without review** — no exceptions, even for "trivial" fixes
3. **No merge with failing CI** — fix the issue, don't skip the check
4. **No hardcoded values** — configuration or constants, never magic numbers in logic
5. **No secrets in code** — environment variables or vault, always
6. **No stale docs** — if code changes, docs update in the same PR or a linked follow-up
7. **No scope creep** — if a task grows beyond its original scope, split it, don't expand it
8. **No orphan data paths** — if a spec creates a table/registry, the ingestion pipeline MUST populate it. Schema without writes is a bug. (ADR-027 post-mortem)
9. **End-to-end smoke test after import** — after any import-related change, verify: `ecle import` → `ecle_repos` → `ecle_stats` → `ecle_find_callers` → `ecle_search`. Empty results = gap.
10. **Cross-cutting spec review** — when Spec A says "reads from X" and Spec B says "writes to X", both specs MUST reference each other. Reviewer verifies the write path exists before approving the read path.

## Post-Import Verification Checklist

After any changes to ingestion, import, or MCP tools, run this sequence and verify non-empty results:

```bash
# 1. Import facts
ecle import ./facts/ --repo-id test

# 2. Verify repos are discoverable
ecle_repos_tool()                    # → lists test repo

# 3. Verify stats are populated
ecle_stats(repo_id="test")           # → files > 0, functions > 0

# 4. Verify cross-repo tools work (if multi-repo)
ecle backfill-artifacts --db ecle.db  # → shared artifacts > 0
ecle_shared_artifacts_tool(...)       # → non-empty for known tables

# 5. Verify semantic search works
ecle_search("billing", repo_id="test") # → results, not "no vector store"
```

If ANY step returns empty or errors, there is an integration gap. Fix before merging.
