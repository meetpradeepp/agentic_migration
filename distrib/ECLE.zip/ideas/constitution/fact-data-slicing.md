# FACT Data Slicing — How CPG + Facts + FSS Maps to Backends

## The Data Flow

```
Source Code
    │
    ▼
CPG Stage (Joern/LSP)
    │ produces: CanonicalFactFileBase per file
    │           (functions, sql_statements, dependencies, execution_sequence, etc.)
    ▼
FACT Ingestion
    │
    ├──→ Structured DB   (searchable facts, indexed lookups, aggregations)
    ├──→ Vector Index     (embeddings for semantic search only)
    └──→ Graph Store      (edges between files, computed from fact relationships)
```

There is NO FSS stage, NO FPS stage as separate processes. CPG facts are **directly sliced** into the three backends in a single ingestion pass.

---

## The Source: What CPG Actually Produces Per File

From examining 19 real `.facts.json` files in `joern-exports/facts/`. Here is the **actual** structure as produced by Joern + AMF language packs:

```json
// batch_rating.ppc.facts.json — Pro*C file (real data)
{
  "filename": "batch_rating.ppc",
  "language": "proc",
  
  // ── Functions (the code units) ──
  "functions": [
    {
      "id": "107374182400",
      "name": "sql_error",
      "returnType": "void",
      "complexity": 1,
      "args": ["context"],
      "variables": ["buf_len", "msg_len", "global_err_msg", "ERR_MSG_LEN"],
      "return_statements": [],
      "start_line": 26,
      "end_line": 32
    },
    {
      "id": "107374182403",
      "name": "db_connect",
      "returnType": "int",
      "complexity": 2,
      "args": ["user", "pwd"],
      "variables": ["SUCCESS", "DB_ERROR", "sqlca", "h_password", "h_username"],
      "return_statements": [
        {"line": 46, "code": "return DB_ERROR;"},
        {"line": 48, "code": "return SUCCESS;"}
      ],
      "start_line": 38,
      "end_line": 49
    }
  ],

  // ── SQL Statements (table operations with full SQL text) ──
  "sql_statements": [
    {
      "id": "30064771082",
      "line": 42,
      "enclosing_method": "db_connect",
      "category": "OTHER",
      "sql_text": "CONNECT :h_username IDENTIFIED BY :h_password",
      "tables": [],
      "host_vars": ["&h_username", "&h_password"]
    },
    {
      "id": "30064771088",
      "line": 53,
      "enclosing_method": "open_cdr_cursor",
      "category": "READ",
      "sql_text": "DECLARE cdr_cursor CURSOR FOR SELECT CDR_ID, SUB_ID, CALL_DURATION, CALL_TYPE FROM UNRATED_CDRS WHERE RATED_STATUS = 'N'",
      "tables": ["UNRATED_CDRS"],
      "host_vars": []
    },
    {
      "id": "30064771155",
      "line": 116,
      "enclosing_method": "bulk_insert_rated_cdrs",
      "category": "WRITE",
      "sql_text": "FOR :count INSERT INTO RATED_CDRS (CDR_ID, RATED_AMOUNT, PROCESS_DATE) VALUES (:h_cdr_id, :h_cost:i_cost, SYSDATE)",
      "tables": ["RATED_CDRS"],
      "host_vars": ["&count", "&h_cdr_id", "&h_cost", "&i_cost"]
    },
    {
      "id": "30064771163",
      "line": 124,
      "enclosing_method": "bulk_insert_rated_cdrs",
      "category": "WRITE",
      "sql_text": "FOR :count UPDATE UNRATED_CDRS SET RATED_STATUS = 'Y' WHERE CDR_ID = :h_cdr_id",
      "tables": ["UNRATED_CDRS"],
      "host_vars": ["&count", "&h_cdr_id"]
    },
    {
      "id": "30064771166",
      "line": 126,
      "enclosing_method": "bulk_insert_rated_cdrs",
      "category": "TRANSACTION",
      "sql_text": "COMMIT",
      "tables": [],
      "host_vars": []
    }
  ],
  
  // ── Global definitions (host variables, constants) ──
  "global_defs": [
    {"name": "h_username", "type": "char[50]"},
    {"name": "h_password", "type": "char[50]"},
    {"name": "h_cdr_id", "type": "long[BATCH_SIZE]"},
    {"name": "h_cost", "type": "double[BATCH_SIZE]"},
    {"name": "BATCH_SIZE", "type": "ANY"}
  ],

  // ── Dependencies (calls to other functions/files) ──
  "dependencies": [
    {"name": "BATCH_SIZE", "line": 15}
  ],

  // ── Data flow edges (variable dependencies between functions) ──
  "data_flow_edges": [
    {"function": "db_connect", "variable": "user"},
    {"function": "db_connect", "variable": "pwd"},
    {"function": "bulk_insert_rated_cdrs", "variable": "batch_struct"}
  ],

  // ── Control flow edges (call graph) ──
  "control_flow_edges": [],
  
  // ── Framework calls (external/system calls) ──
  "framework_calls": [],
  
  // ── Execution sequence (AST with parent-child nodes) ──
  "execution_sequence": [
    {"id": "...", "line": 42, "node_type": "CALL", 
     "enclosing_method": "db_connect",
     "code": "EXEC SQL CONNECT :h_username IDENTIFIED BY :h_password;",
     "parent_node_id": "107374182403"},
    {"id": "...", "line": 53, "node_type": "CALL",
     "enclosing_method": "open_cdr_cursor",
     "code": "EXEC SQL DECLARE cdr_cursor CURSOR FOR SELECT...",
     "parent_node_id": "107374182404"}
  ],

  // ── Structural ──
  "struct_definitions": [],
  "typedefs": [],
  "includes": [],
  "macros": [],
  "global_uses": [],
  "comments": [],
  "literals": [{"value": "100", "type": "int", "line": 15}]
}
```

```json
// fn_transfer_table.srf.facts.json — PowerBuilder function (real data)
{
  "filename": "fn_transfer_table.srf",
  "language": "powerbuilder",
  
  "functions": [
    {
      "id": 107374182401,
      "name": "fn_transfer_table",
      "args": ["string as_table", "string as_fromxrisi", "string as_toxrisi"],
      "complexity": 4,
      "returnType": "void",
      "start_line": 10,
      "end_line": 69,
      "variables": [],
      "return_statements": [],
      "snippet": ""
    }
  ],
  
  "sql_statements": [
    {"sql_text": "commit;", "category": "TRANSACTION", "tables": [],
     "line": 37, "enclosing_method": "fn_transfer_table", "host_vars": []}
  ],
  
  // PowerBuilder-specific: dynamic SQL with resolution
  "dynamic_sql_operations": [],
  "dynamic_sql_tables": [
    {"table_name": "WHERE", "line": 36,
     "sql_fragment": "select * from where kodxrisi = ' ' delete from where kodxrisi = ' '",
     "type": "DynamicSQL-Resolved"}
  ],
  
  // Framework calls (PowerBuilder DataStore/DataWindow methods)
  "framework_calls": [
    {"call_name": "fn_createds_fromsql", "line": 22,
     "enclosing_method": "fn_transfer_table",
     "code_snippet": "fn_createds_fromsql(ls_sql)",
     "category": "SYSTEM_OR_FRAMEWORK_CALL"},
    {"call_name": "lds_fromxrisi.retrieve", "line": 23, "...": "..."},
    {"call_name": "lds_toxrisi.SetItem", "line": 49, "...": "..."},
    {"call_name": "lds_toxrisi.update", "line": 62, "...": "..."},
    {"call_name": "EXECUTE IMMEDIATE", "line": 36, "...": "..."}
  ],
  
  // Local variables with types
  "local_variables": [
    {"name": "ls_sql", "type": "string", "line": 12, "scope": "local"},
    {"name": "lds_fromxrisi", "type": "datastore", "line": 16, "scope": "local"},
    {"name": "ll_rows", "type": "long", "line": 17, "scope": "local"},
    {"name": "lds_toxrisi", "type": "datastore", "line": 28, "scope": "local"}
  ],
  
  // Data reads (variable sources) and writes (assignments)
  "data_reads": [
    {"id": 30064771072, "source": "\"select * from \" + as_table + ...", "line": 19, "origin": "assignment"},
    {"id": 30064771079, "source": "lds_fromxrisi.retrieve()", "line": 23, "origin": "assignment"}
  ],
  "data_writes": [
    {"id": 30064771072, "target": "ls_sql", "line": 19, "origin": "assignment"},
    {"id": 30064771077, "target": "lds_fromxrisi", "line": 22, "origin": "assignment"}
  ],
  
  "dependencies": [
    {"name": "fn_createds_fromsql", "line": 22, "args_code": ["ls_sql"], "external": false},
    {"name": "lds_fromxrisi.retrieve", "line": 23, "args_code": [], "external": false},
    {"name": "EXECUTE IMMEDIATE", "line": 36, "args_code": [], "external": false},
    {"name": "COMMIT", "line": 37, "args_code": [], "external": false}
  ],
  
  // Full execution AST
  "execution_sequence": [
    {"line": 19, "node_type": "CALL", "enclosing_method": "fn_transfer_table",
     "code": "ls_sql = \"select * from \" + as_table + ...",
     "id": 30064771072, "parent_node_id": 107374182401},
    {"line": 19, "node_type": "IDENTIFIER", "code": "ls_sql", "parent_node_id": 30064771072},
    {"line": 19, "node_type": "LITERAL", "code": "\"select * from \"", "parent_node_id": "..."},
    {"line": 44, "node_type": "CONTROL_STRUCTURE", "code": "for i = 1 to ll_rows...", "...": "..."},
    {"line": 48, "node_type": "CONTROL_STRUCTURE", "code": "for j = 1 to ll_cols...", "...": "..."}
  ],
  
  // PowerBuilder-specific: prototypes, struct_definitions, datawindow_tables
  "prototypes": [{"name": "fn_transfer_table", "line": 7, "return_type": "void", "args": []}],
  "struct_definitions": [{"name": "fn_transfer_table", "inherits_from": "function_object", "members": []}],
  "datawindow_tables": [],
  "datawindow_operations": [],
  "datawindow_columns": []
}
```

```json
// dw_misth_ypal_list.srd.facts.json — PowerBuilder DataWindow (real data)
{
  "filename": "dw_misth_ypal_list.srd",
  "language": "powerbuilder",
  
  // DataWindow has NO functions — it's a data definition
  "functions": [],
  
  // But it HAS SQL statements (the DataWindow's retrieval query)
  "sql_statements": [
    {
      "sql_text": "SELECT misth_ypal.kodypal, misth_ypal.kodxrisi, misth_ypal.surname, misth_ypal.name, misth_ypal.mitroo, misth_ypal.klimakio, misth_ypal.klados, misth_ypal.bathmos, misth_zpidikot.descidikot FROM misth_ypal, misth_zpidikot WHERE ( misth_ypal.kodxrisi = :arg_kodxrisi )",
      "source": "DataWindow",
      "category": "READ",
      "tables": ["misth_ypal", "misth_zpidikot"],
      "host_vars": ["arg_kodxrisi"],
      "enclosing_method": "unknown"
    }
  ],
  
  // DataWindow-specific: table references
  "datawindow_tables": [
    {"table_name": "misth_zpidikot", "type": "DataWindow"},
    {"table_name": "misth_ypal", "type": "DataWindow"}
  ],
  
  "data_reads": [
    {"id": 30064771072, "source": "arg_kodxrisi", "line": 18, "origin": "sql"},
    {"id": 30064771072, "source": "arg_kodxrisi", "line": 18, "origin": "datawindow"}
  ]
}
```

### Key Observations from Real Data

1. **`sql_statements` is the richest field** — full SQL text, extracted table names, host variables, and crucially `enclosing_method` which links SQL to the function that executes it. Categories: READ, WRITE, TRANSACTION, OTHER.

2. **`functions` carries AST-level IDs** — the `id` field (e.g., `107374182403`) links to `execution_sequence` entries via `parent_node_id`. Functions have `variables` (local vars used), `return_statements` with actual code.

3. **`execution_sequence` is a full AST** — parent-child tree with node types: CALL, IDENTIFIER, LITERAL, CONTROL_STRUCTURE, RETURN, UNKNOWN. Each node has `enclosing_method`, `line`, `code`, `parent_node_id`.

4. **`dependencies` are function-level calls** — `name` is the callee, `args_code` captures actual argument expressions, `external` flag exists but often not set (defaults false).

5. **`framework_calls` captures method invocations with snippets** — `call_name`, `code_snippet`, `enclosing_method`, `category` (SYSTEM_OR_FRAMEWORK_CALL).

6. **`data_reads` and `data_writes` are variable-level data flow** — source/target is a variable name, origin is "assignment" or "sql" or "datawindow".

7. **Language-specific fields exist** — PowerBuilder has `datawindow_tables`, `datawindow_operations`, `datawindow_columns`, `dynamic_sql_tables`, `prototypes`, `menu_items`, `dialog_flows`, `create_operations`, `validation_rules`. Pro*C has `global_defs` with host variable types.

8. **DataWindow files (.srd) have SQL but no functions** — they are data definitions, not code. Their SQL tables are the key fact.

---

## The Slicing: Exactly What Goes Where

### → Structured DB (PostgreSQL / SQLite)

Everything that gets **searched by exact value, filtered, aggregated, or joined**.

```
FILE-LEVEL (from facts + derived FSS):
┌──────────────────────────────────────────────────────────────────┐
│ file_facts table                                                  │
│                                                                    │
│  id              = SHA256(filename + commit_sha)                   │
│  file_id         = "fee_calculator.c"                ← filename   │
│  commit_sha      = "abc123"                          ← from VCS   │
│  repo_id         = "billing-service"                 ← from VCS   │
│  tenant_id       = "acme"                            ← from config│
│  branch          = "main"                            ← from VCS   │
│  language         = "C"                              ← facts.language│
│  execution_model  = "batch"                          ← derived     │
│  complexity_max   = 12                               ← max(functions.complexity)│
│  complexity_avg   = 10.0                             ← avg(functions.complexity)│
│  function_count   = 2                                ← len(functions)│
│  sql_count        = 2                                ← len(sql_statements)│
│  is_current       = true                                           │
│  previous_id      = SHA256(filename + prev_commit)                 │
│  created_at       = now()                                          │
└──────────────────────────────────────────────────────────────────┘

FILE-TABLE RELATIONSHIPS (from sql_statements):
┌──────────────────────────────────────────────────────────────────┐
│ file_tables table                                                 │
│                                                                    │
│ For each sql_statement:                                            │
│   file_fact_id = parent file's id                                  │
│   table_name   = sql_statement.tables[i]         ← "INVOICE_HDR" │
│   operation    = READ if SELECT, WRITE if INSERT/UPDATE/DELETE     │
│   evidence     = "E1:line:{sql_statement.line}"                    │
│   line         = sql_statement.line               ← 52            │
│   function     = sql_statement.enclosing_method  ← "compute_late_fee"│
│                                                                    │
│ This file produces 2 rows:                                         │
│   (file_id, "INVOICE_HDR", READ,  E1:line:52, "compute_late_fee")│
│   (file_id, "FEES_LEDGER",  WRITE, E1:line:89, "compute_late_fee")│
└──────────────────────────────────────────────────────────────────┘

FUNCTION-LEVEL (from facts.functions):
┌──────────────────────────────────────────────────────────────────┐
│ function_facts table                                              │
│                                                                    │
│ For each function in facts.functions:                              │
│   id            = SHA256(file_id + fn.name + fn.start_line + commit)│
│   file_fact_id  = parent file's id                                 │
│   function_name = fn.name                    ← "compute_late_fee" │
│   line_start    = fn.start_line              ← 45                 │
│   line_end      = fn.end_line                ← 102                │
│   complexity    = fn.complexity              ← 12                 │
│   return_type   = fn.returnType              ← "double"           │
│   param_count   = len(fn.args)               ← 2                  │
│   is_entry_point = (no callers in this file) ← true/false         │
│   is_current    = true                                             │
└──────────────────────────────────────────────────────────────────┘

FUNCTION CALLS (from dependencies + framework_calls, scoped to enclosing function):
┌──────────────────────────────────────────────────────────────────┐
│ function_calls table                                              │
│                                                                    │
│ For each dependency/framework_call:                                │
│   caller_id     = function_facts.id for the enclosing_method       │
│   callee_name   = dependency.name            ← "send_to_gateway"  │
│   call_type     = DIRECT (or VIRTUAL if polymorphic)               │
│   line          = dependency.line            ← 95                  │
│   is_external   = dependency.external        ← true                │
│                                                                    │
│ This file produces:                                                │
│   (compute_late_fee_id, "send_to_gateway", DIRECT, 95, true)      │
└──────────────────────────────────────────────────────────────────┘

FUNCTION TABLE OPS (sql_statements scoped by enclosing_method):
┌──────────────────────────────────────────────────────────────────┐
│ function_table_ops table                                          │
│                                                                    │
│ For each sql_statement, scoped to its enclosing_method:            │
│   function_id = function_facts.id for enclosing_method             │
│   table_name  = sql_statement.tables[i]                            │
│   operation   = READ/WRITE                                         │
│   sql_text    = sql_statement.sql_text (for reference)             │
│   line        = sql_statement.line                                 │
│                                                                    │
│ This gives us function→table granularity:                          │
│   (compute_late_fee_id, "INVOICE_HDR", READ,  "SELECT...", 52)    │
│   (compute_late_fee_id, "FEES_LEDGER",  WRITE, "INSERT...", 89)   │
│                                                                    │
│ NOTE: file_tables is the aggregate. function_table_ops is the      │
│ detail. Both are needed — file-level for broad queries,            │
│ function-level for precise impact analysis.                        │
└──────────────────────────────────────────────────────────────────┘

INCLUDES/IMPORTS (from dependencies where external=false + includes):
┌──────────────────────────────────────────────────────────────────┐
│ file_includes table                                               │
│                                                                    │
│   source_file_id = this file's id                                  │
│   target_name    = "payment_gateway.h"                             │
│   directive      = "include"                                       │
│   line           = 3                                               │
└──────────────────────────────────────────────────────────────────┘

STRUCTURAL DEFINITIONS (types, macros, globals from facts):
┌──────────────────────────────────────────────────────────────────┐
│ file_definitions table                                            │
│                                                                    │
│   file_fact_id  = this file's id                                   │
│   def_type      = TYPE | MACRO | GLOBAL | STRUCT                   │
│   name          = definition name                                  │
│   line          = definition line                                  │
│                                                                    │
│ From facts:                                                        │
│   struct_definitions → def_type=STRUCT                             │
│   global_defs        → def_type=GLOBAL                             │
│                                                                    │
│ file_usages table (what this file USES from other files):          │
│   file_fact_id  = this file's id                                   │
│   usage_type    = TYPE | MACRO | GLOBAL                            │
│   name          = used name                                        │
│   line          = usage line                                       │
└──────────────────────────────────────────────────────────────────┘
```

**What structured DB enables (instant queries):**
```sql
-- "Find all files that write to FEES_LEDGER" (< 1ms)
SELECT f.file_id, f.language FROM file_facts f
JOIN file_tables t ON f.id = t.file_fact_id
WHERE t.table_name = 'FEES_LEDGER' AND t.operation = 'WRITE' AND f.is_current = true;

-- "What functions call send_to_gateway?" (< 1ms)
SELECT fn.function_name, fn.file_id FROM function_facts fn
JOIN function_calls c ON fn.id = c.caller_id
WHERE c.callee_name = 'send_to_gateway' AND fn.is_current = true;

-- "Show me all entry points in the billing service" (< 1ms)
SELECT fn.function_name, fn.file_id, fn.complexity FROM function_facts fn
JOIN file_facts f ON fn.file_fact_id = f.id
WHERE f.repo_id = 'billing-service' AND fn.is_entry_point = true AND fn.is_current = true;

-- "How many tables does each file touch?" (aggregation, < 5ms)
SELECT f.file_id, COUNT(DISTINCT t.table_name) as table_count
FROM file_facts f JOIN file_tables t ON f.id = t.file_fact_id
WHERE f.repo_id = 'billing-service' AND f.is_current = true
GROUP BY f.file_id ORDER BY table_count DESC;

-- "Database lineage view" (what PVG's database.pv was, < 10ms)
SELECT t.table_name, t.operation, f.file_id, f.language, 
       fn.function_name, fn.complexity
FROM file_tables t
JOIN file_facts f ON t.file_fact_id = f.id
LEFT JOIN function_table_ops fto ON fto.table_name = t.table_name
LEFT JOIN function_facts fn ON fto.function_id = fn.id
WHERE f.repo_id = 'billing-service' AND f.is_current = true
ORDER BY t.table_name, t.operation;
```

---

### → Graph Store (Neo4j / PostgreSQL edges table)

Edges computed from facts using the **same 9 signal detectors** that FPS uses today — but written directly to the graph during ingestion, not as a separate stage.

```
EDGE COMPUTATION (runs during ingestion, per file):
┌──────────────────────────────────────────────────────────────────┐
│ For each ingested file, compute edges to/from OTHER files:        │
│                                                                    │
│ Signal 1: WRITE_READ                                               │
│   This file writes FEES_LEDGER (from file_tables WHERE op=WRITE)   │
│   Other files read FEES_LEDGER (from file_tables WHERE op=READ)    │
│   → Edge: this_file →[WRITE_READ, artifact=FEES_LEDGER]→ reader  │
│   Weight: 2.5                                                      │
│   Confidence: 0.8                                                  │
│   Evidence: E1                                                     │
│                                                                    │
│ Signal 2: FUNCTION_DELEGATION                                      │
│   This file calls "send_to_gateway" (from function_calls)          │
│   Other file defines "send_to_gateway" (from function_facts)       │
│   → Edge: this_file →[FUNCTION_CALL, artifact=send_to_gateway]→ other│
│   Weight: 3.0                                                      │
│   Confidence: 0.9                                                  │
│   Evidence: E1                                                     │
│                                                                    │
│ Signal 3: TYPE_DEPENDENCY                                          │
│   This file uses type "FeeRecord" (from file_usages WHERE type=TYPE)│
│   Other file defines "FeeRecord" (from file_definitions WHERE type=TYPE)│
│   → Edge: this_file →[SHARED_TYPE, artifact=FeeRecord]→ definer   │
│   Weight: 1.0                                                      │
│   Confidence: 1.0                                                  │
│   Evidence: E1                                                     │
│                                                                    │
│ Signal 4: INCLUDE_DEPENDENCY                                       │
│   This file includes "payment_gateway.h" (from file_includes)      │
│   → Edge: this_file →[IMPORT, artifact=payment_gateway.h]→ header │
│   Weight: 0.5                                                      │
│   Confidence: 1.0                                                  │
│   Evidence: E1                                                     │
│                                                                    │
│ Signals 5-9: MACRO_DEPENDENCY, GLOBAL_DEPENDENCY,                  │
│   FLAG_CONTINUITY, STRUCTURAL_SEQUENCE, FINANCIAL_DEPENDENCY       │
│   (same pattern: lookup definitions/usages across files)           │
└──────────────────────────────────────────────────────────────────┘

KEY INSIGHT: All 9 signal detectors are INDEX LOOKUPS against the
structured DB. No full scan needed.

  WRITE_READ:   SELECT file_fact_id FROM file_tables 
                WHERE table_name = 'FEES_LEDGER' AND operation = 'READ'
  
  FUNCTION_DELEGATION: SELECT file_fact_id FROM function_facts 
                       WHERE function_name = 'send_to_gateway'
  
  TYPE_DEPENDENCY: SELECT file_fact_id FROM file_definitions 
                   WHERE name = 'FeeRecord' AND def_type = 'TYPE'

Each signal detector becomes a SQL query. Edge computation is O(facts per file),
not O(corpus). The structured DB indexes make cross-file resolution instant.
```

```
EDGE STORAGE:
┌──────────────────────────────────────────────────────────────────┐
│ topology_edges table                                              │
│                                                                    │
│   edge_id       = SHA256(source + target + type + artifact + commit)│
│   source_file   = "fee_calculator.c"                               │
│   target_file   = "settlement_processor.c"                         │
│   source_fn     = "compute_late_fee" (nullable)                    │
│   target_fn     = "process_settlement" (nullable)                  │
│   edge_type     = WRITE_READ                                       │
│   weight        = 2.5                                              │
│   artifact      = "FEES_LEDGER"                                    │
│   signal_type   = "write_read"                                     │
│   confidence    = 0.8                                              │
│   evidence      = "E1"                                             │
│   repo_id       = "billing-service"                                │
│   commit_sha    = "abc123"                                         │
│   is_valid      = true                                             │
│                                                                    │
│ Indexes:                                                           │
│   (source_file, is_valid) — outbound traversal                     │
│   (target_file, is_valid) — inbound traversal                      │
│   (artifact)              — "what depends on FEES_LEDGER?"         │
│   (edge_type, is_valid)   — filter by relationship type            │
└──────────────────────────────────────────────────────────────────┘
```

**What graph enables (traversal queries):**
```sql
-- "Impact of changing fee_calculator.c" — 2-hop outward, weight ≥ 2.0
WITH RECURSIVE impact AS (
    -- Hop 0: start file
    SELECT target_file as file_id, 1 as hops, weight, edge_type, artifact
    FROM topology_edges
    WHERE source_file = 'fee_calculator.c' AND is_valid = true AND weight >= 2.0
    
    UNION ALL
    
    -- Hop 1+: follow edges outward
    SELECT e.target_file, i.hops + 1, e.weight, e.edge_type, e.artifact
    FROM topology_edges e
    JOIN impact i ON e.source_file = i.file_id
    WHERE e.is_valid = true AND e.weight >= 2.0 AND i.hops < 2
)
SELECT DISTINCT file_id, MIN(hops) as distance, 
       array_agg(DISTINCT edge_type) as impact_types
FROM impact
GROUP BY file_id;

-- "Trace data flow for FEES_LEDGER"
SELECT e.source_file, e.target_file, e.source_fn, e.target_fn, e.confidence
FROM topology_edges e
WHERE e.artifact = 'FEES_LEDGER' AND e.edge_type = 'WRITE_READ' AND e.is_valid = true;
```

---

### → Vector Index (Qdrant / ChromaDB)

**Only embeddings for semantic search.** The vector store holds a SLIM representation — just the embedding + routing metadata. Full facts are always retrieved from the structured DB.

```
WHAT GETS EMBEDDED (per file):
┌──────────────────────────────────────────────────────────────────┐
│ Embedding text is assembled from structured facts:                │
│                                                                    │
│ For Tier 1/2 files (full FSS text → rich embedding):              │
│   text = f"""                                                      │
│   File: {filename} ({language})                                    │
│   Execution model: {execution_model}                               │
│   Functions: {', '.join(fn.name for fn in functions)}              │
│   Entry points: {', '.join(entry_points)}                          │
│   Reads tables: {', '.join(tables where op=READ)}                  │
│   Writes tables: {', '.join(tables where op=WRITE)}                │
│   External calls: {', '.join(external_calls)}                      │
│   SQL operations: {count} ({categories})                           │
│   Error handling: {summary}                                        │
│   State transitions: {summary}                                     │
│   Includes: {', '.join(includes)}                                  │
│   """                                                              │
│                                                                    │
│ For Tier 3 files (CIM facts only → sparse embedding):             │
│   text = f"""                                                      │
│   functions: {', '.join(sorted(fn.name for fn in functions))}      │
│   calls: {', '.join(sorted(callee_names))}                         │
│   reads: {', '.join(sorted(read_tables))}                          │
│   writes: {', '.join(sorted(write_tables))}                        │
│   includes: {', '.join(sorted(includes))}                          │
│   """                                                              │
│                                                                    │
│ The embedding captures BEHAVIORAL IDENTITY — not code syntax.     │
│ Two files that read/write the same tables and call the same        │
│ services produce similar vectors even if they're in different      │
│ languages.                                                         │
└──────────────────────────────────────────────────────────────────┘

WHAT GETS STORED IN VECTOR DB:
┌──────────────────────────────────────────────────────────────────┐
│ Vector Point (SLIM — no facts payload):                           │
│                                                                    │
│   id:     same as file_facts.id (for join back)                    │
│   vector: float[768] (or 384 — pending ADR)                       │
│   payload:                                                         │
│     repo_id:       "billing-service"    (for scoping)              │
│     cluster_id:    "cluster_14"         (for scoping)              │
│     is_current:    true                 (for filtering)            │
│     model_version: "bge-base-v1.5"     (for version guard)        │
│     layer:         1                    (routing: file vs fn)      │
│                                                                    │
│   That's it. 5 fields. ~50 bytes of payload.                      │
│   NOT: tables, functions, complexity, language, etc.               │
│   Those live in structured DB, joined by id.                       │
└──────────────────────────────────────────────────────────────────┘

FUNCTION-LEVEL EMBEDDINGS (Layer 2):
┌──────────────────────────────────────────────────────────────────┐
│ Embedding text per function:                                      │
│                                                                    │
│   text = f"""                                                      │
│   {function_name}: {return_type}                                   │
│   Reads: {', '.join(tables where op=READ)}                         │
│   Writes: {', '.join(tables where op=WRITE)}                       │
│   Calls: {', '.join(callees)}                                      │
│   Complexity: {complexity}                                         │
│   Entry point: {is_entry_point}                                    │
│   """                                                              │
│                                                                    │
│ Vector Point:                                                      │
│   id:     same as function_facts.id                                │
│   vector: float[768]                                               │
│   payload:                                                         │
│     repo_id:       "billing-service"                               │
│     cluster_id:    "cluster_14"                                    │
│     is_current:    true                                            │
│     model_version: "bge-base-v1.5"                                 │
│     layer:         2                                               │
└──────────────────────────────────────────────────────────────────┘

CLUSTER CENTROIDS (Layer 3):
┌──────────────────────────────────────────────────────────────────┐
│ Centroid = mean of constituent Layer 1 file vectors                │
│                                                                    │
│ Vector Point:                                                      │
│   id:     cluster_id                                               │
│   vector: float[768] (centroid)                                    │
│   payload:                                                         │
│     entity_type:   "CLUSTER"                                       │
│     repo_id:       "billing-service"                               │
│     is_current:    true                                            │
│     model_version: "bge-base-v1.5"                                 │
│     layer:         3                                               │
└──────────────────────────────────────────────────────────────────┘
```

**What vector enables (semantic queries):**
```python
# "Find files related to fee calculation" — semantic search
results = vector_db.search(
    collection="acme__billing__fss",
    query_vector=embed("fee calculation processing"),
    filter={"is_current": True, "layer": 1},
    top_k=10
)
# Returns: [(id="abc", score=0.89), (id="def", score=0.84), ...]
# Then: SELECT * FROM file_facts WHERE id IN ('abc', 'def') — full facts from structured DB

# "Find semantic duplicates" — high threshold similarity
results = vector_db.search(
    query_vector=get_vector("fee_calculator.c"),
    filter={"is_current": True, "layer": 1, "repo_id": "payments"},
    top_k=5,
    score_threshold=0.92
)
```

---

## The Complete Ingestion Flow

```python
def ingest_file(file_id: str, commit_sha: str, repo_id: str, branch: str,
                facts: CanonicalFactFileBase, metrics: CpgFileMetrics):
    """
    Single ingestion function. Replaces FSS + FPS stages entirely.
    Called once per changed file after CPG extraction.
    """
    
    # ── Step 1: Structured DB — file-level facts ────────────────
    
    # Supersede previous version
    structured_db.execute("""
        UPDATE file_facts SET is_current = false, superseded_at = :now
        WHERE file_id = :file_id AND branch = :branch AND is_current = true
    """, file_id=file_id, branch=branch, now=now())
    
    # Derive file-level aggregates (what FSS does today)
    read_tables = extract_tables(facts.sql_statements, operation="SELECT")
    write_tables = extract_tables(facts.sql_statements, operation="INSERT|UPDATE|DELETE")
    entry_points = detect_entry_points(facts.functions, facts.dependencies)
    execution_model = classify_execution_model(facts)
    
    file_fact_id = sha256(file_id + commit_sha)
    previous_id = get_previous_version_id(file_id, branch)
    
    # Insert file fact
    structured_db.insert("file_facts", {
        "id": file_fact_id,
        "file_id": file_id,
        "commit_sha": commit_sha,
        "repo_id": repo_id,
        "branch": branch,
        "language": facts.language,
        "execution_model": execution_model,
        "complexity_max": metrics.max_complexity,
        "complexity_avg": metrics.avg_complexity,
        "function_count": len(facts.functions),
        "sql_count": len(facts.sql_statements),
        "is_current": True,
        "previous_id": previous_id,
    })
    
    # Insert file-table relationships
    for table, op, evidence, line, fn in extract_table_ops(facts.sql_statements):
        structured_db.insert("file_tables", {
            "file_fact_id": file_fact_id,
            "table_name": table,
            "operation": op,
            "evidence": evidence,
            "line": line,
            "function": fn,
        })
    
    # Insert includes
    for dep in facts.dependencies:
        if not dep.external:
            structured_db.insert("file_includes", {
                "source_file_id": file_fact_id,
                "target_name": dep.name,
                "line": dep.line,
            })
    
    # Insert definitions and usages (types, macros, globals)
    for struct in facts.struct_definitions:
        structured_db.insert("file_definitions", {...})
    for gdef in facts.global_defs:
        structured_db.insert("file_definitions", {...})
    
    # ── Step 2: Structured DB — function-level facts ────────────
    
    for fn in facts.functions:
        fn_id = sha256(file_id + fn.name + str(fn.start_line) + commit_sha)
        
        structured_db.insert("function_facts", {
            "id": fn_id,
            "file_fact_id": file_fact_id,
            "file_id": file_id,
            "function_name": fn.name,
            "line_start": fn.start_line,
            "line_end": fn.end_line,
            "complexity": fn.complexity,
            "return_type": fn.returnType,
            "param_count": len(fn.args),
            "is_entry_point": fn.name in entry_points,
            "is_current": True,
            "commit_sha": commit_sha,
            "repo_id": repo_id,
        })
        
        # Function calls (from dependencies scoped to this function)
        for call in get_calls_in_function(fn.name, facts):
            structured_db.insert("function_calls", {
                "caller_id": fn_id,
                "callee_name": call.name,
                "call_type": "DIRECT",
                "line": call.line,
                "is_external": call.external,
            })
        
        # Function table operations (SQL scoped to this function)
        for sql in get_sql_in_function(fn.name, facts.sql_statements):
            for table in sql.tables:
                structured_db.insert("function_table_ops", {
                    "function_id": fn_id,
                    "table_name": table,
                    "operation": classify_sql_op(sql.category),
                    "sql_text": sql.sql_text,
                    "line": sql.line,
                })
    
    # ── Step 3: Graph — edge computation (replaces FPS) ─────────
    
    # Invalidate old edges from this file
    graph_db.execute("""
        UPDATE topology_edges SET is_valid = false, invalidated_at = :now
        WHERE source_file = :file_id AND is_valid = true
    """, file_id=file_id, now=now())
    
    # Compute new edges using same signals as FPS detectors
    new_edges = []
    
    # Signal 1: WRITE_READ — this file writes table T, find readers of T
    for table, op, *_ in extract_table_ops(facts.sql_statements):
        if op == "WRITE":
            readers = structured_db.query("""
                SELECT DISTINCT f.file_id FROM file_tables t
                JOIN file_facts f ON t.file_fact_id = f.id
                WHERE t.table_name = :table AND t.operation = 'READ'
                AND f.is_current = true AND f.file_id != :self
            """, table=table, self=file_id)
            for reader in readers:
                new_edges.append(Edge(
                    source=file_id, target=reader.file_id,
                    edge_type="WRITE_READ", weight=2.5,
                    artifact=table, signal_type="write_read",
                    confidence=0.8, evidence="E1",
                ))
        elif op == "READ":
            # Also check: who WRITES to tables I read?
            writers = structured_db.query("""
                SELECT DISTINCT f.file_id FROM file_tables t
                JOIN file_facts f ON t.file_fact_id = f.id
                WHERE t.table_name = :table AND t.operation = 'WRITE'
                AND f.is_current = true AND f.file_id != :self
            """, table=table, self=file_id)
            for writer in writers:
                new_edges.append(Edge(
                    source=writer.file_id, target=file_id,
                    edge_type="WRITE_READ", weight=2.5,
                    artifact=table, signal_type="write_read",
                    confidence=0.8, evidence="E1",
                ))
    
    # Signal 2: FUNCTION_DELEGATION — this file calls fn, find definer
    for call in all_calls_in_file(facts):
        definers = structured_db.query("""
            SELECT DISTINCT f.file_id FROM function_facts fn
            JOIN file_facts f ON fn.file_fact_id = f.id
            WHERE fn.function_name = :name AND f.is_current = true
            AND f.file_id != :self
        """, name=call.name, self=file_id)
        for definer in definers:
            new_edges.append(Edge(
                source=file_id, target=definer.file_id,
                edge_type="FUNCTION_CALL", weight=3.0,
                artifact=call.name, signal_type="function_delegation",
                confidence=0.9, evidence="E1",
            ))
    
    # Signals 3-9: TYPE_DEPENDENCY, INCLUDE_DEPENDENCY, etc.
    # Same pattern: lookup from file_definitions/file_usages/file_includes
    # ...
    
    # Batch insert all edges
    graph_db.insert_edges(new_edges)
    
    # ── Step 4: Vector — embed and upsert ───────────────────────
    
    # Assemble embedding text from structured facts
    embedding_text = assemble_embedding_text(
        filename=file_id, language=facts.language,
        execution_model=execution_model,
        functions=[fn.name for fn in facts.functions],
        entry_points=entry_points,
        read_tables=read_tables,
        write_tables=write_tables,
        external_calls=[d.name for d in facts.dependencies if d.external],
        includes=[d.name for d in facts.dependencies if not d.external],
    )
    
    embedding = embedding_model.encode(embedding_text)
    
    # Supersede old vector
    vector_db.set_payload(collection, old_point_id, {"is_current": False})
    
    # Insert new vector (SLIM payload)
    vector_db.upsert(collection, [{
        "id": file_fact_id,
        "vector": embedding,
        "payload": {
            "repo_id": repo_id,
            "cluster_id": get_cluster(file_id),
            "is_current": True,
            "model_version": MODEL_VERSION,
            "layer": 1,
        }
    }])
    
    # Compute version distance
    if previous_id:
        old_vector = vector_db.get_vector(collection, previous_id)
        if old_vector:
            distance = 1.0 - cosine_similarity(embedding, old_vector)
            structured_db.update("file_facts", file_fact_id, 
                                {"version_distance": distance})
    
    # Layer 2 embeddings for functions
    for fn in facts.functions:
        fn_embedding_text = assemble_fn_embedding_text(fn, facts)
        fn_embedding = embedding_model.encode(fn_embedding_text)
        fn_id = sha256(file_id + fn.name + str(fn.start_line) + commit_sha)
        vector_db.upsert(collection, [{
            "id": fn_id,
            "vector": fn_embedding,
            "payload": {
                "repo_id": repo_id,
                "cluster_id": get_cluster(file_id),
                "is_current": True,
                "model_version": MODEL_VERSION,
                "layer": 2,
            }
        }])
    
    # ── Step 5: Update cluster centroid (Layer 3) ───────────────
    
    centroid_manager.update_incrementally(
        cluster_id=get_cluster(file_id),
        old_embedding=old_vector,
        new_embedding=embedding,
    )
```

---

## Summary: Where Every CPG Facts Field Ends Up

Based on the **actual** .facts.json files in `joern-exports/facts/`:

| Facts Field | Structured DB | Graph | Vector | Notes |
|------------|:------------:|:-----:|:------:|-------|
| `filename` | `file_facts.file_id` | edge source/target | — | Primary key component |
| `language` | `file_facts.language` | — | embedding text | "proc", "cpp", "powerbuilder" |
| **functions[]** | | | | |
| `.name` | `function_facts.function_name` | — | embedding text | e.g., "db_connect" |
| `.id` | `function_facts.cpg_node_id` | — | — | Joern AST node ID |
| `.complexity` | `function_facts.complexity` | — | — | Cyclomatic complexity |
| `.returnType` | `function_facts.return_type` | — | — | "int", "void", etc. |
| `.args[]` | `function_facts.param_count` + `function_params` table | — | — | ["user", "pwd"] |
| `.start_line` / `.end_line` | `function_facts.line_start/end` | — | — | Source location |
| `.variables[]` | — | — | — | Too granular; re-extract on demand |
| `.return_statements[]` | `function_facts.has_return` (bool) | — | — | Store code only if needed |
| `.snippet` | — | — | — | Available from source; don't duplicate |
| **sql_statements[]** | | | | **The richest field** |
| `.tables[]` | `file_tables.table_name` | WRITE_READ edges | embedding text | e.g., ["UNRATED_CDRS"] |
| `.category` | `file_tables.operation` | edge weight selection | — | READ/WRITE/TRANSACTION/OTHER |
| `.sql_text` | `sql_statements.sql_text` | — | — | Full SQL for reference |
| `.enclosing_method` | `sql_statements.function_name` → `function_table_ops` | edge source_fn | — | Links SQL to function |
| `.host_vars[]` | `sql_host_vars` table | — | — | ["&h_username", "&h_password"] |
| `.line` | `sql_statements.line` | — | — | Source location |
| `.source` | `sql_statements.source` | — | — | "PowerScript" / "DataWindow" |
| **dependencies[]** | | | | |
| `.name` | `function_calls.callee_name` | FUNCTION_CALL edges | embedding text | e.g., "fn_createds_fromsql" |
| `.line` | `function_calls.line` | — | — | |
| `.args_code[]` | `function_calls.args_text` | — | — | ["ls_sql"] — actual arg expressions |
| `.external` | `function_calls.is_external` | edge type | — | Often not set in PB |
| **framework_calls[]** | | | | |
| `.call_name` | `function_calls.callee_name` | FUNCTION_CALL edges | embedding text | e.g., "lds_toxrisi.update" |
| `.code_snippet` | `function_calls.code_snippet` | — | — | Full call expression |
| `.enclosing_method` | `function_calls.caller_fn` | edge source_fn | — | |
| `.category` | `function_calls.call_category` | — | — | "SYSTEM_OR_FRAMEWORK_CALL" |
| **global_defs[]** | | | | |
| `.name` | `file_definitions.name` | GLOBAL_DEP edges | — | "h_username", "BATCH_SIZE" |
| `.type` | `file_definitions.type_info` | — | — | "char[50]", "long[BATCH_SIZE]" |
| **data_flow_edges[]** | | | | |
| `.function` + `.variable` | `function_data_flows` table | — | — | Variable dependency within function |
| **data_reads[] / data_writes[]** | | | | PowerBuilder-specific |
| `.source` / `.target` | `variable_flows` table | — | — | Variable-level assignment tracking |
| `.origin` | `variable_flows.origin` | — | — | "assignment" / "sql" / "datawindow" |
| **execution_sequence[]** | | | | |
| full AST | — | — | — | NOT stored in DB. Re-derive from CPG on demand. |
| `.node_type` counts | `file_facts.call_count`, `file_facts.control_count` | — | — | Aggregated counts only |
| **struct_definitions[]** | `file_definitions` (STRUCT) | SHARED_TYPE edges | — | |
| **datawindow_tables[]** | `file_tables` (source="DataWindow") | WRITE_READ edges | embedding text | PB-specific |
| **dynamic_sql_tables[]** | `file_tables` (source="DynamicSQL") | — | — | Resolved dynamic SQL |
| **prototypes[]** | `function_facts` (is_prototype=true) | — | — | PB function prototypes |
| **local_variables[]** | — | — | — | Too granular; re-extract on demand |
| **literals[]** | — | — | — | Too granular; re-extract on demand |
| **comments[]** | — | — | — | Not stored (unless `contains_sql=true`) |
| comments[].contains_sql | `commented_sql` table | — | — | Commented-out SQL preserved |

### What Gets Embedded (Vector Index)

The embedding text is assembled from structured facts **after** they're written to the DB:

```python
def assemble_embedding_text(file_facts_row, file_tables_rows, function_rows):
    """Build the text that gets embedded. Deterministic, reproducible."""
    
    tables_read = sorted(set(t.table_name for t in file_tables_rows if t.operation == "READ"))
    tables_written = sorted(set(t.table_name for t in file_tables_rows if t.operation == "WRITE"))
    fn_names = sorted(f.function_name for f in function_rows)
    external_calls = sorted(set(c.callee_name for c in calls if c.is_external))
    framework_calls = sorted(set(c.callee_name for c in calls if c.call_category))
    
    return f"""
    File: {file_facts_row.file_id} ({file_facts_row.language})
    Functions: {', '.join(fn_names)}
    Reads tables: {', '.join(tables_read)}
    Writes tables: {', '.join(tables_written)}
    External calls: {', '.join(external_calls)}
    Framework calls: {', '.join(framework_calls)}
    SQL operations: {file_facts_row.sql_count} ({categories})
    Complexity max: {file_facts_row.complexity_max}
    Execution model: {file_facts_row.execution_model}
    """.strip()
```

### What Does NOT Get Stored Anywhere

| Field | Why not stored |
|-------|---------------|
| `execution_sequence[]` (full AST) | Massive (100+ nodes per file). Re-extract from CPG on demand. Only aggregate counts stored. |
| `local_variables[]` | Per-function internal state. Too granular for cross-file analysis. Re-extract on demand. |
| `literals[]` | Constant values. Not useful for cross-file relationships. |
| `comments[]` (where `contains_sql=false`) | Non-SQL comments have no structural value. |
| `functions[].snippet` | Source code is available from VCS. Don't duplicate in DB. |
| `functions[].variables[]` | Same as local_variables — too granular. |

**Design principle:** If it's re-derivable from CPG in < 1 second, don't store it. Store only facts that enable cross-file queries, edge computation, and semantic search.
