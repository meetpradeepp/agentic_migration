# ECLE 2.0 Constitution

The constitution is the **single source of truth** for every design, implementation,
and operational decision in ECLE 2.0. Every engineer reads it before writing their
first line of code. A violation found in review **blocks merge**.

---

## Structure

The constitution is split into three types of focused documents.
Each file covers exactly one concern — never read the whole folder at once;
load only the file relevant to the task at hand.

### contracts/

Living rules enforced by CI, code review, and eval suites.

| File | Governs |
|---|---|
| `01-coding-standards.md` | Python style, SOLID/DRY/KISS/SRP, type hints, anti-pattern blacklist |
| `02-sdlc-contract.md` | Spec-first, branch/PR/review/CI lifecycle, non-negotiable rules |
| `03-testing-contract.md` | Test pyramid, coverage requirements, eval suites as hard CI gates |
| `04-fact-contract.md` | FACT (Fast/Accurate/Complete/Trustworthy) enforcement per layer |
| `05-confidence-contract.md` | 5-dimension confidence profile, fidelity ceiling, propagation, decay |
| `06-grounding-contract.md` | Every claim must cite evidence; grounding stack; rejection rules |
| `07-staleness-contract.md` | No silent stale answers; thresholds; hard gate; response envelope |
| `08-language-pack-contract.md` | Pack folder structure, manifest.yaml spec, extractor interface |
| `09-event-pipeline-contract.md` | Event types, SRP rules per worker, idempotency, error contract |
| `10-anti-patterns.md` | Banned patterns with examples — reviewer rejects on sight |

### schemas/

Machine-readable schemas defining data contracts between components.
A schema change requires an ADR before implementation.

| File | Defines |
|---|---|
| `facts-base-schema.json` | `CanonicalFactFileBase` — every `facts.json` must conform |
| `metrics-schema.json` | `CpgFileMetrics` — `metrics.json` produced by language packs |
| `events-table.sql` | PostgreSQL events table DDL — the system's immutable append log |
| `language-pack-manifest-schema.yaml` | `manifest.yaml` spec for every language pack |

### adrs/

Architecture Decision Records — immutable log of *why* decisions were made.
ADRs are written **before** implementation begins. Never deleted — superseded ADRs
are marked with status `Superseded by ADR-NNNN`.

| ADR | Decision |
|---|---|
| `ADR-0001-event-driven-pipeline.md` | Event-driven pipeline over direct worker calls |
| `ADR-0002-language-pack-registry.md` | Dynamic language pack registry over static extractor map |
| `ADR-0003-three-backend-architecture.md` | Structured DB + Vector Index + Topology Graph |
| `ADR-0004-slim-vector-design.md` | Slim vector payloads; facts live in structured DB |

---

## Constitution Rules

1. Every engineer reads the full constitution before their first commit.
2. A contract violation in review **blocks merge** — no exceptions.
3. ADRs are written **before** the decision is implemented, not after.
4. Schema changes require an ADR. No exceptions.
5. Anti-patterns in `10-anti-patterns.md` are hard-banned — reviewer rejects on sight.
6. Contracts are updated when the system evolves — stale contracts are bugs.
7. When a contract says "MUST" it is non-negotiable. "SHOULD" allows justified exception.
