# Staleness Contract — No Silent Stale Answers

**The system NEVER silently serves a stale answer as if it were fresh.**

## The Unconditional Guarantee

When an agent queries any layer, the answer reflects the latest state OR is transparently honest about its staleness.

## Staleness Response Rules

| Staleness Score | Action |
|----------------|--------|
| < 0.1 | Serve cached, no synthesis |
| 0.1 - 0.3 | Serve cached with staleness caveat, queue synthesis |
| > 0.3 | Serve cached with WARNING caveat, trigger immediate synthesis |
| NEVER | Block the response waiting for synthesis to finish |

## What Every Response Must Include

```json
{
  "confidence_profile": {
    "syntactic_freshness": "float",
    "behavioral_accuracy": "float",
    "contextual_accuracy": "float",
    "edge_coherence": "float",
    "cluster_alignment": "float"
  },
  "staleness_caveat": "string | null",
  "system_status": {
    "degradation_level": "FULL_SERVICE | DEGRADED_FRESHNESS | DEGRADED_SEARCH | DEGRADED_GRAPH | STORAGE_FAILURE",
    "knowledge_current_as_of": "ISO8601"
  }
}
```

## Hard Gate

**A system that returns `confidence = 1.0` on stale knowledge is WORSE than one that returns nothing.**

The Staleness Honesty eval is a hard gate — the system fails this eval = the system is unusable.

## Proportional Staleness (KAG level)

```
staleness_increment = delta_magnitude / total_clusters_in_capability
```

KAG re-synthesis triggers only when:
1. Accumulated staleness crosses threshold (e.g., 30%)
2. Direct agent query hits this capability with non-zero staleness
3. Engineer explicitly invalidates a claim
