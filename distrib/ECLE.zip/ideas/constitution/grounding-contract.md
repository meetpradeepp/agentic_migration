# Grounding Contract — Universal Rule

**EVERY LLM-generated claim in the system MUST cite the structural evidence it is derived from.**

## Enforcement by Layer

| Layer | What is grounded | Grounded against | Verifier cost |
|-------|-----------------|------------------|--------------|
| FSS | File-level claims | CPG/CIM nodes | Zero LLM — string matching |
| FPS | Edge semantic labels | FSS claims from both endpoints | 1 cheap LLM call per label |
| KAG | Capability narratives | FSS + FPS artifact keys | LLM call for sentence-citation mapping |
| Capability Labels | Discovered capability names | FSS summaries of constituent files | 1 LLM call at discovery time |
| MCP Answers | Tool responses | KAG + FPS + FSS with confidence profile | Runtime composition |

## Rejection Rules

1. A claim without a citation is **rejected** by the automated verifier
2. A claim whose citation **does not exist** in the source artifact is **rejected**
3. A KAG sentence with no citation is replaced with: `"⚠ Gap — insufficient evidence"`
4. Rejected claims are logged as `HALLUCINATION_BLOCKED` events

## The Stack

```
Layer 0 (CPG/CIM):  ground truth — deterministic, no LLM, no hallucination possible
Layer 1 (FSS):      LLM-generated, grounded in CPG/CIM facts, verifier rejects ungrounded
Layer 2 (FPS):      LLM-generated labels, grounded in FSS claims, verifier checks consistency
Layer 3 (KAG):      LLM-generated narratives, grounded in FSS+FPS, verifier rejects uncited
Layer 4 (answers):  MCP tool responses, grounded in KAG+FPS+FSS, confidence always attached

Every layer's LLM output is grounded in the layer below it.
The bottom layer is deterministic.
Hallucination can enter — but it cannot survive verification.
```
