# ECLE 2.0 — Input Processing Model

**Status:** Reference document (not a contract — documents ADR-0015, ADR-0016, ADR-0017,
ADR-0019, ADR-0022, ADR-0031 behaviour in one place)  
**Audience:** Developers, architects, onboarding operators  
**Last updated:** 2026-05-08

---

## Overview

Everything ECLE 2.0 ingests flows through a single classification decision made at
**onboard time**: `content_type`. This single field determines the parser, the storage
target, whether embeddings are produced, and what authority level the resulting knowledge
carries at query time.

```
┌─────────────────────────────────────────────────────────────────────┐
│                    ECLE 2.0 INPUT TYPES                             │
│                                                                     │
│   code        → Tier 1-code    → Structured DB + Vector L1/L2/L3   │
│   config      → Tier 1-domain  → Structured DB only                │
│   data        → Tier 1-domain  → Structured DB only                │
│   data-sql    → Tier 1-domain  → Structured DB only                │
│   docs        → Tier 3         → Structured DB + Vector Layer Docs  │
│                                                                     │
│   RULE: Tier 1-domain MUST NOT be embedded (Contract 06 §8)        │
│   RULE: docs MUST NOT write to file_facts / function_facts          │
│   RULE: code is the ONLY type that goes to both DB and vectors      │
└─────────────────────────────────────────────────────────────────────┘
```

The three-axis onboard model (ADR-0015) defines the full configuration space:

```
content_type  ×  source (git | local)  ×  schedule (once | recurring | re-run)
     5        ×         2              ×              3
= 30 valid onboard configurations
```

---

## 1. Code (`content_type: code`)

**Examples:** `.c`, `.ppc`, `.cbl`, `.py`, `.java`, `.go`, `.cs`, `.js`  
**Tier:** Tier 1-code — highest authority. The executable truth.  
**repo_role:** `module` (primary) or `platform` (shared library repos)

### Pipeline

```
┌──────────────────────────────────────────────────────────────────────┐
│ AXIS 1: content_type = code                                          │
│ AXIS 2: source = git (live repos) or local (snapshots)               │
│ AXIS 3: schedule = recurring (git hook) or once (initial import)     │
└──────────────────────────────────────────────────────────────────────┘
         │
         ▼ file.discovered event
┌─────────────────────────────────┐
│  parse_repo worker              │
│                                 │
│  1. Language detection (3-pass) │  ADR-0012
│     extension → content →       │
│     grammar                     │
│                                 │
│  2. tree-sitter + extractor.sc  │  ADR-0016
│     → facts.json:               │
│       functions[]               │
│       sql_statements[]          │  ← includes columns[] (ADR-0031)
│       dependencies[]            │
│       literals[]                │
│       execution_sequence[]      │
│       includes[]                │
│       struct_definitions[]      │
│       entry_points[]            │
│                                 │
│  3. content_hash = SHA256(bytes) │  Contract 13
│     behavioral_fingerprint       │
│     = SHA256(sorted facts)       │
└────────────┬────────────────────┘
             │ file.ir_produced event
             ▼
┌─────────────────────────────────┐
│  persist_facts worker           │
│                                 │
│  Layer 1 (file-level):          │
│  ├── file_facts                 │
│  ├── file_tables                │
│  ├── file_entry_points          │  ← entry_point_type: tuxedo_service,
│  ├── file_external_calls        │    http_handler, batch_main, etc.
│  └── file_literals              │  ← string constants (ADR-0031)
│                                 │
│  Layer 2 (function-level):      │
│  ├── function_facts             │
│  ├── function_calls             │
│  └── function_table_ops         │  ← fn → table → columns + sql_text (ADR-0031)
│                                 │
│  indexing_state updated         │  parse_status = done
└────────────┬────────────────────┘
             │ facts.persisted event
             ▼
┌─────────────────────────────────┐
│  build_graph worker             │
│                                 │
│  9 signal detectors:            │  ADR-0007
│  FUNCTION_CALL                  │
│  WRITE_READ                     │
│  IMPORT                         │
│  SHARED_TYPE                    │
│  STATE_FLOW                     │
│  ERROR_PROPAGATION              │
│  CONFIG_DEPENDENCY              │
│  DATA_LINEAGE                   │
│  SERVICE_CALL                   │
│                                 │
│  → topology_edges               │
└────────────┬────────────────────┘
             │ graph.updated event
             ▼
┌─────────────────────────────────┐
│  batch_embed worker             │
│                                 │
│  NOT raw source — behavioral    │
│  signatures (structured English)│
│                                 │
│  Layer 1: assemble_embedding_   │
│    text(file) → file centroid   │
│    vector (768-dim)             │
│                                 │
│  Layer 2: assemble_fn_embedding_│
│    text(fn) → function behav.   │
│    signature vector (768-dim)   │
│                                 │
│  Model: Nomic Embed Text v1.5   │  ADR-0008 (ONNX, local, air-gapped)
│  indexing_state: embed_status=  │
│    done                         │
└────────────┬────────────────────┘
             │ embeddings.done event
             ▼
┌─────────────────────────────────┐
│  compute_topology worker        │
│  → Louvain clustering           │  ADR-0011
│  → cluster_assignments          │
│                                 │
│  batch_embed (Layer 3)          │
│  → cluster centroid vectors     │
└─────────────────────────────────┘
```

### What it enables at query time

| Query | Tool | How |
|-------|------|-----|
| Find all callers of a function | `ecle_find_callers` | `function_calls WHERE callee_name = 'X'` |
| All files writing to table T | `ecle_find_tables` | `file_tables WHERE table_name = 'T'` |
| Function updating column C in table T | `ecle_find_by_column` | `function_table_ops WHERE table_name = 'T' AND 'C' = ANY(columns)` |
| Code containing string constant V | `ecle_find_literal` | `file_literals WHERE value = 'V'` |
| Semantic "fee calculation" search | `ecle_search` | ANN on Layer 1/2 + BM25 + Muvera re-rank |
| Change impact analysis | `ecle_impact` | `topology_edges` graph traversal |

### Grounding chain

```
Query result item
  └── file_facts.id
        └── artifact_path (facts.json)
              └── content_hash
                    └── commit_sha
                          └── source file at specific commit
```

Grounding verifier (Contract 06 §4) enforces this chain on every response.

---

## 2. Configuration Files (`content_type: config`)

**Examples:** UBBCONFIG, `.yaml`, `.yml`, `.cfg`, `.env`, `.properties`  
**Tier:** Tier 1-domain — exact lookup. As authoritative as code within its domain.  
**repo_role:** `platform` (service registry, deployment config)

### Pipeline

```
┌──────────────────────────────────────────────────────────────────────┐
│ AXIS 1: content_type = config                                        │
│ AXIS 2: source = git or local (static snapshots are common)          │
│ AXIS 3: schedule = recurring or once                                 │
└──────────────────────────────────────────────────────────────────────┘
         │
         ▼ file.discovered event
┌─────────────────────────────────┐
│  Config parser                  │
│                                 │
│  Key-value extraction:          │
│  ├── INI / properties format    │
│  ├── YAML/TOML structured       │
│  └── UBBCONFIG server groups:   │
│      SERVICE_NAME → source_file │
│      SERVICE_NAME → entry_point │
└────────────┬────────────────────┘
             │
             ▼
┌─────────────────────────────────┐
│  persist_facts worker           │
│                                 │
│  shared_artifacts:              │  artifact_type = SERVICE (ADR-0031)
│  ├── artifact_name = svc name   │
│  ├── artifact_type = SERVICE    │
│  └── defining_repo_id = this    │
│                                 │
│  file_entry_points:             │  entry_point_type = tuxedo_service
│  ├── entry_point_name = svc     │
│  └── entry_point_type =         │
│      tuxedo_service             │
│                                 │
│  field_extractions:             │
│  └── key-value pairs as fields  │
│                                 │
│  ✗ NO vector embeddings         │  Contract 06 §8 — exact data,
│  ✗ NO file_facts                │  never approximate
│  ✗ NO function_facts            │
└─────────────────────────────────┘
```

### Why no embeddings — the precision rule

A service name like `csChgProdTp` is an **exact identifier**. Turning it into a vector
makes it *approximate* — a cosine-distance query might return `csChgSubTp` as "similar".
That is a wrong answer for an exact lookup. Config values are Tier 1-domain: they must
remain exact SQL lookups, never vector similarity targets (Contract 06 §8).

### What it enables at query time (the ECLE 1.0 fix)

The ECLE 1.0 failure on Prompt #1 ("list Tuxedo services calling `pgn_gt_full_message`")
was caused by the absence of this pipeline. With config onboarded:

```
ecle_find_callers('pgn_gt_full_message', resolve_service_name=true)
    │
    ├── function_calls WHERE callee_name = 'pgn_gt_full_message'
    │   → caller functions in source files
    │
    └── shared_artifacts WHERE artifact_type = 'SERVICE'
        JOIN via file_entry_points on source file
        → service names: csChgProdTp, csGtWnpTrx, csChgSub, ...
```

---

## 3. Domain Data (`content_type: data` and `content_type: data-sql`)

**Examples:**
- `data`: XML field definitions, FML schemas, structured text, CSV, API specs
- `data-sql`: `.sql`, `.ddl`, DDL schema files, stored procedure definitions

**Tier:** Tier 1-domain — exact lookup. DDL is as authoritative as code for schema facts.  
**repo_role:** `platform` (DDL schemas, domain XML — shared across all module repos)

### Pipeline

```
┌──────────────────────────────────────────────────────────────────────┐
│ AXIS 1: content_type = data / data-sql                               │
│ AXIS 2: source = git or local                                        │
│ AXIS 3: schedule = recurring (DDL evolves with DB migrations)        │
└──────────────────────────────────────────────────────────────────────┘
         │
         ▼ file.discovered event
┌─────────────────────────────────┐
│  Document type detector         │
│  (for content_type=data only)   │
│                                 │
│  XML root element → api_spec    │
│  XML field decls → field_defn   │
│  CSV/TSV → tabular_data         │
│  Unknown → skip (unsupported)   │
│                                 │
│  For data-sql: DDL parser       │
│  CREATE TABLE / ALTER / INDEX   │
└────────────┬────────────────────┘
             │
             ▼
┌─────────────────────────────────┐
│  Domain parser (per type)       │
│                                 │
│  XML field_definition →         │
│  ├── field_name                 │
│  ├── field_type                 │
│  ├── valid_values (enum)        │
│  └── parent_service             │
│                                 │
│  DDL (data-sql) →               │
│  ├── table_name                 │
│  ├── column_name                │  ADR-0031
│  ├── column_type                │
│  ├── constraints                │
│  ├── COMMENT ON COLUMN text     │  ← business meaning lives here
│  └── CHECK constraint values    │  ← valid values live here
└────────────┬────────────────────┘
             │
             ▼
┌─────────────────────────────────┐
│  persist_facts worker           │
│                                 │
│  shared_artifacts:              │
│  └── artifact_type = TABLE      │
│      (one row per table)        │
│                                 │
│  field_extractions:             │  ADR-0031 extensions:
│  ├── field_name                 │  parent_table
│  ├── field_type                 │  column_position
│  ├── valid_values               │  description (from COMMENT)
│  ├── parent_table               │
│  └── description                │
│                                 │
│  ✗ NO vector embeddings         │  Contract 06 §8
│  ✗ NO file_facts                │
│  ✗ NO function_facts            │
└─────────────────────────────────┘
```

### What it enables at query time (ECLE 1.0 Prompts #2, #5, #6, #7)

```
ecle_field_lookup('SUBSCRIBER', column='INIT_ACTIVATION_DATE')
    └── field_extractions WHERE parent_table='SUBSCRIBER'
        AND field_name='INIT_ACTIVATION_DATE'
        → {type: DATE, description: "Date subscriber was first activated",
           defining_repo: ddl-schemas}

ecle_field_lookup('ACCOUNT', column='BILL_TYPE')
    └── field_extractions WHERE parent_table='ACCOUNT'
        AND field_name='BILL_TYPE'
        → {type: CHAR(1), valid_values: ["P","E"],
           description: "P=Paper bill, E=Electronic/Paperless",
           defining_repo: ddl-schemas}
```

The DDL comment becomes the answer to "what is TFB account" when the DDL contains:
```sql
COMMENT ON COLUMN ACCOUNT.ACCOUNT_TYPE IS
  'TFB = Transfer From Billing — migrated prepaid account type';
```

---

## 4. Documents / Secret Business Docs (`content_type: docs`)

**Examples:** Design docs, runbooks, pricing rules, business process maps, internal
policy documents, system understanding documents  
**Tier:** Tier 3 — informational. Supporting context, not structural ground truth.  
**repo_role:** `platform` (cross-cutting docs available to all module queries)

### Pipeline

```
┌──────────────────────────────────────────────────────────────────────┐
│ AXIS 1: content_type = docs                                          │
│ AXIS 2: source = local (sensitive docs often not in git)             │
│ AXIS 3: schedule = once (static snapshot) or recurring (living docs) │
└──────────────────────────────────────────────────────────────────────┘
         │
         ▼ file.discovered event
┌─────────────────────────────────┐
│  Document reader + chunker      │
│                                 │
│  Formats: .md, .docx, .pdf,     │
│           .html, .txt           │
│                                 │
│  Split into overlapping chunks  │
│  (~512 tokens, configurable)    │
│  Token count per chunk          │
│                                 │
│  NO structural extraction —     │
│  no function/SQL/call parsing   │
└────────────┬────────────────────┘
             │
             ▼
┌─────────────────────────────────┐
│  persist_facts worker           │
│                                 │
│  documents:                     │
│  ├── id, tenant_id, repo_id     │
│  ├── file_path, content_hash    │
│  └── is_current                 │
│                                 │
│  doc_chunks:                    │
│  ├── id (= vector point ID)     │
│  ├── document_id                │
│  ├── chunk_index                │
│  ├── chunk_text                 │
│  └── token_count                │
└────────────┬────────────────────┘
             │
             ▼
┌─────────────────────────────────┐
│  batch_embed worker             │
│                                 │
│  ONNX embedding of chunk_text   │
│  → Layer Docs vector collection │
│  {tenant_id}__{repo_id}__docs   │
│                                 │
│  Lineage:                       │
│  vector_point.id                │
│  → doc_chunk.id                 │
│  → documents.id                 │
│  → file_path + content_hash     │
└─────────────────────────────────┘
```

### Security layers for sensitive documents

```
┌──────────────────────────────────────────────────────────────────────┐
│ LAYER 1 — Tenant isolation (ADR-0022)                                │
│                                                                      │
│ Every doc_chunk row carries tenant_id.                               │
│ PostgreSQL Row Level Security enforces:                              │
│   WHERE tenant_id = current_setting('app.tenant_id')                │
│ Tenant B CANNOT see tenant A's doc chunks. Ever.                     │
│ Enforced at DB level — not application logic.                        │
└──────────────────────────────────────────────────────────────────────┘
┌──────────────────────────────────────────────────────────────────────┐
│ LAYER 2 — API key authentication (ADR-0019, Phase 2+)               │
│                                                                      │
│ `query` scope required to call ecle_search_docs.                     │
│ Key is tenant-scoped: bound to one tenant at creation time.          │
│ Raw key shown once — SHA256(key) stored, never the key itself.       │
│ Dev tier: auth disabled by default (MCP_AUTH_DISABLED=true).         │
└──────────────────────────────────────────────────────────────────────┘
┌──────────────────────────────────────────────────────────────────────┐
│ LAYER 3 — Full audit trail (Contract 11 §1.6)                        │
│                                                                      │
│ Every ecle_search_docs call written to query_audit_log:             │
│   subject     — caller identity (user@corp.com or apikey:label)      │
│   tool        — ecle_search_docs                                     │
│   query_text  — the natural language query                           │
│   called_at   — timestamp                                            │
│                                                                      │
│ Caller informed via FACT envelope:                                   │
│   trustworthy.audit_notice =                                         │
│   "Queries are recorded for system improvement and operational       │
│    audit. See your organisation's data policy."                      │
│                                                                      │
│ Retained for AUDIT_LOG_RETENTION_DAYS (default: 365 days, ADR-0021) │
└──────────────────────────────────────────────────────────────────────┘
┌──────────────────────────────────────────────────────────────────────┐
│ LAYER 4 — Tier 3 authority ceiling (Contract 06 §8)                  │
│                                                                      │
│ A result from a secret doc is labelled Tier 3 = informational.       │
│ It CANNOT override Tier 1-code or Tier 1-domain facts.               │
│ It is supporting context — confirmed against code/DDL before cited   │
│ as ground truth.                                                      │
└──────────────────────────────────────────────────────────────────────┘
```

### Known limitation — no sub-tenant (repo-level) access control

Today's isolation is **tenant-level only**. If the billing team and payments team share
the same tenant, they both see the same `ecle_search_docs` results. Restricting
document access within a tenant (e.g. "only billing team can see pricing-rules.docx")
requires a future ADR for repo-scoped RBAC. This is not yet in the constitution.

### What it enables at query time

```
ecle_search_docs("TFB account business rules")
    │
    ├── BM25 text search on doc_chunks.chunk_text
    │   for "TFB", "account", "business rules"
    │
    ├── ANN vector search on Layer Docs collection
    │   for semantic match to the query
    │
    ├── RRF fusion of BM25 + ANN results
    │
    └── Returns: top-K doc chunks with lineage
                 tier: 3 (informational)
                 lineage: doc_chunk.id → documents.id → file_path
```

---

## 5. Complete Picture — All Types Together

```
PLATFORM REPOS (onboarded first, enrich everything)
┌─────────────────────────────────────────────────────────────────────┐
│  ddl-schemas (data-sql, platform)                                   │
│  → field_extractions (SUBSCRIBER.INIT_ACTIVATION_DATE, etc.)        │
│  → shared_artifacts (TABLE rows for every table)                    │
│                                                                     │
│  service-registry (config, platform)                                │
│  → shared_artifacts (SERVICE rows: csChgProdTp, csGtWnpTrx, ...)    │
│  → file_entry_points (tuxedo_service type)                          │
│                                                                     │
│  tuxedo-field-defs (data, platform)                                 │
│  → field_extractions (FML field definitions with valid values)      │
│                                                                     │
│  system-understanding (docs, platform)                              │
│  → doc_chunks + Layer Docs vectors (business terminology)           │
└──────────────────────────────┬──────────────────────────────────────┘
                               │ enrichment available at query time (ADR-0017)
                               │ no re-indexing of module repos required
                               ▼
MODULE REPOS (onboarded independently, consume platform enrichment)
┌─────────────────────────────────────────────────────────────────────┐
│  billing-service (code, module)                                     │
│  → file_facts, function_facts, function_calls                       │
│  → function_table_ops (fn → SUBSCRIBER + sql_text + columns[])      │
│  → file_literals ("P10MDataPassEndOfServiceOccurred", "PRE_P10M")   │
│  → topology_edges (WRITE_READ, FUNCTION_CALL, etc.)                 │
│  → Layer 1/2/3 vectors (behavioral signatures)                      │
└──────────────────────────────┬──────────────────────────────────────┘
                               │
                               ▼
QUERY TIME — stitching happens here
┌─────────────────────────────────────────────────────────────────────┐
│  "Tuxedo services calling pgn_gt_full_message?"                     │
│  → function_calls (code) + shared_artifacts SERVICE (config)        │
│                                                                     │
│  "Functions updating INIT_ACTIVATION_DATE?"                         │
│  → function_table_ops (code) + field_extractions (DDL)             │
│                                                                     │
│  "What is TFB account / where is BILL_TYPE stored?"                 │
│  → field_extractions description (DDL) + doc_chunks (docs)          │
│                                                                     │
│  "Code creating P10MDataPassEndOfServiceOccurred?"                  │
│  → file_literals (code) + shared_artifacts EVENT (event catalog)    │
└─────────────────────────────────────────────────────────────────────┘
```

---

## 6. Decision Guide — What Content Type to Use

| What you're onboarding | content_type | repo_role | Why |
|------------------------|-------------|-----------|-----|
| Source code (.c, .ppc, .py, .cbl) | `code` | `module` | Full CPG extraction |
| Shared library / framework code | `code` | `platform` | Available to all module queries |
| UBBCONFIG / service registry | `config` | `platform` | Service name → source file mapping |
| `.env`, application properties | `config` | `module` | Module-scoped config extraction |
| DDL / schema SQL files | `data-sql` | `platform` | Column definitions for all modules |
| XML field definitions (FML, etc.) | `data` | `platform` | Exact field lookup for all modules |
| API spec (OpenAPI, WSDL) | `data` | `platform` | Contract registry |
| Design docs, runbooks | `docs` | `platform` | Context for all module queries |
| Internal business rules doc | `docs` | `platform` | Tier 3, tenant-isolated, audited |
| Module-specific documentation | `docs` | `module` | Module-scoped doc search |

---

## 7. What Never Gets Embedded

The following MUST NOT produce vector embeddings (Contract 06 §8 Tier 1-domain rule):

- DDL column names and types
- Config key-value pairs
- Service names from UBBCONFIG
- Field names from XML specs
- API operation names
- Table names

These are **exact identifiers**. Similarity search on them produces wrong answers.
They are exact lookup targets in the structured DB only.

---

## References

| Document | What it defines |
|----------|----------------|
| [ADR-0015](../constitution/adrs/ADR-0015-three-axis-onboard-model.md) | Three-axis model: content_type × source × schedule |
| [ADR-0016](../constitution/adrs/ADR-0016-tree-sitter-extraction-depth.md) | What the code parser extracts (9 categories) |
| [ADR-0017](../constitution/adrs/ADR-0017-platform-module-repository-model.md) | Platform vs module roles; query-time enrichment |
| [ADR-0019](../constitution/adrs/ADR-0019-authn-authz-model.md) | API key auth; tenant-scoped access control |
| [ADR-0022](../constitution/adrs/ADR-0022-tenant-isolation-model.md) | Tenant isolation tiers (logical/schema/physical) |
| [ADR-0031](../constitution/adrs/ADR-0031-stitching-completeness.md) | function_table_ops, file_literals, DDL columns, SERVICE type |
| [Contract 06](../constitution/contracts/06-grounding-contract.md) | Tiered knowledge authority; lineage requirements |
| [Contract 11](../constitution/contracts/11-mcp-contract.md) | Tool catalogue; audit notice rule |
| [Contract 15](../constitution/contracts/15-db-schema-contract.md) | All table schemas |
