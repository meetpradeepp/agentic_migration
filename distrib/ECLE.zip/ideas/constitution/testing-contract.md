# Testing Contract — How We Verify ECLE

## Test Pyramid

```
        /  E2E  \          10% — Full pipeline, live LLM (nightly)
       /----------\
      / Integration \      20% — Cross-layer, Docker services (every PR)
     /----------------\
    /    Unit Tests     \  70% — Single module, fast, deterministic (every PR)
   /--------------------\
```

## Coverage Requirements

| Code Category | Minimum Coverage | Rationale |
|---------------|-----------------|-----------|
| New code (any module) | 80% line coverage | Baseline quality |
| Core abstractions (interfaces, schemas) | 95% line coverage | These are the contracts — must be fully specified |
| Grounding verifiers | 100% line coverage | Safety-critical — incorrect verification = hallucination passes |
| Existing code | No regression allowed | Coverage can only go up, never down |

## Test Properties by Stage

| Property | Non-LLM Stages | LLM Stages |
|----------|---------------|------------|
| **Deterministic** | Required — same input → same output, always | Not required — LLM outputs vary |
| **Idempotent** | Required — processing same event twice = same state | Required — grounding verifier result is deterministic |
| **Fast** | Required — < 100ms per unit test | Acceptable — LLM calls cached via VCR fixtures in CI |
| **Isolated** | Required — no external service dependencies | VCR fixtures for CI; live LLM for nightly |

## Performance Benchmarks (enforced in CI)

| Operation | Target Latency | Gate |
|-----------|---------------|------|
| Commit path (no LLM) | < 500ms | CI fails if exceeded |
| Hot graph read | < 50ms | CI fails if exceeded |
| Structural fingerprint | < 10ms per file | CI fails if exceeded |
| CIM normalization | < 5ms per file | CI fails if exceeded |
| Bloom filter lookup | < 1μs | CI fails if exceeded |
| Regression tolerance | < 10% degradation from baseline | Alert if exceeded |

## Eval Suites (Hard Gates)

These are not regular tests — they are behavioral contracts. Failure means the system is fundamentally broken.

| Eval | What It Tests | Pass Criteria | When |
|------|--------------|---------------|------|
| Refactor Invariance | Fingerprint stability on cosmetic changes | Fingerprint identical, LLM calls = 0 | Every PR |
| Semantic Drift | Fingerprint sensitivity to logic changes | Fingerprint changes, LLM fires | Every PR |
| Neighborhood Staleness | Contextual drift detection | Neighbor change → caller's hash changes | Every PR |
| Staleness Honesty | No silent stale answers | confidence < 1.0 + caveat on stale data | Nightly |
| Grounding Coverage | No uncited LLM claims | 0 ungrounded claims pass verification | Nightly |
| Delta Fidelity | Delta vs full synthesis accuracy | Cosine similarity ≥ 0.92 | Nightly |
| Connector Equivalence | Filesystem vs Git parity | Byte-identical CPG/FSS output | Nightly |
| Cluster Cohesion | Cluster quality | Silhouette score > 0.65 | Nightly |

## LLM Test Strategy

```
Development:
  → Run tests with live LLM calls
  → Record responses as VCR fixtures

CI (every PR):
  → Replay VCR fixtures — deterministic, fast, no LLM cost
  → If prompt changes → fixture mismatch → test fails → re-record

Nightly:
  → Run with live LLM calls — validates fixtures are still accurate
  → If nightly fails but PR passed → fixture is stale → re-record
  → Live eval suites (LLM-as-judge) run here only
```
