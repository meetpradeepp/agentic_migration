# Confidence Contract — Decomposed Confidence Profile

Every node in the knowledge graph carries a **decomposed confidence profile** with 5 independent dimensions.

## The 5 Confidence Dimensions

| Dimension | What it measures | How it degrades |
|-----------|-----------------|-----------------|
| `syntactic_freshness` | CPG is current at this commit | Deterministic — never degrades without code change |
| `behavioral_accuracy` | FSS freshly derived from current CPG | Degrades when fingerprint changes without re-derivation |
| `contextual_accuracy` | Neighborhood hash matches current state | Degrades silently when neighbors change (the key innovation) |
| `edge_coherence` | FPS edge labels match current FSS of endpoints | Degrades when coherence check finds SEMANTICALLY_INCONSISTENT |
| `cluster_alignment` | File's embedding distance from cluster centroid | Degrades over time as file drifts semantically |

## Propagation Rules

- **Extraction fidelity** (FULL/PARTIAL/HEURISTIC) propagates upward as a confidence ceiling
- An FPS edge where either endpoint is PARTIAL/HEURISTIC inherits that ceiling
- A KAG capability node with any HEURISTIC constituent files carries that in its profile
- Tier 3 files always have `behavioral_accuracy: heuristic`

## Confidence Voting (from Learning Loop)

```
new_accuracy = old_accuracy + (vote_delta / sqrt(total_votes))
```

- CONFIRM votes increment `behavioral_accuracy`
- DENY votes decrement `behavioral_accuracy`
- Diminishing returns: 100th vote has less impact than 10th

## Confidence Decay

Nodes decay on a configurable half-life without validation. Decayed nodes are queued for re-derivation on next commit touching them or their neighbors.

## Answers are Always Honest

If `analysis_tier = 3`: response includes `"behavioral_accuracy: heuristic"`
If `delta_chain_depth > 20`: response includes caveat about sequential delta drift
If `model_migration_pending`: response includes model version caveat
