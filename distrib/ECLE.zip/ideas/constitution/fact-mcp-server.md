# FACT MCP Server — Scalable Query Interface

## Why Vector DB Alone Won't Scale

### The Numbers

At 1M files with 10 functions avg per file:
```
Layer 1: 1M file vectors × 768 floats × 4 bytes = ~3 GB vectors alone
Layer 2: 10M function vectors × 768 floats × 4 bytes = ~30 GB vectors alone
Plus HNSW index overhead (2-3x): ~60-90 GB for Layer 2 index
Plus payload storage: each point carries ~2 KB of metadata = ~20 GB payload
Total Layer 2: ~100-120 GB RAM
```

That's just one repo's current state. Add 5 historical versions × 500 branches and it explodes.

### The Real Problem: Most Queries Don't Need Vector Similarity

Look at what people actually ask:

| Query | Needs vectors? | Better served by |
|-------|---------------|------------------|
| "Find all files that write to FEES_LEDGER" | No — exact match on table name | Structured DB index |
| "What functions call `compute_late_fee`?" | No — exact match on callee name | Structured DB index |
| "Show me the FSS for file X at commit Y" | No — key lookup | Structured DB primary key |
| "What's the impact of changing file X?" | No — graph traversal | Graph edges + indexes |
| "What are the entry points in billing service?" | No — boolean filter | Structured DB index |
| "Find files similar to this description" | **Yes** — semantic similarity | Vector DB |
| "Find semantic duplicates" | **Yes** — high-similarity search | Vector DB |
| "What capability does this code belong to?" | **Yes** — nearest centroid | Vector DB |
| "Find code patterns like this snippet" | **Yes** — approximate match | Vector DB |

**~80% of real queries are structured lookups. ~20% need vector similarity.**

Forcing structured lookups through a vector DB with payload filters is:
- 10-100x slower than a properly indexed relational query
- Memory-wasteful (HNSW index loaded for queries that never use it)
- Unreliable at scale (Qdrant payload filters degrade with complex multi-field conditions)

---

## The Hybrid Architecture

```
┌─────────────────────────────────────────────────────────┐
│                    FACT MCP SERVER                        │
│         (single entry point for all queries)              │
│                                                           │
│  ┌───────────────┐  ┌──────────────┐  ┌──────────────┐  │
│  │  Query Router  │  │  View Engine  │  │  Cache Layer  │  │
│  └───────┬───────┘  └──────┬───────┘  └──────┬───────┘  │
│          │                  │                  │          │
├──────────┼──────────────────┼──────────────────┼──────────┤
│          ▼                  ▼                  ▼          │
│  ┌───────────────────────────────────────────────────┐   │
│  │              FACT STORE (3 backends)                │   │
│  │                                                     │   │
│  │  ┌─────────────┐  ┌─────────────┐  ┌───────────┐  │   │
│  │  │ Structured   │  │ Vector      │  │ Graph     │  │   │
│  │  │ Fact DB      │  │ Index       │  │ (topology)│  │   │
│  │  │              │  │             │  │           │  │   │
│  │  │ PostgreSQL   │  │ Qdrant      │  │ Neo4j     │  │   │
│  │  │ (enterprise) │  │ (enterprise)│  │ or        │  │   │
│  │  │ SQLite       │  │ ChromaDB    │  │ SQLite    │  │   │
│  │  │ (single-dev) │  │ (single-dev)│  │ adj-list  │  │   │
│  │  │              │  │             │  │           │  │   │
│  │  │ 80% queries  │  │ 20% queries │  │ traversal │  │   │
│  │  └─────────────┘  └─────────────┘  └───────────┘  │   │
│  └───────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────┘
```

### Backend 1: Structured Fact DB (the workhorse — 80% of queries)

This is where ALL facts live as structured, indexed, queryable rows. Every Layer 1/2/3 point's **payload** lives here. Fast exact-match, range queries, aggregations, joins.

```sql
-- Layer 1: file_facts table
CREATE TABLE file_facts (
    id              TEXT PRIMARY KEY,     -- SHA256(file_id + commit_sha)
    file_id         TEXT NOT NULL,
    commit_sha      TEXT NOT NULL,
    repo_id         TEXT NOT NULL,
    tenant_id       TEXT NOT NULL,
    branch          TEXT NOT NULL,
    language        TEXT,
    is_current      BOOLEAN DEFAULT TRUE,
    
    -- Structured facts (what FSS produces today)
    execution_model TEXT,                 -- batch|streaming|event|request
    complexity_max  INTEGER,
    complexity_avg  REAL,
    function_count  INTEGER,
    
    -- Version tracking
    previous_id     TEXT REFERENCES file_facts(id),
    version_distance REAL,               -- cosine distance from previous
    created_at      TIMESTAMP,
    superseded_at   TIMESTAMP,
    
    -- Indexes for fast structured queries
    UNIQUE(file_id, commit_sha)
);

CREATE INDEX idx_file_facts_repo_current ON file_facts(repo_id, is_current);
CREATE INDEX idx_file_facts_branch ON file_facts(branch, is_current);
CREATE INDEX idx_file_facts_tenant ON file_facts(tenant_id);

-- Layer 1: file_tables (what tables a file reads/writes)
CREATE TABLE file_tables (
    file_fact_id    TEXT REFERENCES file_facts(id),
    table_name      TEXT NOT NULL,
    operation       TEXT NOT NULL,        -- READ | WRITE
    evidence        TEXT,
    line            INTEGER,
    PRIMARY KEY(file_fact_id, table_name, operation)
);

CREATE INDEX idx_file_tables_name ON file_tables(table_name);
-- "Find all files that write to FEES_LEDGER" → instant

-- Layer 1: file_functions (functions defined in a file)
CREATE TABLE file_functions (
    file_fact_id    TEXT REFERENCES file_facts(id),
    function_name   TEXT NOT NULL,
    line_start      INTEGER,
    complexity      INTEGER,
    is_entry_point  BOOLEAN DEFAULT FALSE,
    return_type     TEXT,
    PRIMARY KEY(file_fact_id, function_name)
);

-- Layer 1: file_external_calls (external service calls)
CREATE TABLE file_external_calls (
    file_fact_id    TEXT REFERENCES file_facts(id),
    target          TEXT NOT NULL,
    protocol        TEXT,                 -- HTTP | RPC | MQ | UNKNOWN
    line            INTEGER
);

-- Layer 1: file_entry_points
CREATE TABLE file_entry_points (
    file_fact_id    TEXT REFERENCES file_facts(id),
    description     TEXT,
    evidence        TEXT,
    parameters      TEXT                  -- JSON
);

-- Layer 2: function_facts table
CREATE TABLE function_facts (
    id              TEXT PRIMARY KEY,     -- SHA256(file_id + fn_name + line + commit_sha)
    file_fact_id    TEXT REFERENCES file_facts(id),
    file_id         TEXT NOT NULL,
    function_name   TEXT NOT NULL,
    line_start      INTEGER,
    commit_sha      TEXT NOT NULL,
    repo_id         TEXT NOT NULL,
    cluster_id      TEXT,
    
    -- Function-level facts
    complexity      INTEGER,
    return_type     TEXT,
    parameters      TEXT,                 -- JSON list
    is_entry_point  BOOLEAN DEFAULT FALSE,
    is_current      BOOLEAN DEFAULT TRUE,
    
    created_at      TIMESTAMP,
    superseded_at   TIMESTAMP
);

CREATE INDEX idx_fn_facts_file ON function_facts(file_fact_id);
CREATE INDEX idx_fn_facts_cluster ON function_facts(cluster_id, is_current);

-- Layer 2: function_calls (what a function calls)
CREATE TABLE function_calls (
    caller_id       TEXT REFERENCES function_facts(id),
    callee_name     TEXT NOT NULL,
    call_type       TEXT DEFAULT 'DIRECT', -- DIRECT | VIRTUAL | DYNAMIC
    line            INTEGER
);

CREATE INDEX idx_fn_calls_callee ON function_calls(callee_name);
-- "What calls compute_late_fee?" → instant

-- Layer 2: function_table_ops (what tables a function touches)
CREATE TABLE function_table_ops (
    function_id     TEXT REFERENCES function_facts(id),
    table_name      TEXT NOT NULL,
    operation       TEXT NOT NULL          -- READ | WRITE
);

CREATE INDEX idx_fn_table_ops_table ON function_table_ops(table_name);

-- Layer 3: clusters
CREATE TABLE clusters (
    cluster_id      TEXT PRIMARY KEY,
    cluster_name    TEXT,
    repo_id         TEXT,
    tenant_id       TEXT,
    file_count      INTEGER,
    silhouette_score REAL,
    staleness_score REAL DEFAULT 0.0,
    model_version   TEXT,
    last_updated    TIMESTAMP
);

-- Layer 3: capabilities (span clusters, span repos)
CREATE TABLE capabilities (
    capability_id   TEXT PRIMARY KEY,
    capability_name TEXT,
    tenant_id       TEXT,
    staleness_score REAL DEFAULT 0.0,
    last_synthesized TIMESTAMP
);

CREATE TABLE capability_clusters (
    capability_id   TEXT REFERENCES capabilities(capability_id),
    cluster_id      TEXT REFERENCES clusters(cluster_id),
    PRIMARY KEY(capability_id, cluster_id)
);

-- Topology: edges
CREATE TABLE topology_edges (
    edge_id         TEXT PRIMARY KEY,
    source_file     TEXT NOT NULL,
    target_file     TEXT NOT NULL,
    source_function TEXT,
    target_function TEXT,
    edge_type       TEXT NOT NULL,         -- FUNCTION_CALL|WRITE_READ|EXECUTION_SEQUENCE|...
    weight          REAL NOT NULL,
    artifact        TEXT,                  -- mediating table/type/flag
    signal_type     TEXT,                  -- FPS signal detector type
    confidence      REAL,
    evidence        TEXT,
    commit_sha      TEXT NOT NULL,
    repo_id         TEXT NOT NULL,
    is_valid        BOOLEAN DEFAULT TRUE,
    
    created_at      TIMESTAMP,
    invalidated_at  TIMESTAMP
);

CREATE INDEX idx_edges_source ON topology_edges(source_file, is_valid);
CREATE INDEX idx_edges_target ON topology_edges(target_file, is_valid);
CREATE INDEX idx_edges_type ON topology_edges(edge_type, is_valid);
CREATE INDEX idx_edges_artifact ON topology_edges(artifact);
-- "What files depend on FEES_LEDGER through WRITE_READ edges?" → instant
```

**Scaling:** PostgreSQL handles billions of rows. Partitioned by `tenant_id` + `repo_id`. Read replicas for query load. Single-dev mode uses SQLite with the same schema.

### Backend 2: Vector Index (semantic search — 20% of queries)

The vector DB stores ONLY the embedding + minimal metadata for routing. NOT the full payload. The payload lives in the structured DB.

```
Vector Point (slim):
  id:         same as structured DB primary key
  vector:     float[dim]
  payload:    
    repo_id:      string     (for scoping)
    cluster_id:   string     (for scoping)
    is_current:   bool       (for filtering)
    model_version: string    (for version guard)
    layer:        1 | 2 | 3  (for layer routing)
    
    # NO structured facts in vector payload
    # Full facts live in structured DB, joined by id
```

**This changes everything for scale:**

```
Old approach (all facts in vector payload):
  10M points × 2KB payload = 20 GB payload storage in vector DB
  Complex payload filters on 7+ fields = slow

New approach (slim vector, facts in structured DB):
  10M points × 50 bytes payload = 500 MB payload storage in vector DB
  Simple payload filters on 4 fields = fast
  Full facts retrieved from structured DB by id after vector search
```

**Query flow for semantic search:**
```
1. User: "find files similar to fee calculation"
2. MCP Server → embed query → Vector DB similarity search
3. Vector DB returns: [(id=abc, score=0.92), (id=def, score=0.87), ...]
4. MCP Server → Structured DB: SELECT * FROM file_facts WHERE id IN ('abc', 'def', ...)
5. Return: full facts enriched with similarity scores
```

Two hops, but each hop is fast at what it does. Vector DB does ANN search (~1ms). Structured DB does key lookup (~1ms). Total: ~5ms including network.

### Backend 3: Graph (topology traversal)

The topology graph can live in:
- **Neo4j** (enterprise): native graph traversal, Cypher queries, handles billions of edges
- **PostgreSQL with recursive CTEs** (good enough for most cases): edges table + `WITH RECURSIVE` for path traversal
- **SQLite** (single-dev): same recursive CTEs, simpler deployment

**The graph stores only edges.** Node properties come from the structured DB. This keeps the graph lean and traversal fast.

```
Impact traversal:
1. Start: file X changed
2. Graph: find all edges outward from X (1-hop: direct callers/callees)
3. Graph: extend to 2 hops along high-weight edges (≥ 2.0)
4. Structured DB: enrich each reached node with file_facts
5. Return: impact report with full context
```

---

## The FACT MCP Server

### Architecture

The FACT MCP Server is the **single entry point** for all knowledge queries. It sits between users/agents and the three backends. Every query goes through MCP. No direct backend access.

```python
# The MCP server exposes tools, not databases.
# Agents never know about PostgreSQL, Qdrant, or Neo4j.
# They know about FACT tools.
```

### MCP Tool Catalog

```
DISCOVERY TOOLS (find things):
  fact_search              Semantic search across all layers (→ vector DB)
  fact_find_files          Structured file lookup by filters (→ structured DB)
  fact_find_functions      Structured function lookup by filters (→ structured DB)
  fact_find_tables         Find all files/functions that touch a table (→ structured DB)
  fact_find_callers        Find all callers of a function (→ structured DB)
  fact_find_callees        Find all functions called by a function (→ structured DB)
  fact_find_similar        Find semantically similar files/functions (→ vector DB)
  fact_find_duplicates     Find semantic duplicates above threshold (→ vector DB)

TRAVERSAL TOOLS (follow relationships):
  fact_impact              Impact analysis from a file/function outward (→ graph + structured)
  fact_trace_path          Trace execution path between two points (→ graph + structured)
  fact_trace_data          Trace data flow for a table/artifact (→ graph + structured)
  fact_dependency_tree     Full dependency tree for a file (→ graph + structured)

VIEW TOOLS (what PVG/KAG/SOL produce today, on demand):
  fact_view_database       Database lineage view (was database.pv)
  fact_view_security       Security view — auth/crypto/validation (was security.pv)
  fact_view_api_contracts  Entry points + their call graphs (was api_contract.pv)
  fact_view_system_map     Full system overview (was system_map.pv)
  fact_view_data_flow      Data flow across files (was data_flow.pv)
  fact_view_change_impact  Impact of a proposed change (was change_impact.pv)
  fact_view_capability     Capability description (was KAG capability)
  fact_view_catalog        File role catalog (was KAG catalog)
  fact_view_summary        System summary (was KAG summary)

CLUSTER/CAPABILITY TOOLS:
  fact_explain_capability  Describe a capability from its constituent facts
  fact_cross_capability    Dependencies between capabilities
  fact_discover_capabilities  Run capability discovery (cluster Layer 3 vectors)

VERSION TOOLS:
  fact_file_history        Version chain for a file (all commits, behavioral distance)
  fact_branch_diff         Behavioral diff between branches
  fact_timeline_at         State of knowledge at a specific point in time

CROSS-REPO TOOLS (enterprise-wide discovery — ADR-019, ADR-020):
  fact_repos               List all onboarded repos with stats (→ structured DB)
  fact_shared_artifacts    Find all repos that touch a named artifact (→ structured DB)
  fact_artifact_summary    Aggregate stats for all shared artifacts (→ structured DB)
  fact_cross_repo_edges    Cross-repo connections for a repo (→ graph + structured)
  fact_cross_repo_impact   Impact analysis spanning repo boundaries (→ graph + structured)
  fact_service_map         Full caller/implementer map for a service (→ structured + graph)

ENRICHMENT TOOLS (LLM-enhanced, optional):
  fact_explain_file        LLM-generated natural language explanation of a file's facts
  fact_explain_capability  LLM-generated capability narrative from constituent facts
  fact_summarize_impact    LLM-generated impact summary for a change
```

### Query Routing Logic

```python
class FactQueryRouter:
    """Routes MCP tool calls to the appropriate backend(s)."""

    def route(self, tool: str, params: dict) -> QueryPlan:
        # Pure structured queries → structured DB only
        if tool in ("fact_find_files", "fact_find_functions", "fact_find_tables",
                     "fact_find_callers", "fact_find_callees", "fact_file_history"):
            return QueryPlan(backends=["structured"])

        # Pure semantic queries → vector DB + structured DB for enrichment
        if tool in ("fact_search", "fact_find_similar", "fact_find_duplicates",
                     "fact_discover_capabilities"):
            return QueryPlan(backends=["vector", "structured"])

        # Traversal queries → graph + structured DB for enrichment
        if tool in ("fact_impact", "fact_trace_path", "fact_trace_data",
                     "fact_dependency_tree"):
            return QueryPlan(backends=["graph", "structured"])

        # View queries → structured DB primarily, graph for edges
        if tool.startswith("fact_view_"):
            return QueryPlan(backends=["structured", "graph"])

        # Enrichment queries → structured DB for facts, then LLM
        if tool.startswith("fact_explain_") or tool == "fact_summarize_impact":
            return QueryPlan(backends=["structured", "graph", "llm"])
```

### Query Slicing — How MCP Tools Cut Through Millions of Facts

The key to speed at scale is **never scanning the full corpus**. Every tool uses a combination of:

1. **Tenant + repo scoping** — every query starts with `tenant_id` + `repo_id` filter (or `is_current=true` for cross-repo). This eliminates 99% of data immediately in a multi-tenant deployment.

2. **Indexed lookups** — table name lookups, function name lookups, file ID lookups are all indexed columns. O(log N), not O(N).

3. **Graph-bounded traversal** — impact analysis doesn't scan all edges. It starts at the changed node and traverses outward, pruning by weight threshold. Typical traversal: 20-50 nodes, not millions.

4. **Vector scoping** — semantic search filters by `repo_id` + `is_current` before ANN search. Qdrant evaluates filters before vector comparison when the filter is selective.

5. **Cursor-based pagination** — large result sets stream with cursors. Never load millions of rows into memory.

```
Example: "What's the impact of changing fee_calculator.c?"

Step 1: Structured DB lookup (< 1ms)
  SELECT * FROM file_facts WHERE file_id = 'fee_calculator.c' AND is_current = true

Step 2: Graph traversal, 2 hops, weight ≥ 2.0 (< 5ms)
  Start: fee_calculator.c
  Hop 1: 8 files directly connected (FUNCTION_CALL + WRITE_READ edges)
  Hop 2: 23 files connected to hop-1 files (filtered by weight ≥ 2.0)
  Total: 31 files reached

Step 3: Structured DB bulk lookup (< 2ms)
  SELECT * FROM file_facts WHERE file_id IN (... 31 file IDs ...)
  JOIN file_tables ON ... (to show which tables are affected)

Step 4: Cluster/capability lookup (< 1ms)
  SELECT * FROM clusters WHERE cluster_id IN (... clusters of affected files ...)
  JOIN capabilities ON ...

Total: < 10ms for a complete impact analysis at 1M files.
No vector DB involved. No full corpus scan. Just indexed lookups + bounded traversal.
```

---

## Deployment Models

### Single-Developer (AMF-compatible)

```
FACT MCP Server
  ├── Structured DB: SQLite (single file, ~100 MB for 10K files)
  ├── Vector Index: ChromaDB (local, ~50 MB for 10K files)
  └── Graph: SQLite same DB (edges table with recursive CTEs)

Total footprint: < 200 MB. Runs on a laptop.
```

### Team / On-Premise

```
FACT MCP Server (containerized)
  ├── Structured DB: PostgreSQL (handles 100K-1M files per repo)
  ├── Vector Index: Qdrant (self-hosted, 8-32 GB RAM)
  └── Graph: PostgreSQL (recursive CTEs, or Neo4j for heavy traversal)
```

### Enterprise Cloud

```
FACT MCP Server (K8s deployment, horizontally scaled)
  ├── Structured DB: PostgreSQL (partitioned by tenant + repo, read replicas)
  ├── Vector Index: Qdrant Cloud (sharded by cluster_id, auto-scaling)
  └── Graph: Neo4j Aura / Amazon Neptune (for cross-repo traversal at scale)
  ├── Cache: Redis (query result caching, view materialization cache)
  └── Event Bus: Kafka (ingestion events, invalidation signals)
```

### Why This Scales to Millions

```
                     SQLite     PostgreSQL    PostgreSQL + partitioning
1K files             < 1ms      < 1ms         < 1ms
100K files           < 5ms      < 1ms         < 1ms
1M files             < 50ms     < 5ms         < 2ms
10M files            slow       < 10ms        < 5ms

                     ChromaDB   Qdrant        Qdrant sharded
1K embeddings        < 1ms      < 1ms         < 1ms
100K embeddings      < 5ms      < 1ms         < 1ms
1M embeddings        slow       < 5ms         < 2ms
10M embeddings       N/A        < 10ms        < 5ms

Graph traversal is bounded by hops × degree, not by corpus size.
A 2-hop traversal on a 1M-file graph with avg degree 5:
  ≤ 25 nodes visited. Same as on a 1K-file graph.
```

---

## FACT MCP Server Implementation Approach

### Phase 1: Core Server + SQLite Backend

```
src/fact/
├── __init__.py
├── server.py              # MCP server: tool registration, request handling
├── router.py              # Query router: tool → backend(s)
├── backends/
│   ├── __init__.py
│   ├── interface.py       # IFactStore, IVectorIndex, IGraphStore interfaces
│   ├── structured/
│   │   ├── __init__.py
│   │   ├── sqlite.py      # SQLite implementation (single-dev)
│   │   ├── postgres.py    # PostgreSQL implementation (enterprise)
│   │   └── schema.py      # Table definitions (shared across backends)
│   ├── vector/
│   │   ├── __init__.py
│   │   ├── chromadb.py    # ChromaDB (single-dev)
│   │   └── qdrant.py      # Qdrant (enterprise)
│   └── graph/
│       ├── __init__.py
│       ├── sqlite_graph.py # SQLite recursive CTEs (single-dev)
│       └── neo4j_graph.py  # Neo4j (enterprise)
├── tools/
│   ├── __init__.py
│   ├── discovery.py       # fact_find_*, fact_search, fact_find_similar
│   ├── traversal.py       # fact_impact, fact_trace_*, fact_dependency_tree
│   ├── views.py           # fact_view_* (on-demand PVG/KAG/SOL equivalents)
│   ├── cluster.py         # fact_explain_capability, fact_cross_capability
│   ├── version.py         # fact_file_history, fact_branch_diff, fact_timeline_at
│   └── enrichment.py      # fact_explain_* (LLM-enhanced, optional)
├── ingestion/
│   ├── __init__.py
│   ├── ingestor.py        # CPG/CIM → FACT store ingestion
│   ├── layer1.py          # File fact extraction + embedding
│   ├── layer2.py          # Function fact extraction + embedding
│   ├── layer3.py          # Cluster centroid computation
│   └── topology.py        # Edge extraction from CIM
├── cache/
│   ├── __init__.py
│   ├── view_cache.py      # Cached view results with staleness tracking
│   └── llm_cache.py       # Cached LLM enrichment results
└── config.py              # Backend selection, connection strings, thresholds
```

### Phase 2: PostgreSQL + Qdrant + View Engine

### Phase 3: Multi-tenant + Sharding + Event-driven Ingestion

---

## How Existing AMF MCP Tools Map to FACT

| AMF Tool | FACT Equivalent | Backend |
|----------|----------------|---------|
| `find_semantic_duplicates(query)` | `fact_find_similar(query, threshold=0.95)` | vector + structured |
| `find_code_patterns(query)` | `fact_search(query, layer=2)` | vector + structured |
| `amf_query_sol(query)` | `fact_search(query)` | vector + structured |
| `find_by_language(lang)` | `fact_find_files(language=lang)` | structured only |
| `find_callers_of(fn)` | `fact_find_callers(fn)` | structured only |
| `find_functions_above_complexity(n)` | `fact_find_functions(complexity_min=n)` | structured only |
| `get_entry_points()` | `fact_find_functions(is_entry_point=true)` | structured only |
| `amf_capability_actors(cap)` | `fact_explain_capability(cap)` | structured + graph |
| `amf_capability_impact(cap, change)` | `fact_impact(file, change)` | graph + structured |
| `amf_traverse_flow(start, depth)` | `fact_trace_path(start, depth)` | graph + structured |

**All 7 existing AMF MCP tools are covered.** Plus 20+ new FACT tools for richer querying.
