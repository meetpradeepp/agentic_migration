# FACT Architecture — Rethinking the Pipeline as Multi-Resolution Vector Spaces

## The Observation

AMF's pipeline stages (CPG → FSS → FPS → PVG → KAG → SOL) are **all 100% deterministic with zero LLM calls**. Each stage reads the previous stage's JSON artifacts, applies deterministic transformations, and writes new JSON artifacts. FPS builds a graph from FSS facts. PVG filters the graph into 20 views. KAG assembles views into catalogs. SOL builds a UEG from everything.

**They are all projections of the same underlying facts.**

At enterprise scale with continuous commits, this serial batch pipeline creates cascading staleness — a single file change must flow through 6 stages before knowledge is current. Each intermediate JSON artifact is a snapshot that goes stale the moment the next commit lands.

## The Redesign: FACT

**FACT = Fast, Accurate, Complete, Timely**

These are the four quality guarantees every ECLE response must satisfy:
- **Fast** — queries resolve in milliseconds, not pipeline hours. Ingestion is O(changed_files), not O(corpus).
- **Accurate** — every claim grounded in structural evidence. Zero hallucination. Verifiers reject ungrounded claims.
- **Complete** — no silent gaps. If knowledge is missing or partial, the system says so explicitly with confidence profiles.
- **Timely** — knowledge reflects the latest commit. No cascade staleness. No serving stale answers as fresh.

To achieve FACT, the serial pipeline is replaced with **multi-resolution vector spaces** + a **hybrid storage backend** + **on-demand views**:

```
OLD (AMF):
  CPG → FSS → FPS → PVG → KAG → SOL
  6 serial stages, 6 sets of JSON artifacts, cascade staleness

NEW (ECLE FACT):
  CPG → FACT Store (3 vector layers + topology graph)
             ↓
        Views derived on demand
        (what FPS/PVG/KAG/SOL produce becomes query results, not stored artifacts)
```

---

## The Three Vector Layers

### Layer 1 — File Fact Vectors (replaces FSS)

**What it stores:** One vector per file per version. The embedding captures the file's complete behavioral identity — what it reads, writes, calls, exposes, guards against.

**Source:** CPG/CIM facts for the file, deterministically assembled into a structured fact document.

**Key innovation — version tracking:** Layer 1 vectors are keyed by `(file_id, commit_sha)`. The vector itself encodes the behavioral fingerprint. Two versions of the same file that are behaviorally identical produce near-identical vectors (cosine ≈ 1.0). A meaningful behavioral change produces a different vector. **The vector IS the fingerprint** — no separate fingerprint hash needed.

```
Layer 1 Point:
  id:         SHA256(file_id + commit_sha)
  vector:     float[dim] — embedding of structured fact document
  payload:
    file_id:          string
    commit_sha:       string
    repo_id:          string
    branch:           string
    language:         string
    extraction_fidelity: FULL | PARTIAL | HEURISTIC
    is_current:       bool
    
    # Structured facts (searchable metadata, not just embedding)
    entry_points:     list[string]
    reads_tables:     list[string]
    writes_tables:    list[string]
    external_calls:   list[string]
    functions_defined: list[string]
    error_handlers:   list[string]
    sql_operations:   list[string]
    execution_model:  string (batch|streaming|event|request)
    complexity_max:   int
    complexity_avg:   float
    
    # Version tracking
    previous_version_id: string | null
    version_distance:    float | null  # cosine distance from previous version
    created_at:          ISO8601
    superseded_at:       ISO8601 | null
```

**What this replaces:**
- FSS `*.fss.json` artifacts → the structured facts live in the vector payload
- Behavioral fingerprint hash → the vector IS the fingerprint (cosine distance = behavioral distance)
- Change detection gate → `version_distance` field: if < threshold, skip downstream processing

**What you can query:**
- "Find all files that write to FEES_LEDGER table" → payload filter, no vector search needed
- "Find files similar to this one" → vector similarity search
- "Has this file changed behaviorally since last commit?" → cosine(current, previous) < threshold
- "Which files in this repo handle authentication?" → semantic search on fact text
- "Show me the FSS summary for file X at commit Y" → direct payload retrieval

**Version iteration tracking:**
```
Version chain for a file:
  v1 (commit_abc) → v2 (commit_def) → v3 (commit_ghi)
  
  version_distance(v1→v2) = 0.02  → cosmetic change (rename, comments)
  version_distance(v2→v3) = 0.31  → behavioral change (new table write)
  
  This replaces the dual-layer fingerprint (structural + semantic).
  The vector distance IS the semantic fingerprint comparison.
  The payload field diff IS the structural fingerprint comparison.
```

---

### Layer 2 — Section Fact Vectors (replaces FPS code slices + function-level analysis)

**What it stores:** One vector per function/section per file version. The embedding captures what the section does — its behavioral signature and syntax pattern.

**Source:** CIM function facts + code slices extracted during CPG.

**Key innovation — cross-file relationships emerge from vector proximity:** Two functions that operate on the same tables, call the same external services, or implement the same patterns will have similar vectors. **FPS edges become vector queries** — "find sections in other files that are behaviorally related to this section."

```
Layer 2 Point:
  id:         SHA256(file_id + function_name + line_start + commit_sha)
  vector:     float[dim] — embedding of function behavioral signature
  payload:
    file_id:          string
    function_name:    string
    line_start:       int
    commit_sha:       string
    repo_id:          string
    cluster_id:       string | null
    
    # Function-level facts
    parameters:       list[string]
    return_type:      string | null
    complexity:       int
    reads_tables:     list[string]
    writes_tables:    list[string]
    calls_functions:  list[string]
    called_by:        list[string]   # populated from topology graph
    external_calls:   list[string]
    error_handling:   list[string]
    sql_operations:   list[string]
    state_transitions: list[string]
    
    # Classification (replaces code_slices dual collection)
    behavioral_signature: string   # what it DOES (semantic)
    syntax_pattern:       string   # HOW it does it (structural)
    
    is_entry_point:   bool
    is_current:       bool
    created_at:       ISO8601
```

**What this replaces:**
- `amf_behavior_slices` ChromaDB collection → Layer 2 `behavioral_signature` in payload
- `amf_syntax_slices` ChromaDB collection → Layer 2 `syntax_pattern` in payload
- FPS `code_slices/*.slices.json` → the function facts live in vector payload
- FPS node data (reads, writes, functions_defined, etc.) → Layer 2 payload fields
- SOL UEG nodes → Layer 2 vectors ARE the UEG nodes (with richer metadata)

**What you can query:**
- "Find all functions that write to this table" → payload filter on `writes_tables`
- "Find functions with similar behavior to `reconcile_fees`" → vector similarity
- "Find semantic duplicates" → vector similarity with high threshold (> 0.95)
- "Find code patterns similar to this snippet" → embed query, search Layer 2
- "What functions call `compute_late_fee`?" → payload filter on `calls_functions`
- "Show me the call chain from entry point to database write" → topology traversal + Layer 2 enrichment

---

### Layer 3 — Cluster/Capability Vectors (replaces KAG capabilities)

**What it stores:** One vector per emergent cluster or discovered capability. The embedding is the centroid of constituent Layer 1/Layer 2 vectors, capturing the collective behavioral identity of a group of files.

**Key innovation — capabilities are vector clusters, not synthesized narratives:** KAG currently assembles text narratives per capability. In FACT, a capability IS a region of vector space. You discover it by clustering, describe it by retrieving constituent facts, and track its evolution by centroid drift.

```
Layer 3 Point:
  id:         SHA256(cluster_id | capability_id)
  vector:     float[dim] — centroid of constituent Layer 1 vectors
  payload:
    entity_type:      CLUSTER | CAPABILITY | DOMAIN
    entity_id:        string
    entity_name:      string   # auto-labeled from constituent file facts
    
    # Composition
    constituent_files:    list[string]   # file_ids (for CLUSTER)
    constituent_clusters: list[string]   # cluster_ids (for CAPABILITY)
    constituent_repos:    list[string]   # repo_ids (for CAPABILITY)
    
    # Aggregate facts (rolled up from Layer 1)
    all_tables:       list[string]   # union of all tables touched
    all_external:     list[string]   # union of all external calls
    entry_point_count: int
    file_count:       int
    total_complexity:  int
    dominant_language: string
    
    # Health
    silhouette_score:  float         # cluster cohesion quality
    staleness_score:   float
    model_version:     string
    last_updated:      ISO8601
```

**What this replaces:**
- KAG `summary.json`, `catalog.json`, `flows.json` → derived on demand from Layer 3 + Layer 1/2 retrieval
- KAG audience packs (architect, developer, etc.) → generated on demand by querying Layer 3 + filtering Layer 1/2 by audience needs
- Capability discovery → hierarchical clustering on Layer 3 centroids (already specified in architecture doc)
- KAG data_dictionary → aggregation query: all Layer 1 vectors with `reads_tables` or `writes_tables` containing target table

---

## Topology Graph (replaces FPS edges + PVG views)

The vectors store WHAT things are and DO. The topology graph stores HOW things RELATE.

```
The graph is NOT replaced by vectors. 
Vectors answer: "what is similar to X?" (semantic proximity)
Graph answers: "what is connected to X?" (structural relationship)

These are fundamentally different questions.
similarity ≠ connection (the vector DB contract still holds)
```

**But the graph becomes simpler.** In AMF, FPS builds a rich graph with 9 signal detectors and typed edges. PVG then creates 20 filtered views of this graph. In FACT:

1. **The graph stores only structural edges** (calls, reads, writes, imports — from CPG/CIM)
2. **Edge attributes** (confidence, evidence, signal_type) move to edge payload
3. **PVG's 20 views become 20 parameterized graph queries**, not 20 pre-materialized JSON files

```
Edge Schema (simplified from FPS):
  source:       file_id or function_id (node in Layer 1 or Layer 2)
  target:       file_id or function_id
  edge_type:    FUNCTION_CALL | WRITE_READ | EXECUTION_SEQUENCE | 
                SHARED_TYPE | IMPORT | STATE_FLOW
  weight:       float (canonical weights: 3.0, 2.5, 2.0, 1.0, 0.5)
  artifact:     string (table, type, flag that mediates the relationship)
  confidence:   float
  evidence:     E1 | E2 (deterministic evidence level)
  signal_type:  string (the 9 FPS signal types)
  commit_sha:   string (when this edge was established)
  is_valid:     bool (false = invalidated, not deleted)
```

**PVG views become parameterized queries:**

| Old PVG View | New Query Pattern |
|-------------|-------------------|
| `database.pv` | Graph edges where artifact is a table name + Layer 1 vectors with `reads_tables` or `writes_tables` |
| `sequence.pv` | Graph traversal along EXECUTION_SEQUENCE edges, ordered by weight |
| `security.pv` | Layer 1 vectors where payload matches auth/crypto/validation patterns |
| `api_contract.pv` | Layer 2 vectors where `is_entry_point=true` + their outbound edges |
| `change_impact.pv` | Graph traversal outward from a changed file, weighted by edge type |
| `data_flow.pv` | Graph edges of type WRITE_READ, enriched with Layer 1 table metadata |
| `service_boundary.pv` | Layer 3 clusters + inter-cluster edges |
| `critical_path.pv` | Weighted shortest path through topology graph |
| `system_map.pv` | Full Layer 1 + topology graph (the master view) |

**Each "view" is a query function, not a stored artifact.** It runs against current vector state + current graph state. Always fresh. No staleness cascade.

---

## What Happens to Each Stage

| Stage | Current | In FACT | What Changes |
|-------|---------|---------|-------------|
| **CPG** | Parse → facts JSON | Parse → facts JSON | **Unchanged** — CPG is the ground truth, stays deterministic |
| **FSS** | Facts → per-file summary JSON | Facts → **Layer 1 vector point** | Output format changes: JSON → vector upsert. Content is the same structured facts |
| **FPS** | FSS → flow graph JSON + code slices | CIM → **Layer 2 vector points** + **topology edges** | Split: function facts → Layer 2 vectors; cross-file edges → topology graph. No separate "FPS stage" |
| **PVG** | FPS graph → 20 filtered JSON views | **Deleted as a stage** → becomes 20 query functions against vectors + graph | Views are computed on demand, not pre-materialized |
| **KAG** | PVG → assembled catalogs/summaries JSON | **Deleted as a stage** → becomes aggregation queries against Layer 1/2/3 | Summaries, catalogs, data dictionaries all derived on demand from fact store |
| **MIG** | KAG + rules → migration plan | Queries Layer 3 (capabilities) + topology (dependencies) → migration plan | Input source changes, output unchanged |
| **SOL** | Everything → UEG + contracts + knowledge | **Layer 2 vectors ARE the UEG nodes**; contracts from Layer 2 entry points + edges | SOL's UEG is a view of Layer 2 + topology, not a separately built artifact |

**Net effect:** 6 stages collapse into 2 stages + 3 vector layers + 1 topology graph:
```
Stage 1: CPG extraction (unchanged, deterministic, ground truth)
Stage 2: FACT ingestion (CIM → Layer 1/2/3 vectors + topology edges)

Everything else is a QUERY, not a STAGE.
```

---

## FACT Ingestion Pipeline (replaces FSS + FPS + PVG + KAG)

```
On commit:
  1. CPG extraction for changed files (deterministic, unchanged)
  2. CIM normalization (deterministic, unchanged)
  3. For each changed file:
     a. Compute Layer 1 vector from CIM facts
        → structured fact document → embed → upsert into Layer 1
        → compare cosine distance to previous version
        → if distance < BEHAVIORAL_CHANGE_THRESHOLD: skip further processing
     b. Compute Layer 2 vectors for each function in the file
        → function facts → embed → upsert into Layer 2
     c. Update topology graph edges involving this file
        → deterministic edge computation from CIM (same as FPS signal detectors)
  4. Incremental centroid update for affected cluster (Layer 3)
  5. Done. No FPS stage. No PVG stage. No KAG stage.

Cost: O(changed files), not O(pipeline stages × changed files)
Latency: single pass, not 6 serial stages
Staleness: zero — vectors are current as soon as ingestion completes
```

---

## On-Demand View Generation (replaces PVG/KAG/SOL pre-materialization)

```python
# What was PVG's database.pv.json becomes:
def view_database_lineage(repo_id: str) -> DatabaseLineageView:
    """On-demand database lineage view — always fresh."""
    # Get all files that touch tables
    table_readers = layer1.query(filters={"repo_id": repo_id}, 
                                  payload_filter={"reads_tables": {"$ne": []}})
    table_writers = layer1.query(filters={"repo_id": repo_id},
                                  payload_filter={"writes_tables": {"$ne": []}})
    # Get WRITE_READ edges from topology
    data_edges = topology.edges(type="WRITE_READ", repo_id=repo_id)
    # Assemble view
    return DatabaseLineageView(readers=table_readers, writers=table_writers, 
                                edges=data_edges)

# What was KAG's catalog.json becomes:
def view_file_catalog(repo_id: str) -> FileCatalog:
    """On-demand file catalog — always fresh."""
    all_files = layer1.query(filters={"repo_id": repo_id, "is_current": True})
    return FileCatalog(
        files=[{
            "file": f.payload["file_id"],
            "language": f.payload["language"],
            "tables_read": f.payload["reads_tables"],
            "tables_written": f.payload["writes_tables"],
            "entry_points": f.payload["entry_points"],
            "complexity": f.payload["complexity_max"],
            "execution_model": f.payload["execution_model"],
        } for f in all_files]
    )

# What was SOL's UEG becomes:
def view_execution_graph(repo_id: str) -> ExecutionGraph:
    """On-demand UEG — always fresh."""
    nodes = layer2.query(filters={"repo_id": repo_id, "is_current": True})
    edges = topology.edges(repo_id=repo_id)
    return ExecutionGraph(nodes=nodes, edges=edges)

# What was KAG's summary.json becomes:
def view_system_summary(repo_id: str) -> SystemSummary:
    """On-demand system summary — always fresh."""
    all_files = layer1.query(filters={"repo_id": repo_id, "is_current": True})
    all_tables = set()
    for f in all_files:
        all_tables.update(f.payload["reads_tables"])
        all_tables.update(f.payload["writes_tables"])
    return SystemSummary(
        file_count=len(all_files),
        table_count=len(all_tables),
        # ... aggregated from Layer 1 payloads
    )
```

---

## Scalability Properties

### Why This Scales

1. **No cascade staleness.** Change one file → update its Layer 1 vector + Layer 2 vectors + topology edges. Done. No 6-stage pipeline to run.

2. **No intermediate artifacts.** No `fps_flow_graph.json`, no 20 PVG JSON files, no KAG JSON files. Views are queries, not stored files. Storage grows with files, not with pipeline stages × files.

3. **Incremental by default.** Vector upsert is O(1) per file. Centroid update is O(1) per cluster. Topology edge update is O(degree) per file. Total cost per commit: O(changed_files × avg_degree).

4. **Parallelizable.** Layer 1 and Layer 2 vector computation for different files is fully independent. No inter-file dependency in the ingestion path (topology edges are computed from CIM, not from other files' vectors).

5. **Query-time synthesis scales with answer size, not corpus size.** `view_database_lineage` for a 1M-file repo touches only files that interact with tables — typically < 5% of the corpus. No full scan needed.

### Scaling Numbers

| Corpus | Layer 1 Points | Layer 2 Points | Topology Edges | RAM (768-dim) |
|--------|---------------|---------------|----------------|---------------|
| 1K files | 1K | ~10K | ~50K | ~100 MB |
| 10K files | 10K | ~100K | ~500K | ~1 GB |
| 100K files | 100K | ~1M | ~5M | ~10 GB |
| 1M files | 1M | ~10M | ~50M | ~100 GB (sharded) |

Layer 2 is ~10x Layer 1 (avg ~10 functions per file). Topology edges are ~5x Layer 2 (avg ~5 edges per function). At 1M files, Layer 2 needs sharding.

### Sharding Strategy

```
Layer 1: shard by repo_id (each repo is independent)
Layer 2: shard by cluster_id (within-cluster queries are most common)
Layer 3: single collection (small — one point per cluster/capability)
Topology: shard by cluster_id (same partitioning as Layer 2)
```

---

## What About LLM-Enhanced Synthesis?

The ECLE architecture doc proposed LLM calls for:
- FSS derivation (natural language file summaries)
- KAG synthesis (capability narratives)
- FPS coherence checks (edge label verification)

In FACT, LLM is **optional enrichment**, not a pipeline stage:

```
Tier 1 (always, zero-LLM):
  Layer 1 vectors from CIM facts (deterministic, fast)
  Layer 2 vectors from function facts (deterministic, fast)
  Topology edges from CIM relationships (deterministic, fast)
  All views queryable immediately

Tier 2 (on-demand, LLM-enhanced):
  When an agent asks "explain this capability" →
    1. Retrieve Layer 3 cluster + constituent Layer 1 facts (fast)
    2. LLM synthesizes a narrative from the retrieved facts (expensive but targeted)
    3. Cache the narrative with a staleness hash
    4. Next query: check staleness hash → if unchanged, serve cache; if changed, re-synthesize
  
  When an engineer asks "what does this file do in plain English?" →
    1. Retrieve Layer 1 facts for the file (fast)
    2. LLM generates a natural language summary from the facts (expensive but targeted)
    3. Cache with version key (file_id, commit_sha)
    
  LLM cost is O(what the user asks for), not O(corpus size)
```

**The critical shift:** LLM is at **query time** (when someone asks), not at **ingestion time** (when code changes). Ingestion is fast and deterministic. Synthesis is expensive and happens only when needed.

---

## Backward Compatibility with AMF

```
AMF's output/ directory structure is preserved as a MATERIALIZED VIEW:

  output/fss/json/*.fss.json   → materialized from Layer 1 payload fields
  output/fps/json/fps_flow_graph.json → materialized from topology graph + Layer 2
  output/pvg/*.pv.json         → materialized from view query functions
  output/kag/json/*.json       → materialized from Layer 1/3 aggregation queries
  output/sol/ueg.json          → materialized from Layer 2 + topology

The `output/` directory becomes a local projection cache (as the ECLE architecture doc 
already specifies). AMF's existing agents, skills, and MCP tools read from output/ 
unchanged. FACT populates output/ on demand or on a schedule.

Backward compat command:
  python ecle materialize --format amf --output output/
  → runs all view queries → writes AMF-format JSON files → existing tools work unchanged
```

---

## Migration from Current AMF to FACT

### Phase 1: Dual-Write (AMF pipeline continues, FACT ingestion runs in parallel)
```
1. Implement FACT ingestion (Layer 1 + Layer 2 + topology from CIM)
2. After CPG stage runs, also ingest into FACT store
3. AMF pipeline continues as before — output/ produced by FPS/PVG/KAG/SOL
4. FACT views run alongside — validate equivalence with AMF outputs
5. No user-visible change. Pure validation phase.
```

### Phase 2: FACT as Primary, AMF as Fallback
```
1. MCP tools query FACT views first, fall back to output/ if FACT unavailable
2. output/ materialized from FACT views (instead of FPS/PVG/KAG/SOL stages)
3. AMF FPS/PVG/KAG stages disabled but available via --legacy flag
4. SOL stage reads from FACT Layer 2 + topology instead of FPS output
```

### Phase 3: FACT Only
```
1. FPS/PVG/KAG stages removed from pipeline
2. Pipeline is: CPG → FACT ingestion → done
3. All queries go through FACT view functions
4. output/ materialized on demand or schedule
5. LLM synthesis available as optional enrichment at query time
```

---

## Scale: Millions of Files, Multiple Repos, Multiple Timelines

### Why Serial Pipeline Dies at Scale

Consider the enterprise reality: **50 repos × 20K files avg = 1M files. 500 active branches. 1,000 commits/day.**

With the serial pipeline (CPG → FSS → FPS → PVG → KAG → SOL):
```
Per commit (touches ~5 files):
  CPG: re-extract 5 files            → OK, fast
  FSS: re-derive 5 file summaries    → OK, fast
  FPS: rebuild entire flow graph     → PROBLEM: reads ALL FSS files to find cross-file edges
  PVG: regenerate 20 views           → PROBLEM: reads entire FPS graph to filter
  KAG: re-assemble catalogs          → PROBLEM: reads all 20 PVG views
  SOL: rebuild UEG                   → PROBLEM: reads FPS + PVG + KAG

5 files changed → but FPS/PVG/KAG/SOL read the ENTIRE corpus every time.
At 1M files: impossible. At 1,000 commits/day: dead.
```

With FACT:
```
Per commit (touches ~5 files):
  CPG: re-extract 5 files                         → O(5)
  Layer 1: upsert 5 file vectors                   → O(5)
  Layer 2: upsert ~50 function vectors              → O(50)
  Topology: update edges involving 5 files          → O(5 × avg_degree ≈ 25)
  Layer 3: incremental centroid update              → O(1)

Total work: O(changed_files × degree). Independent of corpus size.
At 1M files: same cost as at 1K files.
At 1,000 commits/day: 1,000 × ~80 vector ops = 80K vector ops/day. Trivial.
```

### Multiple Repos — Unified Fact Space

In FACT, a multi-repo enterprise is just a single vector store with `repo_id` as a payload field. Cross-repo queries are vector queries with no repo filter.

```
Repo isolation:     filter={"repo_id": "billing-service"}  → scoped to one repo
Cross-repo search:  filter={"is_current": True}            → searches all repos
Capability discovery: cluster Layer 1 centroids across repos → capabilities span repos naturally

No federation stage needed. No shared filesystem directory. No separate FED/DOM stages.
Cross-repo capabilities EMERGE from vector proximity:
  fee_calculator.c (repo: billing) and settle.py (repo: payments) 
  produce similar Layer 1 vectors → their cluster centroids are close → 
  capability discovery groups them as "End-of-Day Settlement" automatically.
```

The `{tenant}__{repo}__fss` collection naming from the vector-design doc is preserved. But the key insight is: **cross-repo queries are just queries without a repo_id filter**. No special federation logic.

### Multiple Timelines — Branch-Aware Fact Versioning

Each branch is a timeline. A file can exist in different states across branches simultaneously.

```
Layer 1 versioning:
  file: fee_calculator.c
  
  main branch:    (file_id=X, commit_sha=abc, branch=main)     → vector V1
  feature branch: (file_id=X, commit_sha=def, branch=feat/new) → vector V2
  release branch: (file_id=X, commit_sha=ghi, branch=release/2.0) → vector V3

  All three coexist in Layer 1. All three have is_current=true (on their respective branches).
  
  Query: "what does fee_calculator.c do on main?"
    → filter={file_id=X, branch=main, is_current=true}
    
  Query: "how has fee_calculator.c changed between main and the feature branch?"
    → retrieve V1 and V2, compute cosine distance
    → distance = 0.15 → moderate behavioral change
    → diff their payloads: V2 adds writes_tables=["NEW_TABLE"]
    
  Query: "what's the impact of merging feature branch to main?"
    → find all Layer 1 vectors on feat/new where version_distance > threshold
    → for each: trace outward through topology graph
    → aggregate impact across repos
```

**Historical queries:**
```
  Query: "what was the state of billing-service on Jan 15?"
    → resolve commit_sha for main branch at Jan 15
    → filter={repo_id=billing, branch=main, commit_sha ≤ target}
    → returns the Layer 1 vectors that were is_current at that point
    
  This is why we keep superseded vectors (is_current=false) with their commit_sha.
  Historical state is reconstructable from the version chain.
  GC removes vectors older than 90 days — but release-tagged vectors are kept forever.
```

**Branch lifecycle:**
```
  Active branch (commit in last 14 days): full Layer 1/2/3 maintained
  Stale branch (14-90 days, no commits): vectors retained but not updated
  Dead branch (>90 days or deleted): vectors archived to cold storage
  
  On branch merge to main:
    1. For each file changed on branch:
       a. main's Layer 1 vector becomes the is_current version
       b. branch's Layer 1 vector gets superseded_at = now
    2. Topology edges re-computed for changed files against main's context
    3. Layer 3 centroid update for affected clusters
    4. No FPS/PVG/KAG stages to re-run. Just vector updates.
```

### Multi-Repo Topology — Cross-Repo Edges

When repo A calls repo B's API (HTTP, RPC, message queue), the topology needs cross-repo edges.

```
Edge:
  source: (repo=billing, file=api_client.py, function=call_payment_gateway)
  target: (repo=payments, file=gateway.py, function=process_payment)
  edge_type: CROSS_REPO_CALL
  protocol: HTTP
  confidence: 0.8  (resolved from static analysis of URL/endpoint matching)

Cross-repo edges are discovered by:
  1. Layer 1 payload: external_calls contains endpoint URLs/service names
  2. Match against Layer 2 entry points across repos
  3. If entry_point in repo B matches external_call in repo A → cross-repo edge

This is what the architecture doc's BOUNDARY_NODE concept addresses.
In FACT, it's just an edge in the topology graph with both endpoints resolved.
```

---

## Open Questions for Resolution

1. **Embedding model choice:** Same model for Layer 1 (file facts) and Layer 2 (function facts)? Or specialized models per layer? Single model is simpler; specialized may give better within-layer similarity.

2. **Payload size limits:** Layer 1 payload includes all structured facts (tables, functions, calls, etc.). For files with 100+ functions, this payload is large. Options: store summary in payload, full details in object store with a UAL pointer.

3. **Topology graph engine:** Lightweight (SQLite + adjacency lists) or full graph DB (Neo4j)? For single-dev, SQLite. For enterprise, Neo4j. The FACT interface should abstract this.

4. **View caching strategy:** Views are always fresh but may be expensive to compute for large repos. Cache policy: cache with TTL? Cache with staleness hash? Cache with explicit invalidation on relevant Layer 1/2 changes?

5. **LLM synthesis cache:** When LLM-generated narratives are cached, how long before re-synthesis? Options: on-demand (re-synthesize when underlying vectors change), periodic (re-synthesize weekly), or never (always generate fresh). Cost vs freshness tradeoff.
