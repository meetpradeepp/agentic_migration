# FACT Query Engine — GraphQL Service Behind MCP Tools

## The Architecture

```
Agents / IDE / CI/CD
        │
        ▼
┌─────────────────────────┐
│     MCP Tool Layer       │  Thin tools — translate NL intent → GraphQL queries
│  (fact_impact, fact_search, etc.)                                │
└───────────┬─────────────┘
            │ GraphQL over HTTP
            ▼
┌─────────────────────────────────────────────────────────────┐
│              FACT Query Engine (GraphQL Service)              │
│                                                               │
│  ┌─────────────┐  ┌──────────────┐  ┌────────────────────┐  │
│  │ Schema       │  │ Query Planner │  │ Resolver Pipeline  │  │
│  │ (types,      │  │ (cross-backend│  │ (structured →      │  │
│  │  queries,    │  │  optimization)│  │  graph → vector    │  │
│  │  mutations)  │  │              │  │  composition)      │  │
│  └─────────────┘  └──────────────┘  └────────────────────┘  │
│          │                │                    │              │
│          ▼                ▼                    ▼              │
│  ┌─────────────┐  ┌──────────────┐  ┌────────────────────┐  │
│  │ DataLoaders  │  │ Filter       │  │ Result Composer    │  │
│  │ (batching +  │  │ Pushdown     │  │ (merge multi-      │  │
│  │  caching)    │  │ Engine       │  │  backend results)  │  │
│  └──────┬──────┘  └──────┬───────┘  └────────┬───────────┘  │
│         │                │                    │              │
├─────────┼────────────────┼────────────────────┼──────────────┤
│         ▼                ▼                    ▼              │
│    Structured DB     Graph Store        Vector Index         │
│    (PostgreSQL/      (Neo4j/            (Qdrant/             │
│     SQLite)          pg recursive)       ChromaDB)           │
└─────────────────────────────────────────────────────────────┘
```

### Why GraphQL, Not Just Smart MCP

| Problem | Thin MCP | GraphQL Engine |
|---------|----------|---------------|
| Agent calls 6 tools for one question | 6 round trips, agent orchestrates | 1 query, engine orchestrates |
| N+1 problem (get IDs, then fetch each) | N+1 DB calls | DataLoader batches automatically |
| Cross-backend joins | Impossible in one call | Resolver pipeline composes |
| Overfetching (get full file when you need name) | Always returns full payload | Client specifies exact fields |
| New view needed | New MCP tool code | New GraphQL query, zero backend change |
| Agent composition (impact + similar + capability) | 3 sequential tool calls | 1 nested query |

---

## GraphQL Schema

```graphql
# ─── Layer 1: Files ─────────────────────────────────────────

type FileFact {
  id: ID!
  fileId: String!
  commitSha: String!
  repoId: String!
  branch: String!
  language: String
  isCurrent: Boolean!
  executionModel: String
  complexityMax: Int
  complexityAvg: Float
  functionCount: Int
  createdAt: DateTime!
  supersededAt: DateTime

  # Resolved from structured DB (related tables)
  tables: [TableOperation!]!
  entryPoints: [EntryPoint!]!
  externalCalls: [ExternalCall!]!

  # Resolved from Layer 2 (functions in this file)
  functions: [FunctionFact!]!

  # Resolved from graph (topology edges involving this file)
  dependsOn: [Edge!]!                    # outbound edges
  dependedOnBy: [Edge!]!                 # inbound edges
  impactRadius(hops: Int = 2, minWeight: Float = 2.0): ImpactReport!

  # Resolved from Layer 3 (which cluster/capability)
  cluster: Cluster
  capabilities: [Capability!]!

  # Resolved from vector DB (semantic similarity)
  similar(topK: Int = 5, minScore: Float = 0.7): [SimilarResult!]!

  # Version chain (resolved from structured DB)
  previousVersion: FileFact
  nextVersion: FileFact
  versionDistance: Float                 # cosine distance from previous
  history(limit: Int = 10): [FileFact!]!
}

type TableOperation {
  tableName: String!
  operation: TableOp!                    # READ | WRITE
  evidence: String
  line: Int

  # Cross-file: other files that touch this table
  otherFiles(operation: TableOp): [FileFact!]!
}

enum TableOp { READ WRITE }

type EntryPoint {
  description: String
  evidence: String
  parameters: JSON
}

type ExternalCall {
  target: String!
  protocol: String
  line: Int
  # If resolvable to another repo's file:
  resolvedTarget: FileFact
}

# ─── Layer 2: Functions ─────────────────────────────────────

type FunctionFact {
  id: ID!
  fileId: String!
  functionName: String!
  lineStart: Int!
  commitSha: String!
  repoId: String!
  complexity: Int
  returnType: String
  isEntryPoint: Boolean!
  isCurrent: Boolean!

  # Structured relations
  file: FileFact!
  tables: [TableOperation!]!
  calls: [FunctionCall!]!               # what this function calls
  calledBy: [FunctionCall!]!            # what calls this function

  # Semantic
  similar(topK: Int = 5): [SimilarResult!]!
  duplicates(minScore: Float = 0.95): [SimilarResult!]!
}

type FunctionCall {
  callee: String!
  callType: CallType!
  line: Int
  # If resolvable to a FunctionFact in the store:
  resolvedCallee: FunctionFact
}

enum CallType { DIRECT VIRTUAL DYNAMIC }

# ─── Layer 3: Clusters & Capabilities ───────────────────────

type Cluster {
  clusterId: ID!
  clusterName: String
  repoId: String!
  fileCount: Int!
  silhouetteScore: Float
  stalenessScore: Float!
  dominantLanguage: String

  # Constituent files
  files(limit: Int, offset: Int): [FileFact!]!

  # Aggregate facts
  allTables: [String!]!
  allExternalCalls: [String!]!
  totalComplexity: Int!

  # Relationships
  capabilities: [Capability!]!
  edgesTo(otherClusterId: ID!): [Edge!]!
  neighborClusters(minWeight: Float = 1.0): [ClusterRelation!]!

  # Semantic
  similar(topK: Int = 3): [SimilarResult!]!
}

type Capability {
  capabilityId: ID!
  capabilityName: String!
  stalenessScore: Float!

  # Composition
  clusters: [Cluster!]!
  repos: [String!]!
  fileCount: Int!

  # Cross-capability
  dependsOn: [CapabilityRelation!]!
  dependedOnBy: [CapabilityRelation!]!
  sharedClusters(withCapability: ID!): [Cluster!]!

  # Aggregate facts (rolled up from constituent clusters)
  allTables: [String!]!
  entryPointCount: Int!
}

type CapabilityRelation {
  target: Capability!
  edgeCount: Int!
  dominantType: String!
  totalWeight: Float!
}

# ─── Topology ────────────────────────────────────────────────

type Edge {
  edgeId: ID!
  source: FileFact!
  target: FileFact!
  sourceFunction: String
  targetFunction: String
  edgeType: EdgeType!
  weight: Float!
  artifact: String                       # mediating table/type/flag
  signalType: String
  confidence: Float!
  evidence: String!

  # Contextual
  isInterCluster: Boolean!
  sourceCluster: Cluster
  targetCluster: Cluster
}

enum EdgeType {
  FUNCTION_CALL
  WRITE_READ
  EXECUTION_SEQUENCE
  SHARED_TYPE
  IMPORT
  STATE_FLOW
  CROSS_REPO
}

# ─── Impact & Traversal ────────────────────────────────────

type ImpactReport {
  sourceFile: FileFact!
  hops: Int!
  minWeight: Float!
  directImpact: [ImpactedFile!]!
  transitiveImpact: [ImpactedFile!]!
  clustersAffected: [Cluster!]!
  capabilitiesAffected: [Capability!]!
  tablesAffected: [String!]!
  totalFilesImpacted: Int!
}

type ImpactedFile {
  file: FileFact!
  distance: Int!                         # hops from source
  pathWeight: Float!                     # sum of edge weights on path
  impactType: String!                    # CALLER | CALLEE | DATA_CONSUMER | etc
  path: [Edge!]!                         # edges from source to this file
}

type ExecutionPath {
  pathId: String!
  steps: [PathStep!]!
  totalConfidence: Float!               # min confidence across all steps
  totalWeight: Float!                   # sum of edge weights
  tablesTouched: [String!]!
}

type PathStep {
  node: FunctionFact!
  edge: Edge
  stepNumber: Int!
}

type SimilarResult {
  item: FileFact                         # or FunctionFact or Cluster
  score: Float!
  layer: Int!                            # 1, 2, or 3
}

# ─── Queries ─────────────────────────────────────────────────

type Query {
  # ── Discovery ──
  file(fileId: String!, branch: String, commitSha: String): FileFact
  files(
    repoId: String!
    branch: String = "main"
    language: String
    minComplexity: Int
    hasTable: String                     # files that read or write this table
    isEntryPoint: Boolean
    limit: Int = 50
    offset: Int = 0
  ): [FileFact!]!

  function(fileId: String!, functionName: String!): FunctionFact
  functions(
    repoId: String!
    callee: String                       # functions that call this name
    caller: String                       # functions called by this name
    table: String                        # functions that touch this table
    minComplexity: Int
    isEntryPoint: Boolean
    limit: Int = 50
  ): [FunctionFact!]!

  # ── Semantic Search (→ vector DB) ──
  search(
    query: String!
    repoId: String
    layer: Int                           # 1=files, 2=functions, 3=clusters
    topK: Int = 10
    minScore: Float = 0.5
  ): [SimilarResult!]!

  # ── Topology ──
  impact(
    fileId: String!
    functionName: String
    hops: Int = 2
    minWeight: Float = 2.0
  ): ImpactReport!

  tracePath(
    startFileId: String!
    startFunction: String!
    endFileId: String!
    endFunction: String
    maxDepth: Int = 10
  ): [ExecutionPath!]!

  traceData(
    tableName: String!
    repoId: String!
  ): DataLineage!

  # ── Clusters & Capabilities ──
  cluster(clusterId: ID!): Cluster
  clusters(repoId: String!): [Cluster!]!
  capability(capabilityId: ID!): Capability
  capabilities(tenantId: String!): [Capability!]!
  discoverCapabilities(repoId: String!): [Capability!]!

  # ── Views (what PVG/KAG produce, on demand) ──
  viewDatabaseLineage(repoId: String!): DatabaseLineageView!
  viewSystemMap(repoId: String!): SystemMapView!
  viewSecuritySurface(repoId: String!): SecurityView!
  viewApiContracts(repoId: String!): ApiContractView!

  # ── Version ──
  fileHistory(fileId: String!, branch: String, limit: Int = 20): [FileFact!]!
  branchDiff(
    repoId: String!
    baseBranch: String!
    compareBranch: String!
  ): BranchDiff!

  # ── Cross-Repo (ADR-019, ADR-020) ──
  repos(tenantId: String!): [RepoSummary!]!

  sharedArtifacts(
    tenantId: String!
    artifactName: String!
    artifactType: ArtifactType
  ): SharedArtifactResult!

  artifactSummary(
    tenantId: String!
    artifactType: ArtifactType
    minRepoCount: Int = 2
  ): ArtifactSummaryResult!

  crossRepoEdges(
    tenantId: String!
    repoId: String!
    edgeType: CrossRepoEdgeType
  ): CrossRepoEdgeResult!

  crossRepoImpact(
    tenantId: String!
    artifactName: String!
    artifactType: ArtifactType!
    changeType: ChangeType!
  ): CrossRepoImpactResult!

  serviceMap(
    tenantId: String!
    serviceName: String!
  ): ServiceMapResult!
}

# ─── Cross-Repo Types (ADR-019, ADR-020) ──────────

enum ArtifactType { TABLE TUXEDO_SERVICE API_ENDPOINT MESSAGE_QUEUE SHARED_HEADER }
enum CrossRepoEdgeType { WRITE_READ SERVICE_CALL QUEUE API }
enum ChangeType { SCHEMA_CHANGE SERVICE_RENAME TABLE_DROP COLUMN_ADD COLUMN_DROP }

type RepoSummary {
  repoId: String!
  fileCount: Int!
  functionCount: Int!
  edgeCount: Int!
  tableOpCount: Int!
  vectorCount: Int!
  languages: [String!]!
  lastIngestedAt: String
}

type SharedArtifactResult {
  artifactName: String!
  artifactType: ArtifactType!
  repos: [ArtifactRepoEntry!]!
  crossRepoEdges: [CrossRepoLink!]!
}

type ArtifactRepoEntry {
  repoId: String!
  operation: String!
  files: [ArtifactFileRef!]!
}

type ArtifactFileRef {
  fileId: String!
  lineNumber: Int
}

type CrossRepoLink {
  writerRepo: String!
  readerRepo: String!
  edgeType: String!
  fileCount: Int!
  totalWeight: Float!
}

type ArtifactSummaryResult {
  artifacts: [ArtifactEntry!]!
  totalArtifacts: Int!
  totalCrossRepoLinks: Int!
}

type ArtifactEntry {
  artifactName: String!
  artifactType: ArtifactType!
  repoCount: Int!
  totalReadOps: Int!
  totalWriteOps: Int!
  repos: [String!]!
}

type CrossRepoEdgeResult {
  outbound: [CrossRepoConnection!]!
  inbound: [CrossRepoConnection!]!
  connectedRepos: Int!
}

type CrossRepoConnection {
  repo: String!
  edgeType: String!
  artifacts: [ArtifactRef!]!
  totalWeight: Float!
}

type ArtifactRef {
  artifactName: String!
  artifactType: ArtifactType!
  operation: String!
}

type CrossRepoImpactResult {
  directlyAffected: [ImpactedRepo!]!
  transitivelyAffected: [TransitiveImpact!]!
  directRepoCount: Int!
  directFileCount: Int!
}

type ImpactedRepo {
  repoId: String!
  files: [ImpactedFile!]!
}

type ImpactedFile {
  fileId: String!
  operation: String!
  lineNumber: Int
  functions: [String!]!
}

type TransitiveImpact {
  repoId: String!
  distance: Int!
  impactVia: String!
}

type ServiceMapResult {
  serviceName: String!
  implementedBy: [ServiceImplementor!]!
  calledBy: [ServiceCaller!]!
  callsOut: [ServiceDependency!]!
  tables: [ServiceTableOp!]!
  callerRepoCount: Int!
  totalComplexity: Int!
}

type ServiceImplementor {
  repoId: String!
  fileId: String!
  entryPoints: [EntryPointInfo!]!
}

type EntryPointInfo {
  functionName: String!
  complexity: Int!
}

type ServiceCaller {
  repoId: String!
  fileId: String!
  callerFunction: String!
}

type ServiceDependency {
  targetService: String!
  targetRepo: String
  callCount: Int!
}

type ServiceTableOp {
  tableName: String!
  operation: String!
  fileId: String!
}

# ─── Data Lineage (traces data through the system) ──────────

type DataLineage {
  tableName: String!
  writers: [FileFact!]!
  readers: [FileFact!]!
  dataFlowEdges: [Edge!]!               # WRITE_READ edges involving this table
  transformationChain: [ExecutionPath!]! # paths from write → read → write → ...
}

# ─── Views (materialized on demand) ─────────────────────────

type DatabaseLineageView {
  tables: [TableLineage!]!
  totalTables: Int!
  totalDataFlowEdges: Int!
}

type TableLineage {
  tableName: String!
  writers: [FileFact!]!
  readers: [FileFact!]!
  columns: [ColumnInfo!]!
}

type SystemMapView {
  totalFiles: Int!
  totalFunctions: Int!
  totalEdges: Int!
  totalTables: Int!
  clusters: [Cluster!]!
  languages: [LanguageStat!]!
  entryPoints: [FunctionFact!]!
}

type SecurityView {
  authFiles: [FileFact!]!
  cryptoFiles: [FileFact!]!
  inputValidationFiles: [FileFact!]!
  securityEdges: [Edge!]!
}

type ApiContractView {
  endpoints: [FunctionFact!]!            # entry points
  contracts: [ApiContract!]!
}

type ApiContract {
  entryPoint: FunctionFact!
  tablesRead: [String!]!
  tablesWritten: [String!]!
  downstreamCalls: [FunctionCall!]!
  complexity: Int!
}
```

---

## Resolver Pipeline — How One Query Touches Three Backends

The power of GraphQL is in **resolvers**. Each field in the schema has a resolver that knows which backend to call. GraphQL composes them automatically.

```python
# Example: resolving FileFact.impactRadius
# This single field triggers: graph traversal → structured DB enrichment → cluster lookup

class FileFactResolvers:

    @staticmethod
    def resolve_impact_radius(file_fact, info, hops=2, min_weight=2.0):
        """
        1. Graph: traverse outward from this file, bounded by hops + weight
        2. Structured: batch-load file facts for all reached nodes
        3. Structured: find affected clusters and capabilities
        All in one resolver call. DataLoader batches the DB calls.
        """
        # Step 1: Graph traversal (single query, returns node IDs + paths)
        reached = info.context.graph.traverse_outward(
            start=file_fact.file_id,
            max_hops=hops,
            min_weight=min_weight
        )
        # Returns: [(file_id, distance, path_edges, path_weight), ...]

        # Step 2: Batch load all reached files (DataLoader: 1 SQL query, not N)
        file_ids = [r.file_id for r in reached]
        files = info.context.loaders.file_facts.load_many(file_ids)

        # Step 3: Clusters and capabilities (from already-loaded file facts)
        cluster_ids = {f.cluster_id for f in files if f.cluster_id}
        clusters = info.context.loaders.clusters.load_many(cluster_ids)
        cap_ids = set()
        for c in clusters:
            cap_ids.update(c.capability_ids)
        capabilities = info.context.loaders.capabilities.load_many(cap_ids)

        return ImpactReport(
            source_file=file_fact,
            direct_impact=[...],       # hops == 1
            transitive_impact=[...],   # hops > 1
            clusters_affected=clusters,
            capabilities_affected=capabilities,
            tables_affected=...,       # aggregated from reached files
        )
```

### DataLoaders — Solving the N+1 Problem

```python
class FactDataLoaders:
    """
    DataLoaders batch and cache backend calls within a single request.
    
    Without DataLoader:
      GraphQL resolves 31 files → 31 separate SQL queries (N+1 problem)
    
    With DataLoader:
      GraphQL resolves 31 files → DataLoader batches → 1 SQL query:
      SELECT * FROM file_facts WHERE id IN (... 31 IDs ...)
    """

    def __init__(self, structured_db, vector_db, graph_db):
        self.file_facts = DataLoader(
            batch_fn=lambda ids: structured_db.batch_get_files(ids)
        )
        self.function_facts = DataLoader(
            batch_fn=lambda ids: structured_db.batch_get_functions(ids)
        )
        self.clusters = DataLoader(
            batch_fn=lambda ids: structured_db.batch_get_clusters(ids)
        )
        self.capabilities = DataLoader(
            batch_fn=lambda ids: structured_db.batch_get_capabilities(ids)
        )
        self.file_tables = DataLoader(
            batch_fn=lambda file_ids: structured_db.batch_get_file_tables(file_ids)
        )
        self.file_edges_out = DataLoader(
            batch_fn=lambda file_ids: graph_db.batch_get_outbound_edges(file_ids)
        )
        self.file_edges_in = DataLoader(
            batch_fn=lambda file_ids: graph_db.batch_get_inbound_edges(file_ids)
        )
        self.similar_files = DataLoader(
            batch_fn=lambda specs: vector_db.batch_similar(specs)
        )
```

### Filter Pushdown — Don't Fetch What You'll Throw Away

```python
# BAD: fetch all files, then filter in Python
files = structured_db.get_all_files(repo_id="billing")  # 20K files loaded
result = [f for f in files if f.complexity_max > 10]     # throw away 19K

# GOOD: push filter to SQL
files = structured_db.query("""
    SELECT * FROM file_facts 
    WHERE repo_id = :repo AND is_current = true AND complexity_max > :min
""", repo="billing", min=10)  # DB returns only matching rows

# GraphQL enables this: the query AST tells the resolver WHAT fields
# the client asked for, so the resolver can build a targeted SQL query.
```

---

## How MCP Tools Use the GraphQL Engine

MCP tools become **thin translators** from natural language intent to GraphQL queries.

```python
# MCP Tool: fact_impact
class FactImpactTool:
    """MCP tool that translates impact analysis request to GraphQL."""
    
    GRAPHQL_QUERY = """
    query Impact($fileId: String!, $hops: Int!, $minWeight: Float!) {
      impact(fileId: $fileId, hops: $hops, minWeight: $minWeight) {
        sourceFile { fileId language complexityMax }
        totalFilesImpacted
        directImpact {
          file { fileId language }
          distance
          impactType
          path { edgeType weight artifact }
        }
        clustersAffected { clusterId clusterName fileCount }
        capabilitiesAffected { capabilityName }
        tablesAffected
      }
    }
    """

    async def run(self, file_id: str, hops: int = 2, min_weight: float = 2.0):
        result = await self.graphql_client.execute(
            self.GRAPHQL_QUERY,
            variables={"fileId": file_id, "hops": hops, "minWeight": min_weight}
        )
        return self.format_for_agent(result)


# MCP Tool: fact_search (semantic)
class FactSearchTool:
    """MCP tool for semantic search across the fact store."""

    GRAPHQL_QUERY = """
    query Search($query: String!, $repoId: String, $layer: Int, $topK: Int!) {
      search(query: $query, repoId: $repoId, layer: $layer, topK: $topK) {
        score
        layer
        item {
          ... on FileFact { fileId language complexityMax tables { tableName operation } }
          ... on FunctionFact { functionName fileId complexity }
          ... on Cluster { clusterId clusterName fileCount }
        }
      }
    }
    """


# MCP Tool: fact_explain_file (LLM-enhanced)
class FactExplainFileTool:
    """MCP tool that retrieves facts then asks LLM to explain."""

    FACTS_QUERY = """
    query FileFacts($fileId: String!) {
      file(fileId: $fileId) {
        fileId language executionModel complexityMax
        tables { tableName operation }
        functions { functionName complexity isEntryPoint calls { callee callType } }
        entryPoints { description }
        externalCalls { target protocol }
        dependsOn { target { fileId } edgeType weight artifact }
        cluster { clusterName }
        capabilities { capabilityName }
      }
    }
    """

    async def run(self, file_id: str):
        # Step 1: Get structured facts via GraphQL (fast, deterministic)
        facts = await self.graphql_client.execute(
            self.FACTS_QUERY, variables={"fileId": file_id}
        )
        # Step 2: LLM synthesizes explanation from facts (expensive, optional)
        explanation = await self.llm.explain(facts)
        return explanation
```

---

## The Composition Advantage

An agent wants: "Show me the billing capability — what files are in it, what tables they touch, what's the impact if we change the fee calculator, and find any files similar to it in the payments repo."

**Without GraphQL (6 MCP tool calls):**
```
1. fact_explain_capability("billing")           → structured
2. fact_find_files(cluster_id="billing_core")   → structured
3. fact_find_tables(files=[...])                → structured
4. fact_impact(file="fee_calculator.c")         → graph + structured
5. fact_find_similar("fee_calculator.c")        → vector + structured
6. fact_find_files(repo="payments", similar_to=...) → vector + structured

6 round trips. Agent orchestrates. Redundant data fetched.
```

**With GraphQL (1 query):**
```graphql
{
  capability(capabilityId: "billing") {
    capabilityName
    clusters {
      clusterName
      files(limit: 100) {
        fileId language complexityMax
        tables { tableName operation }
      }
    }
  }
  
  impact(fileId: "fee_calculator.c", hops: 2) {
    totalFilesImpacted
    directImpact { file { fileId } impactType }
    capabilitiesAffected { capabilityName }
    tablesAffected
  }
  
  search(query: "fee calculation", repoId: "payments", topK: 5) {
    score
    item { ... on FileFact { fileId language tables { tableName } } }
  }
}
```

**1 HTTP request. Engine composes across all three backends. DataLoaders batch. No redundant fetches. Response shaped exactly to what the agent needs.**

---

## Deployment Stack

### Single-Developer
```
Python process:
  ├── Strawberry/Ariadne GraphQL server (in-process, no HTTP needed)
  ├── SQLite (structured facts)
  ├── ChromaDB (vector index)
  └── SQLite (topology edges — same DB file)

MCP tools call GraphQL in-process. Zero network overhead.
```

### Team / Enterprise
```
GraphQL Service (FastAPI + Strawberry):
  ├── Connection pool → PostgreSQL (structured facts)
  ├── Qdrant client → Qdrant (vector index)
  ├── Neo4j driver → Neo4j (topology, or PostgreSQL with recursive CTEs)
  └── Redis (DataLoader cache, view cache)

MCP Server → GraphQL over HTTP (localhost or internal network)
```

### Horizontal Scaling
```
GraphQL is stateless — scale horizontally behind a load balancer.
Backends scale independently:
  PostgreSQL: read replicas for query load, partitioned by tenant
  Qdrant: sharded by cluster_id, replicated for availability
  Neo4j: read replicas, or causal cluster for HA
  Redis: clustered for cache distribution

Each GraphQL instance holds no state — just connection pools + DataLoader caches
(per-request lifetime, not global).
```

---

## The Stack Summary

```
┌─────────────────────────────────────────────────────┐
│  Agents / IDE / CI/CD / UI                           │
│  (consumers — they call MCP tools)                   │
└──────────────────────┬──────────────────────────────┘
                       │ MCP protocol
┌──────────────────────▼──────────────────────────────┐
│  MCP Tool Layer                                      │
│  Thin tools: translate intent → GraphQL queries      │
│  ~30 tools, each is ~20 lines of code               │
└──────────────────────┬──────────────────────────────┘
                       │ GraphQL over HTTP (or in-process)
┌──────────────────────▼──────────────────────────────┐
│  FACT Query Engine (GraphQL Service)                 │
│  Schema + Resolvers + DataLoaders + Filter Pushdown  │
│  The brain. Composes cross-backend queries.          │
│  Stateless. Horizontally scalable.                   │
└───┬──────────────────┬──────────────────┬───────────┘
    │                  │                  │
    ▼                  ▼                  ▼
Structured DB      Vector Index      Graph Store
(PostgreSQL/       (Qdrant/          (Neo4j/
 SQLite)           ChromaDB)         pg recursive)
80% queries        20% queries       traversal
```

**Each layer does what it's best at:**
- MCP tools: understand agent intent, format responses
- GraphQL: compose queries, batch backends, shape results
- Structured DB: fast indexed lookups, aggregations, joins
- Vector DB: semantic similarity, ANN search
- Graph: path traversal, impact analysis, dependency trees
