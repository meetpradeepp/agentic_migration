# Vector DB Design — Implementation Approach

## Current State (AMF Baseline)

AMF uses **ChromaDB 1.5.5** with **local embeddings** (all-MiniLM-L6-v2, 384-dim) via ONNX/OpenVINO. Three collection types exist:

| Collection | Stage | Content | Dimension |
|-----------|-------|---------|-----------|
| `amf_behavior_slices` | FPS | behavioral_signature per function | 384 |
| `amf_syntax_slices` | FPS | syntax_snippet per function | 384 |
| `amf_sol_knowledge` | SOL | UEG nodes, edges, claims, contracts, patterns | 384 |

Key AMF design choices to **preserve**:
- Local-first embedding (ONNX/OpenVINO, no internet dependency)
- Pre-computed embeddings passed to ChromaDB (not re-embedded on query)
- Metadata sidecar (`metadata_index.json`) for deterministic queries
- Lazy collection initialization (loaded on first query, not import)
- Air-gapped compliance (no HuggingFace downloads in production)

Key AMF limitations to **evolve**:
- 384-dim embeddings (architecture spec calls for 768-dim — requires model upgrade)
- Single-project scope (no multi-repo, no tenant isolation)
- Drop-and-recreate strategy (SOL rebuilds collection each run)
- No versioning (no `is_current`, no `commit_sha`, no historical retention)
- No model version tagging (cross-version queries unprotected)
- No garbage collection (collections grow unbounded)
- Function-level granularity only (ECLE needs file-level FSS embeddings)

---

## Target State (ECLE)

### Embedding Model Migration

| Property | AMF (Current) | ECLE (Target) | Migration Path |
|----------|--------------|---------------|----------------|
| Model | all-MiniLM-L6-v2 | To be selected (768-dim) | Phase 2 decision — see ADR below |
| Dimensions | 384 | 768 | New collection, not in-place migration |
| Backend | ONNX/OpenVINO local | ONNX/OpenVINO local (preserved) | No change to inference infra |
| Granularity | Function-level (behavioral + syntax) | File-level (FSS summary text) | New collection schema |
| Source text | `behavioral_signature`, `syntax_snippet` | FSS summary text (Tier 1/2) or fingerprint text (Tier 3) | New embedding pipeline |

**Open Decision — ADR Required (Phase 2):** Which 768-dim model?

Candidates:
- `all-MiniLM-L12-v2` (384-dim, well-tested in AMF — may keep 384 and update spec)
- `all-mpnet-base-v2` (768-dim, higher quality, 2x memory)
- `BAAI/bge-base-en-v1.5` (768-dim, strong code/text retrieval)
- `nomic-embed-text-v1.5` (768-dim, long context, Matryoshka dimensionality reduction)

**Decision criteria:**
1. Local ONNX/OpenVINO exportable (mandatory — air-gapped)
2. Code + natural language dual competence (FSS text is hybrid)
3. Memory footprint per million points (production constraint)
4. If 384-dim achieves sufficient silhouette scores on cluster validation, prefer 384 (halves RAM)

**Resolution:** Benchmark during Phase 2 cluster discovery implementation. Measure silhouette scores at 384 vs 768 on a reference repo. The spec says 768 but the right answer is empirical.

---

## Collection Architecture

### 5 Collection Types (progressive rollout)

```
Phase 1-2:
  {tenant}__{repo}__fss           # File-level FSS embeddings (the workhorse)

Phase 3-4:
  {tenant}__cross_repo__capabilities   # Capability centroids (cross-repo)

Phase 5-6:
  {tenant}__{repo}__sol               # SOL: UEG nodes, contracts, patterns (replaces amf_sol_knowledge)
  {tenant}__capabilities__{cap}__sol  # Federated SOL per capability

Preserved (backward compat):
  amf_behavior_slices                  # Legacy FPS behavioral (single-dev mode only)
  amf_syntax_slices                    # Legacy FPS syntactic (single-dev mode only)
```

### The Primary Collection: `{tenant}__{repo}__fss`

This is the core collection. Everything else is derived from or secondary to it.

```
Point Schema:
  id:         deterministic UUID = SHA256(file_id + commit_sha + model_version)
  vector:     float[768] (or 384 — pending ADR)
  payload:
    file_id:        string
    commit_sha:     string
    repo_id:        string
    branch:         string
    cluster_id:     string
    analysis_tier:  1 | 2 | 3
    model_version:  string
    fingerprint:    string (behavioral fingerprint hash)
    fidelity:       FULL | PARTIAL | HEURISTIC
    is_current:     bool
    onboard_run_id: string | null
    created_at:     ISO8601
    superseded_at:  ISO8601 | null

Payload Indexes:
    repo_id       → keyword    (tenant scoping)
    cluster_id    → keyword    (intra-cluster queries, drift detection)
    branch        → keyword    (branch-scoped queries)
    model_version → keyword    (cross-version guard)
    is_current    → bool       (active vs historical)
    analysis_tier → integer    (tier-filtered queries)
    fidelity      → keyword    (quality-filtered queries)

Distance Metric: cosine
```

---

## Implementation Approach — Phase by Phase

### Phase 1: Foundation (Weeks 1-4)

**Goal:** Abstract vector DB behind an interface. Keep AMF working. No new collections yet.

```python
# src/vector/interface.py

class IVectorStore(ABC):
    """Abstraction over ChromaDB (local) and Qdrant (enterprise)."""

    @abstractmethod
    def get_or_create_collection(self, name: str, vector_size: int,
                                  distance_metric: str = "cosine") -> Collection: ...

    @abstractmethod
    def upsert(self, collection: str, points: list[VectorPoint]) -> None: ...

    @abstractmethod
    def query(self, collection: str, vector: list[float], top_k: int,
              filters: dict | None = None) -> list[QueryResult]: ...

    @abstractmethod
    def set_payload(self, collection: str, point_id: str,
                    payload: dict) -> None: ...

    @abstractmethod
    def delete(self, collection: str, point_ids: list[str]) -> None: ...

    @abstractmethod
    def get_vector(self, collection: str, point_id: str) -> list[float] | None: ...

    @abstractmethod
    def count(self, collection: str, filters: dict | None = None) -> int: ...
```

```python
# src/vector/models.py

@dataclass(frozen=True)
class VectorPoint:
    id: str                    # deterministic UUID
    vector: list[float]        # embedding
    payload: dict[str, Any]    # metadata

@dataclass(frozen=True)
class QueryResult:
    id: str
    score: float               # similarity score
    payload: dict[str, Any]
    # NEVER: edge data, relationship claims, capability assignments
    # ALWAYS: node_id, commit_sha, similarity_score, model_version
```

```python
# src/vector/chromadb_store.py — wraps current AMF ChromaDB usage

class ChromaDBStore(IVectorStore):
    """Local ChromaDB for single-developer mode. Backward compatible with AMF."""

    def __init__(self, persist_dir: str):
        self._client = chromadb.PersistentClient(path=persist_dir)
        self._embedding_fn = LocalEmbeddingFunction()  # AMF's ONNX/OpenVINO
```

**Deliverables:**
- `IVectorStore` interface
- `ChromaDBStore` implementation wrapping AMF's existing ChromaDB
- `VectorPoint` and `QueryResult` models
- Existing AMF vector_loader.py and sol_indexer.py continue to work unchanged
- Unit tests for interface compliance

**What does NOT change:** AMF's `amf_behavior_slices`, `amf_syntax_slices`, `amf_sol_knowledge` collections, `models/embeddings.py`, all MCP tools.

---

### Phase 2: Knowledge Graph (Weeks 5-10)

**Goal:** Create the FSS collection. Embed file-level FSS summaries. Use for cluster validation.

**Step 2a — Embedding Model Decision (Week 5)**

Run the embedding model benchmark:
```python
# benchmarks/bench_embedding_model.py

def benchmark_embedding_models():
    """
    For each candidate model:
    1. Embed FSS summaries from a reference repo (1K files)
    2. Run Louvain clustering on structural graph
    3. Compute silhouette score using embeddings within each cluster
    4. Measure: embedding time, RAM per 100K points, silhouette score
    """
    models = [
        ("all-MiniLM-L6-v2", 384),
        ("all-mpnet-base-v2", 768),
        ("bge-base-en-v1.5", 768),
    ]
    # ... benchmark each, produce ADR with results
```

Output: ADR-002 in `constitution/decisions/` with benchmark data and model choice.

**Step 2b — FSS Collection Creation (Weeks 6-7)**

```python
# src/vector/fss_collection.py

class FSSVectorManager:
    """Manages the {tenant}__{repo}__fss collection lifecycle."""

    def __init__(self, store: IVectorStore, tenant_id: str, repo_id: str,
                 model_version: str, vector_size: int):
        self._store = store
        self._collection_name = f"{tenant_id}__{repo_id}__fss"
        self._model_version = model_version
        self._vector_size = vector_size

    def embed_fss(self, file_id: str, commit_sha: str, fss_text: str,
                  cluster_id: str, branch: str, tier: int,
                  fidelity: str, fingerprint: str) -> VectorPoint:
        """Embed an FSS summary and return the point (not yet inserted)."""
        embedding = self._embedding_model.encode(fss_text)
        point_id = deterministic_uuid(file_id, commit_sha, self._model_version)

        return VectorPoint(
            id=point_id,
            vector=embedding,
            payload={
                "file_id": file_id,
                "commit_sha": commit_sha,
                "repo_id": self._repo_id,
                "branch": branch,
                "cluster_id": cluster_id,
                "analysis_tier": tier,
                "model_version": self._model_version,
                "fingerprint": fingerprint,
                "fidelity": fidelity,
                "is_current": True,
                "onboard_run_id": None,
                "created_at": now_iso(),
                "superseded_at": None,
            },
        )

    def embed_tier3_heuristic(self, file_id: str, commit_sha: str,
                               cim: CIM, cluster_id: str, branch: str) -> VectorPoint:
        """Embed a Tier 3 file from CIM structural facts (zero-LLM)."""
        fingerprint_text = " ".join([
            "functions: " + ", ".join(sorted(cim.function_names)),
            "calls: " + ", ".join(sorted(cim.called_functions)),
            "reads: " + ", ".join(sorted(cim.read_tables)),
            "writes: " + ", ".join(sorted(cim.written_tables)),
            "imports: " + ", ".join(sorted(cim.imported_modules)),
        ])
        embedding = self._embedding_model.encode(fingerprint_text)
        # ... same point creation with fidelity="HEURISTIC", tier=3
```

**Step 2c — Cluster Centroid Manager (Weeks 8-9)**

```python
# src/clustering/centroid.py

@dataclass
class ClusterCentroidState:
    cluster_id: str
    centroid: np.ndarray        # float[vector_size]
    cluster_size: int
    incremental_count: int
    last_full_recalc: str       # ISO8601
    drift_accumulator: float
    model_version: str

class CentroidManager:
    """O(1) incremental centroid updates with periodic full recalculation."""

    FULL_RECALC_INTERVAL = 100          # updates before forced recalc
    DRIFT_THRESHOLD = 0.1               # accumulated delta before forced recalc
    MODEL_SWITCH_THRESHOLD = 0.8        # % files re-embedded before centroid switches

    def update_incrementally(self, cluster_id: str,
                              old_embedding: np.ndarray,
                              new_embedding: np.ndarray) -> None:
        state = self._get_state(cluster_id)

        # Guard: model version mismatch
        if state.model_version != self._current_model_version:
            self._trigger_full_recalc(cluster_id)
            return

        # O(1) update — no DB reads
        delta = (new_embedding - old_embedding) / state.cluster_size
        state.centroid += delta
        state.drift_accumulator += float(np.sum(np.abs(delta)))
        state.incremental_count += 1

        if (state.incremental_count >= self.FULL_RECALC_INTERVAL
                or state.drift_accumulator > self.DRIFT_THRESHOLD):
            self._trigger_full_recalc(cluster_id)
        else:
            self._store_state(state)

    def add_file(self, cluster_id: str, embedding: np.ndarray) -> None:
        state = self._get_state(cluster_id)
        n = state.cluster_size
        state.centroid = (state.centroid * n + embedding) / (n + 1)
        state.cluster_size = n + 1
        state.incremental_count += 1
        self._store_state(state)

    def remove_file(self, cluster_id: str, embedding: np.ndarray) -> None:
        state = self._get_state(cluster_id)
        n = state.cluster_size
        if n <= 1:
            return  # cluster dissolving — handled by mutation event
        state.centroid = (state.centroid * n - embedding) / (n - 1)
        state.cluster_size = n - 1
        state.incremental_count += 1
        self._store_state(state)
```

**Step 2d — Semantic Validation for Clustering (Week 10)**

```python
# src/clustering/semantic_validation.py

class SemanticClusterValidator:
    """Uses vector DB to validate structural clusters with semantic signals."""

    def compute_silhouette_scores(self, clusters: dict[str, list[str]]) -> dict[str, float]:
        """Per-cluster silhouette score using FSS embeddings."""
        # For each file: intra-cluster distance vs nearest-cluster distance
        # Score > 0.65 = good cluster; < 0.4 = flagged for review
        ...

    def detect_drift(self, file_id: str, cluster_id: str) -> float:
        """Cosine distance from file's embedding to cluster centroid."""
        file_embedding = self._store.get_vector(self._collection, file_id_point)
        centroid = self._centroid_manager.get_centroid(cluster_id)
        return 1.0 - cosine_similarity(file_embedding, centroid)
```

---

### Phase 3: Continuous Mode (Weeks 11-16)

**Goal:** Incremental vector operations on every commit. Version tracking.

**Step 3a — Versioned Upsert (supersede old, insert new)**

```python
# src/vector/versioned_ops.py

class VersionedVectorOps:
    """Handles the supersede-and-insert pattern for continuous updates."""

    def upsert_new_version(self, file_id: str, commit_sha: str,
                            branch: str, new_fss: FSS, cluster_id: str) -> None:
        """
        1. Mark old version as superseded (is_current=False, superseded_at=now)
        2. Insert new version (is_current=True)
        3. Update cluster centroid incrementally
        """
        # Step 1: Find and supersede old point
        old_points = self._store.query(
            self._collection,
            filters={"file_id": file_id, "branch": branch, "is_current": True},
            # query with zero vector — we want filter match, not similarity
        )
        if old_points:
            old_point = old_points[0]
            self._store.set_payload(self._collection, old_point.id, {
                "is_current": False,
                "superseded_at": now_iso(),
            })
            old_embedding = self._store.get_vector(self._collection, old_point.id)

        # Step 2: Embed and insert new version
        new_point = self._fss_manager.embed_fss(
            file_id, commit_sha, new_fss.summary_text,
            cluster_id, branch, new_fss.tier, new_fss.fidelity, new_fss.fingerprint,
        )
        self._store.upsert(self._collection, [new_point])

        # Step 3: Centroid update
        if old_points:
            self._centroid_manager.update_incrementally(
                cluster_id, np.array(old_embedding), np.array(new_point.vector))
        else:
            self._centroid_manager.add_file(cluster_id, np.array(new_point.vector))
```

**Step 3b — Model Version Guard**

```python
# src/vector/model_guard.py

class ModelVersionGuard:
    """Prevents cross-version similarity comparisons (type error)."""

    def validate_query(self, query_model_version: str,
                       collection_model_versions: set[str]) -> None:
        if query_model_version not in collection_model_versions:
            raise ModelVersionMismatchError(
                f"Query model {query_model_version} not in collection "
                f"versions {collection_model_versions}. "
                f"Cross-version cosine similarity is meaningless."
            )

    def validate_centroid_update(self, file_model: str,
                                  centroid_model: str) -> bool:
        if file_model != centroid_model:
            # Cannot update centroid — trigger full recalc after migration
            return False
        return True
```

---

### Phase 4: Enterprise Scale (Weeks 17-24)

**Goal:** Qdrant backend, bulk onboarding, capability collection, sharding.

**Step 4a — Qdrant Backend**

```python
# src/vector/qdrant_store.py

class QdrantStore(IVectorStore):
    """Qdrant backend for enterprise deployment."""

    def __init__(self, url: str, api_key: str | None = None,
                 grpc_port: int = 6334):
        from qdrant_client import QdrantClient
        self._client = QdrantClient(url=url, api_key=api_key,
                                     grpc_port=grpc_port, prefer_grpc=True)

    def get_or_create_collection(self, name: str, vector_size: int,
                                  distance_metric: str = "cosine") -> str:
        from qdrant_client.models import Distance, VectorParams
        distance = Distance.COSINE if distance_metric == "cosine" else Distance.EUCLID

        if not self._client.collection_exists(name):
            self._client.create_collection(
                collection_name=name,
                vectors_config=VectorParams(size=vector_size, distance=distance),
                # Optimized for write-heavy onboarding then read-heavy queries
                optimizers_config={"indexing_threshold": 20000},  # defer HNSW until 20K points
            )
        return name
```

**Step 4b — Bulk Onboarding Loader**

```python
# src/vector/bulk_loader.py

class BulkVectorLoader:
    """High-throughput vector loading for onboarding Phase 5."""

    BATCH_SIZE = 500          # points per upsert batch
    DEFERRED_INDEX_THRESHOLD = 10000  # disable HNSW during bulk insert above this

    def bulk_load(self, repo_id: str, onboard_run_id: str,
                  embeddings: list[VectorPoint],
                  progress_callback: Callable | None = None) -> BulkLoadResult:
        """
        Load all embeddings for a repo during onboarding.

        Strategy:
        1. If > DEFERRED_INDEX_THRESHOLD points: disable HNSW indexing
        2. Batch upsert in chunks of BATCH_SIZE
        3. Re-enable HNSW and build index
        4. Compute cluster centroids from loaded embeddings
        """
        collection = self._store.get_or_create_collection(
            self._collection_name, self._vector_size)

        # Defer HNSW for large repos (Qdrant-specific optimization)
        if len(embeddings) > self.DEFERRED_INDEX_THRESHOLD:
            self._store.set_indexing_threshold(collection, threshold=0)

        loaded = 0
        for batch in chunks(embeddings, self.BATCH_SIZE):
            self._store.upsert(collection, batch)
            loaded += len(batch)
            if progress_callback:
                progress_callback(loaded, len(embeddings))

        # Re-enable and build HNSW index
        if len(embeddings) > self.DEFERRED_INDEX_THRESHOLD:
            self._store.set_indexing_threshold(collection, threshold=20000)

        # Compute all cluster centroids from loaded embeddings
        self._compute_initial_centroids(embeddings)

        return BulkLoadResult(
            points_loaded=loaded,
            collection=self._collection_name,
            deferred_indexing_used=len(embeddings) > self.DEFERRED_INDEX_THRESHOLD,
        )
```

**Step 4c — Capability Collection**

```python
# src/vector/capability_collection.py

class CapabilityVectorManager:
    """Manages {tenant}__cross_repo__capabilities collection."""

    def upsert_capability(self, capability_id: str, capability_name: str,
                           constituent_clusters: list[str],
                           constituent_repos: list[str]) -> None:
        """
        Capability centroid = mean of constituent cluster centroids.
        """
        cluster_centroids = [
            self._centroid_manager.get_centroid(cid)
            for cid in constituent_clusters
        ]
        capability_centroid = np.mean(cluster_centroids, axis=0)

        point = VectorPoint(
            id=deterministic_uuid(capability_id, self._model_version),
            vector=capability_centroid.tolist(),
            payload={
                "capability_id": capability_id,
                "capability_name": capability_name,
                "constituent_repos": constituent_repos,
                "constituent_clusters": constituent_clusters,
                "model_version": self._model_version,
                "staleness_score": 0.0,
                "last_synthesized_at": now_iso(),
            },
        )
        self._store.upsert(self._cross_repo_collection, [point])
```

**Step 4d — Sharding Strategy (> 1M points)**

```python
# src/vector/sharding.py

class ShardedVectorStore(IVectorStore):
    """
    Routes queries to the correct shard based on cluster_id.
    Activated when a collection exceeds 1M current points (~50 GB RAM).

    Sharding scheme:
      shard_key = hash(cluster_id) % num_shards
      collection_name = f"{base_name}__shard_{shard_key}"

    Cross-shard queries (rare: capability discovery only):
      Fan out to all shards, merge results by score, deduplicate.
    """

    SHARD_THRESHOLD = 1_000_000  # current points before sharding activates

    def should_shard(self, collection: str) -> bool:
        current_count = self._store.count(collection, {"is_current": True})
        return current_count > self.SHARD_THRESHOLD
```

---

### Phase 5: Learning Loop + Hardening (Weeks 25-32)

**Goal:** Garbage collection, model migration, embedding quality monitoring.

**Step 5a — Garbage Collection**

```python
# src/vector/garbage_collection.py

class VectorGarbageCollector:
    """Weekly GC: remove old historical embeddings from vector DB."""

    RETAIN_LAST_N = 5                   # versions per file per branch
    MAX_AGE_DAYS = 90                   # delete older than this
    DELETE_BATCH_SIZE = 1000            # points per deletion batch

    def run_gc(self, collection: str, dry_run: bool = True) -> GCResult:
        """
        1. Query: is_current=false AND superseded_at < (now - 90 days)
        2. Exclude: points whose commit_sha matches a release tag
        3. Ensure: at least 1 historical version per file retained
        4. Delete in batches of 1000
        5. Log every deletion for audit
        """
        candidates = self._find_gc_candidates(collection)
        protected = self._find_release_tagged(collection)
        to_delete = [c for c in candidates
                     if c.id not in protected
                     and self._has_newer_retained(c)]

        if dry_run:
            return GCResult(would_delete=len(to_delete), deleted=0, dry_run=True)

        deleted = 0
        for batch in chunks(to_delete, self.DELETE_BATCH_SIZE):
            self._store.delete(collection, [p.id for p in batch])
            self._audit_log(batch, reason="gc_aged_out")
            deleted += len(batch)

        return GCResult(would_delete=len(to_delete), deleted=deleted, dry_run=False)
```

**Step 5b — Embedding Model Migration**

```python
# src/vector/model_migration.py

class EmbeddingModelMigration:
    """
    Manages transition between embedding model versions.

    Three concurrent states during migration:
    1. Files re-embedded with new model → new embedding space
    2. Files not yet re-embedded → old embedding space, marked pending
    3. Cluster centroids → switch to new model at >80% re-embedded

    CRITICAL: cross-version cosine similarity is never computed.
    """

    MODEL_SWITCH_THRESHOLD = 0.8   # 80% files re-embedded before centroid switches

    def start_migration(self, collection: str,
                         old_version: str, new_version: str,
                         priority_order: list[str]) -> MigrationJob:
        """
        Begin background re-embedding in priority order:
        1. Tier 1 files (highest business value)
        2. Tier 2 files
        3. Tier 3 files (lowest priority)

        No LLM needed — FSS text is unchanged, only re-embed.
        """
        ...

    def check_cluster_readiness(self, cluster_id: str,
                                  new_version: str) -> bool:
        """True if >80% of cluster's files are re-embedded with new version."""
        total = self._store.count(self._collection,
                                   {"cluster_id": cluster_id, "is_current": True})
        migrated = self._store.count(self._collection,
                                      {"cluster_id": cluster_id, "is_current": True,
                                       "model_version": new_version})
        return (migrated / total) >= self.MODEL_SWITCH_THRESHOLD if total > 0 else False
```

---

## The Inviolable Contract

```
VECTOR DB QUERY CONTRACT:
  ALWAYS returns: (node_id, commit_sha, similarity_score, model_version)
  NEVER returns:  edge data, relationship claims, capability assignments
  CALLER MUST:    resolve node_id through graph DB to get relationships
  FORBIDDEN:      inferring that two similar nodes are related
                  (similarity ≠ structural connection)
  model_version mismatch: query REJECTED — caller must specify compatible version
```

**Why this contract matters:** The vector DB is a **discovery index** (find candidates) not a **truth store** (confirm relationships). A function semantically similar to another is NOT necessarily called by it, NOT in the same cluster, NOT part of the same capability. The vector DB surfaces candidates. The graph DB confirms or denies. They are not interchangeable. Violating this contract causes false capability assignments and phantom architectural relationships.

---

## Query Pattern Catalog

| Query | Collection | Filter | Latency Target | When |
|-------|-----------|--------|-----------------|------|
| Drift detection | `fss` | `cluster_id=X, is_current=true` | < 100ms | On file change |
| Semantic search (agent) | `fss` | `repo_id=X, is_current=true, model_version=V` | < 50ms | Agent query |
| Cluster validation | `fss` | `cluster_id=X, is_current=true` | seconds | Onboarding Phase 4 |
| Capability discovery | `cross_repo__capabilities` | `model_version=V` | < 200ms | Weekly batch |
| Nearest neighbors | `fss` | `repo_id=X, is_current=true, model_version=V` | seconds | Onboarding Phase 4 |

---

## Scaling Thresholds

| Trigger | Action |
|---------|--------|
| > 10K current points | Enable payload indexes (auto in Qdrant) |
| > 100K current points | Monitor HNSW build time, consider `on_disk=true` for Qdrant |
| > 1M current points | Shard by cluster_id prefix |
| > 50 GB RAM | Split into multiple Qdrant nodes or enable mmap |
| GC needed | Weekly: delete `is_current=false` older than 90 days (keep 5 per file) |
| Model migration | Background re-embed in tier order; centroid switches at 80% |

---

## Monitoring Metrics (Vector-Specific)

```yaml
vector_metrics:
  query_latency_p50_p99:     by collection, by query type
  upsert_latency_p50_p99:    by collection (should be < 10ms/point)
  collection_size:            current points, total points, RAM usage
  gc_points_deleted:          per run, cumulative
  gc_points_retained:         per run (must always be > 0 per file)
  model_migration_progress:   % files re-embedded per cluster
  centroid_accuracy:          incremental vs full recalc drift
  silhouette_score:           per cluster (target > 0.65)
  hnsw_build_time:            per collection (alert if > 5 min)

alert_rules:
  - query_latency_p99 > 100ms for fss collection: investigate HNSW health
  - collection_size > 80% of shard threshold: plan sharding
  - centroid_drift > 0.1 without full recalc: trigger immediate recalc
  - silhouette_score < 0.4 for any cluster: flag for review
```

---

## File Structure

```
src/vector/
├── __init__.py
├── interface.py               # IVectorStore ABC
├── models.py                  # VectorPoint, QueryResult, ClusterCentroidState
├── chromadb_store.py          # ChromaDB backend (single-dev, AMF backward compat)
├── qdrant_store.py            # Qdrant backend (enterprise)
├── fss_collection.py          # FSS embedding manager (embed, Tier 3 heuristic)
├── capability_collection.py   # Cross-repo capability centroid manager
├── sol_collection.py          # SOL vector collections (replaces amf_sol_knowledge)
├── versioned_ops.py           # Supersede-and-insert for continuous updates
├── bulk_loader.py             # High-throughput onboarding loader
├── garbage_collection.py      # Weekly GC with audit logging
├── model_guard.py             # Cross-version query prevention
├── model_migration.py         # Background re-embedding pipeline
├── sharding.py                # Cluster-based sharding at 1M+ points
├── deterministic_uuid.py      # SHA256(file_id + commit_sha + model_version) → UUID
└── config.py                  # All thresholds, batch sizes, intervals
```

---

## Backward Compatibility Bridge

```python
# src/vector/legacy_bridge.py

class LegacyVectorBridge:
    """
    Maintains backward compatibility with AMF's vector_loader.py and sol_indexer.py.

    In single-developer mode:
    - amf_behavior_slices and amf_syntax_slices continue to work unchanged
    - amf_sol_knowledge continues to work unchanged
    - New FSS collection coexists alongside legacy collections
    - MCP tools (find_semantic_duplicates, find_code_patterns, amf_query_sol)
      continue to query legacy collections

    Migration path:
    - Phase 1-2: legacy collections + new FSS collection coexist
    - Phase 3+: MCP tools query BOTH legacy and new collections, merge results
    - Phase 5+: legacy collections deprecated, new collection is primary
    - Phase 6: legacy collections removed from enterprise mode
              (preserved in single-dev mode for AMF compatibility)
    """
```
