# Coding Standards — Uniform Code Across All Agents

Every agent producing code MUST follow these standards. The Code Reviewer enforces them on every PR. No exceptions.

## Reference Implementation

The existing code in `src/ecle/` is the reference. When in doubt, match the style of:
- `src/ecle/backends/structured/schema.py` — schema definitions
- `src/ecle/backends/structured/sqlite.py` — backend class pattern
- `src/ecle/ingestion/facts_loader.py` — ingestion/business logic pattern
- `tests/unit/test_facts_loader.py` — test pattern

---

## File Structure

### Every Python file starts with

```python
"""
Module name — one-line description of what this module does.

Longer explanation if needed:
- What it handles
- What ADR(s) it implements
- What data it reads/writes
"""

from __future__ import annotations

# stdlib imports
# third-party imports
# ecle imports
```

- **`from __future__ import annotations`** on every file — enables `X | None` syntax on Python 3.11
- **Module docstring** is mandatory — one line minimum, references ADR if implementing a decision
- **Import order**: stdlib → third-party → ecle (enforced by `ruff` isort)

### File naming

```
src/ecle/{module}/{descriptive_name}.py    — snake_case, no abbreviations
tests/unit/test_{module_name}.py           — mirrors the src/ structure
tests/integration/test_{flow_name}.py      — named by what flow it tests
```

---

## Classes

### Pattern: One class per concern, constructor takes dependencies

```python
class TopologyBuilder:
    """Computes topology edges from structured facts using 9 signal detectors."""

    def __init__(self, db: SQLiteBackend, repo_id: str = "default"):
        self.db = db
        self.repo_id = repo_id

    def compute_edges(self, file_id: str) -> list[dict[str, Any]]:
        """Compute all outbound edges for a file from its facts."""
        ...
```

Rules:
- **Dependencies injected via constructor** — no global state, no module-level singletons
- **Class docstring** mandatory — one sentence describing the class's purpose
- **Public methods have docstrings** — describe what, not how
- **Private methods prefixed with `_`** — no docstring required if name is clear
- **No inheritance unless genuinely polymorphic** — prefer composition

### Pattern: Backend classes follow the interface

```python
class SQLiteBackend:
    """SQLite-based structured fact store."""

    def __init__(self, db_path: str | Path = "ecle.db"):
        ...

    def connect(self) -> None: ...
    def close(self) -> None: ...
    def insert(self, table: str, data: dict[str, Any]) -> None: ...
    def fetchall(self, sql: str, params: tuple | dict = ()) -> list[sqlite3.Row]: ...
```

When we add PostgreSQL, it implements the same method signatures. No ABC needed in MVP — just match the interface.

---

## Functions

### Type hints on everything public

```python
# YES — fully typed
def load_file(
    self,
    facts_path: Path,
    commit_sha: str = "import",
    branch: str = "main",
    source_path: str | None = None,
) -> dict[str, Any]:

# NO — untyped
def load_file(self, facts_path, commit_sha="import"):
```

### Return dicts for results, Pydantic models for data

```python
# Results (ad-hoc, vary per operation) — dict is fine
def load_file(...) -> dict[str, Any]:
    return {"file_id": file_id, "status": "new", "functions": 5}

# Structured data (shared, reused, validated) — will become Pydantic later
# For MVP, dicts with documented keys are acceptable
# When we add GraphQL, these become Strawberry types
```

### Private helpers prefixed with `_`, at module level for pure functions

```python
# Module-level pure helpers (no self, no state)
def _sha256(content: bytes) -> str:
    return hashlib.sha256(content).hexdigest()

def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()

def _classify_sql_category(category: str) -> str:
    """Normalize SQL category to READ or WRITE."""
    ...
```

Rules:
- **Pure functions that don't use `self`** → module-level, prefixed with `_`
- **Methods that use `self`** → on the class
- **No `@staticmethod`** — use module-level functions instead (clearer)

---

## SQL

### Parameterized queries only — NEVER string interpolation

```python
# YES — parameterized
self.conn.execute(
    "SELECT * FROM file_facts WHERE file_id = ? AND repo_id = ?",
    (file_id, repo_id),
)

# YES — named parameters for complex queries
self.conn.execute("""
    WITH RECURSIVE impact AS (
        SELECT target_file AS file_id, 1 AS hops
        FROM topology_edges
        WHERE source_file = :start AND is_valid = 1 AND weight >= :min_weight
        ...
    )
""", {"start": file_id, "min_weight": min_weight, "max_hops": max_hops})

# NEVER — string interpolation (SQL injection risk)
self.conn.execute(f"SELECT * FROM file_facts WHERE file_id = '{file_id}'")
```

### Table and column names from schema.py constants — not hardcoded strings

When queries reference table names, they should match `schema.py` exactly. If a table is renamed in schema.py, a text search for the old name should find all queries that need updating.

### Multi-line SQL for readability

```python
# YES — readable, aligned
return self.fetchall("""
    SELECT fn.*, fc.line as call_line, fc.call_type
    FROM function_facts fn
    JOIN function_calls fc ON fn.id = fc.caller_id
    WHERE fc.callee_name = ? AND fn.is_current = 1 AND fn.repo_id = ?
""", (callee_name, repo_id))

# NO — cramped single line
return self.fetchall("SELECT fn.*, fc.line as call_line, fc.call_type FROM function_facts fn JOIN function_calls fc ON fn.id = fc.caller_id WHERE fc.callee_name = ? AND fn.is_current = 1 AND fn.repo_id = ?", (callee_name, repo_id))
```

---

## Error Handling

### Typed exceptions per layer (define as needed, not upfront)

```python
# In each module, define exceptions when first needed:
class IngestionError(Exception):
    """Error during FACT ingestion."""

class SchemaError(Exception):
    """Error in DB schema or migration."""

# NOT: a big exceptions.py file with 50 exception classes defined upfront
```

### Fail fast at boundaries, handle gracefully inside

```python
# At system boundary (reading external files) — fail fast with context
try:
    facts_data = json.loads(raw_bytes)
except json.JSONDecodeError as e:
    raise IngestionError(f"Invalid JSON in {facts_path}: {e}") from e

# Inside processing (one bad function shouldn't kill the whole file)
for fn in functions:
    fn_name = fn.get("name", "")
    if not fn_name:
        continue  # skip unnamed functions, don't crash
```

### Never bare `except:` — always catch specific exceptions

```python
# YES
except (json.JSONDecodeError, OSError) as e:
    results["errors"] += 1

# NEVER
except:
    pass
```

---

## Tests

### Pattern: fixture → class → methods

```python
@pytest.fixture
def db(tmp_path):
    """Fresh SQLite DB for each test."""
    backend = SQLiteBackend(tmp_path / "test.db")
    backend.connect()
    yield backend
    backend.close()

@pytest.fixture
def loader(db):
    return FactsLoader(db, repo_id="test-repo")

class TestSingleFileLoad:
    """Test loading a single .facts.json file."""

    def test_load_batch_rating(self, loader, db):
        """batch_rating.ppc — Pro*C with SQL, functions, globals."""
        result = loader.load_file(FIXTURES / "batch_rating.ppc.facts.json")
        assert result["status"] == "new"
        assert result["functions"] > 0
```

Rules:
- **Fixtures** at top of file — `db`, `loader`, shared state
- **Test classes** group related tests — one class per feature/concern
- **Test methods** are descriptive — `test_load_batch_rating`, not `test_1`
- **Class docstring** says what's being tested
- **Method docstring** says what specific case — `"Pro*C with SQL, functions, globals"`
- **Assert messages not needed** if the test name + docstring are clear
- **`tmp_path` for DB** — each test gets a fresh database, no cross-contamination
- **`yield` in fixtures** for cleanup — close DB, remove temp files

### Test against real data

```python
FIXTURES = Path(__file__).parent.parent / "fixtures" / "sample_facts"

# Tests use AMF's REAL .facts.json files — not synthetic/mock data
# This ensures ECLE actually works with the data it will encounter
```

### What to test

```
Every public method gets at least:
  1. Happy path (normal operation)
  2. Idempotency (same input twice)
  3. Edge case (empty input, missing fields, nonexistent data)

For data-mutating operations, also test:
  4. Version chain preservation (old data still queryable)
  5. Rollback on error (transaction safety)
```

---

## Logging

### Not in MVP — print for now, structured logging later

```python
# MVP: simple prints for observability
print(f"  [FactsLoader] Loaded {file_id}: {len(fn_rows)} functions, {len(table_rows)} table ops")

# Phase 3+: structured JSON logging
logger.info("file_loaded", file_id=file_id, functions=len(fn_rows), table_ops=len(table_rows))
```

Rule: no `print()` in library code that agents might call silently. Use it only in CLI/pipeline entry points.

---

## Configuration

### Hardcoded defaults with override via constructor

```python
class TopologyBuilder:
    # Canonical edge weights (from architecture doc)
    FUNCTION_CALL_WEIGHT = 3.0
    WRITE_READ_WEIGHT = 2.5
    EXECUTION_SEQUENCE_WEIGHT = 2.0
    SHARED_TYPE_WEIGHT = 1.0
    IMPORT_WEIGHT = 0.5

    def __init__(self, db: SQLiteBackend, repo_id: str = "default",
                 min_edge_weight: float = 0.5):
        ...
```

- **Constants as class attributes** (ALL_CAPS) — not buried in method bodies
- **Override via constructor** — not via global config in MVP
- **Config file support comes in Phase 3** — don't overengineer now

---

## What Ruff Enforces

The `pyproject.toml` ruff config catches:
```
E, F, W    — pyflakes/pycodestyle basics
I          — import ordering (isort)
N          — naming conventions
UP         — Python version upgrades (use modern syntax)
B          — bugbear (common gotchas)
A          — shadowing builtins
S          — security (bandit rules via ruff)
T20        — no print() in library code (except CLI entry points)
SIM        — simplify (unnecessary else, etc.)
RUF        — ruff-specific rules
```

Run before every commit:
```bash
ruff check src/ tests/
ruff format src/ tests/
```

---

## Summary: Agent Pre-Flight Checklist

Before producing any code, every agent must verify:

- [ ] File has module docstring with ADR references
- [ ] `from __future__ import annotations` at top
- [ ] All public functions/methods have type hints
- [ ] All public functions/methods have docstrings
- [ ] Dependencies injected via constructor (no globals)
- [ ] SQL uses parameterized queries (never string interpolation)
- [ ] Errors are specific exceptions (never bare `except:`)
- [ ] Tests use real fixture data from `tests/fixtures/`
- [ ] Test covers happy path + idempotency + edge cases
- [ ] `ruff check` and `ruff format` pass
- [ ] Code matches the style of existing reference files in `src/ecle/`
