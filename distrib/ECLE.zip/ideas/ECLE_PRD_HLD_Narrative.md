# ECLE 2.0 — Product & System Narrative (PRD + HLD)

## 1. Vision
ECLE 2.0 is a continuously synchronised, version-aware, trustworthy intelligence fabric for enterprise systems — Fast, Accurate, Complete, and Trustworthy (Timely + Traceable) on every response.

---

## 2. Core Principles
FACT = **F**ast • **A**ccurate • **C**omplete • **T**rustworthy

Every search result, recommendation, and API response is held to FACT:
- **Fast:** Sub-500ms p95; ingestion is O(changed_files); all search paths bounded; no unbounded traversals
- **Accurate:** 5-dimension confidence profile on every result; stale or low-confidence results flagged, never hidden; grounding verifier blocks uncited LLM claims
- **Complete:** Every indexed entity is reachable; coverage gaps explicitly declared in response envelope; no silent gaps
- **Trustworthy** — the umbrella guarantee; enforced by two sub-properties:
  - **Timely:** knowledge reflects the latest commit; no cascade staleness; `knowledge_current_as_of` on every response; staleness score drives honest caveats
  - **Traceable:** every result carries full lineage — source file → parser → embedding model → index timestamp → query plan; uncited claims blocked

---

## 3. Operational Modes

### Day 1 (Baseline)
- Trigger: repo onboarding / bulk upload
- Full ingestion with snapshot consistency
- System becomes queryable only after completion

### Day 2 (Incremental)
- Trigger: commit / file change
- O(changed_files) processing
- Version-aware updates

---

## 4. Event-Driven Flow

Source → Kafka → Workers → Fact Store → Derived Systems → Activation → Query

---

## 5. Core Flows

### Ingestion Flow
- Detect change
- Resolve version
- Extract facts
- Build edges & vectors
- Consistency barrier
- Activate version

### Query Flow
- Intent detection
- Tool orchestration
- Data retrieval
- Trace construction
- Response generation

### Change Intelligence
- Detect diff
- Generate change events
- Propagate impact

### Rule Intelligence
- Detect patterns
- Normalize rules
- Link to trace

---

## 6. Unknown File Handling
- Tier 0 extraction
- Heuristic edges
- Low confidence tagging
- Always visible

---

## 7. Admin Control Plane

### Capabilities
- Source onboarding
- Ingestion monitoring
- Coverage insights
- Change tracking
- System health

---

## 8. Failure Handling
- DLQ for failed ingestion
- Retry mechanisms
- No partial activation
- Replay-safe processing

---

## 9. Performance Model
- Parallel ingestion
- Bounded traversal
- Selective embedding

---

## 10. Governance
- No silent gaps
- Explicit uncertainty
- Full traceability
