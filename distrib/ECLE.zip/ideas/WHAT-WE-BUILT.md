# ECLE — What We've Built

**Enterprise Continuously Learning Engine**
*Status as of April 22, 2026*

---

## 1. The Problem: Enterprise Codebases Are Black Boxes

Large enterprises run on millions of lines of code — often decades old, written in languages like COBOL, C, PowerBuilder, and Pro*C, maintained by teams that have long since moved on. When leadership asks *"What does this system actually do?"*, nobody has a complete answer.

The consequences are real:

| Question | Why It's Hard |
|----------|--------------|
| "What's the impact of changing this file?" | Nobody knows which other files depend on it, or through what paths |
| "Which systems touch the CUSTOMER_ACCOUNTS table?" | The answer spans 5 repos, 3 languages, and 200 files — no one person knows |
| "Can we migrate this capability to a new platform?" | You can't migrate what you can't see. You can't see what you haven't mapped |
| "Is this code dead or critical?" | Comments say one thing, the call graph says another, and the last commit was 2019 |

Traditional approaches — static analysis tools, architecture diagrams, tribal knowledge — all fall short. Static analysis gives you syntax, not behavior. Diagrams go stale the day after they're drawn. Tribal knowledge walks out the door when people leave.

What's needed is a **system that discovers what code actually does** — not what someone thinks it does — and keeps that knowledge current as the code evolves.

---

## 2. What Is a Grounded Discovery Engine?

A grounded discovery engine is a system that:

1. **Discovers behavior from structure** — parses source code into a Code Property Graph (CPG) that captures functions, data flow, call relationships, SQL statements, error handling, and dependencies. This is deterministic extraction, not guessing.

2. **Builds a knowledge graph** — connects files through their actual relationships: "file A calls functions in file B", "file C writes to a table that file D reads", "file E imports file F". These aren't inferred — they're extracted from the code itself.

3. **Grounds every claim in evidence** — every statement the system makes ("this file handles fee calculation", "changing it impacts 31 other files") is traceable back to specific structural evidence in the code. If the system can't prove it, it doesn't say it.

4. **Says "I don't know" when it doesn't** — if knowledge is partial, the system tells you. No silent gaps. No hallucinated answers. An explicit confidence profile on every response.

The **"grounded"** part is what separates this from AI code assistants that guess. An LLM might hallucinate that a function exists. A grounded discovery engine can prove it does — or prove it doesn't — because it parsed the actual source code.

---

## 3. AMF: The First Generation

**AMF (Agentic Migration Factory)** was the first implementation of this idea. Built as a migration intelligence tool, AMF processes source code through a **serial 6-stage pipeline** to produce structured knowledge:

```
Source Code
    │
    ▼
┌─────────────────────────────────────────────────────────────┐
│  STAGE 1: CPG (Code Property Graph)                          │
│  Joern parses source → functions, calls, SQL, dependencies   │
├─────────────────────────────────────────────────────────────┤
│  STAGE 2: FSS (File Summary Sheets)                          │
│  Per-file summaries: what does each file do?                 │
├─────────────────────────────────────────────────────────────┤
│  STAGE 3: FPS (Flow & Processing Signatures)                 │
│  Cross-file flow graph: how do files connect?                │
├─────────────────────────────────────────────────────────────┤
│  STAGE 4: PVG (Projection View Generator)                    │
│  20 architectural views: database lineage, security,         │
│  API contracts, data flow, system map, etc.                  │
├─────────────────────────────────────────────────────────────┤
│  STAGE 5: KAG (Knowledge Aggregation Graph)                  │
│  Capability catalog: what business capabilities exist?       │
├─────────────────────────────────────────────────────────────┤
│  STAGE 6: MIG → SOL (Migration → Solution)                   │
│  Migration plans, wave sequencing, solution delivery         │
└─────────────────────────────────────────────────────────────┘
    │
    ▼
  Output: JSON artifacts per stage
```

### What AMF Delivered

AMF is a serious system — ~39,000 lines of stage code, 50+ documentation files:

- **Multi-language CPG extraction** — C, C++, Java, JavaScript, Python, Go, C#, PowerBuilder, Pro*C
- **Joern-based parsing** with parallel processing
- **MCP server** with dual ChromaDB collections (behavior + syntax) so AI agents can query the knowledge
- **Air-gapped deployment** with local ONNX/OpenVINO embedding models — no cloud dependencies
- **9 pipeline stages** producing comprehensive knowledge artifacts

AMF proved the concept: you **can** build a grounded discovery engine that parses real enterprise code and produces trustworthy, evidence-backed knowledge. It works. Agents use it. Migration teams rely on it.

### Where AMF Hit Its Ceiling

But AMF was designed as a batch tool — run it once, get your artifacts, plan your migration. As usage grew, four fundamental limitations emerged:

| Limitation | Impact |
|-----------|--------|
| **Serial pipeline** — each stage depends on the previous | Change one file → re-run all 6 stages. Full corpus scan every time. |
| **O(corpus_size) cost** — FPS scans every file to rebuild the flow graph | 5 files changed in a 100K-file repo? FPS still scans all 100K files. PVG regenerates all 20 views. KAG re-synthesizes all capabilities. |
| **Single repo, single run** — no multi-repo awareness | Enterprise systems span 10+ repos. AMF can't answer "which repos share this table?" |
| **Stale after first run** — knowledge is a snapshot | The code evolves. The artifacts don't. Within days, the knowledge drifts from reality. |
| **Flat JSON artifacts** — no queryable storage | Stages produce JSON files. Want to filter, join, or traverse? Parse the files yourself. |
| **LLM in every stage** — hallucination risk, cost, rate limits | Every stage calls the LLM. Cost is proportional to corpus size. Non-deterministic outputs. |

The insight: AMF's 6 stages are all **deterministic projections of the same underlying facts**. File summaries, flow graphs, architectural views, capability catalogs — they're all different ways of looking at the same structural data extracted by CPG. There's no reason to compute them serially, store them as files, and let them go stale.

**What if the stages weren't stages at all — but queries?**

---

## 4. ECLE: The Evolution

**ECLE (Enterprise Continuously Learning Engine)** is the enterprise evolution of AMF. It takes everything AMF proved — grounded discovery, multi-language CPG extraction, evidence-backed knowledge — and rebuilds the architecture from a **serial batch pipeline** into a **data platform**.

The core transformation:

```
AMF:   CPG → FSS → FPS → PVG → KAG → MIG → SOL   (6 serial stages)
ECLE:  CPG → FACT Ingestion → done.                 (1 ingestion pass)
       All other "output" = on-demand views via queries
```

Instead of 6 stages producing JSON files, ECLE writes CPG facts into **three storage backends** in a single pass — and everything AMF's stages produced becomes a **query** against those backends. Always fresh. Never stale.

### The FACT Quality Standard

Everything ECLE produces is governed by four guarantees:

| Guarantee | Meaning | How Enforced |
|-----------|---------|-------------|
| **Fast** | Queries in milliseconds, ingestion proportional to what changed | Hybrid storage + indexed lookups + bounded traversal |
| **Accurate** | Every claim grounded in structural evidence, zero hallucination | Grounding contract: uncited claims rejected by automated verifiers |
| **Complete** | No silent gaps; if knowledge is partial, the system says so | Confidence profiles on all responses; `extraction_fidelity: PARTIAL` when applicable |
| **Timely** | Knowledge reflects the latest commit, no stale answers served as fresh | Staleness contract: every response includes `knowledge_current_as_of` timestamp |

### The Numbers (Current Repository Snapshot)

| Metric | Count |
|--------|-------|
| Source files (Python) | 79 |
| Source lines of code | 23,340 |
| Test files | 38 |
| Test lines of code | 10,018 |
| Specifications | 61 |
| Architecture Decision Records | 37 |
| Architectural contracts | 11 |
| Agent definitions | 21 |
| CI/CD workflows | 1 (multi-job) |

### Latest Shipping Changes

- **v1.7.1 shipped on April 21, 2026** with the SPEC-061 auto-job handoff fix: auto jobs now classify files, submit real child jobs to `pending/`, and complete immediately instead of blocking a worker thread through inline CPG and non-code processing.
- **Packaging was hardened for Windows builds** by moving bundle staging to `C:\Temp` when available, avoiding `Compress-Archive` failures on deep AMF paths under `%TEMP%`.
- **The distributable bundle was rebuilt successfully** as `ECLE-v1.7.1-20260421.zip`, validating the current runtime + AMF packaging path.
- **Configuration defaults were externalized** into `src/ecle/config/defaults.yaml`, keeping runtime defaults editable without touching Python source and ensuring the file is included in packaged builds.

---

## 5. Architecture: A Data Platform, Not a Pipeline

ECLE is **not a pipeline**. It is a **data platform** with an ingestion side and a query side sharing three storage backends.

### High-Level Architecture

```
                    ┌─────────────────────────────────────────────────────┐
                    │                  SOURCE MESH                         │
                    │   GitConnector  │  Webhook Receiver  │  Filesystem   │
                    └────────┬────────────────┬────────────────┬──────────┘
                             │                │                │
                             ▼                ▼                ▼
                    ┌─────────────────────────────────────────────────────┐
                    │               CPG EXTRACTION (Joern)                 │
                    │     Deterministic · Zero-LLM · Ground truth          │
                    │     Produces: CanonicalFactFileBase per file          │
                    └──────────────────────┬──────────────────────────────┘
                                           │
                                           ▼
               ┌───────────────────────────────────────────────────────────┐
               │                  FACT INGESTION (single pass)              │
               │                                                            │
               │   ┌─────────────┐   ┌──────────────┐   ┌──────────────┐  │
               │   │ Layer 1     │   │ Layer 2      │   │ Topology     │  │
               │   │ File Facts  │   │ Function     │   │ Edge         │  │
               │   │ + Embedding │   │ Facts +      │   │ Computation  │  │
               │   │             │   │ Embedding    │   │ (10 signals) │  │
               │   └──────┬──────┘   └──────┬───────┘   └──────┬───────┘  │
               └──────────┼─────────────────┼──────────────────┼──────────┘
                          │                 │                   │
          ┌───────────────┼─────────────────┼───────────────────┼───────────┐
          │               ▼                 ▼                   ▼           │
          │  ┌─────────────────┐  ┌────────────────┐  ┌────────────────┐  │
          │  │  STRUCTURED DB  │  │  VECTOR INDEX  │  │ TOPOLOGY GRAPH │  │
          │  │  (SQLAlchemy)   │  │  (ChromaDB)    │  │ (SQL CTEs)     │  │
          │  │                 │  │                │  │                │  │
          │  │  file_facts     │  │  File vectors  │  │  Structural    │  │
          │  │  function_facts │  │  Function vecs │  │  edges with    │  │
          │  │  file_tables    │  │  Doc chunks    │  │  weights and   │  │
          │  │  function_calls │  │  Cluster       │  │  confidence    │  │
          │  │  topology_edges │  │  centroids     │  │                │  │
          │  │  clusters       │  │                │  │  FUNCTION_CALL │  │
          │  │  shared_artifacts│  │  Slim payload: │  │  WRITE_READ    │  │
          │  │  service_index  │  │  embedding +   │  │  IMPORT        │  │
          │  │  ...12 tables   │  │  5 routing     │  │  SHARED_TYPE   │  │
          │  │                 │  │  fields only   │  │  ...10 types   │  │
          │  │  Handles ~80%   │  │  Handles ~20%  │  │                │  │
          │  │  of queries     │  │  of queries    │  │                │  │
          │  └────────┬────────┘  └───────┬────────┘  └───────┬────────┘  │
          │           │                   │                    │           │
          │      STORAGE LAYER (3 backends, unified by GraphQL)            │
          └───────────┼───────────────────┼────────────────────┼───────────┘
                      │                   │                    │
          ┌───────────┼───────────────────┼────────────────────┼───────────┐
          │           ▼                   ▼                    ▼           │
          │  ┌─────────────────────────────────────────────────────────┐  │
          │  │              GRAPHQL QUERY ENGINE                        │  │
          │  │  Schema · DataLoaders · Filter Pushdown · Composition    │  │
          │  └──────────────────────────┬──────────────────────────────┘  │
          │                             │                                  │
          │  ┌──────────────┐  ┌────────┴───────┐  ┌──────────────────┐  │
          │  │ MCP Server   │  │ Smart Chat     │  │ Web UI           │  │
          │  │ (10+ tools)  │  │ Router         │  │ (Jinja2)         │  │
          │  │ stdio + HTTP │  │ (intent→query) │  │                  │  │
          │  └──────┬───────┘  └────────┬───────┘  └──────┬───────────┘  │
          │         │                   │                  │              │
          │     QUERY SIDE (request path — when agents ask questions)      │
          └─────────┼───────────────────┼──────────────────┼──────────────┘
                    │                   │                  │
                    ▼                   ▼                  ▼
              VS Code / IDE        CLI / API         Browser
```

### Three Storage Backends

Each backend is optimized for the query patterns it serves. No backend is forced to handle queries it wasn't designed for.

| Backend | Technology | What It Stores | What It Serves | Scaling |
|---------|-----------|----------------|----------------|---------|
| **Structured DB** | SQLAlchemy (SQLite / PostgreSQL) | All facts as indexed rows: files, functions, tables, calls, definitions, clusters, artifacts | ~80% of queries: exact lookups, filters, aggregations, joins | Billions of rows, partitioned by tenant+repo |
| **Vector Index** | ChromaDB + ONNX embeddings (local, air-gapped) | Slim embeddings + 5 routing fields. No full payload — full facts in structured DB. | ~20% of queries: semantic search, similarity, capability discovery | Sharded by cluster_id at 1M+ points |
| **Topology Graph** | SQL recursive CTEs (Neo4j planned for enterprise) | Structural edges only. Node properties from structured DB. | Traversal: impact analysis, call chains, data lineage | Read replicas, partitioned by cluster |

### Structured DB Schema (12 Tables)

```
┌──────────────────────────────────────────────────────────────────┐
│                    STRUCTURED DB SCHEMA                            │
│                                                                    │
│  ┌─── Layer 1 (File-Level) ────────────────────────────────────┐  │
│  │  file_facts          — one row per file per version          │  │
│  │  file_tables         — tables read/written per file          │  │
│  │  file_entry_points   — entry points per file                 │  │
│  │  file_external_calls — external service calls per file       │  │
│  └──────────────────────────────────────────────────────────────┘  │
│                                                                    │
│  ┌─── Layer 2 (Function-Level) ────────────────────────────────┐  │
│  │  function_facts      — one row per function per version      │  │
│  │  function_calls      — caller→callee relationships           │  │
│  └──────────────────────────────────────────────────────────────┘  │
│                                                                    │
│  ┌─── Layer 3 (Clusters) ──────────────────────────────────────┐  │
│  │  cluster_assignments — file → cluster mapping                │  │
│  └──────────────────────────────────────────────────────────────┘  │
│                                                                    │
│  ┌─── Topology ────────────────────────────────────────────────┐  │
│  │  topology_edges      — structural edges with weights         │  │
│  └──────────────────────────────────────────────────────────────┘  │
│                                                                    │
│  ┌─── Cross-Repo / Enterprise ─────────────────────────────────┐  │
│  │  shared_artifacts    — artifacts shared across repos         │  │
│  │  cross_repo_edges    — cross-repository connections          │  │
│  │  service_call_index  — deterministic service call mapping    │  │
│  │  field_extractions   — Tuxedo field-level visibility         │  │
│  └──────────────────────────────────────────────────────────────┘  │
│                                                                    │
│  ┌─── Metadata ────────────────────────────────────────────────┐  │
│  │  versions            — commit history + version chains       │  │
│  │  repositories        — onboarded repo metadata               │  │
│  │  documents / doc_chunks — non-code knowledge (Tier 3)        │  │
│  └──────────────────────────────────────────────────────────────┘  │
└──────────────────────────────────────────────────────────────────┘
```

### Topology Edge Types

The topology graph captures 10 types of structural relationships between files, each with canonical weights:

| Edge Type | Weight | Meaning |
|-----------|--------|---------|
| `FUNCTION_CALL` | 3.0 | File A calls a function defined in file B |
| `WRITE_READ` | 2.5 | File A writes to a table that file B reads |
| `EXECUTION_SEQUENCE` | 2.0 | File A triggers file B in a processing chain |
| `SHARED_TYPE` | 1.0 | Files share a type definition or data structure |
| `IMPORT` | 0.5 | File A imports/includes file B |
| `STATE_FLOW` | 2.0 | File A modifies state consumed by file B |
| `ERROR_PROPAGATION` | 1.5 | Error in file A flows to handler in file B |
| `CONFIG_DEPENDENCY` | 1.0 | File depends on configuration from another file |
| `DATA_LINEAGE` | 2.5 | Data transformation chain between files |
| `SERVICE_CALL` | 3.0 | Cross-service/cross-repo invocation |

---

## 6. How It Works: End-to-End Workflows

### Workflow 1: Code Onboarding (New Repository)

```
Developer runs: ecle onboard /path/to/repo
                    │
                    ▼
        ┌───────────────────────┐
        │  1. GIT CONNECTOR     │  Clone repo, detect branches, resolve HEAD
        │     git.py            │  Extract: repo_id, branch, commit_sha
        └───────────┬───────────┘
                    │
                    ▼
        ┌───────────────────────┐
        │  2. CPG EXTRACTION    │  Joern processes each source file
        │     cpg/client.py     │  Produces: .facts.json per file
        │                       │  Languages: C, C++, Java, JS, Python,
        │                       │  Go, C#, PowerBuilder, Pro*C
        └───────────┬───────────┘
                    │
                    ▼
        ┌───────────────────────┐
        │  3. FACTS LOADING     │  Parse .facts.json → structured DB
        │     facts_loader.py   │  Version chain: previous_id, version_distance
        │                       │  Tables: file_facts, function_facts,
        │                       │  file_tables, function_calls
        └───────────┬───────────┘
                    │
                    ▼
        ┌───────────────────────┐
        │  4. TOPOLOGY BUILD    │  Compute edges between files
        │     topology.py       │  10 signal detectors scan fact data
        │                       │  Produces: weighted topology_edges
        └───────────┬───────────┘
                    │
                    ▼
        ┌───────────────────────┐
        │  5. EMBEDDING         │  Assemble behavioral signatures
        │     embedding_        │  Embed via ONNX model (local, air-gapped)
        │     pipeline.py       │  Upsert: file vectors + function vectors
        └───────────┬───────────┘
                    │
                    ▼
        ┌───────────────────────┐
        │  6. DOCUMENT INGEST   │  Parse non-code docs (Markdown, DDL, DOCX)
        │     document_         │  Chunk → embed → vector index
        │     embedder.py       │  Link to code facts (Tier 3 knowledge)
        └───────────┬───────────┘
                    │
                    ▼
        ┌───────────────────────┐
        │  7. CLUSTERING        │  Louvain community detection on topology
        │     louvain.py        │  Assign files to clusters
        │                       │  Compute silhouette scores
        └───────────┬───────────┘
                    │
                    ▼
        ┌───────────────────────┐
        │  8. POST-PROCESSING   │  Statistics, artifact registry
        │     post_process.py   │  Cross-repo shared artifact detection
        │                       │  Service call index population
        └───────────┬───────────┘
                    │
                    ▼
              ✅ Repository ready for queries
```

### Workflow 2: Incremental Update (Code Change)

This is where ECLE fundamentally differs from AMF. When code changes, only the changed files are reprocessed — not the entire corpus.

```
Git push / Webhook / Watcher detects change
                    │
                    ▼
        ┌───────────────────────┐
        │  1. CHANGE DETECTION  │  Git diff: which files changed?
        │     incremental.py    │  Cost: O(changed_files), not O(corpus)
        └───────────┬───────────┘
                    │
                    ▼
        ┌───────────────────────┐
        │  2. CPG RE-EXTRACT    │  Only changed files reprocessed
        │     cpg/client.py     │  Unchanged files: skip entirely
        └───────────┬───────────┘
                    │
                    ▼
        ┌───────────────────────┐
        │  3. FAST GATE         │  CIM field diff (< 1ms per file)
        │     (behavioral_sig)  │  Same functions, tables, calls?
        │                       │  YES → skip embedding (saves ~70%)
        │                       │  NO → proceed to re-embed
        └───────────┬───────────┘
                    │
                    ▼
        ┌───────────────────────┐
        │  4. FACT UPSERT       │  Supersede old facts (is_current=false)
        │     facts_loader.py   │  Insert new version (is_current=true)
        │                       │  Update version chain links
        │                       │  Update topology edges
        │                       │  Re-embed if fast gate triggered
        └───────────┬───────────┘
                    │
                    ▼
        ┌───────────────────────┐
        │  5. NEIGHBOR UPDATE   │  When file A changes, query topology
        │     (propagation)     │  for neighbors with weight ≥ 2.0
        │                       │  Recompute their context embeddings
        │                       │  Max: 2 hops, 50 files, hub exemption
        └───────────┬───────────┘
                    │
                    ▼
        ┌───────────────────────┐
        │  6. CENTROID UPDATE   │  Incremental cluster centroid adjustment
        │     (post_process)    │  Drift detection for cluster stability
        └───────────┬───────────┘
                    │
                    ▼
              ✅ Knowledge current — zero staleness
```

**Cost comparison for 5 files changed in a 100K-file repo:**

| Operation | AMF (serial pipeline) | ECLE (FACT ingestion) |
|-----------|----------------------|----------------------|
| CPG extraction | 5 files | 5 files |
| FSS derivation | 5 files | Absorbed into fact upsert |
| FPS graph rebuild | **100K files scanned** | 5 files + ~25 neighbors |
| PVG 20 views | **100K files × 20 views** | Not computed (on-demand) |
| KAG synthesis | **All capabilities** | Not computed (on-demand) |
| Total cost | O(corpus_size) | O(changed_files × avg_degree) |

### Workflow 3: Query Resolution (Agent Asks a Question)

```
Agent / IDE / CLI / Browser
        │
        │  "What's the impact of changing fee_calculator.c?"
        │
        ▼
┌───────────────────────────────────────────────────────────────┐
│  MCP TOOL LAYER (thin — translates intent → GraphQL)          │
│                                                                │
│  Tool selected: ecle_impact                                    │
│  Routes to: graph + structured backends                        │
└──────────────────────────┬────────────────────────────────────┘
                           │
                           ▼
┌───────────────────────────────────────────────────────────────┐
│  GRAPHQL QUERY ENGINE                                          │
│                                                                │
│  Step 1: Structured DB lookup (< 1ms)                          │
│    SELECT * FROM file_facts                                    │
│    WHERE file_id = 'fee_calculator.c' AND is_current = true    │
│                                                                │
│  Step 2: Graph traversal, 2 hops, weight ≥ 2.0 (< 5ms)       │
│    Start: fee_calculator.c                                     │
│    Hop 1: 8 files directly connected                           │
│    Hop 2: 23 files via high-weight edges                       │
│    Total: 31 files reached (NOT full corpus scan)              │
│                                                                │
│  Step 3: Structured DB bulk lookup (< 2ms)                     │
│    SELECT * FROM file_facts WHERE file_id IN (... 31 IDs ...)  │
│    JOIN file_tables for table impact                           │
│                                                                │
│  Step 4: Cluster/capability context (< 1ms)                    │
│    Which capabilities are affected?                            │
│                                                                │
│  Total: < 10ms at any corpus size (1K or 1M files)             │
└──────────────────────────┬────────────────────────────────────┘
                           │
                           ▼
┌───────────────────────────────────────────────────────────────┐
│  RESPONSE (with confidence profile)                            │
│                                                                │
│  {                                                             │
│    "impact": { ... 31 affected files ... },                    │
│    "confidence_profile": {                                     │
│      "ecle_freshness": 0.98,                                   │
│      "extraction_fidelity": "FULL",                            │
│      "context_freshness": 0.95,                                │
│      "edge_validity": 0.97,                                    │
│      "cluster_stability": 0.91                                 │
│    },                                                          │
│    "knowledge_current_as_of": "2026-04-06T14:30:00Z"          │
│  }                                                             │
└───────────────────────────────────────────────────────────────┘
```

### Workflow 4: Smart Chat (Natural Language)

```
User: "Which files handle fee calculation and what tables do they touch?"
        │
        ▼
┌───────────────────────────────────────────────────────────────┐
│  SMART CHAT ROUTER (chat_router.py)                            │
│                                                                │
│  Intent Detection:                                             │
│    1. Embed the question using ONNX model                      │
│    2. Compare against known query templates                    │
│    3. Classify: STRUCTURED (exact lookup) or SEMANTIC (search) │
│                                                                │
│  This query → HYBRID:                                          │
│    - "fee calculation" → semantic search (vector)              │
│    - "what tables" → structured lookup (SQL join)              │
└──────────────────────────┬────────────────────────────────────┘
                           │
                           ▼
┌───────────────────────────────────────────────────────────────┐
│  QUERY EXECUTION                                               │
│                                                                │
│  1. Vector search: "fee calculation" → top 10 similar files    │
│  2. Get file IDs from vector results                           │
│  3. Structured DB: SELECT table_name, operation                │
│     FROM file_tables WHERE file_ecle_id IN (... IDs ...)       │
│  4. Compose: files + their tables + similarity scores          │
└──────────────────────────┬────────────────────────────────────┘
                           │
                           ▼
               Response with files, tables, confidence
```

### Workflow 5: Cross-Repository Discovery

```
Agent: "Which repos share the CUSTOMER_ACCOUNTS table?"
        │
        ▼
┌───────────────────────────────────────────────────────────────┐
│  MCP TOOL: ecle_shared_artifacts                               │
│  Routes to: structured DB only                                 │
│                                                                │
│  SELECT sa.repo_id, sa.artiecle_name, sa.artiecle_type,        │
│         COUNT(DISTINCT ft.file_ecle_id) as file_count          │
│  FROM shared_artifacts sa                                      │
│  JOIN file_tables ft ON ft.table_name = sa.artiecle_name       │
│  WHERE sa.artiecle_name = 'CUSTOMER_ACCOUNTS'                  │
│  GROUP BY sa.repo_id                                           │
│                                                                │
│  Result:                                                       │
│    billing-service:  12 files (7 READ, 5 WRITE)                │
│    payment-gateway:   4 files (4 READ)                         │
│    reporting-engine:  8 files (8 READ)                         │
│                                                                │
│  + cross_repo_edges showing which files in which repos         │
│    are connected through this shared table                     │
└───────────────────────────────────────────────────────────────┘
```

### Workflow 6: Document Onboarding (Non-Code Knowledge)

```
ecle onboard-docs /path/to/docs --repo billing-service
        │
        ▼
┌───────────────────────────────────────────────────────────────┐
│  READER PLUGINS                                                │
│                                                                │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────────────┐│
│  │ Markdown     │  │ DDL Reader   │  │ DOCX Reader          ││
│  │ Reader       │  │ (SQL schema) │  │ (Word documents)     ││
│  │ .md files    │  │ .sql, .ddl   │  │ .docx files          ││
│  └──────┬───────┘  └──────┬───────┘  └──────┬───────────────┘│
│         │                 │                  │                 │
│         ▼                 ▼                  ▼                 │
│  ┌─────────────────────────────────────────────────────────┐  │
│  │  DOCUMENT CHUNKER                                        │  │
│  │  Split into semantic chunks (section-aware, overlap)      │  │
│  └─────────────────────────┬───────────────────────────────┘  │
│                             │                                  │
│                             ▼                                  │
│  ┌─────────────────────────────────────────────────────────┐  │
│  │  DOCUMENT EMBEDDER                                       │  │
│  │  Chunk → ONNX embedding → ChromaDB vector                │  │
│  │  Metadata: source_doc, chunk_index, repo_id              │  │
│  └─────────────────────────────────────────────────────────┘  │
│                                                                │
│  Tier 3 knowledge: searchable alongside code facts             │
│  Cross-tier linking: DDL table names → file_tables references  │
└───────────────────────────────────────────────────────────────┘
```

---

## 7. Structured Domain Knowledge Ingestion

### The Problem: Domain Documents Have Common Structure

Enterprise systems carry thousands of structured domain documents that are **not code** but are just as authoritative:

| Document Type | Examples | Structure | What It Defines |
|--------------|---------|-----------|----------------|
| **Service API specs** | API contracts, service descriptions, interface definitions | Service flow → Error handling → Inputs → Outputs | Every service contract: parameters, types, valid values, error codes |
| **Domain schema definitions** | XML field definitions, FML tables, data dictionaries | Typed field declarations with constraints | Every field in the API/domain surface |
| **DDL schemas** | SQL/DDL, stored procedures, PL/SQL packages | CREATE TABLE / ALTER TABLE / INDEX | Database structure, constraints, relationships |
| **Config files** | Server configs, pool configs, environment definitions | Key-value, server groups, pool mappings | Runtime topology and behavior |
| **Orchestration scripts** | Shell scripts, job schedulers, batch sequences | Job sequences, dependencies, scheduling | Batch execution graph |

The key insight: **documents of the same type follow a common structure**. All API specs for a given system have the same sections. All domain XMLs share the same schema. Enhancing them one-by-one is wrong — the system must understand the common structure per type and extract knowledge from all of them uniformly.

### Tiered Knowledge Model

ECLE organizes all knowledge into tiers based on authority level:

```
┌─────────────────────────────────────────────────────────────────┐
│  TIER 1: Code Facts (Ground Truth)                               │
│  Source: CPG extraction from source code                         │
│  Storage: Structured DB (exact) + Vector Index (semantic)        │
│  Authority: Deterministic, zero LLM, verifiable against source   │
│                                                                   │
│  What: functions, SQL statements, call graphs, dependencies,     │
│        data flow, error handling, complexity metrics              │
├─────────────────────────────────────────────────────────────────┤
│  TIER 1: Structured Domain Data (Equally Authoritative)          │
│  Source: Deterministic parsers for domain-specific formats        │
│  Storage: Structured DB only (exact lookup, no embedding needed)  │
│  Authority: Parsed, not inferred — same as code facts            │
│                                                                   │
│  What: Domain field definitions (XMLs), service contracts        │
│        (API specs), DDL schemas, config parameters, job defs     │
│                                                                   │
│  Key: These are NOT documents to embed — they are structured     │
│  data to parse. Embedding destroys their precision.              │
├─────────────────────────────────────────────────────────────────┤
│  TIER 2: Derived Knowledge (Computed from Tier 1)                │
│  Source: Embeddings of Tier 1 facts                              │
│  Storage: Vector Index                                           │
│  Authority: Derived — cosine distance captures behavioral change │
│                                                                   │
│  What: File similarity, semantic duplicates, capability clusters │
├─────────────────────────────────────────────────────────────────┤
│  TIER 3: Non-Code Knowledge (Supporting Context)                 │
│  Source: Document readers (Markdown, DOCX, plaintext, HTML)      │
│  Storage: Structured DB (doc_chunks) + Vector Index (semantic)   │
│  Authority: Informational — linked to Tier 1 via entity matching │
│                                                                   │
│  What: Architecture docs, runbooks, incident reports, design     │
│        decisions, quality assessments                             │
└─────────────────────────────────────────────────────────────────┘
```

### Cross-Tier Linking

The real power emerges when tiers link together:

```
Service API spec (Tier 1 data):
  ServiceA → calls ServiceB, ServiceC, ServiceD
  ServiceA → reads TABLE_X, TABLE_Y
  ServiceA → writes TABLE_Z, TABLE_W
  ServiceA → 87 error codes with conditions
  ServiceA → 100+ input fields, 50+ output fields

Code facts (Tier 1 code):
  service_a.c → FUNCTION_CALL edges to same services
  service_a.c → WRITE_READ edges to same tables
  service_a.c → framework API calls referencing same fields

DDL schema (Tier 1 data-sql):
  TABLE_X → columns, indexes, constraints
  TABLE_Z → columns, relationships

ECLE connects all three automatically:
  "What touches TABLE_X?"
    → Code: service_a.c reads it (Tier 1 code, CPG evidence)
    → API spec: ServiceA uses it for lookup (Tier 1 data)
    → Schema: 12 columns, 3 indexes (Tier 1 data-sql)
    → 4 other services also reference it (cross-service discovery)
```

### Unified Onboard Model (SPEC-040)

The onboarding system is designed around **three orthogonal axes** — not one monolithic pipeline:

```
┌─────────────────────────────────────────────────────────┐
│              THREE-AXIS ONBOARD MODEL                    │
│                                                          │
│  AXIS 1: Content Type (WHAT)                             │
│  ┌──────────┬──────────┬──────────┬──────────┬────────┐ │
│  │  code    │  config  │  data    │  data-sql│  docs  │ │
│  │  (.c,    │  (.sh,   │  (.xml,  │  (.sql,  │  (.md, │ │
│  │  .java,  │  .yaml,  │  .txt,   │  .ddl,   │  .docx,│ │
│  │  .py,    │  .cfg,   │  .tsv)   │  .rql,   │  .pdf, │ │
│  │  .ppc)   │  .env)   │          │  .pks)   │  .html)│ │
│  └──────────┴──────────┴──────────┴──────────┴────────┘ │
│       │           │          │          │          │     │
│       ▼           ▼          ▼          ▼          ▼     │
│     CPG       Config     Schema     SQL/DDL     Doc     │
│   Extract     Parser     Parser     Parser     Parser   │
│       │           │          │          │          │     │
│       ▼           ▼          ▼          ▼          ▼     │
│    Tier 1     Tier 1     Tier 1     Tier 1     Tier 3   │
│  code facts  config    domain    db_tables   doc_chunks │
│  + Tier 2    facts     facts    db_columns   + vectors  │
│  vectors    + vectors   (exact)  (exact)                │
│                                                          │
│  AXIS 2: Source (WHERE)                                  │
│  ┌────────────────────┬──────────────────────┐          │
│  │  git               │  local               │          │
│  │  Clone/pull, commit│  Scan directory,      │          │
│  │  tracking, branches│  content-hash change  │          │
│  └────────────────────┴──────────────────────┘          │
│                                                          │
│  AXIS 3: Schedule (WHEN)                                 │
│  ┌──────────┬──────────────┬──────────────┐             │
│  │  once    │  recurring   │  re-run      │             │
│  │  Initial │  Watch for   │  Manual      │             │
│  │  import  │  changes     │  retry       │             │
│  └──────────┴──────────────┴──────────────┘             │
│                                                          │
│  Every combination of (content_type × source × schedule) │
│  is valid. 5 × 2 × 3 = 30 valid onboard configurations. │
└─────────────────────────────────────────────────────────┘
```

**Why this matters:** A domain XML directory with thousands of files is onboarded as `content_type=data, source=local, schedule=once`. Service descriptions are `content_type=data, source=git, schedule=recurring` (they live in a repo and evolve with the system). SQL schemas are `content_type=data-sql, source=git, schedule=recurring`. The same pipeline handles all of them — the content type selects the parser, the source selects the connector, the schedule selects the trigger.

### What ECLE Extracts From Structured Domain Documents

For any service API spec, the system extracts:

| Extracted Knowledge | Target | Enables |
|-------------------|--------|---------|
| Service name + description | `service_call_index` | "What does this service do?" |
| Called services (dependencies) | `service_call_index` (caller→callee) | "What services does this depend on?" |
| Tables referenced | `shared_artifacts` + cross-links to `file_tables` | "What touches TABLE_X?" across code AND specs |
| Input fields (types, sizes, valid values) | `field_extractions` | "What are the inputs to this service?" |
| Output fields (types, sizes) | `field_extractions` | "What does this service return?" |
| Error codes (conditions, severity) | Structured DB rows | "What errors can this service throw?" |
| Enhancement/change history | Version metadata | "When was this capability added?" |

**The common structure means one parser per document type handles all instances.** No per-document enhancement — the system understands the structure and extracts knowledge uniformly across hundreds or thousands of specs.

---

## 8. Data Flow: From Source Code to Knowledge

### The CPG-to-Backend Data Slicing

Every `.facts.json` file from CPG extraction is sliced into three backends in a single ingestion pass. No intermediate JSON artifacts. No serial stages.

```
Source Code (e.g., batch_rating.ppc)
        │
        ▼
CPG Extraction (Joern)
        │
        │  Produces .facts.json:
        │    functions[], sql_statements[], dependencies[],
        │    execution_sequence[], error_handling[], metrics{}
        │
        ▼
FACT Ingestion (single pass)
        │
        ├──→ STRUCTURED DB
        │      file_facts:      file_id, language, complexity, execution_model, commit_sha
        │      function_facts:  function_name, parameters, return_type, complexity
        │      file_tables:     table_name (e.g., UNRATED_CDRS), operation (READ/WRITE)
        │      function_calls:  caller_id → callee_name, call_type
        │
        ├──→ VECTOR INDEX
        │      File embedding:     behavioral signature text → ONNX → 384-dim vector
        │      Function embedding: function behavioral text → ONNX → 384-dim vector
        │      Payload: id, repo_id, cluster_id, is_current, model_version (slim)
        │
        └──→ TOPOLOGY GRAPH
               Edge: batch_rating.ppc → UNRATED_CDRS (WRITE_READ, weight=2.5)
               Edge: batch_rating.ppc → RATED_CDRS (WRITE_READ, weight=2.5)
               Edge: batch_rating.ppc → rate_engine.c (FUNCTION_CALL, weight=3.0)
```

### Version Chain Model

Every fact is versioned. Nothing is deleted — old versions are superseded.

```
Version chain for fee_calculator.c:

  v1 (commit abc123)           v2 (commit def456)           v3 (commit ghi789)
  ┌─────────────────┐          ┌─────────────────┐          ┌─────────────────┐
  │ is_current=false │──prev──→│ is_current=false │──prev──→│ is_current=true  │
  │ superseded_at=T1 │         │ superseded_at=T2 │         │ superseded_at=∅  │
  │ version_distance │         │ version_distance │         │                  │
  │  from prev: ∅    │         │  from prev: 0.02 │         │  from prev: 0.31 │
  └─────────────────┘          └─────────────────┘          └─────────────────┘
                                    cosmetic                     behavioral
                                    change                       change
                                (rename, comments)           (new table write)

  - version_distance < 0.05 → cosmetic change → skip re-embedding
  - version_distance > 0.10 → behavioral change → recompute neighbors
```

---

## 9. MCP Tool Catalog

The MCP server exposes 30+ tools organized by function. Agents interact with tools, never with databases directly.

### Discovery Tools (find things)

| Tool | Backend | What It Does |
|------|---------|-------------|
| `ecle_search` | Vector + Structured | Semantic search across all layers |
| `ecle_find_files` | Structured | Lookup files by filters (language, repo, table, etc.) |
| `ecle_find_functions` | Structured | Lookup functions by name, complexity, entry point |
| `ecle_find_tables` | Structured | Find all files/functions touching a table |
| `ecle_find_callers` | Structured | All callers of a function |
| `ecle_find_callees` | Structured | All functions called by a function |
| `ecle_find_similar` | Vector + Structured | Semantically similar files/functions |
| `ecle_find_duplicates` | Vector + Structured | Semantic duplicates above threshold |

### Traversal Tools (follow relationships)

| Tool | Backend | What It Does |
|------|---------|-------------|
| `ecle_impact` | Graph + Structured | Impact analysis outward from a file (bounded traversal) |
| `ecle_trace_path` | Graph + Structured | Execution path between two points |
| `ecle_trace_data` | Graph + Structured | Data flow for a table/artifact |
| `ecle_dependency_tree` | Graph + Structured | Full dependency tree for a file |

### View Tools (what AMF's stages produced — now on demand)

| Tool | Replaces (AMF) | What It Does |
|------|----------------|-------------|
| `ecle_view_database` | `database.pv` (PVG) | Database lineage: who reads/writes which tables |
| `ecle_view_security` | `security.pv` (PVG) | Auth, crypto, validation patterns |
| `ecle_view_api_contracts` | `api_contract.pv` (PVG) | Entry points + their call graphs |
| `ecle_view_system_map` | `system_map.pv` (PVG) | Full system overview |
| `ecle_view_data_flow` | `data_flow.pv` (PVG) | Data flow across files |
| `ecle_view_change_impact` | `change_impact.pv` (PVG) | Impact of a proposed change |
| `ecle_view_capability` | KAG capability | Capability description from constituent facts |
| `ecle_view_catalog` | KAG catalog | File role catalog |
| `ecle_view_summary` | KAG summary | System summary (aggregation) |

### Cross-Repo Tools (enterprise-wide)

| Tool | Backend | What It Does |
|------|---------|-------------|
| `ecle_repos` | Structured | List all onboarded repos with stats |
| `ecle_shared_artifacts` | Structured | Find all repos touching a named artifact |
| `ecle_cross_repo_edges` | Graph + Structured | Cross-repo connections |
| `ecle_cross_repo_impact` | Graph + Structured | Impact spanning repo boundaries |
| `ecle_service_map` | Structured + Graph | Caller/implementer map for a service |

### Version Tools (temporal queries)

| Tool | Backend | What It Does |
|------|---------|-------------|
| `ecle_file_history` | Structured | Version chain for a file (all commits, behavioral distance) |
| `ecle_branch_diff` | Structured + Vector | Behavioral diff between branches |
| `ecle_timeline_at` | Structured | State of knowledge at a specific point in time |

---

## 10. Confidence & Grounding System

### The Grounding Contract

Every claim in the system is traceable to structural evidence. The grounding stack ensures hallucination cannot survive:

```
Layer 0 (CPG/CIM):     Ground truth — deterministic, no LLM, no hallucination possible
Layer 1 (Structured):   Facts extracted from CPG — verifiable against source code
Layer 2 (Vectors):      Derived from Layer 1 facts — distance is the proof
Layer 3 (Clusters):     Emergent from topology — silhouette score validates cohesion
Layer 4 (Answers):      Composed from Layers 1-3 — confidence profile always attached

Hallucination can enter at query-time LLM enrichment —
but it cannot survive the grounding verifier.
Uncited claims → REJECTED. Logged as HALLUCINATION_BLOCKED.
```

### The 5 Confidence Dimensions

Every response carries a decomposed confidence profile:

| Dimension | Measures | How It Degrades |
|-----------|---------|-----------------|
| `ecle_freshness` | CPG is current at this commit | Deterministic — never degrades without code change |
| `extraction_fidelity` | CPG extraction quality (FULL/PARTIAL/HEURISTIC) | Degrades for unsupported language features |
| `context_freshness` | Neighbor files are current | Degrades silently when neighbors change |
| `edge_validity` | Topology edges match current state | Degrades when edge endpoints change |
| `cluster_stability` | File's distance from cluster centroid | Drifts as file evolves semantically |

### The Staleness Contract

**The system NEVER silently serves a stale answer as fresh.** Every response includes:

```json
{
  "confidence_profile": { ... 5 dimensions ... },
  "staleness_caveat": "string | null",
  "system_status": {
    "degradation_level": "FULL_SERVICE | DEGRADED_FRESHNESS | ...",
    "knowledge_current_as_of": "2026-04-06T14:30:00Z"
  }
}
```

| Staleness Score | Action |
|----------------|--------|
| < 0.1 | Serve directly — knowledge is fresh |
| 0.1 - 0.3 | Serve with caveat, queue refresh |
| > 0.3 | Serve with WARNING, trigger immediate refresh |

---

## 11. How AMF's Stages Became ECLE's Views

The fundamental insight: AMF's 6 stages are all deterministic projections of the same underlying facts. ECLE eliminates the stages and computes views on demand.

| AMF Stage | What It Produced | ECLE Equivalent | How |
|-----------|-----------------|-----------------|-----|
| **FSS** | Per-file summary JSON | Layer 1 file_facts + embedding | Facts in structured DB, embedding in vector |
| **FPS** | Flow graph JSON + code slices | Layer 2 function_facts + topology_edges | Functions in structured DB, edges computed from 10 signals |
| **PVG** | 20 filtered view JSON files | 20 parameterized GraphQL queries | Computed on demand, always fresh |
| **KAG** | Catalogs, summaries, data dictionaries | Aggregation queries against structured DB | Derived on demand from Layer 1/2/3 |
| **MIG** | Migration plans, Gantt charts | Queries against capabilities + topology | Wave planning from cluster dependencies |
| **SOL** | UEG + contracts + knowledge | Layer 2 vectors ARE the UEG nodes | Topology + function facts = execution graph |

**Net effect:** 6 stages → 1 ingestion pass. Everything else is a QUERY.

```
AMF:   CPG → FSS → FPS → PVG → KAG → MIG → SOL   (6 serial stages)
ECLE:  CPG → FACT Ingestion → done.                 (1 ingestion pass)
       All other "output" = on-demand views via GraphQL
```

---

## 12. LLM Strategy

### No LLM on the Commit Path

All ingestion is deterministic computation — zero LLM calls. This eliminates:
- Hallucination risk during indexing
- LLM cost proportional to commit volume
- Rate limit bottlenecks on the critical path
- Non-deterministic behavior in the data platform

### LLM at Query Time Only (Optional)

```
Tier 1 (always, zero-LLM):
  - Structured DB lookups, vector searches, graph traversals
  - All facts, edges, clusters, views available immediately
  - Covers 95%+ of agent queries

Tier 2 (on-demand, LLM-enhanced, requires Claude API key):
  - "Explain this capability in plain English"
      → Retrieve Layer 3 cluster + constituent Layer 1 facts
      → LLM synthesizes narrative from retrieved facts
      → Cache with staleness hash

  - "What does this file do?"
      → Retrieve Layer 1 facts
      → LLM generates natural language summary
      → Cache with version key (file_id, commit_sha)

  LLM cost is O(what the user asks for), not O(corpus size)
```

---

## 13. Components Delivered

### Week 1 — Foundation (SPEC-001 through SPEC-008)

All **implemented and tested**.

| Component | Spec | What It Does |
|-----------|------|-------------|
| Structured DB Schema | SPEC-001 | 12-table schema: file_facts, function_facts, topology_edges, cluster_assignments, versions, repos, documents, doc_chunks, shared_artifacts, cross_repo_edges, service_call_index, field_extractions |
| SQLite Backend | SPEC-002 | Full CRUD, queries, traversal, retire/purge with SQLAlchemy Core |
| Facts Loader | SPEC-003 | Ingestion, sync, versioning, superseding, version chains |
| Topology Edges | SPEC-004 | 10 signal detectors: FUNCTION_CALL, WRITE_READ, IMPORT, SHARED_TYPE, EXECUTION_SEQUENCE, etc. |
| Behavioral Signatures | SPEC-005 | Embedding text assembly from CPG facts + ChromaDB vector storage |
| GraphQL Schema | SPEC-006 | Strawberry-based schema with 12+ types, resolvers, DataLoaders |
| CLI | SPEC-007 | `ecle import`, `ecle onboard`, `ecle serve`, `ecle stats`, `ecle remove`, `ecle watch` |
| MCP Server | SPEC-008 | 10+ tools via FastMCP, stdio + HTTP transport, lazy loading |

### Week 2 — Onboarding + Integration (SPEC-009 through SPEC-013)

| Component | Spec | Status | What It Does |
|-----------|------|--------|-------------|
| Git Onboarding | SPEC-009 | Implemented + Tested | Clone → CPG → ingest pipeline with branch detection |
| Git Integration | SPEC-010 | Implemented | Continuous ingestion via polling + incremental diffs |
| Document Onboarding | SPEC-011 | Implemented + Tested | Reader plugins: Markdown, DDL, DOCX, plaintext → chunk → embed |
| Web UI | SPEC-012 | Partial | FastAPI routes, Jinja2 templates, chat interface |
| Settings & Config | SPEC-013 | Implemented | `ecle.yaml`, Lite/Full/Enterprise modes, backend factory |

### Week 3 — Hardening + Cross-Repo (SPEC-014 through SPEC-020)

| Component | Spec | Status | What It Does |
|-----------|------|--------|-------------|
| Shared Artifact Registry | SPEC-014 | Implemented + Tested | Cross-repo artifact sharing with schema + ingestion hooks |
| Cross-Repo MCP Tools | SPEC-015 | Implemented + Tested | 6 cross-repo discovery tools |
| Gap Closure | SPEC-016 | Implemented | CLI wiring, config integration, spec sync |
| Error Handling | SPEC-017 | Implemented | Typed exceptions per layer, structured JSON logging |
| Louvain Clustering | SPEC-018 | Implemented | Community detection, cluster assignment, silhouette scoring |
| Smart Chat Router | SPEC-019 | Implemented | Embedding-based intent → backend selection, LLM-ready |
| CI/CD Integration | SPEC-020 | Implemented | GitHub Actions workflow: lint + unit tests + integration tests |

### Week 4 — Service Separation (SPEC-021 through SPEC-024)

| Component | Spec | Status | What It Does |
|-----------|------|--------|-------------|
| Remote MCP Server | SPEC-021 | Implemented | HTTP transport with Bearer token auth (ADR-022) |
| GraphQL API Service | SPEC-022 | Implemented | Standalone FastAPI with REST + health endpoints |
| Web UI Service | SPEC-023 | Implemented | Standalone UI calling API over HTTP |
| Repository Pattern | SPEC-024 | Implemented + Tested | Consistent data access abstraction (ADR-023) |

### Week 5 — Advanced Features (SPEC-025 through SPEC-037)

| Component | Spec | Status | What It Does |
|-----------|------|--------|-------------|
| Webhook Receiver | SPEC-025 | Implemented + Tested | GitHub push event handler for reactive ingestion |
| CI Pipeline Templates | SPEC-026 | Spec | Reusable CI/CD templates |
| Materialize & AMF Export | SPEC-027 | Spec | `ecle materialize --format amf` backward compat |
| Branch-Aware Queries | SPEC-028 | Implemented | Version-scoped queries with `is_current` flag |
| Artifact Store | SPEC-029 | Implemented | Source + facts file storage (ADR-024) |
| Cross-Repo Query Completeness | SPEC-030 | Spec | Addressing 5 compounding failures (ADR-027) |
| Service Call Graph Index | SPEC-031 | Implemented | Deterministic service mapping (ADR-028) |
| Repo Purge | SPEC-032 | Implemented | Coordinated data removal across all backends (ADR-018) |
| Tuxedo Field-Level Extraction | SPEC-033 | Spec | Field visibility gaps (ADR-029) |
| Centralized Logging | SPEC-034 | Implemented | Structured JSON logging with sensitive data filtering |
| ECLE Home Runtime | SPEC-035 | Implemented | `ECLE_HOME` directory for databases, vectors, models |
| CPG Extraction Trigger | SPEC-036 | Implemented | Local + service mode CPG client with polling |
| Import Queue & Health | SPEC-037 | Implemented | Async job queue with health monitoring |

### Week 6 — Emerging (SPEC-038 through SPEC-042)

| Component | Spec | Status | What It Does |
|-----------|------|--------|-------------|
| Source Vector Layer | SPEC-038 | Spec | Direct source code → vector embedding pipeline |
| Unified Onboard Jobs | SPEC-040 | Spec | Three-axis onboard model (content × source × schedule) |
| Service Boundary Architecture | SPEC-042 | Spec | Service boundary contracts and isolation |

### Weeks 7–8 — Runtime Hardening, Packaging, and Queue Behavior

Recent delivery extended the original six-week baseline into a more production-ready runtime. The biggest additions in the current branch are:

| Area | Specs | What Changed |
|------|-------|--------------|
| Two-phase extraction | SPEC-044, SPEC-045, SPEC-049 | Added the structural/deep extraction workflow and AMF support needed to separate fast structural passes from heavier deep enhancement passes. |
| Packaging and deployment | SPEC-046 | Added versioned distribution packaging, which now produces the v1.7.1 runtime+AMF bundle. |
| Cross-tier linkage and change intelligence | SPEC-047, SPEC-048 | Added explicit cross-tier linker behavior and change-intelligence plumbing so structural ingestion can promote evidence and link code to non-code artifacts. |
| Prompt and onboarding UX | SPEC-050, SPEC-051 | Added transparent prompt enrichment and auto-classify onboarding so mixed uploads can be routed by detected content type instead of forcing a single path. |
| Runtime guardrails | SPEC-053, SPEC-054, SPEC-059 | Added language-common cleanup, query size/performance guards, and configurable runtime limits for service indexing, CPG phases, and MCP response size. |
| Non-code evidence promotion | SPEC-055 | Promoted document, config, and DDL evidence into shared artifacts so cross-repo discovery can reason over more than direct SQL/code-only signals. |
| Queue orchestration | SPEC-056, SPEC-057, SPEC-058, SPEC-061 | Added service-index child jobs, parallel worker pools with CPG slot caps, queue start-mode control, and the auto-job classify-then-submit handoff fix. |
| Pipeline instrumentation | SPEC-060 | Added batch embedding improvements plus timing visibility for detector, linker, and pipeline stages. |

---

## 14. Governance Framework

### 37 Architecture Decision Records

Every non-trivial design choice is captured as an immutable ADR — the "why" behind the "what":

| ADR | Decision | Impact |
|-----|----------|--------|
| ADR-001 | FACT replaces serial pipeline | Core transformation — stages become views |
| ADR-002 | Hybrid storage (not vector-only) | Structured DB for 80%, vector for 20%, graph for traversal |
| ADR-003 | GraphQL query engine | Single composable query language across backends |
| ADR-004 | FPS slicer absorbed into Layer 2 | Behavioral signatures ported as embedding text assembly |
| ADR-005 | AMF baseline tech stack | Preserves AMF's Joern + ChromaDB + ONNX foundation |
| ADR-006 | Embedding model deferred | Benchmark before committing to specific model |
| ADR-007 | Resolved open questions | Fingerprint as fast gate, LLM at query time only |
| ADR-008 | ECLE as knowledge engine | Tier 3: DB schemas, docs, incidents beyond code |
| ADR-009 | Knowledge graph is the product | Graph DB for enterprise traversal |
| ADR-010 | MVP scope + tech stack | SQLite + ChromaDB + FastAPI for Lite mode |
| ADR-011 | CPG storage + AMF reuse | Reuse AMF's Joern pipeline directly |
| ADR-012 | Facts folder sync | File-based artifact exchange between AMF and ECLE |
| ADR-013 | Source-to-fact relation | Traceability from every fact to source location |
| ADR-014 | Version chain — everything kept | Immutable history with superseding links |
| ADR-015 | Cross-version discovery queries | Temporal queries across releases |
| ADR-016 | Hierarchy: repo > cluster > version | Organizational structure for multi-repo |
| ADR-017 | Deployment modes | Lite (SQLite) / Full (Docker) / Enterprise (K8s) |
| ADR-018 | Coordinated data purge | Safe removal across all 3 backends |
| ADR-019 | Shared artifact registry | Cross-repo artifact sharing |
| ADR-020 | Cross-repo MCP tools | Multi-repo discovery from single agent session |
| ADR-021 | Error handling + observability | Typed exceptions, structured JSON logging |
| ADR-022 | Remote MCP transport | HTTP + Bearer auth for service mode |
| ADR-023 | Repository pattern | Consistent data access abstraction |
| ADR-024 | Artifact store | Source + facts in unified store |
| ADR-025 | Materialize replaces pipeline stages | On-demand AMF-format export |
| ADR-026 | SQLAlchemy Core backend | Single ORM replaces raw SQL |
| ADR-027 | Cross-repo query completeness | Fixing 5 compounding failures |
| ADR-028 | Deterministic answers via service index | Service call graph for reliable routing |
| ADR-029 | Tuxedo field-level extraction | Field visibility for legacy Tuxedo code |
| ADR-030 | Two-phase CPG extraction | Structural and deep extraction are separated as distinct runtime phases |
| ADR-031 | Transparent prompt enrichment | Query-time prompt augmentation remains visible and controlled |
| ADR-032 | File upload, not server paths | Upload flows operate on user-provided content, not server-local path assumptions |
| ADR-033 | Service boundary is HTTP-only | Service separation contracts are explicit and transport-safe |
| ADR-034 | Platform repo for shared data | Shared data/config lives in a dedicated platform repo model |
| ADR-035 | Auto-classify onboarding | Mixed uploads are routed by detected content type rather than a single forced ingest path |
| ADR-036 | Lifecycle tests as release gate | Lifecycle coverage became a release-quality gate, not a best-effort check |
| ADR-037 | Non-code evidence promoted to artifacts | Documents/config/DDL can participate in shared-artifact discovery |

### 11 Architectural Contracts

| Contract | Governs |
|----------|---------|
| `fact-architecture.md` | Core FACT data platform design |
| `fact-data-slicing.md` | CPG → backend field mapping |
| `fact-mcp-server.md` | MCP server specification |
| `fact-query-engine.md` | GraphQL schema, resolvers, DataLoaders |
| `grounding-contract.md` | Every claim must cite structural evidence |
| `staleness-contract.md` | No silent stale data — freshness metadata always included |
| `confidence-contract.md` | 5-dimension confidence profiles on all responses |
| `testing-contract.md` | Test pyramid, coverage requirements, benchmarks |
| `vector-design.md` | Embedding model, collections, scaling strategy |
| `coding-standards.md` | Python 3.11+, type hints, SQL safety, error handling |
| `sdlc-contract.md` | Branching, PRs, reviews, Definition of Done |

### 61 Specifications

Every component was specified before implementation. Specs follow a strict format: Purpose, ADR References, Inputs, Outputs, Interface, Behavior, Files, Tests, Dependencies, Status.

### 21 Specialized Agent Definitions

| Agent | Role |
|-------|------|
| Platform Architect | Cross-layer design, architectural coherence |
| CPG Pipeline Engineer | CPG extraction, CIM normalization, language packs |
| FSS Engineer | Dual FSS model, tiered analysis |
| Graph Engineer | Graph DB, clustering, edge lifecycle |
| Fingerprint Engineer | Behavioral fingerprint, change detection |
| Grounding Verifier | Hallucination elimination, citation verification |
| Source Mesh Engineer | VCS connectors, ChangeEvent normalization |
| MCP Tool Engineer | MCP tools, query routing |
| Knowledge Synthesis Engineer | PVG projections, KAG synthesis |
| Learning Loop Engineer | Interaction ledger, confidence voting |
| Migration Solution Engineer | MIG wave planning, SOL delivery |
| Onboarding Engineer | 8-phase pipeline, UI portal |
| Integration Engineer | CI/CD hooks, optimizations |
| Infrastructure Engineer | Shared stores, vector DB, event store |
| DevOps Engineer | Build system, Docker, deployment |
| Code Reviewer | 7-point review checklist |
| Security Auditor | OWASP, tenant isolation, input validation |
| Test Engineer | Test pyramid, eval suites, benchmarks |
| Tech Writer | API docs, runbooks, ADR templates |
| Task Planner | Phase decomposition, dependency tracking |

---

## 15. Technology Stack

### Core (Lite Mode — zero external dependencies)

| Layer | Technology | Version |
|-------|-----------|---------|
| Language | Python | 3.11+ |
| Web Framework | FastAPI | 0.115.0+ |
| ASGI Server | Uvicorn | 0.34.0+ |
| GraphQL | Strawberry GraphQL | 0.260.0+ |
| Validation | Pydantic | 2.10.0+ |
| Database | SQLAlchemy + SQLite | 2.0.0+ |
| Vector Store | ChromaDB | 1.0.0+ |
| Embeddings | ONNX Runtime | 1.19.0+ |
| Tokenizer | Transformers | 4.46.0+ |
| CPG Engine | Joern (via AMF) | CLI integration |
| MCP Protocol | FastMCP | 1.5.0+ |
| File Monitoring | Watchdog | 6.0.0+ |
| Config | PyYAML | 6.0+ |
| Templates | Jinja2 | 3.1.0+ |
| Doc Reader | python-docx | 1.1.0+ |
| HTTP Client | httpx | 0.28.0+ |
| Build System | Hatchling | — |
| Linter/Formatter | Ruff | 0.11.0+ |
| Testing | pytest + pytest-cov | 8.3.0+ |

### Full Mode (additional)

| Technology | Purpose |
|-----------|---------|
| PostgreSQL | Enterprise structured DB |
| Qdrant | Sharded vector index |
| Neo4j | Graph traversal at scale |
| Redis | Async job queue |
| Anthropic Claude API | LLM chat enrichment |
| Prometheus | Metrics/monitoring |
| PyMuPDF | PDF reader |
| openpyxl | Excel reader |
| python-pptx | PowerPoint reader |

---

## 16. Deployment Modes

### Lite Mode (implemented, default)

```
┌─────────────────────────────────────────┐
│           SINGLE MACHINE                 │
│                                          │
│  ecle serve                              │
│    ├── SQLite         (~100 MB / 10K files)
│    ├── ChromaDB       (~50 MB / 10K files)
│    ├── ONNX embeddings (local, air-gapped)
│    ├── GraphQL API    (localhost:8000)
│    ├── MCP Server     (stdio or HTTP)
│    └── Web UI         (localhost:8001)
│                                          │
│  Total footprint: < 200 MB               │
│  Capacity: up to 50K files               │
│  Zero config. Zero external dependencies.│
│  Runs on a laptop. Air-gapped.           │
└─────────────────────────────────────────┘
```

### Full Mode (planned, Docker Compose)

```
┌─────────────────────────────────────────┐
│         DOCKER COMPOSE STACK             │
│                                          │
│  ┌──────────────┐  ┌──────────────────┐ │
│  │ ECLE Server  │  │ PostgreSQL       │ │
│  │ (FastAPI)    │  │ (structured DB)  │ │
│  └──────┬───────┘  └──────────────────┘ │
│         │                                │
│  ┌──────┴───────┐  ┌──────────────────┐ │
│  │ Qdrant       │  │ Redis            │ │
│  │ (vectors)    │  │ (async queue)    │ │
│  └──────────────┘  └──────────────────┘ │
│                                          │
│  + Claude API (LLM chat enrichment)      │
│  + Advanced doc readers (PDF, Excel, PPT)│
│  Capacity: up to 500K files              │
└─────────────────────────────────────────┘
```

### Enterprise Mode (planned, Kubernetes)

```
┌──────────────────────────────────────────────────────┐
│              KUBERNETES CLUSTER                        │
│                                                        │
│  ┌─────────┐  ┌─────────┐  ┌─────────┐  ┌─────────┐│
│  │ ECLE    │  │ ECLE    │  │ ECLE    │  │ ECLE    ││
│  │ Pod 1   │  │ Pod 2   │  │ Pod 3   │  │ Pod N   ││
│  └────┬────┘  └────┬────┘  └────┬────┘  └────┬────┘│
│       └─────────────┴────────────┴─────────────┘     │
│                          │                            │
│  ┌───────────────────────┴────────────────────────┐  │
│  │  PostgreSQL (partitioned by tenant+repo)        │  │
│  │  + Read replicas for query load                 │  │
│  └────────────────────────────────────────────────┘  │
│  ┌────────────────────────────────────────────────┐  │
│  │  Qdrant (sharded by cluster_id, auto-scaling)   │  │
│  └────────────────────────────────────────────────┘  │
│  ┌────────────────────────────────────────────────┐  │
│  │  Neo4j (cross-repo traversal at scale)          │  │
│  └────────────────────────────────────────────────┘  │
│  ┌──────────┐  ┌────────────┐  ┌─────────────────┐  │
│  │ Redis    │  │ Kafka      │  │ Prometheus +     │  │
│  │ (cache)  │  │ (events)   │  │ Grafana (obs.)   │  │
│  └──────────┘  └────────────┘  └─────────────────┘  │
│                                                        │
│  Multi-tenant · OIDC/SAML auth · Millions of files     │
└──────────────────────────────────────────────────────┘
```

---

## 17. Scaling Properties

### Why This Scales

| Property | Mechanism |
|----------|-----------|
| **No cascade staleness** | Change 1 file → update its vectors + edges. Done. No 6-stage pipeline. |
| **No intermediate artifacts** | No `fps_flow_graph.json`, no 20 PVG files, no KAG files. Views are queries. |
| **Incremental by default** | Vector upsert is O(1) per file. Centroid update is O(1) per cluster. |
| **Parallelizable** | Layer 1 and Layer 2 for different files are fully independent. |
| **Query scales with answer, not corpus** | Impact analysis touches ~30 files, not 1M. |

### Performance at Scale

| Corpus | Layer 1 Points | Layer 2 Points | Topology Edges | Structured DB RAM |
|--------|---------------|---------------|----------------|-------------------|
| 1K files | 1K | ~10K | ~50K | ~100 MB |
| 10K files | 10K | ~100K | ~500K | ~1 GB |
| 100K files | 100K | ~1M | ~5M | ~10 GB |
| 1M files | 1M | ~10M | ~50M | ~100 GB (sharded) |

### Query Latency (target)

| Operation | 1K files | 100K files | 1M files |
|-----------|----------|-----------|----------|
| Structured lookup | < 1ms | < 1ms | < 5ms |
| Semantic search | < 5ms | < 5ms | < 10ms |
| Impact traversal (2 hops) | < 5ms | < 10ms | < 10ms |
| Commit ingestion (5 files) | < 500ms | < 500ms | < 500ms |

---

## 18. Test Suite

### Coverage

| Category | Files | Functions | Focus |
|----------|-------|-----------|-------|
| Unit tests | 32 | 700+ assertions across queueing, config, MCP, onboarding, and storage paths | Each component in isolation |
| Integration tests | 5 | End-to-end workflows across onboarding, documents, git, and lifecycle flows | Full pipeline and service interaction coverage |
| Fixtures | 20+ | — | Sample .facts.json files, sample documents |

For the v1.7.1 release path, the targeted regression suite covering config, queue orchestration, runtime limits, pipeline performance, and the new SPEC-061 handoff behavior passed with **114 tests green**.

### Key Test Areas

- **Facts loader** — ingestion, versioning, superseding, idempotency
- **Topology edges** — signal detection, traversal, edge weights
- **Behavioral signatures** — embedding assembly, vector storage/retrieval
- **GraphQL API** — query resolution, filtering, pagination
- **MCP server** — tool execution, lazy loading, transport modes
- **Git onboarding** — clone, branch detection, incremental diffs
- **Cross-repo tools** — multi-repo discovery, shared artifacts
- **Clustering** — Louvain algorithm, cluster assignment, scoring
- **Repository pattern** — data access abstraction consistency
- **Error handling** — typed exceptions, graceful degradation
- **Full pipeline** — end-to-end: import → edges → vectors → docs → clusters → query

### CI/CD Pipeline

GitHub Actions workflow (`ecle-test.yml`) with 3 jobs:
1. **Lint** — `ruff check` + `ruff format --check`
2. **Unit Tests** — Python 3.11, expanded unit suite with coverage reporting
3. **Integration Tests** — full pipeline validation

Triggered on push to `main`/`develop` and all pull requests.

---

## 19. What's Not Yet Built

| Component | Status | Why Deferred |
|-----------|--------|-------------|
| Graph database (Neo4j) | Planned | SQL recursive CTEs work for MVP; Neo4j for enterprise scale |
| Learning loops | Stubbed | Interaction ledger, confidence voting deferred to Phase 5 |
| Security (auth/tenancy) | Stubbed | Enterprise-only, deferred to Phase 4 |
| Monitoring (Prometheus) | Stubbed | Kubernetes-only, deferred to Phase 4 |
| Frontend JavaScript | Not started | Backend API ready; UI is a separate project |
| AMF materialization | Spec written | `ecle materialize --format amf` pending SPEC-027 implementation |
| Cross-repo completeness | Spec written | 5 compounding failures identified (ADR-027), fix designed |
| Tuxedo field extraction | Spec written | 6 field visibility gaps identified (ADR-029) |

---

## 20. Development Timeline

| Week | Focus | Key Deliverables |
|------|-------|-----------------|
| **1** | Foundation | Structured DB schema, SQLite backend, facts loader, topology edges, behavioral signatures, GraphQL, CLI, MCP server. **All 8 specs implemented + tested.** |
| **2** | Onboarding | Git repo onboarding, continuous git integration, document onboarding, web UI, settings/config. |
| **3** | Hardening | Shared artifact registry, cross-repo MCP tools, gap closure, error handling, Louvain clustering, smart chat router, CI/CD pipeline. |
| **4** | Services | Remote MCP server (HTTP), GraphQL API as standalone service, Web UI as standalone service, repository pattern refactor. |
| **5** | Advanced | Webhook receiver, CI pipeline templates, materialize/AMF export, branch-aware queries, artifact store, service call graph, repo purge, Tuxedo field extraction, centralized logging, ECLE home runtime, CPG trigger, import queue. |
| **6** | Emerging | Source vector layer, unified onboard model, service boundary architecture. |
| **7** | Two-phase runtime + packaging | Two-phase extraction workflow, deployment packaging, cross-tier linker, change intelligence, prompt enrichment, and auto-classify onboarding. |
| **8** | Guardrails + completion work | Query guards, non-code artifact promotion, service-index child jobs, parallel workers, queue start control, runtime limits, pipeline performance instrumentation, and SPEC-061 auto-job handoff. |

---

## 21. Key Design Principles

1. **FACT quality standard** — Fast, Accurate, Complete, Timely governs every response
2. **No LLM on the commit path** — ingestion is pure computation, zero hallucination risk
3. **Hybrid storage** — right backend for each query type, not one-size-fits-all
4. **GraphQL composes** — one question = one query across multiple backends
5. **O(changed_files) ingestion** — 5 files changed in a 1M-file repo costs the same as 1K
6. **Views, not stages** — PVG/KAG/SOL output computed on demand, always fresh
7. **Vector distance IS the fingerprint** — cosine distance captures behavioral change
8. **Backward compatibility** — `ecle materialize --format amf` produces AMF output
9. **Clusters are proposals** — Louvain output goes through stabilization rules
10. **Zero hallucination** — every LLM claim must cite structural evidence
11. **Spec-first development** — 61 specifications written before code, with strict review against architectural contracts

---

## 22. File Structure

```
ECLE-EnterpriseContinousLearningEngine/
├── CLAUDE.md                               # Project constitution
├── pyproject.toml                          # Dependencies, build config, ruff rules
│
├── constitution/
│   ├── contracts/                          # 11 architectural contracts
│   │   ├── fact-architecture.md
│   │   ├── fact-data-slicing.md
│   │   ├── fact-mcp-server.md
│   │   ├── fact-query-engine.md
│   │   ├── grounding-contract.md
│   │   ├── staleness-contract.md
│   │   ├── confidence-contract.md
│   │   ├── testing-contract.md
│   │   ├── vector-design.md
│   │   ├── coding-standards.md
│   │   └── sdlc-contract.md
│   └── decisions/                          # 37 ADRs (ADR-001 through ADR-037)
│
├── specs/                                  # 61 specifications
│   ├── week-1/  (SPEC-001 — SPEC-008)     # Foundation
│   ├── week-2/  (SPEC-009 — SPEC-013)     # Onboarding + integration
│   ├── week-3/  (SPEC-014 — SPEC-020)     # Hardening + cross-repo
│   ├── week-4/  (SPEC-021 — SPEC-024)     # Service separation
│   ├── week-5/  (SPEC-025 — SPEC-037)     # Advanced features
│   ├── week-6/  (SPEC-038 — SPEC-042)     # Emerging
│   ├── week-7/  (SPEC-044 — SPEC-051)     # Two-phase runtime + packaging
│   └── week-8/  (SPEC-053 — SPEC-061)     # Guardrails + cross-tier completion
│
├── src/ecle/                               # 79 Python source files
│   ├── backends/
│   │   ├── structured/                     # SQLAlchemy backend (SQLite/PostgreSQL)
│   │   │   ├── interface.py                # IStructuredBackend protocol
│   │   │   ├── models.py                   # Pydantic models
│   │   │   ├── schema.py                   # DDL schema definitions
│   │   │   ├── sqlite.py                   # SQLite implementation
│   │   │   └── sqlalchemy_backend.py       # SQLAlchemy Core backend
│   │   ├── vector/
│   │   │   └── chromadb_store.py           # ChromaDB wrapper
│   │   └── graph/                          # Planned (Neo4j)
│   │
│   ├── ingestion/                          # FACT ingestion pipeline
│   │   ├── facts_loader.py                 # CPG facts → structured DB
│   │   ├── topology.py                     # Edge computation (10 signals)
│   │   ├── behavioral_sig.py               # Embedding text assembly
│   │   ├── embedding_pipeline.py           # File + function vectors
│   │   ├── document_chunker.py             # Document splitting
│   │   ├── document_embedder.py            # Document → vector
│   │   ├── source_embedder.py              # Source code → vector
│   │   ├── incremental.py                  # Git diff → incremental ingest
│   │   ├── artiecle_registry.py            # Cross-repo shared artifacts
│   │   ├── artiecle_store.py               # Source + facts storage
│   │   ├── service_index.py                # Service call graph
│   │   ├── field_extractor.py              # Tuxedo field extraction
│   │   ├── job_queue.py                    # Async import queue
│   │   ├── validation.py                   # Fact validation
│   │   ├── post_process.py                 # Clustering, statistics
│   │   └── readers/                        # Document format readers
│   │       ├── base.py, ddl_reader.py, docx_reader.py,
│   │       ├── markdown_reader.py, plaintext_reader.py
│   │
│   ├── connectors/                         # Source integration
│   │   ├── git.py                          # GitConnector
│   │   ├── git_watcher.py                  # Polling-based change detection
│   │   └── webhook_receiver.py             # GitHub webhook handler
│   │
│   ├── cpg/
│   │   └── client.py                       # CPG client (local + service mode)
│   │
│   ├── query/                              # Query engine
│   │   ├── app.py                          # GraphQL FastAPI application
│   │   ├── schema.py                       # Strawberry GraphQL types
│   │   ├── chat_router.py                  # Intent detection + routing
│   │   └── resolvers/                      # Per-type resolvers
│   │
│   ├── mcp/                                # MCP server
│   │   ├── server.py                       # 10+ tools, stdio + HTTP
│   │   └── cross_repo.py                   # Cross-repo discovery
│   │
│   ├── clustering/
│   │   └── louvain.py                      # Community detection
│   │
│   ├── onboarding/
│   │   └── pipeline.py                     # Source → CPG → ingest orchestration
│   │
│   ├── config/                             # Configuration
│   │   ├── settings.py                     # Lite/Full/Enterprise modes
│   │   ├── loader.py                       # YAML + env resolution
│   │   └── factory.py                      # Backend factory
│   │
│   ├── ui/                                 # Web interface
│   │   ├── routes.py                       # FastAPI routes
│   │   ├── api_client.py                   # GraphQL HTTP client
│   │   ├── progress.py                     # Progress tracking
│   │   └── templates/                      # Jinja2 HTML templates
│   │
│   ├── learning/                           # Planned: interaction ledger
│   ├── security/                           # Planned: auth, tenancy
│   ├── monitoring/                         # Planned: metrics
│   │
│   ├── cli.py                              # ecle CLI entry point
│   ├── errors.py                           # Typed exception hierarchy
│   └── logging_config.py                   # Structured JSON logging
│
├── tests/                                  # 38 test files, 10,018 LOC
│   ├── unit/                               # 32 unit test files
│   ├── integration/                        # 5 integration test files
│   ├── fixtures/                           # Sample facts + documents
│   └── conftest.py                         # Shared fixtures
│
├── .claude/agents/                         # 21 Claude Code agent definitions
├── .github/
│   ├── agents/                             # 21 GitHub Copilot agent definitions
│   └── workflows/ecle-test.yml            # CI/CD pipeline
│
├── AMF-Agentic Migration Factory/          # Original AMF codebase (preserved)
├── AMF/                                    # Active AMF with Joern pipeline
│   ├── stages/{cpg,fss,fps,pvg,kag,mig,dom,fed,sol}/
│   ├── amf_mcp/                            # AMF MCP server + tools
│   ├── layer0_pipeline.py                  # CPG extraction orchestrator
│   ├── layer1_pipeline.py                  # Facts processing orchestrator
│   └── docs/                               # 50+ AMF documentation files
│
├── docs/
│   └── Enterprise Continuously Learning Engine.md  # 282KB origin architecture spec
│
└── scripts/
    └── spec_sync_check.py                  # Spec ↔ implementation validator
```
