"""
check_consistency — Validates cross-reference consistency across the project.

Implements: Contract 01 §11 (project tooling)
Catches: stale contract/ADR counts, missing references in agents/memory/README.

Run: uv run python scripts/check_consistency.py
Exit: 0 = consistent, 1 = drift detected
"""

from __future__ import annotations

import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
CONTRACTS_DIR = ROOT / "constitution" / "contracts"
ADRS_DIR = ROOT / "constitution" / "adrs"
AGENTS_DIR = ROOT / ".github" / "agents"
MEMORY_DIR = ROOT / ".github" / "memory"
CONSTITUTION_README = ROOT / "constitution" / "README.md"

# Files that reference counts/ranges and must stay in sync
TRACKED_FILES: list[Path] = [
    *sorted(AGENTS_DIR.glob("*.agent.md")),
    MEMORY_DIR / "constitution-digest.md",
    MEMORY_DIR / "phase-status.md",
    CONSTITUTION_README,
    ROOT / ".github" / "copilot-instructions.md",
]


def count_contracts() -> int:
    """Count actual contract files (NN-*.md pattern)."""
    return len([f for f in CONTRACTS_DIR.iterdir() if re.match(r"\d{2}-", f.name)])


def count_adrs() -> int:
    """Count actual ADR files (ADR-NNNN-*.md, excluding template)."""
    return len(
        [f for f in ADRS_DIR.iterdir() if re.match(r"ADR-\d{4}-", f.name)]
    )


def get_max_contract_number() -> int:
    """Get the highest contract number."""
    numbers = [
        int(f.name[:2])
        for f in CONTRACTS_DIR.iterdir()
        if re.match(r"\d{2}-", f.name)
    ]
    return max(numbers) if numbers else 0


def get_max_adr_number() -> int:
    """Get the highest ADR number."""
    numbers = [
        int(re.match(r"ADR-(\d{4})-", f.name).group(1))  # type: ignore[union-attr]
        for f in ADRS_DIR.iterdir()
        if re.match(r"ADR-\d{4}-", f.name)
    ]
    return max(numbers) if numbers else 0


def check_count_references(
    content: str, filepath: Path, actual_contracts: int, actual_adrs: int
) -> list[str]:
    """Check for stale numeric references to contract/ADR counts."""
    errors: list[str] = []

    # Pattern: "N contracts" or "N contract" (where N is a number)
    for match in re.finditer(r"\b(\d+)\s+contracts?\b", content, re.IGNORECASE):
        num = int(match.group(1))
        if num != actual_contracts and num > 10:  # ignore small numbers in prose
            errors.append(
                f"{filepath.relative_to(ROOT)}: says '{num} contracts' "
                f"but actual count is {actual_contracts}"
            )

    # Pattern: "N ADRs" or "N ADR"
    for match in re.finditer(r"\b(\d+)\s+ADRs?\b", content):
        num = int(match.group(1))
        if num != actual_adrs and num > 10:
            errors.append(
                f"{filepath.relative_to(ROOT)}: says '{num} ADRs' "
                f"but actual count is {actual_adrs}"
            )

    return errors


def check_range_references(
    content: str,
    filepath: Path,
    max_contract: int,
    max_adr: int,
) -> list[str]:
    """Check for stale range references like 'contracts/01-16' or 'ADR-0001-0027'."""
    errors: list[str] = []

    # Pattern: contracts/01-NN or contracts/01–NN
    for match in re.finditer(r"contracts/01[-–](\d{2})", content):
        upper = int(match.group(1))
        if upper != max_contract:
            errors.append(
                f"{filepath.relative_to(ROOT)}: range 'contracts/01-{match.group(1)}' "
                f"but max contract is {max_contract:02d}"
            )

    # Pattern: ADR-0001-0NNN (range, not a single ADR reference)
    # Heuristic: "ADRs/ADR-0001-0NNN" or "adrs/ADR-0001-0NNN" indicates a range
    for match in re.finditer(r"[Aa][Dd][Rr]s?/ADR-0001[-–](\d{4})", content):
        upper = int(match.group(1))
        if upper != max_adr:
            errors.append(
                f"{filepath.relative_to(ROOT)}: range 'ADR-0001-{match.group(1)}' "
                f"but max ADR is {max_adr:04d}"
            )

    return errors


def check_digest_coverage(actual_contracts: int) -> list[str]:
    """Verify constitution-digest.md has a section for every contract."""
    errors: list[str] = []
    digest_path = MEMORY_DIR / "constitution-digest.md"
    if not digest_path.exists():
        errors.append("Missing: .github/memory/constitution-digest.md")
        return errors

    content = digest_path.read_text(encoding="utf-8")
    for i in range(1, actual_contracts + 1):
        # Look for "Contract NN" or "## NN" or "## Contract NN"
        pattern = rf"\b(Contract\s+{i:02d}|Contract\s+{i}\b|##\s*{i:02d})"
        if not re.search(pattern, content):
            errors.append(
                f".github/memory/constitution-digest.md: "
                f"missing section for Contract {i:02d}"
            )

    return errors


def check_validator_contract_list() -> list[str]:
    """Verify validator agent references all contract files."""
    errors: list[str] = []
    validator_path = AGENTS_DIR / "validator.agent.md"
    if not validator_path.exists():
        errors.append("Missing: .github/agents/validator.agent.md")
        return errors

    content = validator_path.read_text(encoding="utf-8")
    for contract_file in sorted(CONTRACTS_DIR.iterdir()):
        if not re.match(r"\d{2}-", contract_file.name):
            continue
        if contract_file.name not in content:
            errors.append(
                f".github/agents/validator.agent.md: "
                f"does not reference {contract_file.name}"
            )

    return errors


def check_readme_completeness(actual_contracts: int, actual_adrs: int) -> list[str]:
    """Verify constitution/README.md lists all contracts and ADRs."""
    errors: list[str] = []
    if not CONSTITUTION_README.exists():
        errors.append("Missing: constitution/README.md")
        return errors

    content = CONSTITUTION_README.read_text(encoding="utf-8")

    for i in range(1, actual_contracts + 1):
        pattern = rf"\b{i:02d}-"
        if not re.search(pattern, content):
            errors.append(
                f"constitution/README.md: missing Contract {i:02d}"
            )

    for adr_file in sorted(ADRS_DIR.iterdir()):
        if not re.match(r"ADR-\d{4}-", adr_file.name):
            continue
        # Check stem (without .md) appears in README
        stem = adr_file.stem
        if stem not in content:
            errors.append(
                f"constitution/README.md: missing {stem}"
            )

    return errors


def main() -> int:
    """Run all consistency checks. Returns exit code."""
    actual_contracts = count_contracts()
    actual_adrs = count_adrs()
    max_contract = get_max_contract_number()
    max_adr = get_max_adr_number()

    print(f"Found: {actual_contracts} contracts (max={max_contract:02d}), "
          f"{actual_adrs} ADRs (max={max_adr:04d})")

    all_errors: list[str] = []

    # Check count and range references in all tracked files
    for filepath in TRACKED_FILES:
        if not filepath.exists():
            all_errors.append(f"Missing tracked file: {filepath.relative_to(ROOT)}")
            continue
        content = filepath.read_text(encoding="utf-8")
        all_errors.extend(
            check_count_references(content, filepath, actual_contracts, actual_adrs)
        )
        all_errors.extend(
            check_range_references(content, filepath, max_contract, max_adr)
        )

    # Structural checks
    all_errors.extend(check_digest_coverage(actual_contracts))
    all_errors.extend(check_validator_contract_list())
    all_errors.extend(check_readme_completeness(actual_contracts, actual_adrs))

    if all_errors:
        print(f"\n✗ {len(all_errors)} consistency issue(s) found:\n")
        for err in all_errors:
            print(f"  • {err}")
        print("\nFix these before committing. See Contract 01 §11.")
        return 1

    print("✓ All cross-references consistent.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
