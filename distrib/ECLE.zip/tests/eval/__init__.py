# Eval suite tests — behavioral contracts, hard CI gates.
# Contract 03 §6: failure blocks release.
