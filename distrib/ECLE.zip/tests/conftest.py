"""
conftest — Shared pytest fixtures for ECLE test suites.

Implements: Contract 03
Reads:  Nothing
Writes: Temporary test directories (via tmp_path)

Provides common fixtures used across unit and integration tests.
All fixtures are session-scoped or function-scoped as appropriate.
No global mutable state (Contract 10 §A7).
"""

from __future__ import annotations

import pytest

from ecle.config import Settings


@pytest.fixture
def ecle_settings(tmp_path):
    """Provide a Settings instance pointed at temp directories.

    Ensures tests never touch real data (Contract 03 §3: no I/O to real paths).
    """
    return Settings(
        data_root=tmp_path / "data",
        log_dir=tmp_path / "logs",
        artifact_store_path=tmp_path / "artifacts",
        language_packs_path=tmp_path / "packs",
        models_path=tmp_path / "models",
        database_url="sqlite:///:memory:",
        otel_sdk_disabled=True,
    )
