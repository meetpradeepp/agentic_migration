# Implements: SPEC-0009. Tests: get_structured_db, get_artifact_store
"""Unit tests for backend factory functions."""

from __future__ import annotations

from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from ecle.config import settings
from ecle.core.backends import get_artifact_store, get_structured_db
from ecle.core.backends.local_artifact_store import LocalArtifactStore
from ecle.core.backends.postgresql_db import PostgreSQLStructuredDB
from ecle.core.exceptions import DBConnectionError, InvalidConfigError


def test_get_structured_db_returns_postgresql_instance() -> None:
    """AC-12: STRUCTURED_BACKEND='postgresql' returns PostgreSQLStructuredDB."""
    with patch.object(settings, "structured_backend", "postgresql"):
        with patch.object(settings, "database_url", "postgresql://u:p@localhost/db"):
            with patch("psycopg2.connect", return_value=MagicMock()) as mock_connect:
                db = get_structured_db()

    assert isinstance(db, PostgreSQLStructuredDB)
    mock_connect.assert_called_once()


def test_get_structured_db_raises_on_unknown_backend() -> None:
    """AC-13: unknown structured backend raises InvalidConfigError."""
    with patch.object(settings, "structured_backend", "unknown"):
        with pytest.raises(InvalidConfigError):
            get_structured_db()


def test_get_structured_db_raises_db_connection_error_on_psycopg2_failure() -> None:
    """Factory wraps psycopg2 errors as DBConnectionError."""
    import psycopg2  # type: ignore[import]

    with patch.object(settings, "structured_backend", "postgresql"):
        with patch.object(settings, "database_url", "postgresql://u:p@localhost/db"):
            with patch("psycopg2.connect", side_effect=psycopg2.Error("connect failed")):
                with pytest.raises(DBConnectionError):
                    get_structured_db()


def test_get_artifact_store_returns_local_instance(tmp_path: Path) -> None:
    """AC-14: ARTIFACT_BACKEND='local' returns LocalArtifactStore."""
    with patch.object(settings, "artifact_backend", "local"):
        with patch.object(settings, "artifact_store_path", str(tmp_path)):
            store = get_artifact_store()

    assert isinstance(store, LocalArtifactStore)


def test_get_artifact_store_raises_on_unknown_backend() -> None:
    """AC-15: unknown artifact backend raises InvalidConfigError."""
    with patch.object(settings, "artifact_backend", "unknown"):
        with pytest.raises(InvalidConfigError):
            get_artifact_store()
