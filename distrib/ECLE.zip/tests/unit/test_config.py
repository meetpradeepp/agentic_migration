# Implements: SPEC-0001
"""Unit tests for ecle.config.Settings.

Tests: T-19 to T-22 (SPEC-0001 acceptance criteria AC-13, AC-14, error handling row 8).
All tests are no-I/O, < 100ms (Contract 03 §2).
"""

from __future__ import annotations

import pytest


def test_settings_all_18_defaults_correct(monkeypatch) -> None:
    """T-19: All 18 canonical fields have correct defaults (AC-13)."""
    # Clear any env vars that could override defaults
    for var in [
        "ECLE_TIER", "ECLE_ARTIFACT_BACKEND", "ECLE_KAFKA_BOOTSTRAP_SERVERS",
        "ECLE_LOG_LEVEL", "ECLE_VECTOR_BACKEND", "ECLE_TOPOLOGY_BACKEND",
        "ECLE_STRUCTURED_BACKEND", "ECLE_DATABASE_URL",
    ]:
        monkeypatch.delenv(var, raising=False)

    from ecle.config import Settings

    s = Settings()
    assert s.tier == "dev"
    assert s.vector_backend == "qdrant"
    assert s.vector_backend_url == "http://localhost:6333"
    assert s.topology_backend == "neo4j"
    assert s.topology_backend_url == "bolt://localhost:7687"
    assert s.structured_backend == "postgresql"
    assert s.artifact_backend == "local"
    assert s.kafka_bootstrap_servers == "localhost:9092"
    assert s.log_level == "INFO"


def test_settings_artifact_backend_env_override(monkeypatch) -> None:
    """T-20: ECLE_ARTIFACT_BACKEND env var overrides default (AC-14)."""
    monkeypatch.setenv("ECLE_ARTIFACT_BACKEND", "s3")

    from ecle.config import Settings

    s = Settings()
    assert s.artifact_backend == "s3"
    # Other fields retain defaults
    assert s.kafka_bootstrap_servers == "localhost:9092"


def test_settings_kafka_bootstrap_servers_env_override(monkeypatch) -> None:
    """T-21: ECLE_KAFKA_BOOTSTRAP_SERVERS env var overrides default (AC-14)."""
    monkeypatch.setenv("ECLE_KAFKA_BOOTSTRAP_SERVERS", "broker1:9092,broker2:9092")

    from ecle.config import Settings

    s = Settings()
    assert s.kafka_bootstrap_servers == "broker1:9092,broker2:9092"


def test_settings_invalid_type_raises_validation_error(monkeypatch) -> None:
    """T-22: Passing a bad type raises Pydantic ValidationError (Error handling row 8)."""
    from pydantic import ValidationError

    from ecle.config import Settings

    with pytest.raises((ValidationError, Exception)):
        # kafka_poll_timeout_ms must be an int; passing a non-numeric string fails
        Settings(kafka_poll_timeout_ms="not-an-int")  # type: ignore[arg-type]
