# Implements: SPEC-0011
"""Unit tests for NamingChecker — deterministic AST-based ECLE001 naming gate.

Tests: check_source() happy paths (T1–T7), required finding fields (T11),
       syntax-error source (T13), scope-evaluation exception (T16).

All tests: no I/O to real paths, no external network calls, < 100ms each (Contract 03 §2).
"""

from __future__ import annotations

import json
import textwrap

import pytest

from ecle.linting.naming_checker import NamingChecker, NamingFinding, ScopeMetrics


# ---------------------------------------------------------------------------
# Shared checker factory — uses spec-defined defaults
# ---------------------------------------------------------------------------

def _make_checker() -> NamingChecker:
    return NamingChecker(
        non_trivial_logical_lines=10,
        non_trivial_local_variables=3,
        ambiguous_denylist=("tmp", "val", "obj", "res", "ret", "data", "item", "thing", "x1", "y1"),
        allowlist=("i", "j", "k", "x", "y", "z", "n", "m", "_"),
    )


# ---------------------------------------------------------------------------
# T1 — one-letter symbol flagged in non-trivial scope (>= 10 logical lines)
# ---------------------------------------------------------------------------

class TestT1OneLtterSymbolFlaggedInNonTrivialScope:
    """AC-1: one-letter business variable `x` flagged when scope has >= 10 logical lines."""

    SOURCE = textwrap.dedent("""\
        def process_records(records):
            x = []
            total = 0
            count = 0
            for record in records:
                if record.get("active"):
                    total += record["value"]
                    count += 1
                    x.append(record["id"])
            if count == 0:
                return None
            avg = total / count
            return {"ids": x, "avg": avg}
    """)

    def test_check_source_flags_one_letter_symbol_in_non_trivial_scope(self) -> None:
        checker = _make_checker()
        findings = checker.check_source(path="fake.py", source_text=self.SOURCE)

        symbols_found = [f.symbol for f in findings]
        assert "x" in symbols_found, (
            f"Expected ECLE001 finding for symbol 'x' in non-trivial scope; got: {symbols_found}"
        )
        matching = [f for f in findings if f.symbol == "x"]
        assert len(matching) >= 1
        assert matching[0].rule_id == "ECLE001"
        assert "non-trivial" in matching[0].reason.lower() or "business" in matching[0].reason.lower() or "one" in matching[0].reason.lower()


# ---------------------------------------------------------------------------
# T2 — one-letter symbol skipped in trivial scope (< 10 lines, no control flow)
# ---------------------------------------------------------------------------

class TestT2OneLtterSymbolSkippedInTrivialScope:
    """AC-2: symbol `x` not flagged when scope has 2 lines and no control flow/boundary calls."""

    SOURCE = textwrap.dedent("""\
        def add_one(value):
            x = value + 1
            return x
    """)

    def test_check_source_skips_one_letter_symbol_in_trivial_scope(self) -> None:
        checker = _make_checker()
        findings = checker.check_source(path="fake.py", source_text=self.SOURCE)

        symbols_found = [f.symbol for f in findings]
        assert "x" not in symbols_found, (
            f"Expected no finding for 'x' in trivial scope; got findings: {findings}"
        )


# ---------------------------------------------------------------------------
# T3 — ambiguous denylist symbol flagged
# ---------------------------------------------------------------------------

class TestT3AmbiguousDenylistSymbolFlagged:
    """AC-3: `tmp` used for parsed payload is flagged with ECLE001 in non-trivial scope."""

    SOURCE = textwrap.dedent("""\
        def parse_payload(raw_bytes):
            tmp = raw_bytes.decode("utf-8")
            parts = tmp.split(",")
            result = {}
            for part in parts:
                if "=" in part:
                    key, sep, value = part.partition("=")
                    result[key.strip()] = value.strip()
            if not result:
                raise ValueError("empty payload")
            return result
    """)

    def test_check_source_flags_ambiguous_denylist_symbol(self) -> None:
        checker = _make_checker()
        findings = checker.check_source(path="fake.py", source_text=self.SOURCE)

        symbols_found = [f.symbol for f in findings]
        assert "tmp" in symbols_found, (
            f"Expected ECLE001 finding for denylist symbol 'tmp'; got: {symbols_found}"
        )
        matching = [f for f in findings if f.symbol == "tmp"]
        assert matching[0].rule_id == "ECLE001"


# ---------------------------------------------------------------------------
# T4 — tiny loop index `i` allowed (loop body <= 3 lines, not used outside loop)
# ---------------------------------------------------------------------------

class TestT4TinyLoopIndexAllowed:
    """AC-4: `i` as a loop index in a <= 3-line loop body is not flagged."""

    SOURCE = textwrap.dedent("""\
        def build_index(items):
            index_map = {}
            offset_total = 0
            position_count = 0
            for i, item in enumerate(items):
                index_map[i] = item
            for record in items:
                if record.get("active"):
                    offset_total += record["offset"]
                    position_count += 1
            if position_count == 0:
                return index_map
            return index_map
    """)

    def test_check_source_allows_tiny_loop_index(self) -> None:
        checker = _make_checker()
        findings = checker.check_source(path="fake.py", source_text=self.SOURCE)

        symbols_found = [f.symbol for f in findings]
        assert "i" not in symbols_found, (
            f"Expected no finding for tiny loop index 'i'; got findings for: {symbols_found}"
        )


# ---------------------------------------------------------------------------
# T5 — loop index `i` flagged when used outside loop body
# ---------------------------------------------------------------------------

class TestT5LoopIndexFlaggedWhenUsedOutsideLoop:
    """AC-5: `i` reused after its loop in non-trivial scope triggers ECLE001."""

    SOURCE = textwrap.dedent("""\
        def find_last_active(items):
            last_index = -1
            found_count = 0
            active_sum = 0
            for i, item in enumerate(items):
                if item.get("active"):
                    last_index = i
                    found_count += 1
                    active_sum += item.get("value", 0)
            return last_index, found_count, active_sum, i
    """)

    def test_check_source_flags_loop_index_used_outside_loop(self) -> None:
        checker = _make_checker()
        findings = checker.check_source(path="fake.py", source_text=self.SOURCE)

        symbols_found = [f.symbol for f in findings]
        assert "i" in symbols_found, (
            f"Expected ECLE001 finding for 'i' used outside loop; got: {symbols_found}"
        )


# ---------------------------------------------------------------------------
# T6 — math-only symbol `x` not flagged
# ---------------------------------------------------------------------------

class TestT6MathOnlySymbolNotFlagged:
    """AC-6: `x` used only in numeric expressions in non-trivial scope is not flagged."""

    SOURCE = textwrap.dedent("""\
        import math

        def compute_distance(point_a, point_b, point_c, point_d):
            x = point_b[0] - point_a[0]
            y = point_d[1] - point_c[1]
            hypotenuse = math.sqrt(x * x + y * y)
            scaled = hypotenuse * 2.0
            rounded = round(scaled, 4)
            absolute = abs(rounded)
            clamped = max(0.0, min(1.0, absolute))
            normalized = clamped / (clamped + 1.0)
            return normalized
    """)

    def test_check_source_allows_math_only_symbol_context(self) -> None:
        checker = _make_checker()
        findings = checker.check_source(path="fake.py", source_text=self.SOURCE)

        symbols_found = [f.symbol for f in findings]
        assert "x" not in symbols_found, (
            f"Expected no finding for math-only 'x'; got findings for: {symbols_found}"
        )


# ---------------------------------------------------------------------------
# T7 — byte-identical report for same input (determinism)
# ---------------------------------------------------------------------------

class TestT7ReportIsByteIdenticalForSameInput:
    """AC-7: two runs on same source produce identical JSON output (stable sort)."""

    SOURCE = textwrap.dedent("""\
        def aggregate_stats(records):
            tmp = []
            total = 0
            count = 0
            for record in records:
                if record.get("active"):
                    tmp.append(record["value"])
                    total += record["value"]
                    count += 1
            if count == 0:
                return {}
            return {"mean": total / count, "values": tmp}
    """)

    def test_report_is_byte_identical_for_same_input(self) -> None:
        checker = _make_checker()

        findings_run1 = checker.check_source(path="stable.py", source_text=self.SOURCE)
        findings_run2 = checker.check_source(path="stable.py", source_text=self.SOURCE)

        def serialise(findings: list[NamingFinding]) -> str:
            return json.dumps(
                [
                    {
                        "path": f.path,
                        "line": f.line,
                        "column": f.column,
                        "symbol": f.symbol,
                        "reason": f.reason,
                        "rule_id": f.rule_id,
                        "scope_kind": f.scope_kind,
                        "scope_metrics": {
                            "logical_lines": f.scope_metrics.logical_lines,
                            "local_variable_count": f.scope_metrics.local_variable_count,
                            "has_control_flow": f.scope_metrics.has_control_flow,
                            "has_boundary_call": f.scope_metrics.has_boundary_call,
                        },
                    }
                    for f in sorted(findings, key=lambda g: (g.path, g.line, g.column, g.symbol))
                ],
                sort_keys=True,
            )

        assert serialise(findings_run1) == serialise(findings_run2), (
            "Two identical runs produced different output — non-deterministic checker"
        )


# ---------------------------------------------------------------------------
# T11 — finding payload contains all required fields (non-empty)
# ---------------------------------------------------------------------------

class TestT11FindingSchemaContainsRequiredFields:
    """AC-11: each NamingFinding has path, line, symbol, reason, rule_id all populated."""

    SOURCE = textwrap.dedent("""\
        def extract_metadata(raw_record):
            tmp = raw_record.get("meta", {})
            parts = list(tmp.items())
            result = {}
            for key, value in parts:
                if key.startswith("_"):
                    continue
                result[key] = str(value)
            if not result:
                return None
            return result
    """)

    def test_finding_schema_contains_required_fields(self) -> None:
        checker = _make_checker()
        findings = checker.check_source(path="schema_check.py", source_text=self.SOURCE)

        assert len(findings) >= 1, "Expected at least one finding from denylist/one-letter violation"
        for finding in findings:
            assert isinstance(finding.path, str) and finding.path, "path must be non-empty string"
            assert isinstance(finding.line, int) and finding.line > 0, "line must be positive int"
            assert isinstance(finding.symbol, str) and finding.symbol, "symbol must be non-empty string"
            assert isinstance(finding.reason, str) and finding.reason, "reason must be non-empty string"
            assert isinstance(finding.rule_id, str) and finding.rule_id, "rule_id must be non-empty string"
            assert finding.rule_id in ("ECLE001", "ECLE001-PARSE"), f"Unexpected rule_id: {finding.rule_id}"
            assert isinstance(finding.scope_kind, str) and finding.scope_kind, "scope_kind must be non-empty string"
            metrics = finding.scope_metrics
            assert isinstance(metrics, ScopeMetrics), "scope_metrics must be ScopeMetrics instance"
            assert isinstance(metrics.logical_lines, int)
            assert isinstance(metrics.local_variable_count, int)
            assert isinstance(metrics.has_control_flow, bool)
            assert isinstance(metrics.has_boundary_call, bool)


# ---------------------------------------------------------------------------
# T13 — syntax-error source emits ECLE001-PARSE finding
# ---------------------------------------------------------------------------

class TestT13SyntaxErrorSourceEmitsParseRule:
    """Error row 2: Python source with syntax error gets ECLE001-PARSE diagnostic."""

    BROKEN_SOURCE = textwrap.dedent("""\
        def broken_function(:
            pass
    """)

    def test_syntax_error_source_emits_parse_rule_and_exits_two(self) -> None:
        checker = _make_checker()
        findings = checker.check_source(path="broken.py", source_text=self.BROKEN_SOURCE)

        parse_findings = [f for f in findings if f.rule_id == "ECLE001-PARSE"]
        assert len(parse_findings) >= 1, (
            f"Expected ECLE001-PARSE finding for syntax-error source; got: {findings}"
        )
        assert parse_findings[0].path == "broken.py"


# ---------------------------------------------------------------------------
# T16 — scope evaluation exception returns deterministic error diagnostic
# ---------------------------------------------------------------------------

class TestT16ScopeEvaluationExceptionReturnsDiagnostic:
    """Error row 5: internal checker exception during scope eval yields deterministic diagnostic."""

    def test_scope_evaluation_exception_returns_exit_two_with_diagnostic(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        checker = _make_checker()

        # Force an internal error by patching the private scope-analysis method
        # with a callable that raises unconditionally.
        import ecle.linting.naming_checker as checker_module

        original_analyse = getattr(checker_module, "_analyse_scope", None)

        def _exploding_analyse(*_args, **_kwargs):  # noqa: ANN001, ANN202
            raise RuntimeError("injected scope error for testing")

        # Patch via module attribute — works regardless of how the method is structured
        if original_analyse is not None:
            monkeypatch.setattr(checker_module, "_analyse_scope", _exploding_analyse)
        else:
            # If the method is not a module-level function, patch _compute_scope_metrics
            # which is the chokepoint for scope evaluation.
            monkeypatch.setattr(
                checker_module.NamingChecker,
                "_compute_scope_metrics",
                lambda *_args, **_kwargs: (_ for _ in ()).throw(RuntimeError("injected")),
            )

        source = textwrap.dedent("""\
            def some_function(param):
                result = param + 1
                return result
        """)

        findings = checker.check_source(path="error_probe.py", source_text=source)

        # Should not propagate the exception; should return diagnostic finding(s)
        error_findings = [
            f for f in findings
            if f.rule_id in ("ECLE001-PARSE", "ECLE001-ERROR") or "error" in f.reason.lower()
        ]
        assert len(error_findings) >= 1, (
            f"Expected an error diagnostic finding on scope exception; got: {findings}"
        )
