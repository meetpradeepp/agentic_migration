# Unit tests — mirrors src/ecle/ structure.
# Contract 03 §3: no I/O, <100ms, deterministic.
