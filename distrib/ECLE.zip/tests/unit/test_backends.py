# Implements: SPEC-0001
"""Unit tests for backend factory function stubs.

Tests: T-37 (SPEC-0001 AC-21).
All tests are no-I/O, < 100ms (Contract 03 §2).
"""

from __future__ import annotations

from ecle.core.backends import (
    get_artifact_store,
    get_structured_db,
    get_topology_graph,
    get_vector_store,
)


def test_factory_functions_are_callable() -> None:
    """T-37: All four factory functions pass callable() check (AC-21)."""
    assert callable(get_structured_db)
    assert callable(get_artifact_store)
    assert callable(get_vector_store)
    assert callable(get_topology_graph)
