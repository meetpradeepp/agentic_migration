"""
test_rule_loader — Unit tests for RuleLoader: YAML loading, pattern compilation,
applies_to pre-filter, tier ordering, and error handling.

Implements: SPEC-0010
Tests: RuleLoader.load(), RuleLoader.get_annotation_rules(), CompiledAnnotationRule
"""

from __future__ import annotations

import re
import textwrap
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from ecle.config import Settings
from ecle.core.exceptions import DBConnectionError, ECLEBaseError
from ecle.workers.semantic_interpreter.rule_loader import (
    CompiledAnnotationRule,
    RuleLoader,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

_VALID_GLOB_RULE_YAML = textwrap.dedent("""\
    rules:
      - rule_id: tuxedo-service-handler
        version: 1
        scope: annotation
        target: function_facts
        match:
          field: function_name
          pattern: "par_*"
        annotate:
          platform: Tuxedo
          type: service_handler
        confidence: 1.0
""")

_VALID_RULE_WITH_APPLIES_TO_YAML = textwrap.dedent("""\
    rules:
      - rule_id: tuxedo-filtered-handler
        version: 1
        scope: annotation
        target: function_facts
        applies_to:
          platform: Tuxedo
        match:
          field: function_name
          pattern: "par_*"
        annotate:
          platform: Tuxedo
          type: service_handler
        confidence: 1.0
""")

_INVALID_RULE_YAML = textwrap.dedent("""\
    rules:
      - version: 1
        scope: annotation
        target: function_facts
        match:
          field: function_name
          pattern: "bad_*"
        annotate:
          platform: Bad
        confidence: 0.5
""")

_TENANT_RULE_YAML = textwrap.dedent("""\
    rules:
      - rule_id: tenant-specific-rule
        version: 1
        scope: annotation
        target: function_facts
        match:
          field: function_name
          pattern: "tenant_fn_*"
        annotate:
          type: tenant_type
        confidence: 0.6
""")

_REPO_RULE_YAML = textwrap.dedent("""\
    rules:
      - rule_id: repo-specific-rule
        version: 1
        scope: annotation
        target: function_facts
        match:
          field: function_name
          pattern: "repo_fn_*"
        annotate:
          type: repo_type
        confidence: 0.7
""")


def _make_settings(rules_dir: Path) -> Settings:
    """Return a Settings instance with semantic_rules_base_path pointing to rules_dir."""
    return Settings(
        semantic_rules_base_path=rules_dir,
        semantic_rules_artifact_path_prefix="semantic_rules/",
    )


def _make_loader(
    rules_dir: Path,
    *,
    db: MagicMock | None = None,
    artifact_store: MagicMock | None = None,
) -> RuleLoader:
    """Factory helper: create a RuleLoader with mock dependencies."""
    if db is None:
        db = MagicMock()
        db.execute.return_value = [
            {"platform": None, "primary_language": None, "repo_type": None}
        ]
    if artifact_store is None:
        artifact_store = MagicMock()
        artifact_store.exists.return_value = False
    return RuleLoader(
        db=db,
        artifact_store=artifact_store,
        settings=_make_settings(rules_dir),
    )


# ---------------------------------------------------------------------------
# T-10: load() reads a valid base rules YAML; compiled_pattern is re.Pattern
# ---------------------------------------------------------------------------


def test_load_reads_base_rules_yaml_and_compiles_pattern(tmp_path: Path) -> None:
    """Verifies AC-16 pre-condition: load() compiles SingleFactMatch pattern to re.Pattern."""
    # Given
    rules_dir = tmp_path / "base_rules"
    rules_dir.mkdir()
    (rules_dir / "tuxedo.yaml").write_text(_VALID_GLOB_RULE_YAML, encoding="utf-8")

    loader = _make_loader(rules_dir)

    # When
    loader.load()

    # Then
    assert len(loader._base_rules) == 1
    compiled_rule = loader._base_rules[0]
    assert isinstance(compiled_rule, CompiledAnnotationRule)
    assert isinstance(compiled_rule.compiled_pattern, re.Pattern)
    assert compiled_rule.tier == "base"
    assert compiled_rule.rule.rule_id == "tuxedo-service-handler"


# ---------------------------------------------------------------------------
# T-11: get_annotation_rules() returns [] when platform does not match
# ---------------------------------------------------------------------------


def test_get_annotation_rules_returns_empty_on_platform_mismatch(
    tmp_path: Path,
) -> None:
    """Verifies AC-05: rule filtered out when repositories.platform != applies_to.platform."""
    # Given
    rules_dir = tmp_path / "base_rules"
    rules_dir.mkdir()
    (rules_dir / "tuxedo.yaml").write_text(
        _VALID_RULE_WITH_APPLIES_TO_YAML, encoding="utf-8"
    )

    db = MagicMock()
    db.execute.return_value = [
        {"platform": "Spring", "primary_language": None, "repo_type": None}
    ]
    artifact_store = MagicMock()
    artifact_store.exists.return_value = False

    loader = _make_loader(rules_dir, db=db, artifact_store=artifact_store)
    loader.load()

    # When
    result = loader.get_annotation_rules(repo_id="repo1", tenant_id="t1")

    # Then
    assert result == []


# ---------------------------------------------------------------------------
# T-12: get_annotation_rules() returns all rules when no applies_to set
# ---------------------------------------------------------------------------


def test_get_annotation_rules_returns_all_when_no_applies_to(tmp_path: Path) -> None:
    """Verifies AC-07: rule with no applies_to is never filtered."""
    # Given
    rules_dir = tmp_path / "base_rules"
    rules_dir.mkdir()
    (rules_dir / "rules.yaml").write_text(_VALID_GLOB_RULE_YAML, encoding="utf-8")

    db = MagicMock()
    db.execute.return_value = [
        {"platform": "SomePlatform", "primary_language": "COBOL", "repo_type": "batch"}
    ]
    artifact_store = MagicMock()
    artifact_store.exists.return_value = False

    loader = _make_loader(rules_dir, db=db, artifact_store=artifact_store)
    loader.load()

    # When
    result = loader.get_annotation_rules(repo_id="repo1", tenant_id="t1")

    # Then — one base rule returned despite non-matching repo metadata
    assert len(result) == 1
    assert result[0].rule.rule_id == "tuxedo-service-handler"


# ---------------------------------------------------------------------------
# T-13: repo-tier before tenant-tier before base-tier in returned list
# ---------------------------------------------------------------------------


def test_get_annotation_rules_tier_order_repo_before_tenant_before_base(
    tmp_path: Path,
) -> None:
    """Verifies AC-08: tier precedence pre-sort — repo first, tenant second, base third."""
    # Given
    rules_dir = tmp_path / "base_rules"
    rules_dir.mkdir()
    (rules_dir / "base.yaml").write_text(_VALID_GLOB_RULE_YAML, encoding="utf-8")

    db = MagicMock()
    db.execute.return_value = [
        {"platform": None, "primary_language": None, "repo_type": None}
    ]

    artifact_store = MagicMock()

    def _exists(path: str) -> bool:
        return path in {
            "semantic_rules/t1/tenant.yaml",
            "semantic_rules/t1/repo1/repo.yaml",
        }

    def _read_bytes(path: str) -> bytes:
        if path == "semantic_rules/t1/tenant.yaml":
            return _TENANT_RULE_YAML.encode()
        if path == "semantic_rules/t1/repo1/repo.yaml":
            return _REPO_RULE_YAML.encode()
        raise FileNotFoundError(path)

    artifact_store.exists.side_effect = _exists
    artifact_store.read.side_effect = _read_bytes

    loader = _make_loader(rules_dir, db=db, artifact_store=artifact_store)
    loader.load()

    # When
    result = loader.get_annotation_rules(repo_id="repo1", tenant_id="t1")

    # Then — 3 rules total; order must be repo, tenant, base
    assert len(result) == 3
    tiers = [r.tier for r in result]
    assert tiers == ["repo", "tenant", "base"], f"Expected ['repo','tenant','base'], got {tiers}"


# ---------------------------------------------------------------------------
# T-14: within same tier, higher confidence appears first
# ---------------------------------------------------------------------------

_TWO_BASE_RULES_YAML = textwrap.dedent("""\
    rules:
      - rule_id: low-confidence-rule
        version: 1
        scope: annotation
        target: function_facts
        match:
          field: function_name
          pattern: "fn_low_*"
        annotate:
          type: low_type
        confidence: 0.7
      - rule_id: high-confidence-rule
        version: 1
        scope: annotation
        target: function_facts
        match:
          field: function_name
          pattern: "fn_high_*"
        annotate:
          type: high_type
        confidence: 0.9
""")


def test_get_annotation_rules_higher_confidence_first_within_tier(
    tmp_path: Path,
) -> None:
    """Verifies AC-09: within same tier, descending confidence order."""
    # Given
    rules_dir = tmp_path / "base_rules"
    rules_dir.mkdir()
    (rules_dir / "rules.yaml").write_text(_TWO_BASE_RULES_YAML, encoding="utf-8")

    loader = _make_loader(rules_dir)
    loader.load()

    # When
    result = loader.get_annotation_rules(repo_id="repo1", tenant_id="t1")

    # Then — high-confidence rule first
    assert len(result) == 2
    assert result[0].rule.rule_id == "high-confidence-rule"
    assert result[1].rule.rule_id == "low-confidence-rule"


# ---------------------------------------------------------------------------
# T-15: load() logs WARN + skips invalid YAML; valid sibling still loaded
# ---------------------------------------------------------------------------


def test_load_warns_and_skips_invalid_file_loads_valid_sibling(
    tmp_path: Path,
    caplog: pytest.LogCaptureFixture,
) -> None:
    """Verifies AC-16, Contract 20 §7.1: invalid file skipped; valid sibling loaded."""
    # Given
    rules_dir = tmp_path / "base_rules"
    rules_dir.mkdir()
    (rules_dir / "a_invalid.yaml").write_text(_INVALID_RULE_YAML, encoding="utf-8")
    (rules_dir / "b_valid.yaml").write_text(_VALID_GLOB_RULE_YAML, encoding="utf-8")

    loader = _make_loader(rules_dir)

    # When
    import logging

    with caplog.at_level(logging.WARNING, logger="ecle.workers.semantic_interpreter.rule_loader"):
        loader.load()

    # Then
    warn_messages = [r.message for r in caplog.records if r.levelname == "WARNING"]
    assert any("a_invalid.yaml" in msg for msg in warn_messages), (
        f"Expected WARN about a_invalid.yaml; got: {warn_messages}"
    )
    assert len(loader._base_rules) == 1
    assert loader._base_rules[0].rule.rule_id == "tuxedo-service-handler"


# ---------------------------------------------------------------------------
# T-16: compiled_pattern is re.Pattern after load(); re.compile never called
#        during get_annotation_rules()
# ---------------------------------------------------------------------------


def test_pattern_compiled_only_in_load_not_during_get_annotation_rules(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Verifies Contract 20 §5: patterns compiled once at load time only."""
    # Given
    rules_dir = tmp_path / "base_rules"
    rules_dir.mkdir()
    (rules_dir / "rules.yaml").write_text(_VALID_GLOB_RULE_YAML, encoding="utf-8")

    loader = _make_loader(rules_dir)
    loader.load()

    # Guard: compiled_pattern is already a re.Pattern after load()
    assert isinstance(loader._base_rules[0].compiled_pattern, re.Pattern)

    # Spy: intercept re.compile calls within the rule_loader module
    import ecle.workers.semantic_interpreter.rule_loader as _rl_mod

    compile_calls: list[str] = []
    real_compile = re.compile

    def _spy(pattern: str, *args: object, **kwargs: object) -> re.Pattern:  # type: ignore[type-arg]
        compile_calls.append(str(pattern))
        return real_compile(pattern, *args, **kwargs)  # type: ignore[arg-type]

    monkeypatch.setattr(_rl_mod.re, "compile", _spy)

    # When
    loader.get_annotation_rules(repo_id="repo1", tenant_id="t1")

    # Then
    assert compile_calls == [], (
        f"re.compile was called during get_annotation_rules: {compile_calls}"
    )


# ---------------------------------------------------------------------------
# T-32: applies_to.platform match is case-insensitive (AC-06)
# ---------------------------------------------------------------------------


def test_get_annotation_rules_platform_match_is_case_insensitive(
    tmp_path: Path,
) -> None:
    """Verifies AC-06: 'tuxedo' matches rule with applies_to.platform='Tuxedo'."""
    # Given
    rules_dir = tmp_path / "base_rules"
    rules_dir.mkdir()
    (rules_dir / "tuxedo.yaml").write_text(
        _VALID_RULE_WITH_APPLIES_TO_YAML, encoding="utf-8"
    )

    db = MagicMock()
    # Repo has platform in lowercase — should still match rule's "Tuxedo"
    db.execute.return_value = [
        {"platform": "tuxedo", "primary_language": None, "repo_type": None}
    ]
    artifact_store = MagicMock()
    artifact_store.exists.return_value = False

    loader = _make_loader(rules_dir, db=db, artifact_store=artifact_store)
    loader.load()

    # When
    result = loader.get_annotation_rules(repo_id="repo1", tenant_id="t1")

    # Then — case-insensitive match succeeds
    assert len(result) == 1
    assert result[0].rule.rule_id == "tuxedo-filtered-handler"


# ---------------------------------------------------------------------------
# T-35: tenant YAML from artifact store fails validation → WARN logged;
#        file skipped; remaining valid base rules returned; ECLEBaseError NOT raised
# ---------------------------------------------------------------------------


def test_get_annotation_rules_skips_invalid_tenant_yaml_logs_warn(
    tmp_path: Path,
    caplog: pytest.LogCaptureFixture,
) -> None:
    """Verifies Error handling row 2, Contract 20 §7.1: invalid tenant YAML → WARN, skip."""
    # Given
    rules_dir = tmp_path / "base_rules"
    rules_dir.mkdir()
    (rules_dir / "base.yaml").write_text(_VALID_GLOB_RULE_YAML, encoding="utf-8")

    db = MagicMock()
    db.execute.return_value = [
        {"platform": None, "primary_language": None, "repo_type": None}
    ]

    artifact_store = MagicMock()

    def _exists(path: str) -> bool:
        return path == "semantic_rules/t1/tenant.yaml"

    def _read_bytes(path: str) -> bytes:
        # Return YAML that fails RuleFile validation (missing rule_id)
        return _INVALID_RULE_YAML.encode()

    artifact_store.exists.side_effect = _exists
    artifact_store.read.side_effect = _read_bytes

    loader = _make_loader(rules_dir, db=db, artifact_store=artifact_store)
    loader.load()

    # When / Then — must not raise ECLEBaseError
    import logging

    with caplog.at_level(
        logging.WARNING,
        logger="ecle.workers.semantic_interpreter.rule_loader",
    ):
        result = loader.get_annotation_rules(repo_id="repo1", tenant_id="t1")

    warn_messages = [r.message for r in caplog.records if r.levelname == "WARNING"]
    assert any(
        "semantic_rules/t1/tenant.yaml" in msg for msg in warn_messages
    ), f"Expected WARN for tenant.yaml; got: {warn_messages}"

    # Base rule still returned
    assert len(result) == 1
    assert result[0].rule.rule_id == "tuxedo-service-handler"


# ---------------------------------------------------------------------------
# T-36: db.execute() raises DBConnectionError → ECLEBaseError propagated
# ---------------------------------------------------------------------------


def test_get_annotation_rules_db_connection_error_propagated(tmp_path: Path) -> None:
    """Verifies Error handling row 3: DBConnectionError → ECLEBaseError propagated."""
    # Given
    rules_dir = tmp_path / "base_rules"
    rules_dir.mkdir()
    (rules_dir / "base.yaml").write_text(_VALID_GLOB_RULE_YAML, encoding="utf-8")

    db = MagicMock()
    db.execute.side_effect = DBConnectionError("simulated DB outage")

    artifact_store = MagicMock()
    artifact_store.exists.return_value = False

    loader = _make_loader(rules_dir, db=db, artifact_store=artifact_store)
    loader.load()

    # When / Then
    with pytest.raises(ECLEBaseError):
        loader.get_annotation_rules(repo_id="repo1", tenant_id="t1")
