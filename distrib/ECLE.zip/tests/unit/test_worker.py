"""
test_worker — Unit tests for SemanticInterpreter worker.

Implements: SPEC-0010
Tests: SemanticInterpreter.process (file and repo modes), worker_name/input_topic
       properties, FactsAnnotatedPayload, cross-worker isolation
"""

from __future__ import annotations

import ast
from pathlib import Path
from typing import Any
from unittest.mock import MagicMock

import pytest

from ecle.core.exceptions import DBConnectionError, ECLEBaseError
from ecle.workers.semantic_interpreter.evaluator import AnnotationResult
from ecle.workers.semantic_interpreter.worker import SemanticInterpreter


# ---------------------------------------------------------------------------
# Shared helpers
# ---------------------------------------------------------------------------


def _make_result(
    *,
    target_id: str = "uuid-1",
    rule_id: str = "rule-a",
    target_type: str = "function_facts",
) -> AnnotationResult:
    """Return a minimal AnnotationResult for test use."""
    return AnnotationResult(
        target_type=target_type,  # type: ignore[arg-type]
        target_id=target_id,
        rule_id=rule_id,
        rule_version=1,
        platform="Tuxedo",
        domain_entity=None,
        type="service_handler",
        group=None,
        role=None,
        confidence=1.0,
    )


def _build_worker(
    mode: str,
    *,
    consumer: Any,
    producer: Any,
    db: Any,
    rule_loader: Any,
    evaluator: Any,
) -> SemanticInterpreter:
    """Construct SemanticInterpreter with the given dependencies."""
    from ecle.config import Settings  # noqa: PLC0415

    return SemanticInterpreter(
        consumer=consumer,
        producer=producer,
        db=db,
        settings=Settings(),
        rule_loader=rule_loader,
        evaluator=evaluator,
        mode=mode,  # type: ignore[arg-type]
    )


def _plain_mocks() -> tuple[MagicMock, MagicMock, MagicMock, MagicMock, MagicMock]:
    """Return (consumer, producer, db, rule_loader, evaluator) with empty defaults."""
    consumer = MagicMock()
    producer = MagicMock()
    db = MagicMock()
    rule_loader = MagicMock()
    evaluator = MagicMock()
    rule_loader.get_annotation_rules.return_value = []
    evaluator.evaluate_file.return_value = []
    evaluator.evaluate_repo.return_value = []
    return consumer, producer, db, rule_loader, evaluator


# ---------------------------------------------------------------------------
# T-27: worker_name and input_topic for mode='file'   (AC-19)
# ---------------------------------------------------------------------------


def test_mode_file_worker_name_and_topic() -> None:
    """Verifies AC-19: mode='file' → worker_name='semantic_interpreter_file', input_topic='ecle.file.stored'."""
    consumer, producer, db, rule_loader, evaluator = _plain_mocks()
    worker = _build_worker(
        "file",
        consumer=consumer,
        producer=producer,
        db=db,
        rule_loader=rule_loader,
        evaluator=evaluator,
    )
    assert worker.worker_name == "semantic_interpreter_file"
    assert worker.input_topic == "ecle.file.stored"


# ---------------------------------------------------------------------------
# T-28: worker_name and input_topic for mode='repo'   (AC-19)
# ---------------------------------------------------------------------------


def test_mode_repo_worker_name_and_topic() -> None:
    """Verifies AC-19: mode='repo' → worker_name='semantic_interpreter_repo', input_topic='ecle.repo.indexed'."""
    consumer, producer, db, rule_loader, evaluator = _plain_mocks()
    worker = _build_worker(
        "repo",
        consumer=consumer,
        producer=producer,
        db=db,
        rule_loader=rule_loader,
        evaluator=evaluator,
    )
    assert worker.worker_name == "semantic_interpreter_repo"
    assert worker.input_topic == "ecle.repo.indexed"


# ---------------------------------------------------------------------------
# T-29: db.upsert() raises DBConnectionError → ECLEBaseError propagated;
#        offset NOT committed; producer.produce() NOT called   (AC-13)
# ---------------------------------------------------------------------------


def test_db_upsert_failure_propagates_ecle_base_error() -> None:
    """Verifies AC-13: DBConnectionError propagated as ECLEBaseError; no produce; no commit."""
    consumer = MagicMock()
    producer = MagicMock()
    db = MagicMock()
    rule_loader = MagicMock()
    evaluator = MagicMock()

    rule_loader.get_annotation_rules.return_value = []
    evaluator.evaluate_file.return_value = [_make_result()]
    db.upsert.side_effect = DBConnectionError("DB unreachable")

    worker = _build_worker(
        "file",
        consumer=consumer,
        producer=producer,
        db=db,
        rule_loader=rule_loader,
        evaluator=evaluator,
    )

    with pytest.raises(ECLEBaseError):
        worker.process({"file_id": "f1", "repo_id": "r1", "tenant_id": "t1"})

    producer.produce.assert_not_called()
    consumer.commit.assert_not_called()


# ---------------------------------------------------------------------------
# T-30: file mode calls db.upsert + consumer.commit; producer never called  (AC-12b)
# ---------------------------------------------------------------------------


def test_file_trigger_does_not_emit_facts_annotated() -> None:
    """Verifies AC-12b: file mode writes annotations and commits; produce() never called."""
    consumer = MagicMock()
    producer = MagicMock()
    db = MagicMock()
    rule_loader = MagicMock()
    evaluator = MagicMock()

    rule_loader.get_annotation_rules.return_value = []
    evaluator.evaluate_file.return_value = [_make_result()]

    worker = _build_worker(
        "file",
        consumer=consumer,
        producer=producer,
        db=db,
        rule_loader=rule_loader,
        evaluator=evaluator,
    )

    worker.process({"file_id": "f1", "repo_id": "r1", "tenant_id": "t1"})

    db.upsert.assert_called_once()
    consumer.commit.assert_called_once()
    producer.produce.assert_not_called()


# ---------------------------------------------------------------------------
# T-31: only upsert("semantic_annotations") called; no execute on Layer-0 tables  (AC-21)
# ---------------------------------------------------------------------------


def test_layer0_fact_tables_not_modified() -> None:
    """Verifies AC-21: upsert only targets 'semantic_annotations'; no execute on fact tables."""
    consumer = MagicMock()
    producer = MagicMock()
    db = MagicMock()
    rule_loader = MagicMock()
    evaluator = MagicMock()

    rule_loader.get_annotation_rules.return_value = []
    evaluator.evaluate_file.return_value = [
        _make_result(target_id="uuid-1", rule_id="rule-a"),
        _make_result(target_id="uuid-2", rule_id="rule-b"),
    ]

    worker = _build_worker(
        "file",
        consumer=consumer,
        producer=producer,
        db=db,
        rule_loader=rule_loader,
        evaluator=evaluator,
    )
    worker.process({"file_id": "f1", "repo_id": "r1", "tenant_id": "t1"})

    # Every upsert call must target only 'semantic_annotations'
    _forbidden_tables = {"function_facts", "file_tables", "function_table_ops"}
    for upsert_call in db.upsert.call_args_list:
        table = upsert_call.args[0] if upsert_call.args else upsert_call.kwargs.get("table")
        assert table == "semantic_annotations", (
            f"Unexpected upsert target table: {table!r}"
        )

    # Worker must not call db.execute() directly against fact tables
    for exec_call in db.execute.call_args_list:
        sql_str = str(exec_call.args[0] if exec_call.args else "").lower()
        for forbidden_table in _forbidden_tables:
            assert forbidden_table not in sql_str, (
                f"Direct execute() found referencing forbidden table {forbidden_table!r}"
            )


# ---------------------------------------------------------------------------
# T-38: producer.produce() raises exception in mode='repo' → ECLEBaseError;
#        second process() re-runs upsert idempotently   (AC error handling row 8)
# ---------------------------------------------------------------------------


def test_kafka_produce_failure_retries_safely() -> None:
    """Verifies error handling row 8: produce fails → ECLEBaseError; retry re-runs upsert."""
    consumer = MagicMock()
    producer = MagicMock()
    db = MagicMock()
    rule_loader = MagicMock()
    evaluator = MagicMock()

    rule_loader.get_annotation_rules.return_value = []
    evaluator.evaluate_repo.return_value = [_make_result()]

    worker = _build_worker(
        "repo",
        consumer=consumer,
        producer=producer,
        db=db,
        rule_loader=rule_loader,
        evaluator=evaluator,
    )

    # First call: produce raises → ECLEBaseError propagated; offset NOT committed
    producer.produce.side_effect = RuntimeError("Kafka connection refused")
    with pytest.raises(ECLEBaseError):
        worker.process({"repo_id": "r1", "tenant_id": "t1"})

    upsert_count_after_first_call = db.upsert.call_count
    assert upsert_count_after_first_call > 0, (
        "db.upsert() must be called before producer.produce()"
    )
    consumer.commit.assert_not_called()

    # Second call: produce succeeds — upsert called again (idempotent re-run is safe)
    producer.produce.side_effect = None
    worker.process({"repo_id": "r1", "tenant_id": "t1"})

    assert db.upsert.call_count > upsert_count_after_first_call, (
        "db.upsert() must be called again on second process() invocation"
    )


# ---------------------------------------------------------------------------
# T-39: no cross-worker imports in semantic_interpreter package  (AC-20, ADR-0027)
# ---------------------------------------------------------------------------


def test_no_cross_worker_imports() -> None:
    """Verifies AC-20: semantic_interpreter has zero imports from other worker modules."""
    package_dir = (
        Path(__file__).resolve().parent.parent.parent
        / "src" / "ecle" / "workers" / "semantic_interpreter"
    )
    assert package_dir.is_dir(), f"Package directory not found: {package_dir}"

    for py_file in sorted(package_dir.glob("*.py")):
        source = py_file.read_text(encoding="utf-8")
        tree = ast.parse(source, filename=str(py_file))

        for node in ast.walk(tree):
            if isinstance(node, ast.ImportFrom) and node.module:
                module = node.module
                # Imports from ecle.workers.* that are NOT semantic_interpreter or worker_base
                if (
                    module.startswith("ecle.workers.")
                    and "semantic_interpreter" not in module
                    and "worker_base" not in module
                ):
                    pytest.fail(
                        f"Forbidden cross-worker import {module!r} in {py_file.name} "
                        f"(ADR-0027, AC-20)"
                    )
            elif isinstance(node, ast.Import):
                for alias in node.names:
                    module_name = alias.name
                    if (
                        module_name.startswith("ecle.workers.")
                        and "semantic_interpreter" not in module_name
                        and "worker_base" not in module_name
                    ):
                        pytest.fail(
                            f"Forbidden cross-worker import {module_name!r} in {py_file.name} "
                            f"(ADR-0027, AC-20)"
                        )
