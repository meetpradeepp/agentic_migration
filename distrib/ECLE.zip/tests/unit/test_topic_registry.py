# Implements: SPEC-0008
"""Unit tests for ecle.events.topic_registry — pure functions and ensure_topics()."""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest

from ecle.events.topic_registry import (
    PHASE_1_TOPICS,
    TOPIC_DOCUMENT_STORED,
    TOPIC_FACTS_ANNOTATED,
    TOPIC_FILE_IR_PRODUCED,
    TOPIC_FILE_STORED,
    TOPIC_REPO_DETECTED,
    TOPIC_REPO_INDEXED,
    TOPIC_REPO_IR_PRODUCED,
    TOPIC_REPO_STRUCTURAL_COMPLETE,
    TOPIC_SOURCE_RECEIVED,
    TOPIC_SOURCE_SCANNED,
    consumer_group,
    dlq_topic,
    ensure_topics,
)


# ---------------------------------------------------------------------------
# AC-13  dlq_topic()
# ---------------------------------------------------------------------------


def test_dlq_topic_format() -> None:
    """AC-13: dlq_topic strips 'ecle.' prefix and prepends 'ecle.dlq.'."""
    assert dlq_topic("ecle.file.ir_produced") == "ecle.dlq.file.ir_produced"


def test_dlq_topic_format_second_constant() -> None:
    """AC-13: prefix insertion is general, not hardcoded to one topic."""
    assert dlq_topic("ecle.source.received") == "ecle.dlq.source.received"


# ---------------------------------------------------------------------------
# AC-14  consumer_group()
# ---------------------------------------------------------------------------


def test_consumer_group_format() -> None:
    """AC-14: consumer_group returns 'ecle.<worker_name>'."""
    assert consumer_group("parse_repo") == "ecle.parse_repo"


# ---------------------------------------------------------------------------
# AC-17  PHASE_1_TOPICS completeness
# ---------------------------------------------------------------------------


def test_phase1_topics_all_present_no_duplicates() -> None:
    """AC-17: PHASE_1_TOPICS has exactly 9 entries with no duplicates."""
    assert len(PHASE_1_TOPICS) == 9
    assert len(set(PHASE_1_TOPICS)) == 9
    expected = {
        TOPIC_SOURCE_RECEIVED,
        TOPIC_REPO_DETECTED,
        TOPIC_REPO_STRUCTURAL_COMPLETE,
        TOPIC_FILE_IR_PRODUCED,
        TOPIC_REPO_IR_PRODUCED,
        TOPIC_SOURCE_SCANNED,
        TOPIC_FILE_STORED,
        TOPIC_REPO_INDEXED,
        TOPIC_DOCUMENT_STORED,
    }
    assert set(PHASE_1_TOPICS) == expected


# ---------------------------------------------------------------------------
# AC-15  ensure_topics() — idempotent on existing topics
# ---------------------------------------------------------------------------


def test_ensure_topics_idempotent_on_existing() -> None:
    """AC-15: ensure_topics() handles TOPIC_ALREADY_EXISTS without raising."""
    from confluent_kafka import KafkaError, KafkaException  # type: ignore[import]

    err = MagicMock()
    err.code.return_value = KafkaError.TOPIC_ALREADY_EXISTS
    future = MagicMock()
    future.result.side_effect = KafkaException(err)

    admin = MagicMock()
    admin.create_topics.return_value = {"ecle.source.received": future}

    # Must not raise
    ensure_topics(admin, ["ecle.source.received"])
    admin.create_topics.assert_called_once()


# ---------------------------------------------------------------------------
# AC-16  ensure_topics() — creates a missing topic
# ---------------------------------------------------------------------------


def test_ensure_topics_creates_missing_topic() -> None:
    """AC-16: ensure_topics() calls create_topics and resolves success future."""
    future = MagicMock()
    future.result.return_value = None  # success

    admin = MagicMock()
    admin.create_topics.return_value = {"ecle.repo.detected": future}

    ensure_topics(admin, ["ecle.repo.detected"])

    admin.create_topics.assert_called_once()
    future.result.assert_called_once()


# ---------------------------------------------------------------------------
# error-handling: ensure_topics() propagates KafkaException
# ---------------------------------------------------------------------------


def test_ensure_topics_raises_on_broker_error() -> None:
    """ensure_topics() propagates KafkaException from create_topics()."""
    from confluent_kafka import KafkaException  # type: ignore[import]

    admin = MagicMock()
    admin.create_topics.side_effect = KafkaException("broker unreachable")

    with pytest.raises(KafkaException):
        ensure_topics(admin, ["ecle.source.received"])
