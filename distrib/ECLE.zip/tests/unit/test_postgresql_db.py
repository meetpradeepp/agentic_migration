# Implements: SPEC-0009. Tests: PostgreSQLStructuredDB.execute
"""Unit tests for PostgreSQLStructuredDB.execute()."""

from __future__ import annotations

from unittest.mock import MagicMock

import pytest

from ecle.core.backends.postgresql_db import PostgreSQLStructuredDB
from ecle.core.exceptions import DBConnectionError


def _make_db() -> tuple[PostgreSQLStructuredDB, MagicMock, MagicMock]:
    conn = MagicMock()
    cur = MagicMock()
    conn.cursor.return_value.__enter__.return_value = cur
    db = PostgreSQLStructuredDB(conn)
    return db, conn, cur


# ---------------------------------------------------------------------------
# AC-01  execute() appends tenant filter with WHERE clause
# ---------------------------------------------------------------------------


def test_execute_appends_tenant_filter_with_where_clause() -> None:
    db, _conn, cur = _make_db()
    cur.description = [("id",), ("name",)]
    cur.fetchall.return_value = [("t1", "Tenant 1")]

    sql = "SELECT id, name FROM tenants WHERE active = true"
    db.execute(sql, [], tenant_id="t1")

    executed_sql = cur.execute.call_args[0][0]
    params = cur.execute.call_args[0][1]
    assert "WHERE active = true" in executed_sql
    assert "tenant_id = %s" in executed_sql
    assert params[-1] == "t1"


# ---------------------------------------------------------------------------
# AC-02  execute() skips tenant filter for __system__
# ---------------------------------------------------------------------------


def test_execute_no_tenant_filter_for_system() -> None:
    db, _conn, cur = _make_db()
    cur.description = [("id",)]
    cur.fetchall.return_value = [("a",)]

    sql = "SELECT id FROM worker_lifecycle"
    db.execute(sql, [], tenant_id="__system__")

    executed_sql = cur.execute.call_args[0][0]
    assert "tenant_id" not in executed_sql


# ---------------------------------------------------------------------------
# AC-20  execute() appends tenant filter when SQL has no WHERE
# ---------------------------------------------------------------------------


def test_execute_appends_tenant_filter_without_where_clause() -> None:
    db, _conn, cur = _make_db()
    cur.description = [("id",)]
    cur.fetchall.return_value = [("a",)]

    sql = "SELECT id FROM tenants"
    db.execute(sql, [], tenant_id="t1")

    executed_sql = cur.execute.call_args[0][0]
    params = cur.execute.call_args[0][1]
    assert "WHERE tenant_id = %s" in executed_sql
    assert params[-1] == "t1"


# ---------------------------------------------------------------------------
# AC-01 dict params path
# ---------------------------------------------------------------------------


def test_execute_dict_params_path() -> None:
    db, _conn, cur = _make_db()
    cur.description = [("id",)]
    cur.fetchall.return_value = [("a",)]

    sql = "SELECT id FROM tenants WHERE id = %(id)s"
    db.execute(sql, {"id": "abc"}, tenant_id="t1")

    executed_sql = cur.execute.call_args[0][0]
    params = cur.execute.call_args[0][1]
    assert "tenant_id = %(tenant_id)s" in executed_sql
    assert params["tenant_id"] == "t1"


# ---------------------------------------------------------------------------
# error-handling row
# ---------------------------------------------------------------------------


def test_execute_raises_db_connection_error_on_psycopg2_error() -> None:
    db, _conn, cur = _make_db()

    class FakePsycopgError(Exception):
        pass

    cur.execute.side_effect = FakePsycopgError("db down")

    with pytest.raises(DBConnectionError):
        db.execute("SELECT 1", [], tenant_id="t1")


# ---------------------------------------------------------------------------
# AC-04 / AC-04b / AC-04c / AC-05  upsert()
# ---------------------------------------------------------------------------


def test_upsert_fact_table_first_call_inserts_with_no_previous_id() -> None:
    """AC-04: first upsert inserts is_current=True, previous_id=None."""
    db, conn, cur = _make_db()
    cur.fetchone.return_value = None

    row = {"id": "new-id", "repo_id": "r1", "symbol": "f", "tenant_id": "t1"}
    db.upsert("function_facts", row, conflict_keys=["repo_id", "symbol"], tenant_id="t1")

    assert cur.execute.call_count == 2
    assert conn.commit.call_count == 1


def test_upsert_fact_table_second_call_supersedes_prior_row() -> None:
    """AC-04b: second upsert supersedes current row and links previous_id."""
    db, conn, cur = _make_db()
    cur.fetchone.return_value = ("prev-uuid",)

    row = {"id": "new-id", "repo_id": "r1", "symbol": "f", "tenant_id": "t1"}
    db.upsert("function_facts", row, conflict_keys=["repo_id", "symbol"], tenant_id="t1")

    assert cur.execute.call_count == 2
    assert conn.commit.call_count == 1


def test_upsert_uses_sql_identifier_not_fstring() -> None:
    """AC-04c: upsert query composition uses psycopg2.sql objects."""
    from psycopg2 import sql  # type: ignore[import]

    db, _conn, cur = _make_db()
    cur.fetchone.return_value = None

    row = {"id": "new-id", "repo_id": "r1", "symbol": "f", "tenant_id": "t1"}
    db.upsert("function_facts", row, conflict_keys=["repo_id", "symbol"], tenant_id="t1")

    first_query = cur.execute.call_args_list[0][0][0]
    assert isinstance(first_query, sql.Composed)


def test_upsert_skips_tenant_injection_for_system_table() -> None:
    """AC-05: system-table upsert uses single INSERT .. ON CONFLICT path."""
    db, conn, cur = _make_db()
    row = {"worker_name": "scan_source", "command": "run"}

    db.upsert("worker_lifecycle", row, conflict_keys=["worker_name"], tenant_id="__system__")

    assert cur.execute.call_count == 1
    assert conn.commit.call_count == 1


def test_upsert_raises_db_connection_error_on_psycopg2_error() -> None:
    """Error-handling: psycopg2.Error in upsert() is wrapped as DBConnectionError."""
    import psycopg2  # type: ignore[import]

    db, conn, cur = _make_db()
    cur.execute.side_effect = psycopg2.Error("db write failed")

    row = {"id": "new-id", "repo_id": "r1", "symbol": "f", "tenant_id": "t1"}
    with pytest.raises(DBConnectionError):
        db.upsert("function_facts", row, conflict_keys=["repo_id", "symbol"], tenant_id="t1")

    assert conn.rollback.call_count == 1
