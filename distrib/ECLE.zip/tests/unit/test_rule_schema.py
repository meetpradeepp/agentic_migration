"""
test_rule_schema — Unit tests for rule_schema Pydantic v2 models and validators.

Implements: SPEC-0010
Tests: AppliesTo, SingleFactMatch, CoOccurrenceMatch, QueryTokenMatch, RewriteAction,
       AnnotationRule, SearchRule, DisplayRule, RuleGroup, RuleFile — all model validators
"""

from __future__ import annotations

import pytest
from pydantic import ValidationError

from ecle.workers.semantic_interpreter.rule_schema import (
    AnnotationRule,
    CoOccurrenceMatch,
    DisplayRule,
    QueryTokenMatch,
    RewriteAction,
    RuleFile,
    RuleGroup,
    SearchRule,
    SingleFactMatch,
)


# ---------------------------------------------------------------------------
# T-01: Valid AnnotationRule with SingleFactMatch glob pattern
# ---------------------------------------------------------------------------


def test_annotation_rule_single_fact_glob_parses() -> None:
    """Verifies AC-15: Valid AnnotationRule with glob pattern is accepted."""
    # Given / When
    rule = AnnotationRule(
        rule_id="tuxedo-service-handler",
        version=1,
        scope="annotation",
        target="function_facts",
        match=SingleFactMatch(field="function_name", pattern="par_*"),
        annotate={"platform": "Tuxedo", "type": "service_handler"},
        confidence=1.0,
    )
    # Then
    assert rule.rule_id == "tuxedo-service-handler"
    assert rule.version == 1
    assert isinstance(rule.match, SingleFactMatch)


# ---------------------------------------------------------------------------
# T-02: Valid AnnotationRule with regex pattern + valid named-capture reference
# ---------------------------------------------------------------------------


def test_annotation_rule_single_fact_regex_named_capture_parses() -> None:
    """Verifies AC-15: AnnotationRule with valid regex named-capture reference accepted."""
    # Given / When
    rule = AnnotationRule(
        rule_id="gtban-pipeline-group",
        version=1,
        scope="annotation",
        target="function_facts",
        match=SingleFactMatch(
            field="function_name",
            pattern="re:^at(?P<group>[A-Z][a-zA-Z0-9]+)_(extract|process|report)$",
        ),
        annotate={"group": "{match.group}"},
        confidence=1.0,
    )
    # Then
    assert rule.rule_id == "gtban-pipeline-group"
    assert rule.match.pattern.startswith("re:")


# ---------------------------------------------------------------------------
# T-03: Valid AnnotationRule with CoOccurrenceMatch + target=function_table_ops
# ---------------------------------------------------------------------------


def test_annotation_rule_co_occurrence_valid_target_parses() -> None:
    """Verifies AC-18: CoOccurrenceMatch with target=function_table_ops is accepted."""
    # Given / When
    rule = AnnotationRule(
        rule_id="shared-table-group",
        version=1,
        scope="annotation",
        target="function_table_ops",
        match=CoOccurrenceMatch(table_name="*", min_functions=2),
        annotate={"type": "shared_table_group"},
        confidence=0.8,
    )
    # Then
    assert rule.rule_id == "shared-table-group"
    assert isinstance(rule.match, CoOccurrenceMatch)
    assert rule.match.min_functions == 2


# ---------------------------------------------------------------------------
# T-04: Valid SearchRule sub-form A — match + rewrite
# ---------------------------------------------------------------------------


def test_search_rule_subform_a_parses() -> None:
    """Verifies AC-17: SearchRule with match+rewrite (sub-form A) is accepted."""
    # Given / When
    rule = SearchRule(
        rule_id="tuxedo-rewrite",
        version=1,
        scope="search",
        match=QueryTokenMatch(query_token="Tuxedo"),
        rewrite=RewriteAction(filter={"platform": "Tuxedo"}),
    )
    # Then
    assert rule.rule_id == "tuxedo-rewrite"
    assert rule.match is not None
    assert rule.keyword_group is None


# ---------------------------------------------------------------------------
# T-05: Valid SearchRule sub-form B — keyword_group + members
# ---------------------------------------------------------------------------


def test_search_rule_subform_b_parses() -> None:
    """Verifies AC-17: SearchRule with keyword_group+members (sub-form B) is accepted."""
    # Given / When
    rule = SearchRule(
        rule_id="gtban-keyword-group",
        version=1,
        scope="search",
        keyword_group="GTBan",
        members=["at*GTBan*"],
        description="GTBan pipeline group",
    )
    # Then
    assert rule.keyword_group == "GTBan"
    assert rule.members == ["at*GTBan*"]
    assert rule.match is None


# ---------------------------------------------------------------------------
# T-06: SearchRule with both match AND keyword_group → ValidationError (AC-17)
# ---------------------------------------------------------------------------


def test_search_rule_both_subforms_raises() -> None:
    """Verifies AC-17: SearchRule with both match and keyword_group raises ValidationError."""
    # Given / When / Then
    with pytest.raises(ValidationError):
        SearchRule(
            rule_id="bad-search-rule",
            version=1,
            scope="search",
            match=QueryTokenMatch(query_token="Tuxedo"),
            keyword_group="GTBan",
        )


# ---------------------------------------------------------------------------
# T-07: AnnotationRule with CoOccurrenceMatch + target != function_table_ops → ValidationError (AC-18)
# ---------------------------------------------------------------------------


def test_annotation_rule_co_occurrence_wrong_target_raises() -> None:
    """Verifies AC-18: CoOccurrenceMatch with target!=function_table_ops raises ValidationError."""
    # Given / When / Then
    with pytest.raises(ValidationError):
        AnnotationRule(
            rule_id="bad-co-occur",
            version=1,
            scope="annotation",
            target="file_tables",
            match=CoOccurrenceMatch(table_name="*", min_functions=2),
            annotate={"type": "shared_table_group"},
            confidence=0.8,
        )


# ---------------------------------------------------------------------------
# T-08: RuleGroup containing a mix of AnnotationRule and SearchRule
# ---------------------------------------------------------------------------


def test_rule_group_mixed_rules_parses() -> None:
    """Verifies: RuleGroup container with mixed AnnotationRule+SearchRule parses correctly."""
    # Given / When
    group = RuleGroup(
        rule_group="tuxedo-rules",
        version=1,
        description="Tuxedo platform annotation and search rules",
        rules=[
            AnnotationRule(
                rule_id="tuxedo-handler",
                version=1,
                scope="annotation",
                target="function_facts",
                match=SingleFactMatch(field="function_name", pattern="par_*"),
                annotate={"platform": "Tuxedo"},
                confidence=1.0,
            ),
            SearchRule(
                rule_id="tuxedo-search",
                version=1,
                scope="search",
                keyword_group="Tuxedo",
                members=["par_*"],
                description="Tuxedo keyword group",
            ),
        ],
    )
    # Then
    assert group.rule_group == "tuxedo-rules"
    assert len(group.rules) == 2
    assert isinstance(group.rules[0], AnnotationRule)
    assert isinstance(group.rules[1], SearchRule)


# ---------------------------------------------------------------------------
# T-09: RuleFile with unknown scope literal → ValidationError
# ---------------------------------------------------------------------------


def test_rule_file_unknown_scope_raises() -> None:
    """Verifies: RuleFile with unknown scope literal raises ValidationError."""
    # Given / When / Then
    with pytest.raises(ValidationError):
        RuleFile(
            rules=[
                {
                    "rule_id": "bad-rule",
                    "version": 1,
                    "scope": "invalid_scope",
                    "target": "function_facts",
                    "match": {"field": "function_name", "pattern": "par_*"},
                    "annotate": {"platform": "Tuxedo"},
                    "confidence": 1.0,
                }
            ]
        )


# ---------------------------------------------------------------------------
# T-23: AnnotationRule with regex and annotate references missing named group (AC-15, [V2a])
# ---------------------------------------------------------------------------


def test_annotation_rule_regex_missing_named_group_raises() -> None:
    """Verifies AC-15: annotate ref to absent named group raises ValidationError [V2a]."""
    # Given / When / Then
    with pytest.raises(ValidationError):
        AnnotationRule(
            rule_id="bad-regex-named",
            version=1,
            scope="annotation",
            target="function_facts",
            match=SingleFactMatch(
                field="function_name",
                pattern="re:^par_(?P<group>[A-Z]+)$",
            ),
            annotate={"role": "{match.missing_group}"},
            confidence=0.9,
        )


# ---------------------------------------------------------------------------
# T-23b: AnnotationRule with regex and annotate references positional group out of range (AC-15, [V2b])
# ---------------------------------------------------------------------------


def test_annotation_rule_regex_positional_group_out_of_range_raises() -> None:
    """Verifies AC-15: annotate ref to out-of-range positional group raises ValidationError [V2b]."""
    # Given / When / Then
    with pytest.raises(ValidationError):
        AnnotationRule(
            rule_id="bad-regex-positional",
            version=1,
            scope="annotation",
            target="function_facts",
            match=SingleFactMatch(
                field="function_name",
                pattern="re:^par_([A-Z]+)$",  # 1 capture group only
            ),
            annotate={"role": "{match[5]}"},  # group 5 does not exist
            confidence=0.9,
        )
