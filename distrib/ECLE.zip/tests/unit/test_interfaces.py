# Implements: SPEC-0001
"""Unit tests for ECLE 2.0 core abstract interfaces and exception hierarchy.

Tests: IStructuredDB, IArtifactStore, ILanguagePack, IVectorStore, ITopologyGraph,
       ArtifactNotFoundError, DBConnectionError, InvalidLanguagePackError, ECLEBaseError
All tests: no I/O, < 100ms, in-memory stubs only (Contract 03 §2).
"""

from __future__ import annotations

from pathlib import Path
from typing import Any, Sequence

import pytest

from ecle.core.exceptions import (
    ArtifactNotFoundError,
    DBConnectionError,
    ECLEBaseError,
    InvalidConfigError,
    InvalidLanguagePackError,
)
from ecle.core.interfaces import (
    DetectedLayer,
    IArtifactStore,
    ILanguagePack,
    IStructuredDB,
    ITopologyGraph,
    IVectorStore,
)


# ---------------------------------------------------------------------------
# In-memory stub implementations for testing
# ---------------------------------------------------------------------------


class _StubDB(IStructuredDB):
    """Minimal IStructuredDB that records calls for assertion."""

    def __init__(self) -> None:
        self.execute_calls: list[dict[str, Any]] = []
        self.upsert_calls: list[dict[str, Any]] = []
        self._store: list[dict[str, Any]] = []

    def execute(
        self,
        sql: str,
        params: Sequence[Any] | dict[str, Any] | None = None,
        *,
        tenant_id: str,
    ) -> list[dict[str, Any]]:
        self.execute_calls.append({"sql": sql, "params": params, "tenant_id": tenant_id})
        return []

    def upsert(
        self,
        table: str,
        row: dict[str, Any],
        *,
        conflict_keys: Sequence[str],
        tenant_id: str,
    ) -> None:
        self.upsert_calls.append(
            {"table": table, "row": row, "conflict_keys": conflict_keys, "tenant_id": tenant_id}
        )
        # Simulate is_current flip: mark prior matching rows False
        for stored in self._store:
            if all(stored.get(k) == row.get(k) for k in conflict_keys):
                stored["is_current"] = False
        new_row = {**row, "is_current": True}
        self._store.append(new_row)

    def close(self) -> None:
        pass


class _StubArtifactStore(IArtifactStore):
    """In-memory IArtifactStore backed by a plain bytes dict."""

    def __init__(self) -> None:
        self._data: dict[str, bytes] = {}

    def write(self, path: str, data: bytes) -> None:
        self._data[path] = data

    def read(self, path: str) -> bytes:
        try:
            return self._data[path]
        except KeyError as exc:
            raise ArtifactNotFoundError(path) from exc

    def exists(self, path: str) -> bool:
        return path in self._data

    def delete(self, path: str) -> None:
        self._data.pop(path, None)  # idempotent


class _StubLanguagePack(ILanguagePack):
    """ILanguagePack stub that captures behaviour flags for testing."""

    def __init__(self, *, raise_in_extract: Exception | None = None) -> None:
        self._raise_in_extract = raise_in_extract

    @property
    def language_id(self) -> str:
        return "stub"

    def sanitize(self, source_bytes: bytes) -> bytes:
        # Strip UTF-8 BOM and UTF-16 LE BOM
        if source_bytes.startswith(b"\xef\xbb\xbf"):
            return source_bytes[3:]
        if source_bytes.startswith(b"\xff\xfe"):
            return source_bytes[2:]
        return source_bytes

    def extract(
        self,
        tree_or_bytes: Any,
        source_bytes: bytes,
        file_path: Path,
        language_dir: Path,
        detected_layers: list[DetectedLayer] | None = None,
    ) -> dict[str, Any]:
        result: dict[str, Any] = {
            "file_path": str(file_path),
            "extraction_errors": [],
        }
        if self._raise_in_extract is not None:
            try:
                raise self._raise_in_extract
            except Exception as exc:
                result["extraction_errors"].append(
                    {"type": type(exc).__name__, "msg": str(exc)}
                )
        return result


class _SanitizeRaisesUnicodePack(ILanguagePack):
    """ILanguagePack stub whose sanitize() raises UnicodeDecodeError."""

    @property
    def language_id(self) -> str:
        return "bad_encoding"

    def sanitize(self, source_bytes: bytes) -> bytes:
        raise UnicodeDecodeError("utf-8", b"\xff", 0, 1, "invalid start byte")

    def extract(
        self,
        tree_or_bytes: Any,
        source_bytes: bytes,
        file_path: Path,
        language_dir: Path,
        detected_layers: list[DetectedLayer] | None = None,
    ) -> dict[str, Any]:
        return {"file_path": str(file_path), "extraction_errors": []}


# ---------------------------------------------------------------------------
# T-01 / T-02: IStructuredDB abstract + concrete subclass
# ---------------------------------------------------------------------------


def test_istructureddb_is_abstract() -> None:
    """T-01: IStructuredDB cannot be instantiated directly (AC-1)."""
    with pytest.raises(TypeError):
        IStructuredDB()  # type: ignore[abstract]


def test_istructureddb_concrete_subclass_instantiates() -> None:
    """T-02: Concrete subclass with all methods can be instantiated (AC-1)."""
    db = _StubDB()
    assert db is not None


# ---------------------------------------------------------------------------
# T-03 / T-04: IStructuredDB execute() and upsert()
# ---------------------------------------------------------------------------


def test_istructureddb_execute_receives_tenant_id() -> None:
    """T-03: execute() stub records the tenant_id kwarg (AC-2)."""
    db = _StubDB()
    db.execute("SELECT 1", {"r": "R1"}, tenant_id="T1")
    assert len(db.execute_calls) == 1
    assert db.execute_calls[0]["tenant_id"] == "T1"
    assert db.execute_calls[0]["params"] == {"r": "R1"}


def test_istructureddb_upsert_idempotent_sets_is_current() -> None:
    """T-04: Second upsert flips old row to is_current=False (AC-3)."""
    db = _StubDB()
    row = {"file_path": "main.py", "repo_id": "R1", "tenant_id": "T1", "data": "v1"}
    db.upsert("file_facts", row, conflict_keys=["file_path", "repo_id"], tenant_id="T1")
    row2 = {**row, "data": "v2"}
    db.upsert("file_facts", row2, conflict_keys=["file_path", "repo_id"], tenant_id="T1")

    current = [r for r in db._store if r["is_current"] is True]
    obsolete = [r for r in db._store if r["is_current"] is False]
    assert len(current) == 1
    assert len(obsolete) == 1
    assert current[0]["data"] == "v2"


# ---------------------------------------------------------------------------
# T-05 / T-06 / T-07 / T-08 / T-09 / T-10 / T-11: IArtifactStore
# ---------------------------------------------------------------------------


def test_iartifactstore_is_abstract() -> None:
    """T-05: IArtifactStore cannot be instantiated directly (AC-4)."""
    with pytest.raises(TypeError):
        IArtifactStore()  # type: ignore[abstract]


def test_artifact_store_write_read_roundtrip() -> None:
    """T-06: read() returns exactly what was written (AC-5)."""
    store = _StubArtifactStore()
    data = b'{"facts": []}'
    store.write("t1/r1/main.py.facts.json", data)
    assert store.read("t1/r1/main.py.facts.json") == data


def test_artifact_store_read_missing_raises_artifact_not_found() -> None:
    """T-07: read() raises ArtifactNotFoundError with correct path (AC-6)."""
    store = _StubArtifactStore()
    with pytest.raises(ArtifactNotFoundError) as exc_info:
        store.read("t1/r1/ghost.facts.json")
    assert exc_info.value.path == "t1/r1/ghost.facts.json"


def test_artifact_store_exists_false_before_write() -> None:
    """T-08: exists() returns False for an absent path (AC-7)."""
    store = _StubArtifactStore()
    assert store.exists("t1/r1/missing.facts.json") is False


def test_artifact_store_exists_true_after_write() -> None:
    """T-09: exists() returns True after write() (AC-7)."""
    store = _StubArtifactStore()
    store.write("t1/r1/file.facts.json", b"{}")
    assert store.exists("t1/r1/file.facts.json") is True


def test_artifact_store_delete_idempotent_no_exception() -> None:
    """T-10: delete() on absent path does not raise (AC-8)."""
    store = _StubArtifactStore()
    store.delete("t1/r1/absent.facts.json")  # must not raise
    store.delete("t1/r1/absent.facts.json")  # second call also safe


def test_artifact_store_delete_removes_artifact() -> None:
    """T-11: after delete(), exists() returns False (AC-8)."""
    store = _StubArtifactStore()
    store.write("t1/r1/file.facts.json", b"x")
    store.delete("t1/r1/file.facts.json")
    assert store.exists("t1/r1/file.facts.json") is False


# ---------------------------------------------------------------------------
# T-12 / T-13 / T-14 / T-15 / T-16 / T-17 / T-18: ILanguagePack
# ---------------------------------------------------------------------------


def test_ilanguagepack_is_abstract() -> None:
    """T-12: ILanguagePack cannot be instantiated directly (AC-9)."""
    with pytest.raises(TypeError):
        ILanguagePack()  # type: ignore[abstract]


def test_language_pack_extract_never_raises() -> None:
    """T-13: extract() on a pack that internally raises does not propagate (AC-10)."""
    pack = _StubLanguagePack(raise_in_extract=KeyError("missing_node"))
    result = pack.extract(None, b"broken", Path("bad.py"), Path("."))
    assert isinstance(result, dict)


def test_language_pack_extract_populates_extraction_errors() -> None:
    """T-14: extraction_errors is non-empty; entry has type and msg keys (AC-10)."""
    pack = _StubLanguagePack(raise_in_extract=KeyError("missing_node"))
    result = pack.extract(None, b"broken", Path("bad.py"), Path("."))
    errors = result["extraction_errors"]
    assert len(errors) >= 1
    assert errors[0]["type"] == "KeyError"
    assert "missing_node" in errors[0]["msg"]


def test_language_pack_extract_always_has_extraction_errors_key() -> None:
    """T-15: successful extract() still returns extraction_errors: [] (AC-11)."""
    pack = _StubLanguagePack()
    result = pack.extract(object(), b"print('hi')", Path("hello.py"), Path("."))
    assert "extraction_errors" in result
    assert result["extraction_errors"] == []


def test_language_pack_extract_always_has_file_path_key() -> None:
    """T-16: result['file_path'] equals the file_path argument (AC-11)."""
    pack = _StubLanguagePack()
    result = pack.extract(object(), b"print('hi')", Path("hello.py"), Path("."))
    assert result["file_path"] == "hello.py"


def test_language_pack_sanitize_strips_utf8_bom() -> None:
    """T-17: sanitize() removes UTF-8 BOM (AC-12)."""
    pack = _StubLanguagePack()
    result = pack.sanitize(b"\xef\xbb\xbf# coding\n")
    assert result == b"# coding\n"


def test_language_pack_sanitize_strips_utf16_bom() -> None:
    """T-18: sanitize() removes UTF-16 LE BOM (AC-12)."""
    pack = _StubLanguagePack()
    result = pack.sanitize(b"\xff\xfehello")
    assert result == b"hello"


# ---------------------------------------------------------------------------
# T-27 / T-28 / T-29: Exception hierarchy
# ---------------------------------------------------------------------------


def test_artifact_not_found_error_path_attribute() -> None:
    """T-27: ArtifactNotFoundError.path attribute is preserved (AC-17)."""
    e = ArtifactNotFoundError("t1/r1/x.facts.json")
    assert e.path == "t1/r1/x.facts.json"


def test_artifact_not_found_error_message_format() -> None:
    """T-28: str(e) matches 'Artifact not found: <path>' (AC-17)."""
    e = ArtifactNotFoundError("t1/r1/x.facts.json")
    assert str(e) == "Artifact not found: t1/r1/x.facts.json"


def test_all_exceptions_are_ecle_base_subclasses() -> None:
    """T-29: All four custom exceptions inherit ECLEBaseError (AC-18)."""
    assert issubclass(ArtifactNotFoundError, ECLEBaseError)
    assert issubclass(InvalidLanguagePackError, ECLEBaseError)
    assert issubclass(DBConnectionError, ECLEBaseError)
    assert issubclass(InvalidConfigError, ECLEBaseError)


# ---------------------------------------------------------------------------
# T-32 / T-33: Exception chaining
# ---------------------------------------------------------------------------


def test_db_connection_error_chains_from_cause() -> None:
    """T-32: DBConnectionError raised with 'from exc' preserves __cause__ (Contract 01 §4)."""
    original = RuntimeError("connection refused")
    with pytest.raises(DBConnectionError) as exc_info:
        try:
            raise original
        except RuntimeError as exc:
            raise DBConnectionError("db down") from exc
    assert exc_info.value.__cause__ is original


def test_artifact_not_found_error_chains_from_cause() -> None:
    """T-33: ArtifactNotFoundError raised with 'from exc' preserves __cause__ (Contract 01 §4)."""
    original = FileNotFoundError("no such file")
    with pytest.raises(ArtifactNotFoundError) as exc_info:
        try:
            raise original
        except FileNotFoundError as exc:
            raise ArtifactNotFoundError("t1/r1/x.facts.json") from exc
    assert exc_info.value.__cause__ is original


# ---------------------------------------------------------------------------
# T-34: IStructuredDB close()
# ---------------------------------------------------------------------------


def test_istructureddb_close_callable_on_concrete_stub() -> None:
    """T-34: close() is callable on a concrete stub and does not raise."""
    db = _StubDB()
    db.close()  # must not raise


# ---------------------------------------------------------------------------
# T-35 / T-36: IVectorStore and ITopologyGraph are abstract stubs
# ---------------------------------------------------------------------------


def test_ivectorstore_is_abstract() -> None:
    """T-35: IVectorStore cannot be instantiated directly (AC-19)."""
    with pytest.raises(TypeError):
        IVectorStore()  # type: ignore[abstract]


def test_itopologygraph_is_abstract() -> None:
    """T-36: ITopologyGraph cannot be instantiated directly (AC-20)."""
    with pytest.raises(TypeError):
        ITopologyGraph()  # type: ignore[abstract]


# ---------------------------------------------------------------------------
# T-38: ILanguagePack.sanitize() raises UnicodeDecodeError
# ---------------------------------------------------------------------------


def test_language_pack_sanitize_raises_unicode_decode_error() -> None:
    """T-38: sanitize() that raises UnicodeDecodeError propagates uncaught (Error handling row 7)."""
    pack = _SanitizeRaisesUnicodePack()
    with pytest.raises(UnicodeDecodeError):
        pack.sanitize(b"\xff\xfe\x00")
