"""
test_evaluator — Unit tests for RuleEvaluator: single-fact and co-occurrence
annotation evaluation, capture-group substitution, deduplication, and error handling.

Implements: SPEC-0010
Tests: RuleEvaluator.evaluate_file(), RuleEvaluator.evaluate_repo(),
       RuleEvaluator._apply_substitution()
"""

from __future__ import annotations

import fnmatch
import re
from unittest.mock import MagicMock

import pytest

from ecle.config import Settings
from ecle.core.exceptions import PermanentWorkerError
from ecle.core.interfaces import IStructuredDB
from ecle.workers.semantic_interpreter.evaluator import AnnotationResult, RuleEvaluator
from ecle.workers.semantic_interpreter.rule_loader import CompiledAnnotationRule
from ecle.workers.semantic_interpreter.rule_schema import (
    AnnotationRule,
    CoOccurrenceMatch,
    SingleFactMatch,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_glob_rule(
    rule_id: str = "tuxedo-service-handler",
    pattern: str = "par_*",
    target: str = "function_facts",
    annotate: dict | None = None,
    confidence: float = 1.0,
    tier: str = "base",
) -> CompiledAnnotationRule:
    """Build a CompiledAnnotationRule with a glob (fnmatch) pattern."""
    if annotate is None:
        annotate = {"platform": "Tuxedo", "type": "service_handler"}
    rule = AnnotationRule(
        rule_id=rule_id,
        version=1,
        scope="annotation",
        target=target,  # type: ignore[arg-type]
        match=SingleFactMatch(field="function_name", pattern=pattern),
        annotate=annotate,
        confidence=confidence,
    )
    return CompiledAnnotationRule(
        rule=rule,
        compiled_pattern=re.compile(fnmatch.translate(pattern)),
        tier=tier,  # type: ignore[arg-type]
    )


def _make_regex_rule(
    rule_id: str = "gtban-pipeline",
    regex: str = r"^at(?P<group>[A-Z][a-zA-Z0-9]+)_(extract|process|report)$",
    target: str = "function_facts",
    annotate: dict | None = None,
    confidence: float = 1.0,
    tier: str = "base",
) -> CompiledAnnotationRule:
    """Build a CompiledAnnotationRule with a regex pattern."""
    if annotate is None:
        annotate = {"group": "{match.group}", "role": "{match[2]}", "type": "pipeline_stage"}
    rule = AnnotationRule(
        rule_id=rule_id,
        version=1,
        scope="annotation",
        target=target,  # type: ignore[arg-type]
        match=SingleFactMatch(field="function_name", pattern=f"re:{regex}"),
        annotate=annotate,
        confidence=confidence,
    )
    return CompiledAnnotationRule(
        rule=rule,
        compiled_pattern=re.compile(regex),
        tier=tier,  # type: ignore[arg-type]
    )


def _make_co_occurrence_rule(
    rule_id: str = "gl-trans-group",
    table_name_glob: str = "*",
    min_functions: int = 2,
    annotate: dict | None = None,
    confidence: float = 0.9,
    tier: str = "base",
) -> CompiledAnnotationRule:
    """Build a CompiledAnnotationRule for co-occurrence matching."""
    if annotate is None:
        annotate = {"group": "{table_name}", "type": "shared_table_group"}
    rule = AnnotationRule(
        rule_id=rule_id,
        version=1,
        scope="annotation",
        target="function_table_ops",
        match=CoOccurrenceMatch(table_name=table_name_glob, min_functions=min_functions),
        annotate=annotate,
        confidence=confidence,
    )
    return CompiledAnnotationRule(rule=rule, compiled_pattern=None, tier=tier)  # type: ignore[arg-type]


def _make_evaluator(
    rows: list[dict] | None = None,
    max_cooccurrence_rows: int = 50_000,
) -> tuple[RuleEvaluator, MagicMock]:
    """Return a (RuleEvaluator, mock_db) pair with DB returning configured rows."""
    mock_db = MagicMock(spec=IStructuredDB)
    mock_db.execute.return_value = rows or []
    settings = Settings(semantic_interpreter_max_cooccurrence_rows=max_cooccurrence_rows)
    evaluator = RuleEvaluator(db=mock_db, settings=settings)
    return evaluator, mock_db


# ---------------------------------------------------------------------------
# T-17: Glob match produces AnnotationResult with correct fields (AC-01)
# ---------------------------------------------------------------------------


def test_glob_match_produces_annotation() -> None:
    """T-17: evaluate_file() returns AnnotationResult for par_ban_init matched against
    par_* glob rule with correct rule_id, platform, type, confidence (AC-01)."""
    # Given
    crule = _make_glob_rule()
    evaluator, mock_db = _make_evaluator(
        rows=[{"id": "fn-uuid-1", "function_name": "par_ban_init"}]
    )

    # When
    results = evaluator.evaluate_file(
        file_id="file-001",
        repo_id="repo-001",
        compiled_rules=[crule],
    )

    # Then
    assert len(results) == 1
    r = results[0]
    assert r.rule_id == "tuxedo-service-handler"
    assert r.platform == "Tuxedo"
    assert r.type == "service_handler"
    assert r.confidence == 1.0
    assert r.target_type == "function_facts"
    assert r.target_id == "fn-uuid-1"
    # AC-21: evaluator must NOT write to fact tables
    mock_db.upsert.assert_not_called()


# ---------------------------------------------------------------------------
# T-18: Regex named capture substitution produces correct group (AC-02)
# ---------------------------------------------------------------------------


def test_regex_capture_group_substitution() -> None:
    """T-18: evaluate_file() with regex named capture produces group='GTBan' from
    function_name='atGTBan_extract' (AC-02)."""
    # Given
    crule = _make_regex_rule()
    evaluator, _ = _make_evaluator(
        rows=[{"id": "fn-uuid-2", "function_name": "atGTBan_extract"}]
    )

    # When
    results = evaluator.evaluate_file(
        file_id="file-001",
        repo_id="repo-001",
        compiled_rules=[crule],
    )

    # Then
    assert len(results) == 1
    r = results[0]
    assert r.group == "GTBan"
    assert r.role == "extract"
    assert r.type == "pipeline_stage"


# ---------------------------------------------------------------------------
# T-19: Positional capture substitution {match[2]} resolves correctly (AC-02)
# ---------------------------------------------------------------------------


def test_positional_capture_substitution() -> None:
    """T-19: _apply_substitution('{match[2]}', match) on regex with 2 groups
    resolves to second positional capture group value 'extract' (AC-02)."""
    # Given
    pattern_str = r"^at(?P<group>[A-Z][a-zA-Z0-9]+)_(extract|process|report)$"
    compiled_pattern = re.compile(pattern_str)
    m = compiled_pattern.fullmatch("atGTBan_extract")
    assert m is not None, "pattern must match — fixture sanity check"

    evaluator, _ = _make_evaluator()

    # When
    result = evaluator._apply_substitution("{match[2]}", m)

    # Then
    assert result == "extract"


# ---------------------------------------------------------------------------
# T-20: No match produces empty list
# ---------------------------------------------------------------------------


def test_no_match_produces_no_annotation() -> None:
    """T-20: Row with function_name='unrelated_fn' against 'par_*' pattern returns
    empty list[AnnotationResult] — no-match case."""
    # Given
    crule = _make_glob_rule()
    evaluator, _ = _make_evaluator(
        rows=[{"id": "fn-uuid-3", "function_name": "unrelated_fn"}]
    )

    # When
    results = evaluator.evaluate_file(
        file_id="file-001",
        repo_id="repo-001",
        compiled_rules=[crule],
    )

    # Then
    assert results == []


# ---------------------------------------------------------------------------
# T-21: Co-occurrence annotates all functions sharing a table (AC-03)
# ---------------------------------------------------------------------------


def test_cooccurrence_annotates_shared_table_functions() -> None:
    """T-21: evaluate_repo() with 3 distinct functions touching GL_TRANS,
    min_functions=2 → 3 AnnotationResult rows with group='GL_TRANS' (AC-03)."""
    # Given
    crule = _make_co_occurrence_rule(table_name_glob="*", min_functions=2)
    evaluator, mock_db = _make_evaluator(
        rows=[
            {"id": "op-1", "function_name": "fn_a", "table_name": "GL_TRANS"},
            {"id": "op-2", "function_name": "fn_b", "table_name": "GL_TRANS"},
            {"id": "op-3", "function_name": "fn_c", "table_name": "GL_TRANS"},
        ]
    )

    # When
    results = evaluator.evaluate_repo(
        repo_id="repo-001",
        tenant_id="tenant-001",
        compiled_rules=[crule],
    )

    # Then
    assert len(results) == 3
    for r in results:
        assert r.group == "GL_TRANS"
        assert r.rule_id == "gl-trans-group"
        assert r.type == "shared_table_group"
    # AC-21: no writes to fact tables
    mock_db.upsert.assert_not_called()


# ---------------------------------------------------------------------------
# T-22: Co-occurrence row limit triggers PermanentWorkerError (AC-14)
# ---------------------------------------------------------------------------


def test_cooccurrence_row_limit_raises_permanent_error() -> None:
    """T-22: evaluate_repo() with MAX_COOCCURRENCE_ROWS+1 rows returned from DB
    raises PermanentWorkerError (AC-14)."""
    # Given — use a small limit to keep the test fast
    max_rows = 5
    crule = _make_co_occurrence_rule()
    over_limit_rows = [
        {"id": f"op-{i}", "function_name": f"fn_{i}", "table_name": "GL_TRANS"}
        for i in range(max_rows + 1)  # 6 rows > limit of 5
    ]
    evaluator, _ = _make_evaluator(
        rows=over_limit_rows,
        max_cooccurrence_rows=max_rows,
    )

    # When / Then
    with pytest.raises(PermanentWorkerError, match="co-occurrence row count exceeds limit"):
        evaluator.evaluate_repo(
            repo_id="repo-001",
            tenant_id="tenant-001",
            compiled_rules=[crule],
        )


# ---------------------------------------------------------------------------
# T-33: First-match-wins deduplication on equal confidence (AC-10)
# ---------------------------------------------------------------------------


def test_first_match_wins_on_equal_confidence() -> None:
    """T-33: Two base-tier rules with the same rule_id and confidence=1.0 both match
    the same function; Rule A is first in list → only Rule A annotation returned (AC-10)."""
    # Given — same rule_id in both rules triggers (target_id, rule_id) deduplication
    crule_a = _make_glob_rule(
        rule_id="dup-rule",
        annotate={"platform": "Tuxedo", "type": "first"},
        confidence=1.0,
    )
    crule_b = _make_glob_rule(
        rule_id="dup-rule",  # same rule_id — dedup will keep first match
        annotate={"platform": "Tuxedo", "type": "second"},
        confidence=1.0,
    )
    evaluator, _ = _make_evaluator(
        rows=[{"id": "fn-uuid-1", "function_name": "par_ban_init"}]
    )

    # When — Rule A is first in the compiled_rules list
    results = evaluator.evaluate_file(
        file_id="file-001",
        repo_id="repo-001",
        compiled_rules=[crule_a, crule_b],
    )

    # Then — only one result; it must be Rule A (type="first")
    assert len(results) == 1
    assert results[0].type == "first"


# ---------------------------------------------------------------------------
# T-34: Co-occurrence min_functions threshold not met → empty list (AC-04)
# ---------------------------------------------------------------------------


def test_co_occurrence_min_functions_not_met() -> None:
    """T-34: Only 1 distinct function touches GL_TRANS; min_functions=2 → empty list
    (AC-04)."""
    # Given
    crule = _make_co_occurrence_rule(min_functions=2)
    evaluator, _ = _make_evaluator(
        rows=[{"id": "op-1", "function_name": "fn_a", "table_name": "GL_TRANS"}]
    )

    # When
    results = evaluator.evaluate_repo(
        repo_id="repo-001",
        tenant_id="tenant-001",
        compiled_rules=[crule],
    )

    # Then
    assert results == []


# ---------------------------------------------------------------------------
# T-37: Pattern evaluation exception raises PermanentWorkerError (Error handling row 4)
# ---------------------------------------------------------------------------


def test_pattern_evaluation_exception_raises_permanent_error() -> None:
    """T-37: compiled_pattern.fullmatch raises re.error during evaluation →
    PermanentWorkerError raised (Error handling row 4)."""
    # Given — mock the compiled pattern to raise re.error on fullmatch
    rule = AnnotationRule(
        rule_id="error-rule",
        version=1,
        scope="annotation",
        target="function_facts",
        match=SingleFactMatch(field="function_name", pattern="par_*"),
        annotate={"platform": "Test"},
        confidence=1.0,
    )
    mock_pattern = MagicMock()
    mock_pattern.fullmatch.side_effect = re.error("synthetic regex error")

    crule = CompiledAnnotationRule(
        rule=rule,
        compiled_pattern=mock_pattern,
        tier="base",
    )
    evaluator, mock_db = _make_evaluator(
        rows=[{"id": "fn-1", "function_name": "par_test"}]
    )

    # When / Then
    with pytest.raises(PermanentWorkerError):
        evaluator.evaluate_file(
            file_id="file-001",
            repo_id="repo-001",
            compiled_rules=[crule],
        )
