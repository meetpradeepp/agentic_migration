# Implements: SPEC-0009. Tests: LocalArtifactStore
"""Unit tests for LocalArtifactStore."""

from __future__ import annotations

import os
from pathlib import Path
from unittest.mock import patch

import pytest

from ecle.core.backends.local_artifact_store import LocalArtifactStore
from ecle.core.exceptions import ArtifactNotFoundError


# ---------------------------------------------------------------------------
# AC-06  write creates parent directories
# ---------------------------------------------------------------------------


def test_write_creates_parent_directories(tmp_path: Path) -> None:
    """AC-06: write() creates missing parent directories."""
    store = LocalArtifactStore(root=tmp_path)
    store.write("a/b/c/file.json", b'{"k": "v"}')
    assert (tmp_path / "a" / "b" / "c" / "file.json").exists()


# ---------------------------------------------------------------------------
# AC-07  write then read returns original bytes
# ---------------------------------------------------------------------------


def test_write_then_read_returns_original_bytes(tmp_path: Path) -> None:
    """AC-07: read() returns exactly the bytes written."""
    store = LocalArtifactStore(root=tmp_path)
    data = b"\x00\x01\x02binary\xff"
    store.write("tenant/repo/file.facts.json", data)
    assert store.read("tenant/repo/file.facts.json") == data


# ---------------------------------------------------------------------------
# AC-08  read raises ArtifactNotFoundError
# ---------------------------------------------------------------------------


def test_read_raises_artifact_not_found_error(tmp_path: Path) -> None:
    """AC-08: read() raises ArtifactNotFoundError with .path and chained FileNotFoundError."""
    store = LocalArtifactStore(root=tmp_path)
    with pytest.raises(ArtifactNotFoundError) as exc_info:
        store.read("missing/file.json")

    err = exc_info.value
    assert err.path == "missing/file.json"
    assert isinstance(err.__cause__, FileNotFoundError)


# ---------------------------------------------------------------------------
# AC-09  delete removes file
# ---------------------------------------------------------------------------


def test_delete_removes_file(tmp_path: Path) -> None:
    """AC-09: delete() removes an existing file."""
    store = LocalArtifactStore(root=tmp_path)
    store.write("del/me.json", b"data")
    assert store.exists("del/me.json")
    store.delete("del/me.json")
    assert not store.exists("del/me.json")


# ---------------------------------------------------------------------------
# AC-10  delete is idempotent
# ---------------------------------------------------------------------------


def test_delete_is_idempotent_on_missing_file(tmp_path: Path) -> None:
    """AC-10: delete() on a missing file does not raise."""
    store = LocalArtifactStore(root=tmp_path)
    store.delete("does/not/exist.json")  # Must not raise


# ---------------------------------------------------------------------------
# AC-11  write is atomic
# ---------------------------------------------------------------------------


def test_write_is_atomic(tmp_path: Path) -> None:
    """AC-11: write() uses a temp file so the final path is never partially written."""
    store = LocalArtifactStore(root=tmp_path)
    final_path = tmp_path / "some" / "file.json"
    seen_tmp: list[str] = []

    original_replace = os.replace

    def spy_replace(src: str, dst: str) -> None:  # type: ignore[override]
        seen_tmp.append(src)
        original_replace(src, dst)

    with patch("os.replace", side_effect=spy_replace):
        store.write("some/file.json", b"atomic")

    assert final_path.exists()
    assert len(seen_tmp) == 1
    assert seen_tmp[0] != str(final_path)  # temp path differs from final


# ---------------------------------------------------------------------------
# error-handling  OSError on disk full
# ---------------------------------------------------------------------------


def test_write_raises_os_error_on_disk_full(tmp_path: Path) -> None:
    """write() propagates OSError (e.g. disk full) without swallowing."""
    store = LocalArtifactStore(root=tmp_path)
    with patch(
        "tempfile.NamedTemporaryFile",
        side_effect=OSError("No space left on device"),
    ):
        with pytest.raises(OSError):
            store.write("some/file.json", b"data")
