# Implements: SPEC-0008
"""Unit tests for WorkerBase constructor, _check_lifecycle(), run(), and DLQ routing."""

from __future__ import annotations

import json
import threading
from typing import Any
from unittest.mock import MagicMock, call, patch

import pytest

from ecle.core.exceptions import ECLEBaseError, PermanentWorkerError
from ecle.events.topic_registry import TOPIC_SOURCE_RECEIVED
from ecle.workers.base import WorkerBase


# ---------------------------------------------------------------------------
# Test double
# ---------------------------------------------------------------------------


class ConcreteWorker(WorkerBase):
    """Minimal concrete subclass for testing."""

    @property
    def worker_name(self) -> str:
        return "test_worker"

    @property
    def input_topic(self) -> str:
        return TOPIC_SOURCE_RECEIVED

    def process(self, event: dict) -> None:  # type: ignore[override]
        pass


def _make_worker() -> tuple[ConcreteWorker, MagicMock, MagicMock, MagicMock]:
    consumer = MagicMock()
    producer = MagicMock()
    db = MagicMock()
    settings = MagicMock()
    worker = ConcreteWorker(consumer=consumer, producer=producer, db=db, settings=settings)
    return worker, consumer, producer, db


# ---------------------------------------------------------------------------
# AC-03  constructor
# ---------------------------------------------------------------------------


def test_auto_commit_is_false() -> None:
    """AC-03: WorkerBase can be instantiated with a mock consumer without calling commit()."""
    worker, consumer, _producer, _db = _make_worker()
    assert worker._consumer is consumer
    consumer.commit.assert_not_called()


# ---------------------------------------------------------------------------
# AC-10  _check_lifecycle() — missing row
# ---------------------------------------------------------------------------


def test_missing_lifecycle_row_returns_running(caplog: pytest.LogCaptureFixture) -> None:
    """AC-10: empty DB result → 'running' + WARNING logged."""
    import logging

    worker, _consumer, _producer, db = _make_worker()
    db.execute.return_value = []

    with caplog.at_level(logging.WARNING):
        result = worker._check_lifecycle()

    assert result == "running"
    assert db.execute.call_count == 1
    assert any("running" in r.message.lower() or "lifecycle" in r.message.lower() for r in caplog.records)


# ---------------------------------------------------------------------------
# AC-11  _check_lifecycle() — TTL cache
# ---------------------------------------------------------------------------


def test_lifecycle_cache_prevents_duplicate_db_calls() -> None:
    """AC-11: second call within TTL window returns cached value without hitting DB."""
    worker, _consumer, _producer, db = _make_worker()
    db.execute.return_value = [{"command": "run"}]

    with patch("time.monotonic", return_value=0.0):
        result1 = worker._check_lifecycle()

    with patch("time.monotonic", return_value=5.0):
        result2 = worker._check_lifecycle()

    assert result1 == result2 == "running"
    assert db.execute.call_count == 1


# ---------------------------------------------------------------------------
# AC-12  _check_lifecycle() — TTL expiry
# ---------------------------------------------------------------------------


def test_lifecycle_cache_expires_after_ttl() -> None:
    """AC-12: second call after TTL expiry re-queries DB."""
    worker, _consumer, _producer, db = _make_worker()
    db.execute.return_value = [{"command": "run"}]

    with patch("time.monotonic", return_value=0.0):
        worker._check_lifecycle()

    with patch("time.monotonic", return_value=31.0):
        worker._check_lifecycle()

    assert db.execute.call_count == 2


# ---------------------------------------------------------------------------
# error-handling  _check_lifecycle() — DB error
# ---------------------------------------------------------------------------


def test_lifecycle_db_error_returns_running_with_warning(caplog: pytest.LogCaptureFixture) -> None:
    """_check_lifecycle() swallows DB errors and returns 'running' with WARNING."""
    import logging

    worker, _consumer, _producer, db = _make_worker()
    db.execute.side_effect = Exception("db down")

    with caplog.at_level(logging.WARNING):
        result = worker._check_lifecycle()

    assert result == "running"
    assert any(r.levelno >= logging.WARNING for r in caplog.records)


# ===========================================================================
# Helpers for run() tests
# ===========================================================================

class _Stop(Exception):
    """Sentinel to terminate the run() loop in tests."""


def _make_msg(
    payload: bytes = b'{"key": "v"}',
    topic: str = TOPIC_SOURCE_RECEIVED,
    headers: list[tuple[str, bytes]] | None = None,
) -> MagicMock:
    msg = MagicMock()
    msg.value.return_value = payload
    msg.topic.return_value = topic
    msg.headers.return_value = headers or [
        ("X-Request-Id", b"rid-1"),
        ("X-Trace-Id", b"tid-1"),
    ]
    msg.error.return_value = None
    return msg


# ===========================================================================
# ST-0008-05  run() happy path tests (Red)
# ===========================================================================


def test_run_commits_offset_after_process() -> None:
    """AC-01 + AC-02: consumer.commit() is called after process() succeeds."""
    worker, consumer, _producer, db = _make_worker()
    db.execute.return_value = [{"command": "run"}]

    msg = _make_msg()
    consumer.poll.side_effect = [msg, _Stop()]

    with patch.object(worker, "process") as mock_process:
        with pytest.raises(_Stop):
            worker.run()

    mock_process.assert_called_once()
    consumer.commit.assert_called_once_with(msg, asynchronous=False)


def test_run_does_not_commit_offset_before_process() -> None:
    """AC-02: commit() is NOT called when process() raises before completing."""
    worker, consumer, _producer, db = _make_worker()
    db.execute.return_value = [{"command": "run"}]

    msg = _make_msg()
    consumer.poll.side_effect = [msg, _Stop()]

    with patch.object(worker, "process", side_effect=_Stop("process failed")):
        with pytest.raises(_Stop):
            worker.run()

    consumer.commit.assert_not_called()


def test_run_retries_transient_error_without_committing_offset() -> None:
    """AC-04: ECLEBaseError causes retry without commit (retry_count < max)."""
    worker, consumer, _producer, db = _make_worker()
    db.execute.return_value = [{"command": "run"}]
    worker._settings.kafka_dlq_max_retries = 3

    msg = _make_msg()
    consumer.poll.side_effect = [msg, _Stop()]

    call_count = 0
    def flaky_process(_event: dict) -> None:  # noqa: ANN001
        nonlocal call_count
        call_count += 1
        raise ECLEBaseError("transient")

    with patch.object(worker, "process", side_effect=flaky_process):
        with patch("time.sleep"):
            with pytest.raises(_Stop):
                worker.run()

    consumer.commit.assert_not_called()
    assert worker._retry_count > 0


def test_run_routes_to_dlq_after_max_transient_retries() -> None:
    """AC-05: after KAFKA_DLQ_MAX_RETRIES ECLEBaseErrors the message goes to DLQ."""
    max_retries = 3
    worker, consumer, producer, db = _make_worker()
    db.execute.return_value = [{"command": "run"}]
    worker._settings.kafka_dlq_max_retries = max_retries

    msg = _make_msg()
    # Each poll returns the same msg; _Stop terminates after DLQ routing
    consumer.poll.return_value = msg

    dlq_called = threading.Event()
    original_route = worker._route_to_dlq

    def dlq_then_stop(m: Any, e: Exception) -> None:
        original_route(m, e)
        dlq_called.set()
        raise _Stop()

    with patch.object(worker, "_route_to_dlq", side_effect=dlq_then_stop):
        with patch.object(worker, "process", side_effect=ECLEBaseError("transient")):
            with patch("time.sleep"):
                with pytest.raises(_Stop):
                    worker.run()

    # DLQ produce + flush must have happened (via original_route)
    producer.produce.assert_called()
    producer.flush.assert_called()
    # commit after DLQ
    consumer.commit.assert_called()
    assert dlq_called.is_set()


def test_consumer_poll_error_logs_and_continues() -> None:
    """KafkaException from poll() is logged as ERROR and loop continues."""
    from confluent_kafka import KafkaException  # type: ignore[import]
    import logging

    worker, consumer, _producer, db = _make_worker()
    db.execute.return_value = [{"command": "run"}]

    consumer.poll.side_effect = [KafkaException("poll failed"), None, _Stop()]

    with patch.object(worker, "process") as mock_process:
        import logging
        with pytest.raises(_Stop):
            worker.run()

    mock_process.assert_not_called()


# ===========================================================================
# ST-0008-07  DLQ routing, permanent errors, pause/drain (Red)
# ===========================================================================


def test_run_routes_permanent_error_to_dlq_immediately() -> None:
    """AC-06: PermanentWorkerError → DLQ immediately with no retry."""
    worker, consumer, producer, db = _make_worker()
    db.execute.return_value = [{"command": "run"}]
    worker._settings.kafka_dlq_max_retries = 3

    msg = _make_msg()
    consumer.poll.side_effect = [msg, _Stop()]

    with patch.object(worker, "process", side_effect=PermanentWorkerError("perm")):
        with pytest.raises(_Stop):
            worker.run()

    producer.produce.assert_called_once()
    assert worker._retry_count == 0
    consumer.commit.assert_called()


def test_run_routes_json_decode_error_to_dlq() -> None:
    """AC-07: bad JSON payload → DLQ, process() never called."""
    worker, consumer, producer, db = _make_worker()
    db.execute.return_value = [{"command": "run"}]

    msg = _make_msg(payload=b"not-json")
    consumer.poll.side_effect = [msg, _Stop()]

    with patch.object(worker, "process") as mock_process:
        with pytest.raises(_Stop):
            worker.run()

    mock_process.assert_not_called()
    producer.produce.assert_called()
    consumer.commit.assert_called()


def test_run_paused_lifecycle_skips_process() -> None:
    """AC-08: 'paused' lifecycle → process() not called, no commit."""
    worker, consumer, _producer, db = _make_worker()
    db.execute.return_value = [{"command": "pause"}]

    msg = _make_msg()
    consumer.poll.side_effect = [msg, _Stop()]

    with patch.object(worker, "process") as mock_process:
        with patch("time.sleep") as mock_sleep:
            with pytest.raises(_Stop):
                worker.run()

    mock_process.assert_not_called()
    consumer.commit.assert_not_called()
    mock_sleep.assert_called_with(1)


def test_run_draining_zero_lag_transitions() -> None:
    """AC-09: 'draining' + zero lag sets _draining_done=True, process() not called."""
    worker, consumer, _producer, db = _make_worker()
    db.execute.return_value = [{"command": "drain"}]

    # Simulate zero lag: assignment returns one partition, high=5, position=5
    partition = MagicMock()
    consumer.assignment.return_value = [partition]
    consumer.get_watermark_offsets.return_value = (0, 5)
    consumer.position.return_value = 5

    msg = _make_msg()
    consumer.poll.side_effect = [msg, _Stop()]

    with patch.object(worker, "process") as mock_process:
        with patch("time.sleep"):
            with pytest.raises(_Stop):
                worker.run()

    mock_process.assert_not_called()
    assert worker._draining_done is True


def test_dlq_envelope_contains_required_fields() -> None:
    """DLQ envelope must contain all 9 required fields."""
    worker, consumer, producer, db = _make_worker()
    db.execute.return_value = [{"command": "run"}]

    msg = _make_msg()
    consumer.poll.side_effect = [msg, _Stop()]

    with patch.object(worker, "process", side_effect=PermanentWorkerError("perm")):
        with pytest.raises(_Stop):
            worker.run()

    call_kwargs = producer.produce.call_args
    # value is keyword or positional
    raw = call_kwargs[1].get("value") or call_kwargs[0][1]
    envelope = json.loads(raw)

    required_keys = {
        "X-Request-Id", "X-Trace-Id", "original_topic", "original_payload",
        "error_type", "error_message", "worker_name", "retry_count", "failed_at",
    }
    assert required_keys.issubset(envelope.keys())
    assert envelope["X-Request-Id"] == "rid-1"
    assert envelope["X-Trace-Id"] == "tid-1"


def test_producer_flush_called_before_offset_commit_on_dlq() -> None:
    """producer.flush() must precede consumer.commit() in DLQ path."""
    from unittest.mock import call

    worker, consumer, producer, db = _make_worker()
    db.execute.return_value = [{"command": "run"}]

    msg = _make_msg()
    consumer.poll.side_effect = [msg, _Stop()]

    manager = MagicMock()
    manager.attach_mock(producer, "producer")
    manager.attach_mock(consumer, "consumer")

    worker._producer = producer
    worker._consumer = consumer

    with patch.object(worker, "process", side_effect=PermanentWorkerError("perm")):
        with pytest.raises(_Stop):
            worker.run()

    call_names = [c[0] for c in manager.mock_calls]
    flush_idx = next(i for i, n in enumerate(call_names) if "flush" in n)
    commit_idx = next(i for i, n in enumerate(call_names) if "commit" in n and "poll" not in n)
    assert flush_idx < commit_idx, f"flush ({flush_idx}) must come before commit ({commit_idx})"


def test_dlq_producer_error_logs_critical_skips_offset_commit(
    caplog: pytest.LogCaptureFixture,
) -> None:
    """KafkaException in producer.produce() → CRITICAL log, no commit."""
    from confluent_kafka import KafkaException  # type: ignore[import]
    import logging

    worker, consumer, producer, db = _make_worker()
    db.execute.return_value = [{"command": "run"}]
    producer.produce.side_effect = KafkaException("produce failed")

    msg = _make_msg()
    consumer.poll.side_effect = [msg, _Stop()]

    with patch.object(worker, "process", side_effect=PermanentWorkerError("perm")):
        with caplog.at_level(logging.CRITICAL):
            with pytest.raises(_Stop):
                worker.run()

    consumer.commit.assert_not_called()
    assert any(r.levelno >= logging.CRITICAL for r in caplog.records)

