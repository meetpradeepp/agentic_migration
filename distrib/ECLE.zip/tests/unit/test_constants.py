# Implements: SPEC-0001
"""Unit tests for ecle.constants module.

Tests: T-23 to T-26, T-30, T-31 (SPEC-0001 acceptance criteria AC-15, AC-16).
All tests are no-I/O, < 100ms (Contract 03 §2).
"""

from __future__ import annotations

from ecle.constants import (
    ARTIFACT_PATH_TEMPLATE,
    CONSUMER_GROUP_PREFIX,
    DLQ_TOPIC_PREFIX,
    FIDELITY_CEILING,
    FIDELITY_FULL,
    FIDELITY_HEURISTIC,
    FIDELITY_PARTIAL,
    LOUVAIN_MIN_CLUSTER_SIZE,
    WORKER_LIFECYCLE_TTL_SECONDS,
)


def test_artifact_path_template_formats_correctly() -> None:
    """T-23: ARTIFACT_PATH_TEMPLATE produces ADR-0007 §2 canonical path (AC-15)."""
    result = ARTIFACT_PATH_TEMPLATE.format(
        tenant_id="acme",
        repo_id="backend",
        file_rel_path="src/api/handler.py",
    )
    assert result == "acme/backend/src/api/handler.py.facts.json"


def test_fidelity_ceiling_full_is_1_0() -> None:
    """T-24: FIDELITY_CEILING[FIDELITY_FULL] == 1.0 (AC-16)."""
    assert FIDELITY_CEILING[FIDELITY_FULL] == 1.0


def test_fidelity_ceiling_partial_is_0_8() -> None:
    """T-25: FIDELITY_CEILING[FIDELITY_PARTIAL] == 0.8 (AC-16)."""
    assert FIDELITY_CEILING[FIDELITY_PARTIAL] == 0.8


def test_fidelity_ceiling_heuristic_is_0_6() -> None:
    """T-26: FIDELITY_CEILING[FIDELITY_HEURISTIC] == 0.6 (AC-16)."""
    assert FIDELITY_CEILING[FIDELITY_HEURISTIC] == 0.6


def test_worker_lifecycle_ttl_is_thirty() -> None:
    """T-30: WORKER_LIFECYCLE_TTL_SECONDS == 30 and is int."""
    assert WORKER_LIFECYCLE_TTL_SECONDS == 30
    assert isinstance(WORKER_LIFECYCLE_TTL_SECONDS, int)


def test_louvain_min_cluster_size_is_two() -> None:
    """T-31: LOUVAIN_MIN_CLUSTER_SIZE == 2 and is int."""
    assert LOUVAIN_MIN_CLUSTER_SIZE == 2
    assert isinstance(LOUVAIN_MIN_CLUSTER_SIZE, int)


def test_consumer_group_prefix() -> None:
    """CONSUMER_GROUP_PREFIX == 'ecle.' (SPEC-0001 constants table)."""
    assert CONSUMER_GROUP_PREFIX == "ecle."


def test_dlq_topic_prefix() -> None:
    """DLQ_TOPIC_PREFIX == 'ecle.dlq.' (SPEC-0001 constants table)."""
    assert DLQ_TOPIC_PREFIX == "ecle.dlq."
