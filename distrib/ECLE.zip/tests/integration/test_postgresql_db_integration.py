# Implements: SPEC-0009. Tests: PostgreSQLStructuredDB integration
"""Integration tests for PostgreSQLStructuredDB against a live PostgreSQL database."""

from __future__ import annotations

import os
import shutil
from pathlib import Path
from subprocess import CalledProcessError, run

import pytest
import psycopg2

from ecle.config import settings
from ecle.core.backends.postgresql_db import PostgreSQLStructuredDB


def _alembic_cmd() -> list[str]:
    alembic_bin = shutil.which("alembic")
    if not alembic_bin:
        pytest.skip("Alembic executable not found in environment")
    return [alembic_bin]


@pytest.fixture
def project_root() -> Path:
    return Path(__file__).resolve().parents[2]


@pytest.fixture
def postgres_url() -> str:
    url = settings.database_url or os.environ.get("ECLE_DATABASE_URL", "")
    if not url.startswith("postgresql"):
        pytest.skip("SPEC-0009 integration tests require a PostgreSQL database URL")
    return url


@pytest.fixture
def migrated_connection(monkeypatch: pytest.MonkeyPatch, project_root: Path, postgres_url: str):
    monkeypatch.chdir(project_root)
    monkeypatch.setenv("ECLE_DATABASE_URL", postgres_url)

    try:
        run(_alembic_cmd() + ["upgrade", "head"], check=True, cwd=project_root)
    except CalledProcessError as exc:
        pytest.skip(f"Alembic upgrade failed in integration environment: {exc}")

    connection = psycopg2.connect(postgres_url)
    connection.autocommit = False
    try:
        yield connection
    finally:
        connection.rollback()
        connection.close()
        run(_alembic_cmd() + ["downgrade", "base"], check=False, cwd=project_root)


@pytest.mark.integration
def test_execute_filters_by_tenant_against_real_db(migrated_connection) -> None:
    with migrated_connection.cursor() as cursor:
        cursor.execute(
            "INSERT INTO tenants (tenant_id, tenant_name) VALUES (%s, %s)",
            ("t1", "Tenant 1"),
        )
        cursor.execute(
            "INSERT INTO tenants (tenant_id, tenant_name) VALUES (%s, %s)",
            ("t2", "Tenant 2"),
        )
        migrated_connection.commit()

    db = PostgreSQLStructuredDB(migrated_connection)
    rows = db.execute("SELECT tenant_id, tenant_name FROM tenants", [], tenant_id="t1")

    assert rows == [{"tenant_id": "t1", "tenant_name": "Tenant 1"}]


@pytest.mark.integration
def test_upsert_conflict_resolution_against_real_db(migrated_connection) -> None:
    db = PostgreSQLStructuredDB(migrated_connection)

    db.upsert(
        "file_facts",
        {
            "tenant_id": "t1",
            "repo_id": "r1",
            "file_path": "src/a.py",
            "content_hash": "hash-1",
        },
        conflict_keys=["tenant_id", "repo_id", "file_path"],
        tenant_id="t1",
    )
    db.upsert(
        "file_facts",
        {
            "tenant_id": "t1",
            "repo_id": "r1",
            "file_path": "src/a.py",
            "content_hash": "hash-2",
        },
        conflict_keys=["tenant_id", "repo_id", "file_path"],
        tenant_id="t1",
    )

    with migrated_connection.cursor() as cursor:
        cursor.execute(
            """
            SELECT content_hash, is_current, previous_id
            FROM file_facts
            WHERE tenant_id = %s AND repo_id = %s AND file_path = %s
            ORDER BY created_at
            """,
            ("t1", "r1", "src/a.py"),
        )
        rows = cursor.fetchall()

    assert len(rows) == 2
    assert rows[0][1] is False
    assert rows[1][1] is True