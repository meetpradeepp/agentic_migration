# Integration tests — real backends, <5s, full event chains.
# Contract 03 §4: named by the flow being tested.
