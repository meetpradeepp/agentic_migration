"""
test_semantic_interpreter_integration — Integration tests for the SemanticInterpreter pipeline.

Implements: SPEC-0010
Tests: T-24, T-25, T-26, T-40, T-41, T-42
       Wires real RuleLoader + real RuleEvaluator with lightweight in-memory fakes
       for IStructuredDB, IArtifactStore, Kafka consumer/producer.
       No real PostgreSQL or Kafka required.
"""

from __future__ import annotations

import logging
import textwrap
from typing import Any

import pytest

from ecle.config import Settings
from ecle.core.interfaces import IArtifactStore, IStructuredDB
from ecle.workers.semantic_interpreter.evaluator import RuleEvaluator
from ecle.workers.semantic_interpreter.rule_loader import RuleLoader
from ecle.workers.semantic_interpreter.worker import SemanticInterpreter

# ---------------------------------------------------------------------------
# Lightweight in-memory fakes
# ---------------------------------------------------------------------------


class _FakeStructuredDB(IStructuredDB):
    """In-memory IStructuredDB that replays pre-configured execute responses."""

    def __init__(self, execute_responses: list[list[dict[str, Any]]]) -> None:
        """Initialise with ordered list of responses for successive execute() calls."""
        self._responses: list[list[dict[str, Any]]] = list(execute_responses)
        self._call_index: int = 0
        self.execute_calls: list[tuple[Any, Any, str]] = []
        self.upsert_calls: list[tuple[str, dict[str, Any], list[str], str]] = []

    def execute(
        self,
        sql: Any,
        params: dict[str, Any] | None = None,
        *,
        tenant_id: str,
    ) -> list[dict[str, Any]]:
        """Return next pre-configured response; record the call."""
        self.execute_calls.append((sql, params, tenant_id))
        if self._call_index < len(self._responses):
            result = self._responses[self._call_index]
        else:
            result = []
        self._call_index += 1
        return result

    def upsert(
        self,
        table: str,
        row: dict[str, Any],
        *,
        conflict_keys: list[str],
        tenant_id: str,
    ) -> None:
        """Record the upsert call; no-op in-memory."""
        self.upsert_calls.append((table, row, conflict_keys, tenant_id))

    def close(self) -> None:
        """No-op close."""


class _FakeArtifactStore(IArtifactStore):
    """In-memory IArtifactStore backed by a plain bytes dict."""

    def __init__(self, store: dict[str, bytes] | None = None) -> None:
        """Initialise with optional pre-seeded store."""
        self._store: dict[str, bytes] = store or {}

    def exists(self, path: str) -> bool:
        """Return True when path is present in the in-memory store."""
        return path in self._store

    def write(self, path: str, data: bytes) -> None:
        """Write bytes to the in-memory store."""
        self._store[path] = data

    def read(self, path: str) -> bytes:
        """Return bytes for the given path."""
        return self._store[path]

    def delete(self, path: str) -> None:
        """Remove path from the in-memory store (idempotent)."""
        self._store.pop(path, None)


class _FakeConsumer:
    """Minimal Kafka consumer fake that counts commit() calls."""

    def __init__(self) -> None:
        """Initialise call counter."""
        self.commit_calls: int = 0

    def commit(self) -> None:
        """Record commit."""
        self.commit_calls += 1


class _FakeProducer:
    """Minimal Kafka producer fake that records produce() and flush() calls."""

    def __init__(self) -> None:
        """Initialise call lists."""
        self.produce_calls: list[tuple[str, Any]] = []
        self.flush_calls: int = 0

    def produce(self, topic: str, payload: Any) -> None:
        """Record produce call."""
        self.produce_calls.append((topic, payload))

    def flush(self) -> None:
        """Record flush call."""
        self.flush_calls += 1


# ---------------------------------------------------------------------------
# YAML rule templates
# ---------------------------------------------------------------------------

_GLOB_RULE_YAML = textwrap.dedent("""\
    rules:
      - rule_id: "tuxedo-handler"
        version: 1
        scope: "annotation"
        target: "function_facts"
        match:
          field: "function_name"
          pattern: "par_*"
        annotate:
          platform: "Tuxedo"
          type: "service_handler"
        confidence: 1.0
""")

_GLOB_RULE_APPLIES_TO_YAML = textwrap.dedent("""\
    rules:
      - rule_id: "tuxedo-handler"
        version: 1
        scope: "annotation"
        applies_to:
          platform: "Tuxedo"
        target: "function_facts"
        match:
          field: "function_name"
          pattern: "par_*"
        annotate:
          platform: "Tuxedo"
          type: "service_handler"
        confidence: 1.0
""")

_CO_OCCURRENCE_RULE_YAML = textwrap.dedent("""\
    rules:
      - rule_id: "gl-trans-co"
        version: 1
        scope: "annotation"
        target: "function_table_ops"
        match:
          table_name: "GL_TRANS"
          min_functions: 2
        annotate:
          group: "GL_TRANS"
        confidence: 1.0
""")

_BASE_RULE_LOW_CONF_YAML = textwrap.dedent("""\
    rules:
      - rule_id: "base-rule"
        version: 1
        scope: "annotation"
        target: "function_facts"
        match:
          field: "function_name"
          pattern: "par_*"
        annotate:
          platform: "Tuxedo"
        confidence: 0.5
""")

_REPO_RULE_HIGH_CONF_YAML = textwrap.dedent("""\
    rules:
      - rule_id: "base-rule"
        version: 2
        scope: "annotation"
        target: "function_facts"
        match:
          field: "function_name"
          pattern: "par_*"
        annotate:
          platform: "Tuxedo"
        confidence: 0.9
""")

# Missing required field: rule_id — triggers ValidationError in RuleFile
_INVALID_RULE_YAML = textwrap.dedent("""\
    rules:
      - version: 1
        scope: "annotation"
        target: "function_facts"
        match:
          field: "function_name"
          pattern: "par_*"
        annotate:
          platform: "Tuxedo"
        confidence: 1.0
""")


# ---------------------------------------------------------------------------
# Shared helpers
# ---------------------------------------------------------------------------


def _make_settings(tmp_path: Any, *, base_rules_dir: Any) -> Settings:
    """Return Settings pointing at tmp_path directories with given base rules dir."""
    base_rules_dir.mkdir(parents=True, exist_ok=True)
    return Settings(
        data_root=tmp_path / "data",
        log_dir=tmp_path / "logs",
        artifact_store_path=tmp_path / "artifacts",
        language_packs_dir=tmp_path / "packs",
        models_dir=tmp_path / "models",
        database_url="sqlite:///:memory:",
        otel_sdk_disabled=True,
        semantic_rules_base_path=base_rules_dir,
        semantic_rules_artifact_path_prefix="semantic_rules/",
        semantic_interpreter_max_cooccurrence_rows=50_000,
    )


def _build_worker(  # noqa: PLR0913
    mode: str,
    *,
    consumer: _FakeConsumer,
    producer: _FakeProducer,
    db: _FakeStructuredDB,
    rule_loader: RuleLoader,
    evaluator: RuleEvaluator,
    settings: Settings,
) -> SemanticInterpreter:
    """Construct a fully wired SemanticInterpreter for integration testing."""
    return SemanticInterpreter(
        consumer=consumer,
        producer=producer,
        db=db,
        settings=settings,
        rule_loader=rule_loader,
        evaluator=evaluator,
        mode=mode,  # type: ignore[arg-type]
    )


# ---------------------------------------------------------------------------
# T-24: Full file-trigger pipeline with glob rule
# ---------------------------------------------------------------------------


@pytest.mark.integration
def test_file_trigger_end_to_end_glob(tmp_path):
    """Verifies AC-01, AC-12b: file trigger writes annotation; no ecle.facts.annotated emitted."""
    base_rules = tmp_path / "base_rules"
    base_rules.mkdir()
    (base_rules / "tuxedo.yaml").write_text(_GLOB_RULE_YAML, encoding="utf-8")

    settings = _make_settings(tmp_path, base_rules_dir=base_rules)
    db = _FakeStructuredDB(
        execute_responses=[
            # 1. repositories query — empty; rule has no applies_to so it passes
            [],
            # 2. function_facts query — one matching row
            [{"id": "uuid-ff-1", "function_name": "par_ban_init"}],
        ]
    )
    artifact_store = _FakeArtifactStore()
    consumer = _FakeConsumer()
    producer = _FakeProducer()

    rule_loader = RuleLoader(db=db, artifact_store=artifact_store, settings=settings)
    rule_loader.load()
    evaluator = RuleEvaluator(db=db, settings=settings)
    worker = _build_worker(
        "file",
        consumer=consumer,
        producer=producer,
        db=db,
        rule_loader=rule_loader,
        evaluator=evaluator,
        settings=settings,
    )

    worker.process({"file_id": "f1", "repo_id": "r1", "tenant_id": "t1"})

    # One upsert to semantic_annotations with correct fields
    sa_calls = [c for c in db.upsert_calls if c[0] == "semantic_annotations"]
    assert len(sa_calls) == 1
    _table, row, conflict_keys, tenant_id = sa_calls[0]
    assert row["rule_id"] == "tuxedo-handler"
    assert row["confidence"] == 1.0
    assert row["target_type"] == "function_facts"
    assert row["target_id"] == "uuid-ff-1"
    assert row["repo_id"] == "r1"
    assert "annotated_at" in row
    assert tenant_id == "t1"
    assert "rule_id" in conflict_keys

    # AC-12b — file mode must NEVER produce ecle.facts.annotated
    assert producer.produce_calls == []

    # Offset committed after all upserts
    assert consumer.commit_calls == 1


# ---------------------------------------------------------------------------
# T-25: Invalid YAML in base rules is skipped; valid sibling still loaded
# ---------------------------------------------------------------------------


@pytest.mark.integration
def test_invalid_yaml_in_base_rules_skipped(tmp_path, caplog):
    """Verifies AC-16: invalid YAML skipped with WARN; valid sibling rule loaded."""
    base_rules = tmp_path / "base_rules"
    base_rules.mkdir()
    (base_rules / "valid.yaml").write_text(_GLOB_RULE_YAML, encoding="utf-8")
    (base_rules / "invalid.yaml").write_text(_INVALID_RULE_YAML, encoding="utf-8")

    settings = _make_settings(tmp_path, base_rules_dir=base_rules)
    db = _FakeStructuredDB(execute_responses=[])
    artifact_store = _FakeArtifactStore()
    rule_loader = RuleLoader(db=db, artifact_store=artifact_store, settings=settings)

    with caplog.at_level(
        logging.WARNING, logger="ecle.workers.semantic_interpreter.rule_loader"
    ):
        rule_loader.load()

    # Only the valid rule is in _base_rules; no crash
    assert len(rule_loader._base_rules) == 1
    assert rule_loader._base_rules[0].rule.rule_id == "tuxedo-handler"

    # WARN logged with the invalid file path
    assert "invalid.yaml" in caplog.text


# ---------------------------------------------------------------------------
# T-26: applies_to pre-filter excludes rules on platform mismatch
# ---------------------------------------------------------------------------


@pytest.mark.integration
def test_applies_to_pre_filter_excludes_non_matching_platform(tmp_path):
    """Verifies AC-05: rule with applies_to.platform=Tuxedo skipped when repo is Spring."""
    base_rules = tmp_path / "base_rules"
    base_rules.mkdir()
    (base_rules / "tuxedo.yaml").write_text(_GLOB_RULE_APPLIES_TO_YAML, encoding="utf-8")

    settings = _make_settings(tmp_path, base_rules_dir=base_rules)
    db = _FakeStructuredDB(
        execute_responses=[
            # repositories query — platform mismatch
            [{"platform": "Spring", "primary_language": None, "repo_type": None}],
        ]
    )
    artifact_store = _FakeArtifactStore()
    rule_loader = RuleLoader(db=db, artifact_store=artifact_store, settings=settings)
    rule_loader.load()

    result = rule_loader.get_annotation_rules(repo_id="r1", tenant_id="t1")

    # Pre-filter returns empty list — platform mismatch excludes the rule
    assert result == []

    # No semantic_annotations upsert was triggered
    sa_calls = [c for c in db.upsert_calls if c[0] == "semantic_annotations"]
    assert sa_calls == []


# ---------------------------------------------------------------------------
# T-40: Full repo-trigger pipeline with co-occurrence rule
# ---------------------------------------------------------------------------


@pytest.mark.integration
def test_end_to_end_repo_trigger_cooccurrence(tmp_path):
    """Verifies AC-03, AC-12: repo trigger with co-occurrence rule produces 3 annotations."""
    base_rules = tmp_path / "base_rules"
    base_rules.mkdir()
    (base_rules / "gl_trans.yaml").write_text(_CO_OCCURRENCE_RULE_YAML, encoding="utf-8")

    settings = _make_settings(tmp_path, base_rules_dir=base_rules)
    db = _FakeStructuredDB(
        execute_responses=[
            # 1. repositories query — empty; co-occurrence rule has no applies_to
            [],
            # 2. function_table_ops co-occurrence query — 3 distinct functions on GL_TRANS
            [
                {"id": "uuid-op-1", "function_name": "fn_a", "table_name": "GL_TRANS"},
                {"id": "uuid-op-2", "function_name": "fn_b", "table_name": "GL_TRANS"},
                {"id": "uuid-op-3", "function_name": "fn_c", "table_name": "GL_TRANS"},
            ],
        ]
    )
    artifact_store = _FakeArtifactStore()
    consumer = _FakeConsumer()
    producer = _FakeProducer()

    rule_loader = RuleLoader(db=db, artifact_store=artifact_store, settings=settings)
    rule_loader.load()
    evaluator = RuleEvaluator(db=db, settings=settings)
    worker = _build_worker(
        "repo",
        consumer=consumer,
        producer=producer,
        db=db,
        rule_loader=rule_loader,
        evaluator=evaluator,
        settings=settings,
    )

    worker.process({
        "repo_id": "r1",
        "tenant_id": "t1",
        "X_Request_Id": "req-1",
        "X_Trace_Id": "tr-1",
    })

    # 3 upserts to semantic_annotations, each with group="GL_TRANS"
    sa_calls = [c for c in db.upsert_calls if c[0] == "semantic_annotations"]
    assert len(sa_calls) == 3
    for _table, row, _keys, tenant_id in sa_calls:
        assert row["group"] == "GL_TRANS"
        assert tenant_id == "t1"

    # producer.produce() called exactly once with correct annotation_count
    assert len(producer.produce_calls) == 1
    topic, payload = producer.produce_calls[0]
    from ecle.events.topic_registry import TOPIC_FACTS_ANNOTATED  # noqa: PLC0415
    assert topic == TOPIC_FACTS_ANNOTATED
    assert payload["annotation_count"] == 3
    assert payload["repo_id"] == "r1"
    assert payload["tenant_id"] == "t1"

    # Offset committed after produce + flush
    assert consumer.commit_calls == 1


# ---------------------------------------------------------------------------
# T-41: Full pipeline — applies_to mismatch prevents annotations
# ---------------------------------------------------------------------------


@pytest.mark.integration
def test_end_to_end_applies_to_pre_filter_real_db_stub(tmp_path):
    """Verifies AC-05: real RuleLoader + RuleEvaluator; platform mismatch → 0 upserts."""
    base_rules = tmp_path / "base_rules"
    base_rules.mkdir()
    (base_rules / "tuxedo.yaml").write_text(_GLOB_RULE_APPLIES_TO_YAML, encoding="utf-8")

    settings = _make_settings(tmp_path, base_rules_dir=base_rules)
    db = _FakeStructuredDB(
        execute_responses=[
            # repositories query — Spring does not match applies_to.platform=Tuxedo
            [{"platform": "Spring", "primary_language": None, "repo_type": None}],
        ]
    )
    artifact_store = _FakeArtifactStore()
    consumer = _FakeConsumer()
    producer = _FakeProducer()

    rule_loader = RuleLoader(db=db, artifact_store=artifact_store, settings=settings)
    rule_loader.load()
    evaluator = RuleEvaluator(db=db, settings=settings)
    worker = _build_worker(
        "file",
        consumer=consumer,
        producer=producer,
        db=db,
        rule_loader=rule_loader,
        evaluator=evaluator,
        settings=settings,
    )

    worker.process({"file_id": "f1", "repo_id": "r1", "tenant_id": "t1"})

    # No annotations written — applies_to filter blocked all rules
    sa_calls = [c for c in db.upsert_calls if c[0] == "semantic_annotations"]
    assert sa_calls == []


# ---------------------------------------------------------------------------
# T-42: Multi-tier precedence — repo-tier rule wins over base-tier (same rule_id)
# ---------------------------------------------------------------------------


@pytest.mark.integration
def test_end_to_end_multi_tier_precedence(tmp_path):
    """Verifies AC-08: repo-tier rule (confidence=0.9) wins over base-tier (confidence=0.5)."""
    base_rules = tmp_path / "base_rules"
    base_rules.mkdir()
    (base_rules / "base.yaml").write_text(_BASE_RULE_LOW_CONF_YAML, encoding="utf-8")

    settings = _make_settings(tmp_path, base_rules_dir=base_rules)

    # Repo-tier YAML injected via fake artifact store
    repo_yaml_path = "semantic_rules/t1/r1/repo.yaml"
    artifact_store = _FakeArtifactStore(
        store={repo_yaml_path: _REPO_RULE_HIGH_CONF_YAML.encode()}
    )

    db = _FakeStructuredDB(
        execute_responses=[
            # 1. repositories query — empty; no applies_to on either rule
            [],
            # 2. function_facts for repo-tier rule (sorted first by tier)
            [{"id": "uuid-ff-1", "function_name": "par_ban_init"}],
            # 3. function_facts for base-tier rule — same row, but deduped out
            [{"id": "uuid-ff-1", "function_name": "par_ban_init"}],
        ]
    )
    consumer = _FakeConsumer()
    producer = _FakeProducer()

    rule_loader = RuleLoader(db=db, artifact_store=artifact_store, settings=settings)
    rule_loader.load()
    evaluator = RuleEvaluator(db=db, settings=settings)
    worker = _build_worker(
        "file",
        consumer=consumer,
        producer=producer,
        db=db,
        rule_loader=rule_loader,
        evaluator=evaluator,
        settings=settings,
    )

    worker.process({"file_id": "f1", "repo_id": "r1", "tenant_id": "t1"})

    # Exactly ONE upsert — repo-tier rule wins; base-tier deduped by (target_id, rule_id)
    sa_calls = [c for c in db.upsert_calls if c[0] == "semantic_annotations"]
    assert len(sa_calls) == 1
    _table, row, _keys, _tenant = sa_calls[0]
    assert row["rule_id"] == "base-rule"
    assert row["confidence"] == 0.9  # repo-tier rule (version=2)
