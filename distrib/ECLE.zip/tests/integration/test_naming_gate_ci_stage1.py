# Implements: SPEC-0011
"""Integration tests for run_naming_gate.py CLI and JSON report writer.

Tests: CI mode exits 1 on findings (T8), CI mode exits 0 on clean input (T9),
       pre-commit and CI findings match (T10), unreadable file exits 2 (T12),
       syntax-error file exits 2 (T13-integration), missing report directory
       auto-created (T14), invalid mode exits 2 (T15).

All tests invoke scripts/run_naming_gate.py as a subprocess (Contract 03 §2).
"""

from __future__ import annotations

import json
import os
import subprocess
import sys
import textwrap
from pathlib import Path

import pytest

# Path to the CLI script relative to workspace root
_SCRIPTS_DIR = Path(__file__).parent.parent.parent / "scripts"
_NAMING_GATE_SCRIPT = _SCRIPTS_DIR / "run_naming_gate.py"
_PYTHON = sys.executable


def _run_gate(
    *extra_args: str,
    report_path: str | None = None,
    mode: str = "ci",
    paths: list[str] | None = None,
    cwd: str | None = None,
) -> subprocess.CompletedProcess[str]:
    """Helper to invoke run_naming_gate.py as a subprocess."""
    cmd = [_PYTHON, str(_NAMING_GATE_SCRIPT), "--mode", mode]
    if report_path:
        cmd += ["--report", report_path]
    if paths:
        cmd += ["--paths"] + paths
    cmd += list(extra_args)
    return subprocess.run(
        cmd,
        capture_output=True,
        text=True,
        cwd=cwd,
    )


# ---------------------------------------------------------------------------
# Fixture sources
# ---------------------------------------------------------------------------

_DIRTY_SOURCE = textwrap.dedent("""\
    def process_records(records):
        tmp = []
        total = 0
        count = 0
        for record in records:
            if record.get("active"):
                tmp.append(record["value"])
                total += record["value"]
                count += 1
        if count == 0:
            return {}
        return {"mean": total / count, "values": tmp}
""")

_CLEAN_SOURCE = textwrap.dedent("""\
    def add_values(first_value: int, second_value: int) -> int:
        return first_value + second_value
""")


# ---------------------------------------------------------------------------
# T8 — CI mode exits 1 when findings exist
# ---------------------------------------------------------------------------

class TestT8CIModeReturnsNonZeroOnFindings:
    """AC-8: process exits 1 and report file exists with >= 1 finding when violations present."""

    def test_ci_mode_returns_non_zero_on_findings(self, tmp_path: Path) -> None:
        dirty_file = tmp_path / "dirty_module.py"
        dirty_file.write_text(_DIRTY_SOURCE)
        report_file = tmp_path / "report.json"

        result = _run_gate(
            mode="ci",
            report_path=str(report_file),
            paths=[str(dirty_file)],
        )

        assert result.returncode == 1, (
            f"Expected exit code 1 (findings exist); got {result.returncode}\n"
            f"stdout: {result.stdout}\nstderr: {result.stderr}"
        )
        assert report_file.exists(), "Report file must be created even on non-zero exit"
        findings = json.loads(report_file.read_text())
        assert len(findings) >= 1, f"Expected >= 1 finding in report; got: {findings}"


# ---------------------------------------------------------------------------
# T9 — CI mode exits 0 on clean input
# ---------------------------------------------------------------------------

class TestT9CIModeReturnsZeroOnCleanInput:
    """AC-9: process exits 0 and report contains empty array when no violations present."""

    def test_ci_mode_returns_zero_on_clean_input(self, tmp_path: Path) -> None:
        clean_file = tmp_path / "clean_module.py"
        clean_file.write_text(_CLEAN_SOURCE)
        report_file = tmp_path / "report.json"

        result = _run_gate(
            mode="ci",
            report_path=str(report_file),
            paths=[str(clean_file)],
        )

        assert result.returncode == 0, (
            f"Expected exit code 0 (clean input); got {result.returncode}\n"
            f"stdout: {result.stdout}\nstderr: {result.stderr}"
        )
        assert report_file.exists(), "Report file must be created on clean run"
        findings = json.loads(report_file.read_text())
        assert findings == [], f"Expected empty findings array; got: {findings}"


# ---------------------------------------------------------------------------
# T10 — pre-commit and CI findings match for same files (parity)
# ---------------------------------------------------------------------------

class TestT10PreCommitAndCIFindingsMatch:
    """AC-10: CI and local mode produce equal finding set (path, line, symbol, rule_id)."""

    def test_pre_commit_and_ci_findings_match_for_same_files(self, tmp_path: Path) -> None:
        dirty_file = tmp_path / "parity_module.py"
        dirty_file.write_text(_DIRTY_SOURCE)
        report_ci = tmp_path / "report_ci.json"
        report_local = tmp_path / "report_local.json"

        result_ci = _run_gate(
            mode="ci",
            report_path=str(report_ci),
            paths=[str(dirty_file)],
        )
        result_local = _run_gate(
            mode="local",
            report_path=str(report_local),
            paths=[str(dirty_file)],
        )

        assert report_ci.exists(), "CI report must be created"
        assert report_local.exists(), "Local report must be created"

        def extract_key_fields(report_path: Path) -> list[tuple[str, int, str, str]]:
            findings = json.loads(report_path.read_text())
            return sorted(
                (f["path"], f["line"], f["symbol"], f["rule_id"])
                for f in findings
            )

        ci_keys = extract_key_fields(report_ci)
        local_keys = extract_key_fields(report_local)

        assert ci_keys == local_keys, (
            f"CI and local findings differ:\nCI:    {ci_keys}\nLocal: {local_keys}"
        )


# ---------------------------------------------------------------------------
# T12 — unreadable file causes exit 2
# ---------------------------------------------------------------------------

class TestT12UnreadableFileExitsTwo:
    """Error row 1: file that cannot be read yields exit code 2."""

    @pytest.mark.skipif(
        sys.platform == "win32" and os.getenv("CI") != "true",
        reason="File permission manipulation unreliable on Windows dev machines outside CI",
    )
    def test_unreadable_file_exits_two(self, tmp_path: Path) -> None:
        locked_file = tmp_path / "locked.py"
        locked_file.write_text(_DIRTY_SOURCE)
        locked_file.chmod(0o000)
        report_file = tmp_path / "report.json"

        try:
            result = _run_gate(
                mode="ci",
                report_path=str(report_file),
                paths=[str(locked_file)],
            )
        finally:
            locked_file.chmod(0o644)

        assert result.returncode == 2, (
            f"Expected exit code 2 for unreadable file; got {result.returncode}\n"
            f"stdout: {result.stdout}\nstderr: {result.stderr}"
        )


# ---------------------------------------------------------------------------
# T14 — missing report directory is auto-created
# ---------------------------------------------------------------------------

class TestT14MissingReportDirectoryIsCreated:
    """Error row 3: nested report output path with missing parents is auto-created."""

    def test_missing_report_directory_is_created(self, tmp_path: Path) -> None:
        clean_file = tmp_path / "clean_module.py"
        clean_file.write_text(_CLEAN_SOURCE)
        # Deep path that doesn't exist yet
        report_file = tmp_path / "deeply" / "nested" / "sub" / "report.json"

        assert not report_file.parent.exists(), "Precondition: parent dirs must not exist"

        result = _run_gate(
            mode="ci",
            report_path=str(report_file),
            paths=[str(clean_file)],
        )

        assert report_file.exists(), (
            f"Expected report file to be created at {report_file}; "
            f"exit={result.returncode} stderr={result.stderr}"
        )


# ---------------------------------------------------------------------------
# T15 — invalid mode argument exits 2
# ---------------------------------------------------------------------------

class TestT15InvalidModeExitsTwo:
    """Error row 4: passing an unknown --mode value exits 2 without creating a report."""

    def test_invalid_mode_exits_two(self, tmp_path: Path) -> None:
        report_file = tmp_path / "report.json"

        result = _run_gate(
            mode="badmode",
            report_path=str(report_file),
        )

        assert result.returncode == 2, (
            f"Expected exit code 2 for invalid mode; got {result.returncode}\n"
            f"stdout: {result.stdout}\nstderr: {result.stderr}"
        )


# ---------------------------------------------------------------------------
# T13 (integration) — syntax-error file causes CLI exit 2
# ---------------------------------------------------------------------------

class TestT13SyntaxErrorFileExitsTwoCLI:
    """Error row 2 (CLI level): file with Python syntax error causes exit code 2."""

    BROKEN_SOURCE = textwrap.dedent("""\
        def broken_function(:
            pass
    """)

    def test_syntax_error_file_causes_cli_exit_two(self, tmp_path: Path) -> None:
        broken_file = tmp_path / "broken.py"
        broken_file.write_text(self.BROKEN_SOURCE)
        report_file = tmp_path / "report.json"

        result = _run_gate(
            mode="ci",
            report_path=str(report_file),
            paths=[str(broken_file)],
        )

        assert result.returncode == 2, (
            f"Expected exit code 2 for syntax-error file; got {result.returncode}\n"
            f"stdout: {result.stdout}\nstderr: {result.stderr}"
        )
        assert report_file.exists(), "Report must be written even for syntax-error input"
        findings = json.loads(report_file.read_text())
        parse_findings = [f for f in findings if f["rule_id"] == "ECLE001-PARSE"]
        assert len(parse_findings) >= 1, (
            f"Expected ECLE001-PARSE finding in report; got: {findings}"
        )
