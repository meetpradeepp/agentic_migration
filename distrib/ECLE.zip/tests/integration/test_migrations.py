# Implements: SPEC-0009. Tests: Alembic migration 0001_phase1_schema
"""Integration tests for the Phase 1 Alembic schema migration."""

from __future__ import annotations

import os
import shutil
from pathlib import Path
from subprocess import CalledProcessError, run

import pytest

import psycopg2

from ecle.config import settings


def _alembic_cmd() -> list[str]:
    alembic_bin = shutil.which("alembic")
    if not alembic_bin:
        pytest.skip("Alembic executable not found in environment")
    return [alembic_bin]


TABLES = [
    "tenants",
    "repositories",
    "versions",
    "indexing_state",
    "import_jobs",
    "worker_lifecycle",
    "tenant_config",
    "api_keys",
    "query_audit_log",
    "file_facts",
    "file_tables",
    "file_entry_points",
    "file_external_calls",
    "file_literals",
    "function_facts",
    "function_calls",
    "function_table_ops",
    "cluster_assignments",
    "coverage_gap_counts",
    "confidence_votes",
    "semantic_annotations",
]

INDEXES = [
    "ix_file_facts_tenant_repo_current",
    "ix_file_facts_tenant_repo_file_path",
    "ix_file_facts_cluster_stable_current",
    "ix_file_tables_tenant_table_current",
    "ix_function_facts_tenant_repo_function_current",
    "ix_function_calls_tenant_callee_current",
    "uq_indexing_state_tenant_repo_entity",
    "uq_api_keys_key_hash",
    "ix_api_keys_tenant_revoked",
    "ix_query_audit_log_tenant_called_at",
    "ix_query_audit_log_subject_called_at",
    "uq_confidence_votes_tenant_entity",
    "uq_tenant_config_tenant_key",
    "ix_import_jobs_tenant_started_at",
    "ix_import_jobs_repo_status",
    "uq_worker_lifecycle_worker_name",
    "uq_semantic_annotations_current",
    "ix_repositories_tenant_platform",
]


@pytest.fixture
def project_root() -> Path:
    return Path(__file__).resolve().parents[2]


@pytest.fixture
def postgres_url() -> str:
    url = settings.database_url or os.environ.get("ECLE_DATABASE_URL", "")
    if not url.startswith("postgresql"):
        pytest.skip("SPEC-0009 integration tests require a PostgreSQL database URL")
    return url


@pytest.fixture
def migrated_db(monkeypatch: pytest.MonkeyPatch, project_root: Path, postgres_url: str):
    monkeypatch.chdir(project_root)
    monkeypatch.setenv("ECLE_DATABASE_URL", postgres_url)

    command = _alembic_cmd() + ["upgrade", "head"]
    try:
        run(command, check=True, cwd=project_root)
    except CalledProcessError as exc:
        pytest.skip(f"Alembic upgrade failed in integration environment: {exc}")

    connection = psycopg2.connect(postgres_url)
    try:
        yield connection
    finally:
        connection.close()
        run(_alembic_cmd() + ["downgrade", "base"], check=False, cwd=project_root)


def _fetch_catalog_rows(connection, query: str, params: tuple[str, ...]) -> list[str]:
    with connection.cursor() as cursor:
        cursor.execute(query, params)
        return [row[0] for row in cursor.fetchall()]


@pytest.mark.integration
def test_migration_0001_creates_all_tables(migrated_db) -> None:
    tables = _fetch_catalog_rows(
        migrated_db,
        """
        SELECT tablename
        FROM pg_tables
        WHERE schemaname = current_schema()
          AND tablename = ANY(%s)
        ORDER BY tablename
        """,
        (TABLES,),
    )
    indexes = _fetch_catalog_rows(
        migrated_db,
        """
        SELECT indexname
        FROM pg_indexes
        WHERE schemaname = current_schema()
          AND indexname = ANY(%s)
        ORDER BY indexname
        """,
        (INDEXES,),
    )

    assert tables == sorted(TABLES)
    assert indexes == sorted(INDEXES)


@pytest.mark.integration
def test_migration_0001_downgrade_drops_all_tables(migrated_db) -> None:
    project_root = Path(__file__).resolve().parents[2]
    run(_alembic_cmd() + ["downgrade", "base"], check=True, cwd=project_root)

    remaining = _fetch_catalog_rows(
        migrated_db,
        """
        SELECT tablename
        FROM pg_tables
        WHERE schemaname = current_schema()
          AND tablename = ANY(%s)
        """,
        (TABLES,),
    )

    assert remaining == []


@pytest.mark.integration
def test_migration_0001_is_idempotent(postgres_url: str, project_root: Path) -> None:
    run(_alembic_cmd() + ["upgrade", "head"], check=True, cwd=project_root)
    run(_alembic_cmd() + ["upgrade", "head"], check=True, cwd=project_root)

    connection = psycopg2.connect(postgres_url)
    try:
        tables = _fetch_catalog_rows(
            connection,
            """
            SELECT tablename
            FROM pg_tables
            WHERE schemaname = current_schema()
              AND tablename = ANY(%s)
            """,
            (TABLES,),
        )
    finally:
        connection.close()
        run(_alembic_cmd() + ["downgrade", "base"], check=False, cwd=project_root)

    assert sorted(tables) == sorted(TABLES)


@pytest.mark.integration
def test_migration_0001_bootstrap_rows(migrated_db) -> None:
    worker_names = _fetch_catalog_rows(
        migrated_db,
        """
        SELECT worker_name
        FROM worker_lifecycle
        WHERE worker_name = ANY(%s)
          AND command = 'run'
        ORDER BY worker_name
        """,
                (["scan_source", "parse_repo", "persist_facts"],),
    )

    assert worker_names == ["parse_repo", "persist_facts", "scan_source"]

