"""Phase 1 schema migration.

Implements: SPEC-0009
"""

from __future__ import annotations

from alembic import op


revision = "0001_phase1_schema"
down_revision = None
branch_labels = None
depends_on = None


TABLES: tuple[str, ...] = (
    "tenants",
    "repositories",
    "versions",
    "indexing_state",
    "import_jobs",
    "worker_lifecycle",
    "tenant_config",
    "api_keys",
    "query_audit_log",
    "file_facts",
    "file_tables",
    "file_entry_points",
    "file_external_calls",
    "file_literals",
    "function_facts",
    "function_calls",
    "function_table_ops",
    "cluster_assignments",
    "coverage_gap_counts",
    "confidence_votes",
    "semantic_annotations",
)

INDEXES: tuple[str, ...] = (
    "ix_file_facts_tenant_repo_current",
    "ix_file_facts_tenant_repo_file_path",
    "ix_file_facts_cluster_stable_current",
    "ix_file_tables_tenant_table_current",
    "ix_function_facts_tenant_repo_function_current",
    "ix_function_calls_tenant_callee_current",
    "uq_indexing_state_tenant_repo_entity",
    "uq_api_keys_key_hash",
    "ix_api_keys_tenant_revoked",
    "ix_query_audit_log_tenant_called_at",
    "ix_query_audit_log_subject_called_at",
    "uq_confidence_votes_tenant_entity",
    "uq_tenant_config_tenant_key",
    "ix_import_jobs_tenant_started_at",
    "ix_import_jobs_repo_status",
    "uq_worker_lifecycle_worker_name",
    "uq_semantic_annotations_current",
    "ix_repositories_tenant_platform",
)


def upgrade() -> None:
    op.execute("CREATE EXTENSION IF NOT EXISTS pgcrypto")

    op.execute(
        """
        CREATE TABLE IF NOT EXISTS tenants (
            tenant_id TEXT PRIMARY KEY,
            tenant_name TEXT NOT NULL,
            created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
        )
        """
    )
    op.execute(
        """
        CREATE TABLE IF NOT EXISTS repositories (
            tenant_id TEXT NOT NULL,
            repo_id TEXT NOT NULL,
            repo_name TEXT NOT NULL,
            platform TEXT NULL,
            primary_language TEXT NULL,
            repo_type TEXT NULL,
            created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
            PRIMARY KEY (tenant_id, repo_id)
        )
        """
    )
    op.execute(
        """
        CREATE TABLE IF NOT EXISTS versions (
            tenant_id TEXT NOT NULL,
            repo_id TEXT NOT NULL,
            version_id TEXT PRIMARY KEY,
            commit_sha TEXT NOT NULL,
            created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
        )
        """
    )
    op.execute(
        """
        CREATE TABLE IF NOT EXISTS indexing_state (
            tenant_id TEXT NOT NULL,
            repo_id TEXT NOT NULL,
            entity_id TEXT NOT NULL,
            status TEXT NOT NULL,
            updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
            PRIMARY KEY (tenant_id, repo_id, entity_id)
        )
        """
    )
    op.execute(
        """
        CREATE TABLE IF NOT EXISTS import_jobs (
            job_id TEXT PRIMARY KEY,
            tenant_id TEXT NOT NULL,
            repo_id TEXT NOT NULL,
            status TEXT NOT NULL,
            started_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
            finished_at TIMESTAMPTZ NULL
        )
        """
    )
    op.execute(
        """
        CREATE TABLE IF NOT EXISTS worker_lifecycle (
            worker_name TEXT PRIMARY KEY,
            command TEXT NOT NULL,
            tenant_id TEXT NULL,
            repo_id TEXT NULL,
            created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
            updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
        )
        """
    )
    op.execute(
        """
        CREATE TABLE IF NOT EXISTS tenant_config (
            tenant_id TEXT NOT NULL,
            config_key TEXT NOT NULL,
            config_value TEXT NOT NULL,
            updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
            PRIMARY KEY (tenant_id, config_key)
        )
        """
    )
    op.execute(
        """
        CREATE TABLE IF NOT EXISTS api_keys (
            key_hash TEXT PRIMARY KEY,
            tenant_id TEXT NOT NULL,
            revoked_at TIMESTAMPTZ NULL,
            created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
        )
        """
    )
    op.execute(
        """
        CREATE TABLE IF NOT EXISTS query_audit_log (
            audit_id TEXT PRIMARY KEY,
            tenant_id TEXT NOT NULL,
            subject TEXT NOT NULL,
            called_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
            query_text TEXT NOT NULL
        )
        """
    )
    op.execute(
        """
        CREATE TABLE IF NOT EXISTS file_facts (
            id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
            tenant_id TEXT NOT NULL,
            repo_id TEXT NOT NULL,
            file_path TEXT NOT NULL,
            cluster_stable_id TEXT NULL,
            is_current BOOLEAN NOT NULL DEFAULT TRUE,
            previous_id UUID NULL,
            superseded_at TIMESTAMPTZ NULL,
            content_hash TEXT NULL,
            created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
        )
        """
    )
    op.execute(
        """
        CREATE TABLE IF NOT EXISTS file_tables (
            id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
            tenant_id TEXT NOT NULL,
            repo_id TEXT NOT NULL,
            file_id UUID NOT NULL,
            table_name TEXT NOT NULL,
            is_current BOOLEAN NOT NULL DEFAULT TRUE,
            created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
        )
        """
    )
    op.execute(
        """
        CREATE TABLE IF NOT EXISTS file_entry_points (
            id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
            tenant_id TEXT NOT NULL,
            repo_id TEXT NOT NULL,
            file_id UUID NOT NULL,
            entry_point TEXT NOT NULL,
            is_current BOOLEAN NOT NULL DEFAULT TRUE,
            created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
        )
        """
    )
    op.execute(
        """
        CREATE TABLE IF NOT EXISTS file_external_calls (
            id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
            tenant_id TEXT NOT NULL,
            repo_id TEXT NOT NULL,
            file_id UUID NOT NULL,
            call_name TEXT NOT NULL,
            is_current BOOLEAN NOT NULL DEFAULT TRUE,
            created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
        )
        """
    )
    op.execute(
        """
        CREATE TABLE IF NOT EXISTS file_literals (
            id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
            tenant_id TEXT NOT NULL,
            repo_id TEXT NOT NULL,
            file_id UUID NOT NULL,
            literal_value TEXT NOT NULL,
            is_current BOOLEAN NOT NULL DEFAULT TRUE,
            created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
        )
        """
    )
    op.execute(
        """
        CREATE TABLE IF NOT EXISTS function_facts (
            id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
            tenant_id TEXT NOT NULL,
            repo_id TEXT NOT NULL,
            function_name TEXT NOT NULL,
            file_id UUID NOT NULL,
            is_current BOOLEAN NOT NULL DEFAULT TRUE,
            previous_id UUID NULL,
            superseded_at TIMESTAMPTZ NULL,
            created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
        )
        """
    )
    op.execute(
        """
        CREATE TABLE IF NOT EXISTS function_calls (
            id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
            tenant_id TEXT NOT NULL,
            repo_id TEXT NOT NULL,
            caller_name TEXT NOT NULL,
            callee_name TEXT NOT NULL,
            is_current BOOLEAN NOT NULL DEFAULT TRUE,
            created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
        )
        """
    )
    op.execute(
        """
        CREATE TABLE IF NOT EXISTS function_table_ops (
            id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
            tenant_id TEXT NOT NULL,
            repo_id TEXT NOT NULL,
            function_name TEXT NOT NULL,
            table_name TEXT NOT NULL,
            column_name TEXT NULL,
            is_current BOOLEAN NOT NULL DEFAULT TRUE,
            created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
        )
        """
    )
    op.execute(
        """
        CREATE TABLE IF NOT EXISTS cluster_assignments (
            id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
            tenant_id TEXT NOT NULL,
            repo_id TEXT NOT NULL,
            file_id UUID NOT NULL,
            cluster_stable_id TEXT NOT NULL,
            is_current BOOLEAN NOT NULL DEFAULT TRUE,
            created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
        )
        """
    )
    op.execute(
        """
        CREATE TABLE IF NOT EXISTS coverage_gap_counts (
            id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
            tenant_id TEXT NOT NULL,
            repo_id TEXT NOT NULL,
            gap_name TEXT NOT NULL,
            gap_count INTEGER NOT NULL DEFAULT 0,
            updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
        )
        """
    )
    op.execute(
        """
        CREATE TABLE IF NOT EXISTS confidence_votes (
            tenant_id TEXT NOT NULL,
            entity_id TEXT NOT NULL,
            subject TEXT NOT NULL,
            vote INTEGER NOT NULL,
            created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
            PRIMARY KEY (tenant_id, entity_id)
        )
        """
    )
    op.execute(
        """
        CREATE TABLE IF NOT EXISTS semantic_annotations (
            id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
            tenant_id TEXT NOT NULL,
            repo_id TEXT NOT NULL,
            target_type TEXT NOT NULL,
            target_id TEXT NOT NULL,
            rule_id TEXT NOT NULL,
            rule_version INTEGER NOT NULL,
            platform TEXT NULL,
            domain_entity TEXT NULL,
            type TEXT NULL,
            "group" TEXT NULL,
            role TEXT NULL,
            confidence DOUBLE PRECISION NOT NULL,
            is_current BOOLEAN NOT NULL DEFAULT TRUE,
            annotated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
        )
        """
    )

    op.execute("CREATE UNIQUE INDEX IF NOT EXISTS ix_file_facts_tenant_repo_current ON file_facts (tenant_id, repo_id, is_current)")
    op.execute("CREATE INDEX IF NOT EXISTS ix_file_facts_tenant_repo_file_path ON file_facts (tenant_id, repo_id, file_path)")
    op.execute("CREATE INDEX IF NOT EXISTS ix_file_facts_cluster_stable_current ON file_facts (cluster_stable_id, is_current)")
    op.execute("CREATE INDEX IF NOT EXISTS ix_file_tables_tenant_table_current ON file_tables (tenant_id, table_name, is_current)")
    op.execute("CREATE INDEX IF NOT EXISTS ix_function_facts_tenant_repo_function_current ON function_facts (tenant_id, repo_id, function_name, is_current)")
    op.execute("CREATE INDEX IF NOT EXISTS ix_function_calls_tenant_callee_current ON function_calls (tenant_id, callee_name, is_current)")
    op.execute("CREATE UNIQUE INDEX IF NOT EXISTS uq_indexing_state_tenant_repo_entity ON indexing_state (tenant_id, repo_id, entity_id)")
    op.execute("CREATE UNIQUE INDEX IF NOT EXISTS uq_api_keys_key_hash ON api_keys (key_hash)")
    op.execute("CREATE INDEX IF NOT EXISTS ix_api_keys_tenant_revoked ON api_keys (tenant_id, revoked_at)")
    op.execute("CREATE INDEX IF NOT EXISTS ix_query_audit_log_tenant_called_at ON query_audit_log (tenant_id, called_at)")
    op.execute("CREATE INDEX IF NOT EXISTS ix_query_audit_log_subject_called_at ON query_audit_log (subject, called_at)")
    op.execute("CREATE UNIQUE INDEX IF NOT EXISTS uq_confidence_votes_tenant_entity ON confidence_votes (tenant_id, entity_id)")
    op.execute("CREATE UNIQUE INDEX IF NOT EXISTS uq_tenant_config_tenant_key ON tenant_config (tenant_id, config_key)")
    op.execute("CREATE INDEX IF NOT EXISTS ix_import_jobs_tenant_started_at ON import_jobs (tenant_id, started_at DESC)")
    op.execute("CREATE INDEX IF NOT EXISTS ix_import_jobs_repo_status ON import_jobs (repo_id, status)")
    op.execute("CREATE UNIQUE INDEX IF NOT EXISTS uq_worker_lifecycle_worker_name ON worker_lifecycle (worker_name)")
    op.execute(
        "CREATE UNIQUE INDEX IF NOT EXISTS uq_semantic_annotations_current ON semantic_annotations (tenant_id, repo_id, target_type, target_id, rule_id) WHERE is_current = true"
    )
    op.execute("CREATE INDEX IF NOT EXISTS ix_repositories_tenant_platform ON repositories (tenant_id, platform)")

    op.execute(
        """
        INSERT INTO worker_lifecycle (worker_name, command)
        VALUES ('scan_source', 'run'), ('parse_repo', 'run'), ('persist_facts', 'run')
        ON CONFLICT (worker_name) DO NOTHING
        """
    )


def downgrade() -> None:
    op.execute("DROP INDEX IF EXISTS ix_repositories_tenant_platform")
    op.execute("DROP INDEX IF EXISTS uq_semantic_annotations_current")
    op.execute("DROP INDEX IF EXISTS uq_worker_lifecycle_worker_name")
    op.execute("DROP INDEX IF EXISTS ix_import_jobs_repo_status")
    op.execute("DROP INDEX IF EXISTS ix_import_jobs_tenant_started_at")
    op.execute("DROP INDEX IF EXISTS uq_tenant_config_tenant_key")
    op.execute("DROP INDEX IF EXISTS uq_confidence_votes_tenant_entity")
    op.execute("DROP INDEX IF EXISTS ix_query_audit_log_subject_called_at")
    op.execute("DROP INDEX IF EXISTS ix_query_audit_log_tenant_called_at")
    op.execute("DROP INDEX IF EXISTS ix_api_keys_tenant_revoked")
    op.execute("DROP INDEX IF EXISTS uq_api_keys_key_hash")
    op.execute("DROP INDEX IF EXISTS uq_indexing_state_tenant_repo_entity")
    op.execute("DROP INDEX IF EXISTS ix_function_calls_tenant_callee_current")
    op.execute("DROP INDEX IF EXISTS ix_function_facts_tenant_repo_function_current")
    op.execute("DROP INDEX IF EXISTS ix_file_tables_tenant_table_current")
    op.execute("DROP INDEX IF EXISTS ix_file_facts_cluster_stable_current")
    op.execute("DROP INDEX IF EXISTS ix_file_facts_tenant_repo_file_path")
    op.execute("DROP INDEX IF EXISTS ix_file_facts_tenant_repo_current")

    for table in reversed(TABLES):
        op.execute(f"DROP TABLE IF EXISTS {table}")

