"""Versioned Alembic migrations for ECLE Phase 1.

Implements: SPEC-0009
"""
