"""Alembic package for ECLE Phase 1 schema migrations.

Implements: SPEC-0009
"""
