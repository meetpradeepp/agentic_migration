# ECLE 2.0 — Deterministic Code Intelligence Engine.
#
# This package is the root of all ECLE source code.
# See constitution/README.md for project rules.
# See specs/phase-N/ for specifications.
