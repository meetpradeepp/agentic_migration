"""
exceptions — ECLE 2.0 base exception hierarchy.

Implements: SPEC-0001
Reads:  N/A
Writes: N/A — exception class definitions only
"""

from __future__ import annotations


class ECLEBaseError(Exception):
    """Base class for all ECLE runtime errors.

    WorkerBase retries on ECLEBaseError (transient). Subclasses that represent
    permanent failures should raise PermanentWorkerError instead.
    """


class ArtifactNotFoundError(ECLEBaseError):
    """Raised when a requested artifact path does not exist in the artifact store."""

    def __init__(self, path: str) -> None:
        self.path = path
        super().__init__(f"Artifact not found: {path}")


class InvalidLanguagePackError(ECLEBaseError):
    """Raised when a language pack module does not implement the ILanguagePack interface."""


class DBConnectionError(ECLEBaseError):
    """Raised when the structured database backend is unreachable or returns a fatal error."""


class InvalidConfigError(ECLEBaseError):
    """Raised when a configuration value is invalid or a required field is missing."""


class PermanentWorkerError(ECLEBaseError):
    """Route message to DLQ immediately; no retry."""
