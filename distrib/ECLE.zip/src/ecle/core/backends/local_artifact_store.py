"""Local filesystem artifact store.

Implements: SPEC-0009
Reads:  local filesystem under configured artifact root
Writes: local filesystem under configured artifact root
"""

from __future__ import annotations

import os
import tempfile
from pathlib import Path

from ecle.core.exceptions import ArtifactNotFoundError
from ecle.core.interfaces import IArtifactStore


class LocalArtifactStore(IArtifactStore):
    """Filesystem-backed artifact store rooted at a configured directory."""

    def __init__(self, root: Path) -> None:
        self._root = root

    def _resolve(self, path: str) -> Path:
        return self._root / path

    def write(self, path: str, data: bytes) -> None:
        target = self._resolve(path)
        target.parent.mkdir(parents=True, exist_ok=True)

        # Write to temp file in same directory, then atomically replace.
        with tempfile.NamedTemporaryFile(dir=target.parent, delete=False) as tmp_file:
            tmp_file.write(data)
            tmp_path = tmp_file.name

        os.replace(tmp_path, target)

    def read(self, path: str) -> bytes:
        target = self._resolve(path)
        try:
            return target.read_bytes()
        except FileNotFoundError as exc:
            raise ArtifactNotFoundError(path) from exc

    def exists(self, path: str) -> bool:
        return self._resolve(path).exists()

    def delete(self, path: str) -> None:
        try:
            self._resolve(path).unlink()
        except FileNotFoundError:
            return
