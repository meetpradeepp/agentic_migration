"""Backend factory functions for ECLE 2.0.

Implements: SPEC-0001, SPEC-0009
Reads:  ecle.config.settings
Writes: None
"""

from __future__ import annotations

from pathlib import Path

import psycopg2  # type: ignore[import]

from ecle.config import settings
from ecle.core.backends.local_artifact_store import LocalArtifactStore
from ecle.core.backends.postgresql_db import PostgreSQLStructuredDB
from ecle.core.exceptions import DBConnectionError, InvalidConfigError
from ecle.core.interfaces import IArtifactStore, IStructuredDB, ITopologyGraph, IVectorStore


def get_structured_db() -> IStructuredDB:
    """Return a concrete IStructuredDB instance based on settings.structured_backend."""
    backend = settings.structured_backend
    if backend == "postgresql":
        try:
            connection = psycopg2.connect(settings.database_url)
        except psycopg2.Error as exc:
            raise DBConnectionError("Failed to connect to PostgreSQL") from exc
        return PostgreSQLStructuredDB(connection)

    raise InvalidConfigError(f"Unknown STRUCTURED_BACKEND: {backend}")


def get_artifact_store() -> IArtifactStore:
    """Return a concrete IArtifactStore instance based on settings.artifact_backend."""
    backend = settings.artifact_backend
    if backend == "local":
        return LocalArtifactStore(root=Path(settings.artifact_store_path))

    raise InvalidConfigError(f"Unknown ARTIFACT_BACKEND: {backend}")


def get_vector_store() -> IVectorStore:
    """Return a concrete IVectorStore instance (Phase 2)."""
    raise NotImplementedError("IVectorStore concrete implementation deferred to Phase 2")


def get_topology_graph() -> ITopologyGraph:
    """Return a concrete ITopologyGraph instance (Phase 3)."""
    raise NotImplementedError("ITopologyGraph concrete implementation deferred to Phase 3")
