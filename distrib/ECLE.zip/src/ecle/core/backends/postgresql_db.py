"""PostgreSQL structured DB backend.

Implements: SPEC-0009
Reads:  PostgreSQL tables via parameterized SQL
Writes: PostgreSQL tables via parameterized SQL
"""

from __future__ import annotations

from collections.abc import Sequence
from typing import Any

import psycopg2  # type: ignore[import]
from psycopg2 import sql  # type: ignore[import]

from ecle.core.exceptions import DBConnectionError
from ecle.core.interfaces import IStructuredDB


class PostgreSQLStructuredDB(IStructuredDB):
    """IStructuredDB implementation backed by psycopg2 connection."""

    SYSTEM_TABLES: frozenset[str] = frozenset(
        {
            "worker_lifecycle",
            "tenants",
            "tenant_config",
            "api_keys",
            "query_audit_log",
        }
    )

    def __init__(self, connection: Any) -> None:
        self._connection = connection

    def execute(
        self,
        sql: str,
        params: Sequence[Any] | dict[str, Any] | None = None,
        *,
        tenant_id: str,
    ) -> list[dict[str, Any]]:
        """Execute SQL and return rows as list[dict]."""
        query = sql
        final_params: Sequence[Any] | dict[str, Any] | None = params

        if tenant_id != "__system__":
            if isinstance(params, dict):
                final_params = dict(params)
                final_params["tenant_id"] = tenant_id
                if " where " in sql.lower():
                    query = sql + " AND tenant_id = %(tenant_id)s"
                else:
                    query = sql + " WHERE tenant_id = %(tenant_id)s"
            else:
                base = list(params or [])
                base.append(tenant_id)
                final_params = base
                if " where " in sql.lower():
                    query = sql + " AND tenant_id = %s"
                else:
                    query = sql + " WHERE tenant_id = %s"

        try:
            with self._connection.cursor() as cursor:
                cursor.execute(query, final_params)
                if cursor.description is None:
                    return []
                columns = [c[0] for c in cursor.description]
                rows = cursor.fetchall()
                return [dict(zip(columns, row, strict=False)) for row in rows]
        except psycopg2.Error as exc:
            raise DBConnectionError("PostgreSQL execute failed") from exc
        except Exception as exc:  # noqa: BLE001
            raise DBConnectionError("PostgreSQL execute failed") from exc

    def upsert(
        self,
        table: str,
        row: dict[str, Any],
        *,
        conflict_keys: Sequence[str],
        tenant_id: str,
    ) -> None:
        """Upsert row into *table* with version-chain behavior for fact tables."""
        table_ident = sql.Identifier(table)
        conflict_idents = [sql.Identifier(k) for k in conflict_keys]

        try:
            with self._connection.cursor() as cursor:
                if table in self.SYSTEM_TABLES:
                    # System tables use regular upsert (no version-chain).
                    columns = list(row.keys())
                    insert_cols = sql.SQL(", ").join(sql.Identifier(c) for c in columns)
                    values_placeholders = sql.SQL(", ").join(
                        sql.Placeholder(c) for c in columns
                    )
                    update_cols = [c for c in columns if c not in conflict_keys]
                    set_clause = sql.SQL(", ").join(
                        sql.SQL("{} = EXCLUDED.{}").format(
                            sql.Identifier(c), sql.Identifier(c)
                        )
                        for c in update_cols
                    )

                    query = sql.SQL(
                        "INSERT INTO {} ({}) VALUES ({}) "
                        "ON CONFLICT ({}) DO UPDATE SET {}"
                    ).format(
                        table_ident,
                        insert_cols,
                        values_placeholders,
                        sql.SQL(", ").join(conflict_idents),
                        set_clause,
                    )
                    cursor.execute(query, row)
                    self._connection.commit()
                    return

                # Fact tables: two-step version chain.
                conflict_where = sql.SQL(" AND ").join(
                    sql.SQL("{} = {}")
                    .format(sql.Identifier(k), sql.Placeholder(k))
                    for k in conflict_keys
                )

                update_query = sql.SQL(
                    "UPDATE {} "
                    "SET is_current = false, superseded_at = NOW() "
                    "WHERE {} AND tenant_id = %(tenant_id)s AND is_current = true "
                    "RETURNING id"
                ).format(table_ident, conflict_where)

                update_params = {k: row[k] for k in conflict_keys if k in row}
                update_params["tenant_id"] = tenant_id
                cursor.execute(update_query, update_params)
                prev = cursor.fetchone()
                previous_id = prev[0] if prev else None

                insert_row = dict(row)
                insert_row["is_current"] = True
                insert_row["previous_id"] = previous_id

                columns = list(insert_row.keys())
                insert_cols = sql.SQL(", ").join(sql.Identifier(c) for c in columns)
                values_placeholders = sql.SQL(", ").join(
                    sql.Placeholder(c) for c in columns
                )
                insert_query = sql.SQL("INSERT INTO {} ({}) VALUES ({})").format(
                    table_ident,
                    insert_cols,
                    values_placeholders,
                )
                cursor.execute(insert_query, insert_row)
                self._connection.commit()
        except psycopg2.Error as exc:
            self._connection.rollback()
            raise DBConnectionError("PostgreSQL upsert failed") from exc
        except Exception as exc:  # noqa: BLE001
            self._connection.rollback()
            raise DBConnectionError("PostgreSQL upsert failed") from exc

    def close(self) -> None:
        """Close underlying psycopg2 connection."""
        self._connection.close()
