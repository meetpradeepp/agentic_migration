# Core module — interfaces, backend factories, shared utilities.
