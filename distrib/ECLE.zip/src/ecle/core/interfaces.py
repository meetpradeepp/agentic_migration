"""
interfaces — Abstract base interfaces for ECLE 2.0 backend adapters.

Implements: SPEC-0001
Reads:  N/A
Writes: N/A — interface definitions only
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from pathlib import Path
from typing import Any, Sequence

# Phase 1 type alias; refined in Phase 2 (Contract 17 §1)
DetectedLayer = dict[str, Any]


class IStructuredDB(ABC):
    """Abstract interface for the structured fact database (PostgreSQL or SQLite)."""

    @abstractmethod
    def execute(
        self,
        sql: str,
        params: Sequence[Any] | dict[str, Any] | None = None,
        *,
        tenant_id: str,
    ) -> list[dict[str, Any]]:
        """Execute a parameterised SELECT query and return rows as dicts."""

    @abstractmethod
    def upsert(
        self,
        table: str,
        row: dict[str, Any],
        *,
        conflict_keys: Sequence[str],
        tenant_id: str,
    ) -> None:
        """Insert or update a row using the conflict-key partial unique index."""

    @abstractmethod
    def close(self) -> None:
        """Release the underlying database connection."""


class IArtifactStore(ABC):
    """Abstract interface for the artifact store (local filesystem or S3).

    Contract 14 §4 — exact signature match required for all concrete backends.
    """

    @abstractmethod
    def write(self, path: str, data: bytes) -> None:
        """Write bytes to the given artifact path, creating parents as needed."""

    @abstractmethod
    def read(self, path: str) -> bytes:
        """Read and return the raw bytes at the given artifact path.

        Raises:
            ArtifactNotFoundError: If no artifact exists at *path*.
        """

    @abstractmethod
    def exists(self, path: str) -> bool:
        """Return True if an artifact exists at the given path."""

    @abstractmethod
    def delete(self, path: str) -> None:
        """Remove the artifact at *path*. No-op if absent (idempotent)."""


class ILanguagePack(ABC):
    """Abstract interface for language extraction packs.

    Contract 08 §4 — exact signature match required.
    extract() MUST NEVER raise — internal errors appended to result['extraction_errors'].
    """

    @property
    @abstractmethod
    def language_id(self) -> str:
        """Return the canonical language identifier (e.g. 'python', 'powerbuilder')."""

    @abstractmethod
    def sanitize(self, source_bytes: bytes) -> bytes:
        """Strip BOMs and normalise raw source bytes before parsing.

        Raises:
            UnicodeDecodeError: If the bytes cannot be decoded by the expected codec.
        """

    @abstractmethod
    def extract(
        self,
        tree_or_bytes: Any,
        source_bytes: bytes,
        file_path: Path,
        language_dir: Path,
        detected_layers: list[DetectedLayer] | None = None,
    ) -> dict[str, Any]:
        """Run full extraction; return dict always including 'extraction_errors' key.

        Implementations MUST catch all internal exceptions and append them as
        ``{"type": ExcClassName, "msg": str(e)}`` to ``result["extraction_errors"]``.
        Contract 08 §4: ``detected_layers`` canonical type is ``list``; ABC uses ``None``
        to comply with Contract 10 (no mutable default). Implementations guard:
        ``if detected_layers is None: detected_layers = []``.
        """


class IVectorStore(ABC):
    """Abstract stub — Phase 2 concrete implementation (Contract 17 §1)."""

    @abstractmethod
    def search(
        self,
        collection: str,
        query_vector: list[float],
        limit: int,
        *,
        tenant_id: str,
    ) -> list[dict[str, Any]]:
        """Return nearest-neighbour results from the vector store."""

    @abstractmethod
    def upsert(
        self,
        collection: str,
        vectors: list[dict[str, Any]],
        *,
        tenant_id: str,
    ) -> None:
        """Insert or update embedding vectors in the given collection."""

    @abstractmethod
    def close(self) -> None:
        """Release the underlying vector store connection."""


class ITopologyGraph(ABC):
    """Abstract stub — Phase 3 concrete implementation (Contract 17 §1)."""

    @abstractmethod
    def query(
        self,
        cypher: str,
        params: dict[str, Any],
        *,
        tenant_id: str,
    ) -> list[dict[str, Any]]:
        """Execute a Cypher query and return rows as dicts."""

    @abstractmethod
    def merge_node(
        self,
        label: str,
        identity: dict[str, Any],
        properties: dict[str, Any],
        *,
        tenant_id: str,
    ) -> None:
        """Merge a node by identity keys; update properties on match."""

    @abstractmethod
    def close(self) -> None:
        """Release the underlying graph database connection."""
