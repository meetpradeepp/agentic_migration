"""
worker_base — Minimal WorkerBase stub for SPEC-0008.

Implements: SPEC-0008 (stub — full implementation in Stream 1)
Reads:  N/A — abstract base class only
Writes: N/A
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from ecle.config import Settings
    from ecle.core.interfaces import IStructuredDB


class WorkerBase(ABC):
    """Minimal stub for SPEC-0008 WorkerBase. Full implementation in Stream 1."""

    def __init__(
        self,
        consumer: Any,
        producer: Any,
        db: IStructuredDB,
        settings: Settings,
    ) -> None:
        """Initialise with injected Kafka consumer, producer, DB, and settings."""
        self.consumer = consumer
        self.producer = producer
        self.db = db
        self.settings = settings

    @property
    @abstractmethod
    def worker_name(self) -> str:
        """Return the unique worker name identifier."""

    @property
    @abstractmethod
    def input_topic(self) -> str:
        """Return the Kafka topic this worker consumes from."""

    @abstractmethod
    def process(self, event: dict[str, Any]) -> None:
        """Process a single deserialized Kafka event payload."""
