"""
WorkerBase ABC for all ECLE Kafka consumer workers.

Implements: SPEC-0008
Reads:  worker_lifecycle table (via IStructuredDB)
Writes: DLQ topics (via Kafka producer)
"""

from __future__ import annotations

import json
import logging
import time
from abc import ABC, abstractmethod
from datetime import datetime, timezone
from typing import Any

from confluent_kafka import KafkaException  # type: ignore[import]

from ecle.config import Settings
from ecle.constants import WORKER_LIFECYCLE_POLL_S
from ecle.core.exceptions import ECLEBaseError, PermanentWorkerError
from ecle.core.interfaces import IStructuredDB
from ecle.events.topic_registry import dlq_topic

_log = logging.getLogger(__name__)


class WorkerBase(ABC):
    """Abstract base class for all ECLE Kafka consumer workers."""

    def __init__(
        self,
        consumer: Any,
        producer: Any,
        db: IStructuredDB,
        settings: Settings,
    ) -> None:
        self._consumer = consumer
        self._producer = producer
        self._db = db
        self._settings = settings
        self._retry_count: int = 0
        self._draining_done: bool = False
        self._lifecycle_cache: str | None = None
        self._lifecycle_checked_at: float = 0.0
        self._pending_msg: Any = None
        self._pending_event: dict[str, Any] | None = None

    # ------------------------------------------------------------------
    # Abstract interface
    # ------------------------------------------------------------------

    @property
    @abstractmethod
    def worker_name(self) -> str:
        """Unique worker identifier (e.g. 'parse_repo')."""

    @property
    @abstractmethod
    def input_topic(self) -> str:
        """Kafka topic this worker subscribes to."""

    @abstractmethod
    def process(self, event: dict[str, Any]) -> None:
        """Process a single decoded event dict. Raise ECLEBaseError for transient failures."""

    # ------------------------------------------------------------------
    # Main loop
    # ------------------------------------------------------------------

    def run(self) -> None:
        """Subscribe to input_topic and poll/process indefinitely."""
        self._consumer.subscribe([self.input_topic])

        while True:
            try:
                msg = self._consumer.poll(
                    getattr(self._settings, "KAFKA_POLL_TIMEOUT_MS", 1000) / 1000.0
                )
            except KafkaException as exc:
                _log.error("poll error on %s: %s", self.input_topic, exc)
                continue

            if msg is None:
                continue

            # Lifecycle check
            state = self._check_lifecycle()
            if state == "paused":
                time.sleep(1)
                continue
            if state == "draining":
                lag = self._compute_lag()
                if lag == 0:
                    self._draining_done = True
                time.sleep(1)
                continue

            # Decode
            try:
                raw = msg.value().decode("utf-8")
                event = json.loads(raw)
            except Exception as exc:
                self._route_to_dlq(msg, PermanentWorkerError("JSON decode failure") if not isinstance(exc, PermanentWorkerError) else exc)
                continue

            self._pending_msg = msg
            self._pending_event = event

            # Process
            try:
                self.process(event)
                self._consumer.commit(msg, asynchronous=False)
                _log.debug("committed offset for %s", msg.topic())
                self._retry_count = 0
            except PermanentWorkerError as exc:
                self._route_to_dlq(msg, exc)
            except ECLEBaseError as exc:
                max_retries = getattr(self._settings, "kafka_dlq_max_retries", 3)
                self._retry_count += 1
                if self._retry_count < max_retries:
                    linger = min(2 ** self._retry_count, 30)
                    time.sleep(linger)
                    # Do not commit; same message will be reprocessed
                else:
                    self._route_to_dlq(msg, exc)

    # ------------------------------------------------------------------
    # DLQ routing
    # ------------------------------------------------------------------

    def _route_to_dlq(self, msg: Any, exc: Exception) -> None:
        """Produce *msg* to the DLQ topic and commit offset."""
        headers_raw = msg.headers() or []
        headers: dict[str, str] = {
            k: (v.decode("utf-8") if isinstance(v, bytes) else str(v))
            for k, v in headers_raw
        }

        envelope = {
            "X-Request-Id": headers.get("X-Request-Id", ""),
            "X-Trace-Id": headers.get("X-Trace-Id", ""),
            "original_topic": msg.topic(),
            "original_payload": self._pending_event or {},
            "error_type": type(exc).__name__,
            "error_message": str(exc),
            "worker_name": self.worker_name,
            "retry_count": self._retry_count,
            "failed_at": datetime.now(tz=timezone.utc).isoformat().replace("+00:00", "Z"),
        }

        try:
            self._producer.produce(
                dlq_topic(msg.topic()),
                value=json.dumps(envelope).encode("utf-8"),
            )
            self._producer.flush()
        except KafkaException as kafka_exc:
            _log.critical(
                "DLQ produce failed for %s (%s): %s",
                msg.topic(),
                headers.get("X-Request-Id", ""),
                kafka_exc,
                exc_info=True,
            )
            self._retry_count = 0
            return

        self._consumer.commit(msg, asynchronous=False)
        _log.error(
            "routed to DLQ topic=%s request_id=%s error_type=%s",
            msg.topic(),
            headers.get("X-Request-Id", ""),
            type(exc).__name__,
        )
        self._retry_count = 0

    # ------------------------------------------------------------------
    # Draining
    # ------------------------------------------------------------------

    def _compute_lag(self) -> int:
        """Return total consumer lag across all assigned partitions."""
        lag = 0
        for partition in self._consumer.assignment():
            _low, high = self._consumer.get_watermark_offsets(partition)
            pos = self._consumer.position(partition)
            lag += max(0, high - pos)
        return lag

    # ------------------------------------------------------------------
    # Lifecycle control
    # ------------------------------------------------------------------

    def _check_lifecycle(self) -> str:
        """Return current lifecycle command from DB, with TTL cache."""
        now = time.monotonic()
        if (
            self._lifecycle_cache is not None
            and (now - self._lifecycle_checked_at) < WORKER_LIFECYCLE_POLL_S
        ):
            return self._lifecycle_cache

        try:
            rows = self._db.execute(
                "SELECT command FROM worker_lifecycle WHERE worker_name = %s",
                [self.worker_name],
                tenant_id="__system__",
            )
        except Exception as exc:  # noqa: BLE001
            _log.warning(
                "lifecycle DB query failed for worker %s — defaulting to running: %s",
                self.worker_name,
                exc,
            )
            self._lifecycle_cache = "running"
            self._lifecycle_checked_at = now
            return "running"

        if not rows:
            _log.warning(
                "No lifecycle row found for worker %s — defaulting to running",
                self.worker_name,
            )
            self._lifecycle_cache = "running"
            self._lifecycle_checked_at = now
            return "running"

        command = rows[0].get("command", "run")
        _command_map = {
            "run": "running",
            "pause": "paused",
            "drain": "draining",
        }
        if command == "reset_offset":
            _log.critical("reset_offset command received for worker %s", self.worker_name)
            state = "running"
        else:
            state = _command_map.get(command, "running")

        self._lifecycle_cache = state
        self._lifecycle_checked_at = now
        return state

    # ------------------------------------------------------------------
    # Shutdown
    # ------------------------------------------------------------------

    def close(self) -> None:
        """Gracefully close consumer and flush producer."""
        if self._pending_msg is not None:
            try:
                self._consumer.commit(self._pending_msg, asynchronous=False)
            except Exception:  # noqa: BLE001
                pass
        self._consumer.close()
        self._producer.flush()

