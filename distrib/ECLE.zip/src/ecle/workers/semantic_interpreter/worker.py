"""
worker — SemanticInterpreter Kafka worker (file and repo trigger modes).

Implements: SPEC-0010
Reads:  ecle.file.stored (mode='file'), ecle.repo.indexed (mode='repo');
        function_facts, file_tables, function_table_ops, repositories
        (read-only, delegated to RuleEvaluator and RuleLoader)
Writes: semantic_annotations (via IStructuredDB.upsert);
        ecle.facts.annotated Kafka topic (mode='repo' only)
"""

from __future__ import annotations

import datetime
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any, Literal

from ecle.core.exceptions import ECLEBaseError
from ecle.events.topic_registry import TOPIC_FACTS_ANNOTATED
from ecle.workers.worker_base import WorkerBase

if TYPE_CHECKING:
    from ecle.config import Settings
    from ecle.core.interfaces import IStructuredDB
    from ecle.workers.semantic_interpreter.evaluator import AnnotationResult, RuleEvaluator
    from ecle.workers.semantic_interpreter.rule_loader import RuleLoader

_TOPIC_FILE_STORED: str = "ecle.file.stored"
_TOPIC_REPO_INDEXED: str = "ecle.repo.indexed"

_SEMANTIC_ANNOTATIONS_TABLE: str = "semantic_annotations"
_ANNOTATION_CONFLICT_KEYS: list[str] = [
    "tenant_id",
    "repo_id",
    "target_type",
    "target_id",
    "rule_id",
]


@dataclass
class FactsAnnotatedPayload:
    """Payload for the ecle.facts.annotated event (AC-12, SPEC-0010)."""

    repo_id: str
    tenant_id: str
    annotation_count: int
    rule_ids: list[str]
    annotated_at: str  # ISO-8601 UTC
    X_Request_Id: str | None = None
    X_Trace_Id: str | None = None

    def dict(self) -> dict[str, Any]:
        """Serialise to a plain dict for Kafka produce."""
        return {
            "repo_id": self.repo_id,
            "tenant_id": self.tenant_id,
            "annotation_count": self.annotation_count,
            "rule_ids": self.rule_ids,
            "annotated_at": self.annotated_at,
            "X_Request_Id": self.X_Request_Id,
            "X_Trace_Id": self.X_Trace_Id,
        }


class SemanticInterpreter(WorkerBase):
    """Deterministic semantic annotation worker (SPEC-0010, ADR-0034).

    mode='file': consumes ecle.file.stored → annotates file facts → upserts →
                 commits offset. Does NOT emit ecle.facts.annotated.
    mode='repo': consumes ecle.repo.indexed → annotates repo facts → upserts →
                 produces ecle.facts.annotated → flushes → commits offset.
    """

    def __init__(  # noqa: PLR0913
        self,
        consumer: Any,
        producer: Any,
        db: IStructuredDB,
        settings: Settings,
        *,
        rule_loader: RuleLoader,
        evaluator: RuleEvaluator,
        mode: Literal["file", "repo"],
    ) -> None:
        """Initialise with injected dependencies and operating mode."""
        super().__init__(consumer=consumer, producer=producer, db=db, settings=settings)
        self._rule_loader = rule_loader
        self._evaluator = evaluator
        self._mode = mode

    @property
    def worker_name(self) -> str:
        """Return the worker name identifier (AC-19)."""
        return f"semantic_interpreter_{self._mode}"

    @property
    def input_topic(self) -> str:
        """Return the Kafka input topic for this mode (AC-19)."""
        if self._mode == "file":
            return _TOPIC_FILE_STORED
        return _TOPIC_REPO_INDEXED

    def process(self, event: dict[str, Any]) -> None:
        """Dispatch the event to the appropriate mode handler."""
        if self._mode == "file":
            self._process_file(event)
        else:
            self._process_repo(event)

    # ------------------------------------------------------------------
    # Private mode handlers
    # ------------------------------------------------------------------

    def _process_file(self, event: dict[str, Any]) -> None:
        """Handle ecle.file.stored event (SPEC-0010 Behaviour 4-8, AC-12b)."""
        file_id: str = event["file_id"]
        repo_id: str = event["repo_id"]
        tenant_id: str = event["tenant_id"]

        rules = self._rule_loader.get_annotation_rules(repo_id, tenant_id)
        results = self._evaluator.evaluate_file(file_id, repo_id, rules)
        self._upsert_annotations(results, repo_id=repo_id, tenant_id=tenant_id)
        self.consumer.commit()

    def _process_repo(self, event: dict[str, Any]) -> None:
        """Handle ecle.repo.indexed event (SPEC-0010 Behaviour 9-14, AC-12)."""
        repo_id: str = event["repo_id"]
        tenant_id: str = event["tenant_id"]
        x_request_id: str | None = event.get("X_Request_Id")
        x_trace_id: str | None = event.get("X_Trace_Id")

        rules = self._rule_loader.get_annotation_rules(repo_id, tenant_id)
        results = self._evaluator.evaluate_repo(repo_id, tenant_id, rules)
        self._upsert_annotations(results, repo_id=repo_id, tenant_id=tenant_id)

        rule_ids = sorted({r.rule_id for r in results})
        payload = FactsAnnotatedPayload(
            repo_id=repo_id,
            tenant_id=tenant_id,
            annotation_count=len(results),
            rule_ids=rule_ids,
            annotated_at=datetime.datetime.now(datetime.UTC).isoformat(),
            X_Request_Id=x_request_id,
            X_Trace_Id=x_trace_id,
        )
        try:
            self.producer.produce(TOPIC_FACTS_ANNOTATED, payload.dict())
            self.producer.flush()
        except Exception as exc:
            raise ECLEBaseError(
                f"Failed to produce {TOPIC_FACTS_ANNOTATED} for repo_id={repo_id!r}: {exc}"
            ) from exc

        self.consumer.commit()

    def _upsert_annotations(
        self,
        results: list[AnnotationResult],
        *,
        repo_id: str,
        tenant_id: str,
    ) -> None:
        """Write each AnnotationResult to semantic_annotations (AC-21, SPEC-0010 §Behaviour 7)."""
        for result in results:
            self.db.upsert(
                _SEMANTIC_ANNOTATIONS_TABLE,
                {
                    "repo_id": repo_id,
                    "target_type": result.target_type,
                    "target_id": result.target_id,
                    "rule_id": result.rule_id,
                    "rule_version": result.rule_version,
                    "platform": result.platform,
                    "domain_entity": result.domain_entity,
                    "type": result.type,
                    "group": result.group,
                    "role": result.role,
                    "confidence": result.confidence,
                    "annotated_at": datetime.datetime.now(datetime.UTC).isoformat(),
                },
                conflict_keys=_ANNOTATION_CONFLICT_KEYS,
                tenant_id=tenant_id,
            )
