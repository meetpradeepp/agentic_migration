"""
rule_loader — YAML rule loading, glob/regex compilation, applies_to pre-filter.

Implements: SPEC-0010
Reads:  YAML rule files from settings.semantic_rules_base_path (filesystem) and
        settings.semantic_rules_artifact_path_prefix paths (IArtifactStore)
Writes: N/A — builds compiled rule cache used by RuleEvaluator; no DB writes
"""

from __future__ import annotations

import fnmatch
import logging
import re
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING, Literal

import yaml
from pydantic import ValidationError

from ecle.core.exceptions import DBConnectionError, ECLEBaseError
from ecle.workers.semantic_interpreter.rule_schema import (
    AnnotationRule,
    CoOccurrenceMatch,
    RuleFile,
    RuleGroup,
    SingleFactMatch,
)

if TYPE_CHECKING:
    from ecle.config import Settings
    from ecle.core.interfaces import IArtifactStore, IStructuredDB

logger = logging.getLogger(__name__)

# Tier sort order — lower number = higher precedence (repo wins over tenant wins over base)
_TIER_ORDER: dict[str, int] = {"repo": 0, "tenant": 1, "base": 2}


# ---------------------------------------------------------------------------
# Public dataclass
# ---------------------------------------------------------------------------


@dataclass
class CompiledAnnotationRule:
    """Annotation rule with pattern pre-compiled at load time (Contract 20 §5)."""

    rule: AnnotationRule
    compiled_pattern: re.Pattern[str] | None  # None for CoOccurrenceMatch rules
    tier: Literal["base", "tenant", "repo"]


# ---------------------------------------------------------------------------
# Private helpers
# ---------------------------------------------------------------------------


def _compile_annotation_pattern(
    match: SingleFactMatch | CoOccurrenceMatch,
) -> re.Pattern[str] | None:
    """Compile pattern at load time — NEVER during evaluation (Contract 20 §5).

    Returns None for CoOccurrenceMatch rules (no compiled pattern needed).
    For SingleFactMatch:
      - "re:<regex>" prefix → strip prefix, compile as Python regex.
      - plain string         → treat as fnmatch glob, convert via fnmatch.translate.
    """
    if isinstance(match, CoOccurrenceMatch):
        return None
    pattern = match.pattern
    if pattern.startswith("re:"):
        return re.compile(pattern[3:])
    # Plain glob — convert to anchored regex via fnmatch.translate
    return re.compile(fnmatch.translate(pattern))


def _flatten_annotation_rules(
    item: object,
) -> list[AnnotationRule]:
    """Extract AnnotationRule instances from a RuleFile list item.

    Handles both bare AnnotationRule entries and RuleGroup wrappers.
    Non-annotation scopes (search, display) are silently ignored.
    """
    if isinstance(item, AnnotationRule):
        return [item]
    if isinstance(item, RuleGroup):
        return [r for r in item.rules if isinstance(r, AnnotationRule)]
    return []


def _matches_applies_to(rule: AnnotationRule, repo_meta: dict) -> bool:  # type: ignore[type-arg]
    """Return True if the rule's applies_to passes for the given repo metadata.

    Comparisons are case-insensitive (AC-06, Contract 20 §6.3).
    A rule with applies_to=None always passes (AC-07).
    A None repo_meta field is treated as an empty string.
    """
    applies_to = rule.applies_to
    if applies_to is None:
        return True

    if applies_to.platform is not None:
        repo_val = (repo_meta.get("platform") or "").lower()
        if applies_to.platform.lower() != repo_val:
            return False

    if applies_to.primary_language is not None:
        repo_val = (repo_meta.get("primary_language") or "").lower()
        if applies_to.primary_language.lower() != repo_val:
            return False

    if applies_to.repo_type is not None:
        repo_val = (repo_meta.get("repo_type") or "").lower()
        if applies_to.repo_type.lower() != repo_val:
            return False

    return True


# ---------------------------------------------------------------------------
# RuleLoader
# ---------------------------------------------------------------------------


class RuleLoader:
    """Loads, validates, and compiles YAML rule files for SemanticInterpreter.

    Patterns are compiled ONCE (in load() or _load_tier_from_store()) and
    never recompiled during evaluation — Contract 20 §5.
    """

    def __init__(
        self,
        db: IStructuredDB,
        artifact_store: IArtifactStore,
        settings: Settings,
    ) -> None:
        """Initialise the loader with injected dependencies."""
        self._db = db
        self._artifact_store = artifact_store
        self._settings = settings
        self._base_rules: list[CompiledAnnotationRule] = []
        # Cache: (tenant_id, repo_id) → filtered + sorted compiled rules
        self._cache: dict[tuple[str, str], list[CompiledAnnotationRule]] = {}

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def load(self) -> None:
        """Scan semantic_rules_base_path, validate, and compile all base rules.

        Invalid YAML files are logged at WARN level and skipped; valid siblings
        continue to load — Contract 20 §7.1, AC-16.
        Patterns compiled here — NEVER during evaluation (Contract 20 §5).
        """
        base_path = Path(self._settings.semantic_rules_base_path)
        self._base_rules = []
        for yaml_path in sorted(base_path.glob("*.yaml")):
            try:
                raw_text = yaml_path.read_text(encoding="utf-8")
                data = yaml.safe_load(raw_text)
                rule_file = RuleFile.model_validate(data)
            except (yaml.YAMLError, ValidationError) as exc:
                logger.warning(
                    "Skipping invalid rule file %s: %s", yaml_path, exc
                )
                continue

            for item in rule_file.rules:
                for rule in _flatten_annotation_rules(item):
                    compiled = _compile_annotation_pattern(rule.match)
                    self._base_rules.append(
                        CompiledAnnotationRule(
                            rule=rule,
                            compiled_pattern=compiled,
                            tier="base",
                        )
                    )

    def get_annotation_rules(
        self,
        repo_id: str,
        tenant_id: str,
    ) -> list[CompiledAnnotationRule]:
        """Return compiled annotation rules applicable to the given repo/tenant.

        Workflow:
          1. Load tenant + repo YAML from artifact store (compile patterns).
          2. Query repositories table for applies_to pre-filter metadata.
          3. Filter rules case-insensitively by applies_to fields.
          4. Sort: repo-tier first, tenant-tier second, base-tier third;
             within same tier: descending confidence (AC-08, AC-09).
          5. Cache result by (tenant_id, repo_id) to avoid recompilation.

        Raises:
            ECLEBaseError: When the repositories query raises DBConnectionError.
        """
        cache_key = (tenant_id, repo_id)
        if cache_key in self._cache:
            return self._cache[cache_key]

        prefix = self._settings.semantic_rules_artifact_path_prefix
        tenant_rules = self._load_tier_from_store(
            f"{prefix}{tenant_id}/tenant.yaml",
            tier="tenant",
        )
        repo_rules = self._load_tier_from_store(
            f"{prefix}{tenant_id}/{repo_id}/repo.yaml",
            tier="repo",
        )

        # Query repositories table for applies_to pre-filter
        try:
            rows = self._db.execute(
                "SELECT platform, primary_language, repo_type"
                " FROM repositories"
                " WHERE repo_id = %(repo_id)s AND tenant_id = %(tenant_id)s",
                {"repo_id": repo_id, "tenant_id": tenant_id},
                tenant_id="__system__",
            )
        except DBConnectionError as exc:
            raise ECLEBaseError(
                f"DB connection failed during applies_to pre-filter for repo_id={repo_id}"
            ) from exc

        repo_meta: dict = rows[0] if rows else {}  # type: ignore[type-arg]
        all_rules = self._base_rules + tenant_rules + repo_rules

        # Apply applies_to pre-filter (case-insensitive — AC-06)
        filtered = [r for r in all_rules if _matches_applies_to(r.rule, repo_meta)]

        # Sort by tier precedence, then descending confidence within tier
        filtered.sort(key=lambda r: (_TIER_ORDER[r.tier], -r.rule.confidence))

        self._cache[cache_key] = filtered
        return filtered

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    def _load_tier_from_store(
        self,
        path: str,
        tier: Literal["tenant", "repo"],
    ) -> list[CompiledAnnotationRule]:
        """Load and compile rules from an artifact store path.

        Returns an empty list if the path does not exist or fails validation.
        Validation failures are logged at WARN level and skipped —
        Contract 20 §7.1, AC-16 / Error handling row 2.
        """
        if not self._artifact_store.exists(path):
            return []
        try:
            raw = self._artifact_store.read(path)
            data = yaml.safe_load(raw)
            rule_file = RuleFile.model_validate(data)
        except (yaml.YAMLError, ValidationError) as exc:
            logger.warning(
                "Skipping invalid rule file from artifact store %s: %s", path, exc
            )
            return []

        rules: list[CompiledAnnotationRule] = []
        for item in rule_file.rules:
            for rule in _flatten_annotation_rules(item):
                compiled = _compile_annotation_pattern(rule.match)
                rules.append(
                    CompiledAnnotationRule(
                        rule=rule,
                        compiled_pattern=compiled,
                        tier=tier,
                    )
                )
        return rules
