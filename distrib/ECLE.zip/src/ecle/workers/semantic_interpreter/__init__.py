"""
semantic_interpreter — Semantic rule engine worker package.

Implements: SPEC-0010
Reads:  YAML rule files, function_facts, file_tables, function_table_ops, repositories
Writes: semantic_annotations
"""

from __future__ import annotations
