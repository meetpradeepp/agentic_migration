"""
evaluator — Single-fact and co-occurrence annotation rule evaluation.

Implements: SPEC-0010
Reads:  function_facts, file_tables, function_table_ops (read-only, via IStructuredDB.execute)
Writes: N/A — produces AnnotationResult list; DB writes handled by SemanticInterpreter worker
"""

from __future__ import annotations

import fnmatch
import logging
import re
from dataclasses import dataclass
from typing import TYPE_CHECKING, Literal

from psycopg import sql as psql

from ecle.core.exceptions import PermanentWorkerError

if TYPE_CHECKING:
    from ecle.config import Settings
    from ecle.core.interfaces import IStructuredDB
    from ecle.workers.semantic_interpreter.rule_loader import CompiledAnnotationRule

logger = logging.getLogger(__name__)


@dataclass
class AnnotationResult:
    """Annotation produced by evaluating one rule against one fact row (AC-01..04)."""

    target_type: Literal["file_tables", "function_facts", "function_table_ops"]
    target_id: str
    rule_id: str
    rule_version: int
    platform: str | None
    domain_entity: str | None
    type: str | None
    group: str | None
    role: str | None
    confidence: float


@dataclass
class RuleEvaluator:
    """Evaluates compiled annotation rules against structured fact tables (read-only).

    NEVER writes to function_facts, file_tables, or function_table_ops — AC-21.
    Patterns must be pre-compiled by RuleLoader; no re.compile occurs here — Contract 20 §5.
    """

    db: IStructuredDB
    settings: Settings

    def evaluate_file(
        self,
        file_id: str,
        repo_id: str,
        compiled_rules: list[CompiledAnnotationRule],
    ) -> list[AnnotationResult]:
        """Evaluate single-fact annotation rules for a single file (AC-01, AC-02, AC-10).

        CoOccurrenceMatch rules are silently skipped in file mode — only SingleFactMatch
        rules are evaluated. Results deduplicated by (target_id, rule_id): the first
        match in list order wins (list is pre-sorted by tier + confidence by RuleLoader).
        Table and column names are passed via psycopg.sql.Identifier — Contract 10 A10.
        """
        from ecle.workers.semantic_interpreter.rule_schema import CoOccurrenceMatch  # noqa: PLC0415

        results: list[AnnotationResult] = []
        seen: set[tuple[str, str]] = set()  # (target_id, rule_id)

        for crule in compiled_rules:
            if isinstance(crule.rule.match, CoOccurrenceMatch):
                continue  # Co-occurrence rules are skipped in file mode (AC-12)

            field = crule.rule.match.field
            table = crule.rule.target

            # Use psycopg.sql.Identifier for table/column names — Contract 10 A10
            sql_query = psql.SQL(
                "SELECT id, {} FROM {} "
                "WHERE file_id = %(file_id)s AND repo_id = %(repo_id)s "
                "AND is_current = true"
            ).format(psql.Identifier(field), psql.Identifier(table))

            rows = self.db.execute(
                sql_query,  # type: ignore[arg-type]
                {"file_id": file_id, "repo_id": repo_id},
                tenant_id="",
            )

            for row in rows:
                value = str(row.get(field) or "")
                try:
                    m = crule.compiled_pattern.fullmatch(value)
                except re.error as exc:
                    raise PermanentWorkerError(
                        f"Pattern evaluation failed for rule '{crule.rule.rule_id}': {exc}"
                    ) from exc

                if m is None:
                    continue

                target_id = str(row["id"])
                dedup_key = (target_id, crule.rule.rule_id)
                if dedup_key in seen:
                    continue
                seen.add(dedup_key)
                results.append(self._build_annotation_result(crule, target_id, m))

        return results

    def evaluate_repo(
        self,
        repo_id: str,
        tenant_id: str,
        compiled_rules: list[CompiledAnnotationRule],
    ) -> list[AnnotationResult]:
        """Evaluate all annotation rules for a full repository (AC-03, AC-04, AC-14).

        Evaluates both SingleFactMatch rules (without file_id filter) and
        CoOccurrenceMatch rules (groups function_table_ops rows by table_name).
        Raises PermanentWorkerError if the co-occurrence row count for the repo
        exceeds settings.semantic_interpreter_max_cooccurrence_rows — AC-14.
        """
        results: list[AnnotationResult] = []
        seen: set[tuple[str, str]] = set()  # (target_id, rule_id)

        self._evaluate_single_fact_rules(
            compiled_rules, repo_id=repo_id, tenant_id=tenant_id,
            results=results, seen=seen,
        )
        self._evaluate_co_occurrence_rules(
            compiled_rules, repo_id=repo_id, tenant_id=tenant_id,
            results=results, seen=seen,
        )
        return results

    def _evaluate_single_fact_rules(
        self,
        compiled_rules: list[CompiledAnnotationRule],
        *,
        repo_id: str,
        tenant_id: str,
        results: list[AnnotationResult],
        seen: set[tuple[str, str]],
    ) -> None:
        """Append AnnotationResults for all SingleFactMatch rules scoped to a repo."""
        from ecle.workers.semantic_interpreter.rule_schema import CoOccurrenceMatch  # noqa: PLC0415

        for crule in compiled_rules:
            if isinstance(crule.rule.match, CoOccurrenceMatch):
                continue

            field = crule.rule.match.field
            table = crule.rule.target
            sql_query = psql.SQL(
                "SELECT id, {} FROM {} "
                "WHERE repo_id = %(repo_id)s AND is_current = true"
            ).format(psql.Identifier(field), psql.Identifier(table))

            rows = self.db.execute(
                sql_query,  # type: ignore[arg-type]
                {"repo_id": repo_id},
                tenant_id=tenant_id,
            )
            for row in rows:
                value = str(row.get(field) or "")
                try:
                    m = crule.compiled_pattern.fullmatch(value)
                except re.error as exc:
                    raise PermanentWorkerError(
                        f"Pattern evaluation failed for rule '{crule.rule.rule_id}': {exc}"
                    ) from exc
                if m is None:
                    continue
                target_id = str(row["id"])
                dedup_key = (target_id, crule.rule.rule_id)
                if dedup_key in seen:
                    continue
                seen.add(dedup_key)
                results.append(self._build_annotation_result(crule, target_id, m))

    def _evaluate_co_occurrence_rules(
        self,
        compiled_rules: list[CompiledAnnotationRule],
        *,
        repo_id: str,
        tenant_id: str,
        results: list[AnnotationResult],
        seen: set[tuple[str, str]],
    ) -> None:
        """Append AnnotationResults for all CoOccurrenceMatch rules scoped to a repo."""
        from ecle.workers.semantic_interpreter.rule_schema import CoOccurrenceMatch  # noqa: PLC0415

        co_rules = [
            crule for crule in compiled_rules
            if isinstance(crule.rule.match, CoOccurrenceMatch)
        ]
        if not co_rules:
            return

        max_rows = self.settings.semantic_interpreter_max_cooccurrence_rows
        co_sql = psql.SQL(
            "SELECT id, function_name, table_name FROM function_table_ops "
            "WHERE repo_id = %(repo_id)s AND is_current = true LIMIT %(limit)s"
        )
        co_rows = self.db.execute(
            co_sql,  # type: ignore[arg-type]
            {"repo_id": repo_id, "limit": max_rows + 1},
            tenant_id=tenant_id,
        )
        if len(co_rows) > max_rows:
            raise PermanentWorkerError(
                f"co-occurrence row count exceeds limit for repo_id={repo_id!r}"
            )

        # Group rows by table_name for efficient matching
        by_table: dict[str, list[dict]] = {}  # type: ignore[type-arg]
        for row in co_rows:
            tname = str(row.get("table_name") or "")
            by_table.setdefault(tname, []).append(row)

        for crule in co_rules:
            co_match = crule.rule.match  # CoOccurrenceMatch
            for table_name, table_rows in by_table.items():
                if not fnmatch.fnmatch(table_name, co_match.table_name):
                    continue
                distinct_fns = {str(r.get("function_name") or "") for r in table_rows}
                if len(distinct_fns) < co_match.min_functions:
                    continue  # AC-04: minimum distinct function threshold not met
                for row in table_rows:
                    target_id = str(row["id"])
                    dedup_key = (target_id, crule.rule.rule_id)
                    if dedup_key in seen:
                        continue
                    seen.add(dedup_key)
                    results.append(
                        self._build_co_occurrence_result(crule, target_id, table_name)
                    )

    def _apply_substitution(
        self,
        template: str,
        match: re.Match | None,  # type: ignore[type-arg]
    ) -> str | None:
        """Resolve {match.<name>} and {match[N]} substitution markers in a template.

        Returns the template unchanged when no substitution markers are present.
        Raises PermanentWorkerError if markers are present but match is None, or if
        a named group or positional group index cannot be resolved (Error handling row 4+5).
        """
        has_named = bool(re.search(r"\{match\.[A-Za-z_][A-Za-z0-9_]*\}", template))
        has_positional = bool(re.search(r"\{match\[\d+\]\}", template))

        if not has_named and not has_positional:
            return template  # No substitution markers — return as-is

        if match is None:
            raise PermanentWorkerError(
                f"Template '{template}' contains substitution markers but match is None"
            )

        result = template

        # Resolve named groups: {match.<group_name>} → match.group("<group_name>")
        for ref_name in re.findall(r"\{match\.([A-Za-z_][A-Za-z0-9_]*)\}", template):
            try:
                value = match.group(ref_name)
            except IndexError as exc:
                raise PermanentWorkerError(
                    f"Named group '{ref_name}' not found in match for template '{template}'"
                ) from exc
            result = result.replace(
                f"{{match.{ref_name}}}", value if value is not None else ""
            )

        # Resolve positional groups: {match[N]} → match.group(N)
        for ref_n_str in re.findall(r"\{match\[(\d+)\]\}", template):
            ref_n = int(ref_n_str)
            try:
                value = match.group(ref_n)
            except IndexError as exc:
                raise PermanentWorkerError(
                    f"Positional group {ref_n} out of range for template '{template}'"
                ) from exc
            result = result.replace(
                f"{{match[{ref_n_str}]}}", value if value is not None else ""
            )

        return result

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    def _build_annotation_result(
        self,
        crule: CompiledAnnotationRule,
        target_id: str,
        match: re.Match,  # type: ignore[type-arg]
    ) -> AnnotationResult:
        """Build an AnnotationResult by substituting annotate values via regex match."""
        annotate = crule.rule.annotate

        def _resolve(key: str) -> str | None:
            raw = annotate.get(key)
            if raw is None:
                return None
            return self._apply_substitution(raw, match)

        return AnnotationResult(
            target_type=crule.rule.target,
            target_id=target_id,
            rule_id=crule.rule.rule_id,
            rule_version=crule.rule.version,
            platform=_resolve("platform"),
            domain_entity=_resolve("domain_entity"),
            type=_resolve("type"),
            group=_resolve("group"),
            role=_resolve("role"),
            confidence=crule.rule.confidence,
        )

    def _build_co_occurrence_result(
        self,
        crule: CompiledAnnotationRule,
        target_id: str,
        table_name: str,
    ) -> AnnotationResult:
        """Build an AnnotationResult for a co-occurrence match, substituting {table_name}."""
        annotate = crule.rule.annotate

        def _resolve(key: str) -> str | None:
            raw = annotate.get(key)
            if raw is None:
                return None
            return raw.replace("{table_name}", table_name)

        return AnnotationResult(
            target_type=crule.rule.target,
            target_id=target_id,
            rule_id=crule.rule.rule_id,
            rule_version=crule.rule.version,
            platform=_resolve("platform"),
            domain_entity=_resolve("domain_entity"),
            type=_resolve("type"),
            group=_resolve("group"),
            role=_resolve("role"),
            confidence=crule.rule.confidence,
        )
