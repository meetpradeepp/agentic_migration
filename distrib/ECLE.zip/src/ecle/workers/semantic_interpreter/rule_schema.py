"""
rule_schema — Pydantic v2 models for semantic interpreter YAML rule files.

Implements: SPEC-0010
Reads:  YAML rule files validated against these models (via RuleLoader and Admin API)
Writes: N/A — pure schema definitions
"""

from __future__ import annotations

import re
from typing import Literal

from pydantic import BaseModel, model_validator


class AppliesTo(BaseModel):
    """Optional repository pre-filter applied to any rule scope."""

    platform: str | None = None
    primary_language: str | None = None
    repo_type: str | None = None


class SingleFactMatch(BaseModel):
    """Single-fact pattern match on a column in the target table."""

    field: Literal["function_name", "table_name", "query_token"]
    pattern: str  # plain glob (fnmatch) or "re:<regex>" prefix — Contract 20 §6.3


class CoOccurrenceMatch(BaseModel):
    """Co-occurrence match on function_table_ops; valid only with target=function_table_ops."""

    table_name: str  # glob match on table_name column
    min_functions: int  # minimum distinct functions touching the table


class QueryTokenMatch(BaseModel):
    """Match on an individual user query token; used by SearchRule sub-form A."""

    query_token: str  # exact or glob match on individual query tokens


class RewriteAction(BaseModel):
    """Query rewrite action applied at query time; used by SearchRule sub-form A."""

    filter: dict[str, str | None] | None = None
    expand_tokens: list[str] | None = None


class AnnotationRule(BaseModel):
    """Annotation rule evaluated at ingest time; result persisted to semantic_annotations."""

    rule_id: str
    version: int  # >= 1 monotonic — Contract 20 §5
    scope: Literal["annotation"]
    applies_to: AppliesTo | None = None
    target: Literal["file_tables", "function_facts", "function_table_ops"]
    match: SingleFactMatch | CoOccurrenceMatch
    annotate: dict[str, str | None]
    confidence: float  # 0.0-1.0 inclusive -- Contract 20 SS6.10

    @model_validator(mode="after")
    def _validate_co_occurrence_target(self) -> AnnotationRule:
        """[V1] CoOccurrenceMatch requires target='function_table_ops' — Contract 20 §5, AC-18."""
        if (
            isinstance(self.match, CoOccurrenceMatch)
            and self.target != "function_table_ops"
        ):
            raise ValueError(
                f"co_touch match requires target='function_table_ops', "
                f"got target='{self.target}'"
            )
        return self

    @model_validator(mode="after")
    def _validate_capture_group_references(self) -> AnnotationRule:
        """[V2] Validate {match.<name>} and {match[N]} references against compiled regex — AC-15."""
        if not isinstance(self.match, SingleFactMatch):
            return self
        pattern = self.match.pattern
        if not pattern.startswith("re:"):
            return self

        regex_str = pattern[3:]
        try:
            compiled = re.compile(regex_str)
        except re.error as exc:
            raise ValueError(
                f"Invalid regex pattern '{regex_str}': {exc}"
            ) from exc

        for key, value in self.annotate.items():
            if value is None:
                continue

            # [V2a] Verify {match.<name>} named-group references
            for ref_name in re.findall(
                r"\{match\.([A-Za-z_][A-Za-z0-9_]*)\}", value
            ):
                if ref_name not in compiled.groupindex:
                    raise ValueError(
                        f"annotate['{key}'] references named group '{ref_name}' "
                        f"which is absent from pattern '{regex_str}'. "
                        f"Available named groups: {list(compiled.groupindex.keys())}"
                    )

            # [V2b] Verify {match[N]} positional-group references
            for ref_n_str in re.findall(r"\{match\[(\d+)\]\}", value):
                ref_n = int(ref_n_str)
                if ref_n > compiled.groups:
                    raise ValueError(
                        f"annotate['{key}'] references positional group {ref_n} "
                        f"but pattern '{regex_str}' only has {compiled.groups} "
                        f"capture group(s)"
                    )

        return self


class SearchRule(BaseModel):
    """Search rule evaluated at query time; ephemeral per-query rewrite — not persisted."""

    rule_id: str
    version: int  # >= 1 monotonic — Contract 20 §5
    scope: Literal["search"]
    applies_to: AppliesTo | None = None
    # Sub-form A (rewrite) — mutually exclusive with sub-form B
    match: QueryTokenMatch | None = None
    rewrite: RewriteAction | None = None
    # Sub-form B (keyword group) — mutually exclusive with sub-form A
    keyword_group: str | None = None
    members: list[str] | None = None
    description: str | None = None

    @model_validator(mode="after")
    def _validate_subform_exclusive(self) -> SearchRule:
        """Enforce mutually exclusive sub-forms A and B — Contract 20 §2.2, AC-17."""
        has_match = self.match is not None
        has_keyword_group = self.keyword_group is not None
        if has_match and has_keyword_group:
            raise ValueError(
                "SearchRule cannot have both 'match' and 'keyword_group' — "
                "sub-forms A and B are mutually exclusive (Contract 20 §2.2)"
            )
        if not has_match and not has_keyword_group:
            raise ValueError(
                "SearchRule must specify either 'match' (sub-form A) or "
                "'keyword_group' (sub-form B) — Contract 20 §2.2"
            )
        return self


class DisplayRule(BaseModel):
    """Display rule evaluated by MCP result formatter; cosmetic substitution only."""

    rule_id: str
    version: int  # >= 1 monotonic — Contract 20 §5
    scope: Literal["display"]
    applies_to: AppliesTo | None = None
    match: SingleFactMatch
    label: str
    description: str | None = None


class RuleGroup(BaseModel):
    """Optional wrapper grouping related rules under a shared applies_to context."""

    rule_group: str  # unique per rule file -- Contract 20 S3
    version: int
    applies_to: AppliesTo | None = None
    description: str
    rules: list[AnnotationRule | SearchRule | DisplayRule]


class RuleFile(BaseModel):
    """Top-level container for a YAML rule file; validated before loading."""

    rules: list[AnnotationRule | SearchRule | DisplayRule | RuleGroup]
