# Workers module — Kafka consumer workers (one file per worker).
