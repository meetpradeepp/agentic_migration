"""
config — ECLE 2.0 application settings via Pydantic BaseSettings.

Implements: SPEC-0001, Contract 01 §6, Contract 14, ADR-0028
Reads:  .env, environment variables
Writes: Nothing — read-only settings object

All tunable values come from here. No magic numbers in code (Contract 01 §6).
No hardcoded paths (Contract 14). Environment variables override file config.
18 canonical fields per SPEC-0001 Interface contract table; additional fields
for SPEC-0008 worker tuning and SPEC-0010 semantic interpreter.
"""

from __future__ import annotations

from pathlib import Path
from typing import Final

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict

# Project root — resolved once, used everywhere.
PROJECT_ROOT: Final[Path] = Path(__file__).resolve().parent.parent.parent


class Settings(BaseSettings):
    """ECLE application settings.

    Load order: .env file → environment variables → defaults.
    Environment variables use ECLE_ prefix (e.g. ECLE_TIER=compose).
    18 canonical fields per SPEC-0001 Interface contract table.
    """

    model_config = SettingsConfigDict(
        env_prefix="ECLE_",
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )

    # --- Tier (ADR-0010, Contract 14) ---
    tier: str = Field(default="dev", description="Deployment tier: dev | compose | enterprise")

    # --- Data paths (ADR-0028) ---
    data_root: Path = Field(default=PROJECT_ROOT / "ecle-data", description="Runtime data root")
    log_dir: Path = Field(default=PROJECT_ROOT / "ecle-logs", description="Log output directory")
    config_path: Path = Field(
        default=PROJECT_ROOT / "ecle-data" / "config" / "ecle.yaml",
        description="Path to runtime YAML config file",
    )
    log_config_path: Path = Field(
        default=PROJECT_ROOT / "ecle-data" / "config" / "logging.yaml",
        description="Path to logging configuration YAML",
    )

    # --- Structured DB (Contract 15) ---
    structured_backend: str = Field(
        default="postgresql",
        description="Structured DB backend: postgresql",
    )
    structured_backend_url: str = Field(
        default="",
        description="Structured DB URL (set via env var — Contract 01 §9)",
    )
    database_url: str = Field(
        default="",
        description="PostgreSQL connection string (set via env var — Contract 01 §9)",
    )

    # --- Vector store (Contract 12) ---
    vector_backend: str = Field(default="qdrant", description="Vector backend: chromadb | qdrant")
    vector_backend_url: str = Field(
        default="http://localhost:6333",
        description="Vector store URL",
    )

    # --- Topology graph ---
    topology_backend: str = Field(default="neo4j", description="Graph backend: sqlite | neo4j")
    topology_backend_url: str = Field(
        default="bolt://localhost:7687",
        description="Graph DB URL",
    )

    # --- Artifact store (ADR-0007, Contract 14) ---
    artifact_backend: str = Field(default="local", description="Artifact backend: local | s3 | azure | nfs")
    artifact_store_path: Path = Field(
        default=PROJECT_ROOT / "ecle-data" / "repos",
        description="Local artifact store path",
    )

    # --- Language packs (Contract 08) ---
    language_packs_path: Path = Field(
        default=PROJECT_ROOT / "ecle-data" / "language_packs",
        description="Language pack directory",
    )

    # --- Models (ADR-0008) ---
    models_path: Path = Field(
        default=PROJECT_ROOT / "ecle-data" / "models",
        description="Local ONNX model directory",
    )

    # --- Kafka (ADR-0013, Contract 09) ---
    kafka_bootstrap_servers: str = Field(
        default="localhost:9092",
        description="Kafka bootstrap servers",
    )

    # --- Observability (Contract 16) ---
    log_level: str = Field(default="INFO", description="Root log level (Contract 16)")
    otel_sdk_disabled: bool = Field(
        default=True,
        description="Disable OpenTelemetry in dev (Contract 16)",
    )

    # ---- Kafka worker tuning (SPEC-0008) ---
    kafka_poll_timeout_s: float = Field(
        default=1.0,
        description="Kafka consumer poll timeout in seconds",
    )
    kafka_poll_timeout_ms: int = Field(
        default=1000,
        description="Kafka consumer poll timeout in milliseconds",
    )
    kafka_max_poll_records: int = Field(
        default=500,
        description="Max records per poll",
    )
    kafka_dlq_max_retries: int = Field(
        default=3,
        description="Max DLQ retry attempts before permanent failure",
    )
    kafka_producer_linger_ms: int = Field(
        default=5,
        description="Producer linger time in milliseconds",
    )

    # --- Embedding (Contract 12) ---
    embedding_backend: str = Field(
        default="onnx",
        description="Embedding backend: onnx | openai (Contract 12)",
    )
    embed_batch_size: int = Field(default=128, description="Max items per embedding batch")
    embed_max_tokens: int = Field(default=32768, description="Max tokens per embedding batch")
    embed_max_wait_ms: int = Field(default=100, description="Max wait before batch flush (ms)")

    # --- MCP (Contract 11) ---
    mcp_max_results: int = Field(default=100, description="Max results per MCP tool call")

    # --- Semantic Interpreter (SPEC-0010, ADR-0034) ---
    semantic_rules_base_path: Path = Field(
        default=PROJECT_ROOT / "src" / "ecle" / "workers" / "semantic_interpreter" / "base_rules",
        description="Base YAML rules directory for semantic_interpreter (SPEC-0010)",
    )
    semantic_rules_artifact_path_prefix: str = Field(
        default="semantic_rules/",
        description="Artifact store path prefix for tenant/repo YAML rule files (SPEC-0010)",
    )
    semantic_interpreter_max_cooccurrence_rows: int = Field(
        default=50_000,
        description="Max function_table_ops rows for co-occurrence evaluation (SPEC-0010)",
    )
    semantic_interpreter_mode: str = Field(
        default="file",
        description="SemanticInterpreter mode: 'file' or 'repo' (SPEC-0010)",
    )


# Module-level singleton — import as `from ecle.config import settings`
settings = Settings()
