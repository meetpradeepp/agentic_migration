"""
constants — Immutable constants shared across ECLE modules.

Implements: SPEC-0001, Contract 01 §6
Reads:  Nothing
Writes: Nothing

These are truly fixed values — not configurable, not environment-dependent.
Configurable values go in ecle.config.Settings instead.
"""

from __future__ import annotations

from typing import Final

# Artifact path template (ADR-0007 §2)
ARTIFACT_PATH_TEMPLATE: Final[str] = "{tenant_id}/{repo_id}/{file_rel_path}.facts.json"

# Schema version for facts.json artifacts (Contract 15, facts-base-schema.json)
SCHEMA_VERSION: Final[str] = "2.1"

# Fidelity levels (Contract 05) — used for extraction_fidelity column
FIDELITY_FULL: Final[str] = "FULL"
FIDELITY_PARTIAL: Final[str] = "PARTIAL"
FIDELITY_HEURISTIC: Final[str] = "HEURISTIC"

# Fidelity ceiling values (Contract 05)
FIDELITY_CEILING: Final[dict[str, float]] = {
    "FULL": 1.0,
    "PARTIAL": 0.8,
    "HEURISTIC": 0.6,
}

# Fallback ceiling when DefaultPack + used_fallback=True (Contract 05 §2)
FIDELITY_FALLBACK_CEILING: Final[float] = 0.5

# Kafka / worker prefixes (Contract 09, ADR-0027)
CONSUMER_GROUP_PREFIX: Final[str] = "ecle."
DLQ_TOPIC_PREFIX: Final[str] = "ecle.dlq."

# Worker lifecycle TTL — seconds between DB polls (ADR-0027, Contract 09)
WORKER_LIFECYCLE_TTL_SECONDS: Final[int] = 30

# Louvain community detection minimum cluster size (ADR-0011)
LOUVAIN_MIN_CLUSTER_SIZE: Final[int] = 2

# Confidence dimensions (Contract 05) — the 6-dimensional profile
CONFIDENCE_DIMENSIONS: Final[tuple[str, ...]] = (
    "syntactic_freshness",
    "behavioral_accuracy",
    "contextual_accuracy",
    "edge_coherence",
    "cluster_alignment",
    "semantic_accuracy",
)

# Staleness score thresholds (Contract 07)
STALENESS_CLEAN: Final[float] = 0.1
STALENESS_CAVEAT: Final[float] = 0.3
# Above 0.3 → WARNING + re-index event

# Kafka topic prefix (Contract 09) — used by topic_registry
KAFKA_TOPIC_PREFIX: Final[str] = "ecle"

# DLQ topic prefix (Contract 09)
KAFKA_DLQ_PREFIX: Final[str] = "ecle.dlq"

# Worker lifecycle poll interval in seconds (Contract 09, ADR-0027)
WORKER_LIFECYCLE_POLL_S: Final[int] = 30

# Query timeout (Contract 04)
QUERY_TIMEOUT_S: Final[float] = 2.0

# Behavioral fingerprint hash algorithm (Contract 13)
FINGERPRINT_ALGORITHM: Final[str] = "sha256"
