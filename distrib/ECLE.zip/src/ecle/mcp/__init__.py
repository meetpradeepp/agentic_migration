# MCP module — Model Context Protocol server and tools.
