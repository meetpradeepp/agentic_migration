# Events module — Kafka topic registry, event payloads, producer/consumer utilities.
