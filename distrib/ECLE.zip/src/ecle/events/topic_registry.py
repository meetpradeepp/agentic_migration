"""
Phase 1 Kafka topic constants and registry utilities.

Implements: SPEC-0008
Reads:  N/A — constant definitions only
Writes: N/A
"""

from __future__ import annotations

from confluent_kafka.admin import AdminClient, NewTopic  # type: ignore[import]
from confluent_kafka import KafkaException  # type: ignore[import]

from ecle.constants import KAFKA_DLQ_PREFIX, KAFKA_TOPIC_PREFIX

# ---------------------------------------------------------------------------
# Phase 1 topic constants (ADR-0013 naming: ecle.{event_type})
# ---------------------------------------------------------------------------

TOPIC_SOURCE_RECEIVED: str = "ecle.source.received"
TOPIC_REPO_DETECTED: str = "ecle.repo.detected"
TOPIC_REPO_STRUCTURAL_COMPLETE: str = "ecle.repo.structural_complete"
TOPIC_FILE_IR_PRODUCED: str = "ecle.file.ir_produced"
TOPIC_REPO_IR_PRODUCED: str = "ecle.repo.ir_produced"
TOPIC_SOURCE_SCANNED: str = "ecle.source.scanned"
TOPIC_FILE_STORED: str = "ecle.file.stored"
TOPIC_REPO_INDEXED: str = "ecle.repo.indexed"
TOPIC_DOCUMENT_STORED: str = "ecle.document.stored"
TOPIC_FACTS_ANNOTATED: str = "ecle.facts.annotated"

PHASE_1_TOPICS: list[str] = [
    TOPIC_SOURCE_RECEIVED,
    TOPIC_REPO_DETECTED,
    TOPIC_REPO_STRUCTURAL_COMPLETE,
    TOPIC_FILE_IR_PRODUCED,
    TOPIC_REPO_IR_PRODUCED,
    TOPIC_SOURCE_SCANNED,
    TOPIC_FILE_STORED,
    TOPIC_REPO_INDEXED,
    TOPIC_DOCUMENT_STORED,
]


# ---------------------------------------------------------------------------
# Pure helper functions
# ---------------------------------------------------------------------------


def dlq_topic(event_topic: str) -> str:
    """Return the DLQ topic name for *event_topic*.

    Example: ``'ecle.file.ir_produced'`` → ``'ecle.dlq.file.ir_produced'``
    """
    prefix = KAFKA_TOPIC_PREFIX + "."
    suffix = event_topic[len(prefix):] if event_topic.startswith(prefix) else event_topic
    return KAFKA_DLQ_PREFIX + "." + suffix


def consumer_group(worker_name: str) -> str:
    """Return the consumer-group name for *worker_name*.

    Example: ``'parse_repo'`` → ``'ecle.parse_repo'``
    """
    return KAFKA_TOPIC_PREFIX + "." + worker_name


# ---------------------------------------------------------------------------
# Topic provisioning
# ---------------------------------------------------------------------------


def ensure_topics(
    admin: AdminClient,
    topics: list[str],
    *,
    num_partitions: int = 1,
    replication_factor: int = 1,
) -> None:
    """Idempotently create *topics* via *admin*.

    Ignores ``TopicAlreadyExistsException``; re-raises any other
    ``KafkaException``.
    """
    from confluent_kafka import KafkaError  # type: ignore[import]

    new_topics = [
        NewTopic(t, num_partitions=num_partitions, replication_factor=replication_factor)
        for t in topics
    ]
    futures = admin.create_topics(new_topics)
    for _topic, future in futures.items():
        try:
            future.result()
        except KafkaException as exc:
            if exc.args[0].code() == KafkaError.TOPIC_ALREADY_EXISTS:
                pass
            else:
                raise
