"""ecle.linting.naming_checker — Deterministic AST-based ECLE001 naming gate.

Implements: SPEC-0011
Reads:  Python source files (UTF-8)
Writes: Nothing (caller serialises findings)

Determinism contract (ADR-0037):
  - AST-only evaluation; no network, no model, no filesystem side-effects
  - Fixed token lists and thresholds
  - Stable sort order: (path, line, column, symbol)
  - Same revision + same config → byte-identical JSON when serialised by caller
"""

from __future__ import annotations

import ast
import io
import tokenize
from dataclasses import dataclass
from pathlib import Path


# ---------------------------------------------------------------------------
# Constants  (ADR-0037 Decision section)
# ---------------------------------------------------------------------------

RULE_ID_ECLE001 = "ECLE001"
RULE_ID_ECLE001_PARSE = "ECLE001-PARSE"
RULE_ID_ECLE001_ERROR = "ECLE001-ERROR"

_CONTROL_FLOW_NODE_TYPES: frozenset[type[ast.stmt]] = frozenset(
    {ast.If, ast.For, ast.While, ast.With, ast.Try, ast.Match}  # type: ignore[attr-defined]
    if hasattr(ast, "Match")
    else {ast.If, ast.For, ast.While, ast.With, ast.Try},
)

_DB_CALL_TOKENS: frozenset[str] = frozenset(
    {"execute", "executemany", "upsert", "fetchone", "fetchall"}
)
_IO_CALL_TOKENS: frozenset[str] = frozenset(
    {"open", "read_text", "read_bytes", "write_text", "write_bytes", "write_json", "read_json"}
)
_NETWORK_CALL_TOKENS: frozenset[str] = frozenset(
    {"produce", "poll", "flush", "send", "post", "get", "put", "delete", "request"}
)
_BOUNDARY_CALL_TOKENS: frozenset[str] = (
    _DB_CALL_TOKENS | _IO_CALL_TOKENS | _NETWORK_CALL_TOKENS
)

_MATH_OPERATOR_TYPES: tuple[type, ...] = (
    ast.Add, ast.Sub, ast.Mult, ast.Div, ast.FloorDiv, ast.Mod,
    ast.Pow, ast.BitAnd, ast.BitOr, ast.BitXor, ast.LShift, ast.RShift,
    ast.USub, ast.UAdd,
)


# ---------------------------------------------------------------------------
# Public dataclasses
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class ScopeMetrics:
    """Computed metrics for a single function/method scope."""

    logical_lines: int
    local_variable_count: int
    has_control_flow: bool
    has_boundary_call: bool


@dataclass(frozen=True)
class NamingFinding:
    """One ECLE001 (or ECLE001-PARSE / ECLE001-ERROR) violation record."""

    path: str
    line: int
    column: int
    symbol: str
    reason: str
    rule_id: str
    scope_kind: str
    scope_metrics: ScopeMetrics


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _count_logical_lines(source_text: str, func_node: ast.FunctionDef | ast.AsyncFunctionDef) -> int:  # noqa: E501
    """Count non-blank, non-comment logical lines inside a function/method body."""
    try:
        tokens = list(
            tokenize.generate_tokens(io.StringIO(source_text).readline)
        )
    except tokenize.TokenError:
        return 0

    func_start = func_node.body[0].lineno if func_node.body else func_node.lineno
    func_end = func_node.end_lineno or func_node.lineno  # type: ignore[attr-defined]

    logical_line_numbers: set[int] = set()
    for tok_type, _tok_string, tok_start, _tok_end, _tok_line in tokens:
        tok_line_no = tok_start[0]
        if func_start <= tok_line_no <= func_end:
            if tok_type not in (
                tokenize.COMMENT,
                tokenize.NL,
                tokenize.NEWLINE,
                tokenize.INDENT,
                tokenize.DEDENT,
                tokenize.ENCODING,
            ):
                logical_line_numbers.add(tok_line_no)
    return len(logical_line_numbers)


def _collect_local_variable_names(func_node: ast.FunctionDef | ast.AsyncFunctionDef) -> set[str]:
    """Collect names assigned as local variables (excludes function parameters)."""
    param_names: set[str] = {
        arg.arg for arg in func_node.args.args
        + func_node.args.posonlyargs
        + func_node.args.kwonlyargs
    }
    if func_node.args.vararg:
        param_names.add(func_node.args.vararg.arg)
    if func_node.args.kwarg:
        param_names.add(func_node.args.kwarg.arg)

    local_names: set[str] = set()
    for node in ast.walk(func_node):
        if isinstance(node, (ast.Assign, ast.AugAssign, ast.AnnAssign)):
            targets = node.targets if isinstance(node, ast.Assign) else [node.target]  # type: ignore[attr-defined]
            for target in targets:
                if isinstance(target, ast.Name) and target.id not in param_names:
                    local_names.add(target.id)
        elif isinstance(node, (ast.For, ast.comprehension)):
            loop_target = node.target
            for name_node in ast.walk(loop_target):
                if isinstance(name_node, ast.Name) and name_node.id not in param_names:
                    local_names.add(name_node.id)
        elif isinstance(node, ast.NamedExpr):
            if isinstance(node.target, ast.Name) and node.target.id not in param_names:
                local_names.add(node.target.id)

    return local_names


def _has_control_flow(func_node: ast.FunctionDef | ast.AsyncFunctionDef) -> bool:
    """Return True if the function body contains any control-flow statement."""
    for node in ast.walk(func_node):
        if node is func_node:
            continue
        if type(node) in _CONTROL_FLOW_NODE_TYPES:
            return True
    return False


def _has_boundary_call(func_node: ast.FunctionDef | ast.AsyncFunctionDef) -> bool:
    """Return True if the function body contains a known boundary call token."""
    for node in ast.walk(func_node):
        if isinstance(node, ast.Call):
            func_expr = node.func
            call_name: str | None = None
            if isinstance(func_expr, ast.Name):
                call_name = func_expr.id
            elif isinstance(func_expr, ast.Attribute):
                call_name = func_expr.attr
            if call_name and call_name in _BOUNDARY_CALL_TOKENS:
                return True
    return False


def _compute_scope_metrics(
    func_node: ast.FunctionDef | ast.AsyncFunctionDef,
    source_text: str,
    non_trivial_logical_lines: int,
    non_trivial_local_variables: int,
) -> ScopeMetrics:
    """Compute ScopeMetrics for a single function/method scope."""
    logical_lines = _count_logical_lines(source_text, func_node)
    local_vars = _collect_local_variable_names(func_node)
    has_cf = _has_control_flow(func_node)
    has_bc = _has_boundary_call(func_node)
    return ScopeMetrics(
        logical_lines=logical_lines,
        local_variable_count=len(local_vars),
        has_control_flow=has_cf,
        has_boundary_call=has_bc,
    )


def _is_non_trivial_scope(
    metrics: ScopeMetrics,
    non_trivial_logical_lines: int,
    non_trivial_local_variables: int,
) -> bool:
    return (
        metrics.logical_lines >= non_trivial_logical_lines
        or metrics.local_variable_count >= non_trivial_local_variables
        or metrics.has_control_flow
        or metrics.has_boundary_call
    )


def _collect_loop_targets_with_ranges(
    func_node: ast.FunctionDef | ast.AsyncFunctionDef,
) -> list[tuple[str, int, int]]:
    """Return list of (symbol, loop_start_line, loop_end_line) for loop-iteration variables."""
    loop_entries: list[tuple[str, int, int]] = []
    for node in ast.walk(func_node):
        if isinstance(node, ast.For):
            loop_end = getattr(node, "end_lineno", node.lineno)
            for name_node in ast.walk(node.target):
                if isinstance(name_node, ast.Name):
                    loop_entries.append((name_node.id, node.lineno, loop_end))
    return loop_entries


def _collect_all_name_uses(
    func_node: ast.FunctionDef | ast.AsyncFunctionDef,
    symbol: str,
) -> list[int]:
    """Return all line numbers where *symbol* is used as an ast.Name (load or store)."""
    use_lines: list[int] = []
    for node in ast.walk(func_node):
        if isinstance(node, ast.Name) and node.id == symbol:
            use_lines.append(node.lineno)
    return use_lines


def _count_body_logical_lines(loop_node: ast.For, source_text: str) -> int:
    """Count logical body lines of a for-loop (excluding the 'for' header line)."""
    if not loop_node.body:
        return 0
    try:
        tokens = list(
            tokenize.generate_tokens(io.StringIO(source_text).readline)
        )
    except tokenize.TokenError:
        return 0
    body_start = loop_node.body[0].lineno
    body_end = getattr(loop_node, "end_lineno", loop_node.lineno)
    logical_line_numbers: set[int] = set()
    for tok_type, _tok_string, tok_start, _tok_end, _tok_line in tokens:
        tok_line_no = tok_start[0]
        if body_start <= tok_line_no <= body_end:
            if tok_type not in (
                tokenize.COMMENT,
                tokenize.NL,
                tokenize.NEWLINE,
                tokenize.INDENT,
                tokenize.DEDENT,
                tokenize.ENCODING,
            ):
                logical_line_numbers.add(tok_line_no)
    return len(logical_line_numbers)


def _is_tiny_loop_index_guard(
    symbol: str,
    func_node: ast.FunctionDef | ast.AsyncFunctionDef,
    source_text: str,
) -> bool:
    """Return True if *symbol* qualifies for the tiny-loop-index allow-list exception.

    Guards (all must hold):
    - symbol is a loop-iteration variable in at least one for-loop
    - every for-loop that declares symbol has a body with <= 3 logical lines
    - symbol is not referenced outside any of its enclosing loop bodies
    """
    loop_entries = _collect_loop_targets_with_ranges(func_node, )
    relevant_loops: list[tuple[str, int, int]] = [
        entry for entry in loop_entries if entry[0] == symbol
    ]
    if not relevant_loops:
        return False

    all_use_lines = set(_collect_all_name_uses(func_node, symbol))

    for _sym, loop_start, loop_end in relevant_loops:
        # Check body line count for this loop
        matching_for_nodes = [
            node for node in ast.walk(func_node)
            if isinstance(node, ast.For) and node.lineno == loop_start
        ]
        for loop_node in matching_for_nodes:
            body_lines = _count_body_logical_lines(loop_node, source_text)
            if body_lines > 3:
                return False

        # Check that all uses of symbol fall within this loop's range
        for use_line in all_use_lines:
            if not (loop_start <= use_line <= loop_end):
                return False

    return True


def _is_math_only_guard(
    symbol: str,
    func_node: ast.FunctionDef | ast.AsyncFunctionDef,
) -> bool:
    """Return True if every use of *symbol* is exclusively in a numeric/math expression.

    Strategy: walk all Name nodes for symbol; for each, check that the nearest
    containing expression only involves numeric operators or constants.
    A use in a subscript, call arg, comparison, or attribute access disqualifies.
    """
    for node in ast.walk(func_node):
        if not isinstance(node, ast.Name) or node.id != symbol:
            continue
        # Check context — if Load context, inspect parent expression type
        if isinstance(node.ctx, ast.Load):
            # We rely on the parent-finding pattern via visitor
            pass  # Handled below via _SymbolUseVisitor

    visitor = _SymbolUseContextVisitor(symbol)
    visitor.visit(func_node)
    return visitor.all_math_only


class _SymbolUseContextVisitor(ast.NodeVisitor):
    """Collect all expression contexts where *symbol* appears and classify them."""

    def __init__(self, symbol: str) -> None:
        self._symbol = symbol
        self.all_math_only = True
        self._in_math_expr = False

    def visit_BinOp(self, node: ast.BinOp) -> None:  # noqa: N802
        if type(node.op) in _MATH_OPERATOR_TYPES:
            old = self._in_math_expr
            self._in_math_expr = True
            self.generic_visit(node)
            self._in_math_expr = old
        else:
            old = self._in_math_expr
            self._in_math_expr = False
            self.generic_visit(node)
            self._in_math_expr = old

    def visit_UnaryOp(self, node: ast.UnaryOp) -> None:  # noqa: N802
        if type(node.op) in _MATH_OPERATOR_TYPES:
            old = self._in_math_expr
            self._in_math_expr = True
            self.generic_visit(node)
            self._in_math_expr = old
        else:
            old = self._in_math_expr
            self._in_math_expr = False
            self.generic_visit(node)
            self._in_math_expr = old

    def visit_Name(self, node: ast.Name) -> None:  # noqa: N802
        if node.id == self._symbol and isinstance(node.ctx, ast.Load):
            if not self._in_math_expr:
                self.all_math_only = False

    def visit_Assign(self, node: ast.Assign) -> None:  # noqa: N802
        # RHS is the value being assigned — enter math context for the value
        old = self._in_math_expr
        self._in_math_expr = True
        self.visit(node.value)
        self._in_math_expr = old
        # LHS targets: Name node as Store context is not a "use"
        for target in node.targets:
            self.visit(target)

    def visit_Call(self, node: ast.Call) -> None:  # noqa: N802
        # symbol used as a call argument = not math-only
        old = self._in_math_expr
        self._in_math_expr = False
        self.generic_visit(node)
        self._in_math_expr = old

    def visit_Subscript(self, node: ast.Subscript) -> None:  # noqa: N802
        old = self._in_math_expr
        self._in_math_expr = False
        self.generic_visit(node)
        self._in_math_expr = old

    def visit_AugAssign(self, node: ast.AugAssign) -> None:  # noqa: N802
        # AugAssign value: inherit math context from BinOp visitor, not forced here
        self.generic_visit(node)

    def visit_Expr(self, node: ast.Expr) -> None:  # noqa: N802
        old = self._in_math_expr
        self._in_math_expr = False
        self.generic_visit(node)
        self._in_math_expr = old

    def visit_Compare(self, node: ast.Compare) -> None:  # noqa: N802
        old = self._in_math_expr
        self._in_math_expr = False
        self.generic_visit(node)
        self._in_math_expr = old


def _should_skip_by_allowlist(
    symbol: str,
    func_node: ast.FunctionDef | ast.AsyncFunctionDef,
    source_text: str,
    allowlist: frozenset[str],
) -> bool:
    """Return True if *symbol* passes any allow-list exception guard.

    Guards evaluated in order:
    1. Throwaway underscore: `_` always passes
    2. Tiny loop index: `i`, `j`, `k` (subset of allowlist) when guard holds
    3. Math-only notation: `x`, `y`, `z`, `n`, `m` (subset) when guard holds
    """
    if symbol == "_":
        return True

    if symbol not in allowlist:
        return False  # Not in allowlist at all — denylist handling done by caller

    _LOOP_INDEX_SYMBOLS = frozenset({"i", "j", "k"})
    _MATH_SYMBOLS = frozenset({"x", "y", "z", "n", "m"})

    if symbol in _LOOP_INDEX_SYMBOLS:
        return _is_tiny_loop_index_guard(symbol, func_node, source_text)

    if symbol in _MATH_SYMBOLS:
        return _is_math_only_guard(symbol, func_node)

    # Other allowlist symbols (future-proofing): skip unconditionally
    return True


def _collect_local_assignment_nodes(
    func_node: ast.FunctionDef | ast.AsyncFunctionDef,
) -> list[tuple[str, int, int]]:
    """Return (symbol, line, column) for every local variable assignment target."""
    param_names: set[str] = {
        arg.arg for arg in func_node.args.args
        + func_node.args.posonlyargs
        + func_node.args.kwonlyargs
    }
    if func_node.args.vararg:
        param_names.add(func_node.args.vararg.arg)
    if func_node.args.kwarg:
        param_names.add(func_node.args.kwarg.arg)

    results: list[tuple[str, int, int]] = []

    for node in ast.walk(func_node):
        if isinstance(node, (ast.Assign, ast.AugAssign, ast.AnnAssign)):
            targets = node.targets if isinstance(node, ast.Assign) else [node.target]  # type: ignore[attr-defined]
            for target in targets:
                if isinstance(target, ast.Name) and target.id not in param_names:
                    results.append((target.id, target.lineno, target.col_offset))
        elif isinstance(node, ast.For):
            for name_node in ast.walk(node.target):
                if isinstance(name_node, ast.Name) and name_node.id not in param_names:
                    results.append((name_node.id, name_node.lineno, name_node.col_offset))
        elif isinstance(node, ast.NamedExpr):
            if isinstance(node.target, ast.Name) and node.target.id not in param_names:
                results.append((node.target.id, node.target.lineno, node.target.col_offset))

    return results


# ---------------------------------------------------------------------------
# Public checker class
# ---------------------------------------------------------------------------

class NamingChecker:
    """Deterministic AST-based naming gate implementing rule ECLE001.

    Implements: SPEC-0011
    """

    def __init__(
        self,
        *,
        non_trivial_logical_lines: int,
        non_trivial_local_variables: int,
        ambiguous_denylist: tuple[str, ...],
        allowlist: tuple[str, ...],
    ) -> None:
        self._non_trivial_logical_lines = non_trivial_logical_lines
        self._non_trivial_local_variables = non_trivial_local_variables
        self._ambiguous_denylist: frozenset[str] = frozenset(ambiguous_denylist)
        self._allowlist: frozenset[str] = frozenset(allowlist)

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def check_paths(self, paths: list[str]) -> list[NamingFinding]:
        """Run ECLE001 on every file in *paths* and return sorted findings."""
        all_findings: list[NamingFinding] = []
        for file_path in paths:
            try:
                source_text = Path(file_path).read_text(encoding="utf-8")
            except OSError as read_err:
                # Unreadable file: surface as error diagnostic, caller handles exit code
                all_findings.append(
                    NamingFinding(
                        path=file_path,
                        line=0,
                        column=0,
                        symbol="<unreadable>",
                        reason=f"File could not be read: {read_err}",
                        rule_id=RULE_ID_ECLE001_ERROR,
                        scope_kind="file",
                        scope_metrics=ScopeMetrics(
                            logical_lines=0,
                            local_variable_count=0,
                            has_control_flow=False,
                            has_boundary_call=False,
                        ),
                    )
                )
                continue
            file_findings = self.check_source(path=file_path, source_text=source_text)
            all_findings.extend(file_findings)
        return _sort_findings(all_findings)

    def check_source(self, *, path: str, source_text: str) -> list[NamingFinding]:
        """Run ECLE001 on *source_text* (already read) for file *path*."""
        try:
            tree = ast.parse(source_text, filename=path)
        except SyntaxError as syntax_err:
            return [
                NamingFinding(
                    path=path,
                    line=syntax_err.lineno or 0,
                    column=syntax_err.offset or 0,
                    symbol="<syntax-error>",
                    reason=f"Syntax error: {syntax_err.msg}",
                    rule_id=RULE_ID_ECLE001_PARSE,
                    scope_kind="file",
                    scope_metrics=ScopeMetrics(
                        logical_lines=0,
                        local_variable_count=0,
                        has_control_flow=False,
                        has_boundary_call=False,
                    ),
                )
            ]

        findings: list[NamingFinding] = []
        func_nodes = [
            node for node in ast.walk(tree)
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))
        ]
        for func_node in func_nodes:
            try:
                scope_findings = self._check_function_scope(
                    path=path,
                    source_text=source_text,
                    func_node=func_node,
                )
            except Exception as exc:  # noqa: BLE001
                scope_findings = [
                    NamingFinding(
                        path=path,
                        line=getattr(func_node, "lineno", 0),
                        column=0,
                        symbol="<error>",
                        reason=f"Internal checker error during scope evaluation: {exc}",
                        rule_id=RULE_ID_ECLE001_ERROR,
                        scope_kind="function",
                        scope_metrics=ScopeMetrics(
                            logical_lines=0,
                            local_variable_count=0,
                            has_control_flow=False,
                            has_boundary_call=False,
                        ),
                    )
                ]
            findings.extend(scope_findings)

        return _sort_findings(findings)

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _check_function_scope(
        self,
        *,
        path: str,
        source_text: str,
        func_node: ast.FunctionDef | ast.AsyncFunctionDef,
    ) -> list[NamingFinding]:
        """Evaluate ECLE001 rule for a single function/method scope."""
        scope_metrics = self._compute_scope_metrics(func_node, source_text)

        if not _is_non_trivial_scope(
            scope_metrics,
            self._non_trivial_logical_lines,
            self._non_trivial_local_variables,
        ):
            return []

        scope_kind = (
            "method"
            if isinstance(func_node, ast.FunctionDef) and _is_method(func_node)
            else "function"
        )

        assignment_nodes = _collect_local_assignment_nodes(func_node)
        seen_symbols: set[str] = set()
        findings: list[NamingFinding] = []

        for symbol, line, column in assignment_nodes:
            if symbol in seen_symbols:
                continue

            violation_reason = self._classify_violation(symbol)
            if violation_reason is None:
                continue  # Not a denylist candidate

            if _should_skip_by_allowlist(symbol, func_node, source_text, self._allowlist):
                continue

            seen_symbols.add(symbol)
            findings.append(
                NamingFinding(
                    path=path,
                    line=line,
                    column=column,
                    symbol=symbol,
                    reason=violation_reason,
                    rule_id=RULE_ID_ECLE001,
                    scope_kind=scope_kind,
                    scope_metrics=scope_metrics,
                )
            )

        return findings

    def _compute_scope_metrics(
        self,
        func_node: ast.FunctionDef | ast.AsyncFunctionDef,
        source_text: str,
    ) -> ScopeMetrics:
        """Delegate to module-level helper; exists as a method for test monkeypatching."""
        return _compute_scope_metrics(
            func_node,
            source_text,
            self._non_trivial_logical_lines,
            self._non_trivial_local_variables,
        )

    def _classify_violation(self, symbol: str) -> str | None:
        """Return a deterministic reason string if *symbol* is a candidate for ECLE001, else None.

        Note: allowlist guard evaluation is a separate step (_should_skip_by_allowlist).
        All one-letter alpha symbols and denylist symbols are candidates; the allowlist
        guards decide whether to suppress the finding.
        """
        if symbol in self._ambiguous_denylist:
            return (
                f"Ambiguous denylist symbol '{symbol}' used as a business/state variable "
                "in a non-trivial scope — use a descriptive name (ECLE001)"
            )
        if len(symbol) == 1 and symbol.isalpha():
            return (
                f"One-letter business variable '{symbol}' in a non-trivial scope — "
                "use a descriptive name (ECLE001)"
            )
        return None


# ---------------------------------------------------------------------------
# Module-level helpers (non-public, stable for monkeypatching in tests)
# ---------------------------------------------------------------------------

def _sort_findings(findings: list[NamingFinding]) -> list[NamingFinding]:
    """Sort findings by (path, line, column, symbol) — deterministic stable order."""
    return sorted(findings, key=lambda f: (f.path, f.line, f.column, f.symbol))


def _is_method(func_node: ast.FunctionDef) -> bool:
    """Heuristic: first argument is 'self' or 'cls' — treat as method."""
    if func_node.args.args:
        return func_node.args.args[0].arg in ("self", "cls")
    return False
