"""ecle.linting — Static analysis and naming-enforcement gate.

Implements: SPEC-0011
"""

from __future__ import annotations
