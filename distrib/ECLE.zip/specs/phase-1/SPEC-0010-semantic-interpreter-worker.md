# SPEC-0010 — Semantic Interpreter Worker

**Phase:** 1
**Status:** Implemented
**Implements:** ADR-0034, ADR-0027
**Depends on:** SPEC-0001, SPEC-0008, SPEC-0009

---

## Problem

Tree-sitter and Joern extract structurally correct but semantically opaque facts. Three
compounding gaps block FACT-C (Completeness) compliance and make Phase 2 embeddings
semantically blind if left unresolved (ADR-0034 §Context):

1. **Platform classification gap** — `par_ban*` functions are Tuxedo service handlers.
   After full ingestion, ECLE cannot answer "how many Tuxedo services are there?" The
   answer is *unknown*, not zero. This is a FACT-C failure, not a search quality issue.
2. **Function group blindness** — `atGTBan_extract`, `atGTBan_process`, `atGTBan_report`
   are extracted as three unrelated functions with no shared group, role, or
   pipeline-pattern classification.
3. **Phase 2 embedding coupling** — Phase 2 `batch_embed` subscribes to
   `ecle.facts.annotated` (ADR-0034 §Layered architecture Invariant 3). Un-annotated
   facts would produce semantically blind vectors, baking the defect permanently into
   the vector space before Phase 2 begins.

ADR-0034 mandates a deterministic per-fact annotation layer in Phase 1, before Phase 2
embeddings are generated. Contract 20 defines the YAML rule schema and evaluation
semantics. The `semantic_annotations` table is already declared in SPEC-0009 migration
`0001_phase1_schema` per ADR-0034; this spec implements the worker that populates it.

**FACT impact (Contract 04):**
- **Fast** — single-fact rules compiled at startup; evaluation is O(rules × rows) with
  no network calls; co-occurrence bounded by `SEMANTIC_INTERPRETER_MAX_COOCCURRENCE_ROWS`.
- **Accurate** — deterministic pattern matching; `rule_id` + `rule_version` pinned in
  every annotation row; no probabilistic inference at the fact level.
- **Complete** — fills the platform/group/role knowledge gap Tree-sitter cannot produce;
  enables "how many Tuxedo services?" and "how many GTBan pipeline flows?" queries.
- **Trustworthy** — full annotation lineage (`rule_id`, `rule_version`, `annotated_at`)
  per row; idempotent upsert on unique constraint; re-annotation is auditable and scoped.

---

## Decision

Five modules under `src/ecle/workers/semantic_interpreter/`:

| Module | Path | Provides |
|--------|------|---------|
| `rule_schema` | `src/ecle/workers/semantic_interpreter/rule_schema.py` | Pydantic v2 models: `AppliesTo`, `SingleFactMatch`, `CoOccurrenceMatch`, `AnnotationRule`, `SearchRule`, `DisplayRule`, `RuleGroup`, `RuleFile` |
| `rule_loader` | `src/ecle/workers/semantic_interpreter/rule_loader.py` | `RuleLoader` — loads + validates base/tenant/repo YAML rule files; compiles glob/regex at load time |
| `evaluator` | `src/ecle/workers/semantic_interpreter/evaluator.py` | `RuleEvaluator` — single-fact + co-occurrence evaluation; capture-group substitution; tier precedence |
| `worker` | `src/ecle/workers/semantic_interpreter/worker.py` | `SemanticInterpreter(WorkerBase)` — mode-dispatched consumer; writes `semantic_annotations`; emits `ecle.facts.annotated` |
| `__init__` | `src/ecle/workers/semantic_interpreter/__init__.py` | Package init |

**Consumes (two independent consumer groups — ADR-0034 §Worker SRP):**

| Event | Topic | Consumer group | Trigger reason |
|-------|-------|---------------|---------------|
| `ecle.file.stored` | `ecle.file.stored` | `ecle.semantic_interpreter_file` | Single-fact rules; evaluable per file without cross-file data |
| `ecle.repo.indexed` | `ecle.repo.indexed` | `ecle.semantic_interpreter_repo` | Co-occurrence rules; require the full per-repo fact set |

**Emits:**

| Event | Topic | When |
|-------|-------|------|
| `ecle.facts.annotated` | `ecle.facts.annotated` | **Repo trigger flow only (mode="repo")** — after all annotation rules evaluated AND all `semantic_annotations` rows written for the repo. File trigger flow (mode="file") writes annotations and commits offset but does NOT emit this event. Phase 2 `batch_embed` subscribes to `ecle.facts.annotated` to ensure it embeds fully-annotated facts (ADR-0034 §Layered architecture Invariant 3). |

**Amends:**
- **SPEC-0001 Settings** — adds `SEMANTIC_RULES_BASE_PATH`,
  `SEMANTIC_RULES_ARTIFACT_PATH_PREFIX`, `SEMANTIC_INTERPRETER_MAX_COOCCURRENCE_ROWS`,
  `SEMANTIC_INTERPRETER_MODE` (see Interface contract).
- **SPEC-0008 `topic_registry.py`** — adds `TOPIC_FACTS_ANNOTATED =
  "ecle.facts.annotated"` to `PHASE_1_TOPICS` (Contract 09 §Topic naming).
- **Contract 09 §3** — adds `semantic_interpreter_file` to `file.stored` consumers;
  adds `tenant_id` to `file.stored` payload; adds `semantic_interpreter_repo` to
  `repo.indexed` consumers; adds `facts.annotated` event row.

**Reads (Layer 0 fact tables — read-only; this worker MUST NOT modify these tables):**
- `function_facts` — single-fact pattern matching on `function_name` (Contract 15)
- `file_tables` — single-fact pattern matching on `table_name` (Contract 15)
- `function_table_ops` — single-fact and co-occurrence matching (Contract 15)
- `repositories` — `applies_to` pre-filter: `platform`, `primary_language`, `repo_type`
  (SPEC-0009, ADR-0034)

**Writes:**
- `semantic_annotations` — via `IStructuredDB.upsert()` only; unique constraint
  `(tenant_id, repo_id, target_type, target_id, rule_id) WHERE is_current = true`
  (SPEC-0009, Contract 15 §1 Rules 1+4)

**Layered architecture invariants (ADR-0034 §Layered architecture — non-negotiable):**
- This worker does NOT modify `file_facts`, `function_facts`, `file_tables`,
  `file_entry_points`, `file_external_calls`, or `function_table_ops` rows.
- This worker does NOT import from `ecle.workers.parse_repo`,
  `ecle.workers.persist_facts`, or any other worker module (ADR-0027; enforced by
  `eval_async_coupling` on every PR).
- Layer 0 extraction (parse_repo, persist_facts) is NOT re-triggered by this worker
  for any reason.

---

## Interface contract

```python
# src/ecle/workers/semantic_interpreter/rule_schema.py
# (from __future__ import annotations — Contract 01 §2)

class AppliesTo(BaseModel):
    platform: str | None = None       # matches repositories.platform — Contract 20 §6.3
    language: str | None = None       # matches repositories.primary_language — Contract 20 §6.5
    repo_type: str | None = None      # matches repositories.repo_type — Contract 20 §6.4

class SingleFactMatch(BaseModel):
    field: str                        # column name in the target table — Contract 20 §2.1
    pattern: str                      # glob (fnmatch) or "re:..." prefix — Contract 20 §2.1

class CoOccurrenceMatch(BaseModel):
    table_name: str                   # glob match on table_name column — Contract 20 §2.1
    min_functions: int                # minimum distinct functions touching the table — Contract 20 §2.1

class QueryTokenMatch(BaseModel):
    query_token: str                  # exact or glob match on query token — Contract 20 §2.2

class RewriteAction(BaseModel):
    filter: dict[str, str | None] | None = None   # add DB filter predicates — Contract 20 §2.2
    expand_tokens: list[str] | None = None         # additional query tokens — Contract 20 §2.2

class AnnotationRule(BaseModel):
    rule_id: str
    version: int                      # >= 1 monotonic — Contract 20 §5
    scope: Literal["annotation"]
    applies_to: AppliesTo | None = None
    target: Literal["file_tables", "function_facts", "function_table_ops"]  # Contract 20 §6.2
    match: SingleFactMatch | CoOccurrenceMatch
    annotate: dict[str, str | None]   # values may use "{match.group}" / "{match[N]}" substitution — Contract 20 §6.9
    confidence: float                 # 0.0–1.0 inclusive — Contract 20 §6.10
    # @model_validator(mode="after") [V1]: if isinstance(match, CoOccurrenceMatch) and
    #   target != "function_table_ops": raise ValidationError(
    #   "co_touch match requires target='function_table_ops'") — Contract 20 §5, AC-18
    # @model_validator(mode="after") [V2]: for regex patterns (match.pattern starts with
    #   "re:"), parse named capture groups from compiled regex; validate:
    #   (a) for each "{match.<name>}" reference in annotate values, verify <name> in
    #       compiled_pattern.groupindex — raise ValidationError if not found;
    #   (b) for each "{match[N]}" reference in annotate values, verify N <=
    #       compiled_pattern.groups — raise ValidationError if out of range;
    #   Contract 20 §5/§6.9, AC-15

class SearchRule(BaseModel):
    rule_id: str
    version: int                      # >= 1 monotonic — Contract 20 §5
    scope: Literal["search"]
    applies_to: AppliesTo | None = None
    # Sub-form A (rewrite) — mutually exclusive with sub-form B:
    match: QueryTokenMatch | None = None
    rewrite: RewriteAction | None = None
    # Sub-form B (keyword group) — mutually exclusive with sub-form A:
    keyword_group: str | None = None  # Contract 20 §2.2
    members: list[str] | None = None  # Contract 20 §2.2
    description: str | None = None
    # @model_validator(mode="after"): raises ValidationError if both match and
    # keyword_group present, or if neither is present — Contract 20 §5

class DisplayRule(BaseModel):
    rule_id: str
    version: int                      # >= 1 monotonic — Contract 20 §5
    scope: Literal["display"]
    applies_to: AppliesTo | None = None
    match: SingleFactMatch
    label: str                        # human-readable label substitution — Contract 20 §2.3
    description: str | None = None

class RuleGroup(BaseModel):
    rule_group: str                   # unique per rule file — Contract 20 §3
    version: int
    applies_to: AppliesTo | None = None
    description: str
    rules: list[AnnotationRule | SearchRule | DisplayRule]  # Contract 20 §3

class RuleFile(BaseModel):
    rules: list[AnnotationRule | SearchRule | DisplayRule | RuleGroup]  # Contract 20 §5
    # Validation: duplicate rule_id within tier rejected; co_touch on non-function_table_ops rejected
```

```python
# src/ecle/workers/semantic_interpreter/rule_loader.py
# (from __future__ import annotations — Contract 01 §2)

@dataclass
class CompiledAnnotationRule:
    rule: AnnotationRule
    compiled_pattern: re.Pattern[str] | None  # None for co_touch rules; compiled at load time only
    tier: Literal["base", "tenant", "repo"]   # Contract 20 §4

class RuleLoader:
    def __init__(self, db: IStructuredDB, artifact_store: IArtifactStore, settings: Settings) -> None: ...
    def load(self) -> None: ...
    # Loads all base rules from settings.SEMANTIC_RULES_BASE_PATH; validates each file
    # via RuleFile; compiles all glob (fnmatch.translate + re.compile) and regex
    # (re.compile with "re:" prefix stripped) patterns immediately. Patterns MUST be
    # compiled here — never during evaluation (Contract 20 §5).
    # Raises InvalidConfigError on YAML parse failure or RuleFile validation failure;
    # logs WARN with file path and error detail; skips invalid file; continues with
    # valid files — Contract 20 §7.1. No process exit on base rule validation failure.

    def get_annotation_rules(self, repo_id: str, tenant_id: str) -> list[CompiledAnnotationRule]: ...
    # Loads tenant YAML from artifact store path
    #   f"{settings.SEMANTIC_RULES_ARTIFACT_PATH_PREFIX}{tenant_id}/tenant.yaml"
    # and repo YAML from
    #   f"{settings.SEMANTIC_RULES_ARTIFACT_PATH_PREFIX}{tenant_id}/{repo_id}/repo.yaml"
    # (if present).
    # Compiles patterns for any newly loaded rule; caches compiled rules by (tenant_id, repo_id).
    # Applies applies_to pre-filter: queries repositories table via:
    #   db.execute(
    #       "SELECT platform, primary_language, repo_type FROM repositories
    #        WHERE repo_id = %(repo_id)s AND tenant_id = %(tenant_id)s",
    #       {"repo_id": repo_id, "tenant_id": tenant_id},
    #       tenant_id="__system__",  # explicit filter in SQL; skip double-filtering
    #   )
    # If query raises DBConnectionError: re-raises as ECLEBaseError (WorkerBase retries).
    # Skips any rule whose applies_to fields do not match repo metadata (case-insensitive).
    # Returns filtered list sorted by tier precedence: repo first, then tenant, then base.
    # Returns empty list if no rules match applies_to or no rules loaded.
```

```python
# src/ecle/workers/semantic_interpreter/evaluator.py
# (from __future__ import annotations — Contract 01 §2)

@dataclass
class AnnotationResult:
    target_type: str        # "file_tables" | "function_facts" | "function_table_ops"
    target_id: str          # UUID of the matched row in the target table
    rule_id: str
    rule_version: int
    platform: str | None    # from annotate.platform — Contract 20 §6.7
    domain_entity: str | None  # from annotate.domain_entity — ADR-0018 enrich step key
    type: str | None        # from annotate.type — Contract 20 §6.6
    group: str | None       # from annotate.group (with capture substitution)
    role: str | None        # from annotate.role (with capture substitution)
    confidence: float

class RuleEvaluator:
    def __init__(self, db: IStructuredDB, settings: Settings) -> None: ...

    def evaluate_file(
        self,
        file_id: str,
        repo_id: str,
        tenant_id: str,
        rules: list[CompiledAnnotationRule],
    ) -> list[AnnotationResult]: ...
    # Evaluates single-fact annotation rules only. Co-occurrence (CoOccurrenceMatch)
    # rules are SKIPPED in file mode.
    # For each SingleFactMatch rule: queries target table with parameterised SQL:
    #   SELECT id, {field} FROM {table} WHERE file_id=%(file_id)s AND repo_id=%(repo_id)s
    #   AND is_current=true
    # Table/column names via psycopg2.sql.Identifier — never f-string SQL (Contract 10 A10).
    # Applies tier precedence (repo > tenant > base; same tier: highest confidence wins;
    # equal confidence: first-match-wins in load order) to deduplicate per (target_id, rule_id).
    # Raises PermanentWorkerError on regex evaluation exception or unresolved substitution.

    def evaluate_repo(
        self,
        repo_id: str,
        tenant_id: str,
        rules: list[CompiledAnnotationRule],
    ) -> list[AnnotationResult]: ...
    # Evaluates single-fact AND co-occurrence annotation rules.
    # For co-occurrence rules: queries function_table_ops with LIMIT
    #   settings.SEMANTIC_INTERPRETER_MAX_COOCCURRENCE_ROWS + 1.
    # If returned row count > SEMANTIC_INTERPRETER_MAX_COOCCURRENCE_ROWS:
    #   raises PermanentWorkerError("co-occurrence row limit exceeded for repo_id=<id>").
    # Groups rows by table_name; glob-matches table_name against co_touch.table_name pattern;
    # for each matched table where distinct function count >= min_functions: annotates each
    # matching function row (substitutes {table_name} as literal table name value).
    # Applies tier precedence and deduplication as in evaluate_file.
    # Raises PermanentWorkerError on regex exception or unresolved substitution.

    def _apply_substitution(self, template: str, match: re.Match[str]) -> str: ...
    # "{match.group_name}" → named capture group value via match.group(group_name).
    # "{match[N]}" → positional capture group via match.group(N).
    # Returns template unchanged if no substitution placeholders present.
    # Raises PermanentWorkerError if named group absent or positional index out of range.
```

```python
# src/ecle/workers/semantic_interpreter/worker.py
# (from __future__ import annotations — Contract 01 §2)

class SemanticInterpreter(WorkerBase):  # SPEC-0008
    def __init__(
        self,
        consumer: Consumer,
        producer: Producer,
        db: IStructuredDB,
        settings: Settings,
        *,
        rule_loader: RuleLoader,
        evaluator: RuleEvaluator,
        mode: Literal["file", "repo"],
    ) -> None: ...
    # mode controls worker_name and input_topic; keyword-only args prevent positional error.
    # No mutable default arguments — Contract 10 (anti-pattern guard), Contract 01 §5.

    @property
    def worker_name(self) -> str: ...
    # mode="file"  → "semantic_interpreter_file"
    # mode="repo"  → "semantic_interpreter_repo"

    @property
    def input_topic(self) -> str: ...
    # mode="file"  → TOPIC_FILE_STORED   ("ecle.file.stored")
    # mode="repo"  → TOPIC_REPO_INDEXED  ("ecle.repo.indexed")

    def process(self, event: dict[str, Any]) -> None: ...
    # Idempotent — Contract 09 §1. Same event processed twice → same semantic_annotations
    # rows (upsert on unique constraint). Raises ECLEBaseError (transient) or
    # PermanentWorkerError (permanent) — SPEC-0008 WorkerBase contract.
```

```python
# src/ecle/events/topic_registry.py  — amendment to SPEC-0008
TOPIC_FACTS_ANNOTATED = "ecle.facts.annotated"  # new; added to PHASE_1_TOPICS — Contract 09
```

**`ecle.facts.annotated` event payload (emitted by this worker):**

```python
# ecle.facts.annotated  (emitted)
@dataclass
class FactsAnnotatedPayload:
    repo_id: str            # repository identifier — Contract 09
    tenant_id: str          # tenant isolation key — Contract 15
    annotation_count: int   # total semantic_annotations rows written in this run
    rule_ids: list[str]     # rule_ids of all annotation rules applied (deduplicated)
    annotated_at: str       # ISO-8601 UTC timestamp
    X_Request_Id: str       # mandatory — Contract 16
    X_Trace_Id: str         # mandatory — Contract 16
```

**Settings additions** (`src/ecle/config.py` — extends table from SPEC-0001, amended by SPEC-0008):

| Field | Default | Contract ref |
|-------|---------|-------------|
| `SEMANTIC_RULES_BASE_PATH` | `"src/ecle/workers/semantic_interpreter/base_rules/"` | Contract 20 §4 |
| `SEMANTIC_RULES_ARTIFACT_PATH_PREFIX` | `"semantic_rules/"` | Contract 20 §4, Contract 14 §2.3 — no hardcoded path literals in code |
| `SEMANTIC_INTERPRETER_MAX_COOCCURRENCE_ROWS` | `50000` | ADR-0034 §Consequences |
| `SEMANTIC_INTERPRETER_MODE` | `"file"` | ADR-0034 §Worker SRP — `"file"` or `"repo"` |

No credentials or secrets in defaults — Contract 01 §9.

**DB schema (no DDL in this spec — declared in SPEC-0009 migration `0001_phase1_schema`):**

```sql
-- Table: semantic_annotations (SPEC-0009, ADR-0034, Contract 15)
-- Unique constraint: (tenant_id, repo_id, target_type, target_id, rule_id)
--   WHERE is_current = true  — ensures idempotent re-runs
-- Partial unique index: (tenant_id, repo_id, target_type, target_id, rule_id)
--   WHERE is_current = true  — supports ADR-0018 enrich-step exact lookup — SPEC-0009

-- READ-ONLY in this worker (MUST NOT be modified by SemanticInterpreter):
--   function_facts, file_tables, function_table_ops, repositories
```

---

## Behaviour

**Startup (both modes):**

1. Factory calls `rule_loader.load()` at process startup. `RuleLoader` reads every YAML
   file from `settings.SEMANTIC_RULES_BASE_PATH`, validates each via `RuleFile` Pydantic
   model, and compiles all glob patterns (`fnmatch.translate` + `re.compile`) and all regex
   patterns (`re.compile`, "re:" prefix stripped). Compilation happens ONCE at startup —
   NEVER during evaluation (Contract 20 §5). If any file fails `RuleFile` validation:
   log WARN with file path and error detail; skip the invalid file; continue loading valid
   files. Worker startup proceeds with valid rules only — Contract 20 §7.1.

2. Worker registers lifecycle bootstrap row:
   `db.upsert("worker_lifecycle", {"worker_name": self.worker_name, "command": "run"}, conflict_keys=["worker_name"], tenant_id="__system__")` — SPEC-0008 §Behaviour.

3. `WorkerBase.run()` begins polling `input_topic` with consumer group
   `consumer_group(self.worker_name)` (e.g. `"ecle.semantic_interpreter_file"` —
   SPEC-0008 `consumer_group()` helper).

**File trigger flow (mode="file", consuming `ecle.file.stored`):**

4. `process(event)` extracts `file_id`, `repo_id`, `tenant_id`, `X_Request_Id`,
   `X_Trace_Id` from event payload. All field reads are parameterised — Contract 01 §7.

5. Calls `rule_loader.get_annotation_rules(repo_id, tenant_id)`:
   a. Loads tenant YAML from artifact store path
      `f"{settings.SEMANTIC_RULES_ARTIFACT_PATH_PREFIX}{tenant_id}/tenant.yaml"`
      (no-op if absent — `IArtifactStore.exists()` check first).
   b. Loads repo YAML from
      `f"{settings.SEMANTIC_RULES_ARTIFACT_PATH_PREFIX}{tenant_id}/{repo_id}/repo.yaml"`
      (no-op if
      absent).
   c. Compiles patterns for any newly loaded rules; caches compiled rules keyed by
      `(tenant_id, repo_id)` to avoid recompilation on subsequent events.
   d. Queries `repositories` table for `applies_to` pre-filter:
      `db.execute("SELECT platform, primary_language, repo_type FROM repositories WHERE repo_id = %(repo_id)s AND tenant_id = %(tenant_id)s", {"repo_id": repo_id, "tenant_id": tenant_id}, tenant_id="__system__")`.
      If query raises `DBConnectionError`: re-raises; WorkerBase retries; offset not committed.
   e. For each loaded rule, if `rule.applies_to` is set: compare repo metadata
      case-insensitively against `applies_to.platform`, `applies_to.language`,
      `applies_to.repo_type`; skip any rule where a set field does not match.
   f. Returns filtered `list[CompiledAnnotationRule]` sorted repo-first (tier precedence
      pre-applied). Returns empty list if no rules survive the pre-filter.

6. Calls `evaluator.evaluate_file(file_id, repo_id, tenant_id, rules)`:
   a. For each annotation-scope rule with `SingleFactMatch`: executes parameterised SQL to
      fetch rows from the target table (`function_facts`, `file_tables`, or
      `function_table_ops`) filtered by `file_id`, `repo_id`, `is_current=true`.
      Table and column names passed via `psycopg2.sql.Identifier` — never f-string SQL
      (Contract 01 §10, Contract 10 A10).
   b. For each returned row: evaluates `compiled_pattern` against `row[rule.match.field]`
      (glob via `fnmatch.fnmatch`; regex via `re.fullmatch` — Contract 20 §2.1). On
      pattern evaluation exception (malformed compiled regex): raises `PermanentWorkerError`.
   c. On match: calls `_apply_substitution(template, match)` for each `annotate` field
      containing `{match.group_name}` or `{match[N]}`. On unresolved substitution: raises
      `PermanentWorkerError`.
   d. Co-occurrence rules (`CoOccurrenceMatch`) are **skipped** in file mode.
   e. Applies tier precedence across all results: repo > tenant > base; same tier — highest
      confidence wins; equal confidence — first-match-wins in load order. Deduplicates per
      `(target_id, rule_id)` pair.

7. Batch-upserts all `AnnotationResult` rows to `semantic_annotations` via
   `db.upsert("semantic_annotations", row, conflict_keys=["tenant_id", "repo_id", "target_type", "target_id", "rule_id"], tenant_id=tenant_id)` — one `upsert()` call per result.
   Uses Contract 15 §1 Rules 1+4 two-step version-chain (implemented in SPEC-0009
   `PostgreSQLStructuredDB`). On failure: raises `DBConnectionError → ECLEBaseError`;
   WorkerBase retries; offset not committed; second run is safe (upsert idempotent).

8. WorkerBase commits Kafka offset via `consumer.commit(msg, asynchronous=False)` —
   SPEC-0008 §Behaviour step 6. Offset committed ONLY after all `db.upsert()` calls in
   step 7 succeed. No `ecle.facts.annotated` event is emitted in file trigger mode —
   ADR-0034 §Layered architecture Invariant 2: `ecle.facts.annotated` is the
   per-repo ingestion-completion signal, emitted only by the repo trigger flow.

**Repo trigger flow (mode="repo", consuming `ecle.repo.indexed`):**

9. `process(event)` extracts `repo_id`, `tenant_id`, `X_Request_Id`, `X_Trace_Id`.
    Steps 5a–5f (rule loading and applies_to pre-filter) are identical to the file flow.

10. Calls `evaluator.evaluate_repo(repo_id, tenant_id, rules)`:
    a. For single-fact annotation rules: executes parameterised SQL to fetch ALL rows from
       target table filtered by `repo_id`, `is_current=true` (no `file_id` filter).
       Pattern matching, capture substitution, and precedence deduplication as in steps
       6b–6e.
    b. For co-occurrence annotation rules (`CoOccurrenceMatch`): executes:
       `db.execute("SELECT id, function_name, table_name FROM function_table_ops WHERE repo_id = %(repo_id)s AND is_current = true LIMIT %(limit)s", {"repo_id": repo_id, "limit": settings.SEMANTIC_INTERPRETER_MAX_COOCCURRENCE_ROWS + 1}, tenant_id=tenant_id)`.
       If returned row count > `SEMANTIC_INTERPRETER_MAX_COOCCURRENCE_ROWS`: raises
       `PermanentWorkerError("co-occurrence row limit exceeded for repo_id=<id>")` — routes
       to DLQ immediately; no annotations written.
    c. Groups rows by `table_name`; matches each `table_name` against
       `co_touch.table_name` glob pattern via `fnmatch.fnmatch`. For each matched table
       where `len(distinct function_names) >= co_touch.min_functions`: calls
       `_apply_substitution()` with `{table_name}` resolved to the literal `table_name`
       value; builds `AnnotationResult` for each matching function row.
    d. Applies tier precedence and deduplication identical to step 6e.

11. Step 7 (batch upsert to `semantic_annotations`) executes identically to the file
    trigger flow.

12. Builds `FactsAnnotatedPayload` with `repo_id`, `tenant_id`, `annotation_count` (count
    of rows upserted in this run), `rule_ids` (deduplicated list of all applied rule_ids),
    `annotated_at` (UTC ISO-8601), `X_Request_Id` and `X_Trace_Id` propagated from the
    incoming `ecle.repo.indexed` event.

13. Produces `ecle.facts.annotated` event to `TOPIC_FACTS_ANNOTATED`; calls
    `producer.flush()`. On failure: raises `ECLEBaseError`; WorkerBase retries from
    step 11 (upsert idempotent — safe to re-run). Offset is NOT committed until this
    step succeeds.

14. WorkerBase commits Kafka offset via `consumer.commit(msg, asynchronous=False)` —
    SPEC-0008 §Behaviour step 6. Offset committed ONLY after `ecle.facts.annotated` is
    produced and flushed.

---

## Acceptance criteria

| ID | Given | Input | Expected |
|----|-------|-------|---------|
| AC-01 | Annotation rule `rule_id="tuxedo-service-handler"`, `pattern: "par_*"`, `target: function_facts`, `confidence: 1.0` loaded in base tier | `function_facts` row with `function_name = "par_ban_init"` | `AnnotationResult` produced with `rule_id="tuxedo-service-handler"`, `platform="Tuxedo"`, `type="service_handler"`, `confidence=1.0` |
| AC-02 | Annotation rule with `pattern: "re:^at(?P<group>[A-Z][a-zA-Z0-9]+)_(extract\|process\|report)$"` loaded; `annotate.group = "{match.group}"`, `annotate.role = "{match[2]}"` | `function_facts` row with `function_name = "atGTBan_extract"` | `AnnotationResult` with `group="GTBan"`, `role="extract"`, `type="pipeline_stage"` via capture substitution. Note: `{match[2]}` extracts group 2 `(extract\|process\|report)`; `{match[1]}` would extract group 1 `(?P<group>...)` = "GTBan" — ADR-0034 §YAML examples |
| AC-03 | Co-occurrence rule `target: function_table_ops`, `min_functions: 2`, `table_name: "*"` | 3 distinct functions all touch table `GL_TRANS` in `function_table_ops` | All 3 function rows produce `AnnotationResult` with `group="GL_TRANS"`, `type="shared_table_group"` |
| AC-04 | Co-occurrence rule `min_functions: 2` | Only 1 distinct function touches `GL_TRANS` | No `AnnotationResult` produced for `GL_TRANS` group |
| AC-05 | Rule has `applies_to: {platform: "Tuxedo"}` | `repositories.platform = "Spring"` for the repo under test | Rule skipped by pre-filter; 0 annotations produced |
| AC-06 | Rule has `applies_to: {platform: "Tuxedo"}` | `repositories.platform = "tuxedo"` (different case) | Case-insensitive match succeeds; rule applied; annotations produced |
| AC-07 | Rule has no `applies_to` field set | Repository with any platform, language, repo_type | Rule applied; no pre-filter rejection |
| AC-08 | Repo tier rule and base tier rule both match same function; repo rule `confidence: 0.9`, base rule `confidence: 1.0` | Same `function_facts` row matched by both | Repo tier rule wins (repo > base regardless of confidence) — Contract 20 §4 Rule 1 |
| AC-09 | Two base tier rules both match same function; Rule A `confidence: 0.9`, Rule B `confidence: 0.7` | Same `function_facts` row | Rule A annotation produced; Rule B excluded — deduplication applied at write time by `evaluator.evaluate_file()` before `db.upsert()` is called; only one `AnnotationResult` per `(target_id, rule_id-A)` pair reaches the DB — Contract 20 §4 Rule 2 |
| AC-10 | Two base tier rules both match same function; Rule A `confidence: 1.0`, Rule B `confidence: 1.0`; Rule A first in YAML file | Same `function_facts` row | Rule A wins; first-match-wins in file order — Contract 20 §4 Rule 3 |
| AC-11 | `SemanticInterpreter` (mode="file") processes same `ecle.file.stored` event twice with identical content | First run writes 5 `semantic_annotations` rows | Second run calls `db.upsert()` with same conflict keys; `semantic_annotations` contains 5 rows (not 10); no duplicate rows — Contract 09 §1 idempotency |
| AC-12 | All annotation rules evaluated; all `db.upsert()` calls complete in `mode="repo"` | `ecle.repo.indexed` event | `ecle.facts.annotated` produced with correct `repo_id`, `tenant_id`, `annotation_count`, `rule_ids[]`, `annotated_at`; `X_Request_Id` and `X_Trace_Id` propagated from input event — ADR-0034 §Layered architecture Invariant 2 |
| AC-12b | `SemanticInterpreter` in `mode="file"` processes a file event; all upserts complete | `ecle.file.stored` event | No `ecle.facts.annotated` event emitted; offset committed only after all `db.upsert()` calls succeed |
| AC-13 | `db.upsert("semantic_annotations")` raises `DBConnectionError` | Any event | `ECLEBaseError` propagated to WorkerBase; offset NOT committed; `ecle.facts.annotated` NOT emitted; WorkerBase retries up to `KAFKA_DLQ_MAX_RETRIES` — SPEC-0008 |
| AC-14 | `function_table_ops` row count for repo = 50,001 (> `SEMANTIC_INTERPRETER_MAX_COOCCURRENCE_ROWS=50000`) | `ecle.repo.indexed` event | `PermanentWorkerError` raised; event routed to DLQ immediately; no `semantic_annotations` rows written |
| AC-15 | `AnnotationRule` with `pattern: "re:^at(?P<group>...)$"` and `annotate: {role: "{match.missing_group}"}` where `missing_group` is not a named group in the pattern | `RuleFile` Pydantic validation at `rule_loader.load()` | `ValidationError` raised at load time; rule file rejected with descriptive message — Contract 20 §5 [V2] |
| AC-16 | Base rules YAML file missing required field `rule_id` | Worker startup (before consuming any event) | WARN logged with file path and error detail; invalid file skipped; remaining valid rules loaded; Kafka polling begins with valid rules only — Contract 20 §7.1 |
| AC-17 | `SearchRule` YAML document contains both `match` and `keyword_group` fields | `RuleFile` Pydantic validation | `ValidationError` raised; entire rule file rejected with descriptive message — Contract 20 §5 |
| AC-18 | `AnnotationRule` YAML document has `co_touch` with `target: file_tables` | `RuleFile` Pydantic validation | `ValidationError` raised; rule file rejected — Contract 20 §5 |
| AC-19 | Two `SemanticInterpreter` instances constructed with `mode="file"` and `mode="repo"` | `worker_name`, `input_topic` properties inspected | `mode="file"` → `worker_name="semantic_interpreter_file"`, `input_topic="ecle.file.stored"`; `mode="repo"` → `worker_name="semantic_interpreter_repo"`, `input_topic="ecle.repo.indexed"` |
| AC-20 | `semantic_interpreter` package import graph inspected | `eval_async_coupling` CI check on every PR | Zero imports from `ecle.workers.parse_repo`, `ecle.workers.persist_facts`, or any other worker module — ADR-0027 |
| AC-21 | `process()` completes normally | `function_facts`, `file_tables`, `function_table_ops` rows before and after | Row counts and field values identical; no modification by this worker — ADR-0034 §Layered architecture Invariant 1 |

---

## Error handling

| Error condition | Classification | Response | Event emitted |
|----------------|---------------|-----------|--------------|
| Invalid YAML or `RuleFile` validation failure in base rules directory at startup | Non-fatal | WARN log with file path and error detail; invalid file skipped; processing continues with remaining valid rule files; Kafka polling begins — Contract 20 §7.1 | None |
| Tenant/repo YAML from artifact store fails `RuleFile` validation | Non-fatal | WARN log with file path and error detail; invalid rule file skipped; remaining valid rule files applied to the current event; event is NOT routed to DLQ due to rule validation failure alone — Contract 20 §7.1 | None |
| `repositories` query in `applies_to` pre-filter fails | Transient | `DBConnectionError → ECLEBaseError`; WorkerBase retries with exponential back-off; DLQ after `KAFKA_DLQ_MAX_RETRIES` | DLQ envelope on final retry |
| Pattern evaluation raises exception on compiled regex | Permanent | `PermanentWorkerError`; DLQ immediate; no retry — rule is broken, retry cannot help | DLQ envelope |
| Unresolved capture substitution (`{match.group_name}` or `{match[N]}` not found) | Permanent | `PermanentWorkerError`; DLQ immediate; no retry | DLQ envelope |
| Co-occurrence row count > `SEMANTIC_INTERPRETER_MAX_COOCCURRENCE_ROWS` | Permanent | `PermanentWorkerError`; DLQ immediate; no retry — increase limit or reduce repo size | DLQ envelope |
| `db.upsert("semantic_annotations")` raises `psycopg2.Error` | Transient | `DBConnectionError → ECLEBaseError`; WorkerBase retries (upsert is idempotent — safe to re-run) | DLQ envelope on final retry |
| Kafka produce (`ecle.facts.annotated`) fails | Transient | `ECLEBaseError`; WorkerBase retries from step 7 (upsert idempotent — safe to re-run); offset not committed | DLQ envelope on final retry |

All exceptions chained with `raise X(...) from exc` — Contract 01 §4.
No bare `except:` — Contract 10 A9.

---

## Tests required

File: `tests/unit/test_rule_schema.py`
File: `tests/unit/test_rule_loader.py`
File: `tests/unit/test_evaluator.py`
File: `tests/unit/test_worker.py`
File: `tests/integration/test_semantic_interpreter_integration.py`

Every test file must carry `# Implements: SPEC-0010` header — Contract 02 §4.

| Test ID | Test case | Type | Verifies |
|---------|-----------|------|---------|
| T-01 | `test_valid_annotation_rule_glob` | unit | `AnnotationRule` with glob `pattern: "par_*"` accepted by Pydantic v2 |
| T-02 | `test_valid_annotation_rule_regex` | unit | `AnnotationRule` with `pattern: "re:^at.*"` accepted by Pydantic v2 |
| T-03 | `test_valid_annotation_rule_cooccurrence` | unit | `AnnotationRule` with `CoOccurrenceMatch` and `target: function_table_ops` accepted |
| T-04 | `test_valid_search_rule_rewrite` | unit | `SearchRule` with `match` + `rewrite` (sub-form A) accepted; no `keyword_group` field required |
| T-05 | `test_valid_search_rule_keyword_group` | unit | `SearchRule` with `keyword_group` + `members` + `description` (sub-form B) accepted; no `match` field required |
| T-06 | `test_invalid_search_rule_both_subforms` | unit | `ValidationError` raised when `SearchRule` has both `match` and `keyword_group` — AC-17 |
| T-07 | `test_invalid_cooccurrence_on_file_tables` | unit | `ValidationError` raised for `AnnotationRule` with `co_touch` and `target: file_tables` — AC-18 |
| T-08 | `test_rule_group_container` | unit | `RuleGroup` YAML parsed; all enclosed `rules` extracted as independent `AnnotationRule` objects |
| T-09 | `test_invalid_scope_value` | unit | `ValidationError` raised for `scope: "transform"` (unknown scope) — Contract 20 §6.1 |
| T-10 | `test_loads_base_rules_at_startup` | unit | `load()` reads YAML from `SEMANTIC_RULES_BASE_PATH`; returned `CompiledAnnotationRule` objects have `compiled_pattern` that is a `re.Pattern` — AC-16 pre-condition |
| T-11 | `test_applies_to_platform_skips_non_matching_repo` | unit | `get_annotation_rules()` returns empty list when `repositories.platform="Spring"` and rule has `applies_to.platform="Tuxedo"` — AC-05 |
| T-12 | `test_applies_to_any_matches_all_repos` | unit | `get_annotation_rules()` returns all rules when no `applies_to` set on any rule — AC-07 |
| T-13 | `test_tier_precedence_repo_over_tenant` | unit | When both repo-tier and tenant-tier rules match same repo, repo-tier rule appears first in returned list — AC-08 |
| T-14 | `test_tier_precedence_confidence_wins_within_tier` | unit | Within same tier, higher-confidence rule appears before lower-confidence rule in returned list — AC-09 |
| T-15 | `test_invalid_yaml_raises_warn_and_skips` | unit | `load()` logs WARN and skips invalid file when YAML missing required `rule_id` field; valid sibling files still loaded — AC-16, Contract 20 §7.1 |
| T-16 | `test_regex_compiled_at_load_not_evaluation` | unit | `CompiledAnnotationRule.compiled_pattern` is a `re.Pattern` after `load()`; no `re.compile` call occurs during `evaluate_file()` call (spy/mock assertion) — Contract 20 §5 |
| T-17 | `test_glob_match_produces_annotation` | unit | `evaluate_file()` returns `AnnotationResult` with correct `rule_id`, `platform`, `type`, `confidence` for `function_name="par_ban_init"` matched against `"par_*"` — AC-01 |
| T-18 | `test_regex_capture_group_substitution` | unit | `evaluate_file()` with regex named capture produces `group="GTBan"` from `function_name="atGTBan_extract"` — AC-02 |
| T-19 | `test_positional_capture_substitution` | unit | `_apply_substitution("{match[2]}", match)` on regex `^at(?P<group>...)_(extract|process|report)$` resolves to second positional capture group value `"extract"` — AC-02 |
| T-20 | `test_no_match_produces_no_annotation` | unit | Row with `function_name="unrelated_fn"` against `"par_*"` pattern → empty `list[AnnotationResult]` |
| T-21 | `test_cooccurrence_annotates_shared_table_functions` | unit | `evaluate_repo()` with 3 distinct functions touching `GL_TRANS`, `min_functions=2` → 3 `AnnotationResult` rows with `group="GL_TRANS"` — AC-03 |
| T-22 | `test_cooccurrence_row_limit_raises_permanent_error` | unit | `evaluate_repo()` with stubbed DB returning `MAX_COOCCURRENCE_ROWS + 1` rows → `PermanentWorkerError` raised — AC-14 |
| T-23 | `test_unresolved_named_group_fails_at_load` | unit | `RuleFile` with `AnnotationRule` containing `pattern: "re:^par_(?P<group>...)$"` and `annotate: {role: "{match.missing_group}"}` → `ValidationError` raised during `load()`; rule file rejected — AC-15, Contract 20 §5 [V2a] |
| T-23b | `test_positional_group_out_of_range_fails_at_load` | unit | `RuleFile` with `AnnotationRule` containing `pattern: "re:^par_([A-Z]+)$"` (1 group) and `annotate: {role: "{match[5]}"}` → `ValidationError` raised during `load()`; rule file rejected — Contract 20 §5 [V2b] |
| T-24 | `test_end_to_end_annotation_file_trigger` | integration | `ecle.file.stored` event consumed → `semantic_annotations` rows written with correct `rule_id`, `rule_version`, `confidence`, `annotated_at`, `is_current=true` — AC-01, AC-12 |
| T-25 | `test_end_to_end_facts_annotated_emitted` | integration | After all upserts complete, `ecle.facts.annotated` produced to Kafka topic with correct `annotation_count`, `rule_ids[]`, propagated `X_Request_Id` — AC-12 |
| T-26 | `test_idempotent_rerun_same_annotations` | integration | Two `ecle.file.stored` events with same `file_id` processed sequentially → `semantic_annotations` row count unchanged; `is_current=true` row has same `rule_id` and `confidence` — AC-11 |
| T-27 | `test_mode_file_worker_name_and_topic` | unit | `SemanticInterpreter(mode="file").worker_name == "semantic_interpreter_file"` and `.input_topic == "ecle.file.stored"` — AC-19 |
| T-28 | `test_mode_repo_worker_name_and_topic` | unit | `SemanticInterpreter(mode="repo").worker_name == "semantic_interpreter_repo"` and `.input_topic == "ecle.repo.indexed"` — AC-19 |
| T-29 | `test_db_upsert_failure_propagates_ecle_base_error` | unit | `db.upsert()` raises `DBConnectionError` → `ECLEBaseError` propagated; offset NOT committed; `ecle.facts.annotated` NOT produced — AC-13 |
| T-30 | `test_file_trigger_does_not_emit_facts_annotated` | unit | `process()` in `mode="file"` calls `db.upsert()` and commits offset; producer `produce()` is never called — AC-12b |
| T-31 | `test_layer0_fact_tables_not_modified` | unit | After `process()` completes: mock DB `execute()` calls inspected; no `UPDATE` or `INSERT` against `function_facts`, `file_tables`, `function_table_ops` — AC-21 |
| T-32 | `test_applies_to_platform_case_insensitive_success` | unit | Rule with `applies_to.platform="Tuxedo"`; `repositories.platform="tuxedo"` → rule applied (case-insensitive match) — AC-06 |
| T-33 | `test_first_match_wins_on_equal_confidence` | unit | Two base-tier rules, both `confidence: 1.0`, match same function; Rule A first in YAML → Rule A annotation in result, Rule B excluded — AC-10 |
| T-34 | `test_co_occurrence_min_functions_not_met` | unit | 1 distinct function touches `GL_TRANS`; `min_functions=2` → empty `list[AnnotationResult]` — AC-04 |
| T-35 | `test_tenant_yaml_validation_failure_skips_file` | unit | Tenant YAML from artifact store missing `rule_id` field → WARN logged; file skipped; remaining valid rules applied to event; event NOT routed to DLQ — Error handling row 2, Contract 20 §7.1 |
| T-36 | `test_applies_to_db_query_failure_raises_ecle_base_error` | unit | `db.execute()` in `applies_to` pre-filter raises `DBConnectionError` → `ECLEBaseError` propagated; WorkerBase retries — Error handling row 3 |
| T-37 | `test_pattern_evaluation_exception_raises_permanent_error` | unit | Mock `re.fullmatch` raises `re.error` during evaluation → `PermanentWorkerError` raised; DLQ routing — Error handling row 4 |
| T-38 | `test_kafka_produce_failure_retries_safely` | unit | `producer.produce()` raises `KafkaException` in `mode="repo"` → `ECLEBaseError` raised; second call to `process()` re-runs upsert idempotently without error — Error handling row 8 |
| T-39 | `test_no_cross_worker_imports` | eval | Import graph of `ecle.workers.semantic_interpreter` inspected; zero imports from `ecle.workers.parse_repo`, `ecle.workers.persist_facts`, or any other worker module — AC-20, ADR-0027; enforced by `eval_async_coupling` CI gate |
| T-40 | `test_end_to_end_repo_trigger_cooccurrence` | integration | `ecle.repo.indexed` event consumed with 3 functions touching `GL_TRANS`; `semantic_annotations` rows written with `group="GL_TRANS"`; `ecle.facts.annotated` emitted with `annotation_count=3` — AC-03, AC-12 |
| T-41 | `test_end_to_end_applies_to_pre_filter_real_db` | integration | Real `repositories` row with `platform="Spring"`; rule has `applies_to.platform="Tuxedo"`; no `semantic_annotations` rows written — AC-05 |
| T-42 | `test_end_to_end_multi_tier_precedence` | integration | Base-tier rule and repo-tier rule both match same function; after full pipeline: `semantic_annotations` contains only repo-tier annotation for that `(target_id, rule_id)` pair — AC-08 |

Coverage targets (Contract 03 §Coverage):
- `rule_schema.py`: ≥ 95%
- `rule_loader.py`: ≥ 90%
- `evaluator.py`: ≥ 90%
- `worker.py`: ≥ 80%

All unit tests (`test_rule_schema.py`, `test_rule_loader.py`, `test_evaluator.py`,
`test_worker.py`) must be no-I/O, complete in < 100ms each, and be deterministic —
Contract 03 §Unit tests. External dependencies (`IStructuredDB`, `IArtifactStore`,
Kafka `Consumer`/`Producer`) are mocked/stubbed in all unit tests. Integration tests
use real backends.

---

## Out of scope

- Does NOT cover: Admin API endpoints `POST /admin/v1/semantic-rules/{tier}`,
  `GET /admin/v1/semantic-rules/{tier}`, `DELETE /admin/v1/semantic-rules/{tier}`
  (ADR-0020, ADR-0026 — Phase 6 Admin Portal spec).
- Does NOT cover: Scoped re-annotation event handling on rule file update (ADR-0034
  §Re-annotation strategy — re-annotation event trigger deferred to Phase 1 enhancement;
  SPEC number TBD; this worker processes `ecle.file.stored` and `ecle.repo.indexed` only).
- Does NOT cover: `--force-reannotate` Admin CLI flag (ADR-0034 §Re-annotation strategy —
  destructive full-corpus operation, Phase 6 scope).
- Does NOT cover: `search` and `display` rule evaluation at query time — `SearchRule` and
  `DisplayRule` models are validated by `RuleFile` at load time but NOT evaluated by
  `SemanticInterpreter`; search rule evaluation belongs to ADR-0018 `enrich` step
  (Phase 3 MCP query layer); display rule evaluation belongs to MCP result formatter.
- Does NOT cover: Phase 2 `batch_embed` worker which subscribes to `ecle.facts.annotated`
  — Phase 2 scope (Contract 17 §2).
- Does NOT cover: ADR-0025 domain ontology enrichment at cluster-centroid level — Phase 4
  scope; `domain_entity` field written by this worker enables the ADR-0018 Phase 3 lookup.
- Does NOT cover: DDL for `semantic_annotations` table — already declared in SPEC-0009
  migration `0001_phase1_schema` per ADR-0034. SQL schema file
  `constitution/schemas/semantic_annotations.sql` is deferred to the release-manager
  step; its absence does not block this spec.
- Does NOT cover: `function_calls` or `cluster_assignments` table reads — not required for
  rule-engine evaluation; any future need requires a new spec (Phase 3 topology scope).

---

## Deviations

None - implementation matches the approved specification behavior and acceptance criteria.
