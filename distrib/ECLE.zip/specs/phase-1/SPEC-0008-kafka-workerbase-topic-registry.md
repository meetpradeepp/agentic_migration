# SPEC-0008 — Kafka WorkerBase + Topic Registry

**Phase:** 1
**Status:** Implemented
**Implements:** ADR-0013, ADR-0027
**Depends on:** SPEC-0001, SPEC-0009

---

## Problem

Every Phase 1 worker (scan_source, parse_repo, persist_facts) has identical lifecycle
concerns: consumer setup, offset management, lifecycle polling, error classification,
DLQ routing, and idempotency enforcement. Without a shared base class these concerns
will be re-implemented per worker, creating divergent offset-commit behaviour, missing
lifecycle polling, and uneven DLQ coverage — all direct violations of Contract 09
mandatory rules.

All inter-worker communication must travel through Kafka topics declared centrally
(ADR-0013 §Topic naming). Without a `topic_registry.py`, topic strings are scattered
as literals across workers, preventing idempotent startup creation and enabling typos
that silently orphan events. This spec implements all mandatory rules of Contract 09
Event Pipeline Contract.

**FACT impact (Contract 04):** WorkerBase enforces `enable.auto.commit=False` and
post-write offset commit — guaranteeing exactly the re-delivery semantics that make
ingestion trustworthy. Lifecycle polling (running|paused|draining) means operators can
pause a misbehaving worker without data loss, preserving completeness. Topic registry
centralises DLQ addresses, making gaps observable (fast).

---

## Decision

Two deliverables — no DDL, no concrete workers:

| Module | Path | Provides |
|--------|------|---------|
| `base` | `src/ecle/workers/base.py` | `WorkerBase` ABC + `PermanentWorkerError` |
| `topic_registry` | `src/ecle/events/topic_registry.py` | Phase 1 topic constants, `PHASE_1_TOPICS`, `dlq_topic()`, `consumer_group()`, `ensure_topics()` |

`Settings` gains 4 new fields (added to `src/ecle/config.py` — amends SPEC-0001). No
other files from SPEC-0001 are modified.

`worker_lifecycle` table DDL is defined in SPEC-0009; WorkerBase reads it via
`IStructuredDB` (SPEC-0001). WorkerBase is not responsible for creating the table.

---

## Interface contract

```python
# src/ecle/core/exceptions.py  — amends SPEC-0001 hierarchy
class PermanentWorkerError(ECLEBaseError): ...  # route to DLQ immediately; no retry

# src/ecle/workers/base.py  (from __future__ import annotations — Contract 01 §2)
class WorkerBase(ABC):
    def __init__(self, consumer: Consumer, producer: Producer, db: IStructuredDB, settings: Settings) -> None: ...

    @property
    @abstractmethod
    def worker_name(self) -> str: ...              # e.g. "parse_repo"

    @property
    @abstractmethod
    def input_topic(self) -> str: ...              # e.g. TOPIC_REPO_DETECTED

    @abstractmethod
    def process(self, event: dict[str, Any]) -> None: ...
    # MUST be idempotent. Raises ECLEBaseError (transient) or PermanentWorkerError (permanent).

    def run(self) -> None: ...                     # main loop; blocks; handles lifecycle + DLQ
    def _check_lifecycle(self) -> str: ...         # returns "running"|"paused"|"draining" (translated from DB values run|pause|drain; see Behaviour step 14)
    def close(self) -> None: ...                   # commit pending offset, close consumer + producer

# src/ecle/events/topic_registry.py  (from __future__ import annotations — Contract 01 §2)

# Phase 1 topic constants (ADR-0013 §Topic naming: ecle.{event_type})
TOPIC_SOURCE_RECEIVED          = "ecle.source.received"
TOPIC_REPO_DETECTED            = "ecle.repo.detected"
TOPIC_REPO_STRUCTURAL_COMPLETE = "ecle.repo.structural_complete"
TOPIC_FILE_IR_PRODUCED         = "ecle.file.ir_produced"
TOPIC_REPO_IR_PRODUCED         = "ecle.repo.ir_produced"
TOPIC_SOURCE_SCANNED           = "ecle.source.scanned"
TOPIC_FILE_STORED              = "ecle.file.stored"
TOPIC_REPO_INDEXED             = "ecle.repo.indexed"
TOPIC_DOCUMENT_STORED          = "ecle.document.stored"

PHASE_1_TOPICS: list[str] = [...]  # all nine strings above

def dlq_topic(event_topic: str) -> str: ...
# "ecle.file.ir_produced" → "ecle.dlq.file.ir_produced"  (DLQ_TOPIC_PREFIX from constants.py)

def consumer_group(worker_name: str) -> str: ...
# "parse_repo" → "ecle.parse_repo"  (CONSUMER_GROUP_PREFIX from constants.py)

def ensure_topics(
    admin: AdminClient,
    topics: list[str],
    *,
    num_partitions: int = 1,
    replication_factor: int = 1,
) -> None: ...
# Idempotent — skips topics that already exist. Raises on broker connection failure.
```

**Settings additions** (`src/ecle/config.py` — extends table from SPEC-0001):

| Field | Default | Contract ref |
|-------|---------|-------------|
| `KAFKA_POLL_TIMEOUT_MS` | `1000` | ADR-0013 |
| `KAFKA_MAX_POLL_RECORDS` | `500` | ADR-0013 |
| `KAFKA_DLQ_MAX_RETRIES` | `3` | Contract 09 §1 |
| `KAFKA_PRODUCER_LINGER_MS` | `5` | ADR-0013 §Producer config |

---

## Behaviour

**WorkerBase.run() loop:**

1. `consumer.subscribe([self.input_topic])` on entry.
2. `msg = consumer.poll(settings.KAFKA_POLL_TIMEOUT_MS / 1000)` — if `None` (timeout), continue.
3. Decode `msg.value()` as UTF-8 JSON → `event: dict[str, Any]`. JSON decode failure →
   `PermanentWorkerError` → step 8 (DLQ, no retry).
4. Call `_check_lifecycle()` → returns `"running" | "paused" | "draining"` (translated from DB values — see step 14).
   - `"paused"`: sleep 1 s, `continue` — do NOT call `process()`, do NOT commit offset.
   - `"draining"`: check consumer group lag via `consumer.assignment()`; if lag == 0 set
     internal `_draining_done = True` and stop consuming new messages (behave as paused).
   - `"running"`: proceed.
5. Call `self.process(event)`. On success → step 6. On `ECLEBaseError` (transient) → step 7.
   On `PermanentWorkerError` → step 8.
6. Commit offset: `consumer.commit(msg, asynchronous=False)`. Log DEBUG. Continue loop.
7. **Transient retry:** increment `_retry_count`. If `_retry_count < settings.KAFKA_DLQ_MAX_RETRIES`:
   sleep `min(2 ** _retry_count, 30)` seconds, `continue` (same message redelivered from loop
   since offset was never committed). If `_retry_count >= settings.KAFKA_DLQ_MAX_RETRIES`: route
   to DLQ (step 8).
8. **DLQ route:** produce error envelope to `dlq_topic(msg.topic())` (see DLQ envelope below),
   call `producer.flush()`, then commit offset (`consumer.commit(msg, asynchronous=False)`).
   Reset `_retry_count = 0`. Log ERROR with `X-Request-Id`, error type, original topic.
9. `close()`: commit any uncommitted offset, `consumer.close()`, `producer.flush()`.

**DLQ envelope** (JSON payload produced to DLQ topic — Contract 16: every event payload carries `X-Request-Id` and `X-Trace-Id`):
```
{
  "X-Request-Id": str,       # propagated from original event headers
  "X-Trace-Id": str,         # propagated from original event headers
  "original_topic": str,
  "original_payload": dict,
  "error_type": str,         # exception class name
  "error_message": str,
  "worker_name": str,
  "retry_count": int,
  "failed_at": ISO-8601 str
}
```

**`_check_lifecycle()` — 30 s TTL cache (ADR-0027 §Rule 4):**

10. If `_lifecycle_cache` is set and `time.monotonic() - _lifecycle_checked_at < WORKER_LIFECYCLE_TTL_SECONDS`:
    return cached value.
11. Query `worker_lifecycle` table:
    `db.execute("SELECT command FROM worker_lifecycle WHERE worker_name = %s", [self.worker_name], tenant_id="__system__")`.
    Note: `worker_lifecycle` has no `tenant_id` column; SPEC-0009 must document that `PostgreSQLStructuredDB.execute()` skips the tenant filter when `tenant_id="__system__"`.
12. If row missing: log WARNING, return `"running"` (safe default — Contract 15 §worker_lifecycle).
13. If `command == "reset_offset"`: log CRITICAL — this command is Admin-only and must not be
    processed by a running worker; return `"running"`.
14. Translate DB command to state string: `"run"` → `"running"`, `"pause"` → `"paused"`, `"drain"` → `"draining"`. Update `_lifecycle_cache` and `_lifecycle_checked_at`. Return translated state string.

**`ensure_topics()` (called from worker `__main__.py` at startup — not by WorkerBase.run()):**

15. For each topic in `topics`: call `AdminClient.create_topics([NewTopic(topic, ...)])`.
    Ignore `TopicAlreadyExistsException`. Raise on any other error.

**Kafka producer config** (ADR-0013 §Producer config — assembled by subclass or factory):
```
enable.idempotence = True
acks               = all
retries            = 5
retry.backoff.ms   = 200
compression.type   = lz4
linger.ms          = settings.KAFKA_PRODUCER_LINGER_MS
```

**Kafka consumer config** (ADR-0013 §Consumer config — assembled by subclass or factory):
```
enable.auto.commit = False
max.poll.records   = settings.KAFKA_MAX_POLL_RECORDS
group.id           = consumer_group(worker_name)
```

---

## Acceptance criteria

| ID | Given | Input | Expected |
|----|-------|-------|---------|
| AC-01 | WorkerBase subclass, lifecycle=running | `run()` called | `consumer.poll()` called in continuous loop |
| AC-02 | `process()` returns without error | Kafka message | Offset committed exactly once, after `process()` returns; not before |
| AC-03 | Consumer config inspected | Worker initialized | `enable.auto.commit == False` |
| AC-04 | `process()` raises `ECLEBaseError`, retry_count < `KAFKA_DLQ_MAX_RETRIES` | Kafka message | Offset NOT committed; message retried after exponential back-off sleep |
| AC-05 | `process()` raises `ECLEBaseError`, retry_count == `KAFKA_DLQ_MAX_RETRIES` | Kafka message | DLQ envelope produced to `ecle.dlq.{topic}`; producer flushed; offset committed; retry_count reset |
| AC-06 | `process()` raises `PermanentWorkerError` | Kafka message | DLQ envelope produced immediately; no retry; producer flushed; offset committed |
| AC-07 | JSON decode fails on `msg.value()` | Malformed payload | Treated as `PermanentWorkerError`; routed to DLQ; offset committed |
| AC-08 | `worker_lifecycle.command = "pause"` | `_check_lifecycle()` returns "paused" | `process()` NOT called; offset NOT committed; loop sleeps 1 s |
| AC-09 | `worker_lifecycle.command = "drain"`, consumer lag = 0 | Next lifecycle check | Worker stops consuming; behaves as paused; in-flight message completes first |
| AC-10 | `worker_lifecycle` row missing | `_check_lifecycle()` called | Returns `"running"` with WARNING log; no crash |
| AC-11 | `_check_lifecycle()` called twice within 30 s | — | Exactly 1 DB query; cached result returned on second call |
| AC-12 | `_check_lifecycle()` called after 30 s elapsed | — | New DB query issued; cache refreshed |
| AC-13 | `dlq_topic("ecle.file.ir_produced")` | — | Returns `"ecle.dlq.file.ir_produced"` |
| AC-14 | `consumer_group("parse_repo")` | — | Returns `"ecle.parse_repo"` |
| AC-15 | `ensure_topics()` called; all topics already exist | AdminClient connected | No error; returns normally |
| AC-16 | `ensure_topics()` called; one topic missing | AdminClient connected | Missing topic created; existing topics unaffected |
| AC-17 | All 9 Phase 1 topic constants | `PHASE_1_TOPICS` | All 9 strings present; no duplicates |
| AC-18 | Worker subclass imports another worker module | `eval_async_coupling` | Eval fails; merge blocked (Contract 09 §0) |

---

## Error handling

| Error | Classification | Handling |
|-------|---------------|---------|
| `ECLEBaseError` from `process()` | Transient | Retry with exponential back-off; DLQ after `KAFKA_DLQ_MAX_RETRIES` |
| `PermanentWorkerError` from `process()` | Permanent | DLQ immediately; no retry |
| JSON decode failure | Permanent | DLQ immediately |
| DB error in `_check_lifecycle()` | Non-fatal | Log WARNING; treat lifecycle as `"running"` |
| Producer error in `_route_to_dlq()` | Critical | Log CRITICAL; skip offset commit (message redelivered on restart) |
| `consumer.poll()` error | Recoverable | Log ERROR; continue loop (consumer self-heals on next poll) |
| `ensure_topics()` broker error | Fatal (startup) | Raise; process exits; do not start consuming |

All exceptions are chained (`raise X(...) from exc` — Contract 01 §4). No bare `except:`.

---

## Tests required

```
tests/unit/test_worker_base.py:
  test_run_commits_offset_after_process
  test_run_does_not_commit_offset_before_process
  test_run_retries_transient_error_without_committing_offset  # AC-04
  test_run_routes_to_dlq_after_max_transient_retries          # AC-05
  test_run_routes_permanent_error_to_dlq_immediately          # AC-06
  test_run_routes_json_decode_error_to_dlq                    # AC-07
  test_run_paused_lifecycle_skips_process                     # AC-08
  test_run_draining_zero_lag_transitions_to_paused            # AC-09
  test_missing_lifecycle_row_returns_running                  # AC-10
  test_lifecycle_cache_prevents_duplicate_db_calls            # AC-11
  test_lifecycle_cache_expires_after_ttl                      # AC-12
  test_auto_commit_is_false                                   # AC-03
  test_dlq_envelope_contains_required_fields                  # incl. X-Request-Id + X-Trace-Id
  test_producer_flush_called_before_offset_commit_on_dlq
  test_lifecycle_db_error_returns_running_with_warning        # Error table: DB error in _check_lifecycle()
  test_dlq_producer_error_logs_critical_skips_offset_commit   # Error table: Producer error in _route_to_dlq()
  test_consumer_poll_error_logs_and_continues                 # Error table: consumer.poll() error

tests/unit/test_topic_registry.py:
  test_dlq_topic_format                                       # AC-13
  test_consumer_group_format                                  # AC-14
  test_ensure_topics_idempotent_on_existing                   # AC-15
  test_ensure_topics_creates_missing_topic                    # AC-16
  test_phase1_topics_all_present_no_duplicates                # AC-17
  test_ensure_topics_raises_on_broker_error                   # Error table: ensure_topics() broker error

tests/integration/test_worker_base_integration.py:
  test_worker_processes_event_end_to_end                      # real Kafka + mock process()
  test_worker_respects_pause_command                          # real Kafka + real DB lifecycle table
```

All test files carry `# Implements: SPEC-0008` header (Contract 02).

**Coverage targets (Contract 03):**
- `src/ecle/workers/base.py`: ≥ 80% line coverage
- `src/ecle/events/topic_registry.py`: ≥ 95% line coverage (interface module)
- Unit tests: no I/O, deterministic, < 100 ms per test.

---

## Out of scope

| Item | Owning spec |
|------|------------|
| `scan_source` worker implementation | SPEC-0004 |
| `parse_repo` worker implementation | SPEC-0005 |
| `persist_facts` worker implementation | SPEC-0006 |
| `worker_lifecycle` table DDL + Alembic migration | SPEC-0009 |
| KEDA `ScaledObject` manifests | Phase 6 (ADR-0027 §Rule 3) |
| Celery Beat (`sweep_coordinator`) integration | Phase 1+ (SPEC-0007+) |
| Worker `GET /metrics` Prometheus endpoint | Phase 6 (Contract 16) |
| Topics for Phase 2+ workers | Phase 2+ (Contract 17) |

---

## Deviations

DEV-0008-001: Integration harness hardening was applied for deterministic real-Kafka execution on local Windows environments.

- Integration tests use unique consumer-group IDs per run and `auto.offset.reset="earliest"` to avoid stale committed offsets across reruns.
- Worker thread startup/teardown sequencing was tightened (`worker.close()` + bounded `thread.join(...)`) to prevent intermittent thread shutdown races.
- These are test-harness and lifecycle-safety adjustments only; WorkerBase interface, DLQ contract, and topic contract behavior remain unchanged.
