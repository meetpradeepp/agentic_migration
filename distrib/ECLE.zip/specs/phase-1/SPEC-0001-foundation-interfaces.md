# SPEC-0001 — Foundation Interfaces

**Phase:** 1
**Status:** Approved
**Implements:** ADR-0007, ADR-0027, ADR-0028
**Depends on:** None

---

## Problem

ECLE 2.0's event-driven pipeline consists of independently deployable Kafka consumer
workers that must never import each other's modules (ADR-0027). Without shared
backend-agnostic protocol contracts, workers would couple to specific backend
implementations (Contract 10, A6: Hardcoded backend reference), embed magic numbers
(Contract 01 §6 violation), and break tier-transparent deployment (Contract 14 §2).

This spec establishes the five foundational abstractions that every Phase 1 component
depends on:

1. `IStructuredDB` — parameterised, tenant-isolated, `is_current`-filtered DB access
   (Contract 15 §1)
2. `IArtifactStore` — backend-agnostic artifact I/O as required by Contract 14 §4 and
   ADR-0007; no `open()` or `Path.read_bytes()` ever in worker code
3. `ILanguagePack` — language extraction protocol every pack must implement (Contract 08)
4. `ecle.config.Settings` — all tuneable configuration in one Pydantic `BaseSettings`
   subclass (Contract 01 §6, Contract 14 §3)
5. `ecle/constants.py` — fixed non-configurable values that are architectural invariants

No Phase 1 worker may be written without these foundations in place. They form the
shared library layer that every worker imports without coupling workers to each other.

`ILanguagePack` is included here (rather than in SPEC-0002) because it is a foundational
protocol that must exist before any language pack — including the DefaultPack (SPEC-0002)
— can be written. Its inclusion is mandated by Contract 08 §4, which specifies the exact
interface signature; this is an implicit expansion of the Contract 17 §1 SPEC-0001 row.

**FACT impact (Contract 04):** These interfaces have no direct query surface; they underpin
FACT compliance by enforcing parameterised SQL (trustworthy), `is_current` filtering
(accurate), tenant isolation (complete), and factory-level connection reuse (fast).

---

## Decision

Five pure-library modules (no Kafka, no workers, no DDL):

| Module | Path | Provides |
|--------|------|---------|
| `interfaces` | `src/ecle/core/interfaces.py` | `IStructuredDB`, `IArtifactStore`, `ILanguagePack`, `IVectorStore` (stub), `ITopologyGraph` (stub) |
| `backends` | `src/ecle/core/backends.py` | `get_structured_db()`, `get_artifact_store()`, `get_vector_store()`, `get_topology_graph()` |
| `exceptions` | `src/ecle/core/exceptions.py` | `ECLEBaseError` hierarchy |
| `config` | `src/ecle/config.py` | `Settings` (`BaseSettings`); module-level `settings` singleton |
| `constants` | `src/ecle/constants.py` | Fixed architectural invariants |

`IVectorStore` and `ITopologyGraph` are **protocol stubs only** — signatures defined here; concrete implementations deferred to Phase 2 and Phase 3 (Contract 17 §1 lists all five interfaces as SPEC-0001 deliverables).

---

## Interface contract

```python
# src/ecle/core/exceptions.py  (from __future__ import annotations — Contract 01 §2)
class ECLEBaseError(Exception): ...
class ArtifactNotFoundError(ECLEBaseError):
    def __init__(self, path: str) -> None: ...  # self.path = path; str(e) = "Artifact not found: {path}"
class InvalidLanguagePackError(ECLEBaseError): ...
class DBConnectionError(ECLEBaseError): ...
class InvalidConfigError(ECLEBaseError): ...

# src/ecle/core/interfaces.py  (from __future__ import annotations — Contract 01 §2)
DetectedLayer = dict[str, Any]  # Phase 1 type alias; refined in Phase 2

class IStructuredDB(ABC):
    def execute(self, sql: str, params: Sequence[Any] | dict[str, Any], *, tenant_id: str) -> list[dict[str, Any]]: ...
    def upsert(self, table: str, row: dict[str, Any], *, conflict_keys: Sequence[str], tenant_id: str) -> None: ...
    def close(self) -> None: ...

class IArtifactStore(ABC):  # Contract 14 §4 — exact signature match required
    def write(self, path: str, data: bytes) -> None: ...
    def read(self, path: str) -> bytes: ...          # raises ArtifactNotFoundError(path) from exc
    def exists(self, path: str) -> bool: ...
    def delete(self, path: str) -> None: ...         # idempotent; no-op if absent

class ILanguagePack(ABC):  # Contract 08 §4 — exact signature match required
    @property
    def language_id(self) -> str: ...
    def sanitize(self, source_bytes: bytes) -> bytes: ...
    def extract(
        self,
        tree_or_bytes: Any,
        source_bytes: bytes,
        file_path: Path,
        language_dir: Path,
        detected_layers: list[DetectedLayer] | None = None,  # Contract 10: no mutable default
    ) -> dict[str, Any]: ...
    # extract() MUST NEVER raise — internal errors → result["extraction_errors"]
    # Contract 08 §4 canonical type signature is `= []`; ABC uses `None` to comply with
    # Contract 10. Implementations guard: `if detected_layers is None: detected_layers = []`

class IVectorStore(ABC):  # stub — Phase 2 concrete impl
    def search(self, collection: str, query_vector: list[float], limit: int, *, tenant_id: str) -> list[dict[str, Any]]: ...
    def upsert(self, collection: str, vectors: list[dict[str, Any]], *, tenant_id: str) -> None: ...
    def close(self) -> None: ...

class ITopologyGraph(ABC):  # stub — Phase 3 concrete impl
    def query(self, cypher: str, params: dict[str, Any], *, tenant_id: str) -> list[dict[str, Any]]: ...
    def merge_node(self, label: str, identity: dict[str, Any], properties: dict[str, Any], *, tenant_id: str) -> None: ...
    def close(self) -> None: ...

# src/ecle/core/backends.py  (from __future__ import annotations — Contract 01 §2)
def get_structured_db() -> IStructuredDB: ...    # reads STRUCTURED_BACKEND; Phase 1: postgresql only
def get_artifact_store() -> IArtifactStore: ...  # reads ARTIFACT_BACKEND: local | s3 | azure | nfs
def get_vector_store() -> IVectorStore: ...      # raises NotImplementedError in Phase 1
def get_topology_graph() -> ITopologyGraph: ...  # raises NotImplementedError in Phase 1
```

**Settings** (`src/ecle/config.py` — Pydantic `BaseSettings`; singleton: `from ecle.config import settings`):

| Field | Default | Contract ref |
|-------|---------|-------------|
| `ECLE_TIER` | `"dev"` | Contract 14 §1 |
| `ECLE_DATA_ROOT` | `"./ecle-data"` | ADR-0028 |
| `ECLE_LOG_DIR` | `"./ecle-logs"` | ADR-0028 |
| `ECLE_CONFIG_PATH` | `"./ecle-data/config/ecle.yaml"` | ADR-0028 |
| `ECLE_LOG_CONFIG_PATH` | `"./ecle-data/config/logging.yaml"` | ADR-0028 |
| `STRUCTURED_BACKEND` | `"postgresql"` | Contract 14 §3 |
| `STRUCTURED_BACKEND_URL` | `""` (required; set via env var — Contract 01 §9) | Contract 14 §3 |
| `DATABASE_URL` | `""` (required; set via env var — Contract 01 §9) | Contract 14 §3 |
| `VECTOR_BACKEND` | `"qdrant"` | Contract 14 §3 |
| `VECTOR_BACKEND_URL` | `"http://localhost:6333"` | Contract 14 §3 |
| `TOPOLOGY_BACKEND` | `"neo4j"` | Contract 14 §3 |
| `TOPOLOGY_BACKEND_URL` | `"bolt://localhost:7687"` | Contract 14 §3 |
| `ARTIFACT_BACKEND` | `"local"` | Contract 14 §3 |
| `ARTIFACT_STORE_PATH` | `"./ecle-data/repos"` | ADR-0028 |
| `LANGUAGE_PACKS_PATH` | `"./ecle-data/language_packs"` | Contract 14 §3 |
| `ECLE_MODELS_PATH` | `"./ecle-data/models"` | Contract 14 §3 |
| `KAFKA_BOOTSTRAP_SERVERS` | `"localhost:9092"` | ADR-0013 |
| `LOG_LEVEL` | `"INFO"` | Contract 16 |

**Constants** (`src/ecle/constants.py` — not env-var overridable):

```
ARTIFACT_PATH_TEMPLATE       = "{tenant_id}/{repo_id}/{file_rel_path}.facts.json"  # ADR-0007 §2
FIDELITY_FULL / PARTIAL / HEURISTIC  = "FULL" / "PARTIAL" / "HEURISTIC"
FIDELITY_CEILING             = {FULL: 1.0, PARTIAL: 0.8, HEURISTIC: 0.6}           # Contract 05 §2
FIDELITY_FALLBACK_CEILING    = 0.5    # DefaultPack + used_fallback=True            # Contract 05 §2
CONSUMER_GROUP_PREFIX        = "ecle."
DLQ_TOPIC_PREFIX             = "ecle.dlq."
WORKER_LIFECYCLE_TTL_SECONDS = 30     # int                                         # ADR-0027
LOUVAIN_MIN_CLUSTER_SIZE     = 2      # int                                         # ADR-0011
```




---

## Behaviour

### `IStructuredDB` lifecycle

1. Worker obtains an `IStructuredDB` instance by calling `get_structured_db()` (stub
   signature defined in this spec / `backends.py`; concrete backend-switching logic in
   SPEC-0009) at module level — one instance per worker process (Contract 14
   §6 singleton pattern).
2. Worker calls `db.execute(sql, params, tenant_id=tenant_id)`. The `sql` argument is a
   literal string with named placeholders (`:col` or `%(col)s`). The `params` argument
   binds all variable values. f-string or concatenated SQL is banned (Contract 01 §7,
   Anti-pattern A10).
3. The concrete implementation automatically scopes `execute()` to `tenant_id` by adding
   `AND tenant_id = :tenant_id` to the WHERE clause for fact table queries, ensuring
   cross-tenant data is never returned.
4. For fact tables (`file_facts`, `function_facts`, etc.), `execute()` adds
   `AND is_current = true` unless the caller has explicitly included an `is_current`
   predicate in `sql` (Contract 15 §1).
5. Worker calls `db.upsert(table, row, conflict_keys=[...], tenant_id=tenant_id)` to
   write a new fact version. The implementation:
   a. Issues a parameterised `UPDATE` setting `is_current = false, superseded_at = NOW()`
      on any existing row matching `conflict_keys + tenant_id`.
   b. Issues a parameterised `INSERT` for the new row with `is_current = true`.
   Both steps are wrapped in a single DB transaction. On constraint violation from a
   concurrent writer, the upsert retries once before raising `DBConnectionError`.
6. The factory (SPEC-0009) caches the `IStructuredDB` connection for the process lifetime
   per Contract 14 §6. Callers do not call `db.close()` mid-request; connection teardown
   is managed by process shutdown hooks defined in SPEC-0009.

### `IArtifactStore` lifecycle

7. Worker obtains an `IArtifactStore` instance by calling `get_artifact_store()` (stub
   signature defined in this spec / `backends.py`; concrete backend-switching logic in
   SPEC-0009) at module level. Backend is selected from `settings.ARTIFACT_BACKEND`.
8. `parse_repo` (SPEC-0005) constructs the artifact path using `ARTIFACT_PATH_TEMPLATE`
   from `ecle.constants` and calls `store.write(path, data)` with JSON-encoded facts bytes.
   This is the ONLY place an artifact is written for a given file version.
9. Downstream workers (`persist_facts`, `build_graph`) call `store.read(path)` using the
   `artifact_path` from the `file.ir_produced` event payload (ADR-0007 §2, Contract 09 §3).
10. If the artifact is absent (race, deletion, or path mismatch), `read()` raises
    `ArtifactNotFoundError`. The calling worker routes the event to the DLQ topic
    `ecle.dlq.file.ir_produced` — it does not retry indefinitely.
11. `store.exists(path)` is available for pre-flight checks (e.g. idempotency guard before
    writing) without incurring a `read()` + exception path.
12. `store.delete(path)` is called by the data-lifecycle worker (future phase) during
    purge operations. It is a no-op if the artifact is already absent.

### `ILanguagePack` lifecycle

13. `LanguagePackRegistry` (SPEC-0002) loads all packs from `settings.LANGUAGE_PACKS_PATH`
    at startup. For each pack, it verifies the module exports a class implementing
    `ILanguagePack`; if not, raises `InvalidLanguagePackError`.
14. `parse_repo` (SPEC-0005) calls `pack.sanitize(source_bytes)` on raw file bytes before
    parsing. The result is passed to the tree-sitter parser and then to `pack.extract()`.
15. `pack.extract(tree, sanitized_bytes, file_path)` runs the full extraction. Any
    exception raised internally is caught by the pack implementation and added to
    `result["extraction_errors"]` as a dict: `{"type": "ExceptionClassName", "msg": str(e)}`.
    The method returns normally in all cases (Contract 08 §3).
16. Callers inspect `result["extraction_errors"]` to determine whether extraction was
    complete or degraded. A non-empty list triggers `fidelity = FIDELITY_HEURISTIC` in
    the `file.ir_produced` event (ADR-0016, Contract 05 §2).

### `ecle.config.Settings` lifecycle

17. `settings = Settings()` is evaluated once at import time in `src/ecle/config.py`.
    Pydantic reads env vars and the optional `.env` file. If validation fails (missing
    required var or type mismatch), `pydantic_settings.ValidationError` is raised before
    any worker logic runs.
18. Every worker, factory, and library module that needs configuration imports the
    singleton: `from ecle.config import settings`. No module calls `os.environ` or
    `os.getenv` directly.
19. `settings` is effectively immutable after import. No worker modifies its attributes.

### `ecle/constants.py` lifecycle

20. Constants are imported where needed: `from ecle.constants import FIDELITY_CEILING`.
    They are never assigned or overridden at runtime.
21. When a new architectural constant is needed (e.g. a new fidelity tier), it is added
    here via a spec amendment — never hardcoded inline in a worker.

---

## Acceptance criteria

| ID | Given | Input | Expected |
|----|-------|-------|----------|
| AC-1 | `IStructuredDB` imported; no subclass | `IStructuredDB()` | `TypeError` raised |
| AC-2 | Stub `IStructuredDB` subclass that records call args | `db.execute("SELECT...", {"r": "R1"}, tenant_id="T1")` | Stub records `tenant_id="T1"`; param is present and non-empty |
| AC-3 | Stub with in-memory store; row `(main.py, R1, T1, is_current=True)` exists | `db.upsert("file_facts", {...}, conflict_keys=["file_path","repo_id"], tenant_id="T1")` called twice | Exactly one `is_current=True` row after both calls; prior row now `is_current=False` |
| AC-4 | `IArtifactStore` imported; no subclass | `IArtifactStore()` | `TypeError` raised |
| AC-5 | In-memory stub `IArtifactStore` | `store.write("t1/r1/main.py.facts.json", b'{...}')` then `store.read(same path)` | `read()` returns the exact bytes written |
| AC-6 | In-memory stub; no artifact at path | `store.read("t1/r1/ghost.facts.json")` | `ArtifactNotFoundError` raised; `.path == "t1/r1/ghost.facts.json"` |
| AC-7 | In-memory stub | `store.exists(path)` → `store.write(path, b"x")` → `store.exists(path)` | `False`, then `True` |
| AC-8 | In-memory stub; no artifact at path | `store.delete(path)` called twice | No exception; `store.exists(path)` returns `False` |
| AC-9 | `ILanguagePack` imported; no subclass | `ILanguagePack()` | `TypeError` raised |
| AC-10 | Stub `ILanguagePack` whose `extract()` internally raises `KeyError("missing_node")` | `pack.extract(None, b"broken", Path("bad.py"), Path("."))` | Returns `dict`; `result["extraction_errors"]` non-empty with `{"type":"KeyError","msg":"missing_node"}`; no exception |
| AC-11 | Stub `ILanguagePack` that succeeds | `pack.extract(mock_tree, b"print('hi')", Path("hello.py"), Path("."))` | `dict` contains `"file_path": "hello.py"` and `"extraction_errors": []` |
| AC-12 | Stub `ILanguagePack` with working `sanitize()` | `pack.sanitize(b'\xef\xbb\xbf# coding\n')` | `b'# coding\n'` (UTF-8 BOM removed) |
| AC-13 | Clean environment; no ECLE_* vars set | `Settings()` | `ECLE_TIER=="dev"`, `ARTIFACT_BACKEND=="local"`, `KAFKA_BOOTSTRAP_SERVERS=="localhost:9092"`, `LOG_LEVEL=="INFO"` |
| AC-14 | `ARTIFACT_BACKEND=s3` in environment | `Settings()` | `s.ARTIFACT_BACKEND == "s3"`; all other fields retain defaults |
| AC-15 | `from ecle.constants import ARTIFACT_PATH_TEMPLATE` | `ARTIFACT_PATH_TEMPLATE.format(tenant_id="acme", repo_id="backend", file_rel_path="src/api/handler.py")` | `"acme/backend/src/api/handler.py.facts.json"` |
| AC-16 | `FIDELITY_CEILING`, `FIDELITY_FULL/PARTIAL/HEURISTIC` imported | `FIDELITY_CEILING[FIDELITY_FULL]`, `[FIDELITY_PARTIAL]`, `[FIDELITY_HEURISTIC]` | `1.0`, `0.8`, `0.6` respectively |
| AC-17 | `from ecle.core.exceptions import ArtifactNotFoundError` | `e = ArtifactNotFoundError("t1/r1/x.facts.json")` | `e.path == "t1/r1/x.facts.json"`; `str(e) == "Artifact not found: t1/r1/x.facts.json"` |
| AC-18 | All four custom exception classes imported | `issubclass(ArtifactNotFoundError, ECLEBaseError)` etc. | All four return `True` |
| AC-19 | `IVectorStore` imported; no subclass | `IVectorStore()` | `TypeError` raised |
| AC-20 | `ITopologyGraph` imported; no subclass | `ITopologyGraph()` | `TypeError` raised |
| AC-21 | `get_structured_db, get_artifact_store, get_vector_store, get_topology_graph` imported | `callable(get_structured_db)` etc. | `True` for all four |

---

## Error handling

| Error condition | Classification | Response | Event emitted |
|----------------|---------------|----------|---------------|
| `IArtifactStore.read()` — artifact absent at path | permanent | Raise `ArtifactNotFoundError(path) from exc`. Caller routes event to DLQ (`ecle.dlq.file.ir_produced`). | None (caller decides) |
| `IArtifactStore.write()` — backend storage unavailable (disk full, S3 503) | transient | Raise `OSError` or backend-specific exception (not wrapped here — left to concrete impl). Worker redelivers via Kafka uncommitted offset. | None (Kafka redelivery) |
| `IStructuredDB.execute()` — connection lost mid-query | transient | Raise `DBConnectionError` chained from driver exception (`from exc`). Worker allows event to redeliver via uncommitted offset. | None (Kafka redelivery) |
| `IStructuredDB.execute()` — connection refused at startup | transient | Raise `DBConnectionError`. Worker process exits; supervisor/K8s restarts it. | None |
| `IStructuredDB.upsert()` — constraint violation after one retry | transient | Raise `DBConnectionError`. Kafka uncommitted offset triggers redelivery. | None |
| `ILanguagePack.extract()` — any internal exception | permanent (captured) | Implementation catches internally; appends `{"type": exc_class, "msg": str(e)}` to `extraction_errors`; returns partial dict. Never re-raises. | None (caller inspects `extraction_errors`) |
| `ILanguagePack.sanitize()` — `UnicodeDecodeError` | permanent | Raise `UnicodeDecodeError`. Caller (`parse_repo`) converts to an `extraction_errors` entry and sets `fidelity = FIDELITY_HEURISTIC`. | None |
| `Settings` validation — type mismatch or missing required var | permanent | `pydantic_settings.ValidationError` raised at import time; caller (worker entry point) wraps and re-raises as `InvalidConfigError`. Worker exits immediately. | None |
| `constants` import — module not found | permanent | `ModuleNotFoundError` — infrastructure issue; deployment error. | None |

---

## Tests required

File: `tests/unit/test_interfaces.py`
File: `tests/unit/test_config.py`
File: `tests/unit/test_constants.py`
File: `tests/unit/test_backends.py`

| Test ID | Test function | File | Type | Verifies |
|---------|--------------|------|------|----------|
| T-01 | `test_istructureddb_is_abstract` | `test_interfaces.py` | unit | AC-1: `IStructuredDB()` raises `TypeError` |
| T-02 | `test_istructureddb_concrete_subclass_instantiates` | `test_interfaces.py` | unit | AC-1: Concrete subclass with all methods can be instantiated |
| T-03 | `test_istructureddb_execute_receives_tenant_id` | `test_interfaces.py` | unit | AC-2: stub records `tenant_id` kwarg on `execute()` call |
| T-04 | `test_istructureddb_upsert_idempotent_sets_is_current` | `test_interfaces.py` | unit | AC-3: in-memory stub; second upsert flips old row to `is_current=False` |
| T-05 | `test_iartifactstore_is_abstract` | `test_interfaces.py` | unit | AC-4: `IArtifactStore()` raises `TypeError` |
| T-06 | `test_artifact_store_write_read_roundtrip` | `test_interfaces.py` | unit | AC-5: in-memory stub; `read()` returns exactly what was written |
| T-07 | `test_artifact_store_read_missing_raises_artifact_not_found` | `test_interfaces.py` | unit | AC-6: `ArtifactNotFoundError` raised with correct `path` |
| T-08 | `test_artifact_store_exists_false_before_write` | `test_interfaces.py` | unit | AC-7: `exists()` returns `False` for absent path |
| T-09 | `test_artifact_store_exists_true_after_write` | `test_interfaces.py` | unit | AC-7: `exists()` returns `True` after `write()` |
| T-10 | `test_artifact_store_delete_idempotent_no_exception` | `test_interfaces.py` | unit | AC-8: `delete()` on absent path does not raise |
| T-11 | `test_artifact_store_delete_removes_artifact` | `test_interfaces.py` | unit | AC-8: after `delete()`, `exists()` returns `False` |
| T-12 | `test_ilanguagepack_is_abstract` | `test_interfaces.py` | unit | AC-9: `ILanguagePack()` raises `TypeError` |
| T-13 | `test_language_pack_extract_never_raises` | `test_interfaces.py` | unit | AC-10: stub that raises internally; no exception escapes |
| T-14 | `test_language_pack_extract_populates_extraction_errors` | `test_interfaces.py` | unit | AC-10: `extraction_errors` list is non-empty; entry has `type` and `msg` keys |
| T-15 | `test_language_pack_extract_always_has_extraction_errors_key` | `test_interfaces.py` | unit | AC-11: successful `extract()` still returns `extraction_errors: []` |
| T-16 | `test_language_pack_extract_always_has_file_path_key` | `test_interfaces.py` | unit | AC-11: `result["file_path"] == file_path` argument |
| T-17 | `test_language_pack_sanitize_strips_utf8_bom` | `test_interfaces.py` | unit | AC-12: UTF-8 BOM `\xef\xbb\xbf` removed |
| T-18 | `test_language_pack_sanitize_strips_utf16_bom` | `test_interfaces.py` | unit | AC-12: UTF-16 LE BOM `\xff\xfe` removed |
| T-19 | `test_settings_all_18_defaults_correct` | `test_config.py` | unit | AC-13: all 18 default values match Contract 14 §3 table |
| T-20 | `test_settings_artifact_backend_env_override` | `test_config.py` | unit | AC-14: `ARTIFACT_BACKEND=s3` env var is picked up |
| T-21 | `test_settings_kafka_bootstrap_servers_env_override` | `test_config.py` | unit | AC-14: `KAFKA_BOOTSTRAP_SERVERS` env var overrides default |
| T-22 | `test_settings_invalid_type_raises_validation_error` | `test_config.py` | unit | Error handling row 8: bad value type raises Pydantic error at construction |
| T-23 | `test_artifact_path_template_formats_correctly` | `test_constants.py` | unit | AC-15: path format matches ADR-0007 §2 |
| T-24 | `test_fidelity_ceiling_full_is_1_0` | `test_constants.py` | unit | AC-16: `FIDELITY_CEILING[FIDELITY_FULL] == 1.0` |
| T-25 | `test_fidelity_ceiling_partial_is_0_8` | `test_constants.py` | unit | AC-16: `FIDELITY_CEILING[FIDELITY_PARTIAL] == 0.8` |
| T-26 | `test_fidelity_ceiling_heuristic_is_0_6` | `test_constants.py` | unit | AC-16: `FIDELITY_CEILING[FIDELITY_HEURISTIC] == 0.6` |
| T-27 | `test_artifact_not_found_error_path_attribute` | `test_interfaces.py` | unit | AC-17: `ArtifactNotFoundError.path` preserved; message contains path |
| T-28 | `test_artifact_not_found_error_message_format` | `test_interfaces.py` | unit | AC-17: `str(e) == "Artifact not found: <path>"` |
| T-29 | `test_all_exceptions_are_ecle_base_subclasses` | `test_interfaces.py` | unit | AC-18: all four custom exceptions inherit `ECLEBaseError` |
| T-30 | `test_worker_lifecycle_ttl_is_thirty` | `test_constants.py` | unit | `WORKER_LIFECYCLE_TTL_SECONDS == 30`; type is `int` |
| T-31 | `test_louvain_min_cluster_size_is_two` | `test_constants.py` | unit | `LOUVAIN_MIN_CLUSTER_SIZE == 2`; type is `int` |
| T-32 | `test_db_connection_error_chains_from_cause` | `test_interfaces.py` | unit | Error handling row 3: `DBConnectionError` raised with `from exc` preserves `__cause__` |
| T-33 | `test_artifact_not_found_error_chains_from_cause` | `test_interfaces.py` | unit | Contract 01 §4: `ArtifactNotFoundError` raised with `from exc` preserves `__cause__` |
| T-34 | `test_istructureddb_close_callable_on_concrete_stub` | `test_interfaces.py` | unit | `close()` exists and is callable on a concrete stub; no exception |
| T-35 | `test_ivectorstore_is_abstract` | `test_interfaces.py` | unit | AC-19: `IVectorStore()` raises `TypeError` |
| T-36 | `test_itopologygraph_is_abstract` | `test_interfaces.py` | unit | AC-20: `ITopologyGraph()` raises `TypeError` |
| T-37 | `test_factory_functions_are_callable` | `test_backends.py` | unit | AC-21: all four factory functions pass `callable()` check |
| T-38 | `test_language_pack_sanitize_raises_unicode_decode_error` | `test_interfaces.py` | unit | Error handling row 7: stub `sanitize()` that raises `UnicodeDecodeError` propagates uncaught |

Every test in `test_interfaces.py` and `test_config.py` must execute in < 100ms with
no I/O (Contract 03 §2). Use in-memory stub implementations — no real DB, no real
filesystem, no real Kafka.

Coverage target: `src/ecle/core/interfaces.py`, `src/ecle/core/exceptions.py`,
`src/ecle/config.py`, `src/ecle/constants.py` ≥ 95% line coverage (Contract 03 §1).

---

## Out of scope

- **Factory function stub signatures** (`get_structured_db()`, `get_artifact_store()`,
  `get_vector_store()`, `get_topology_graph()`) are declared in this spec (in
  `backends.py`). The **concrete backend-switching implementations** are defined in
  SPEC-0009 alongside the concrete backend classes.
- **Concrete implementations** `LocalArtifactStore`, `S3ArtifactStore`,
  `AzureBlobArtifactStore`, `PostgreSQLStructuredDB` — defined in SPEC-0009.
- **`IVectorStore` and `ITopologyGraph` concrete implementations** — stubs are defined in this spec (per Contract 17 §1); concrete backends deferred to Phase 2 and Phase 3.
- **DB DDL** (`CREATE TABLE` statements for Contract 15 §2 tables) — SPEC-0009.
- **`LanguagePackRegistry`** (scan, hot-reload, manifest validation) — SPEC-0002.
- **`WorkerBase`** (Kafka consumer lifecycle, offset commit, DLQ routing) — SPEC-0008.
- **`EventEmitter`** and event payload dataclasses — SPEC-0003 / Contract 09.
- **Concrete language pack implementations** (e.g. `python/`, `powerbuilder/`) — covered
  by individual language pack specs.
- **`.env` file creation or management** — deployment concern; out of scope for this spec.
- **`topic_registry.py`** — SPEC-0008.

---

## Deviations

_To be filled at implementation time. Empty for Draft specs._
