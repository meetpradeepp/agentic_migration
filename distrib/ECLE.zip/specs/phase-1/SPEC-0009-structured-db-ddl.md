# SPEC-0009 — Structured DB DDL + Concrete Backends

**Phase:** 1
**Status:** Implemented
**Implements:** ADR-0007, ADR-0028, ADR-0034, Contract 15
**Depends on:** SPEC-0001, SPEC-0008

---

## Problem

SPEC-0001 defines `IStructuredDB` and `IArtifactStore` as protocol contracts and
`get_structured_db()` / `get_artifact_store()` as factory stubs that raise
`NotImplementedError`. Without concrete implementations, no Phase 1 worker can persist
facts, read artifacts, or be tested end-to-end against real backends.

Additionally, the `worker_lifecycle` table — required by `WorkerBase._check_lifecycle()`
(SPEC-0008) — and all Phase 1 fact tables defined in Contract 15 must exist before any
worker can run. Without an Alembic-managed schema, table creation is manual, unrepeatable,
and not portable across the three deployment tiers.

**FACT impact (Contract 04):** Parameterised SQL via `PostgreSQLStructuredDB` eliminates
SQL injection risk (trustworthy). `is_current` filter enforcement at the DB layer means
no worker can accidentally serve stale facts (accurate). `LocalArtifactStore` provides
the deterministic `{tenant_id}/{repo_id}/{file_rel_path}.facts.json` path required by
ADR-0007, making artifacts addressable without DB lookup (complete/fast).

---

## Decision

Four deliverables:

| Module | Path | Provides |
|--------|------|---------|
| `postgresql_db` | `src/ecle/core/backends/postgresql_db.py` | `PostgreSQLStructuredDB(IStructuredDB)` |
| `local_artifact_store` | `src/ecle/core/backends/local_artifact_store.py` | `LocalArtifactStore(IArtifactStore)` |
| `backends` (update) | `src/ecle/core/backends.py` | Fill in `get_structured_db()` + `get_artifact_store()` factory stubs from SPEC-0001 |
| `migrations` | `alembic/versions/0001_phase1_schema.py` | All Phase 1 tables (see below) + Alembic env bootstrap |

`IVectorStore` and `ITopologyGraph` factories continue to raise `NotImplementedError`
(Phase 2 and Phase 3 scope — Contract 17).

`PostgreSQLStructuredDB` notes:
- Uses `psycopg2` (synchronous) — no async required for Phase 1 workers
- `execute()` appends `AND tenant_id = %(tenant_id)s` for all tables that carry `tenant_id`;
  passes through unchanged for system tables (`worker_lifecycle`, `tenant_config`) when
  `tenant_id="__system__"` is passed (satisfies SPEC-0008 Behaviour step 11)
- `upsert()` compiles to `INSERT ... ON CONFLICT (conflict_keys) DO UPDATE SET ...`
- Connection is injected at construction; `close()` closes it

`LocalArtifactStore` notes:
- Root path = `settings.ARTIFACT_STORE_PATH` (ADR-0028 `ecle-data/repos/`)
- All I/O via `pathlib.Path`; no direct `open()` at caller sites (Contract 14 §4)
- `read()` raises `ArtifactNotFoundError(path) from exc` on missing file (SPEC-0001)
- `write()` creates parent directories with `parents=True, exist_ok=True`
- `delete()` is idempotent — no error if path absent

**Phase 1 tables (Alembic migration `0001_phase1_schema`):**

| Table | Layer | Notes |
|-------|-------|-------|
| `tenants` | Metadata | Tenant registry |
| `repositories` | Metadata | One row per repo per tenant; includes `platform VARCHAR NULLABLE`, `primary_language VARCHAR NULLABLE`, and `repo_type VARCHAR NULLABLE` (ADR-0034, Contract 20 §6.3–6.5 — needed by rule engine `applies_to` pre-filter) |
| `versions` | Metadata | Commit history |
| `indexing_state` | Metadata | Per-file pipeline tracker |
| `import_jobs` | Metadata | Ingestion job tracker |
| `worker_lifecycle` | Metadata | WorkerBase lifecycle commands (SPEC-0008) |
| `tenant_config` | Metadata | Runtime config overrides |
| `api_keys` | Auth | API key registry |
| `query_audit_log` | Auth | Append-only call log |
| `file_facts` | Layer 1 | Central file-level fact table |
| `file_tables` | Layer 1 | Tables read/written per file |
| `file_entry_points` | Layer 1 | Entry points per file |
| `file_external_calls` | Layer 1 | External calls per file |
| `file_literals` | Layer 1 | String/int literals per file |
| `function_facts` | Layer 2 | Function-level facts |
| `function_calls` | Layer 2 | Caller→callee relationships |
| `function_table_ops` | Layer 2 | Function→table→column granularity |
| `cluster_assignments` | Layer 3 | File→cluster mapping |
| `coverage_gap_counts` | Layer 3 | Extension miss counter |
| `confidence_votes` | Auth | Developer feedback votes |
| `semantic_annotations` | Layer 2 | Semantic rule engine annotations per fact (ADR-0034) |

**Phase 1 indexes** (Phase 1 mandatory indexes from Contract 15 §3 — all created in migration `0001`):

| Table | Columns | Type |
|-------|---------|------|
| `file_facts` | `(tenant_id, repo_id, is_current)` | Composite |
| `file_facts` | `(tenant_id, repo_id, file_path)` | Composite |
| `file_facts` | `(cluster_stable_id, is_current)` | Composite |
| `file_tables` | `(tenant_id, table_name, is_current)` | Composite |
| `function_facts` | `(tenant_id, repo_id, function_name, is_current)` | Composite |
| `function_calls` | `(tenant_id, callee_name, is_current)` | Composite |
| `indexing_state` | `(tenant_id, repo_id, entity_id)` | Unique |
| `api_keys` | `(key_hash)` | Unique |
| `api_keys` | `(tenant_id, revoked_at)` | Composite |
| `query_audit_log` | `(tenant_id, called_at)` | Composite |
| `query_audit_log` | `(subject, called_at)` | Composite |
| `confidence_votes` | `(tenant_id, entity_id)` | Unique |
| `tenant_config` | `(tenant_id, config_key)` | Unique |
| `import_jobs` | `(tenant_id, started_at DESC)` | Composite |
| `import_jobs` | `(repo_id, status)` | Composite |
| `worker_lifecycle` | `(worker_name)` | Unique |
| `semantic_annotations` | `(tenant_id, repo_id, target_type, target_id, rule_id) WHERE is_current = true` | Partial unique |
| `repositories` | `(tenant_id, platform)` | Composite |

Note: `shared_artifacts`, `cross_repo_edges`, `service_call_index`, `field_extractions`,
`cross_repo_summary`, `topology_edges`, and `doc_chunks` are Phase 3+ tables — NOT
included in this migration. Their indexes are deferred to the migration that creates each
table. Absence of these tables must not break Phase 1 worker startup.

---

## Interface contract

```python
# src/ecle/core/backends/postgresql_db.py  (from __future__ import annotations — Contract 01 §2)
class PostgreSQLStructuredDB(IStructuredDB):
    SYSTEM_TABLES: frozenset[str] = frozenset({"worker_lifecycle", "tenant_config"})

    def __init__(self, connection: psycopg2.extensions.connection) -> None: ...
    def execute(self, sql: str, params: Sequence[Any] | dict[str, Any], *, tenant_id: str) -> list[dict[str, Any]]: ...
    # If tenant_id != "__system__": appends AND tenant_id = %(tenant_id)s / %s to WHERE clause
    # If tenant_id == "__system__": executes query as-is (system tables have no tenant_id column)
    # Returns list of dicts; uses cursor.description for column names
    def upsert(self, table: str, row: dict[str, Any], *, conflict_keys: Sequence[str], tenant_id: str) -> None: ...
    # Two-step version-chain upsert for fact tables (Contract 15 §1 Rules 1+4):
    #   1. UPDATE ... SET is_current=false, superseded_at=NOW() WHERE conflict_keys AND tenant_id AND is_current=true
    #   2. INSERT ... with is_current=true, previous_id=<superseded row UUID>
    #   Both steps in one transaction. Table/column names via psycopg2.sql.Identifier (Contract 01 §10).
    # For system tables (worker_lifecycle, tenant_config): single INSERT ON CONFLICT DO UPDATE (no version chain).
    # Never f-string SQL for structural elements (Contract 10 A10, Contract 01 §10).
    def close(self) -> None: ...

# src/ecle/core/backends/local_artifact_store.py  (from __future__ import annotations — Contract 01 §2)
class LocalArtifactStore(IArtifactStore):
    def __init__(self, root: Path) -> None: ...   # root = Path(settings.ARTIFACT_STORE_PATH)
    def write(self, path: str, data: bytes) -> None: ...
    # Resolves to root / path; creates parents; writes atomically (temp file + rename)
    def read(self, path: str) -> bytes: ...
    # Raises ArtifactNotFoundError(path) from exc on FileNotFoundError
    def exists(self, path: str) -> bool: ...
    def delete(self, path: str) -> None: ...
    # Idempotent: FileNotFoundError is silently suppressed

# src/ecle/core/backends.py  — filled-in factories (amends SPEC-0001)
def get_structured_db() -> IStructuredDB: ...
# Reads settings.STRUCTURED_BACKEND; raises InvalidConfigError for unknown backend
# "postgresql" → PostgreSQLStructuredDB(psycopg2.connect(settings.DATABASE_URL))

def get_artifact_store() -> IArtifactStore: ...
# Reads settings.ARTIFACT_BACKEND
# "local" → LocalArtifactStore(Path(settings.ARTIFACT_STORE_PATH))
```

**`worker_lifecycle` bootstrap row:** On first startup, each worker calls `upsert()` to
ensure its lifecycle row exists:
```
upsert("worker_lifecycle", {"worker_name": self.worker_name, "command": "run"}, conflict_keys=["worker_name"], tenant_id="__system__")
```

---

## Behaviour

**`PostgreSQLStructuredDB.execute()` — tenant filter injection:**

1. Parse the `sql` string: detect if it contains a `WHERE` clause (case-insensitive).
2. If `tenant_id == "__system__"`: execute `sql` with `params` as-is. Return results.
3. If `tenant_id != "__system__"`:
   - If `WHERE` present: append `AND tenant_id = %(tenant_id)s` (dict params) or
     `AND tenant_id = %s` (list/tuple params); add `tenant_id` to `params`.
   - If no `WHERE`: append `WHERE tenant_id = %(tenant_id)s` or `WHERE tenant_id = %s`;
     add `tenant_id` to `params`.
4. Execute using `cursor.execute(final_sql, final_params)`. Fetch all rows with
   `cursor.fetchall()`. Use `cursor.description` to build `list[dict]`.
5. Never call `connection.commit()` — callers manage transactions.

**`PostgreSQLStructuredDB.upsert()` — two-step version-chain for fact tables:**

6. Determine table type: if `table` in `SYSTEM_TABLES` → use single-statement path (step 9). Otherwise use two-step version-chain path (steps 7–8).
7. **Two-step version-chain (fact tables):**
   a. Build UPDATE statement using `psycopg2.sql.SQL` + `psycopg2.sql.Identifier` for all structural elements (table name, column names) — never f-string SQL (Contract 01 §10, Contract 10 A10):
      `UPDATE {table} SET is_current = false, superseded_at = NOW() WHERE {conflict_cols_filter} AND tenant_id = %s AND is_current = true`.
      Execute with conflict key values + `tenant_id`. Store returned `id` (the superseded row UUID) via `cursor.fetchone()`.
   b. Inject `previous_id = <superseded UUID or None>`, `is_current = true` into a copy of `row`. If `tenant_id != "__system__"` and not already in `row`: inject `tenant_id`.
   c. Build INSERT statement using `psycopg2.sql.Identifier` for table and all column names:
      `INSERT INTO {table} ({cols}) VALUES ({placeholders})`.
      Execute. Both steps share the same `connection` transaction.
8. Wrap steps 7a–7c in a single transaction block. If either step raises `psycopg2.Error`: rollback, then raise `DBConnectionError(...) from exc`.
9. **Single-statement path (system tables):** Build `INSERT INTO {table} ({cols}) VALUES ({placeholders}) ON CONFLICT ({conflict_cols}) DO UPDATE SET {assignments}` using `psycopg2.sql.Identifier` for all structural elements. Execute. No transaction wrapping needed.

**`LocalArtifactStore.write()` — atomic write:**

10. Compute full path: `self._root / path`. Create parent directories with
    `parents=True, exist_ok=True`.
11. Write to a temp file in the same directory (`path + ".tmp"`).
12. `os.replace(tmp_path, full_path)` — atomic on POSIX and Windows.

**`get_structured_db()` factory:**

13. Read `settings.STRUCTURED_BACKEND`.
14. `"postgresql"` → `psycopg2.connect(settings.DATABASE_URL)` →
    `PostgreSQLStructuredDB(conn)`. Connection error raises `DBConnectionError` chained
    from `psycopg2.Error`.
15. Unknown backend → `raise InvalidConfigError(f"Unknown STRUCTURED_BACKEND: {value}") from None`.

**`get_artifact_store()` factory:**

16. Read `settings.ARTIFACT_BACKEND`.
17. `"local"` → `LocalArtifactStore(Path(settings.ARTIFACT_STORE_PATH))`.
18. Unknown backend → `raise InvalidConfigError(f"Unknown ARTIFACT_BACKEND: {value}") from None`.

**Alembic migration `0001_phase1_schema`:**

19. `upgrade()`: `CREATE TABLE IF NOT EXISTS` for all 21 Phase 1 tables in dependency order
    (parent tables before FK-referencing children). Create all 18 mandatory Phase 1 indexes
    (see Decision section index table).
    Insert bootstrap `worker_lifecycle` rows for Phase 1 workers:
    `scan_source`, `parse_repo`, `persist_facts` — all with `command="run"`.
20. `downgrade()`: `DROP TABLE IF EXISTS` in reverse dependency order. Drop indexes.

---

## Acceptance criteria

| ID | Given | Input | Expected |
|----|-------|-------|---------|
| AC-01 | `PostgreSQLStructuredDB`, real or mock connection | `execute("SELECT ... WHERE repo_id = %s", ["r1"], tenant_id="t1")` | Query appends `AND tenant_id = %s` with value `"t1"` |
| AC-02 | Same | `execute("SELECT ... WHERE repo_id = %s", ["r1"], tenant_id="__system__")` | Query sent as-is, no tenant filter appended |
| AC-03 | Same | `execute("SELECT * FROM worker_lifecycle WHERE worker_name = %s", ["parse_repo"], tenant_id="__system__")` | Returns rows from `worker_lifecycle` without tenant filter |
| AC-04 | `upsert()` on `file_facts`, first call (no prior row) | `row={"file_path": "a.py", ...}`, `conflict_keys=["tenant_id","repo_id","file_path"]` | INSERT executes; row written with `is_current=true`, `previous_id=None` |
| AC-04b | `upsert()` on `file_facts`, second call (prior row exists) | Same `conflict_keys`; new content_hash | Prior row set `is_current=false`, `superseded_at` set; new row written with `is_current=true`, `previous_id=<prior UUID>`; both operations in same transaction |
| AC-04c | Any `upsert()` on fact table | `table` or column name | SQL structure uses `psycopg2.sql.Identifier`; no f-string SQL for structural elements |
| AC-05 | `upsert()` on `worker_lifecycle` with `tenant_id="__system__"` | `row={"worker_name":"parse_repo","command":"run"}`, `conflict_keys=["worker_name"]` | Executes without injecting `tenant_id` into row |
| AC-06 | `LocalArtifactStore`, temp path | `write("t1/r1/src/foo.py.facts.json", b"data")` | File written at `root/t1/r1/src/foo.py.facts.json`; parent dirs created |
| AC-07 | Write followed by read | Same path | `read()` returns original bytes |
| AC-08 | `read()` on missing path | Non-existent path | `ArtifactNotFoundError` raised with `path` attribute set; chained from `FileNotFoundError` |
| AC-09 | `delete()` on existing path | Existing path | File removed; subsequent `exists()` returns `False` |
| AC-10 | `delete()` on missing path | Non-existent path | Returns without error (idempotent) |
| AC-11 | `write()` concurrent writes | Two writes to same path | Second write atomically replaces first; no partial/corrupt file visible |
| AC-12 | `get_structured_db()`, `STRUCTURED_BACKEND="postgresql"` | Valid `DATABASE_URL` | Returns `PostgreSQLStructuredDB` instance |
| AC-13 | `get_structured_db()`, `STRUCTURED_BACKEND="unknown"` | Any `DATABASE_URL` | Raises `InvalidConfigError` |
| AC-14 | `get_artifact_store()`, `ARTIFACT_BACKEND="local"` | Valid `ARTIFACT_STORE_PATH` | Returns `LocalArtifactStore` instance |
| AC-15 | `get_artifact_store()`, `ARTIFACT_BACKEND="unknown"` | — | Raises `InvalidConfigError` |
| AC-16 | Alembic migration `0001_phase1_schema` applied to empty DB | `alembic upgrade head` | All 21 tables exist; all 18 indexes exist |
| AC-17 | Migration `0001` followed by `alembic downgrade base` | — | All 21 tables dropped; no residual schema |
| AC-18 | Migration `0001` applied twice | `alembic upgrade head` idempotent | No error on second run (`CREATE TABLE IF NOT EXISTS`) |
| AC-19 | Bootstrap rows in migration | After `upgrade()` | `worker_lifecycle` rows present for `scan_source`, `parse_repo`, `persist_facts` with `command="run"` |
| AC-20 | `execute()` SQL with no WHERE clause | `execute("SELECT * FROM tenants", [], tenant_id="t1")` | Appends `WHERE tenant_id = %s` with `"t1"` |

---

## Error handling

| Error | Classification | Handling |
|-------|---------------|---------|
| `psycopg2.Error` in `execute()` or `upsert()` | Transient (caller decides) | Re-raise as `DBConnectionError(...) from exc`; caller (WorkerBase) classifies as `ECLEBaseError` → retry |
| `FileNotFoundError` in `read()` | Permanent | Raise `ArtifactNotFoundError(path) from exc` |
| `OSError` in `write()` (disk full, perms) | Permanent | Re-raise as-is; caller logs and routes to DLQ |
| `InvalidConfigError` in factories | Fatal (startup) | Raised before any worker connects; process exits |
| `DBConnectionError` in `get_structured_db()` | Fatal (startup) | Raised before loop starts; process exits |
| Alembic migration failure | Fatal (startup) | Migration exits non-zero; deployment fails fast |
| `OSError` from `os.replace()` in atomic rename | Permanent | Covered by existing `OSError in write()` error row — applies to both the temp write and the final rename step |

All exceptions chained (`raise X(...) from exc` — Contract 01 §4). No bare `except:`.

---

## Tests required

```
tests/unit/test_postgresql_db.py:
  test_execute_appends_tenant_filter_with_where_clause        # AC-01
  test_execute_no_tenant_filter_for_system                    # AC-02, AC-03
  test_execute_appends_tenant_filter_without_where_clause     # AC-20
  test_upsert_fact_table_first_call_inserts_with_no_previous_id   # AC-04
  test_upsert_fact_table_second_call_supersedes_prior_row         # AC-04b — is_current chain
  test_upsert_uses_sql_identifier_not_fstring                     # AC-04c
  test_upsert_skips_tenant_injection_for_system_table             # AC-05
  test_execute_raises_db_connection_error_on_psycopg2_error
  test_upsert_raises_db_connection_error_on_psycopg2_error

tests/unit/test_local_artifact_store.py:
  test_write_creates_parent_directories                       # AC-06
  test_write_then_read_returns_original_bytes                 # AC-07
  test_read_raises_artifact_not_found_error                   # AC-08
  test_delete_removes_file                                    # AC-09
  test_delete_is_idempotent_on_missing_file                   # AC-10
  test_write_is_atomic                                        # AC-11
  test_write_raises_os_error_on_disk_full                     # Error handling: OSError in write()

tests/unit/test_backends_factories.py:
  test_get_structured_db_returns_postgresql_instance          # AC-12
  test_get_structured_db_raises_on_unknown_backend            # AC-13
  test_get_structured_db_raises_db_connection_error_on_psycopg2_failure  # Error handling: DBConnectionError
  test_get_artifact_store_returns_local_instance              # AC-14
  test_get_artifact_store_raises_on_unknown_backend           # AC-15

tests/integration/test_migrations.py:
  test_migration_0001_creates_all_tables                      # AC-16
  test_migration_0001_downgrade_drops_all_tables              # AC-17
  test_migration_0001_is_idempotent                           # AC-18
  test_migration_0001_bootstrap_rows                          # AC-19

tests/integration/test_postgresql_db_integration.py:
  test_execute_filters_by_tenant_against_real_db
  test_upsert_conflict_resolution_against_real_db
```

All test files carry `# Implements: SPEC-0009` header (Contract 02).

**Coverage targets (Contract 03):**
- `src/ecle/core/backends/postgresql_db.py`: ≥ 80% line coverage
- `src/ecle/core/backends/local_artifact_store.py`: ≥ 80% line coverage
- `src/ecle/core/backends.py`: ≥ 80% line coverage
- `alembic/versions/0001_phase1_schema.py`: ≥ 80% line coverage
- Unit tests: no I/O, deterministic, < 100 ms per test.

---

## Out of scope

| Item | Owning spec |
|------|------------|
| `Neo4jTopologyGraph` (ITopologyGraph impl) | Phase 3 |
| `QdrantVectorStore` (IVectorStore impl) | Phase 2 |
| Phase 3+ tables (`topology_edges`, `shared_artifacts`, `cross_repo_edges`, `service_call_index`, `field_extractions`, `cross_repo_summary`, `doc_chunks`) | Phase 3 |
| Alembic migration 0002+ (schema amendments) | Future specs requiring schema changes (Contract 15 §6) |
| Artifact cleanup worker | Phase 2 (ADR-0007 §Retention policy) |
| Connection pooling (pgbouncer, SQLAlchemy pool) | Phase 6 (Contract 18 §DB access) |
| Tenant provisioning API | SPEC-0007 (MCP Phase 1) |
| `admin_db.py` (Admin API DB layer) | SPEC-0007 |
| `documents` table and `doc_chunks` table | Phase 2+ (Tier 3 document ingestion not in Phase 1 scope) |

---

## Deviations

DEV-0009-001: Integration test Alembic invocation was adjusted to use the environment Alembic executable (`alembic`) instead of `python -m alembic`.

- Rationale: local package/module shadowing in this repository can break `python -m alembic` resolution in some environments.
- Effect: migration integration tests now run reliably under the project environment command runner.
- No migration DDL, table/index contract, or backend runtime behavior changed.
