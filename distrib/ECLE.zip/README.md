# ECLE 2.0

Deterministic Code Intelligence Engine. **No LLM at any runtime layer.**

## Quick Start

```bash
# Install uv (if not already)
# https://docs.astral.sh/uv/getting-started/installation/

# Clone and install
uv sync --dev

# Run lint + format
uv run ruff check src/ tests/
uv run ruff format src/ tests/

# Run type checks
uv run mypy src/ecle/

# Run tests
uv run pytest tests/unit/ -v

# Run all checks (what CI does)
uv run ruff check src/ tests/ && uv run ruff format --check src/ tests/ && uv run mypy src/ecle/ && uv run pytest tests/ -v
```

## Project Structure

```
src/ecle/              ← Python source (installed as `ecle` package)
tests/                 ← Test suites (unit, integration, eval)
constitution/          ← The constitution — single source of truth
specs/                 ← Specification documents
ecle-data/             ← Runtime data (gitignored except config)
ecle-logs/             ← Log output (gitignored)
.github/agents/        ← AI agent definitions
.github/memory/        ← Agent memory digests (ADR-0029)
.github/pipeline/      ← SDLC pipeline state (ADR-0030)
scripts/               ← Development scripts
```

## Constitution

Read `constitution/README.md` before writing any code. Every change follows:

```
Spec → Tests (Red) → Implementation (Green) → Review → Release
```

See `constitution/contracts/` for all rules. See `constitution/adrs/` for architecture decisions.
