# Ideas Backlog

> Written by orchestrator at G-1. Append-only — ideas are never deleted, only closed.
> An idea is closed by one of two outcomes:
> - **In Pipeline** → linked to a SPEC (set `Closed by: SPEC-NNNN`)
> - **Deferred** → not viable for current phase (set `Closed by: Deferred — <reason/phase>`)
>
> Orchestrator reads this at G0 to carry prior thinking into triage.

---

### IDEA-0001: Semantic Rule Engine (Post-Extraction Meaning Layer)
- Date: 2026-05-10
- Updated: 2026-05-11 — Phase re-evaluated to Phase 1 (see reasoning below)
- Problem: ECLE parsers extract correct but opaque structural facts. Three compounding gaps confirmed in discussion:
  1. **Table-level opacity** — `TXD_BILL_CYCLE` extracted correctly but query for "billing cycle table" returns nothing. ADR-0025 cluster-level ontology cannot produce precise fact-level annotations.
  2. **Function group blindness** — `atGTBan_extract`, `atGTBan_process`, `atGTBan_report` extracted as 3 unrelated functions. No rule → no group "GTBan", no detection of extract→process→report pipeline pattern, no suffix-role inference.
  3. **Platform classification gap (FACT completeness violation)** — `par_ban*` functions are Tuxedo service handlers. After full ingestion, ECLE cannot answer "how many Tuxedo services are there?" — the answer is *unknown*, not zero. This is a FACT-C (Completeness) failure, not a search quality issue. Same applies to: "how many GTBan pipeline flows?", "which files are Tuxedo entry points?", "show all service-handler functions across repos?" — all unanswerable without classification rules.
- Phase fit: **Phase 1** — MUST precede Phase 2 embeddings. If Phase 2 embeds un-annotated facts, the vector space is semantically blind from day 1 and search results will be permanently wrong for enterprise naming conventions. Rule engine must annotate facts BEFORE embeddings are generated.
- Key constraints:
  - ADR-0025 (ontology enricher) operates at cluster level; rule engine operates at fact level — complementary, not conflicting; ADR-0025 must be amended to clarify the two-layer relationship
  - ADR-0027 (async component autonomy) — new `semantic_interpreter` worker must be added to the worker registry; Kafka-only comms enforced
  - ADR-0018 (flow registry) — `enrich` step should preferentially use `semantic_annotations.domain_entity` for exact lookup before falling back to cluster `concept_stems[]`
  - ADR-0020 (admin control plane) — new `POST /admin/v1/semantic-rules` endpoint; fits existing admin API pattern
  - Contract 09 — two new Kafka events required: trigger event consumed by `semantic_interpreter`, `facts.annotated` emitted after annotation write
  - Contract 15 — new `semantic_annotations` table required; schema change requires ADR per Contract 15 §1 Rule 6
  - ADR-0012 (detection rules) — detection rule YAML format is a structural precedent; semantic rule YAML is analogous for meaning extraction
- Layer 0 (Tree-sitter/Joern/parse_repo/persist_facts) = extraction-only, commoditized, batch formation by count only — rule engine has NO input into batch planning
- Layer 1 (semantic_interpreter) = adds domain meaning to stored facts; this enriched data IS the ingestion — `ecle.facts.annotated` is the ingestion completion signal, not `ecle.repo.indexed`
- Phase 2 `batch_embed` subscribes to `ecle.facts.annotated` — never `ecle.repo.indexed`
- Rule capabilities required:
  - Glob/regex match on name → assign `domain_entity`, `platform`, `type`, `group`, `role`
  - Suffix pattern inference (`_extract/_process/_report` trio → pipeline group + role)
  - Multi-fact rules (functions co-touching the same table → shared group)
  - Tenant rule tiers (base rules + tenant overrides; tenant wins on conflict)
- Open questions (for ADR-0034 to decide):
  - Trigger: `semantic_interpreter` consumes `file.stored` (per-file incremental) OR `repo.indexed` (per-repo batch, needed for multi-fact rules)? Likely both via fan-out.
  - Re-annotation: when rules change, invalidate ALL annotations for changed `rule_id` only, or full repo re-annotation?
  - Confidence: does the rule engine emit a confidence score, or is rule-match = confidence 1.0?
- Recommendation: **ADR-0034 + Contract 20 + SPEC-0010 — Phase 1**
  - ADR-0034: worker SRP, DB table design, event types, rule tier model, annotation lineage, relationship to ADR-0025, trigger strategy
  - Contract 20: YAML rule schema, evaluation semantics, annotation lineage requirements, tenant rule API behaviour, re-annotation triggers
  - SPEC-0010: `semantic_interpreter` worker + YAML rule loader + `semantic_annotations` migration
  - Amends: ADR-0025, ADR-0027, ADR-0018, ADR-0020; Contract 09 (new events), Contract 15 (new table + `semantic_annotations` index)
- Status: In Pipeline
- Closed by: ADR-0034 + Contract 20 + SPEC-0010 (Phase 1)
