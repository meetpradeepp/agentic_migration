# Constitution Digest — Agent Quick Reference

> **Source of truth:** `constitution/contracts/` and `constitution/adrs/`.
> This digest is a compact reference for agent context optimization (ADR-0029).
> When exact contract wording is needed, load the full contract file.

---

## Contract 01 — Coding Standards
- `from __future__ import annotations` on every file
- Module docstring mandatory: one sentence + `Implements: SPEC-NNNN`
- Import order: stdlib → third-party → ecle (absolute only, no relative imports)
- Type hints on all public functions — no exceptions
- One class = one responsibility; dependencies injected via constructor
- No class-level mutable state; no side effects in constructors
- Function soft limit: 30 lines of logic
- Typed exceptions only — no bare `except:`, chain with `from exc`
- Config via `ecle.config.Settings` (Pydantic BaseSettings) — no magic numbers
- SQL: parameterised queries only — f-string SQL is a security blocker
- Logging: `logging.getLogger(__name__)`, structured `extra={}`, never `print()`
- No secrets in code — environment variables only
- **Traceability** (§10): every non-trivial branch cites spec AC or contract rule; every bug fix references spec deviation; orphan TODOs banned
- **Tooling** (§11): uv + ruff + mypy + pytest; all config in `pyproject.toml`; pre-commit hooks enforce all rules

## Contract 02 — SDLC Contract
- Lifecycle: Spec → Tests (Red) → Implementation (Green) → Review → Merge → Release
- Spec before code. Tests before implementation. Always.
- Spec format: 14 mandatory sections (§2) — none may be omitted
- TDD order: `test(...)` commit MUST precede `feat(...)` commit
- Commit format: `<type>(<scope>): <description> [Phase N]`
- PR max 500 lines changed; one human review minimum
- **10-point review checklist (§6)**: spec conformance, interface, standards, coverage, anti-patterns, events, orphan data, AC coverage, traceability, SAST report (ADR-0036)
- **SAST at G5**: `@sast` agent runs `bandit` + `pip-audit`; FAIL verdict blocks merge; WARN requires reviewer acknowledgement; always on full `src/` tree
- Every test file: `# Implements: SPEC-NNNN` header
- Phase governance: `Phase:` header must match Contract 17

## Contract 03 — Testing Contract
- Pyramid: 70% unit, 20% integration, 10% E2E
- Coverage: new code ≥80%, interfaces/schemas ≥95%, grounding verifiers 100%
- Unit tests: no I/O, < 100ms, deterministic, `test_<function>_<scenario>`
- Integration tests: real backends, < 5s, full event chain, clean up in teardown
- 8 eval suites are hard CI gates (see contract for full list)
- Performance: `sanitize()` <10ms, `parse()` <10ms, `extract()` <50ms, DB insert <100ms, ANN search <50ms

## Contract 04 — FACT Contract
- Every response carries full `fact` envelope (fast, accurate, complete, trustworthy)
- Query timeout: 2s hard limit; partial results with `fast.timed_out: true`
- `coverage_warnings[]` mandatory; `indexing_state` checked pre-query
- Full lineage to source file + commit required on every result
- Banned: O(N²) matching, silent gaps, confidence=1.0 on stale data

## Contract 05 — Confidence Contract
- 6 dimensions: `syntactic_freshness`, `behavioral_accuracy`, `contextual_accuracy`, `edge_coherence`, `cluster_alignment`, `semantic_accuracy`
- Single scalar confidence is banned — always 6-dimensional
- Fidelity ceiling: FULL=1.0, PARTIAL=0.8, HEURISTIC=0.6, HEURISTIC+fallback=0.5
- `null` (not 0.0) for inapplicable dimensions
- Decay only on evidence of change — time alone does not trigger decay

## Contract 06 — Grounding Contract
- Every result traceable to deterministic artifact — no LLM at any layer
- Required lineage: `source_file`, `artifact_path`, `extractor_version`, `commit_sha`, `indexed_at`, `file_facts_id`
- Missing lineage → gap marker `{"gap": true, "reason": "lineage_incomplete"}`
- 4 authority tiers; Tier 1-code (CPG facts) wins conflicts

## Contract 07 — Staleness Contract
- Never silently serve stale as fresh — always serve, always with honesty
- Score ranges: 0.0–0.1 (clean), 0.1–0.3 (caveat), 0.3–1.0 (WARNING + re-index event)
- `knowledge_current_as_of` = oldest `last_indexed_at` across all response files
- Hub files (top 10% centrality) with staleness > 0.0 trigger cluster re-index

## Contract 08 — Language Pack Contract
- Self-contained folder: `language_packs/<language_id>/`
- Required files: `manifest.yaml`, `fast_extractor.py`, `schema.py`
- `extract()` MUST NEVER raise — errors go in `extraction_errors` list
- New language = drop folder + hot-reload; new framework = drop `.yaml` in `detection_rules/`

## Contract 09 — Event Pipeline Contract
- Kafka is the ONLY inter-component communication channel (ADR-0027)
- Each worker independently deployable, scalable, controllable lifecycle
- Topic naming: `ecle.{event_type}`; DLQ: `ecle.dlq.{event_type}`
- `enable.auto.commit=False` mandatory; offset committed only after durable write
- Every worker is idempotent — same event twice = same final state
- Workers poll `worker_lifecycle` table on 30s TTL (running|paused|draining)
- `eval_async_coupling` verifies no cross-worker imports on every PR

## Contract 10 — Anti-Patterns (All Banned)
- A1: God class / God worker (multi-responsibility)
- A2: Direct worker-to-worker calls (imports, HTTP, shared DB)
- A3: Inheritance for code reuse (non-polymorphic)
- A4: Premature abstraction / YAGNI
- A5: DRY violation (copy-pasted logic)
- A6: Hardcoded backend references
- A7: Global mutable state
- A8: Shared DB connection between workers
- A9: Bare `except` / silent swallowing
- A10: f-string SQL (injection risk)
- A11: Secrets in code

## Contract 11 — MCP Contract
- Every tool response = full FACT envelope; no raw DB rows
- Tools MUST NOT generate content — structured facts only
- Backend access only via `IStructuredDB`, `IVectorStore`, `ITopologyGraph` factories
- Tools are stateless; `limit` clamped to MAX_RESULTS (100)
- **stdio transport banned — HTTP only** (`POST /mcp`, JSON-RPC 2.0)
- Error responses MUST NOT expose internals

## Contract 12 — Embedding Contract
- ONNX/OpenVINO mandatory; cloud APIs banned unless `EMBEDDING_BACKEND=openai`
- Idempotency key: `SHA256(entity_id + content_hash + model_name + dim)`
- Slim vector payloads: only `repo_id`, `cluster_stable_id`, `is_current`, `model_version`, `layer`
- Collection naming: `{tenant}__{repo}__layer1|layer2|docs`
- Micro-batch: flush at 128 items or 32768 tokens or 100ms
- Embedding failure MUST NOT fail the file — log ERROR, set `embed_status='failed'`

## Contract 13 — Incremental Ingestion Contract
- Ingestion is O(changed_files), not O(corpus)
- Change signal: `content_hash = SHA256(file_bytes)` before sanitization
- `indexing_state` rows updated, never deleted
- Cascade: neighbour change degrades `contextual_accuracy` only — never re-parse
- Behavioral fingerprint gate: unchanged signatures → skip re-embedding

## Contract 14 — Deployment Contract
- Three tiers: dev, Docker Compose, Kubernetes — same codebase, config only
- `if settings.ECLE_TIER == ...` in app code is banned
- All artifact I/O via `IArtifactStore`; no direct `open()` / `Path.read_bytes()`
- No hardcoded paths — everything from `settings`
- Workers and MCP server MUST be stateless

## Contract 15 — DB Schema Contract
- No hard deletes — old versions superseded via `is_current=false`
- Tenant isolation: every fact table carries `tenant_id`; cross-tenant queries forbidden
- Queries MUST filter `is_current=true` unless requesting history
- Schema changes require an ADR
- Key tables: `file_facts`, `function_facts`, `cluster_assignments`, `file_tables`, `file_entry_points`, `file_external_calls`, `function_calls`

## Contract 16 — Observability Contract
- Every component: Prometheus metrics at `GET /metrics`
- Hard SLOs: MCP p95 <1s, p99 <2s, Kafka lag <10K, ingestion >99%, DLQ=0
- OpenTelemetry tracing; new trace per Kafka consumer (linked by `X-Request-Id`)
- Every event payload: `X-Request-Id` and `X-Trace-Id` mandatory
- Repo health gauges updated transactionally at end of ingestion

## Contract 17 — Phase Roadmap Contract (amended by ADR-0035)
- No spec without a phase assignment
- No phase-N+1 work until phase-N exit criteria pass
- Phases are additive — never break earlier functionality
- **Every phase is a product milestone** — each phase delivers a demonstrable user-facing capability; version tag certifies the capability works end-to-end
- **Walking skeleton** — every phase defines a minimum ordered set of specs (skeleton) that produce the milestone capability; planner MUST order skeleton specs before enhancement specs
- **Enhancement specs** — extend the skeleton within the same phase; all must be `Status: Implemented` before the version tag
- Version tag = working product increment (not just CI gates passing)
- Current phase: **Phase 1** — Milestone: ingest a repo and query facts via MCP; version tag: `v0.1.0`
- Phase 1 walking skeleton: SPEC-0001 → SPEC-0008 → SPEC-0009 → SPEC-0005 → SPEC-0006 → SPEC-0007
- Phase 1 enhancements: SPEC-0004, SPEC-0002, SPEC-0010

## Contract 18 — Implementation Guidelines
- ADR consumption mandatory: coder, planner, code-reviewer read ADRs from `workspace/current/adrs/`
- Worker pattern: inherit `WorkerBase`, inject dependencies, `process()` is idempotent
- Backend abstraction: business logic depends on interfaces, factory selects implementation
- Event emission: produce → flush → offset committed by WorkerBase
- Config pattern: `ecle.config.Settings` for tunable values, `ecle/constants.py` for fixed values
- DB access: parameterised queries, filter `is_current=true`, include `tenant_id`
- Test patterns: unit (no I/O), integration (real backends), idempotency test required per worker
- File organization: one worker per file, one MCP tool per file, no cross-worker imports
- DI wiring: factory at startup, no singletons, no import-time side effects
- Error handling: transient → retry with backoff, permanent → DLQ

## Contract 20 — Semantic Rule Engine Contract
- Companion to ADR-0034; Phase 1
- Three rule scopes: `annotation` (ingest-time, persisted to `semantic_annotations`), `search` (query-time, ephemeral rewrite), `display` (response-time, cosmetic label substitution)
- YAML + Pydantic v2 validation; schema module: `src/ecle/workers/semantic_interpreter/rule_schema.py` (SPEC-0010)
- Three-tier precedence: repo > tenant > base; same-tier: highest confidence wins; tie: first-match-wins in file order
- Pattern matching: glob (default, `fnmatch`) or `re:` prefix for Python `re.fullmatch()`; named and positional capture substitution in `annotate` fields
- `applies_to` pre-filter: match `repositories.platform`, `.primary_language`, `.repo_type` — skip rule file if repo does not match
- Reserved `annotate.type` values: `service_handler | pipeline_stage | shared_table_group | entry_point | utility | unknown`
- Reserved `annotate.platform` values: `Tuxedo | Spring | Django | Rails | FastAPI | unknown`
- `confidence: 1.0` = exact/deterministic; annotation lineage (`rule_id`, `rule_version`, `annotated_at`) mandatory on every `semantic_annotations` row
- Eval suites: `eval_semantic_rule_schema`, `eval_idempotent_annotation`, `eval_tier_precedence`, `eval_annotation_lineage`, `eval_search_rule_latency`

### Contract 19 — CPG Extraction Tier Contract
**Scope:** Every language pack, `parse_repo`, `persist_facts`, MCP tools reading extraction facts, confidence reporting.
**Enforced by:** `eval_two_phase_cycle`, `eval_extraction_tier_label`, `eval_c_family_extractors`, `eval_idempotent_ingest`, `eval_fidelity_ceiling` (all every PR).
**Related:** ADR-0032, ADR-0033, ADR-0016, Contract 05, Contract 08, Contract 13, Contract 15.

**Core invariant:** Every fact committed to the knowledge graph is at full extraction depth. Structural extraction (`fast_extractor.py`) is an intermediate phase — artifacts carry `"_extraction_tier": "structural"` and go to artifact store only, never to `file_facts`. `persist_facts` MUST reject any artifact still carrying `_extraction_tier` with `ValueError`.

**Key rules:**
- `fast_extractor.py` MUST set `"_extraction_tier": "structural"` in every facts dict.
- `extractor.sc` (Joern) MUST NOT set `_extraction_tier` — absence = full-depth signal.
- No `extraction_tier` column on `file_facts` — all committed rows are full-depth by construction.
- C-family packs MUST use the shared extractor library (ADR-0033); no per-language duplicate extraction logic.
- Two-phase handoff via Kafka: structural artifact stored → `ecle.file.stored` emitted → Joern deep phase triggered → full artifact replaces structural → `persist_facts` commits.
- Fidelity ceiling: if Joern fails, `persist_facts` logs a coverage gap (`coverage_gap_counts`) and does NOT fall back to structural facts.

---

## ADR Quick Reference

> Full ADR text lives in `constitution/adrs/`. Load the full file when exact wording is needed.
> This section lists the key architectural decision each ADR encodes, for fast agent orientation.

| ADR | Title | Key rule for agents |
|-----|-------|---------------------|
| ADR-0001 | Event-Driven Pipeline | Kafka-first; all workers communicate via events |
| ADR-0012 | Multi-Level Language Detection | Three-pass detection (extension → content heuristics → AST); `detected_layers[]` written to every `file_facts` row; detection rule YAML in `language_packs/<lang>/detection_rules/` |
| ADR-0013 | Kafka Event Broker | KRaft mode; `auto.create.topics.enable=false`; topics declared in `topic_registry.py` |
| ADR-0018 | Intent-Driven Flow Registry | Flow Registry JSON + FlowSelector + FlowExecutor; `enrich` step: (1) exact lookup in `semantic_annotations.domain_entity` (ADR-0034), (2) cluster-stem fallback (ADR-0025) |
| ADR-0019 | AuthN/AuthZ Model | API key scopes: `read`, `write`, `admin`; `admin` required for all Admin API endpoints |
| ADR-0020 | Admin Control Plane | Admin API on port 4001; endpoints: tenants, repos, workers, ontology, **semantic-rules** (ADR-0034 addition) |
| ADR-0021 | Data Lifecycle | Hard-delete banned; purge via scheduled job; `semantic_annotations` `is_current=false` rows subject to lifecycle retention |
| ADR-0025 | Domain Ontology Strategy | Three-layer vocabulary (base + tenant + auto-derived); cluster-level probabilistic enrichment; **rule-engine annotations (ADR-0034) take precedence over cluster stems in ADR-0018 `enrich` step** |
| ADR-0027 | Async Component Autonomy | All workers independent; Kafka-only comms; per-worker KEDA scaling; `semantic_interpreter` worker added (ADR-0034) |
| ADR-0029 | Agent Token Optimization | Agents load this digest; validator and spec-reviewer load full contracts |
| ADR-0030 | Pipeline Workspace | `.github/pipeline/workspace/current/` holds active spec + plan + ADRs |
| ADR-0031 | Stitching Completeness | Two-phase CPG extraction; stitching merge table |
| ADR-0032 | Two-Phase CPG Extraction | Structural phase (fast_extractor) then deep phase (Joern); `repo.structural_complete` gate event |
| ADR-0033 | C-Family Shared Extractor Library | Shared C/C++ extractor; language pack delegates via adapter |
| **ADR-0034** | **Semantic Rule Engine for Fact-Level Annotation** | New `semantic_interpreter` worker; three-tier rule model (base > tenant > repo, conflict: repo wins); consumes `ecle.file.stored` (per-file) + `ecle.repo.indexed` (per-repo batch); emits `ecle.facts.annotated`; writes `semantic_annotations` table; YAML rule schema (glob/regex + capture-group substitution); re-annotation scoped to changed `rule_id` only; amends ADR-0025, ADR-0027, ADR-0018, ADR-0020; adds event to Contract 09; adds table + index to Contract 15; **Companion: Contract 20**; Phase 1 |
| **ADR-0035** | **Each Phase is a Product Milestone** | Adds milestone model to Contract 17: every phase has a `Milestone capability` statement, a `Walking skeleton` (minimum specs for end-to-end demo, implemented first), and `Enhancement specs` (extend skeleton, complete before version tag); version tag = working product increment; planner MUST order skeleton specs before enhancement specs at G3; no new version tags, no new phase sequencing changes |
| **ADR-0036** | **SAST Toolchain and Security Agent** | `@sast` agent runs at G5; tools: `bandit -r src/ -f json` + `pip-audit --format json`; FAIL = HIGH/HIGH bandit finding or CVE with fix; WARN = MEDIUM bandit or CVE without fix; FAIL blocks G5; WARN needs reviewer acknowledgement; no LLM judgment — tool-reported severity is the sole classifier; adds `eval_sast_clean` CI gate; `bandit` + `pip-audit` in `dev` extras |
| **ADR-0037** | **Deterministic Variable Naming Enforcement Gate** | Adds CI Stage 1 rule `ECLE001` to reject one-letter/ambiguous business variable names in non-trivial scopes; deterministic exception list for tiny loop indices, math-only notation, and unpack throwaways; requires machine-readable JSON findings (`path`, `line`, `column`, `symbol`, `rule_id`, `reason`, `scope_kind`, `scope_metrics`) and local/pre-commit parity with CI |
