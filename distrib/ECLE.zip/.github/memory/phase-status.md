# Phase Status — Living Document

> Updated by release-manager at each phase transition.
> Agents read this to know current phase, active work, and what's done.

---

## Current Phase: 1 — Foundation

**Version target:** `v0.1.0`  
**Status:** In Progress  
**Entry criteria:** ✅ Constitution complete (18 contracts, 31 ADRs, 4 schemas)

---

## Phase 1 Specs

| Spec | Title | Status | Assignee |
|------|-------|--------|----------|
| SPEC-0001 | Foundation Interfaces | Implemented (unit complete) | — |
| SPEC-0002 | Language Pack Registry | Not Started | — |
| SPEC-0004 | Upload API + scan_source (rewrite) | Not Started | — |
| SPEC-0005 | parse_repo worker (rewrite) | Not Started | — |
| SPEC-0006 | persist_facts worker (rewrite) | Not Started | — |
| SPEC-0007 | MCP Phase 1 Tools | Not Started | — |
| SPEC-0008 | Kafka WorkerBase + Topic Registry | Implemented (integration suite passing on configured local infra) | — |
| SPEC-0009 | Structured DB DDL | Implemented (migration + backend integration suites passing on configured local infra) | — |
| SPEC-0010 | semantic_interpreter Worker | Implemented (tests passing) | — |
| SPEC-0011 | Deterministic Naming Enforcement | Implemented (16 tests pass; G6 released 2026-05-14) | — |

## Phase 1 Exit Criteria

- [ ] All Phase 1 specs `Status: Implemented`
- [ ] `eval_schema_conformance` passes
- [ ] `eval_event_chain_complete` passes
- [ ] `eval_idempotent_ingest` passes
- [ ] `eval_srp_isolation` passes
- [ ] `eval_fallback_coverage` passes
- [ ] Post-import smoke test passes
- [ ] Version tag: `v0.1.0`

---

## Completed Phases

_None yet._

---

## ADR Log (Recent)

| ADR | Title | Status |
|-----|-------|--------|
| ADR-0028 | Runtime Data and Logging Layout | Accepted |
| ADR-0029 | Agent Token Optimization via Offline Memory | Accepted |
| ADR-0030 | Pipeline Workspace for Agent Artifacts | Accepted |
| ADR-0031 | Cross-Source Stitching Completeness | Accepted |
| ADR-0032 | Two-Phase CPG Extraction (Structural → Deep) | Accepted |
| ADR-0033 | C-Family Shared Extractor Library | Accepted |
| ADR-0034 | Semantic Rule Engine for Fact-Level Annotation | Accepted |
