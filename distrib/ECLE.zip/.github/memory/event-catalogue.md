# Event Catalogue — Quick Reference

> **Source of truth:** `constitution/contracts/09-event-pipeline-contract.md` §3.
> Compact table for agents that need event names/payloads without loading the full contract.

---

## Phase 1 Events

| Event | Topic | Producer | Consumer(s) | Required Fields |
|---|---|---|---|---|
| `upload.received` | `ecle.upload.received` | Admin API | `scan_source` | `job_id`, `tenant_id`, `repo_id`, `artifact_path`, `content_types[]`, `repo_role` |
| `source.received` | `ecle.source.received` | API | `scan_source` | `source_type`, `source_ref`, `upload_id`, `tenant_id` |
| `repo.detected` | `ecle.repo.detected` | `scan_source` | `parse_repo` | `repo_id`, `repo_path`, `languages[]`, `upload_id`, `tenant_id` |
| `source.scanned` | `ecle.source.scanned` | `scan_source` | `link_contracts` | `upload_id`, `repo_count`, `tenant_id` |
| `file.ir_produced` | `ecle.file.ir_produced` | `parse_repo` | `persist_facts`, `build_graph` ★ | `artifact_path`, `file_id`, `repo_id`, `language`, `fidelity`, `used_fallback`, `content_hash`, `commit_sha` |
| `repo.ir_produced` | `ecle.repo.ir_produced` | `parse_repo` | `build_contract_registry` | `repo_id`, `file_count`, `failed_count`, `fallback_count` |
| `file.stored` | `ecle.file.stored` | `persist_facts` | `chunk_file`, `detect_dsl_mappings` ★ | `file_id`, `repo_id` |

## Phase 2 Events

| Event | Topic | Producer | Consumer(s) | Required Fields |
|---|---|---|---|---|
| `file.chunked` | `ecle.file.chunked` | `chunk_file` | `batch_embed` | `file_id`, `chunk_count`, `artifact_path` |
| `file.embedded` | `ecle.file.embedded` | `batch_embed` | `cluster_centroids` | `file_id`, `model_version`, `vector_ids[]` |

## Phase 3 Events

| Event | Topic | Producer | Consumer(s) | Required Fields |
|---|---|---|---|---|
| `graph.updated` | `ecle.graph.updated` | `build_graph` | `compute_topology` | `file_id`, `changed_file_ids[]`, `node_count`, `edge_count`, `repo_id` |
| `topology.updated` | `ecle.topology.updated` | `compute_topology` | `cluster_centroids`, `ontology_enricher` ★ | `repo_id`, `changed_cluster_ids[]`, `edge_count`, `scope`, `recompute` |
| `repo.indexed` | `ecle.repo.indexed` | `persist_facts` | `cross_repo_indexer` | `repo_id`, `tenant_id`, `file_count`, `cluster_count` |

## Phase 4 Events

| Event | Topic | Producer | Consumer(s) | Required Fields |
|---|---|---|---|---|
| `dsl.mapped` | `ecle.dsl.mapped` | `detect_dsl_mappings` | `ontology_enricher` | `file_id`, `concepts[]` |
| `ontology.enriched` | `ecle.ontology.enriched` | `ontology_enricher` | — | `file_id`, `concepts[]` |
| `re-embed.batch` | `ecle.re-embed.batch` | `sweep_coordinator` | `batch_embed` | `cluster_id`, `layer`, `model_version_new`, `file_ids[]` |

## Phase 5 Events

| Event | Topic | Producer | Consumer(s) | Required Fields |
|---|---|---|---|---|
| `contracts.registered` | `ecle.contracts.registered` | `build_contract_registry` | `link_contracts` | `repo_id`, `contract_count` |
| `cross.linked` | `ecle.cross.linked` | `link_contracts` | — | `upload_id`, `link_count`, `unresolved_count` |
| `feedback.given` | `ecle.feedback.given` | `ecle_feedback` MCP | `learning_analyzer` | `entity_id`, `entity_type`, `signal`, `query_id`, `subject`, `tenant_id` |
| `confidence.updated` | `ecle.confidence.updated` | `learning_analyzer` | — | `entity_id`, `old_accuracy`, `new_accuracy`, `reason` |
| `reindex.requested` | `ecle.reindex.requested` | Query layer | `scan_source` | `repo_id`, `tenant_id`, `reason`, `requested_at` |

★ = Fan-out: each consumer runs as a separate consumer group.
