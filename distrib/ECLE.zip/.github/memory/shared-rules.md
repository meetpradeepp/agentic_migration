# Shared Agent Rules

> **Source of truth:** Constitution contracts. This file extracts rules duplicated
> across 6–10 agents into a single reference (ADR-0029). All agents load this file
> instead of embedding their own copies.

---

## 1. TDD Order (Contract 02 §1, §4)

- Tests are written FIRST — committed as `test(<scope>):` before any `feat(<scope>):` commit
- Red phase: all tests MUST FAIL before implementation begins
- Green phase: minimum implementation to make tests pass
- Refactor phase: structural improvements under green tests only
- Reviewer verifies TDD order via `git log --oneline`

## 2. Anti-Pattern Quick Scan (Contract 10)

Before writing or reviewing code, grep for:
| Pattern to grep | Anti-pattern |
|---|---|
| Class with 3+ public methods doing unrelated things | A1 God class |
| `from ecle.workers.X import` inside another worker | A2 Cross-worker import |
| `httpx.post\|requests.post` targeting a worker URL | A2 Direct HTTP call |
| `class X(Y):` where Y is not genuinely polymorphic | A3 Inheritance for reuse |
| `ABC` with only one implementation and no second planned | A4 YAGNI |
| Same SQL/logic block in 2+ files | A5 DRY violation |
| `sqlite3.connect\|SQLiteBackend` in business logic | A6 Hardcoded backend |
| Module-level mutable variables (`_cache = []`) | A7 Global mutable state |
| `except:` or `except Exception as e: pass` | A9 Bare except |
| `f"SELECT.*{` or `"SELECT.*" +` | A10 SQL injection |
| `PASSWORD = "` or `API_KEY = "` | A11 Secrets in code |

## 3. Python File Standards (Contract 01 §2)

Every `.py` file MUST have:
```
"""<module> — <one-line description>. Implements: SPEC-NNNN"""
from __future__ import annotations
# stdlib → third-party → ecle (absolute imports only)
```

Every `test_*.py` file MUST have:
```
"""test_<module> — <description>. Implements: SPEC-NNNN. Tests: <target>"""
from __future__ import annotations
```

## 4. Commit Message Format (Contract 02 §4)

```
<type>(<scope>): <description> [Phase N]
```
Types: `feat` | `fix` | `test` | `refactor` | `docs` | `chore` | `perf`
- Present tense, imperative mood ("add", not "added")
- One logical change per commit
- Reference spec/ADR in commit body

## 5. Kafka Governance (Contract 09, ADR-0027)

- Workers communicate via Kafka events ONLY — no direct calls
- Topic naming: `ecle.{domain}.{action}` (e.g. `ecle.file.ir_produced`)
- Consumer group: `ecle.{worker_name}`
- `enable.auto.commit=False` — commit offset only after durable write
- Every event payload includes `X-Request-Id` and `X-Trace-Id`
- DLQ topic: `ecle.dlq.{event_type}`
- Workers are idempotent — same event twice = same DB state

## 6. Spec Traceability (Contract 02 §7)

- Every source file: module docstring with `Implements: SPEC-NNNN`
- Every test file: header with `Implements: SPEC-NNNN` and `Tests: <target>`
- Every commit body: reference to spec or ADR being implemented

## 7. Phase Discipline (Contract 17)

- Every spec has a `Phase:` header matching a phase in Contract 17
- No phase-N+1 work until phase-N exit criteria pass
- Components, workers, events must exist in the declared phase's deliverables
- If work doesn't fit current phase scope → defer to later phase

## 8. Configuration & Secrets (Contract 01 §6, Contract 14)

- All tunable values from `ecle.config.Settings` (Pydantic BaseSettings)
- Fixed constants in `ecle/constants.py`
- No secrets in code — environment variables only
- No hardcoded paths — everything from `settings`
- No `if settings.ECLE_TIER == ...` in application code

## 9. Error Handling (Contract 01 §5)

- Always name specific exception types
- Chain with `from exc` to preserve traceback
- Never use exceptions for flow control
- Custom exception hierarchy per module
- Workers: transient errors → retry with backoff; permanent → DLQ

## 10. No LLM in Runtime

ECLE 2.0 is deterministic. AI assists development only — never execution.
No LLM calls, no generative AI, no prompt templates in `src/ecle/`.

## 11. Inline Traceability (Contract 01 §10)

Every non-trivial line of code must be traceable by a human maintainer:

| What | Comment format |
|---|---|
| Acceptance criteria | `# AC-N: <brief description> (SPEC-NNNN)` |
| Error handling | `# Error: <condition> (SPEC-NNNN §Error handling)` |
| Contract rule | `# Contract NN §M: <rule summary>` |
| ADR decision | `# ADR-NNNN: <why this approach>` |
| Bug fix | `# Fix: <what> (SPEC-NNNN §Deviations DEV-NNN)` |
| Enhancement | `# Enhancement: <what> (SPEC-NNNN §Deviations ENH-NNN)` |
| TODO | `# TODO(SPEC-NNNN): <what>` — orphan TODOs banned |

## 12. Build Commands (Contract 01 §11)

```bash
uv sync --extra dev            # Install with dev tools
uv run ruff check src/ tests/  # Lint
uv run ruff format src/ tests/ # Format
uv run mypy src/ecle/          # Type check
uv run pytest tests/unit/ -v   # Unit tests
uv run pytest tests/ -v        # All tests
```

## 13. Naming Clarity Rule (first-pass quality)

- Use descriptive business-variable names by default; avoid single-letter names outside trivial loop indexes.
- Prefer intent-rich names tied to spec vocabulary (`tenant_id`, `repo_id`, `sql_query`, `db_connection`, `rule_loader`).
- Before final verification, perform a readability sweep to remove ambiguous names and avoid rename churn in follow-up passes.
