# ECLE 2.0 — Copilot Instructions

## Project Identity

ECLE 2.0 is a deterministic code intelligence engine. **No LLM at any runtime layer.**
Event-driven pipeline; Kafka (KRaft) as exclusive broker; all workers are Kafka consumer
processes. FACT (Fast / Accurate / Complete / Trustworthy) is the north star.

## The Constitution

The `constitution/` folder is the **single source of truth** for every design,
implementation, and operational decision. Read it before writing any code.

```
constitution/
  contracts/01-18    ← living rules enforced by CI + review
  schemas/           ← machine-readable data contracts
  adrs/ADR-0001-0031 ← immutable decision log
```

**HARD RULE: No code without a spec. No spec without constitution conformance.**

## SDLC Pipeline (Contract 02)

Every change — feature, bug fix, enhancement — follows this lifecycle:

```
Spec → Tests (Red) → Implementation (Green) → Review → Release
```

**Phase discipline (Contract 17):** All work is scoped to a phase. The current phase is
determined by which exit criteria have been met. The orchestrator enforces phase boundaries.

| Phase | Focus | Version tag |
|-------|-------|-------------|
| 1 | Foundation: Kafka + Parse + Structured DB + MCP tools | `v0.1.0` |
| 2 | Embedding + Vector Layers + Chunking | `v0.2.0` |
| 3 | Topology Graph + Impact Analysis + GraphQL | `v0.3.0` |
| 4 | Ontology + DSL + Cluster Centroids | `v0.4.0` |
| 5 | Cross-Repo Linking + Grounding + Feedback | `v0.5.0` |
| 6 | Enterprise Scale-Out + Admin Portal | `v1.0.0` |

## Agent Memory & Token Optimization (ADR-0029)

Agents load compact digests instead of full contracts to save context budget:

```
.github/memory/
  constitution-digest.md    ← compact digest of all 18 contracts
  shared-rules.md           ← common rules extracted from agents (TDD, anti-patterns, etc.)
  event-catalogue.md        ← event type quick reference from Contract 09
  phase-status.md           ← living doc: current phase, active specs, milestones
```

**Validator and spec-reviewer still load full contracts** — they are the safety net.

## Pipeline Workspace (ADR-0030)

In-flight artifacts live in a structured workspace:

```
.github/pipeline/
  state.json                ← current pipeline state
  plans/                    ← implementation plans
  workspace/current/        ← active work area
    spec.md                 ← active spec
    plan.json               ← active plan
    adrs/                   ← ADRs referenced by the spec
    reviews/                ← review and validation reports
    subtasks/               ← per-subtask working state
```

Orchestrator creates workspace at G0, populates spec + ADRs at G1, clears at G6.

The `.github/agents/orchestrator.agent.md` manages the 7-gate pipeline:

| Gate | Purpose | Agent |
|------|---------|-------|
| G0 | Triage & classify | orchestrator |
| G1 | Write spec/ADR | @spec-writer, @adr-writer, @spec-patcher |
| G1→G2 | Validate spec compliance | @validator |
| G2 | Review spec | @spec-reviewer |
| G2→G3 | Validate review completeness | @validator |
| G3 | Plan subtasks | @planner |
| G3→G4 | Validate plan compliance | @validator |
| G4 | TDD implementation | @coder, @tester, @refactor |
| G4→G5 | Validate code compliance | @validator |
| G5 | Code review + test audit | @code-reviewer, @tester, @validator |
| G6 | Release | @release-manager, @validator |

## Agent Directory

| Agent | File | Role |
|-------|------|------|
| orchestrator | `.github/agents/orchestrator.agent.md` | Gate state machine, constitution enforcer |
| spec-writer | `.github/agents/spec-writer.agent.md` | Writes new specs (Contract 02 §2 format) |
| spec-patcher | `.github/agents/spec-patcher.agent.md` | Amends existing specs for fixes/enhancements |
| spec-reviewer | `.github/agents/spec-reviewer.agent.md` | 15-point constitution conformance review |
| adr-writer | `.github/agents/adr-writer.agent.md` | Writes ADRs using constitution template |
| planner | `.github/agents/planner.agent.md` | Breaks specs into TDD subtasks |
| coder | `.github/agents/coder.agent.md` | TDD implementation, one subtask at a time |
| tester | `.github/agents/tester.agent.md` | Test quality, TDD order, coverage, eval suites |
| refactor | `.github/agents/refactor.agent.md` | Safe structural improvements under green tests |
| validator | `.github/agents/validator.agent.md` | Constitution compliance scanner at every gate |
| code-reviewer | `.github/agents/code-reviewer.agent.md` | 9-point review (Contract 02 §6) |
| release-manager | `.github/agents/release-manager.agent.md` | Release gates, CHANGES.md, version tags |

## Non-Negotiable Rules

1. **Spec before code.** Every change has a spec at `specs/phase-N/SPEC-NNNN-<name>.md`.
2. **Tests before implementation.** `test(...)` commit precedes `feat(...)` commit.
3. **Constitution is law.** Contract violations block merge. No exceptions.
4. **No LLM in runtime.** ECLE 2.0 is deterministic. AI assists development, not execution.
5. **No direct worker calls.** Workers communicate via Kafka events only (ADR-0027).
6. **Anti-patterns are banned.** Contract 10 items are rejected on sight.
7. **Schema changes need ADRs.** No schema change without a corresponding ADR.
8. **No scope creep.** If work grows beyond spec, create a new spec.
9. **Phase discipline.** Work must target the current phase (Contract 17). Future-phase work is deferred until entry criteria are met.
10. **No phase-skipping.** Phase N+1 cannot begin until Phase N exit criteria pass.

## Work Types

| Type | Spec action | Example |
|------|------------|---------|
| NEW_FEATURE | New spec created | "Add Kafka WorkerBase class" |
| SPEC_REWRITE | Old spec superseded, new spec created | "Rewrite SPEC-0003 for Kafka" |
| BUG_FIX | Existing spec amended (Deviations section) | "Fix offset commit timing" |
| ENHANCEMENT | Existing spec extended | "Add DLQ routing to WorkerBase" |
| CONSTITUTION_CHANGE | ADR first, then contract/schema update | "Add new event type" |

## File Conventions

```
specs/phase-N/SPEC-NNNN-<name>.md     ← spec documents
constitution/adrs/ADR-NNNN-<name>.md   ← architecture decisions
constitution/contracts/NN-<name>.md    ← living contracts
constitution/schemas/<name>            ← data schemas
src/ecle/<module>/<name>.py            ← source code
tests/unit/test_<module>.py            ← unit tests
tests/integration/test_<flow>.py       ← integration tests
.github/agents/<name>.agent.md         ← agent definitions
.github/pipeline/state.json            ← current pipeline state
.github/pipeline/plans/                ← implementation plans
CHANGES.md                             ← change registry
```

## How to Start Working

1. Tell the orchestrator what you want to build or fix
2. It classifies the work and declares the mode (FULL / PATCH)
3. You approve the classification
4. The pipeline proceeds gate by gate, with your approval at each stop
5. No gate is skippable. No approval is assumed.
