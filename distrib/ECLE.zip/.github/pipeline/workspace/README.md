# Pipeline Workspace

This directory contains in-flight artifacts for the active pipeline work item.
Managed by the orchestrator agent per ADR-0030.

## Structure

```
workspace/
  current/          ← active work (cleared at G6 release)
    spec.md         ← the active spec being implemented
    plan.json       ← the active plan
    adrs/           ← ADRs referenced by the spec (copied at G1)
    reviews/        ← review and validation reports
    subtasks/       ← per-subtask working state
```

## Rules

1. **Orchestrator creates** `current/` at G0
2. **Spec and ADRs populated** at G1 — orchestrator copies spec and referenced ADRs
3. **Plan populated** at G3 — planner writes, orchestrator copies
4. **Agents read from here** — no searching required
5. **Cleared at G6** — workspace is ephemeral
