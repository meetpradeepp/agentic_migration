# Code Review Report — SPEC-0011

**Reviewer:** code-reviewer agent
**Date:** 2026-05-14
**Verdict:** FAIL

---

## 9-Point Checklist

| # | Check | Result | Notes |
|---|-------|--------|-------|
| 1 | Spec conformance | ❌ | `run_checker()` exits `1` instead of `2` for ECLE001-PARSE (syntax error) findings — violates Error Handling row 2 |
| 2 | Interface contract | ✅ | All public signatures match spec exactly; frozen dataclasses correct |
| 3 | Coding standards | ❌ | Unused import `Sequence` (naming_checker.py:21); stdlib import order violation (naming_checker.py:15–17) |
| 4 | Test coverage | ❌ | T13 is named "exits_two" but never asserts CLI exit code; no integration test covers CLI exit-2 on syntax-error input |
| 5 | No anti-patterns | ✅ | No God class, no cross-worker imports, no LLM, no hardcoded secrets, no SQL injection vectors |
| 6 | Event contract | ✅ | N/A — no Kafka events in scope |
| 7 | No orphan data paths | ✅ | N/A — no DB tables written or read |
| 8 | Acceptance criteria covered | ✅ | All AC-1 through AC-11 have corresponding tests; all 5 error rows have tests (T12–T16) |
| 9 | Test traceability | ✅ | Both test files carry `# Implements: SPEC-0011` header; test names follow `test_<function>_<scenario>` format |

---

## ECLE-Specific Checks

| Check | Result | Notes |
|-------|--------|-------|
| TDD order | ❌ | `git log --oneline` shows 3 broad commits ("first commit", "planning update 1", "token optimization & spec implementation"). No `test(<scope>):` commit precedes `feat(<scope>):` commit. Commit format does not match required `<type>(<scope>): <description> [Phase N]` |
| No LLM usage | ✅ | AST-only evaluation confirmed; no network or model calls at runtime |
| Kafka consumers | ✅ | N/A for this spec |
| Security (OWASP) | ✅ | No hardcoded credentials, no SQL, parameterized file paths, no logging of sensitive data |
| Scope creep | ✅ | Implementation stays within spec boundaries; no undocumented public API surface |

---

## Violations

### V1 — [Check 1 / Spec Conformance]
**File:** `scripts/run_naming_gate.py:196`
**Code:**
```python
violation_findings = [f for f in findings if f.rule_id not in (RULE_ID_ECLE001_ERROR,)]
```
**Issue:** `RULE_ID_ECLE001_PARSE = "ECLE001-PARSE"` is **not** in the exclusion set `(RULE_ID_ECLE001_ERROR,)`.
Therefore, when `check_source()` returns an ECLE001-PARSE finding for a syntax-error file,
that finding lands in `violation_findings` and `run_checker()` returns `1`, not `2`.

**Spec requirement:** Error Handling row 2 — *"Python source has syntax error → … fail run with exit `2`"*

**Required fix:** Add `RULE_ID_ECLE001_PARSE` to the exclusion check, and route it to the `return 2`
branch alongside `RULE_ID_ECLE001_ERROR`. For example:
```python
_ERROR_RULE_IDS = frozenset({RULE_ID_ECLE001_ERROR, RULE_ID_ECLE001_PARSE})
has_parse_errors = any(f.rule_id == RULE_ID_ECLE001_PARSE for f in findings)

violation_findings = [f for f in findings if f.rule_id not in _ERROR_RULE_IDS]

if has_unreadable or has_parse_errors or internal_errors:
    return 2
if violation_findings:
    return 1
return 0
```

---

### V2 — [Check 3 / Coding Standards — Unused Import]
**File:** `src/ecle/linting/naming_checker.py:21`
**Code:**
```python
from typing import Sequence
```
**Issue:** `Sequence` is imported but never referenced anywhere in the file.
`ruff` (rule F401) will flag this as an unused import.
**Contract:** Contract 01 §11 — *"uv + ruff … all config in pyproject.toml; pre-commit hooks enforce all rules"*

**Required fix:** Remove line 21 (`from typing import Sequence`).

---

### V3 — [Check 3 / Coding Standards — Import Order]
**File:** `src/ecle/linting/naming_checker.py:15–17`
**Code:**
```python
import ast
import tokenize
import io
```
**Issue:** Stdlib imports are not alphabetically sorted. Correct order is `ast → io → tokenize`.
`ruff`/`isort` (rule I001) will flag this.
**Contract:** Contract 01 §2 — *"Import order: stdlib → third-party → ecle"* (ruff/isort enforced)

**Required fix:** Reorder to:
```python
import ast
import io
import tokenize
```

---

### V4 — [Check 4 / Test Coverage — T13 Missing Exit-Code Assertion]
**File:** `tests/unit/test_naming_checker.py:331`
**Test name:** `test_syntax_error_source_emits_parse_rule_and_exits_two`
**Issue:** The test name claims "exits_two" but the test only calls `checker.check_source()` (a
pure Python method that returns findings, not an exit code). **Exit code `2` is never asserted.**
There is also no integration-level test in `tests/integration/test_naming_gate_ci_stage1.py`
that invokes the CLI with a syntax-error file and asserts `returncode == 2`.

**Spec requirement:** Error Handling row 2 — *"fail run with exit `2`"*

**Required fix (two steps):**
1. Add an integration test (e.g., `TestT13SyntaxErrorFileExitsTwoCLI`) in
   `tests/integration/test_naming_gate_ci_stage1.py` that writes a broken Python file to
   `tmp_path`, calls `_run_gate(mode="ci", ...)`, and asserts `result.returncode == 2`.
2. Rename or update the unit test to accurately describe what it covers:
   `test_syntax_error_source_emits_ecle001_parse_finding` (remove misleading "exits_two").

---

### V5 — [TDD Order / Contract 02 §4]
**Evidence:** `git log --oneline` returns:
```
6622c5b token optimization & spec implementation
ecdf173 planning update 1
edc566e first commit
```
None of the commit messages follow the required `<type>(<scope>): <description> [Phase N]` format.
No `test(<scope>):` commit precedes any `feat(<scope>):` commit in the log.
**Contract:** Contract 02 §4 — *"TDD order: `test(...)` commit MUST precede `feat(...)` commit"*

**Note for @release-manager:** Commit history cannot be amended post-push without force push
(requires team approval). Log this as a process deviation in the spec `## Deviations` section.
For future specs, ensure granular commits are made during G4.

---

## Deviations from Spec (for spec-patcher once PASS is reached)

The following implementation choices differ from exact spec wording but are **not blocking**:

| # | Location | Spec wording | Actual | Severity |
|---|----------|-------------|--------|----------|
| D1 | `scripts/run_naming_gate.py` — `main()` | `def main() -> int:` | `def main(argv: list[str] \| None = None) -> int:` | Non-blocking — optional parameter enables unit testability |
| D2 | `scripts/run_naming_gate.py` — `_EXCLUDE_DIR_NAMES` | Glob `"*.egg-info"` in frozenset | The frozenset literal `"*.egg-info"` never matches as a literal directory name; the actual check is `endswith(".egg-info")` — the frozenset entry is dead code | Non-blocking — behaviour is correct, but dead entry adds confusion |
| D3 | `scripts/run_naming_gate.py` — `run_checker()` | `mode: Literal["ci", "local"]` used to control behaviour | `mode` parameter is accepted but not used in function body (CI and local paths are identical, which satisfies AC-10 parity) | Non-blocking — ruff ARG002 warning; acceptable for current spec scope |
| D4 | `src/ecle/linting/naming_checker.py` — `_SymbolUseContextVisitor.visit_Assign` | "symbol participates exclusively in numeric expressions" | Assignment RHS is unconditionally entered with `_in_math_expr=True`, meaning `x = some_string + other_string` would not flag `x` as non-math (false negative for string `+`). Type-unaware trade-off in static analysis. | Non-blocking — spec says "deterministic"; behaviour is deterministic, just permissive for string `+` |

---

## Verdict

**FAIL**

Three blocking violations must be resolved before G6:

1. **V1** — `run_checker()` exits `1` instead of `2` for syntax-error files. Fix in `scripts/run_naming_gate.py`.
2. **V2 + V3** — Unused `Sequence` import and misordered stdlib imports in `src/ecle/linting/naming_checker.py`.
3. **V4** — T13 does not assert CLI exit code `2`; integration test for syntax-error exit code is missing.

Return to `@coder` with these violations. After fixes, re-run all 17 tests and resubmit for G5 re-review.
