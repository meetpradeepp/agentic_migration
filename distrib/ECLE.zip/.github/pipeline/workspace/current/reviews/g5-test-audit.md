# G5 Test Audit — SPEC-0011

**Audited by:** @tester  
**Date:** 2026-05-14  
**Spec:** SPEC-0011 — Deterministic Naming Enforcement  
**Test files audited:**
- `tests/unit/test_naming_checker.py`
- `tests/integration/test_naming_gate_ci_stage1.py`

---

## T3 — TDD Order

| Check | Result | Notes |
|-------|--------|-------|
| Tests structured to fail without implementation | **PASS** | Both test files import from `ecle.linting.naming_checker` and invoke `scripts/run_naming_gate.py`; an absent module or script would yield `ImportError`/`FileNotFoundError` before any assertion. |
| Each test targets a single AC | **PASS** | All 16 test methods map 1:1 to a unique AC or error row per the spec's `## Tests required` table. No test combines unrelated criteria. |
| Plan TDD order respected (tests before impl subtasks) | **WARN** | All four SPEC-0011 files are **uncommitted** (git status: `??`). There are no `test(linting):` commits preceding any `feat(linting):` commit, which is the formal Contract 02 §7 rule 13 requirement. Filesystem timestamps are consistent with TDD order: unit test created 14:47, integration test 14:48, `naming_checker.py` 14:50, `run_naming_gate.py` 14:53. The plan (`SPEC-0011-plan.json`, committed in `ecdf173`) correctly sequences ST-0011-T01/T02/T03 before ST-0011-I01/I02/I03. **Action required: commit test files first with `test(linting):` messages, then commit implementation files with `feat(linting):` messages, before G6.** |

---

## T4 — Eval Suite Coverage

### Acceptance Criteria Coverage

| AC | Test ID | Test method | PASS/FAIL |
|----|---------|-------------|-----------|
| AC-1 (one-letter symbol flagged, non-trivial scope) | T1 | `test_check_source_flags_one_letter_symbol_in_non_trivial_scope` | **PASS** |
| AC-2 (one-letter symbol skipped, trivial scope) | T2 | `test_check_source_skips_one_letter_symbol_in_trivial_scope` | **PASS** |
| AC-3 (denylist symbol `tmp` flagged) | T3 | `test_check_source_flags_ambiguous_denylist_symbol` | **PASS** |
| AC-4 (tiny loop index `i` allowed) | T4 | `test_check_source_allows_tiny_loop_index` | **PASS** |
| AC-5 (loop index `i` flagged when used outside loop) | T5 | `test_check_source_flags_loop_index_used_outside_loop` | **PASS** |
| AC-6 (math-only `x`/`y` not flagged) | T6 | `test_check_source_allows_math_only_symbol_context` | **PASS** |
| AC-7 (byte-identical output, determinism) | T7 | `test_report_is_byte_identical_for_same_input` | **PASS** |
| AC-8 (CI exits 1 with findings) | T8 | `test_ci_mode_returns_non_zero_on_findings` | **PASS** |
| AC-9 (CI exits 0 on clean input) | T9 | `test_ci_mode_returns_zero_on_clean_input` | **PASS** |
| AC-10 (CI and local modes produce equal finding set) | T10 | `test_pre_commit_and_ci_findings_match_for_same_files` | **PASS** |
| AC-11 (finding payload has all required fields) | T11 | `test_finding_schema_contains_required_fields` | **PASS** |

### Error Handling Coverage

| Error condition | Test ID | Test method | PASS/FAIL |
|----------------|---------|-------------|-----------|
| Row 1 — unreadable file exits 2 | T12 | `test_unreadable_file_exits_two` | **SKIP** (Windows dev; `@pytest.mark.skipif` on `win32` outside CI) |
| Row 2 — syntax error emits ECLE001-PARSE | T13 | `test_syntax_error_source_emits_parse_rule_and_exits_two` | **PASS** |
| Row 3 — missing report directory auto-created | T14 | `test_missing_report_directory_is_created` | **PASS** |
| Row 4 — invalid mode argument exits 2 | T15 | `test_invalid_mode_exits_two` | **PASS** |
| Row 5 — scope evaluation exception yields diagnostic | T16 | `test_scope_evaluation_exception_returns_exit_two_with_diagnostic` | **PASS** |

### Test ID Completeness (spec `## Tests required` table)

All 16 test IDs T1–T16 are present and match the spec table. No spec-required test is absent.

### Test Run Summary

```
Platform: win32, Python 3.13.0, pytest 8.4.2
Collected: 16 items
Passed:    15
Skipped:   1  (T12 — Windows dev platform guard)
Failed:     0
Duration:  1.32 s
```

### Coverage

```
src/ecle/linting/__init__.py         100%
src/ecle/linting/naming_checker.py    88%   (35 miss, 15 partial branches)
                                            Lines not covered: 96-97, 126, 128,
                                            143-144, 235, 240-241, 277, 295,
                                            338-341, 344-353, 414, 429, 442,
                                            444, 459-460, 498-517, 612, 683
TOTAL                                 88%   (≥ 80% threshold: MET)
```

`scripts/run_naming_gate.py` is not a Python package module and was exercised via subprocess in integration tests; its logical coverage is captured by T8–T10, T12–T15 passing. Direct statement coverage unavailable but all CLI exit paths (0, 1, 2) are exercised.

---

## Specific NamingChecker Test Source Checks

| Check | Verdict | Detail |
|-------|---------|--------|
| T4 — tiny loop index source qualifies | **PASS** | `for i, item in enumerate(items): index_map[i] = item` — 1-line loop body (≤ 3); `i` not referenced after loop end. |
| T5 — loop index used outside loop | **PASS** | `return last_index, found_count, active_sum, i` — `i` appears in the return statement after the `for` block, outside any loop scope. |
| T6 — math-only symbol `x`/`y` | **PASS** | `x = point_b[0] - point_a[0]` and `y = point_d[1] - point_c[1]`; both symbols appear exclusively in numeric arithmetic (`x * x + y * y`). No assignment to a collection, dict, or non-numeric target. |
| T16 — monkeypatch targets patchable attribute | **PASS** | Test patches `checker_module._analyse_scope` (module-level function) if present, then falls back to `checker_module.NamingChecker._compute_scope_metrics`. Both are patchable via `monkeypatch.setattr`. The dual-path approach is robust regardless of internal refactoring. |

---

## T7 — Determinism / Byte Identity

T7 calls `checker.check_source()` twice on identical input, serialises both result lists with `json.dumps(..., sort_keys=True)` after stable-sorting by `(path, line, column, symbol)`, and asserts string equality — which is equivalent to byte identity for JSON output. **PASS.**

---

## I/O Isolation

| Check | Verdict |
|-------|---------|
| Unit tests — no real file I/O to production paths | **PASS** — all sources are `textwrap.dedent()` strings passed directly; `path` argument is `"fake.py"` / `"broken.py"` etc. (never written to disk). |
| Unit tests — no network calls | **PASS** — checker is pure AST, no network calls observable. |
| Unit tests — < 5 s each | **PASS** — full unit suite completed in 0.66 s (10 tests). |
| Integration tests — use `tmp_path` | **PASS** — every integration test fixture calls `tmp_path / "..."` for all file creation. No writes outside pytest tmp directory. |
| Integration tests — isolated from production data | **PASS** — no reference to `ecle-data/` or real repository paths. |

---

## Issues Found

1. **WARN — No `test(linting):` commits exist before `feat(linting):` commits.**  
   All SPEC-0011 files are untracked. Contract 02 §7 rule 13 requires separate commits in the correct order. Filesystem timestamps confirm tests were authored first, but git commit history must formalise this before G6. Required commits (in order):
   ```
   test(linting): add unit tests T1-T7 T11 for NamingChecker.check_source [Phase 1]
   test(linting): add unit tests T13 T16 for NamingChecker error handling [Phase 1]
   test(linting): add integration tests T8-T10 T12 T14 T15 for naming gate CLI [Phase 1]
   feat(linting): implement NamingChecker with ECLE001 rule and AST scope analysis [Phase 1]
   feat(linting): implement run_naming_gate.py CLI with JSON report writer [Phase 1]
   ```

2. **WARN — T12 skipped on Windows developer machines.**  
   `test_unreadable_file_exits_two` uses a `@pytest.mark.skipif` guard for `win32` outside CI. The test will run in CI (Linux runner). This is acceptable for error row 1, but the skip must not prevent error row 1 coverage in the CI gate report. Recommend adding a note to CHANGES.md or CI config confirming T12 executes on the CI runner.

3. **INFO — 12% uncovered lines in `naming_checker.py` (88% coverage).**  
   Coverage exceeds the 80% general threshold and the 95% threshold does not apply here (this is not interface/schema code). The uncovered lines (498–517, 344–353) likely correspond to edge paths in boundary-call detection and fall-through clauses. No action required at this threshold, but worth monitoring if implementation grows.

---

## Verdict

**PASS with conditions** — the test suite is functionally complete (all 16 spec-required tests present, 15/16 execute and pass, 1 conditionally skipped on Windows with CI execution guaranteed), I/O isolation is clean, determinism is verified, each test maps to exactly one AC, and coverage meets the 80% threshold at 88%.

**One required action before G6:**  
Formalise TDD order by splitting the uncommitted work into separate `test(linting):` and `feat(linting):` commits (in that order) as specified in `SPEC-0011-plan.json`. This is required by Contract 02 §7 rule 13 and must be completed before the release gate.
