﻿# Spec Review Report — SPEC-0010 (Second Pass)

**Reviewer:** spec-reviewer agent
**Date:** 2026-05-12
**Review pass:** Second pass (re-review after first-pass REJECTED)
**Spec file:** `specs/phase-1/SPEC-0010-semantic-interpreter-worker.md`
**Work type:** NEW_FEATURE
**Governing ADR:** ADR-0034 (Semantic Rule Engine for Fact-Level Annotation)
**Companion contract:** Contract 20 (Semantic Rule Engine Contract)
**Verdict:** CONDITIONAL PASS

---

## Summary

SPEC-0010 (Semantic Interpreter Worker) has been substantially revised since the first-pass
REJECTED review. Both FAIL findings are fully resolved: the `Amends` section now formally
documents the Contract 09 §3 amendments, and those amendments are confirmed present in the
live contract; `AnnotationRule` carries load-time `@model_validator` comments [V1] and [V2]
aligned with Contract 20 §5; AC-15 and T-23 are correctly revised to assert `ValidationError`
at `rule_loader.load()` not at evaluation time. All four WARNs are acceptably addressed.

One new minor WARN (W5) was identified during this pass: the [V2] validator comment covers
named capture-group references (`{match.group_name}`) but omits the parallel Contract 20 §5
requirement to also validate positional group count (`{match[N]}`) at load time. This does
not block implementation — a positional-group mismatch degrades gracefully to
`PermanentWorkerError` at evaluation time — but the gap should be closed before the coder
begins work on `rule_schema.py`.

---

## Summary Table (all 28 checks)

| # | Check | Result | Notes |
|---|-------|--------|-------|
| F1 | File location matches `specs/phase-N/SPEC-NNNN-<name>.md` | PASS | |
| F2 | All mandatory sections present | PASS | |
| F3 | `Status: Draft` | PASS | |
| F4 | `Implements:` references correct ADR(s) | PASS | ADR-0034 + ADR-0027 |
| F5 | `Depends on:` lists all dependency specs | PASS | SPEC-0001, SPEC-0008, SPEC-0009 |
| F6 | SPEC number is sequential and unique | PASS | |
| I1 | Function signatures use Contract 01 type annotation style | PASS | |
| I2 | Every Kafka event references a topic in Contract 09 | PASS | All three events confirmed in Contract 09 §3 |
| I3 | Every DB table references a table in Contract 15 | PASS | |
| I4 | Schema references match `constitution/schemas/` files | PASS | Deferral explicitly noted in Out of scope |
| I5 | New events/tables/schemas — amendment to contracts noted | PASS | Amends section covers all four Contract 09 §3 amendments |
| B1 | Every behaviour step is atomic and testable | PASS | 14 numbered steps |
| B2 | Kafka offset commit explicit (after durable write) | PASS | Steps 8 and 14 explicit |
| B3 | Error handling covers all external interactions | PASS | 8 error rows |
| B4 | No Contract 10 anti-patterns; conforms to Contract 20 §5 | PASS | Both validators [V1] and [V2] present |
| B5 | Cross-cutting references valid | PASS | tenant_id confirmed in file.stored payload (FAIL 1 fix) |
| T1 | Every AC has >=1 test | PASS | All 22 ACs mapped to tests |
| T2 | Every error condition has >=1 test | PASS | All 8 error rows covered |
| T3 | Test file paths follow Contract 01 naming | PASS | |
| T4 | Test types match Contract 03 pyramid | PASS | T-40, T-41, T-42 added; integration ratio improved |
| A1 | No LLM usage at any layer | PASS | Fully deterministic |
| A2 | No direct worker-to-worker calls | PASS | |
| A3 | Kafka-only inter-component communication | PASS | |
| A4 | Worker is independently deployable | PASS | |
| A5 | FACT impact assessed for all four dimensions | PASS | |
| A6 | Phase scope valid | PASS | All Phase 1 |
| A7 | No future-phase dependencies | PASS | |
| — | [V2] positional group count omitted from load-time validator | WARN (W5) | See below |

---

## Detailed Checks

### Section 1: Format Compliance (Contract 02 §2)

| # | Check | Result | Notes |
|---|-------|--------|-------|
| F1 | File location `specs/phase-1/SPEC-0010-semantic-interpreter-worker.md` | PASS | Exactly matches `specs/phase-N/SPEC-NNNN-<name>.md` |
| F2 | All mandatory sections present | PASS | Problem, Decision, Interface contract, Behaviour, Acceptance criteria, Error handling, Tests required, Out of scope, Deviations — all present |
| F3 | `Status: Draft` (correct for NEW_FEATURE pre-approval) | PASS | `**Status:** Draft` |
| F4 | `Implements: ADR-0034, ADR-0027` | PASS | ADR-0034 governs the rule engine; ADR-0027 constrains autonomy model |
| F5 | `Depends on: SPEC-0001, SPEC-0008, SPEC-0009` | PASS | SPEC-0009 declares semantic_annotations DDL; SPEC-0008 declares WorkerBase; SPEC-0001 declares Settings |
| F6 | SPEC-0010 sequential and unique | PASS | No collision found |

---

### Section 2: Interface & Contract Alignment

| # | Check | Result | Notes |
|---|-------|--------|-------|
| I1 | Type annotations follow Contract 01 | PASS | `from __future__ import annotations` on every module; all public methods annotated; Pydantic v2 models properly typed |
| I2 | Every Kafka event in Contract 09 §3 | PASS | `ecle.file.stored` — semantic_interpreter_file consumer confirmed; `ecle.repo.indexed` — semantic_interpreter_repo consumer confirmed; `ecle.facts.annotated` — full event row confirmed with correct payload |
| I3 | Every DB table in Contract 15 | PASS | semantic_annotations (SPEC-0009/ADR-0034); function_facts, file_tables, function_table_ops, repositories (Contract 15); worker_lifecycle (SPEC-0008) |
| I4 | Schema references match constitution/schemas/ | PASS | Out of scope explicitly states "SQL schema file constitution/schemas/semantic_annotations.sql is deferred to the release-manager step; its absence does not block this spec" |
| I5 | New events/tables — amendment to contracts noted | PASS | Amends section: Contract 09 §3 — adds semantic_interpreter_file to file.stored consumers; adds tenant_id to file.stored payload; adds semantic_interpreter_repo to repo.indexed consumers; adds facts.annotated event row |

---

### Section 3: Behaviour & Correctness

| # | Check | Result | Notes |
|---|-------|--------|-------|
| B1 | Every behaviour step atomic and testable | PASS | 14 numbered steps (3 startup, 5 file trigger, 6 repo trigger); each maps to >=1 AC |
| B2 | Kafka offset commit explicit | PASS | Step 8: "Offset committed ONLY after all db.upsert() calls succeed"; Step 14: "Offset committed ONLY after ecle.facts.annotated produced and flushed"; consumer.commit(asynchronous=False) |
| B3 | Error handling covers all external interactions | PASS | 8 rows: invalid YAML (base/tenant/repo), repositories query, pattern eval exception, unresolved substitution, co-occurrence row limit, upsert failure, Kafka produce failure |
| B4 | No Contract 10 anti-patterns; conforms to Contract 20 §5 | PASS | 5-module SRP; psycopg2.sql.Identifier for SQL identifiers; all exceptions chained; [V1] and [V2] validators documented in AnnotationRule |
| B5 | Cross-cutting references valid | PASS | tenant_id confirmed in file.stored payload (fixed as part of FAIL 1 resolution — Contract 09 §3 amendment) |

---

### Section 4: Testability

| # | Check | Result | Notes |
|---|-------|--------|-------|
| T1 | Every AC has >=1 test | PASS | AC-01 to AC-21 all mapped; AC-09 now unambiguous (W1 fix); AC-15 correctly revised to load-time ValidationError |
| T2 | Every error condition has >=1 test | PASS | T-15, T-35, T-36, T-37, T-23, T-22, T-29, T-38 |
| T3 | Test file paths follow Contract 01 naming | PASS | test_rule_schema.py, test_rule_loader.py, test_evaluator.py, test_worker.py, test_semantic_interpreter_integration.py |
| T4 | Test types match Contract 03 pyramid | PASS | ~35 unit + 7 integration (T-24 to T-26, T-40 to T-42) + 1 eval = 43 tests; integration ratio ~16% (improved from 7.7%) |

---

### Section 5: Architecture Governance

| # | Check | Result | Notes |
|---|-------|--------|-------|
| A1 | No LLM usage | PASS | Entirely deterministic; glob/regex matching only |
| A2 | No direct worker-to-worker calls | PASS | Behaviour invariants explicit; eval_async_coupling CI gate; AC-20 + T-39 |
| A3 | Kafka-only inter-component communication | PASS | Consumes and emits via Kafka only |
| A4 | Worker independently deployable | PASS | ADR-0034 confirms independent Dockerfile, K8s Deployment, ScaledObject |
| A5 | FACT impact all four dimensions | PASS | Problem section has dedicated FACT impact block: Fast, Accurate, Complete, Trustworthy |
| A6 | Phase scope valid | PASS | Phase 1; all workers, events, tables confirmed Phase 1 |
| A7 | No future-phase dependencies | PASS | Phase 2+ mentioned only in Out of scope as downstream consumer |

---

## Re-verification of Previous FAIL Findings

### FAIL 1 — Contract 09 §3 not amended — RESOLVED

**Previous finding:** The spec introduced two new consumer groups and a new event without
formally documenting amendments to Contract 09 §3, and without updating the live contract.

**Fix verified:**

The Amends section now states:
> "**Contract 09 §3** — adds `semantic_interpreter_file` to `file.stored` consumers; adds
> `tenant_id` to `file.stored` payload; adds `semantic_interpreter_repo` to `repo.indexed`
> consumers; adds `facts.annotated` event row."

Verification against live Contract 09 §3:

| Amendment declared | Status in contract |
|---|---|
| semantic_interpreter_file added to file.stored Consumed by | CONFIRMED — present with star (fan-out) |
| tenant_id added to file.stored payload required fields | CONFIRMED — file_id, repo_id, tenant_id listed |
| semantic_interpreter_repo added to repo.indexed Consumed by | CONFIRMED — present with star (fan-out) |
| facts.annotated event row added | CONFIRMED — full row present; payload: repo_id, tenant_id, annotation_count, rule_ids[], annotated_at, X_Request_Id, X_Trace_Id |

FAIL 1 is FULLY RESOLVED.

---

### FAIL 2 — AnnotationRule missing load-time validators [V1] and [V2] — RESOLVED

**Previous finding:** AnnotationRule had no validator for co_touch/target mismatch [V1] and
no validator for unresolvable named capture references [V2]. Both conditions silently reached
evaluation time instead of being caught at load time per Contract 20 §5.

**Fix verified in Interface contract (rule_schema.py AnnotationRule):**

```
# @model_validator(mode="after") [V1]: if isinstance(match, CoOccurrenceMatch) and
#   target != "function_table_ops": raise ValidationError(
#   "co_touch match requires target='function_table_ops'") — Contract 20 §5, AC-18
# @model_validator(mode="after") [V2]: for regex patterns (match.pattern starts with
#   "re:"), parse named capture groups from compiled regex; for each
#   "{match.<name>}" reference in annotate values, verify <name> is a named group;
#   raise ValidationError if any reference is unresolvable — Contract 20 §5/§6.9, AC-15
```

[V1] verification:
- Validator comment present in AnnotationRule
- AC-18 tests ValidationError on co_touch with target: file_tables at RuleFile validation time
- T-07 test_invalid_cooccurrence_on_file_tables covers this at Pydantic validation

[V2] verification (named group case):
- Validator comment present in AnnotationRule
- AC-15 revised — asserts ValidationError raised "at load time" during rule_loader.load()
- T-23 renamed test_unresolved_named_group_fails_at_load; asserts ValidationError during load()

FAIL 2 is RESOLVED. A partial-coverage gap in [V2] (positional groups) is documented as W5.

---

## Re-verification of Previous WARN Findings

### W1 — AC-09 ambiguity — RESOLVED

**Previous finding:** AC-09 was ambiguous whether deduplication was at the evaluator or DB layer.

**Fix verified:** AC-09 now reads:
> "deduplication applied at write time by evaluator.evaluate_file() before db.upsert() is
> called; only one AnnotationResult per (target_id, rule_id-A) pair reaches the DB —
> Contract 20 §4 Rule 2"

Deduplication is explicitly at the evaluator level before any DB call. The phrase "rule_id-A"
(meaning "the winning rule's rule_id") is slightly informal but unambiguous in context.
RESOLVED — no action required.

---

### W2 — Integration test ratio below Contract 03 target — RESOLVED

**Previous finding:** 3 integration tests (7.7%); target 20%. Co-occurrence, applies_to,
and multi-tier paths had no integration coverage.

**Fix verified:** Three integration tests added:
- T-40 test_end_to_end_repo_trigger_cooccurrence — repo trigger + co-occurrence + ecle.facts.annotated
- T-41 test_end_to_end_applies_to_pre_filter_real_db — applies_to against real repositories table
- T-42 test_end_to_end_multi_tier_precedence — base vs repo tier full pipeline

Integration ratio: 7 tests of ~43 total = ~16%. Still below the 20% target but all three
previously-uncovered critical paths now have integration coverage. ACCEPTABLY RESOLVED.

---

### W3 — tenant_id absent from file.stored payload — RESOLVED

**Previous finding:** Behaviour step 4 extracted tenant_id from ecle.file.stored but
Contract 09 §3 did not list tenant_id in the file.stored required fields.

**Fix verified:** Resolved as part of FAIL 1 — Contract 09 §3 file.stored row now lists
file_id, repo_id, tenant_id as required payload fields. RESOLVED.

---

### W4 — constitution/schemas/semantic_annotations.sql absent — RESOLVED

**Previous finding:** ADR-0034 §Compliance states the schema file must be authored in
SPEC-0010; no file existed and the spec did not address its absence.

**Fix verified:** Out of scope section now explicitly states:
> "SQL schema file constitution/schemas/semantic_annotations.sql is deferred to the
> release-manager step; its absence does not block this spec."

The deferral is explicit, intentional, and correctly scoped. RESOLVED.

---

## New Finding

### W5 — [V2] load-time validator omits positional group count check (NEW — LOW)

**Severity:** Low. Does not block implementation.

**Location:** Interface contract, rule_schema.py, AnnotationRule [V2] comment.

**Finding:**

The [V2] @model_validator comment states:
> "for each `{match.<name>}` reference in annotate values, verify <name> is a named group;
> raise ValidationError if any reference is unresolvable"

Contract 20 §5 lists two parallel capture-mismatch rejection conditions:

| Condition (Contract 20 §5) | [V2] comment coverage |
|---|---|
| annotate field references {match.group_name} — pattern has no such named group | COVERED |
| annotate field references {match[N]} — pattern has fewer than N capture groups | NOT COVERED |

Contract 20 §6.9 states both forms are "validated at rule-load time by the Pydantic schema
(§5)." The positional-group case is handled at evaluation time by _apply_substitution
raising PermanentWorkerError — so the error does not go silently undetected — but Contract
20 §5 requires it to be caught at load time. There is no test asserting ValidationError at
load time for an out-of-range {match[N]} reference.

**Required fix before coder begins rule_schema.py:**

1. Extend [V2] comment in AnnotationRule:
```
# @model_validator(mode="after") [V2]: for regex patterns (match.pattern starts with
#   "re:"), compile the regex and:
#   (a) for each "{match.<name>}" reference in annotate values, verify <name> is in
#       compiled_pattern.groupindex; raise ValidationError if absent;
#   (b) for each "{match[N]}" reference in annotate values, verify N <= compiled_pattern.groups;
#       raise ValidationError if N exceeds group count
#   — Contract 20 §5/§6.9, AC-15
```

2. Add test T-23b to test_rule_schema.py:

| T-23b | test_positional_group_out_of_range_fails_at_load | unit | RuleFile with AnnotationRule pattern "re:^par_(.+)$" (1 group) and annotate: {role: "{match[5]}"} (index 5 > group count) -> ValidationError raised during load(); rule file rejected — Contract 20 §5 |

**Impact:** Low. Positional-group errors still surface as PermanentWorkerError at evaluation
time. No silent data corruption. No change to public API, event schema, or DB schema.

---

## Verdict Detail

| Category | Result |
|---|---|
| Previous FAIL 1 (Contract 09 §3 not amended) | RESOLVED |
| Previous FAIL 2 (AnnotationRule missing [V1] and [V2]) | RESOLVED |
| Previous W1 (AC-09 ambiguity) | RESOLVED |
| Previous W2 (integration test ratio) | RESOLVED |
| Previous W3 (tenant_id in file.stored payload) | RESOLVED |
| Previous W4 (schema SQL file) | RESOLVED |
| New W5 ([V2] positional group count omitted) | OPEN — LOW |

No FAIL-level violations remain. One new LOW-severity WARN.

---

## Required Action Before Implementation Begins

**One targeted fix required (does not require a third full review pass):**

Extend the AnnotationRule [V2] comment to cover positional group count validation as shown
in W5 above, and add test T-23b. A diff review of these two changes is sufficient; no
further spec-reviewer pass is needed.

Once the W5 fix is applied, the spec may be advanced to `Status: Approved` and G3 (planner)
may begin.
