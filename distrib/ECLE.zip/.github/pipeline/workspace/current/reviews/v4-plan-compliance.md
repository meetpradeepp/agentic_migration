# Constitution Compliance Report — G3→G4 — SPEC-0011

**Scanned by:** @validator  
**Date:** 2026-05-14  
**Gate:** G3→G4 (V4 — Plan Compliance Scan)  
**Target:** `.github/pipeline/plans/SPEC-0011-plan.json`  
**Spec:** `specs/phase-1/SPEC-0011-deterministic-naming-enforcement.md`  
**Contracts loaded:** Contract 02 §5, Contract 03  

---

## V4 Plan Compliance Scan — SPEC-0011

### Checklist

| # | Check | Verdict | Evidence |
|---|-------|---------|----------|
| V4.1 | Plan references approved spec | **PASS** | `spec_id="SPEC-0011"`, `spec_file="specs/phase-1/SPEC-0011-deterministic-naming-enforcement.md"`, spec `Status: Approved` |
| V4.2 | TDD order enforced — all test subtasks before dependent implementation subtasks | **PASS** | ST-0011-T01 and ST-0011-T02 are in `depends_on` for ST-0011-I01; ST-0011-T03 is in `depends_on` for ST-0011-I02; ST-0011-I03 depends on ST-0011-I02 which transitively covers ST-0011-T03 |
| V4.3 | Each subtask has required fields (`id`, `type`, `title`, `description`, `files_create`, `files_modify`, `verification`, `depends_on`, `status`) | **PASS** | All 6 subtasks (T01, T02, T03, I01, I02, I03) carry all nine required fields plus `commit_message`, `max_lines`, `estimated_lines` |
| V4.4 | Verification commands present and non-empty | **PASS** | Every subtask has a concrete `uv run pytest` or `uv run python` command; none are empty or placeholder strings |
| V4.5 | SRP respected — each subtask addresses one logical change | **PASS** | T01=unit happy-path tests; T02=unit error-handling tests; T03=integration CLI tests; I01=NamingChecker module; I02=CLI entrypoint+report writer (single file, tightly coupled); I03=pre-commit config wiring |
| V4.6 | No subtask exceeds 300 lines (`estimated_lines`) | **PASS** | Max is ST-0011-I01 at 270 lines; all others ≤ 200; none exceed 300 |
| V4.7 | All acceptance criteria (AC-1 through AC-11) covered by ≥1 test subtask | **PASS** | AC-1–7, AC-11 → T1–T7, T11 in ST-0011-T01; AC-8–10 → T8–T10 in ST-0011-T03; full mapping table below |
| V4.8 | All 5 error-handling rows covered by ≥1 test subtask | **PASS** | Error row 1 (T12) → ST-0011-T03; row 2 (T13) → ST-0011-T02; row 3 (T14) → ST-0011-T03; row 4 (T15) → ST-0011-T03; row 5 (T16) → ST-0011-T02 |
| V4.9 | Dependencies are acyclic | **PASS** | Topological order: T01 → T02 (and T03 in parallel) → I01 → I02 → I03; no back-edges present |
| V4.10 | Files listed in plan match files declared in spec `## Decision` | **WARN** | Three spec-declared files correctly appear in plan; `src/ecle/linting/__init__.py` appears in ST-0011-I01 `files_create` but is not listed in spec `## Decision` section |

---

### AC ↔ Subtask Traceability Map

| AC | Test ID | Covered by |
|----|---------|------------|
| AC-1 | T1 | ST-0011-T01 |
| AC-2 | T2 | ST-0011-T01 |
| AC-3 | T3 | ST-0011-T01 |
| AC-4 | T4 | ST-0011-T01 |
| AC-5 | T5 | ST-0011-T01 |
| AC-6 | T6 | ST-0011-T01 |
| AC-7 | T7 | ST-0011-T01 |
| AC-8 | T8 | ST-0011-T03 |
| AC-9 | T9 | ST-0011-T03 |
| AC-10 | T10 | ST-0011-T03 |
| AC-11 | T11 | ST-0011-T01 |

### Error-Handling Row ↔ Subtask Traceability Map

| Error row | Test ID | Covered by |
|-----------|---------|------------|
| Row 1 — unreadable file, exit 2 | T12 | ST-0011-T03 |
| Row 2 — syntax error → ECLE001-PARSE, exit 2 | T13 | ST-0011-T02 |
| Row 3 — missing report directory auto-created | T14 | ST-0011-T03 |
| Row 4 — invalid mode argument, exit 2 | T15 | ST-0011-T03 |
| Row 5 — checker internal exception, deterministic diagnostic, exit 2 | T16 | ST-0011-T02 |

---

### Warnings (non-blocking)

**[WARN W1 — V4.10 — ST-0011-I01]** `src/ecle/linting/__init__.py` listed in `files_create` but absent from spec `## Decision` section.  
- **Plan field:** `ST-0011-I01.files_create` includes `"src/ecle/linting/__init__.py"`  
- **Spec text (## Decision):** lists only `src/ecle/linting/naming_checker.py`, `scripts/run_naming_gate.py`, and `.pre-commit-config.yaml`  
- **Assessment:** The `__init__.py` is a necessary package marker implied by Python module conventions; its omission from the spec is an oversight in the spec's Decision section, not a planner error.  
- **Recommended action:** @spec-patcher should add `src/ecle/linting/__init__.py` to the spec's `## Decision` file list for completeness. Does not block G4.

**[WARN W2 — V4.3 — ST-0011-T01]** Minor internal count inconsistency in subtask description.  
- **Plan field:** `ST-0011-T01.description` states "nine failing tests" but enumerates exactly eight tests: T1, T2, T3, T4, T5, T6, T7, T11.  
- **Assessment:** The title correctly states "T1–T7, T11" (8 tests). The word "nine" in the prose is a transcription error; it does not affect the test IDs or AC coverage.  
- **Recommended action:** @planner may correct the description prose at any convenient point. Does not block G4.

---

### Summary

| Metric | Value |
|--------|-------|
| Total checks | 10 |
| PASS | 9 |
| WARN | 2 (on checks V4.3 and V4.10) |
| FAIL | 0 |

### Verdict

**PASS — plan is compliant and G4 may proceed.**

Both warnings are non-blocking. W1 (missing `__init__.py` in spec Decision) is a spec gap, not a plan defect; the plan is correct. W2 (prose count error in ST-0011-T01 description) is cosmetic. No V4 hard failure conditions are present: TDD order is enforced, all ACs and error rows have test coverage, no subtask exceeds 300 lines, dependencies are acyclic, and the plan references an Approved spec.

**Recommended follow-on (low priority):** @spec-patcher should amend SPEC-0011 `## Decision` to list `src/ecle/linting/__init__.py` to keep spec and plan in sync before the spec is marked `Implemented`.
