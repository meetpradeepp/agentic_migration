# SPEC-0011 — Deterministic Naming Enforcement

**Phase:** 1
**Status:** Approved
**Implements:** ADR-0037
**Depends on:** SPEC-0001

## Problem

Phase 1 currently lacks a deterministic naming gate that prevents ambiguous business variable names from entering mainline code, which creates review churn and correctness risk despite existing style guidance. ADR-0037 requires machine-enforced naming validation in CI Stage 1 and local parity so generated and hand-written code defaults to descriptive symbols without reviewer interpretation variance, improving FACT-A and FACT-T outcomes through repeatable static checks.

## Decision

Create a deterministic naming checker module and CI/local gate wiring that enforces rule `ECLE001` for non-trivial scopes.

- Module/class/function created or modified:
  - `src/ecle/linting/naming_checker.py` with `NamingChecker` and deterministic AST-based scope analysis
  - `scripts/run_naming_gate.py` as command entrypoint for CI Stage 1 and local usage
  - `.pre-commit-config.yaml` hook entry using the same command and config as CI
- Events consumed: None (Contract 09 not applicable)
- Events produced: None (Contract 09 not applicable)
- DB tables read/written: None (Contract 15 not applicable)
- Artifacts read/written:
  - Reads source files from repository working tree
  - Writes JSON report artifact to `.github/pipeline/workspace/current/reviews/naming-gate-report.json` (ADR-0030)

`ECLE001` rule behavior (deterministic):

- Violation target:
  - One-letter identifier used as a business/state/dependency local variable in a non-trivial scope
  - Ambiguous short-name denylist used as business/state/dependency local variable in a non-trivial scope:
    `tmp`, `val`, `obj`, `res`, `ret`, `data`, `item`, `thing`, `x1`, `y1`
- Non-trivial scope threshold (scope is non-trivial if ANY condition is true):
  - Logical code lines in function/method body >= `10` (exclude blank lines/comments)
  - Local variable declarations (excluding parameters) >= `3`
  - At least one control-flow node exists: `if`, `elif`, `match`, `try`, `for`, `while`, `with`
  - At least one boundary call exists (deterministic call-name match):
    - DB tokens: `execute`, `executemany`, `upsert`, `fetchone`, `fetchall`
    - File/artifact I/O tokens: `open`, `read_text`, `read_bytes`, `write_text`, `write_bytes`, `write_json`, `read_json`
    - Network/Kafka tokens: `produce`, `poll`, `flush`, `send`, `post`, `get`, `put`, `delete`, `request`
- Allow-list exceptions (never violations when guard conditions hold):
  - Tiny loop indices: `i`, `j`, `k` only when loop body logical lines <= `3` and symbol has no use outside loop body
  - Math-only notation: `x`, `y`, `z`, `n`, `m` only when symbol participates exclusively in numeric expressions in the containing scope
  - Unpack throwaway: `_` allowed for ignored values
  - Comprehension local indices: same conditions as tiny loop indices
- Determinism requirements:
  - AST-only evaluation, fixed token lists, fixed thresholds, stable traversal order by `(path, line, column, symbol)`
  - No external network/model service calls
  - Same repository revision + same config must produce byte-identical JSON report

CI Stage 1 and local parity:

- CI Stage 1 executes `scripts/run_naming_gate.py --mode ci --report <path>` and fails non-zero when any `ECLE001` finding exists in checked scope.
- Pre-commit hook executes the same command in `--mode local` over staged Python files and fails commit on findings.
- Developer local parity command is required: `uv run python scripts/run_naming_gate.py --mode local --report .tmp/naming-gate-report.json`.
- CI and local modes must share the same default thresholds, denylist, allow-list, and output schema.

## Interface contract

```python
# src/ecle/linting/naming_checker.py
@dataclass(frozen=True)
class ScopeMetrics:
    logical_lines: int
    local_variable_count: int
    has_control_flow: bool
    has_boundary_call: bool

@dataclass(frozen=True)
class NamingFinding:
    path: str
    line: int
    column: int
    symbol: str
    reason: str
    rule_id: str
    scope_kind: str
    scope_metrics: ScopeMetrics

class NamingChecker:
    def __init__(self, *, non_trivial_logical_lines: int, non_trivial_local_variables: int, ambiguous_denylist: tuple[str, ...], allowlist: tuple[str, ...]) -> None: ...
    def check_paths(self, paths: list[str]) -> list[NamingFinding]: ...
    def check_source(self, *, path: str, source_text: str) -> list[NamingFinding]: ...
```

```python
# scripts/run_naming_gate.py
def parse_args(argv: list[str]) -> argparse.Namespace: ...
def run_checker(*, mode: Literal["ci", "local"], target_paths: list[str], report_path: str) -> int: ...
def write_report(*, report_path: str, findings: list[NamingFinding]) -> None: ...
def main() -> int: ...
```

| Field | Default | Contract ref |
|-------|---------|-------------|
| `NAMING_GATE_NON_TRIVIAL_LOGICAL_LINES` | `10` | Contract 01 §9 |
| `NAMING_GATE_NON_TRIVIAL_LOCAL_VARIABLES` | `3` | Contract 01 §9 |
| `NAMING_GATE_AMBIGUOUS_DENYLIST` | `"tmp,val,obj,res,ret,data,item,thing,x1,y1"` | ADR-0037 Decision |
| `NAMING_GATE_ALLOWLIST` | `"i,j,k,x,y,z,n,m,_"` | ADR-0037 Decision |
| `NAMING_GATE_REPORT_PATH` | `".github/pipeline/workspace/current/reviews/naming-gate-report.json"` | ADR-0030 |

```text
RULE_ID_ECLE001 = "ECLE001"  # Non-trivial scope business variable naming  # ADR-0037
NON_TRIVIAL_SCOPE_ANY = True  # Any threshold hit marks non-trivial scope    # ADR-0037
CHECKER_REPORT_VERSION = "1" # Deterministic schema contract version         # Contract 02
```

Checker output schema (JSON array, stable sort required):

```python
# naming-gate-report.json finding schema
@dataclass(frozen=True)
class NamingFindingPayload:
    path: str
    line: int
    column: int
    symbol: str
    reason: str
    rule_id: str
    scope_kind: str
    scope_metrics: dict[str, int | bool]
```

## Behaviour

1. Stage 1 CI or local command discovers target Python files and excludes virtualenv/build/cache directories by deterministic path filter.
2. Runner creates `NamingChecker` with configured thresholds/denylist/allow-list; missing config values fall back to defaults defined in this spec.
3. For each function/method scope, checker computes `ScopeMetrics` from AST and logical-line tokenizer.
4. Checker marks scope non-trivial when any non-trivial threshold condition is true.
5. In non-trivial scope, checker evaluates each local variable assignment target against `ECLE001` deny rules.
6. Before recording a finding, checker applies allow-list exception guards; if guard passes, symbol is not flagged.
7. Checker emits one `NamingFinding` per violating symbol occurrence with deterministic `reason` text and `rule_id="ECLE001"`.
8. Runner sorts findings by `(path, line, column, symbol)` and writes JSON report using the required schema.
9. CI Stage 1 exits `1` when finding count > 0 and exits `0` when no findings exist.
10. Pre-commit/local command uses the same checker/config and mirrors exit behavior for parity with CI.

## Acceptance criteria

| ID | Given | Input | Expected |
|----|-------|-------|----------|
| AC-1 | A function has 12 logical lines and local variable `x` used for business state | `uv run python scripts/run_naming_gate.py --mode ci --report .tmp/r1.json` | Report contains one finding with `rule_id="ECLE001"`, `symbol="x"`, and `reason` indicating one-letter business variable in non-trivial scope. |
| AC-2 | A function has 2 lines and one local variable `x` with no control flow/boundary calls | Same command as AC-1 | Report contains zero findings for that symbol because scope is trivial. |
| AC-3 | A non-trivial function uses variable `tmp` for parsed payload | Same command as AC-1 | Report contains finding with `symbol="tmp"` and `rule_id="ECLE001"`. |
| AC-4 | A loop variable `i` is used only inside a 3-line loop body | Same command as AC-1 | No finding for `i` because tiny-loop allow-list guard passes. |
| AC-5 | Symbol `i` from loop is reused after loop in same non-trivial scope | Same command as AC-1 | Finding is emitted for `i` because allow-list guard fails on out-of-loop use. |
| AC-6 | Symbol `x` appears only in numeric math expressions in non-trivial scope | Same command as AC-1 | No finding for `x` because math-only allow-list guard passes. |
| AC-7 | Same codebase revision is checked twice with identical config | Run command twice, compare report bytes | Generated report files are byte-identical and sorted identically. |
| AC-8 | CI run has at least one finding | `uv run python scripts/run_naming_gate.py --mode ci --report .tmp/r2.json` | Process exits with code `1` and report file exists with >=1 finding record. |
| AC-9 | Clean codebase with no violations | `uv run python scripts/run_naming_gate.py --mode ci --report .tmp/r3.json` | Process exits with code `0` and report is valid empty array `[]`. |
| AC-10 | Pre-commit and CI run on same changed files | Pre-commit hook invocation and CI Stage 1 invocation | Both runs produce equal finding set for overlapping files (same `path,line,symbol,rule_id`). |
| AC-11 | A violation is emitted | Any failing run with one finding | Finding payload includes `path`, `line`, `symbol`, `reason`, `rule_id` fields populated and non-empty. |

## Error handling

| Error condition | Classification | Response | Event emitted |
|----------------|---------------|----------|--------------|
| Target file cannot be read (permission/missing) | transient | Record checker process error in stderr, skip unreadable file, exit `2` if any unreadable file exists | none |
| Python source has syntax error | permanent | Add finding-like diagnostic with `rule_id="ECLE001-PARSE"` and fail run with exit `2` | none |
| Report output path directory missing | transient | Create parent directory and retry write once; on retry failure exit `2` | none |
| Invalid mode argument | permanent | Print usage and exit `2` without report mutation | none |
| Checker internal exception while evaluating one scope | permanent | Emit deterministic error diagnostic for path/line and continue other files; final exit `2` | none |

## Tests required

File: `tests/unit/test_naming_checker.py`
File: `tests/integration/test_naming_gate_ci_stage1.py`

| Test ID | Test case | Type | Verifies |
|---------|-----------|------|----------|
| T1 | `test_check_source_flags_one_letter_symbol_in_non_trivial_scope` | unit | AC-1 |
| T2 | `test_check_source_skips_one_letter_symbol_in_trivial_scope` | unit | AC-2 |
| T3 | `test_check_source_flags_ambiguous_denylist_symbol` | unit | AC-3 |
| T4 | `test_check_source_allows_tiny_loop_index` | unit | AC-4 |
| T5 | `test_check_source_flags_loop_index_used_outside_loop` | unit | AC-5 |
| T6 | `test_check_source_allows_math_only_symbol_context` | unit | AC-6 |
| T7 | `test_report_is_byte_identical_for_same_input` | unit | AC-7 |
| T8 | `test_ci_mode_returns_non_zero_on_findings` | integration | AC-8 |
| T9 | `test_ci_mode_returns_zero_on_clean_input` | integration | AC-9 |
| T10 | `test_pre_commit_and_ci_findings_match_for_same_files` | integration | AC-10 |
| T11 | `test_finding_schema_contains_required_fields` | unit | AC-11 |
| T12 | `test_unreadable_file_exits_two` | integration | Error row 1 |
| T13 | `test_syntax_error_source_emits_parse_rule_and_exits_two` | unit | Error row 2 |
| T14 | `test_missing_report_directory_is_created` | integration | Error row 3 |
| T15 | `test_invalid_mode_exits_two` | integration | Error row 4 |
| T16 | `test_scope_evaluation_exception_returns_exit_two_with_diagnostic` | unit | Error row 5 |

## Out of scope

- Does NOT cover: Auto-renaming or autofix of flagged symbols (defer to future enhancement spec in Phase 1 or Phase 2).
- Does NOT cover: Non-Python language naming enforcement (owned by language-pack specific specs after Phase 1 milestone).
- Does NOT cover: Historical whole-repository debt remediation workflow beyond changed-file CI policy decisions.
- Does NOT cover: Any Kafka event, DB schema, or MCP API changes.

## Deviations

_To be filled at implementation time. Empty for Draft specs._