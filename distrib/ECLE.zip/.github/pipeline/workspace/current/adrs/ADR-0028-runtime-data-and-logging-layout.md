# ADR-0028: Runtime Data and Logging Directory Layout

**Status:** Accepted  
**Date:** 2026-05-08  
**Deciders:** Lead Engineer, Architecture Review  
**Supersedes:** —  
**Superseded by:** —  
**FACT impact:**
- Fast: `neutral` — no runtime performance change; directory layout is structural
- Accurate: `neutral` — no effect on computation paths
- Complete: `improves` — consolidated layout ensures no artifact is orphaned or misplaced
- Trustworthy: `improves` — central logging config with per-module control increases auditability

---

### Context

ADR-0010 defines Tier 1 data paths as scattered top-level directories: `./data/ecle.db`,
`./data/chroma/`, `./artifacts/`, `./language_packs/`. Logs go to stdout only. This layout
has several problems:

1. **No single runtime root** — data files are spread across multiple top-level directories,
   making cleanup, backup, and `.gitignore` management fragile.
2. **No per-repo artifact isolation** — `./artifacts/` is a flat namespace; uploaded zips,
   raw source, and IR files are co-mingled.
3. **No file-based logging** — Contract 16 §5.5 mandates stdout-only for Tier 1 and
   Fluentd for Tier 2+, but developers need persistent log files during development with
   per-module log level control.
4. **No central config location** — configuration lives only in environment variables and
   `.env`; there is no canonical directory for YAML config, local models, or runtime state.

We need two clearly separated runtime directories: one for data (state that matters) and
one for logs (ephemeral diagnostic output). Both must be `.gitignore`d, easily relocatable
via config, and compatible with the three-tier model.

---

### Decision

We will establish two top-level runtime directories — `ecle-data/` and `ecle-logs/` — as
the exclusive locations for all runtime state and log output respectively. All existing
scattered path references (`./data/`, `./artifacts/`) will be consolidated under `ecle-data/`.
Logging will be controlled by a central `ecle-data/config/logging.yaml` with per-module
log level overrides.

#### `ecle-data/` — all runtime state

```
ecle-data/
├── config/                          # central configuration
│   ├── ecle.yaml                    # master runtime config (overrides env vars)
│   └── logging.yaml                 # per-module log levels and handlers
├── db/                              # database data directories
│   ├── postgresql/                  # PGDATA for local PostgreSQL instance
│   ├── qdrant/                      # Qdrant storage path
│   └── neo4j/                       # Neo4j data directory
├── models/                          # local ONNX models for embedding
│   └── .gitkeep
├── language_packs/                  # language pack manifests + extractors
│   └── .gitkeep
├── repos/                           # per-repo runtime artifacts
│   └── {tenant_id}/
│       └── {repo_id}/
│           ├── uploads/             # uploaded zip/tar before extraction
│           ├── source/              # extracted raw source tree
│           └── ir/                  # IR output (facts.json, metrics.json, chunks.json)
└── .gitkeep
```

#### `ecle-logs/` — all log output

```
ecle-logs/
├── ecle-mcp.log                     # MCP server logs
├── ecle-admin.log                   # Admin API logs
├── ecle-worker-scan_source.log      # per-worker log files
├── ecle-worker-parse_repo.log
├── ecle-worker-persist_facts.log
├── ecle-worker-build_graph.log
├── ecle-worker-chunk_file.log
├── ecle-worker-batch_embed.log
├── ecle-worker-compute_topology.log
├── ecle-celery-beat.log             # periodic task scheduler
└── ecle-kafka.log                   # Kafka broker logs (Tier 1 local broker)
```

#### Path mapping from old to new

| Old path (ADR-0010) | New path | Config variable |
|---------------------|----------|-----------------|
| `./data/ecle.db` | `ecle-data/db/ecle.db` | `STRUCTURED_BACKEND_URL` |
| `./data/chroma/` | `ecle-data/vectors/chroma/` | `VECTOR_BACKEND_URL` |
| `./artifacts/` | `ecle-data/repos/{tenant}/{repo}/ir/` | `ARTIFACT_STORE_PATH` |
| `./language_packs/` | `ecle-data/language_packs/` | `LANGUAGE_PACKS_PATH` |
| (none) | `ecle-data/config/ecle.yaml` | `ECLE_CONFIG_PATH` |
| (none) | `ecle-data/config/logging.yaml` | `ECLE_LOG_CONFIG_PATH` |
| (none) | `ecle-data/models/` | `ECLE_MODELS_PATH` |
| (none) | `ecle-data/repos/{t}/{r}/uploads/` | derived from `ECLE_DATA_ROOT` |
| (none) | `ecle-data/repos/{t}/{r}/source/` | derived from `ECLE_DATA_ROOT` |
| stdout only | `ecle-logs/` | `ECLE_LOG_DIR` |

#### New environment variables

| Variable | Default (Tier 1) | Description |
|----------|------------------|-------------|
| `ECLE_DATA_ROOT` | `./ecle-data` | Root of all runtime data |
| `ECLE_LOG_DIR` | `./ecle-logs` | Root of all log files |
| `ECLE_CONFIG_PATH` | `{ECLE_DATA_ROOT}/config/ecle.yaml` | Master config file |
| `ECLE_LOG_CONFIG_PATH` | `{ECLE_DATA_ROOT}/config/logging.yaml` | Logging config file |
| `ECLE_MODELS_PATH` | `{ECLE_DATA_ROOT}/models` | ONNX model directory |

All other config variables (`STRUCTURED_BACKEND_URL`, `VECTOR_BACKEND_URL`,
`ARTIFACT_STORE_PATH`, `LANGUAGE_PACKS_PATH`) now default to paths under
`ECLE_DATA_ROOT` instead of scattered top-level directories.

#### `logging.yaml` — central logging configuration

```yaml
version: 1
disable_existing_loggers: false

formatters:
  json:
    class: ecle.core.logging.JsonFormatter
    fields:
      - timestamp
      - level
      - service
      - version
      - tenant_id
      - request_id
      - trace_id
      - message
  console:
    format: "%(asctime)s [%(levelname)-5s] %(name)s — %(message)s"

handlers:
  console:
    class: logging.StreamHandler
    formatter: console
    stream: ext://sys.stdout
  file:
    class: logging.handlers.RotatingFileHandler
    formatter: json
    filename: "${ECLE_LOG_DIR}/{service}.log"
    maxBytes: 52428800     # 50 MB
    backupCount: 5
    encoding: utf-8

root:
  level: INFO
  handlers: [console, file]

# Per-module log level overrides
loggers:
  ecle.core:
    level: INFO
  ecle.workers.scan_source:
    level: INFO
  ecle.workers.parse_repo:
    level: INFO
  ecle.workers.persist_facts:
    level: INFO
  ecle.workers.build_graph:
    level: INFO
  ecle.workers.chunk_file:
    level: INFO
  ecle.workers.batch_embed:
    level: INFO
  ecle.workers.compute_topology:
    level: INFO
  ecle.mcp:
    level: INFO
  ecle.admin:
    level: INFO
  ecle.db:
    level: WARN
  ecle.vectors:
    level: WARN
  ecle.kafka:
    level: INFO
  # Override for debugging:
  # ecle.workers.parse_repo:
  #   level: DEBUG
```

#### Tier mapping

| Tier | `ECLE_DATA_ROOT` | `ECLE_LOG_DIR` | Notes |
|------|-------------------|----------------|-------|
| 1 (dev) | `./ecle-data` | `./ecle-logs` | Local filesystem; both `.gitignore`d |
| 2 (compose) | `/app/ecle-data` (Docker volume: `ecle-data`) | `/app/ecle-logs` (Docker volume: `ecle-logs`) | Named volumes; log rotation in-container |
| 3 (enterprise) | N/A — backends are managed services | stdout → Fluentd DaemonSet | `ecle-data/` not used; all state in S3/PG/Qdrant |

Tier 3 does NOT use `ecle-data/` or `ecle-logs/` directories — state lives in managed
services and logs ship via Fluentd/Fluent Bit to centralized log stores. The `ecle-data/`
layout is strictly for Tier 1 and Tier 2.

#### Rules

1. **Both directories are `.gitignore`d** — they contain runtime state, never committed.
2. **`ecle init` creates the full tree** — the CLI `init` command scaffolds both directories
   with `.gitkeep` files and default configs.
3. **No code references raw paths** — all access goes through `settings.ECLE_DATA_ROOT`
   or the backend factory functions (`get_artifact_store()`, `get_structured_db()`).
4. **Per-repo isolation is mandatory** — artifacts are always under
   `repos/{tenant_id}/{repo_id}/`, never in a flat namespace.
5. **Log files follow Contract 16 format** — structured JSON, one object per line, with
   all mandatory fields from Contract 16 §5.1.
6. **Log levels are module-controlled** — `logging.yaml` sets per-module levels; developers
   can enable `DEBUG` for a single module without flooding all logs.
7. **File handler uses rotation** — 50 MB max, 5 backups. Prevents unbounded disk growth.

---

### Consequences

**Positive:**

- Single `ECLE_DATA_ROOT` makes backup, cleanup, and relocation trivial.
- Per-repo directory isolation prevents cross-tenant artifact leakage.
- Central `logging.yaml` gives developers module-level log control without code changes.
- `.gitignore` requires only two entries: `ecle-data/` and `ecle-logs/`.
- Compatible with all three tiers — Tier 3 simply doesn't use the local directories.

**Negative / Trade-offs:**

- Breaking change to Tier 1 default paths — existing `./data/` and `./artifacts/` users
  must migrate (mitigated by `ecle migrate-data` CLI command in Phase 1).
- Slightly deeper directory nesting for per-repo artifacts.

**Neutral / Operational notes:**

- Contract 14 §3 tier-default table must be updated with new default paths.
- ADR-0010 Tier 1 section must reference `ecle-data/` instead of `./data/`.
- `docker-compose.yml` (Tier 2) must mount `ecle-data` and `ecle-logs` as named volumes.
