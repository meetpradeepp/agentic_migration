# ADR-0027: Async Component Autonomy Model

**Status:** Accepted
**Date:** 2026-05-07
**Deciders:** Lead Engineer, Architecture Review
**Supersedes:** —
**Superseded by:** —
**Amends:** ADR-0010 (per-worker scaling units), ADR-0013 (event-bus-only inter-component communication), ADR-0020 (per-worker lifecycle controls in Admin API)
**FACT impact:**
- Fast: `improves` — workers scale independently; one slow worker cannot throttle another
- Accurate: `neutral` — autonomy does not affect extraction correctness
- Complete: `improves` — paused or failed workers can be resumed without data loss; backpressure is contained to a single topic rather than cascading across the system
- Trustworthy: `improves` — each worker's health, throughput, and error rate is independently observable and controllable without restarting the system

---

### Context

ECLE 2.0 has multiple workers (parse_repo, persist_facts, batch_embed, cluster_centroids, compute_topology, document_embedder, learning_analyzer, ontology_enricher, etc.). Currently:

- Workers are defined and individually named, but there is no formal rule preventing direct calls between them.
- There is no per-worker lifecycle control — a misbehaving worker can only be fixed by redeploying the whole stack.
- Scaling parameters are global or ad-hoc — there is no per-worker scaling model.
- `import_jobs` tracks aggregate job status but does not track which pipeline stage a job is at.
- The Admin UI shows repo-level health but no worker-level operational state.

As the system grows (more workers, more tenants, larger repos), the ability to independently pause, scale, and debug individual workers becomes an operational necessity — not a nice-to-have.

---

### Decision

**Every ECLE component is an autonomous, independently deployable, independently scalable unit. All inter-component communication MUST be mediated by a Kafka event. Direct synchronous calls between workers are banned.**

This is an architectural invariant — not a guideline.

---

### Rule 1: Event-bus-only inter-component communication

**The Kafka event bus is the ONLY mechanism through which workers communicate.**

```
BANNED:
    parse_repo_worker.call(persist_facts_worker.handle(event))
    persist_facts_worker.emit_directly(batch_embed_worker)
    import_jobs_worker.notify(compute_topology_worker)

REQUIRED:
    parse_repo_worker → [Kafka: ecle.file.ir_produced] → persist_facts_worker
    persist_facts_worker → [Kafka: ecle.file.stored] → batch_embed_worker
```

**The Admin API is the only exception**: it writes to the DB and emits Kafka events, but never calls worker processes directly. The Admin API is a control-plane component, not a data-plane component.

**Why:** Direct calls create hidden coupling. A slow `persist_facts` would block `parse_repo` if they were coupled. With Kafka as the boundary, `parse_repo` continues producing at full speed; `persist_facts` accumulates lag and is scaled independently.

Enforcement: `10-anti-patterns.md` — "Direct call between two Kafka worker processes" is a banned pattern. Code review blocks merge.

---

### Rule 2: Per-worker independent deployability

Each worker is a distinct Python module in `src/ecle/workers/{worker_name}/` with:
- Its own `__main__.py` entry point (`python -m ecle.workers.parse_repo`)
- Its own `Dockerfile` (or shared base image with `CMD` override)
- Its own K8s `Deployment` manifest
- Its own K8s `Service` (for `GET /metrics` scraping only — workers do not expose REST APIs)
- Its own KEDA `ScaledObject`

Workers share the `src/ecle/` library code (DB clients, vector clients, Kafka client, etc.) but are deployed as separate processes. No worker imports another worker's module.

---

### Rule 3: Per-worker independent scaling

Each worker has a KEDA `ScaledObject` that scales based on its Kafka consumer group lag:

```yaml
# Pattern — one ScaledObject per worker
apiVersion: keda.sh/v1alpha1
kind: ScaledObject
metadata:
  name: ecle-{worker_name}
spec:
  scaleTargetRef:
    name: ecle-{worker_name}
  minReplicaCount: WORKER_{WORKER_NAME}_MIN_REPLICAS   # from env/config
  maxReplicaCount: WORKER_{WORKER_NAME}_MAX_REPLICAS   # from env/config
  triggers:
    - type: kafka
      metadata:
        topic:            {input_topic}
        consumerGroup:    ecle-{worker_name}
        lagThreshold:     WORKER_{WORKER_NAME}_LAG_THRESHOLD
        bootstrapServers: ${KAFKA_BOOTSTRAP_SERVERS}
```

**Scaling constants per worker (overridable via `tenant_config` / system config):**

| Worker | Min replicas | Max replicas | Lag threshold | Input topic |
|--------|-------------|-------------|---------------|-------------|
| `scan_source` | 1 | 4 | 10 | `ecle.source.received` |
| `parse_repo` | 1 | 16 | 100 | `ecle.repo.detected` |
| `persist_facts` | 1 | 16 | 100 | `ecle.file.ir_produced` |
| `compute_topology` | 1 | 8 | 50 | `ecle.file.stored` |
| `cluster_centroids` | 1 | 8 | 50 | `ecle.topology.updated` |
| `batch_embed` | 1 | 16 | 200 | `ecle.file.stored` |
| `document_embedder` | 1 | 8 | 100 | `ecle.document.stored` |
| `cross_repo_indexer` | 1 | 4 | 20 | `ecle.repo.indexed` |
| `sweep_coordinator` | 1 | 1 | — | Celery Beat (no KEDA) |
| `coverage_gap_aggregator` | 1 | 4 | 50 | `ecle.language_pack.extension_miss` |
| `learning_analyzer` | 1 | 4 | 50 | `ecle.feedback.given` |
| `ontology_enricher` | 1 | 4 | 50 | `ecle.ontology.reload.requested` |

`WORKER_{NAME}_MIN_REPLICAS`, `WORKER_{NAME}_MAX_REPLICAS`, `WORKER_{NAME}_LAG_THRESHOLD` are runtime-tunable via Admin API (added to overridable config keys in ADR-0020).

**Tier 1 (dev):** All workers run as single processes (`min=max=1`); KEDA not present.
**Tier 2 (compose):** Docker Compose `scale` per service; no KEDA; scaling is manual.
**Tier 3 (enterprise):** KEDA auto-scaling as above.

---

### Rule 4: Per-worker lifecycle control

Each worker polls a `worker_lifecycle` table (see Contract 15) on a 30 s TTL alongside `tenant_config`. Supported commands:

| Command | Effect |
|---------|--------|
| `run` | Normal operation (default) |
| `pause` | Worker stops calling `consumer.poll()`; in-flight messages complete processing; no new messages consumed |
| `drain` | Worker processes until consumer group lag = 0, then transitions to `pause` automatically |
| `reset_offset` | Admin-only; resets consumer group offset to `earliest` or `latest` (requires explicit `offset_target` field); triggers full reprocessing |

**Pause guarantees:**
- A paused worker MUST complete any message currently being processed before stopping.
- A paused worker MUST NOT commit offsets for messages it has not processed.
- Kafka consumer group lag accumulates while paused — this is expected and visible in Admin UI.
- `enable.auto.commit=False` (Contract 09) makes pause safe — no uncommitted offsets are lost.

**Lifecycle state machine:**
```
running ──pause──▶ paused ──resume──▶ running
running ──drain──▶ draining ──(lag=0)──▶ paused
paused  ──reset──▶ running (from new offset)
```

`worker_lifecycle` changes are audited in `query_audit_log` with `tool = "admin:worker_lifecycle"`.

---

### Rule 5: Per-worker pipeline step tracking

`import_jobs.pipeline_state` (JSONB column — see Contract 15) tracks each worker's contribution to a job in real-time:

```json
{
  "scan_source":       { "status": "complete", "started_at": "...", "completed_at": "..." },
  "parse_repo":        { "status": "complete", "file_count": 78,  "empty_count": 22 },
  "persist_facts":     { "status": "running",  "persisted": 45,   "failed": 0 },
  "batch_embed":       { "status": "pending" },
  "compute_topology":  { "status": "pending" },
  "cluster_centroids": { "status": "pending" }
}
```

Each worker writes its step status to `pipeline_state` on start (`running`) and completion (`complete | failed`). This is a JSON patch — workers only update their own key, never overwrite the full object.

The top-level `import_jobs.status` is derived from `pipeline_state`:
- `pending` = no worker has started yet
- `running` = at least one step is `running`
- `complete` = all expected steps are `complete`
- `failed` = any step is `failed`

---

### Rule 6: Per-worker independent observability

Each worker process exposes `GET /metrics` on its own port (`WORKER_METRICS_PORT`, default: `9090`). The Prometheus scrape config targets each worker pod independently — not aggregated behind a shared endpoint.

Per-worker metrics from Contract 16 §2 (`ecle_worker_messages_processed_total`, `ecle_worker_kafka_lag`, etc.) are labelled with `worker` so Grafana can show per-worker panels without a shared service.

Each worker also emits a `worker_alive` heartbeat log line (INFO) every 60 s with current lag, replica count, and lifecycle state — so ops teams can verify a specific worker is running even without Prometheus access.

---

### Consequences

**Positive:**
- `parse_repo` bottleneck does not block `batch_embed` from processing already-persisted files — they consume from different topics.
- A misbehaving `ontology_enricher` (e.g., stuck on a large cluster) can be paused without touching any other component.
- New workers (e.g., `security_analyzer`, `test_coverage_analyzer`) can be added to the system without changing any existing worker — just add a new consumer on an existing topic.
- Each worker can be rolled back independently without redeploying the full stack.
- The Admin UI Worker Control page provides a single pane of glass for all worker state.

**Negative / Trade-offs:**
- Pipeline step tracking via `pipeline_state` JSONB requires JSON patch operations — slightly more complex than a single status field, but avoids a separate `job_steps` table with N rows per job.
- Lifecycle polling (30 s TTL) means a pause command takes up to 30 s to take effect. Acceptable — pause is an operator action, not a real-time interrupt.
- Per-worker `ScaledObject` manifests multiply the K8s resource count. Acceptable — this is standard KEDA practice.

---

### Alternatives Considered

| Alternative | Why Rejected |
|-------------|-------------|
| Celery for all workers (ECLE 1.0 approach) | Celery chains create tight coupling between tasks; Celery Beat is kept only for `sweep_coordinator` (scheduled, not event-driven) |
| gRPC between workers | Synchronous; creates direct coupling; violates Rule 1; worker failures propagate synchronously |
| Single `worker_status` enum on `import_jobs` | Cannot track which stage a multi-step pipeline is at; Admin UI cannot show per-step progress |
| KEDA only on high-volume workers | Partial scaling creates an inconsistent operational model; every worker MUST have defined scaling bounds even if min=max=1 |

---

### Compliance

- ADR: `ADR-0010` — per-worker K8s Deployment and KEDA ScaledObject are the Tier 3 resource model
- ADR: `ADR-0013` — Kafka is the exclusive inter-component bus; this ADR formalises it as a hard rule
- ADR: `ADR-0020` — Admin API gains `/workers` lifecycle endpoints (amended)
- ADR: `ADR-0026` — Admin Portal gains Worker Control page (amended)
- Contract: `constitution/contracts/09-event-pipeline-contract.md` — async-first rule added (§0)
- Contract: `constitution/contracts/10-anti-patterns.md` — direct worker-to-worker call ban
- Contract: `constitution/contracts/15-db-schema-contract.md` — `worker_lifecycle` table; `import_jobs.pipeline_state` column

---

### References

| # | Citation | Relevance to this ADR |
|---|----------|----------------------|
| R1 | Richardson, C. "Microservices Patterns", Manning 2025 — Saga, CQRS, Event Sourcing patterns | Validates async-first, event-driven worker autonomy over synchronous orchestration |
| R2 | Hohpe, G. & Woolf, B. "Enterprise Integration Patterns", Addison-Wesley 2003 — Competing Consumers, Process Manager | Foundational patterns for independent consumer workers and pipeline state tracking |
| R3 | Kubernetes KEDA (Kubernetes Event-Driven Autoscaling) — keda.sh | Industry standard for scaling workers based on Kafka consumer group lag; validates per-worker ScaledObject pattern |
| R4 | Reactive Manifesto (reactivemanifesto.org) — Responsive, Resilient, Elastic, Message-Driven | Architectural principles: worker independence, backpressure via consumer lag, and message-driven communication |
