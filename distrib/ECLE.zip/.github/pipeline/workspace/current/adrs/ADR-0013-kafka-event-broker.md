# ADR-0013: Kafka as Exclusive Event Broker (All Tiers)

**Status:** Accepted  
**Date:** 2026-05-05  
**Deciders:** Lead Engineer, Architecture Review  
**Supersedes:** ADR-0001 (PostgreSQL events table as event broker)  
**Superseded by:** —  
**FACT impact:**
- Fast: `improves` — Kafka consumer poll is push-signalled (no polling interval); fan-out to N consumers is parallel; consumer group lag is a native metric for HPA scaling
- Accurate: `neutral` — broker change does not affect extraction or confidence scoring
- Complete: `improves` — fan-out events (`file.ir_produced` → `persist_facts` + `build_graph`) are now guaranteed independently; PostgreSQL single-row model was silently broken for multi-consumer events
- Trustworthy: `improves` — offset-based replay is deterministic; DLQ topics make failures observable without manual SQL queries; idempotent producer prevents duplicate message injection

---

### Context

ADR-0001 chose a PostgreSQL `events` table as the inter-worker communication channel. The decision was sound at the time: PostgreSQL was already required, the events table gave a free audit trail, and message broker infrastructure felt premature for Phase 1.

Two problems have since become blockers:

**Problem 1 — Fan-out is structurally broken.**  
The event catalogue has events consumed by multiple workers:
- `file.ir_produced` → consumed by both `persist_facts` AND `build_graph`
- `file.stored` → consumed by both `chunk_file` AND `detect_dsl_mappings`

A single `processed_at` timestamp on a row cannot track two independent consumers. The first worker to set `processed_at` marks the row as "done" — the second worker never sees it, or both race to process it. Fixing this in PostgreSQL requires a consumer-tracking join table, which is reinventing Kafka without Kafka's guarantees.

**Problem 2 — Dev/prod divergence.**  
ADR-0010 Tier 1 used `Celery task_always_eager=True` (synchronous in-process execution) and a SQLite-backed queue. The consequence, noted as a trade-off in ADR-0010: "async bugs can hide in dev and only surface in Tier 2." This is unacceptable for a system whose correctness guarantees depend on event ordering, idempotency, and consumer group isolation. The bugs we most need to catch — offset commit timing, rebalancing during long-running jobs, DLQ routing — are invisible in eager mode.

---

### Decision

We will use **Kafka (KRaft mode, no ZooKeeper) as the exclusive event broker across all three deployment tiers**. There is no per-tier broker abstraction — every tier runs real Kafka.

**No IEventBroker interface.** Abstracting the broker was considered (see Alternatives) and rejected: the abstraction would hide the exact failure modes we need to surface.

**Celery is removed as the worker execution framework.** Workers become plain Kafka consumer processes (confluent-kafka-python). **Celery Beat is retained** for periodic tasks (nightly evals, staleness sweeps) — it has no equivalent in Kafka.

---

### KRaft — no ZooKeeper

Kafka 3.3+ ships KRaft (Kafka Raft Metadata) as production-ready. Kafka 3.7+ makes it the default. ZooKeeper is deprecated and removed in Kafka 4.0.

All ECLE deployments use Kafka in KRaft mode. ZooKeeper is never provisioned. Config: `process.roles=broker,controller` on a single-node dev/compose deployment; dedicated controller nodes in enterprise.

---

### Topic naming convention

```
ecle.{event_type}
```

Examples:
```
ecle.source.received
ecle.file.ir_produced
ecle.file.stored
ecle.reindex.requested
```

DLQ topics follow:
```
ecle.dlq.{original_topic_suffix}
```

Examples:
```
ecle.dlq.file.ir_produced
ecle.dlq.file.stored
```

**Topic creation:** All topics are declared in `src/ecle/events/topic_registry.py` and created at startup via admin API. No auto-create in production (`auto.create.topics.enable=false`).

---

### Consumer group naming convention

```
ecle.{worker_name}
```

Examples:
```
ecle.scan_source
ecle.persist_facts
ecle.build_graph
ecle.chunk_file
ecle.detect_dsl_mappings
```

Fan-out works natively: `persist_facts` (group `ecle.persist_facts`) and `build_graph` (group `ecle.build_graph`) both subscribe to `ecle.file.ir_produced`. Kafka delivers all messages to both groups independently. No join tables, no race conditions.

---

### Producer configuration

```python
KAFKA_PRODUCER_CONFIG = {
    "bootstrap.servers": KAFKA_BOOTSTRAP_SERVERS,
    "enable.idempotence": True,          # exactly-once delivery per partition
    "acks": "all",                        # leader + all ISR replicas confirm
    "retries": 5,
    "retry.backoff.ms": 200,
    "compression.type": "lz4",
    "linger.ms": 5,                       # micro-batch for throughput
}
```

`enable.idempotence=True` + `acks=all` gives at-least-once delivery with idempotent deduplication at the broker. Combined with worker-level idempotency (§5 of Contract 09), the system achieves effectively-once processing.

---

### Consumer configuration

```python
KAFKA_CONSUMER_CONFIG = {
    "bootstrap.servers": KAFKA_BOOTSTRAP_SERVERS,
    "group.id": f"ecle.{WORKER_NAME}",
    "auto.offset.reset": "earliest",
    "enable.auto.commit": False,          # manual commit after successful processing
    "max.poll.interval.ms": 300000,       # 5 min — long-running jobs (parse_repo)
    "session.timeout.ms": 45000,
}
```

**Manual offset commit is mandatory.** Workers call `consumer.commit()` only after the processing result is durably written (DB committed, artifact written). Auto-commit would advance the offset before work is confirmed — losing events on crash.

---

### Error handling and DLQ

| Failure type | Worker action | Kafka action |
|---|---|---|
| Retryable error (transient DB failure) | Retry 3× with exponential backoff | Do NOT commit offset; message redelivered on restart |
| Permanent error (malformed payload, schema mismatch) | Log full payload; forward to DLQ topic | Commit offset on original topic (do not block pipeline) |
| Worker crash mid-processing | No offset commit was made | Kafka redelivers from last committed offset on restart |
| DLQ message | Separate `dlq_inspector` process; alerts ops | No auto-reprocessing — human review required |

DLQ topic naming: `ecle.dlq.{original_topic_suffix}` (e.g. `ecle.dlq.file.ir_produced`).

---

### Partitioning strategy

| Topic | Partition key | Rationale |
|---|---|---|
| `ecle.source.received` | `tenant_id` | Tenant isolation; ordering per tenant |
| `ecle.file.ir_produced` | `repo_id` | File events for same repo processed in order |
| `ecle.file.stored` | `file_id` | Independent per file; max parallelism |
| `ecle.file.chunked` | `file_id` | Same |
| `ecle.file.embedded` | `file_id` | Same |
| All others | `repo_id` | Default — repo-scoped ordering |

Default partition count: 12 (dev/compose: 1). Configurable via `KAFKA_DEFAULT_PARTITIONS`.

**Per-topic partition counts — enterprise tier minimum:**

| Topic | Enterprise partitions | Rationale |
|---|---|---|
| `ecle.file.ir_produced` | 24 | Highest-volume topic; `persist_facts` and `build_graph` both fan-out here; 1 partition = serial bottleneck |
| `ecle.file.stored` | 24 | Fan-out to `chunk_file` and `detect_dsl_mappings` |
| `ecle.file.embedded` | 12 | `cluster_centroids` consumer; moderate volume |
| `ecle.source.received` | 6 | One per active tenant typical |
| `ecle.reindex.requested` | 6 | Async; moderate throughput |
| `ecle.re-embed.batch` | 12 | Sweep parallelism; one partition = one worker active |
| All others | 6 | Default |
| DLQ topics | 1 | Low volume; human-reviewed |

Partition count per topic is set via `KAFKA_PARTITIONS_{TOPIC_SUFFIX}` env var (e.g. `KAFKA_PARTITIONS_FILE_IR_PRODUCED=24`). The default from `KAFKA_DEFAULT_PARTITIONS` applies to topics without a specific override.

**Rule:** `max_worker_replicas` for any consumer group MUST NOT exceed the partition count of the topic it consumes. KEDA `ScaledObject.maxReplicaCount` MUST be set to `min(desired_max, partition_count)`. Excess replicas sit idle and waste pod resources without improving throughput.

---

### Tier-specific deployment

| Tier | Kafka deployment | Notes |
|---|---|---|
| `dev` | Kafka (KRaft, single broker) — local install at `c:\utilities\kafka`; start with `kafka-server-start.bat` | No Docker required |
| `compose` | Kafka (KRaft, single broker) — Docker service `ecle-kafka` | `docker-compose.yml` ships in repo; `confluentinc/cp-kafka:7.7` image |
| `enterprise` | Kafka cluster (3+ brokers, KRaft) or managed: Confluent Cloud / AWS MSK / Azure Event Hubs (Kafka protocol) | `KAFKA_BOOTSTRAP_SERVERS` env var |

**Local Kafka for dev:** The local Kafka install at `c:\utilities\kafka` runs in KRaft mode (no ZooKeeper). Start with `kafka-server-start.bat config\kraft\server.properties`. All producer/consumer code is identical across tiers — `KAFKA_BOOTSTRAP_SERVERS=localhost:9092` is the only dev-specific config.

---

### Celery transition

| Responsibility | Before (ADR-0001) | After (ADR-0013) |
|---|---|---|
| Worker task routing | Celery (polls events table) | Kafka consumer groups |
| Worker retry | Celery retry with backoff | Kafka offset + manual commit + DLQ |
| Worker process management | Celery worker processes | Plain Python processes (`src/ecle/workers/{name}.py`) |
| Horizontal scaling | Celery concurrency setting | Kafka consumer group — add process = add consumer |
| HPA trigger metric | PostgreSQL unprocessed event count | Kafka consumer group lag (native metric; KEDA in K8s) |
| Periodic tasks (nightly evals, staleness sweeps) | Celery Beat | **Celery Beat retained** — no Kafka equivalent |

Redis was previously required as the Celery broker backend. With Celery removed from the worker path, **Redis is no longer a required infrastructure dependency**. It may be added later for API-layer caching if needed.

---

### Audit trail

The PostgreSQL `events` table served dual purpose: message broker + audit log. Kafka replaces the broker role. The audit trail is replaced by:

1. **Kafka topic retention — tiered by event criticality:**

   A single `KAFKA_RETENTION_HOURS=168` (7 days) for all topics is insufficient: a 7-day deployment pause causes silent data loss for critical pipeline events. Retention is tiered by event type:

   | Category | Topics | Retention | Rationale |
   |---|---|---|---|
   | **Critical pipeline** | `ecle.file.ir_produced`, `ecle.file.stored`, `ecle.source.received` | **30 days** | Loss = silent indexing gap; must survive extended maintenance windows |
   | **Derived / replayable** | `ecle.file.embedded`, `ecle.file.chunked`, `ecle.topology.updated`, `ecle.ontology.enriched` | **7 days** | Replayable from upstream critical events; 7 days sufficient |
   | **Operational / sweep** | `ecle.reindex.requested`, `ecle.re-embed.batch` | **3 days** | Short-lived job coordination; staleness beyond 3 days means re-trigger is safer |
   | **DLQ** | `ecle.dlq.*` | **90 days** | Human review required; must not expire before operator sees them |

   Configuration: `KAFKA_RETENTION_MS_{CATEGORY}` env vars override per-category defaults. Topic registry (`src/ecle/events/topic_registry.py`) assigns each topic to a category at creation time.

   **Alert rule:** if consumer group lag on any Critical pipeline topic exceeds `KAFKA_LAG_ALERT_THRESHOLD` (default: 10,000 messages), emit a `pipeline.lag_alert` event and surface in `GET /metrics`. A lagging consumer approaching the retention window is a data-loss risk, not just a throughput issue.
2. **PostgreSQL `pipeline_runs` table** — a new lightweight table records `(repo_id, event_type, entity_id, status, created_at, completed_at)` for long-term audit. Written by each worker after successful commit. This is an append-only audit log, not a message queue.

---

### Alternatives Considered

| Alternative | Why Rejected |
|---|---|
| IEventBroker abstraction (different broker per tier) | Hides consumer group rebalancing, offset timing, DLQ routing bugs — exactly the bugs we need to catch in dev |
| Keep PostgreSQL events table + add consumer tracking table | Reinventing Kafka badly; N-consumer fan-out requires N rows per event; offset management is manual |
| RabbitMQ | No native offset replay; messages deleted on ack; no consumer group lag metric for autoscaling |
| Redis Streams | No persistent offset replay after eviction; Redis TTL creates silent data loss risk |
| AWS SQS / Azure Service Bus | Cloud vendor lock-in; air-gapped enterprise deployments excluded |
| Pulsar | Superior in some metrics but operational complexity higher; Kafka tooling ecosystem larger |

---

### Compliance

- Contract: `constitution/contracts/09-event-pipeline-contract.md` — updated to Kafka model; events table section replaced with topic/consumer group model
- ADR-0010: Three-tier deployment updated — Redis removed from Tier 2; Kafka/Redpanda added to all tiers
- Anti-pattern: A15 (sync API worker calls) — unchanged; still banned
- Eval: `eval_event_chain_complete` — unchanged assertion; implementation uses Kafka consumer group lag = 0 as terminal condition
- Eval: `eval_idempotent_ingest` — unchanged; now also verifies offset commit only after durable write

---

### References

| # | Citation | Relevance to this ADR |
|---|----------|----------------------|
| R1 | Richardson, C. "Microservices Patterns", Manning 2025, Ch. 6: Event Sourcing | Event sourcing pattern: persist state as sequence of events; event store doubles as message broker — validates Kafka as exclusive event bus |
| R2 | Hohpe, G. & Woolf, B. "Enterprise Integration Patterns", Addison-Wesley 2003 | Foundational patterns: Message Channel, Competing Consumers, Dead Letter Channel, Idempotent Receiver — all implemented in ECLE's Kafka model |
| R3 | Confluent, "Kafka: The Definitive Guide", O'Reilly 2021 — Consumer Groups, Exactly-Once Semantics | Industry reference for consumer group rebalancing, offset management, and DLQ patterns |
| R4 | Apache Kafka KRaft (KIP-500) — kafka.apache.org | Removes ZooKeeper dependency; validates ECLE's KRaft-mode choice for simplified operations |
