# ADR-0007: Artifact Store as IR Intermediary

**Status:** Accepted  
**Date:** 2026-05-05  
**Deciders:** Lead Engineer, Architecture Review  
**Supersedes:** —  
**Superseded by:** —  

---

### Context

After `parse_repo` extracts facts from source files, those facts must flow to four
downstream workers: `persist_facts`, `build_graph`, `chunk_file` (via `file.stored`),
and `detect_dsl_mappings` (via `file.stored`). The question is: **how does the data
move from the parser to these workers?**

Three options were considered:

**Option A — In-memory passing via Celery task arguments:**  
`parse_repo` serialises the full `facts` dict into the `file.ir_produced` event payload
(JSONB) and downstream workers deserialise it from there.

**Option B — Direct DB writes by the parser:**  
`parse_repo` writes directly to `file_facts`, `function_facts`, etc. Downstream workers
read from the DB. No intermediate artifact.

**Option C — Artifact file on disk:**  
`parse_repo` writes `facts.json` to a local path. The event payload carries only the
path and metadata. Downstream workers read the file independently.

ECLE 1.0 experience: in-memory passing via event payload caused JSONB bloat (~50 KB per
file × 10K files = 500 MB in the events table for one repo), query slowness on the
events table, and made replay expensive (re-serialise entire facts dict into each retry).

---

### Decision

We will use **Option C — artifact files on disk** as the IR intermediary between
`parse_repo` and all downstream workers.

- `parse_repo` writes one `{file_rel_path}.facts.json` per source file to:
  `ARTIFACT_STORE_PATH/{tenant_id}/{repo_id}/{file_rel_path}.facts.json`
- The `file.ir_produced` event payload carries only: `artifact_path`, `file_id`,
  `repo_id`, `language`, `fidelity`, `used_fallback`, `content_hash`, `commit_sha`
- Downstream workers (`persist_facts`, `build_graph`) read from `artifact_path`
- `parse_repo` MUST NOT write to any DB or vector store — artifact files are its only output
- `chunk_file` (consumed via `file.stored`) reads from the Structured DB, not the artifact —
  it does not need the raw facts, only the structured rows

**Artifact path convention:**
```
ARTIFACT_STORE_PATH/{tenant_id}/{repo_id}/{file_rel_path}.facts.json
```

**Retention policy:**
- Artifacts are retained until `file.stored` and `graph.updated` events are both `processed_at` set
- Cleanup worker (Phase 2) deletes artifacts older than `ARTIFACT_RETENTION_DAYS` (default: 7)
- In Phase 1: no automatic cleanup; artifacts accumulate; operator deletes manually

---

### Consequences

**Positive:**

- Events table stays slim — only routing metadata in JSONB, not full facts (~200 bytes vs ~50 KB per event)
- `parse_repo` is purely a file transformer — no DB dependency, testable in isolation
- Artifacts are replayable independently of the event system: if `persist_facts` fails,
  re-emit `file.ir_produced` and the artifact is still on disk — no re-parsing needed
- Artifacts are auditable: engineers can inspect any `facts.json` to debug extraction quality
- Downstream workers are decoupled from each other — they each read the same artifact independently
- Artifact path is deterministic from `(tenant_id, repo_id, file_rel_path)` — idempotency without DB lookup

**Negative / Trade-offs:**

- Disk space required: ~50 KB/file × 1M files = ~50 GB at scale (needs cleanup worker)
- Shared filesystem required in distributed deployment (NFS, S3, Azure Blob) — adds operational dependency
- Disk write failure in `parse_repo` fails the file silently unless explicitly checked
- Artifact store is a new operational concern (backup, retention, permissions)

**Neutral / Operational notes:**

- Phase 1: local filesystem (`ARTIFACT_STORE_PATH=./artifacts`); single machine only
- Phase 2: pluggable `IArtifactStore` interface (`LocalArtifactStore`, `S3ArtifactStore`, `AzureBlobArtifactStore`)
- `ARTIFACT_STORE_PATH` is a required config key — worker fails to start if unset
- Artifacts are written atomically (write to `.tmp` then rename) to prevent partial reads

---

### Alternatives Considered

| Alternative | Why Rejected |
|-------------|-------------|
| Inline facts in event payload JSONB | Events table bloat (~50 KB/file); slow replay; JSONB size limit risk; proven problematic in ECLE 1.0 |
| Parser writes directly to Structured DB | Violates SRP — parser would have two jobs; creates tight coupling between parser and DB schema; DB changes require parser changes |
| In-memory Celery chord / group passing | Celery serialises to Redis broker; same size problem as JSONB; not persisted for replay |
| Shared in-memory cache (Redis) | Not durable; eviction risk; adds cache consistency problem; facts may be lost before downstream consumes |

---

### Compliance

- Contract: `constitution/contracts/09-event-pipeline-contract.md` (parse_repo SRP — no DB writes)
- Contract: `constitution/contracts/08-language-pack-contract.md` (extractor interface — returns dict, not DB rows)
- Anti-pattern: A16 (cross-boundary writes — parse_repo must not write to DB)
- Schema: `constitution/schemas/facts-base-schema.json` (every artifact must conform)
- Eval: `eval_srp_isolation` — verifies parse_repo makes zero DB/vector/graph writes
- Eval: `eval_schema_conformance` — validates every artifact against facts-base-schema.json
