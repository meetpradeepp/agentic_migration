# SPEC-0002 — Per-Gate Token Budget Tracking

**Phase:** 0
**Status:** Implemented
**Implements:** HAR-ADR-0023
**Depends on:** SPEC-0001
**Relevant contracts:** HAR-C-0002

---

## Problem

Teams using the harness have no visibility into token cost at the gate level. The `pipeline_metrics.py` script has a fully-implemented `--tokens` reader (`TaskTokenReport`, `TokenEntry`, `--tokens` flag) that parses `gate-log.json`, but no agent or orchestrator step writes to that file. Without the writer side, cost transparency is unavailable and `pipeline_metrics.py --tokens` returns no data.

## Decision

The orchestrator appends one token-usage entry to `<workspace_path>/gate-log.json` at the close of each gate (G1–G6) when `hooks.yaml → token_budget_tracking: enabled`.

**File written:** `<workspace_path>/gate-log.json` (JSON Lines — one object per line, no wrapping array)

**Entry format:**
```json
{"gate": "G1", "agent": "spec-writer", "tokens_in": 1200, "tokens_out": 800, "timestamp": "2026-06-09T10:30:00Z"}
```

**Fields:**
- `gate` — gate identifier: `"G1"` through `"G6"`
- `agent` — primary agent for the gate (e.g. `"spec-writer"`, `"planner"`, `"coder"`, `"spec-reviewer"`, `"code-reviewer"`)
- `tokens_in` — estimated input tokens: total characters of all context loaded this gate ÷ 4
- `tokens_out` — estimated output tokens: total characters of agent response ÷ 4
- `timestamp` — ISO-8601 UTC timestamp at gate close

**Activation toggle:** `hooks.yaml → token_budget_tracking`
- `enabled` → gate-log entries are written
- `disabled` or absent → no file writes (default)

**Reporting:** `python constitution/harness/scripts/pipeline_metrics.py --tokens`

## Interface contract

No Python code changes. Agent instruction change only.

**Orchestrator — Token Budget Tracking section:**
```
token_budget_tracking: enabled|disabled   # from hooks.yaml
gate-log.json format: JSON Lines, one {"gate","agent","tokens_in","tokens_out","timestamp"} per line
```

## Scenarios

### Scenario: tracking enabled, gate closes normally
GIVEN `hooks.yaml → token_budget_tracking: enabled`
AND a pipeline task has an active workspace at `<workspace_path>`
WHEN gate G1 completes (spec-writer produces output)
THEN the orchestrator appends one JSON object to `<workspace_path>/gate-log.json`
AND the object contains `gate`, `agent`, `tokens_in`, `tokens_out`, `timestamp` fields

### Scenario: tracking disabled
GIVEN `hooks.yaml → token_budget_tracking: disabled` (or key absent)
WHEN any gate completes
THEN no write to `gate-log.json` occurs

### Scenario: file does not yet exist
GIVEN `token_budget_tracking: enabled`
AND `gate-log.json` does not yet exist in `<workspace_path>`
WHEN the first gate closes
THEN `gate-log.json` is created with the first entry

### Scenario: workspace does not yet exist
GIVEN `token_budget_tracking: enabled`
AND the pipeline workspace has not been created yet (e.g. gate close before G0 workspace creation)
WHEN a gate closes
THEN the gate-log write is skipped silently (no error)

### Scenario: metrics report
GIVEN one or more tasks have `gate-log.json` with entries
WHEN `pipeline_metrics.py --tokens` is run
THEN the report shows per-gate token totals, breakdown by gate, and top-N most expensive tasks

## Constraints

_None — this spec prescribes no mechanism-level constraints. Implementation is orchestrator instruction text only._

## Acceptance criteria

| ID | Given | Input | Expected |
|----|-------|-------|----------|
| AC-1 | `token_budget_tracking: enabled` in hooks.yaml, workspace exists | G1 completes | `gate-log.json` created/appended with one object containing all five required fields |
| AC-2 | `token_budget_tracking: enabled`, `gate-log.json` already has one entry | G2 completes | `gate-log.json` has a second line (JSON Lines, not overwritten) |
| AC-3 | `token_budget_tracking: disabled` (or key absent) | Any gate completes | `gate-log.json` does not exist and is not created |
| AC-4 | `gate-log.json` has entries from a completed task | `pipeline_metrics.py --tokens` invoked | Report shows per-gate totals; no crash; correct aggregation |
| AC-5 | Workspace does not exist at gate close | Gate closes before G0 workspace creation | No error; no file created |

## Error handling

N/A — the gate-log write is best-effort. A write failure (e.g. disk full) MUST NOT block the pipeline gate from completing. Log the failure to the gate output and continue.

## Tests required

### AC tests (outcome)
Implementation is agent instruction text in `orchestrator.agent.md` — no Python code introduced. Acceptance criteria are verified by manual end-to-end run:

| Test ID | Test case | Verifies |
|---------|-----------|----------|
| T1 | Run a full pipeline task with `token_budget_tracking: enabled`; inspect `gate-log.json` | AC-1, AC-2 |
| T2 | Run a full pipeline task with `token_budget_tracking: disabled`; confirm no `gate-log.json` | AC-3 |
| T3 | After T1, run `pipeline_metrics.py --tokens` | AC-4 |
| T4 | Observe orchestrator behaviour when workspace creation is deferred | AC-5 |

## Out of scope

- Per-agent-invocation tracking within a single gate (multiple agents per gate are aggregated as one entry)
- Exact token counts from model API (estimates only; ±20% accuracy expected)
- Budget enforcement (blocking a gate when a threshold is exceeded) — future enhancement
- Real-time token dashboards or external reporting integrations

## Deviations

_None — implementation matches spec exactly._
