# SPEC-0008 — Multimodal Input in Discovery-Grill

**Phase:** 0
**Status:** Implemented
**Implements:** —
**Depends on:** None
**Relevant contracts:** HAR-C-0002

---

## Problem

The discovery-grill skill (`SKILL.md`) already defines a complete Step 1.6 — Visual Signal Extraction — for handling image attachments (architecture diagrams, whiteboard photos, UI mockups, ER diagrams). However, the `discovery.agent.md` agent file does not reference Step 1.5 or Step 1.6, so agents invoking the discovery skill are unaware these steps exist. Users who attach images to discovery prompts receive no structured extraction of visual entities or constraints.

## Decision

Update `discovery.agent.md` to:
1. List Step 1.5 (Terminology Sharpening) and Step 1.6 (Visual Signal Extraction) in the skill inventory
2. Instruct Mode A execution to apply Step 1.6 when the user attaches an image, immediately after Step 1 and before Step 2

No changes to the discovery-grill `SKILL.md` are required — Step 1.6 is already fully authored there.

## Interface contract

No Python code. Agent instruction change only.

**`discovery.agent.md` — Skill section additions:**
```
- Step 1.5: Terminology sharpening — flag vague or conflicting terms before the grill starts
- Step 1.6: Visual signal extraction — if the user attaches an image, extract entities and infer constraints (SPEC-0008)
```

**`discovery.agent.md` — Mode A addition:**
```
If the user attaches an image (diagram, whiteboard, mockup), execute Step 1.6 
(Visual Signal Extraction) immediately after Step 1 and before Step 2.
Visual signals are advisory hypotheses — confirm each during the grill loop; 
never treat them as verified facts.
```

## Scenarios

### Scenario: user attaches an image in discovery prompt
GIVEN the user submits a discovery prompt with an attached image (diagram, whiteboard, mockup)
WHEN the discovery agent is invoked in Mode A
THEN the agent executes Step 1.6 (Visual Signal Extraction) after Step 1 and before Step 2
AND visible entities (boxes, nodes, labels, arrows) are listed with `(from image)` prefix
AND ambiguous or illegible elements are marked `[unclear]`
AND unconfirmed entities remain marked `[unconfirmed]` in the `## Visual Signals` section of the discovery brief

### Scenario: no image attached
GIVEN the user submits a discovery prompt without an image
WHEN the discovery agent is invoked in Mode A
THEN Step 1.6 is skipped silently
AND the grill proceeds from Step 0 → Step 1 → Step 2

### Scenario: visual signal contradicts constitution
GIVEN the user attaches an image showing a direct worker-to-worker call
WHEN Step 1.6 extracts this as a hypothesis
THEN the agent marks the entity `[unconfirmed]` and raises it as a constitutional risk in Step 3
AND does NOT treat the image as spec authority

## Constraints

_None — this spec prescribes no mechanism-level constraints. Implementation is agent instruction text only._

## Acceptance criteria

| ID | Given | Input | Expected |
|----|-------|-------|----------|
| AC-1 | Discovery agent invoked in Mode A | User attaches an architecture diagram | Agent lists visible entities with `(from image)` prefix before the first grill question |
| AC-2 | Discovery agent invoked in Mode A | User attaches an image | Step 1.6 executes after Step 1; Step 2 grill loop does not start until Step 1.6 is complete |
| AC-3 | Discovery agent invoked in Mode A | No image attached | Step 1.6 is skipped; grill proceeds normally from Step 0 |
| AC-4 | Image entity is not confirmed during grill loop | Discovery brief produced | Unconfirmed entity appears under `## Visual Signals` marked `[unconfirmed]` |
| AC-5 | Image shows a pattern that violates constitution | Step 1.6 extracts the entity | Entity flagged as constitutional risk in Step 3; not accepted as fact |

## Error handling

N/A — image processing is advisory. If the agent cannot interpret an image (illegible, unsupported format), it marks all extracted entities as `[unclear]` and proceeds to Step 2 without blocking.

## Tests required

### AC tests (outcome)
Implementation is agent instruction text in `discovery.agent.md` — no Python code introduced. Acceptance criteria are verified by manual end-to-end invocation:

| Test ID | Test case | Verifies |
|---------|-----------|----------|
| T1 | Invoke discovery agent with an attached architecture diagram | AC-1, AC-2 |
| T2 | Invoke discovery agent with no image | AC-3 |
| T3 | During grill loop, do not confirm an image entity; inspect brief | AC-4 |
| T4 | Attach image showing direct service-to-service call (no Kafka); inspect Step 3 output | AC-5 |

## Out of scope

- Image pre-processing or OCR (agents use multimodal vision capability directly)
- Storing images as workspace artifacts — images are context only, not committed files
- Mode B (Stress-Test a Design) — image support applies to Mode A only; Mode B users supply a design in text
- Non-image attachments (PDFs, spreadsheets) — out of scope; note and skip

## Deviations

_None — implementation matches spec exactly._
