﻿# Skill: next-number

## Purpose

Provides thread-safe, sequential number assignment for {project_name} pipeline
identifiers: SPEC numbers, ADR numbers, and Contract numbers.

Use this skill whenever an agent needs to assign a new identifier number.
Never derive a number by scanning the filesystem manually — use this script
to prevent duplicate assignments across parallel chat sessions.

---

## When to invoke

| Agent | When |
|---|---|
| orchestrator | G0 — before recording a new task in `state.json` |
| spec-writer | G1 — before creating a new `SPEC-NNNN-<name>.md` file |
| adr-writer | Before creating a new `SYS-ADR-NNNN` or `HAR-ADR-NNNN` file |
| spec-patcher | Never — patching an existing spec; no new number needed |
| release-manager | Never — numbers are assigned at creation time, not release |

---

## Commands

**Claim the next SPEC number (use when creating a new spec):**
```
python constitution/harness/scripts/next_number.py --type spec
```
Output: `SPEC-0022  (claimed)`

**Claim the next SYS-ADR number (use when creating a new system ADR):**
```
python constitution/harness/scripts/next_number.py --type sys-adr
```
Output: `SYS-ADR-0050  (claimed)`

**Claim the next HAR-ADR number (use when creating a new harness ADR):**
```
python constitution/harness/scripts/next_number.py --type har-adr
```
Output: `HAR-ADR-0012  (claimed)`

**Claim the next SYS-C number (use when creating a new system contract):**
```
python constitution/harness/scripts/next_number.py --type sys-contract
```
Output: `SYS-C-0014  (claimed)`

**Claim the next HAR-C number (use when creating a new harness contract):**
```
python constitution/harness/scripts/next_number.py --type har-contract
```
Output: `HAR-C-0009  (claimed)`

**Peek without claiming (use when checking, not assigning):**
```
python constitution/harness/scripts/next_number.py --type spec --peek
python constitution/harness/scripts/next_number.py --type sys-adr --peek
python constitution/harness/scripts/next_number.py --type har-adr --peek
python constitution/harness/scripts/next_number.py --type sys-contract --peek
python constitution/harness/scripts/next_number.py --type har-contract --peek
```

**Show all current counters:**
```
python constitution/harness/scripts/next_number.py --status
```

**Re-seed from filesystem (run after manual renames or rollbacks):**
```
python constitution/harness/scripts/next_number.py --seed
```

---

## Rules

1. **Claim before creating the file.** Run the script first, get the number, then
   create the file using that number. Never create the file first and derive the
   number afterward.

2. **If you abandon a claimed number** (the task was cancelled after G0 but before
   the file was created), run `--seed` to resync the counter with the filesystem.
   The abandoned number is skipped — that is acceptable.

3. **Peek does not reserve.** Two parallel sessions calling `--peek` get the same
   number. Only `claim` (without `--peek`) is atomic and exclusive.

4. **Do not edit `number-registry.db` manually.** Use `--seed` to correct drift.

5. **The registry is in `.github/pipeline/number-registry.db`** — it is committed
   to the repository so all sessions on the same checkout share the same counters.

---

## How it works (for transparency)

The script uses a SQLite database with `BEGIN EXCLUSIVE` transactions. Only one
process can hold the exclusive lock at a time — any concurrent caller blocks until
the lock is released (up to 15 seconds timeout). This makes it safe to run from
two VS Code chat sessions simultaneously on the same machine.

SQLite was chosen over file-locking because:
- It is cross-platform (Windows + Linux + Mac)
- It is already in Python stdlib — no extra dependencies
- `EXCLUSIVE` transaction semantics are well-defined and tested
