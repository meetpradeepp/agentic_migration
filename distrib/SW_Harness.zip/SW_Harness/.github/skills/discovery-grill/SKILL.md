﻿---
name: discovery-grill
description: >
  Grill the user relentlessly about a raw idea or problem to uncover every
  constitutional implication for {project_name}. Walk each branch of the design
  tree one question at a time. Explore the codebase to answer questions you
  can answer yourself. Produce a discovery brief the orchestrator uses at G0.
  Use when user has a raw idea, says "I want to build X", or asks "what would
  this take?".
---

# SKILL — {project_name} Discovery Grill

**Domain:** Pre-pipeline discovery for {project_name} constitutional design
**Used by:** @discovery agent

---

## Purpose

This skill turns a raw idea or problem statement into a complete **discovery brief** —
a structured document that the orchestrator can act on at G0. It does this by grilling
the user through every constitutional dimension of the {project_name} design space.

The grill is not a checklist — it is a branching interview. Each answer opens or closes
branches. The skill walks all open branches before closing.

---

## Protocol

### Step 0 — Codebase First

Before asking the user anything, **explore the codebase** to answer as many questions
as you can yourself:

- Scan `constitution/contracts/` for contracts that govern the topic
- Scan `constitution/adrs/` for existing decisions that apply
- Scan `specs/` for existing specs that cover or overlap the topic
- Read `.github/memory/constitution-digest.md` for the compact rule set
- Read `.github/memory/phase-status.md` to know the current phase and active work
- Read `.github/memory/ideas-backlog.md` to check if this idea was already captured

For each question below: if the codebase gives a clear answer, **state it as your
recommended answer** and move on. Only ask the user when the codebase is ambiguous
or silent.

### Step 1 — State What You Know

Before the first question, summarise:
- What the idea is (restate it in your own words)
- What the codebase already has that is relevant
- What is clearly missing or unclear

This prevents the user from re-explaining context you already have.

### Step 1.5 — Terminology Sharpening

Before asking the first question, scan the user's request for vague or overloaded terms.
For each problematic term, call it out immediately — do not let ambiguous language enter the grill:

- **Conflicts with constitution vocabulary** — "The constitution defines 'worker' as a Kafka
  consumer process, but you said 'service' — do you mean a Kafka worker or a REST service?"
- **Overloaded terms** — "You said 'index' — do you mean a Postgres index, a vector index in
  Qdrant, or the micro-index artefact? Those are three different things."
- **Underdefined scope words** — "'Improve performance' is too broad — which FACT dimension is
  failing: Fast (latency), Accurate (correctness), Complete (coverage), or Trustworthy (audit)?"

Once a term is resolved, **capture it inline** by appending to
`.github/memory/constitution-digest.md` under a `## Terminology Resolutions` section
(create the section if absent). Do not batch these — write each resolved term as it is
agreed, before moving to the next question.

### Step 1.6 — Visual Signal Extraction (IDEA-H-006, optional)

If the user attaches an **image** (architecture diagram, whiteboard photo, UI mockup,
ER diagram, or sequence diagram), extract entity and constraint signals before the grill loop:

1. **Describe visible structure:** List boxes, nodes, labels, arrows, and boundary lines.
2. **Infer entity types:** Match to known concepts — services, tables, events, queues,
   external systems, users/actors.
3. **Infer constraints from arrows:** Directed arrows = data flow or calls; bidirectional =
   sync exchange; dashed = optional or async.
4. **Note ambiguities:** Any label that is illegible, cut off, or has no clear mapping
   to a known entity type — mark as `[unclear]`.
5. **Do NOT treat visual signals as verified facts** — they are hypotheses to confirm
   during the grill. Prefix every image-derived entity with `(from image)` in the brief.

Visual signals feed into the grill as pre-populated hypotheses:
- Present them at the start: *"From your diagram I can see X, Y, Z — I'll use these as
  a starting point and confirm each during the interview."*
- Any image entity that is not confirmed during the grill is marked `[unconfirmed]` in
  the `## Visual Signals` section of the discovery brief.

### Step 2 — The Grill Loop

Ask questions **one at a time**. Never bundle more than one question per turn.

For every question:
1. State the **branch** you are exploring (e.g. "Data model branch", "Event pipeline branch")
2. Ask the **single most important unresolved question** in that branch
3. Give your **recommended answer** with a one-sentence rationale
4. Wait for the user's response before moving to the next question

When the user answers, either:
- **Confirm and close** the branch sub-question → move to the next open branch
- **Open a new sub-branch** if the answer reveals new ambiguity → resolve it before moving on

**During every user response, apply these two checks before advancing:**

- **Terminology check** — if the answer contains a vague or conflicting term, stop and sharpen
  it (same rules as Step 1.5) before closing the branch. Capture the resolved term inline.
- **Code cross-reference** — if the user states how something currently works, verify the claim
  against the codebase. If a contradiction is found, surface it immediately: "The code in
  `{src_dir}/<module>` does X, but you said Y — which is the intended behaviour?" Do not advance
  the branch until the contradiction is resolved.

**Scenario stress-test** — for every domain relationship or boundary decision, invent one
concrete edge-case scenario that probes it before closing the branch. Example: "If two ingest
events arrive for the same file within the same Kafka offset window, what should happen?"
The user's answer must be consistent with the constitution; if it is not, flag the conflict.

### Step 3 — Constitution Impact Sweep

After the functional design is resolved, sweep through every constitutional dimension
and ask (or self-answer from codebase):

| Dimension | Question |
|-----------|----------|
| **Event pipeline** | Does this introduce a new Kafka event type or topic? (SYS-C-0006) |
| **Data model** | Does this require a new table, column, or index? (SYS-C-0010) |
| **Public interface** | Does this add a new public class, function, or API surface? |
| **ADR needed** | Does any decision here lack an existing ADR to back it? |
| **Contract amendment** | Does any existing contract need updating to permit or mandate this? |
| **Phase fit** | Is every component here deliverable in the current phase? (HAR-C-0007) |
| **FACT compliance** | Does this uphold Fast / Accurate / Complete / Trustworthy? (SYS-C-0001) |
| **Testing surface** | What is the unit, integration, and eval test surface for this work? |
| **Anti-patterns** | Does any part of this design touch a banned pattern? (HAR-C-0004) |

For each dimension where the answer is YES or UNKNOWN → mark it as an open item in
the discovery brief.

### Step 4 — Risk Register

After the sweep, ask:
- "What could silently go wrong if this is built without resolving [open item]?"
- Capture each risk as a brief entry: risk, mitigation, must-resolve-before.

### Step 5 — Close and Produce

Once all branches are resolved (no open questions remain), produce the
**Discovery Brief** (see Output section below).

---

## Grill Question Bank

Use these question starters when exploring each branch. Do not read them out verbatim —
adapt them to the specific idea.

### Problem Branch
- What exact problem does this solve? Can it be stated in one sentence?
- Which FACT dimension does this violate today? (Fast / Accurate / Complete / Trustworthy)
- Who experiences this problem — which agent, tool, or human workflow?
- What happens if we do NOT solve it?

### Design Branch
- What is the simplest design that solves the problem without violating any contract?
- Which existing {project_name} component is closest to what you need?
- Is this a new worker, a new rule, a new MCP tool, a new admin endpoint, or something else?
- What are the hard constraints from the constitution that shape the design?

### Data Model Branch
- What new data needs to be stored? What existing table is it closest to?
- Is this a new table (→ ADR required) or columns on an existing table (→ migration)?
- What is the primary key strategy? (UUID, composite, sequence?)
- What are the FK relationships, and do they cross existing table boundaries?

### Event Pipeline Branch
- What triggers this work — which Kafka event does it consume?
- What does it emit when done — what event signals completion?
- Is SRP maintained — does this worker do exactly ONE thing?
- What is the idempotency key?

### Interface Branch
- What new public function or class signatures are needed?
- What does the caller pass in and what does it receive back?
- Does this change any existing interface (→ breaking change risk)?

### Phase Fit Branch
- Every component named here — does it appear in the current phase's deliverable list?
- What would need to be deferred to a later phase?
- Is there a dependency on a not-yet-started spec?

### ADR Branch
- What is the core architectural decision being made here?
- Are there two or more reasonable alternatives? (→ ADR needed)
- Which existing ADRs would this supersede or amend?

**ADR 3-criteria gate** — only recommend a new ADR when ALL THREE are true:
1. **Hard to reverse** — the cost of changing this decision later is meaningful
2. **Surprising without context** — a future reader will wonder "why did they do it this way?"
3. **Genuine trade-off** — there were real alternatives and this one was chosen for specific reasons

If any criterion is missing, skip the ADR. Record the decision in the discovery brief's
"Resolved Decisions" table instead — no ADR file needed.

---

## Output — Discovery Brief

Produce this document at the end of the grill. Save it to
`.github/pipeline/workspace/<idea-slug>/discovery-brief.md` if a workspace exists,
or present it inline for the user to review.

```markdown
# Discovery Brief — <Idea Title>

**Date:** <ISO8601>
**Status:** Draft — awaiting orchestrator triage

---

## Problem Statement
One-sentence description of the problem being solved.

## Proposed Solution
Two-to-four sentence summary of the agreed design.

## Constitutional Impact

| Dimension | Impact | Evidence |
|-----------|--------|----------|
| Event pipeline | New event: `{project_name}.<event>` | SYS-C-0006 |
| Data model | New table: `<table_name>` | SYS-C-0010 |
| Public interface | New class: `<ClassName>` | — |
| ADRs needed | ADR-XXXX: <decision title> | — |
| Contract amendments | Contract NN §M: <what changes> | — |
| Phase fit | ✅ All components in Phase N | HAR-C-0007 |
| FACT compliance | ✅ No FACT violations | SYS-C-0001 |
| Anti-patterns | ✅ None triggered | HAR-C-0004 |

## ADRs Required

- **ADR-XXXX** (new): <title> — <one-line rationale>
- **ADR-YYYY** (amendment): <what changes and why>

## Contracts Requiring Amendment

- **Contract NN**: <section> — <what needs to change>

## Specs Required

- **SPEC-NNNN** (new): <title> — <scope in one sentence>
- **SPEC-MMMM** (amendment): <what changes>

## Ideas Backlog Entry

> To be appended to `.github/memory/ideas-backlog.md`

### IDEA-XXXX: <Title>
- Date: <ISO8601>
- Status: Captured
- Problem: <one paragraph>
- Phase fit: Phase N — <rationale>
- Open questions: <any unresolved items>
- Recommendation: <ADRs + Contracts + Specs + Amendments>

## Risk Register

| Risk | Mitigation | Must resolve before |
|------|-----------|---------------------|
| <risk> | <mitigation> | <spec or phase milestone> |

## Resolved Decisions

> Compact log of every question asked and the agreed answer.

| Question | Answer | Rationale |
|----------|--------|-----------|
| ... | ... | ... |

## Visual Signals

> Present only when an image was attached to the discovery prompt.
> Image-derived signals are advisory — confirmed items are integrated into the brief;
> unconfirmed items are listed here for the spec-writer to verify or discard.

| Entity | Type | Source | Status |
|--------|------|--------|--------|
| `<label from image>` | service / table / event / actor / queue | from image | confirmed / [unconfirmed] |

*(Omit this section entirely if no image was provided)*
```
