﻿# SKILL — {project_name} Triage Decision (PATCH vs FULL)

**Domain:** {project_name} pipeline triage at G0
**Used by:** @orchestrator at G0; @spec-patcher to confirm mode before starting

---

## Purpose

This skill encodes the deterministic PATCH vs FULL decision tree. Load it at G0 when
classifying work. Answer every question in order. The **first YES to a FULL question
locks the mode as FULL** — continue only to document the reason, not to find a PATCH
path.

---

## Decision Tree

Work through these questions against the user's request and the spec/ADR search results
from G0 actions 3–5.

### Questions that force FULL mode

Answer each YES or NO based on evidence, not assumption.

| Q | Question | Evidence to check |
|---|----------|-------------------|
| Q1 | Does this introduce a **new public interface**, class, or API surface? | Search `specs/` for the class name; if absent → YES |
| Q2 | Does this **change a DB schema** or require a new Alembic migration? | Check `alembic/versions/` and SYS-C-0010 table list |
| Q3 | Does this **add or change a Kafka event type or topic**? | Check `constitution/system/contracts/SYS-C-0006-event-pipeline-contract.md` topic table |
| Q4 | Does this require a **new ADR** or changes an existing contract file? | Any edit to `constitution/` → YES |
| Q5 | Does this touch **more than one source module** (two or more distinct `.py` files in `src/`)? | Count affected source files; if > 1 → YES |
| Q6 | Is the **spec file new** (not amending an existing one)? | If `specs/phase-N/SPEC-NNNN-<name>.md` does not exist → YES |
| Q7 | Does this change an **agent file** in `.github/agents/`? | Any agent edit → YES |
| Q8 | Is this an ENHANCEMENT that will **add > 50 lines** to the existing spec? | Estimate from scope description → if > 50 → YES |

If ANY of Q1–Q8 is YES → **mode = FULL**.

### Questions that confirm PATCH mode

Only reach these if ALL of Q1–Q8 are NO.

| Q | Question | Evidence to check |
|---|----------|-------------------|
| P1 | Is this a **bug fix inside one existing implemented spec**? | Spec has `Status: Implemented`; defect traced to that spec |
| P2 | Is the fix contained to **a single source file**? | Count affected `.py` files in `src/` |
| P3 | Are **no new public names** introduced (no new classes, functions, or constants added to the interface)? | Check spec's `## Interface contract` — fix stays within existing signatures |
| P4 | Are tests **additions only** (no test file restructuring)? | New test functions added to existing `test_*.py` files |

If ALL of P1–P4 are YES → **mode = PATCH**.

If any of P1–P4 cannot be confirmed YES → **escalate to FULL** (when in doubt, FULL is the safe choice).

---

## Borderline Cases — Always FULL

These situations look like PATCH but are FULL regardless of the answers above:

- Any change to `constitution/` files (contracts, ADRs, schemas)
- Any new `alembic/versions/` migration file
- Any edit to `.github/agents/` agent definitions
- Any change that triggers a CHANGES.md `[CONSTITUTION]` entry
- Any fix that reveals the spec's `## Interface contract` was wrong (interface fix = spec rewrite)

---

## Output Format for G0

When declaring mode, always state:

```
**Mode declared: FULL | PATCH**
**Reason:** <one sentence citing the specific Q-number that drove the decision>
**Evidence:** <what you searched and what you found>
```

Examples:
- `Mode: FULL — Q1 YES: introduces new class LanguagePackRegistry not present in any existing spec`
- `Mode: FULL — Q4 YES: requires amendment to constitution/system/contracts/SYS-C-0007-mcp-contract.md`
- `Mode: PATCH — All Q1–Q8 NO; P1–P4 confirmed: single-file fix to auth middleware, no new interface`

---

## PATCH Mode Gate Reduction

In PATCH mode the pipeline skips G2 (spec review) and G3 (full planning). Remaining
gates:

```
G0 (triage) → G1 (@spec-patcher amends Deviations) → G4 (coder fixes) → G5 (review) → G6 (release)
```

User approval is required at G1 (show amended spec) and G5 (show code + tests).
The validator still runs VM.1 at G4→G5 — mechanical coverage check is never skipped.

---

## HOTFIX Mode — Production-Critical Bypass

HOTFIX is reserved for **production-breaking bugs only** — system down, data loss, or
security vulnerability requiring immediate patch. It is NOT a shortcut for inconvenient
spec overhead.

### HOTFIX eligibility — all four conditions must be true

| # | Condition | Evidence to check |
|---|-----------|-------------------|
| H1 | The defect is in an **existing `Status: Implemented` spec** | Confirm spec exists and is implemented |
| H2 | The fix touches **exactly one source file** | Count `.py` files under `src/` in the diff |
| H3 | **No new public interface** introduced (no new class, function, or constant added to the module's public surface) | Check that fix stays within existing signatures |
| H4 | **No schema change**, no new Kafka event/topic, no new ADR required | Check alembic/, SYS-C-0006, constitution/ |

If ANY condition is false → **escalate to PATCH or FULL**.

### HOTFIX gate flow

```
G0 (triage + eligibility check) → G4 (coder: test first, then fix) → G5 (review + SAST) → G6 (release)
```

Gates skipped: G1 (spec-writer), G2 (spec-review), G3 (planner).

**What still happens inside G4:**
- `@spec-patcher` writes a one-paragraph Deviations entry to the existing spec **before** any code is written
- `@coder` writes a failing test first (`test(...)` commit), then the fix (`fix(...)` commit) — TDD is never skipped
- `@validator` runs VM.1 (coverage check) before G5

**User approval required at:** G0 (confirm HOTFIX eligibility) and G5 (code + tests shown).

### Output format for G0 HOTFIX declaration

```
**Mode declared: HOTFIX**
**Reason:** <one sentence — why this cannot wait for PATCH/FULL>
**Eligibility:** H1 ✓ | H2 ✓ | H3 ✓ | H4 ✓
**Affected spec:** SPEC-NNNN
**Single source file:** {src_dir}/<module>/<file>.py
```

### HOTFIX is NOT appropriate for

- Improvements, refactors, or cleanups ("it bothers me")
- Bugs that don't break production (degrade quality, not correctness)
- Fixes requiring more than one source file
- Anything touching a config field, Kafka event, or DB schema
