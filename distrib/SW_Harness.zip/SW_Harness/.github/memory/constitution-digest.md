﻿# Constitution Digest — SW_Harness Quick Reference

> **Source of truth:** `constitution/harness/contracts/`.
> This digest is a compact reference for agent context optimization (HAR-ADR-0002).
> When exact contract wording is needed, load the full contract file.
> SYS-C contracts are project-level — each project creates its own (HAR-ADR-0021).

---

## HAR-C-0001 — Coding Standards
- `from __future__ import annotations` on every file
- Module docstring mandatory: one sentence + `Implements: SPEC-NNNN`
- Import order: stdlib → third-party → {project_name} (absolute only, no relative imports)
- Type hints on all public functions — no exceptions
- One class = one responsibility; dependencies injected via constructor
- No class-level mutable state; no side effects in constructors
- Function soft limit: 30 lines of logic
- Typed exceptions only — no bare `except:`, chain with `from exc`
- Config via `{src_dir}.config.Settings` (Pydantic BaseSettings) — no magic numbers
- SQL: parameterised queries only — f-string SQL is a security blocker
- Logging: `logging.getLogger(__name__)`, structured `extra={}`, never `print()`
- No secrets in code — environment variables only
- **Traceability** (§10): every non-trivial branch cites spec AC or contract rule; every bug fix references spec deviation; orphan TODOs banned
- **Tooling** (§11): uv + ruff + mypy + pytest; all config in `pyproject.toml`; pre-commit hooks enforce all rules
- **Lint safety** (§11): `ruff --fix --select TC` is BANNED — silently moves runtime imports into TYPE_CHECKING, causing NameError. Run `ruff check` read-only; fix TC violations manually. Use `# noqa: TC003` with justification if import must stay at runtime.


## HAR-C-0002 — SDLC Contract
- Lifecycle: Spec → Tests (Red) → Implementation (Green) → Review → Merge → Release
- Spec before code. Tests before implementation. Always.
- Spec format: 14 mandatory sections (§2) — none may be omitted
- TDD order: `test(...)` commit MUST precede `feat(...)` commit
- Commit format: `<type>(<scope>): <description> [Phase N]`
- PR max 500 lines changed; one human review minimum
- **10-point review checklist (§6)**: spec conformance, interface, standards, coverage, anti-patterns, events, orphan data, AC coverage, traceability, SAST report (HAR-ADR-0005). **HAR-ADR-0011 adds 4 sub-bullets**: (a) Pydantic `Field(description=)` ↔ `@field_validator` allowed-values cross-check [Check 2]; (b) YAML config inline env-var comment correctness (`ECLE_`+`UPPER_SNAKE_CASE`) [Check 3]; (c) broad `except Exception` must not swallow sub-check errors [Check 5]; (d) migration-head literals in integration tests updated when `alembic/versions/` changes [Check 7]
- **SAST at G5**: `@sast` agent runs `bandit` + `pip-audit`; FAIL verdict blocks merge (exception: zero-runtime tasks per HAR-ADR-0008 §Opt-5 — FAIL is advisory); WARN requires reviewer acknowledgement; always on full `src/` tree
- **§7 rules 14–15** (new): Error handling rows must include literal `Body` JSON schema; Interface contract must include `__init__` for any class whose constructor args are integration points (middleware, services, factories)
- **§8 Rule 16** (new): G6 mandatory commit sequence — `@release-manager` commits all SPEC changes before closing G6; TDD order (`test` before `feat`); full 10-step order in `release-manager.agent.md §6`; `git status --short` must be clean; `git add .` banned
- Every test file: `# Implements: SPEC-NNNN` header
- Phase governance: `Phase:` header must match HAR-C-0007
- **§9 Cross-spec wiring rule** (new): BUG_FIX/ENHANCEMENT on a spec with `Depends on:` MUST include ≥1 integration test exercising the dependency boundary; reviewer blocks at G5 if absent


## HAR-C-0003 — Testing Contract
- Pyramid: 70% unit, 20% integration, 10% E2E
- Coverage: new code ≥80%, interfaces/schemas ≥95%, grounding verifiers 100%
- **Per-subtask gate (G4)**: after each `implement` subtask, run `pytest --cov=<new_module> --fail-under=80`; sub-80% blocks the subtask — add missing tests before moving on
- Unit tests: no I/O, < 100ms, deterministic, `test_<function>_<scenario>`
- Integration tests: real backends, < 5s, full event chain, clean up in teardown
- 8 eval suites are hard CI gates (see contract for full list)
- Performance: `sanitize()` <10ms, `parse()` <10ms, `extract()` <50ms, DB insert <100ms, ANN search <50ms
- **§3a One canonical test file per source module** (new): unit tests for `src/ecle/foo/bar.py` must live only in `tests/unit/test_bar.py`; splitting across multiple files is banned (exceptions: integration tests by flow name, `test_*_hooks.py` with own spec)


## HAR-C-0004 — Anti-Patterns (All Banned)
- A1: God class / God worker (multi-responsibility)
- A2: Direct worker-to-worker calls (imports, HTTP, shared DB)
- A3: Inheritance for code reuse (non-polymorphic)
- A4: Premature abstraction / YAGNI
- A5: DRY violation (copy-pasted logic)
- A6: Hardcoded backend references
- A7: Global mutable state
- A8: Shared DB connection between workers
- A9: Bare `except` / silent swallowing
- A10: f-string SQL (injection risk)
- A11: Secrets in code
- A12: Functions > 30 lines of logic
- A13: Nested conditionals > 3 levels
- A14: `None` as sentinel / None for errors
- A15: Synchronous processing in API thread
- A16: Worker writing to another worker's owned table
- A17: Missing idempotency key on DB inserts
- **A18: MagicMock for Pydantic Settings** (new): `MagicMock()`/`create_autospec` for `EcleSettings` is banned; use real `EcleSettings(**overrides)` or `EcleSettings.model_construct(**overrides)`


## HAR-C-0005 — Deployment Contract
- Three tiers: dev, Docker Compose, Kubernetes — same codebase, config only
- `if settings.ECLE_TIER == ...` in app code is banned
- All artifact I/O via `IArtifactStore`; no direct `open()` / `Path.read_bytes()`
- No hardcoded paths — everything from `settings`
- Workers and MCP server MUST be stateless


## HAR-C-0006 — Observability Contract
- Every component: Prometheus metrics at `GET /metrics`
- Hard SLOs: MCP p95 <1s, p99 <2s, Kafka lag <10K, ingestion >99%, DLQ=0
- OpenTelemetry tracing; new trace per Kafka consumer (linked by `X-Request-Id`)
- Every event payload: `X-Request-Id` and `X-Trace-Id` mandatory
- Repo health gauges updated transactionally at end of ingestion


## HAR-C-0007 — Phase Roadmap Contract (amended by HAR-ADR-0004, SYS-ADR-0011, SYS-ADR-0052)
- No spec without a phase assignment
- No phase-N+1 work until phase-N exit criteria pass
- Phases are additive — never break earlier functionality
- **Every phase is a product milestone** — each phase delivers a demonstrable user-facing capability; version tag certifies the capability works end-to-end
- **Walking skeleton** — every phase defines a minimum ordered set of specs (skeleton) that produce the milestone capability; planner MUST order skeleton specs before enhancement specs
- **Enhancement specs** — extend the skeleton within the same phase; all must be `Status: Implemented` before the version tag
- Version tag = working product increment (not just CI gates passing)
- Current phase: **Phase 3** — Milestone: natural-language semantic search via vector similarity; version tag: `v0.3.0`
- **SYS-ADR-0052 (phase reorder 2026-06-01):** Phases 4–6 restructured. Cluster Centroids + sweep_coordinator + GraphQL moved to Phase 3. Phase 4 = Cross-Repo + Grounding + Feedback + **Admin Portal** (MVP gate, `v0.4.0`). Phase 5 = Ontology + DSL + **CodeGraph Explorer UI** (`v0.5.0`). Phase 6 = Enterprise Scale-Out only (`v1.0.0`) — Admin Portal removed from Phase 6.
- **SYS-ADR-0011 (Leiden amendment 2026-05-31):** Phase 2 walking skeleton updated — Neo4j replaces generic ITopologyGraph; Phase 6 HA cluster note updated
- Phase 2 walking skeleton: (1) ITopologyGraph Neo4j backend → (2) build_graph worker → (3) compute_topology worker (Leiden, SYS-ADR-0011) → (4) fact_impact MCP tool
- Phase 3 walking skeleton: (1) Embedding model ADR → (2) IVectorStore **Qdrant** (SYS-ADR-0052; no ChromaDB) → (3) chunk_file worker → (4) batch_embed worker → (5) fact_search MCP tool; **enhancements**: cluster_centroids worker, sweep_coordinator, GraphQL endpoint
- Phase 4 walking skeleton: build_contract_registry → link_contracts → cross_repo_indexer → Grounding verifier → Admin Portal UI (SYS-ADR-0026); **enhancements**: ecle_feedback, learning_analyzer, coverage_gap_aggregator
- Phase 5 walking skeleton: Domain ontology YAML → detect_dsl_mappings → ontology_enricher → fact_view_database → CodeGraph Explorer UI (IDEA-0026)
- Phase 6 walking skeleton: PostgreSQL backend → Qdrant backend → Neo4j HA cluster → Multi-tenancy; **enhancements**: KEDA autoscaling, Observability stack, Disaster recovery, Document embedding, SYS-ADR-0033 webhook receiver
- Phase 1 walking skeleton: SPEC-0001 → SPEC-0008 → SPEC-0013 (API Key Auth) → SPEC-0009 → SPEC-0005 → SPEC-0006 → SPEC-0007
- Phase 1 enhancements: SPEC-0004, SPEC-0002, SPEC-0010, SPEC-0011, SPEC-0014 (fact_find_table_owners), SPEC-0015 (fact_find_function_callers)


## HAR-C-0008 — Implementation Guidelines
- ADR consumption mandatory: coder, planner, code-reviewer read ADRs from `<workspace_path>/adrs/` (two-step resolve per HAR-ADR-0008 **amended by HAR-ADR-0012**: orchestrator calls `pipeline_db.py get_active_tasks()` → gets `workspace_path` → agents read `<workspace_path>/task-state.json` for full state; agents do NOT read `state.json` or `state.db` directly)
- Worker pattern: inherit `WorkerBase`, inject dependencies, `process()` is idempotent
- Backend abstraction: business logic depends on interfaces, factory selects implementation
- Event emission: produce → flush → offset committed by WorkerBase
- Config pattern: `{src_dir}.config.Settings` for tunable values, `ecle/constants.py` for fixed values
- DB access: parameterised queries, filter `is_current=true`, include `tenant_id`
- Test patterns: unit (no I/O), integration (real backends), idempotency test required per worker
- File organization: one worker per file, one MCP tool per file, no cross-worker imports
- DI wiring: factory at startup, no singletons, no import-time side effects
- Error handling: transient → retry with backoff, permanent → DLQ


## HAR-C-0009 — Proof Obligation Registry (implements HAR-ADR-0020)
- Every constitution contract rule must have a registered `proof_status`: `VERIFIED | PARTIALLY_VERIFIED | HUMAN_REVIEW | UNVERIFIED`
- Five contract classes: `ENUMERATIVE` (inventory diff), `STRUCTURAL` (AST/static), `BEHAVIORAL` (property/mutation tests), `QUALITY` (benchmarks/coverage), `SEMANTIC` (eval corpus)
- Three registries: `proof-strategies.yaml` (PS-0001…PS-0012 closed enum), `evidence-providers.yaml` (VM.1…VM.5+), `assertions/<contract-id>.yaml` (atomic assertions per contract)
- Atomic Rule Principle: one assertion = one class = one proof strategy; compound rules must be split
- VM.5 (`check_contract_fidelity.py`): ENUMERATIVE inventory diff against alembic DDL or event schema; exit 1 on missing item; closes SYS-C-0010 failure class
- Dispatcher (`run_proof_dispatcher.py`): reads assertions YAML, resolves proof strategy, invokes evidence provider; runs at G4/G5
- Coverage report (`report_coverage.py`): VERIFIED+PARTIALLY_VERIFIED / total by class; `UNVERIFIED` in denominator always; runs at G6
- CI gate (`check_rule_classification.py`): every assertion must have valid `proof_status`; exit 1 on unclassified; runs on every PR touching `constitution/`
- Phase 1 bootstrap: assertions files for `SYS-C-0010`, `SYS-C-0006`, `HAR-C-0002`, `HAR-C-0003` only; all others default to absent (UNVERIFIED by declaration)
- `HUMAN_REVIEW` and `UNVERIFIED` are first-class honest statuses — not failures; their presence in coverage report is legible accounting, not a gate blocker

