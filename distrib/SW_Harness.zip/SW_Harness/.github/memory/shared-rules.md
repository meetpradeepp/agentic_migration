﻿# Shared Agent Rules

> **Source of truth:** Constitution contracts. This file extracts rules duplicated
> across 6–10 agents into a single reference (HAR-ADR-0002). All agents load this file
> instead of embedding their own copies.

---

## 1. TDD Order (HAR-C-0002 §1, §4)

- Tests are written FIRST — committed as `test(<scope>):` before any `feat(<scope>):` commit
- Red phase: all tests MUST FAIL before implementation begins
- Green phase: minimum implementation to make tests pass
- Refactor phase: structural improvements under green tests only
- Reviewer verifies TDD order via `git log --oneline`

## 2. Anti-Pattern Quick Scan (HAR-C-0004)

Before writing or reviewing code, grep for:
| Pattern to grep | Anti-pattern |
|---|---|
| Class with 3+ public methods doing unrelated things | A1 God class |
| `from {src_dir}.workers.X import` inside another worker | A2 Cross-worker import |
| `httpx.post\|requests.post` targeting a worker URL | A2 Direct HTTP call |
| `class X(Y):` where Y is not genuinely polymorphic | A3 Inheritance for reuse |
| `ABC` with only one implementation and no second planned | A4 YAGNI |
| Same SQL/logic block in 2+ files | A5 DRY violation |
| `sqlite3.connect\|SQLiteBackend` in business logic | A6 Hardcoded backend |
| Module-level mutable variables (`_cache = []`) | A7 Global mutable state |
| `except:` or `except Exception as e: pass` | A9 Bare except |
| `f"SELECT.*{` or `"SELECT.*" +` | A10 SQL injection |
| `PASSWORD = "` or `API_KEY = "` | A11 Secrets in code |

## 3. Python File Standards (HAR-C-0001 §2)

Every `.py` file MUST have:
```
"""<module> — <one-line description>. Implements: SPEC-NNNN"""
from __future__ import annotations
# stdlib → third-party → {project_name} (absolute imports only)
```

Every `test_*.py` file MUST have:
```
"""test_<module> — <description>. Implements: SPEC-NNNN. Tests: <target>"""
from __future__ import annotations
```

## 4. Commit Message Format (HAR-C-0002 §4)

```
<type>(<scope>): <description> [Phase N]
```
Types: `feat` | `fix` | `test` | `refactor` | `docs` | `chore` | `perf`
- Present tense, imperative mood ("add", not "added")
- One logical change per commit
- Reference spec/ADR in commit body

## 5. Queue/Event Governance (sample — adapt to project's messaging technology)

- Workers communicate via events/queue ONLY — no direct calls
- Topic naming convention: `{project_name}.{domain}.{action}` (e.g. `{project_name}.{domain}.{event}`)  _(sample — update to match your queue tech)_
- Consumer group: `{project_name}.{worker_name}`
- `enable.auto.commit=False` — commit offset only after durable write
- Every event payload includes `X-Request-Id` and `X-Trace-Id`
- DLQ topic: `{project_name}.dlq.{event_type}`
- Workers are idempotent — same event twice = same DB state

## 6. Spec Traceability (HAR-C-0002 §7)

- Every source file: module docstring with `Implements: SPEC-NNNN`
- Every test file: header with `Implements: SPEC-NNNN` and `Tests: <target>`
- Every commit body: reference to spec or ADR being implemented

## 7. Phase Discipline (HAR-C-0007)

- Every spec has a `Phase:` header matching a phase in HAR-C-0007
- No phase-N+1 work until phase-N exit criteria pass
- Components, workers, events must exist in the declared phase's deliverables
- If work doesn't fit current phase scope → defer to later phase

## 8. Configuration & Secrets (HAR-C-0001 §6, HAR-C-0005)

- All tunable values from `{src_dir}.config.Settings` (Pydantic BaseSettings)  _(sample — adapt to project's settings class)_
- Fixed constants in `{src_dir}/constants.py`
- No secrets in code — environment variables only
- No hardcoded paths — everything from `settings`
- No `if settings.{PROJECT_NAME_TIER} == ...` in application code

## 9. Error Handling (HAR-C-0001 §5)

- Always name specific exception types
- Chain with `from exc` to preserve traceback
- Never use exceptions for flow control
- Custom exception hierarchy per module
- Workers: transient errors → retry with backoff; permanent → DLQ

## 10. No LLM in Runtime

{project_name} is deterministic. AI assists development only — never execution.
No LLM calls, no generative AI, no prompt templates in `{src_dir}/`.

## 11. Inline Traceability (HAR-C-0001 §10)

Every non-trivial line of code must be traceable by a human maintainer:

| What | Comment format |
|---|---|
| Acceptance criteria | `# AC-N: <brief description> (SPEC-NNNN)` |
| Error handling | `# Error: <condition> (SPEC-NNNN §Error handling)` |
| Contract rule | `# Contract NN §M: <rule summary>` |
| ADR decision | `# ADR-NNNN: <why this approach>` |
| Bug fix | `# Fix: <what> (SPEC-NNNN §Deviations DEV-NNN)` |
| Enhancement | `# Enhancement: <what> (SPEC-NNNN §Deviations ENH-NNN)` |
| TODO | `# TODO(SPEC-NNNN): <what>` — orphan TODOs banned |

## 12. Build Commands (HAR-C-0001 §11)

```bash
uv sync --extra dev            # Install with dev tools
uv run ruff check src/ tests/  # Lint
uv run ruff format src/ tests/ # Format
uv run mypy {src_dir}/          # Type check
uv run pytest tests/unit/ -v   # Unit tests
uv run pytest tests/ -v        # All tests
```

## 13. Naming Clarity Rule (first-pass quality)

- Use descriptive business-variable names by default; avoid single-letter names outside trivial loop indexes.
- Prefer intent-rich names tied to spec vocabulary (`tenant_id`, `repo_id`, `sql_query`, `db_connection`, `rule_loader`).
- Before final verification, perform a readability sweep to remove ambiguous names and avoid rename churn in follow-up passes.

## 15. Planner — Export Contract Binding (prevent class-name drift)

When producing a plan for a NEW_FEATURE or ENHANCEMENT spec, the planner MUST:

1. **Extract every exported class and constant name** from the spec's "Interface contract" / "Exported Types" section verbatim.
2. **Add a `spec_exports` field** to every test subtask and its paired implementation subtask in `plan.json`:
   ```json
   "spec_exports": {
     "classes": ["CallerQuery", "CallerResult", "CallerResponse", "CallerLineage"],
     "constants": ["MAX_RESULTS", "MAX_DEPTH", "QUERY_TIMEOUT_MS"]
   }
   ```
3. The coder MUST verify that every name in `spec_exports` is used exactly as-is in the implementation. Any deviation is a spec violation requiring a `## Deviations` entry.

**Rationale:** Stream-7 G5 uncovered a full test+implementation rewrite because the coder invented `FunctionCallersQuery` instead of `CallerQuery` (as defined in the spec). This binding eliminates the root cause.

## 16. Coder — SQL Table Name Cross-Reference (prevent runtime blockers)

Before finalising any SQL in an implementation subtask, the coder MUST:

1. List every table name used in the SQL (e.g., `function_facts`, `file_facts`, `function_calls`).
2. Confirm each table exists in at least one migration file under `{migration_dir}/`. Use grep:
   ```
   grep -r "<table_name>" {migration_dir}/
   ```
3. If a table name does NOT appear in any migration, it must not be used — raise the discrepancy before producing the implementation.

**Rationale:** Stream-7 used `JOIN functions` in SQL (table does not exist); spec said `function_facts`. Unit tests passed because the DB was mocked; this was only caught at the validator stage and would have failed at runtime.

## 17. Mechanical Verification Scripts (close AI-attestation gap)

Three scripts in `scripts/` provide **independent, executable evidence** that
replaces AI-only attestation for critical compliance checks. Agents and the
orchestrator MUST reference their output as evidence — not substitute their own
judgement for a script result.

| Script | Purpose | Run by | Gate |
|--------|---------|--------|------|
| `scripts/check_spec_test_coverage.py --spec <file>` | Confirms every AC and T-ID in a spec has a matching test stub in the declared test files. Exit 0 = clean; exit 1 = gaps found. | @validator (VM.1/VM.2) | After G4, at G5 |
| `scripts/check_phase_gate.py --phase <N>` | Confirms all phase-N specs are `Status: Implemented` before phase exit. Exit 0 = ready; exit 1 = not ready. | @release-manager, @validator (VM.3) | G6, phase transition |
| `scripts/pipeline_metrics.py` | Extracts cycle time, gate averages, and phase completion % from `workspace/*/task-state.json` (HAR-ADR-0008); slim `state.json` index used only for task list. No exit gate — advisory metrics for audit evidence. | @orchestrator | G6, on-demand |

**Rules:**
- A VM.1 exit code 1 blocks G5 entry. The coder must add missing test stubs.
- Script output must be pasted verbatim into the compliance report — paraphrasing is not evidence.
- If scripts cannot be run in the current session context, mark the check `UNVERIFIED` (not PASS) and escalate to the orchestrator.

## 17. FACT Envelope — Use the Shared Builder (prevent incomplete envelopes)

All MCP tool implementations MUST use the project's shared fact-builder helper to construct the FACT dict.  _(Sample: `{src_dir}.mcp.tools._fact_builder.build_fact_envelope()`)_  Never assemble the envelope inline from scratch.

**Mandatory kwargs:**
`duration_ms`, `timed_out`, `timeout_ms`, `routing`, `result_count`, `limit`, `truncated`, `coverage_warnings`, `lineage_complete`, `query_plan`

**Optional:** `extra_trustworthy: dict` for tool-specific fields (e.g., `unresolved_callees`).

**Rationale:** Stream-7 G5 required three remediation cycles to fix 9 missing FACT envelope fields. The shared builder encodes the full SYS-C-0007 §2 structure once and is validated once.

## 14. Token & Memory Efficiency Protocol (HAR-ADR-0002 / HAR-ADR-0009 — Non-Bypassable)

1. **Cluster-first (HAR-ADR-0009):** Load your role's cluster digest files from `.github/memory/agent-clusters.md` instead of the mega-digest. Find your cluster, then load only the listed `contract-digests/*.md` files. This replaces the mega-digest (`constitution-digest.md`) as the primary contract load path for all agents except orchestrator, discovery, validator, and spec-reviewer.
2. **Mega-digest use:** `constitution-digest.md` is loaded by orchestrator and discovery for broad orientation. Validator and spec-reviewer load full contracts. All other agents use their cluster files.
3. **Escalate only:** Open full contracts (`constitution/contracts/`) only when exact wording is required or ambiguity is unresolved. Cite the section.
4. **One-pass:** Read each memory source once per gate/invocation. Re-read only on: file changed, gate changed, new user input, or validator requests exact citation.
5. **No redundant re-reads:** Do not re-open unchanged memory files in the same cycle.
6. **Windowed retrieval:** Prefer targeted section reads over full-file reads for large artifacts.
7. **Evidence over verbosity:** Retain contract/ADR/spec refs in summaries; never drop decision evidence.
8. **Session-persistent reads:** HAR-C-0008 full text is read once at G4 start by coder/tester/refactor and is not re-read on subsequent subtasks in the same session.
9. **Hard-stop precedence:** Token optimization NEVER relaxes gates, approvals, validator calls, or hard stops.
8. **Session-persistent files:** Within a G4 implementation session, `constitution/harness/contracts/HAR-C-0008-implementation-guidelines.md` is read ONCE at the start of the first subtask. Skip re-reading on all subsequent subtasks in the same session — the file does not change between subtasks.

## 18. Session Efficiency — Extended Persistence Rules

**G4 session-persistent artifacts (coder, tester, refactor — read once at G4 start, skip on all subsequent subtasks in the same session):**
- `HAR-C-0008-implementation-guidelines.md` (existing §14.8)
- `<workspace_path>/spec.md` — does not change mid-G4; reference sections by heading
- `<workspace_path>/adrs/SYNOPSIS.md` — ADR decisions are stable; escalate to full ADR file only on-demand

**Orchestrator session-start fast path:**
- If `task-state.json.active_subtask` is a non-null object (active G4 task) → skip `constitution-digest.md` and `event-catalogue.md`; load only `shared-rules.md` + `phase-status.md` + `agent-clusters.md`
- Full 5-file load reserved for: G0 triage, gate transitions, and sessions where no active task exists

**G5 pre-mechanical gate (orchestrator checks before invoking review agents):**
- `ruff check` errors → return to coder immediately
- TDD order broken in `git log` → return to coder immediately
- New module coverage < 80% → return to coder immediately
- MagicMock in unit tests (HAR-C-0004 §A18) → return to coder immediately
- Module import proof (HAR-ADR-0019 Guardrail 2): `python -c \"from {src_dir}.X import Y\"` per `spec_exports` → ImportError → return to coder; skip if no `spec_exports` in plan
- SAST report timestamp (HAR-ADR-0019 Guardrail 3): stale/absent report → proceed to Step 1 (fresh `@sast`); does not block coder
- All 6 clean → proceed to SAST + code-reviewer + tester + validator

**V3/V5 validator fast paths:**
- V3: if every PASS item has a `file:line` citation → V3.1 PASS without loading mega-digest
- V5: no mega-digest required; run 5-point targeted check directly; escalate only on suspected violation

## 19. Context Load Attestation Protocol (HAR-ADR-0019)

All agents that load specific workspace or constitution files MUST follow this protocol:

**On successful load:** Log `[LOADED] <relative-path> (<size> bytes)` as the first line(s) of the response preamble — one line per file loaded — before any analysis content.

**On missing required file:** Immediately halt and respond:
`CONTEXT_INCOMPLETE: <relative-path> — required file not found. Reporting to orchestrator.`
Do NOT proceed with assumed, inferred, or training-data content as a substitute.

**Session-persistent files (§18):** For files covered by session-persistence (e.g., `spec.md`, `SYNOPSIS.md`, `HAR-C-0008`), attest only on the FIRST load in a session. On subsequent subtasks in the same G4 session, log `[SESSION-CACHED] <relative-path>` instead. No re-attestation required per subtask.

**Scope:** Applies to all agents. Validators and spec-reviewers (which load full contracts) attest to each contract file loaded. Orchestrator attests to workspace artifacts it opens at each gate. G1 SYNOPSIS.md completeness block (Guardrail 1, HAR-ADR-0019) and V4.11 (Guardrail 5) are mechanical checks that run before attestation content is evaluated.
