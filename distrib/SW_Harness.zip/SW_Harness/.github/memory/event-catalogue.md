﻿# Event Catalogue

> Auto-maintained by @discovery-grill and @coder. Do not edit manually.
> One row per event type. Add rows as new events are introduced.

| Event | Topic | Payload fields | Raised by | Consumed by | Contract |
|-------|-------|---------------|-----------|-------------|----------|

_No events defined yet. Populate after first discovery session._
