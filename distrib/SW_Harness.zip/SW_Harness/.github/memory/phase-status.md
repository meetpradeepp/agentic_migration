﻿# Phase Status

> Updated by @release-manager at each phase gate (G6).

| Phase | Name | Status | Exit criteria | Notes |
|-------|------|--------|---------------|-------|
| 0 | Harness Self-Improvement — First 8 | Active | All 8 SPEC-000[1-8] at Status: Implemented | 8 specs in pipeline as of 2026-06-08 |

---

## Phase 0 — Active Specs

| SPEC | IDEA | Title | Gate | ADR |
|------|------|-------|------|-----|
| SPEC-0001 | IDEA-H-003 | Agent Hooks via hooks.yaml | G1 (in progress) | HAR-ADR-0022 |
| SPEC-0002 | IDEA-H-005 | Per-Gate Token Budget Tracking | Implemented | HAR-ADR-0023 |
| SPEC-0003 | IDEA-H-007 | EARS Notation for Acceptance Criteria | G0_complete (queued) | HAR-ADR-0024 |
| SPEC-0004 | IDEA-H-008 | Adversary Agent — Red-Team Spec Review | G0_complete (queued) | HAR-ADR-0025 |
| SPEC-0005 | IDEA-H-001 | G0.5 Pre-Spec Landscape Gate | G0_complete (blocked on SPEC-0001) | HAR-ADR-0026 |
| SPEC-0006 | IDEA-H-002 | G0.8 Architect Gate | G0_complete (blocked on SPEC-0001) | HAR-ADR-0027 |
| SPEC-0007 | IDEA-H-004 | Fast-Lane Risk Classification | G0_complete (blocked on SPEC-0001) | HAR-ADR-0028 |
| SPEC-0008 | IDEA-H-006 | Multimodal Input in Discovery-Grill | Implemented | — |
