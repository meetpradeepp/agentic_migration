﻿# Ideas Archive

> Completed or rejected ideas. Auto-populated from ideas-backlog.md when items reach Done or Rejected.

| ID | Title | Category | Resolution | Archived |
|----|-------|----------|------------|----------|

_Empty._
