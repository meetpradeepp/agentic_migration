﻿# Ideas Backlog

> Captured improvement ideas for SW_Harness itself.
> All items go through the harness's own pipeline before implementation.
> Status flow: Captured â†’ Under Review â†’ Spec Written â†’ In Pipeline â†’ Done | Rejected

---

| ID | Title | Category | Status | Captured |
|----|-------|----------|--------|----------|
| IDEA-H-001 | G0.5 Pre-Spec Landscape Gate | harness | Done | 2025-07-01 | SPEC-0005 |
| IDEA-H-002 | G0.8 Architect Gate | harness | Done | 2025-07-01 | SPEC-0006 |
| IDEA-H-003 | Agent Hooks via hooks.yaml | harness | Done | 2025-07-01 | SPEC-0001 |
| IDEA-H-004 | Fast-Lane Risk Classification | harness | Done | 2025-07-01 | SPEC-0007 |
| IDEA-H-005 | Per-Gate Token Budget Tracking | harness | Done | 2025-07-01 | SPEC-0002 |
| IDEA-H-006 | Multimodal Input in Discovery-Grill | harness | Done | 2025-07-01 | SPEC-0008 |
| IDEA-H-007 | EARS Notation for Acceptance Criteria | harness | Done | 2025-07-01 | SPEC-0003 |
| IDEA-H-008 | Adversary Agent â€” Red-Team Spec Review | harness | Done | 2026-06-08 | SPEC-0004 |

---

## IDEA-H-001 â€” G0.5 Pre-Spec Landscape Gate

**Category:** harness  
**Status:** Done
**Captured:** 2025-07-01  
**Closed by:** SPEC-0005  
**Source:** Amazon Kiro learning â€” spec-prereader agent concept  

**Summary:**
Add an optional gate G0.5 between G0 (Triage) and G1 (Spec Write) where a
`@spec-prereader` agent scans the existing codebase for related prior work before
the spec-writer begins. This prevents spec authors from reinventing patterns or
ignoring existing conventions.

**Behaviour (proposed):**
- `@spec-prereader` receives the triage output and scans `specs/`, `constitution/adrs/`,
  and existing source modules for related terms.
- Produces a one-page "Landscape Summary" deposited in `workspace/<task>/prereader.md`.
- `@spec-writer` loads `prereader.md` as context before drafting the spec.

**Gate placement:** Between G0 and G1, optional (controlled by `hooks.yaml`).  
**Dependency:** IDEA-H-003 (hooks.yaml infrastructure) enables opt-in/opt-out.

---

## IDEA-H-002 â€” G0.8 Architect Gate

**Category:** harness  
**Status:** Done
**Captured:** 2025-07-01  
**Closed by:** SPEC-0006  
**Source:** Amazon Kiro learning â€” upfront architecture clarification interview  

**Summary:**
Add gate G0.8 between G0 and G1 where an `@architect` agent conducts a
plain-language interview across five dimensions before any spec is written:
requirements, data model, API surface, non-functional requirements, and open risks.

**Behaviour (proposed):**
- `@architect` asks structured clarifying questions across 5 dimensions.
- Produces a `workspace/<task>/arch-brief.md` that the spec-writer loads at G1.
- Reduces spec rework caused by discovering architectural ambiguity mid-implementation.

**Gate placement:** Between G0 and G1, or between G0.5 and G1 if IDEA-H-001 is
also implemented.  
**Dependency:** IDEA-H-003 (hooks.yaml) for opt-in gate control.

---

## IDEA-H-003 â€” Agent Hooks via hooks.yaml

**Category:** harness  
**Status:** Done
**Captured:** 2025-07-01  
**Closed by:** SPEC-0001  
**Source:** Amazon Kiro learning â€” hooks.yaml extensibility mechanism  

**Summary:**
Introduce a `.github/hooks/hooks.yaml` configuration file that lets a project
declare which optional gates and agent behaviours are active, without modifying
agent instruction files.

**Behaviour (proposed):**
```yaml
hooks:
  G0.5_prereader: enabled        # IDEA-H-001
  G0.8_architect: enabled        # IDEA-H-002
  fast_lane_for_risk_low: ask    # IDEA-H-004  (ask = confirm before applying)
  token_budget_tracking: enabled # IDEA-H-005
```
- `enabled` â€” gate runs automatically.
- `ask` â€” gate pauses for user confirmation before applying the fast-lane path.
- `disabled` â€” gate is skipped.

**Benefit:** Project teams can tune the harness's gate overhead to their context
without forking agent files.

---

## IDEA-H-004 â€” Fast-Lane Risk Classification

**Category:** harness  
**Status:** Done
**Captured:** 2025-07-01  
**Closed by:** SPEC-0007  
**Source:** Amazon Kiro learning â€” autopilot / reduced-friction lane for low-risk work  

**Summary:**
Add a `risk` field (`low | high`) to each subtask in `plan.json`. For `risk: low`
subtasks, the orchestrator may offer a condensed review path (fewer mandatory
approval stops), subject to `hooks.yaml` confirmation policy.

**Behaviour (proposed):**
- `@planner` classifies each subtask as `risk: low` or `risk: high` based on
  surface area (new public API, DB schema change, security-sensitive path â†’ high).
- Orchestrator checks `hooks.yaml â†’ fast_lane_for_risk_low`.
- If `ask`: orchestrator presents a summary and waits for user confirmation before
  applying the fast-lane path.
- TDD order is never bypassed â€” fast-lane means fewer approval pauses, not fewer tests.

---

## IDEA-H-005 â€” Per-Gate Token Budget Tracking

**Category:** harness  
**Status:** Done
**Captured:** 2025-07-01  
**Closed by:** SPEC-0002  
**Source:** Amazon Kiro learning â€” token transparency / cost visibility  

**Summary:**
Extend `pipeline_metrics.py` with a `--tokens` flag that reads token usage logs
from `workspace/<task>/gate-log.json` (proposed format) and reports per-gate
token consumption alongside cycle time.

**Behaviour (proposed):**
- Each agent appends a `{"gate": "G1", "tokens_in": N, "tokens_out": M}` entry
  to `workspace/<task>/gate-log.json` at the end of each gate.
- `pipeline_metrics.py --tokens` aggregates and reports:
  - Total tokens per task
  - Breakdown by gate
  - Top-N most expensive tasks
- No external dependencies â€” reads from existing workspace folder structure.

**Benefit:** Makes token cost visible at the project level, enabling teams to
identify expensive spec types and tune gate depth accordingly.

---

## IDEA-H-006 â€” Multimodal Input in Discovery-Grill

**Category:** harness  
**Status:** Done
**Captured:** 2025-07-01  
**Closed by:** SPEC-0008  
**Source:** Amazon Kiro learning â€” multimodal context (images, diagrams)  

**Summary:**
Allow the `@discovery-grill` agent to accept images (architecture diagrams,
whiteboard photos, UI mockups) as additional context input alongside text
descriptions. The agent extracts entity and constraint signals from the image
and folds them into the discovery output.

**Behaviour (proposed):**
- User attaches an image in the discovery prompt.
- `@discovery-grill` describes visible entities (boxes, arrows, labels) and infers
  architectural constraints from the diagram.
- Discovered entities are appended to the grill output under a `## Visual Signals`
  section, clearly labelled as image-derived (not verified against code).

**Constraint:** Visual signals are advisory only â€” they feed into the spec interview
but do not bypass grill questions or spec review.

---

## IDEA-H-007 â€” EARS Notation for Acceptance Criteria

**Category:** harness  
**Status:** Done
**Captured:** 2025-07-01  
**Closed by:** SPEC-0003  
**Source:** Amazon Kiro learning â€” EARS (Easy Approach to Requirements Syntax)  

**Summary:**
Introduce EARS-formatted acceptance criteria as an optional authoring pattern in
specs. EARS provides five structured templates that reduce ambiguity in AC wording:

| Template | Keyword | Pattern |
|----------|---------|---------|
| Ubiquitous | (none) | The `{system}` shall `{action}`. |
| Event-driven | WHEN | WHEN `{trigger}`, the `{system}` shall `{action}`. |
| State-driven | WHILE | WHILE `{state}`, the `{system}` shall `{action}`. |
| Conditional | IF/THEN | IF `{condition}`, THEN the `{system}` shall `{action}`. |
| Optional | WHERE | WHERE `{feature}` is available, the `{system}` shall `{action}`. |

**Behaviour (proposed):**
- `@spec-writer` is updated to suggest EARS-formatted ACs when a spec is
  event-driven or state-sensitive.
- `check_spec_frontmatter.py` gains an optional `--ears-lint` flag that warns
  (not errors) when an AC lacks a structured keyword.
- EARS adoption is gradual â€” existing specs are not retroactively reformatted.

**Benefit:** Structured ACs reduce the surface area for misinterpretation between
spec-writer, coder, and tester.

---

## IDEA-H-008 â€” Adversary Agent â€” Red-Team Spec Review

**Category:** harness  
**Status:** Done
**Captured:** 2026-06-08  
**Closed by:** SPEC-0004
**Source:** Observed in originating project ï¿½ dversary agent produced structured FAIL reports at G2 with security, schema, and logic-gap findings. No .agent.md definition was committed.  

**Summary:**
Define and register an @adversary agent that runs at G2 alongside @spec-reviewer.
The adversary agent reads a spec and produces a structured dversary-<mode>.md report
identifying security flaws, logical contradictions, missing definitions, and untestable
acceptance criteria ï¿½ the findings a hostile implementer or attacker would exploit.

**Observed modes (from originating project outputs):**
- --spec mode: reviews spec text for logic gaps, auth bypasses, schema mismatches,
  and behavior rules that contradict each other.
- Additional modes (e.g. --code) may be added later.

**Finding severity scheme (observed):**
| Severity | Meaning |
|----------|---------|
| FAIL | Spec cannot pass G2 ï¿½ blocks approval |
| WARN | Spec should address before implementation ï¿½ advisory |
| NOTE | Minor inconsistency, cosmetic, or informational |

**Behaviour (proposed):**
- @adversary loads the spec, ADR SYNOPSIS, and relevant contract digests.
- Produces workspace/<task>/reviews/adversary-spec.md with a findings table.
- Any FAIL finding blocks G2 approval ï¿½ same veto power as @spec-reviewer.
- Orchestrator invokes @adversary in parallel with @spec-reviewer at G2.
- FAIL findings must be resolved before G2 â†’ G3 transition.

**Benefit:** The adversary agent found 3 FAIL-severity issues (auth bypass, missing DDL
column, undefined reset-offset behavior) in the originating project that spec-reviewer
and validator did not catch. It closes the gap between spec completeness and adversarial
correctness.

**Note on definition file:** The .agent.md for the adversary agent was never committed
to the originating project's agents folder ï¿½ it was invoked ad-hoc. This IDEA captures
the formal definition work as a harness improvement.
