﻿# Agent Contract Cluster Manifest
#
# HAR-ADR-0009: Agent-Role Contract Cluster Loading
# Single source of truth for which contract digest files each agent loads.
#
# Each agent loads ONLY the listed files from `.github/memory/contract-digests/`.
# Validator and spec-reviewer are exempt — they load full contract text from
# `constitution/contracts/` as the pipeline's safety net.
#
# When a new contract is added to the constitution, update the relevant cluster(s)
# here AND run `scripts/generate_micro_index.py` to produce the new digest file.
# This file must be updated in the same commit as the new contract ADR.

---

## Cluster: authoring
**Agents:** spec-writer, spec-patcher, adr-writer

Load these digest files (in order):
```
.github/memory/contract-digests/contract-01-digest.md   # Coding Standards
.github/memory/contract-digests/contract-02-digest.md   # SDLC Contract
.github/memory/contract-digests/contract-03-digest.md   # Testing Contract
.github/memory/contract-digests/contract-04-digest.md   # FACT Contract
.github/memory/contract-digests/contract-05-digest.md   # Confidence Contract
.github/memory/contract-digests/contract-06-digest.md   # Grounding Contract
.github/memory/contract-digests/contract-07-digest.md   # Staleness Contract
.github/memory/contract-digests/contract-08-digest.md   # Language Pack Contract
.github/memory/contract-digests/contract-09-digest.md   # Event Pipeline Contract
.github/memory/contract-digests/contract-10-digest.md   # Anti-Patterns
.github/memory/contract-digests/contract-11-digest.md   # MCP Contract
.github/memory/contract-digests/contract-15-digest.md   # DB Schema Contract
.github/memory/contract-digests/contract-17-digest.md   # Phase Roadmap Contract
```

**Why these:** Spec-writer and adr-writer must verify FACT/confidence/grounding/staleness
(04–07), language pack conformance (08), MCP tool design (11), DB schema references (15),
and phase scope (17). Contracts 12–14, 16, 18–21 are domain implementation details not
needed at the authoring stage.

**Escalation:** Load the full contract text (from `constitution/contracts/`) only when
exact clause wording is required — cite the section in the spec or ADR.

---

## Cluster: implementation
**Agents:** coder, tester, refactor

Load these digest files (in order):
```
.github/memory/contract-digests/contract-01-digest.md   # Coding Standards
.github/memory/contract-digests/contract-02-digest.md   # SDLC Contract
.github/memory/contract-digests/contract-03-digest.md   # Testing Contract
.github/memory/contract-digests/contract-09-digest.md   # Event Pipeline Contract
.github/memory/contract-digests/contract-10-digest.md   # Anti-Patterns
.github/memory/contract-digests/contract-15-digest.md   # DB Schema Contract
.github/memory/contract-digests/contract-18-digest.md   # Implementation Guidelines
```

**Why these:** Code and tests are governed by coding standards (01), TDD discipline (02),
test pyramid and coverage rules (03), Kafka governance (09), banned anti-patterns (10),
DB table naming (15), and implementation patterns / DI wiring (18). FACT/confidence/
grounding etc. are spec-level concerns enforced by spec-writer and validator — coders
implement the FACT builder utility, not the rules governing when to use it.

**Escalation:** Load `constitution/harness/contracts/HAR-C-0008-implementation-guidelines.md` full text
once at G4 start (session-persistent per shared-rules §18 / §14.8). All other escalations
require explicit cite.

---

## Cluster: planning
**Agents:** planner

Load these digest files (in order):
```
.github/memory/contract-digests/contract-01-digest.md   # Coding Standards
.github/memory/contract-digests/contract-02-digest.md   # SDLC Contract
.github/memory/contract-digests/contract-03-digest.md   # Testing Contract
.github/memory/contract-digests/contract-09-digest.md   # Event Pipeline Contract
.github/memory/contract-digests/contract-10-digest.md   # Anti-Patterns
.github/memory/contract-digests/contract-17-digest.md   # Phase Roadmap Contract
```

**Why these:** Planner breaks specs into subtasks respecting TDD order (02), test
structure (03), Kafka worker boundaries (09), anti-pattern avoidance (10), and phase
scope (17). Implementation detail contracts are not needed at planning time.

---

## Cluster: review
**Agents:** code-reviewer

Load these digest files (in order):
```
.github/memory/contract-digests/contract-01-digest.md   # Coding Standards
.github/memory/contract-digests/contract-02-digest.md   # SDLC Contract
.github/memory/contract-digests/contract-03-digest.md   # Testing Contract
.github/memory/contract-digests/contract-09-digest.md   # Event Pipeline Contract
.github/memory/contract-digests/contract-10-digest.md   # Anti-Patterns
.github/memory/contract-digests/contract-15-digest.md   # DB Schema Contract
.github/memory/contract-digests/contract-18-digest.md   # Implementation Guidelines
```

**Why these:** Code review covers the same surface as implementation (same 7 digests).
The reviewer checks code against what the coder should have applied. No domain-specific
contracts needed unless the spec explicitly involves Phase 2+ features.

---

## Cluster: release
**Agents:** release-manager

Load these digest files (in order):
```
.github/memory/contract-digests/contract-01-digest.md   # Coding Standards
.github/memory/contract-digests/contract-02-digest.md   # SDLC Contract (release gates §8)
.github/memory/contract-digests/contract-09-digest.md   # Event Pipeline Contract
.github/memory/contract-digests/contract-10-digest.md   # Anti-Patterns
.github/memory/contract-digests/contract-17-digest.md   # Phase Roadmap Contract (exit criteria)
```

**Why these:** Release gate checks (HAR-C-0002 §8) and phase exit criteria (HAR-C-0007)
are the primary concerns. No implementation or domain-specific contracts needed.

---

## Cluster: governance
**Agents:** validator, spec-reviewer

These agents are **exempt from cluster loading**. They load the full text of all 21
contracts from `constitution/contracts/` — they are the pipeline safety net and must
have access to exact clause wording for every compliance check.

---

## Cluster: orchestration
**Agents:** orchestrator, discovery

These agents use `.github/memory/constitution-digest.md` (mega-digest) for broad
orientation. They operate across all domains and phases, making role-scoped loading
impractical. This is intentional and consistent with their gate-management role.

---

## Update Protocol (HAR-ADR-0009 §Decision)

When a new contract is added to the constitution:
1. Add the new contract digest file to every cluster where the new contract applies.
2. Run `scripts/generate_micro_index.py` to produce the new `contract-NN-digest.md` file.
3. Update `.github/memory/constitution-digest.md` to include the new contract summary.
4. Update this manifest in the same commit as the new contract ADR.
5. Run the validator to confirm no agent cluster is missing a required contract.
