﻿# {project_name} — Copilot Instructions

## Project Identity

{project_name} is a deterministic code intelligence engine. **No LLM at any runtime layer.**
Event-driven pipeline; Kafka (KRaft) as exclusive broker; all workers are Kafka consumer
processes. FACT (Fast / Accurate / Complete / Trustworthy) is the north star.

## The Constitution

The `constitution/` folder is the **single source of truth** for every design,
implementation, and operational decision. Read it before writing any code.

```
constitution/
  system/contracts/  ← SYS-C-0001…SYS-C-0013 (system rules, enforced by CI + review)
  harness/contracts/ ← HAR-C-0001…HAR-C-0008 (harness rules, enforced by CI + review)
  schemas/           ← machine-readable data contracts
  system/adrs/       ← SYS-ADR-0001…SYS-ADR-0049 (immutable system decisions)
  harness/adrs/      ← HAR-ADR-0001…HAR-ADR-0011 (immutable harness decisions)
```

**HARD RULE: No code without a spec. No spec without constitution conformance.**

## SDLC Pipeline (HAR-C-0002)

Every change — feature, bug fix, enhancement — follows this lifecycle:

```
Spec → Tests (Red) → Implementation (Green) → Review → Release
```

**Phase discipline (HAR-C-0007):** All work is scoped to a phase. The current phase is
determined by which exit criteria have been met. The orchestrator enforces phase boundaries.

| Phase | Focus | Version tag |
|-------|-------|-------------|
| 1 | Foundation: Kafka + Parse + Structured DB + MCP tools | `v0.1.0` |
| 2 | Embedding + Vector Layers + Chunking | `v0.2.0` |
| 3 | Topology Graph + Impact Analysis + GraphQL | `v0.3.0` |
| 4 | Cross-Repo Linking + Grounding + Feedback + Admin Portal | `v0.4.0` |
| 5 | Ontology + DSL + CodeGraph Explorer | `v0.5.0` |
| 6 | Enterprise Scale-Out + Production | `v1.0.0` |

## Agent Memory & Token Optimization (HAR-ADR-0002)

Agents load compact digests instead of full contracts to save context budget:

```
.github/memory/
  constitution-digest.md    ← compact digest of all 22 contracts
  shared-rules.md           ← common rules extracted from agents (TDD, anti-patterns, etc.)
  event-catalogue.md        ← event type quick reference from SYS-C-0006
  phase-status.md           ← living doc: current phase, active specs, milestones
```

**Validator and spec-reviewer still load full contracts** — they are the safety net.

## Pipeline Workspace (HAR-ADR-0007)

Each task gets a spec-scoped workspace directory. Workspaces persist after G6 as a
permanent audit trail and are never overwritten by a subsequent task.

```
.github/pipeline/
  state.json                ← active_tasks array; each task has workspace_path
  plans/                    ← implementation plans (SPEC-NNNN-plan.json)
  workspace/
    SPEC-0002/              ← task-8 workspace (spec-scoped, permanent)
      spec.md
      plan.json
      adrs/
      reviews/
      subtasks/
    SPEC-0014-0015/         ← multi-spec task uses hyphen-joined IDs
    HAR-ADR-0008/               ← CONSTITUTION_CHANGE task that produced HAR-ADR-0008
    task-N/                 ← CONSTITUTION_CHANGE with neither spec nor ADR (rare fallback)
```

Orchestrator creates `workspace/<spec_id>/` at G0, records `workspace_path` in
`state.json`, populates spec + ADRs at G1. Agents resolve the active workspace by
reading `state.json → active task → workspace_path`.

The `.github/agents/orchestrator.agent.md` manages the 7-gate pipeline:

| Gate | Purpose | Agent |
|------|---------|-------|
| G0 | Triage & classify | orchestrator |
| G1 | Write spec/ADR | @spec-writer, @adr-writer, @spec-patcher |
| G1→G2 | Validate spec compliance | @validator |
| G2 | Review spec | @spec-reviewer |
| G2→G3 | Validate review completeness | @validator |
| G3 | Plan subtasks | @planner |
| G3→G4 | Validate plan compliance | @validator |
| G4 | TDD implementation | @coder, @tester, @refactor |
| G4→G5 | Validate code compliance | @validator |
| G5 | Code review + test audit | @code-reviewer, @tester, @validator |
| G6 | Release | @release-manager, @validator |

## Agent Directory

| Agent | File | Role |
|-------|------|------|
| orchestrator | `.github/agents/orchestrator.agent.md` | Gate state machine, constitution enforcer |
| spec-writer | `.github/agents/spec-writer.agent.md` | Writes new specs (HAR-C-0002 §2 format) |
| spec-patcher | `.github/agents/spec-patcher.agent.md` | Amends existing specs for fixes/enhancements |
| spec-reviewer | `.github/agents/spec-reviewer.agent.md` | 15-point constitution conformance review |
| adr-writer | `.github/agents/adr-writer.agent.md` | Writes ADRs using constitution template |
| planner | `.github/agents/planner.agent.md` | Breaks specs into TDD subtasks |
| coder | `.github/agents/coder.agent.md` | TDD implementation, one subtask at a time |
| tester | `.github/agents/tester.agent.md` | Test quality, TDD order, coverage, eval suites |
| refactor | `.github/agents/refactor.agent.md` | Safe structural improvements under green tests |
| validator | `.github/agents/validator.agent.md` | Constitution compliance scanner at every gate |
| code-reviewer | `.github/agents/code-reviewer.agent.md` | 9-point review (HAR-C-0002 §6) |
| release-manager | `.github/agents/release-manager.agent.md` | Release gates, CHANGES.md, version tags |

## Non-Negotiable Rules

1. **Spec before code.** Every change has a spec at `specs/phase-N/SPEC-NNNN-<name>.md`.
2. **Tests before implementation.** `test(...)` commit precedes `feat(...)` commit.
3. **Constitution is law.** Contract violations block merge. No exceptions.
4. **No LLM in runtime.** {project_name} is deterministic. AI assists development, not execution.
5. **No direct worker calls.** Workers communicate via Kafka events only (SYS-ADR-0027).
6. **Anti-patterns are banned.** HAR-C-0004 items are rejected on sight.
7. **Schema changes need ADRs.** No schema change without a corresponding ADR.
8. **No scope creep.** If work grows beyond spec, create a new spec.
9. **Phase discipline.** Work must target the current phase (HAR-C-0007). Future-phase work is deferred until entry criteria are met.
10. **No phase-skipping.** Phase N+1 cannot begin until Phase N exit criteria pass.

## Work Types

| Type | Spec action | Example |
|------|------------|---------|
| NEW_FEATURE | New spec created | "Add Kafka WorkerBase class" |
| SPEC_REWRITE | Old spec superseded, new spec created | "Rewrite SPEC-0003 for Kafka" |
| BUG_FIX | Existing spec amended (Deviations section) | "Fix offset commit timing" |
| ENHANCEMENT | Existing spec extended | "Add DLQ routing to WorkerBase" |
| CONSTITUTION_CHANGE | ADR first, then contract/schema update | "Add new event type" |

## File Conventions

```
specs/phase-N/SPEC-NNNN-<name>.md     ← spec documents
constitution/adrs/ADR-NNNN-<name>.md   ← architecture decisions
constitution/contracts/NN-<name>.md    ← living contracts
constitution/schemas/<name>            ← data schemas
{src_dir}/<module>/<name>.py            ← source code
tests/unit/test_<module>.py            ← unit tests
tests/integration/test_<flow>.py       ← integration tests
.github/agents/<name>.agent.md         ← agent definitions
.github/pipeline/state.json            ← current pipeline state
.github/pipeline/plans/                ← implementation plans
CHANGES.md                             ← change registry
```

## Project Skills

Domain-specific skills are in `.github/skills/`. Load a skill's `SKILL.md` when the
task falls within its domain — it provides structured decision logic that supplements
agent instructions.

| Skill | Path | When to load |
|-------|------|-------------|
| triage-decision | `.github/skills/triage-decision/SKILL.md` | @orchestrator at G0 — PATCH vs FULL classification |
| next-number | `.github/skills/next-number/SKILL.md` | @orchestrator, @spec-writer, @adr-writer — claim next SPEC/ADR/Contract number before creating any file |

## Mechanical Verification Scripts

Three scripts provide **independent, executable evidence** replacing AI-only attestation.
Run them and include literal output in compliance reports — do not paraphrase results.

| Script | Purpose | Gate |
|--------|---------|------|
| `constitution/harness/scripts/check_spec_test_coverage.py --spec <file>` | AC and T-ID → test stub coverage (VM.1/VM.2) | After G4, G5 |
| `constitution/harness/scripts/check_phase_gate.py --phase <N>` | All phase-N specs Implemented before phase exit (VM.3) | G6 |
| `constitution/harness/scripts/pipeline_metrics.py` | Cycle time, gate averages, completion % (VM.4) | G6, on-demand |

## How to Start Working

1. Tell the orchestrator what you want to build or fix
2. It classifies the work and declares the mode (FULL / PATCH) using the triage-decision skill
3. You approve the classification
4. The pipeline proceeds gate by gate, with your approval at each stop
5. No gate is skippable. No approval is assumed.
