﻿# Implements: SPEC-0022
# Spec: {specs_dir}/SPEC-0022-harness-pipeline-reliability.md
# Subtask: SPEC-0022-T02
"""
pipeline_db — SQLite-backed pipeline state for {project_name} harness.

Replaces direct state.json read/write with a WAL-mode SQLite database.
A6 anti-pattern exception granted by HAR-ADR-0012: this module is harness
infrastructure under .github/pipeline/, never imported by {src_dir}/.

Public API:
    get_active_tasks() -> list[dict]
    add_task(task_id, workspace_path, description, current_gate, work_type, created_at)
    update_gate(task_id, new_gate)
    close_task(task_id, closed_at)
    migrate(state_json_path, db_path)  -- also callable via --migrate CLI

Private:
    _ensure_schema(conn)
    _regenerate_state_json(conn)
"""

from __future__ import annotations

import contextlib
import json
import sqlite3
import sys
from pathlib import Path

# ---------------------------------------------------------------------------
# Module-level path constants — mutable so tests can monkeypatch them.
# ---------------------------------------------------------------------------

_DB_PATH: Path = Path(__file__).resolve().parent / "state.db"
_STATE_JSON_PATH: Path = Path(__file__).resolve().parent / "state.json"


# ---------------------------------------------------------------------------
# Private helpers
# ---------------------------------------------------------------------------


def _ensure_schema(conn: sqlite3.Connection) -> None:
    """Create tables and set WAL mode if they do not yet exist."""
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS active_tasks (
            task_id        TEXT PRIMARY KEY,
            workspace_path TEXT NOT NULL,
            description    TEXT NOT NULL,
            current_gate   TEXT NOT NULL,
            work_type      TEXT NOT NULL,
            created_at     TEXT NOT NULL
        )
        """
    )
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS closed_task_index (
            task_id        TEXT PRIMARY KEY,
            workspace_path TEXT NOT NULL,
            description    TEXT NOT NULL,
            current_gate   TEXT NOT NULL,
            work_type      TEXT NOT NULL,
            closed_at      TEXT NOT NULL
        )
        """
    )


def _regenerate_state_json(conn: sqlite3.Connection) -> None:
    """Write state.json atomically from the current DB state (HAR-ADR-0008 slim-index format).

    Reads both tables from *conn* (inside the caller's transaction so uncommitted
    writes are visible) and writes to _STATE_JSON_PATH via a tmp-then-rename swap.
    """
    active_rows = conn.execute("SELECT * FROM active_tasks").fetchall()
    closed_rows = conn.execute("SELECT * FROM closed_task_index").fetchall()

    active_tasks = [
        {
            "task_id": row[0],
            "workspace_path": row[1],
            "description": row[2],
            "current_gate": row[3],
            "work_type": row[4],
            "created_at": row[5],
        }
        for row in active_rows
    ]
    closed_index = [
        {
            "task_id": row[0],
            "workspace_path": row[1],
            "description": row[2],
            "current_gate": row[3],
            "work_type": row[4],
            "closed_at": row[5],
        }
        for row in closed_rows
    ]

    state_data = {
        "_schema": "HAR-ADR-0008-state-v2",
        "_GENERATED": True,
        "_source": "state.db",
        "active_tasks": active_tasks,
        "closed_task_index": closed_index,
    }

    state_json_tmp = _STATE_JSON_PATH.with_suffix(".tmp")
    state_json_tmp.write_text(json.dumps(state_data, indent=2), encoding="utf-8")
    state_json_tmp.replace(_STATE_JSON_PATH)


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def get_active_tasks() -> list[dict]:
    """Return all rows from active_tasks as a list of dicts (AC-01)."""
    conn = sqlite3.connect(str(_DB_PATH))
    conn.row_factory = sqlite3.Row
    try:
        _ensure_schema(conn)
        cursor = conn.execute("SELECT * FROM active_tasks")
        return [dict(row) for row in cursor.fetchall()]
    finally:
        conn.close()


def add_task(  # noqa: PLR0913
    task_id: str,
    workspace_path: str,
    description: str,
    current_gate: str,
    work_type: str,
    created_at: str,
) -> None:
    """Insert a new task into active_tasks and regenerate state.json (AC-02).

    Raises:
        ValueError: if task_id already exists in active_tasks.
    """
    conn = sqlite3.connect(str(_DB_PATH))
    try:
        _ensure_schema(conn)
        conn.execute("BEGIN EXCLUSIVE")
        existing_row = conn.execute(
            "SELECT task_id FROM active_tasks WHERE task_id = ?", (task_id,)
        ).fetchone()
        if existing_row:
            raise ValueError(f"task_id already exists: {task_id}")
        conn.execute(
            "INSERT INTO active_tasks VALUES (?, ?, ?, ?, ?, ?)",
            (task_id, workspace_path, description, current_gate, work_type, created_at),
        )
        _regenerate_state_json(conn)
        conn.commit()
    except Exception:
        with contextlib.suppress(Exception):
            conn.rollback()
        raise
    finally:
        conn.close()


def update_gate(task_id: str, new_gate: str) -> None:
    """Update current_gate for an active task and regenerate state.json (AC-03).

    Raises:
        ValueError: if task_id is not present in active_tasks.
    """
    conn = sqlite3.connect(str(_DB_PATH))
    try:
        _ensure_schema(conn)
        conn.execute("BEGIN EXCLUSIVE")
        update_result = conn.execute(
            "UPDATE active_tasks SET current_gate = ? WHERE task_id = ?",
            (new_gate, task_id),
        )
        if update_result.rowcount == 0:
            raise ValueError(f"task_id not found in active_tasks: {task_id}")
        _regenerate_state_json(conn)
        conn.commit()
    except Exception:
        with contextlib.suppress(Exception):
            conn.rollback()
        raise
    finally:
        conn.close()


def close_task(task_id: str, closed_at: str) -> None:
    """Move a task from active_tasks to closed_task_index (AC-04).

    Raises:
        ValueError: if task_id is not present in active_tasks.
    """
    conn = sqlite3.connect(str(_DB_PATH))
    try:
        _ensure_schema(conn)
        conn.execute("BEGIN EXCLUSIVE")
        active_row = conn.execute(
            "SELECT * FROM active_tasks WHERE task_id = ?", (task_id,)
        ).fetchone()
        if active_row is None:
            raise ValueError(f"task_id not found in active_tasks: {task_id}")
        conn.execute(
            "INSERT INTO closed_task_index VALUES (?, ?, ?, ?, ?, ?)",
            (active_row[0], active_row[1], active_row[2], active_row[3], active_row[4], closed_at),
        )
        conn.execute("DELETE FROM active_tasks WHERE task_id = ?", (task_id,))
        _regenerate_state_json(conn)
        conn.commit()
    except Exception:
        with contextlib.suppress(Exception):
            conn.rollback()
        raise
    finally:
        conn.close()


def migrate(
    state_json_path: Path | str | None = None,
    db_path: Path | str | None = None,
) -> None:
    """Seed state.db from an existing state.json slim-index file (AC-06).

    Uses INSERT OR IGNORE so repeated calls are idempotent.

    Args:
        state_json_path: Path to state.json.  Defaults to _STATE_JSON_PATH.
        db_path: Path to state.db.  Defaults to _DB_PATH.

    Raises:
        FileNotFoundError: if the resolved state.json path does not exist.
    """
    resolved_json = Path(state_json_path) if state_json_path is not None else _STATE_JSON_PATH
    resolved_db = Path(db_path) if db_path is not None else _DB_PATH

    if not resolved_json.exists():
        raise FileNotFoundError(f"state.json not found: {resolved_json}")

    state_content = json.loads(resolved_json.read_text(encoding="utf-8"))

    conn = sqlite3.connect(str(resolved_db))
    try:
        _ensure_schema(conn)
        conn.execute("BEGIN EXCLUSIVE")
        for task in state_content.get("active_tasks", []):
            conn.execute(
                "INSERT OR IGNORE INTO active_tasks VALUES (?, ?, ?, ?, ?, ?)",
                (
                    task["task_id"],
                    task["workspace_path"],
                    task["description"],
                    task["current_gate"],
                    task["work_type"],
                    task["created_at"],
                ),
            )
        conn.commit()
    except Exception:
        with contextlib.suppress(Exception):
            conn.rollback()
        raise
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# CLI entry point
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="Pipeline state migration utility.")
    parser.add_argument("--migrate", action="store_true", help="Seed state.db from state.json")
    args = parser.parse_args()

    if args.migrate:
        try:
            migrate()
        except FileNotFoundError as exc:
            sys.stderr.write(f"ERROR: {exc}\n")
            sys.exit(2)
