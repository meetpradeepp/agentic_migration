# Pipeline Workspace

Each active or completed task gets a dedicated subfolder here, named by spec ID.

## Naming Convention

```
workspace/
  SPEC-0001/          ← single-spec task
  SPEC-0014-0015/     ← multi-spec task (hyphen-joined IDs)
  HAR-ADR-0008/       ← CONSTITUTION_CHANGE task
  task-N/             ← fallback (rare, no spec or ADR)
  current -> SPEC-NNNN/   ← symlink to active task (gitignored)
```

## Contents Per Task Folder

```
SPEC-NNNN/
  spec.md             ← copy of the spec at G1
  plan.json           ← implementation plan at G3
  task-state.json     ← gate transitions, timestamps (HAR-ADR-0008)
  adrs/               ← ADR files created/referenced by this task
    SYNOPSIS.md       ← one-liner per ADR decision (loaded by coder)
  reviews/            ← spec review (G2) and code review (G5) outputs
  subtasks/           ← per-subtask outputs (coder/tester/refactor)
```

## Retention Policy

- Named workspaces (`SPEC-NNNN/`) are **committed** — permanent audit trail.
- `current/` (symlink or folder) is **gitignored** — transient active pointer.
- Never overwrite an existing workspace folder with a new task.
