﻿# HAR-C-0007 — Phase Roadmap Contract

**Scope:** All specs, plans, and implementation work.
**Enforced by:** Orchestrator agent, spec-reviewer agent, release-manager agent.
**Status:** Active
**Related:** HAR-C-0002 (SDLC), SYS-C-0006 (Event Pipeline), SYS-ADR-0010 (Three-Tier Deployment), SYS-ADR-0013 (Kafka), SYS-ADR-0027 (Async Autonomy), HAR-ADR-0004 (Phase as Product Milestone)

---

## 0. Purpose

This contract defines the **phase boundaries** for {project_name} development. Every phase is
a **product milestone** — it delivers a demonstrable, user-facing capability end-to-end.
No phase ends without something a user can interact with. Phases are sequential — a later
phase MUST NOT begin implementation until the preceding phase's exit criteria are met
(HAR-ADR-0004).

**HARD RULES:**

1. **No spec without a phase assignment.** Every spec's `Phase:` header MUST reference
   a phase defined in this contract.
2. **No phase-N+1 implementation until phase-N exit criteria pass.** The release-manager
   agent verifies exit criteria before recommending a version tag.
3. **Phases are additive.** Later phases extend earlier phases — they never break or
   replace delivered functionality.
4. **Verification is mandatory.** Each phase defines verification commands that must
   pass before the phase is considered complete.
5. **Scope is locked per phase.** If work doesn't fit the current phase's scope, it
   belongs to a later phase. No exceptions.
6. **Every phase has a walking skeleton.** The G3 planner MUST order walking-skeleton
   specs before enhancement specs in the implementation plan. Walking-skeleton specs are
   implemented first; enhancement specs extend the working skeleton within the same phase.
7. **Version tag = working product increment.** The version tag certifies that the
   milestone capability works end-to-end AND all specs (skeleton + enhancements) are
   `Status: Implemented`. The version tag is NEVER applied to the skeleton alone.

### Milestone model (HAR-ADR-0004)

Every phase definition in this contract contains three delivery structures:

| Structure | Definition |
|-----------|------------|
| **Milestone capability** | One sentence — the user-facing, demonstrable outcome the phase produces. The version tag certifies this capability works. |
| **Walking skeleton** | Minimum ordered set of specs whose completion produces the milestone capability end-to-end. Implemented first, in dependency order. |
| **Enhancement specs** | Remaining specs that extend the skeleton. Must all be `Status: Implemented` before the version tag. May be implemented in any order after the skeleton works. |

---

## 1. Phase 1 — Foundation: Kafka Workers + Structured DB + Parse Pipeline

**Milestone capability:** A developer can upload a source repository, have it parsed automatically, and query its functions, files, and SQL tables via MCP tools — all within a running ECLE instance.

**Entry criteria:** Constitution complete (all contracts, ADRs, schemas finalised).

### Walking skeleton

Minimum specs to deliver the milestone capability end-to-end. Implemented in this order:

| Order | Spec | Unlocks |
|-------|------|---------|
| 1 | SPEC-0001 — Foundation Interfaces | `IStructuredDB`, `IArtifactStore`, factory functions; all workers depend on this |
| 2 | SPEC-0008 — Kafka WorkerBase + Topic Registry | Worker lifecycle, offset management, DLQ routing; parse_repo and persist_facts depend on this |
| 2.5 | SPEC-0013 — API Key Auth | `api_keys` table (Phase 1 schema); auth middleware on Admin API + MCP (SYS-ADR-0019); required before any authenticated production query |
| 3 | SPEC-0009 — Structured DB DDL | All DB tables; persist_facts depends on this |
| 4 | SPEC-0005 — parse_repo worker | Consumes `repo.detected` → extracts facts → emits `file.ir_produced` |
| 5 | SPEC-0006 — persist_facts worker | Consumes `file.ir_produced` → upserts structured DB → emits `file.stored` |
| 6 | SPEC-0007 — MCP Phase 1 Tools | `fact_find_files`, `fact_find_functions`, `fact_find_tables` with FACT envelope |

**Skeleton checkpoint:** After these six specs, a repo can be parsed and queried via authenticated MCP.

### Enhancement specs

Extend the skeleton within Phase 1. All must be `Status: Implemented` before `v0.1.0`:

| Spec | What it adds |
|------|--------------|
| SPEC-0004 — Upload API + scan_source | `POST /upload` HTTP entry point; `scan_source` worker; replaces CLI trigger |
| SPEC-0002 — Language Pack Registry | Multi-language support; hot-reload; manifest validation; DefaultPack fallback |
| SPEC-0010 — Semantic Interpreter Worker | Deterministic fact annotation (SYS-ADR-0032); `ecle.facts.annotated` event; Phase 2 topology prerequisite |
| SPEC-0011 — Deterministic Naming Enforcement | CI Stage 1 naming gate (`ECLE001`) for non-trivial scopes; deterministic lint findings for review readiness |
| SPEC-0014 — fact_find_table_owners MCP tool | Answers "which files/functions write to table X?"; backed by `function_table_ops` (Phase 1 data); no topology or vectors required (SYS-ADR-0038) |
| SPEC-0015 — fact_find_function_callers MCP tool | Answers "who calls function X?"; backed by `function_calls` (Phase 1 data); no topology or vectors required (SYS-ADR-0038) |
| SPEC-0016 — Pipeline Stage Hook Engine | Declarative entry/exit quality gates + processing hooks for all pipeline workers; `HookEngine` injected into `WorkerBase`; 3-plane control (Criteria / Action / Processing); base rules for parse_repo, persist_facts, semantic_interpreter, batch_embed (SYS-ADR-0046) |

### Workers operational in Phase 1
- `scan_source`
- `parse_repo`
- `persist_facts`
- `semantic_interpreter` (file mode + repo mode)

### Events operational in Phase 1
- `upload.received`
- `source.received`
- `repo.detected`
- `repo.structural_complete` (SYS-ADR-0030 / SPEC-0005 DEV-003 — two-phase CPG gate event)
- `file.ir_produced`
- `repo.ir_produced`
- `file.stored`
- `facts.annotated`
- `language_pack.reloaded`
- `language_pack.reload_failed`
- `language_pack.extension_miss`
- `hook.entry_rejected` (SYS-ADR-0046 / SPEC-0016 — entry hook rejection audit event)
- `hook.exit_failed` (SYS-ADR-0046 / SPEC-0016 — exit hook failure audit event)

### Exit criteria (version tag: `v0.1.0`)
- [ ] All Phase 1 specs `Status: Implemented`
- [ ] Milestone capability demonstrated end-to-end
- [ ] `eval_schema_conformance` passes (facts validate against `facts-base-schema.json` v2.1)
- [ ] `eval_event_chain_complete` passes (upload → scan → parse → persist → MCP query)
- [ ] `eval_idempotent_ingest` passes (same event processed twice = same DB state)
- [ ] `eval_srp_isolation` passes (no cross-worker imports)
- [ ] `eval_fallback_coverage` passes (DefaultPack fires for `.xyz` files)
- [ ] Post-import smoke test passes (HAR-C-0002 §9)
- [ ] Version tag: `v0.1.0`

### Verification commands
```bash
# Full event chain — from upload to query
POST /upload test_fixture.zip
ecle events --type repo.ir_produced --repo test_fixture
ecle stats --repo test_fixture           # files > 0, functions > 0
ecle mcp fact_find_files --repo test_fixture --query "*.py"   # results not empty
```

---

## 2. Phase 2 — Topology Graph + Impact Analysis + GraphQL

> **Reordered from Phase 3 by SYS-ADR-0038** (2026-05-14). Topology delivers higher value to T-Mobile
> support teams sooner; vector infrastructure is deferred to Phase 3.

**Milestone capability:** A developer can ask "what is the blast radius if I change this file?" and receive a multi-hop impact report showing every file, function, and service that would be affected — all grounded in the code topology graph.

**Entry criteria:** Phase 1 exit criteria met. `v0.1.0` tagged.

### Walking skeleton

| Order | Spec | Unlocks |
|-------|------|---------|
| 1 | ITopologyGraph impl (SPEC-TBD) | Neo4j backend for `ITopologyGraph` (SYS-ADR-0003); `build_graph` and `compute_topology` depend on this |
| 2 | build_graph worker (SPEC-TBD) | Consumes `file.ir_produced` → builds graph nodes + edges → emits `graph.updated` |
| 3 | compute_topology worker (SPEC-TBD) | Consumes `graph.updated` → Leiden community detection (SYS-ADR-0011) → emits `topology.updated` |
| 4 | fact_impact MCP tool (SPEC-TBD) | Multi-hop impact report from topology graph; the core Phase 2 milestone capability |

**Skeleton checkpoint:** After these four, `fact_impact` returns a grounded blast-radius report.

### Enhancement specs

| Spec | What it adds |
|------|--------------|
| fact_trace_path MCP tool (SPEC-TBD) | Call chain traversal (who calls what, how deep) |
| Coverage warnings (SPEC-TBD) | `indexing_state` completeness in FACT envelope |
| Incremental ingestion (SPEC-TBD) | `content_hash` skip rules (SYS-C-0009) |

### Workers operational (new in Phase 2)
- `build_graph`
- `compute_topology`

### Events operational (new in Phase 2)
- `graph.updated`
- `topology.updated`

### Exit criteria (version tag: `v0.2.0`)
- [ ] All Phase 2 specs `Status: Implemented`
- [ ] Milestone capability demonstrated end-to-end
- [ ] `fact_impact` returns multi-hop results for a test fixture repo
- [ ] Leiden assigns `cluster_stable_id` to all indexed files
- [ ] Incremental re-parse skips unchanged files (content_hash match)
- [ ] Version tag: `v0.2.0`

### Verification commands
```bash
ecle mcp fact_impact --file billing/charge_engine.py   # blast radius results, not empty
ecle stats --repo test_fixture --graph                 # node_count > 0, edge_count > 0
```

---

## 3. Phase 3 — Embedding + Vector Layers + Chunking

> **Reordered from Phase 2 by SYS-ADR-0038** (2026-05-14). Vector infrastructure complexity deferred;
> topology-first delivers higher-value capability for T-Mobile support teams in Phase 2.

**Milestone capability:** A developer can search a repository using natural language ("find all billing functions") and receive semantically relevant results ranked by vector similarity — no keyword matching required.

**Entry criteria:** Phase 2 exit criteria met. `v0.2.0` tagged.

> **SYS-ADR-0041 must be accepted before Phase 3 schema work begins.** The three cross-tier edge tables (`code_uses_column`, `field_maps_column`, `service_uses_field`) and two new event types (`lineage.column_linked`, `lineage.field_mapped`) required by Phase 3 topology queries are gated on SYS-ADR-0041 acceptance per SYS-C-0010 §1 Rule 6.

### Walking skeleton

| Order | Spec | Unlocks |
|-------|------|---------|
| 1 | Embedding model ADR (new) | Benchmark `all-MiniLM-L6-v2` vs alternatives; record model choice; required before any embed spec begins |
| 2 | IVectorStore Qdrant impl (SPEC-TBD) | Qdrant backend for `IVectorStore` (SYS-ADR-0052); Layer 1 + Layer 2 collections; `batch_embed` depends on this |
| 3 | chunk_file worker (SPEC-TBD) | Consumes `file.stored` → chunks facts → emits `file.chunked` |
| 4 | batch_embed worker (SPEC-TBD) | Consumes `file.chunked` → ONNX embed → upserts vectors → emits `file.embedded` |
| 5 | fact_search MCP tool (SPEC-TBD) | Semantic search via Layer 1/2 vectors; FACT envelope response |

**Skeleton checkpoint:** After these five, a user can run a natural-language search against an indexed repo.

### Enhancement specs

| Spec | What it adds |
|------|--------------|
| Behavioral fingerprint gate (SPEC-TBD) | `version_distance < BEHAVIORAL_THRESHOLD` → skip re-embed on cosmetic changes |
| MCP SSE transport (SPEC-TBD) | HTTP SSE transport for MCP server (SYS-ADR-0006) |
| fact_view_semantic (SPEC-TBD) | Domain-annotated semantic search combining topology + vectors |
| cluster_centroids worker (SPEC-TBD) | Consumes `file.embedded` + `topology.updated` → updates Layer 3 centroid vectors per Leiden cluster; `cluster_alignment` confidence dimension becomes non-null (SYS-ADR-0052: moved from Phase 4 — deps met at Phase 3 end) |
| sweep_coordinator (SPEC-TBD) | Celery Beat periodic re-index trigger for stale clusters; emits `re-embed.batch`; depends on `cluster_centroids` (SYS-ADR-0052: moved from Phase 4) |
| GraphQL endpoint (SPEC-TBD) | FastAPI + Strawberry; query planner routes structured/vector/graph; moved from Phase 2 enhancement — required by CodeGraph Explorer (Phase 5, SYS-ADR-0052) |

### Workers operational (new in Phase 3)
- `chunk_file`
- `batch_embed`
- `cluster_centroids`
- `sweep_coordinator` (Celery Beat periodic)

### Events operational (new in Phase 3)
- `file.chunked`
- `file.embedded`
- `re-embed.batch`

### Exit criteria (version tag: `v0.3.0`)
- [ ] All Phase 3 specs `Status: Implemented`
- [ ] Milestone capability demonstrated end-to-end
- [ ] `eval_fidelity_ceiling` passes (HEURISTIC fidelity → confidence ceiling ≤ 0.6)
- [ ] Refactor invariance eval passes (cosmetic rename → `version_distance < 0.05`)
- [ ] Embedding model ADR written and accepted
- [ ] `fact_search` returns results from Layer 1/2 vectors
- [ ] `cluster_alignment` dimension active in confidence profile (not null) — Layer 3 centroid count > 0
- [ ] GraphQL schema validates (introspection returns schema)
- [ ] Version tag: `v0.3.0`

### Verification commands
```bash
ecle search "billing function" --repo test_fixture   # vector results, not empty
ecle stats --repo test_fixture --vectors             # layer1_count > 0, layer2_count > 0
```

---

## 4. Phase 4 — Cross-Repo Linking + Grounding + Feedback + Admin Portal

> **Reordered from Phase 5 by SYS-ADR-0052** (2026-06-01). Cross-Repo + Grounding + Feedback
> from the former Phase 5 combined with the Admin Portal (formerly Phase 6). Phase 4 is the
> **MVP gate**: the Admin Portal gives operators a web UI for repo onboarding, job tracking,
> and system health from `v0.4.0` rather than `v1.0.0`.

**Milestone capability:** An operator can onboard repositories via ZIP or git URL, track import jobs, and view system health through a web portal — AND a developer can query cross-repo blast radius spanning multiple indexed repos with complete grounding lineage on every result.

**Entry criteria:** Phase 3 exit criteria met. `v0.3.0` tagged.

### Walking skeleton

| Order | Spec | Unlocks |
|-------|------|---------|
| 1 | build_contract_registry worker (SPEC-TBD) | Consumes `repo.ir_produced` → extracts public API contracts → emits `contracts.registered` |
| 2 | link_contracts worker (SPEC-TBD) | Consumes `contracts.registered` → O(C log C) cross-repo matching → emits `cross.linked` |
| 3 | cross_repo_indexer worker (SPEC-TBD) | Consumes `repo.indexed` → upserts cross-repo summary |
| 4 | Grounding verifier (SPEC-TBD) | Verifies all query results carry complete lineage (SYS-C-0003); required before cross-repo results are surfaced |
| 5 | Admin Portal UI (SPEC-TBD) | React 18 SPA — Onboard, Import Jobs, System Health (SYS-ADR-0026); repo onboarding via ZIP upload or git URL; the core operator milestone capability |

**Skeleton checkpoint:** After these five, `fact_impact` spans multiple repos with full lineage, and operators have a working web portal.

### Enhancement specs

| Spec | What it adds |
|------|--------------|
| ecle_feedback MCP tool (SPEC-TBD) | Feedback signal collection from users (SYS-ADR-0024) |
| learning_analyzer worker (SPEC-TBD) | Consumes `feedback.given` → updates confidence votes → emits `confidence.updated` |
| coverage_gap_aggregator worker (SPEC-TBD) | Consumes `language_pack.extension_miss` → aggregates → emits `coverage_gap` |

### Workers operational (new in Phase 4)
- `build_contract_registry`
- `link_contracts`
- `cross_repo_indexer`
- `learning_analyzer`
- `coverage_gap_aggregator`

### Events operational (new in Phase 4)
- `contracts.registered`
- `cross.linked`
- `repo.indexed`
- `feedback.given`
- `confidence.updated`
- `language_pack.extension_miss`
- `language_pack.coverage_gap`

### Exit criteria (version tag: `v0.4.0`)
- [ ] All Phase 4 specs `Status: Implemented`
- [ ] Milestone capability demonstrated end-to-end
- [ ] Cross-repo `fact_impact` returns results spanning two repos
- [ ] `eval_grounding_coverage` passes (all query results carry complete lineage)
- [ ] Feedback loop: `ecle_feedback` → `confidence.updated` event chain works
- [ ] Admin Portal: ZIP upload + git URL onboarding works end-to-end (SPEC per SYS-ADR-0026)
- [ ] Admin Portal: Import jobs page shows real job status from Kafka pipeline
- [ ] Version tag: `v0.4.0`

---

## 5. Phase 5 — Ontology + DSL + CodeGraph Explorer

> **Reordered from Phase 4 by SYS-ADR-0052** (2026-06-01). Ontology+DSL moves from former Phase 4.
> CodeGraph Explorer UI (IDEA-0026) added to this phase: launching the graph explorer alongside the
> Ontology layer means cluster cards carry domain names ("Payment Pipeline") from day one, rather
> than bare cluster IDs.

**Milestone capability:** A developer can ask "what business capabilities does this codebase support?" and receive a structured answer using domain vocabulary (e.g. "Billing: charge engine, fee calculation, invoice generation") — AND explore the topology graph interactively with domain-labelled cluster regions in the CodeGraph Explorer UI.

**Entry criteria:** Phase 4 exit criteria met. `v0.4.0` tagged.

### Walking skeleton

| Order | Spec | Unlocks |
|-------|------|---------|
| 1 | Domain ontology YAML (SPEC-TBD) | Base + tenant YAML vocabularies (SYS-ADR-0025); required before DSL detection can classify anything |
| 2 | detect_dsl_mappings worker (SPEC-TBD) | Consumes `file.stored` → tags DSL concepts → emits `dsl.mapped` |
| 3 | ontology_enricher worker (SPEC-TBD) | Consumes `dsl.mapped` + `topology.updated` → enriches ontology → emits `ontology.enriched` |
| 4 | fact_view_database MCP tool (SPEC-TBD) | Exposes domain-annotated aggregate database view; the core milestone capability |
| 5 | CodeGraph Explorer UI (SPEC-TBD) | React Flow 12 graph visualization — cluster cards with `canonical_name` from ontology, impact tour player, path highlighting (IDEA-0026 + SYS-ADR-0052); requires GraphQL endpoint (Phase 3) and `cluster_stable_id` (Phase 3 `compute_topology`) |

**Skeleton checkpoint:** After these five, a user can query domain-annotated capability views and explore the topology graph with labelled clusters.

### Enhancement specs

| Spec | What it adds |
|------|--------------|
| Staleness enforcement (SPEC-TBD) | `staleness_score` on every cluster; `staleness_caveat` in FACT envelope (SYS-C-0004) |
| fact_view_api_contracts MCP tool (SPEC-TBD) | Contract surface view across all entry points |

### Workers operational (new in Phase 5)
- `detect_dsl_mappings`
- `ontology_enricher`

### Events operational (new in Phase 5)
- `dsl.mapped`
- `ontology.enriched`

### Exit criteria (version tag: `v0.5.0`)
- [ ] All Phase 5 specs `Status: Implemented`
- [ ] Milestone capability demonstrated end-to-end
- [ ] `cluster_alignment` dimension non-null and `canonical_name` populated for ≥1 cluster
- [ ] Staleness caveat appears in responses for stale clusters
- [ ] `eval_staleness_honesty` passes
- [ ] CodeGraph Explorer loads topology graph with labelled cluster cards
- [ ] CodeGraph Explorer impact tour player walks a blast-radius path (fact_impact result)
- [ ] Version tag: `v0.5.0`

---

## 6. Phase 6 — Enterprise Scale-Out + Production

> **Amended by SYS-ADR-0052** (2026-06-01): Admin Portal moved to Phase 4. Phase 6 is now
> exclusively the enterprise infrastructure phase — production-grade backends, multi-tenancy,
> autoscaling, and disaster recovery. The Admin Portal already exists by Phase 6; the backend
> upgrade (PostgreSQL, Qdrant, Neo4j HA) happens transparently without changing its interface.

**Milestone capability:** An enterprise team can run ECLE at scale — PostgreSQL backend, multi-tenancy with Row-Level Security, KEDA autoscaling, full observability, and disaster recovery — across unlimited tenant repositories, with production-grade reliability and zero-downtime upgrades.

**Entry criteria:** Phase 5 exit criteria met. `v0.5.0` tagged.

### Walking skeleton

| Order | Spec | Unlocks |
|-------|------|---------|
| 1 | PostgreSQL backend (SPEC-TBD) | `IStructuredDB` PostgreSQL impl; pgbouncer mandatory (SYS-ADR-0010 Tier 3); all Tier 3 workers depend on this |
| 2 | Qdrant production cluster (SPEC-TBD) | Upgrade single-node Qdrant dev container to production cluster with replication + snapshots (SYS-ADR-0010 Tier 3); no `IVectorStore` interface change |
| 3 | Neo4j HA cluster (SPEC-TBD) | Scale Phase 3 single-node Neo4j to enterprise HA cluster; required for enterprise-scale multi-repo deployments |
| 4 | Multi-tenancy (SPEC-TBD) | Tenant isolation (SYS-ADR-0022); Row-Level Security policies; required before multi-tenant production use |

**Skeleton checkpoint:** After these four, the system runs on production-grade backends with full tenant isolation. The existing Admin Portal (Phase 4) continues to function transparently on the upgraded backend.

### Enhancement specs

| Spec | What it adds |
|------|--------------|
| KEDA autoscaling (SPEC-TBD) | Per-worker ScaledObject based on Kafka lag (SYS-ADR-0027) |
| Observability stack (SPEC-TBD) | Prometheus metrics, Grafana dashboards, OTel tracing (HAR-C-0006) |
| Disaster recovery (SPEC-TBD) | Backup/restore procedures (SYS-ADR-0023) |
| Document embedding (SPEC-TBD) | `document_embedder` worker for non-code docs (SYS-C-0008 §9) |
| Language Pack API isolation (SPEC-TBD) | IDEA-0015 deferred risk: RLS isolation of language packs per tenant |
| SYS-ADR-0033 webhook receiver (SPEC-TBD) | Continuous ingestion via git webhook events; git integration beyond basic URL onboarding (SYS-ADR-0033) |

### Workers operational (new in Phase 6)
- `document_embedder`

### Exit criteria (version tag: `v1.0.0`)
- [ ] All Phase 6 specs `Status: Implemented`
- [ ] Milestone capability demonstrated end-to-end
- [ ] Tier 3 deployment works end-to-end (K8s + managed PG + Qdrant + Kafka cluster)
- [ ] KEDA scales workers based on Kafka lag
- [ ] `eval_observability_baseline` passes (HAR-C-0006)
- [ ] `eval_log_masking` passes (no PII in logs)
- [ ] Multi-tenant isolation verified (Tenant A cannot see Tenant B data)
- [ ] DR drill executed successfully
- [ ] Version tag: `v1.0.0`

---

## 7. Rules for spec-writer and orchestrator

### Spec assignment
- Every spec MUST have `**Phase:** N` matching a phase in this contract
- The orchestrator MUST reject work that targets a phase whose entry criteria aren't met
- If a user requests work for a future phase, the orchestrator declares it and defers

### Scope enforcement
- If a spec grows to include deliverables from a later phase → STOP, split the spec
- The spec-reviewer MUST verify that the spec's scope fits within its declared phase
- No "Phase 1" spec may reference workers/events that only exist in Phase 3+

### Phase progression
- The release-manager verifies ALL exit criteria before recommending a version tag
- Version tags encode phase: `v0.{phase}.{patch}` for phases 1-5, `v1.0.0` for Phase 6
- Patches within a phase: `v0.1.1`, `v0.1.2` etc. (bug fixes, enhancements to existing specs)

### Constitution amendments
- Adding a new worker/event to SYS-C-0006 requires identifying which phase it belongs to
- If a worker is added to Phase 1 scope, ALL Phase 1 exit criteria must still be achievable
- Phase scope can only be adjusted by amending this contract (requires user approval)
