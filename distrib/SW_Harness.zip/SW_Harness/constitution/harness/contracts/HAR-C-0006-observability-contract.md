﻿# HAR-C-0006 — Observability Contract

**Scope:** Every deployed ECLE component — MCP server, Admin API, Kafka workers, Celery Beat, vector store.
**Enforced by:** `GET /metrics` schema validation (CI), `eval_observability_baseline` (nightly), alerting rule review (every PR that adds a new constant or worker).
**Status:** Active
**Related:** SYS-ADR-0010 (tiers), SYS-ADR-0013 (Kafka), SYS-ADR-0019 (auth), SYS-ADR-0020 (admin), SYS-ADR-0023 (DR)

---

## 1. The guarantee

**ECLE MUST be observable without direct database or log file access.**

An operator diagnosing a production issue MUST be able to answer the following questions using only `GET /metrics`, `GET /admin/v1/health`, and a Prometheus/Grafana dashboard:

- Is the ingestion pipeline moving? (worker Kafka consumer lag)
- Is query performance degraded? (p50/p95/p99 query latency)
- Is the data fresh? (stale vector ratio, avg staleness score)
- Are there coverage gaps? (failed files, unindexed repos)
- Is the system about to run out of resources? (DB connections, disk, memory)
- Who is using the system? (per-tenant request rates, top tools)

Answers that require `kubectl exec` + `psql` + manual query = an observability gap that must be fixed.

---

## 2. Instrumentation requirements

Every component MUST emit metrics in **Prometheus text format** at `GET /metrics`.

### MCP Server metrics

| Metric | Type | Labels | Description |
|--------|------|--------|-------------|
| `ecle_mcp_requests_total` | Counter | `tenant_id`, `tool`, `status` (ok/error/timeout) | Total MCP tool call attempts |
| `ecle_mcp_request_duration_ms` | Histogram | `tenant_id`, `tool` | End-to-end tool call duration; buckets: 50, 100, 200, 500, 1000, 2000 |
| `ecle_mcp_timed_out_total` | Counter | `tenant_id`, `tool` | Calls that hit the 2s hard timeout |
| `ecle_mcp_search_depth` | Histogram | `tenant_id`, `depth` (layer1/layer2/layer3/structured) | Which cascade layer answered |
| `ecle_mcp_flow_duration_ms` | Histogram | `tenant_id`, `flow_id` | Full flow execution time (SYS-ADR-0018) |
| `ecle_mcp_step_duration_ms` | Histogram | `tenant_id`, `step_name` | Per-step execution time (SYS-ADR-0018) |

### Worker metrics (per worker type)

| Metric | Type | Labels | Description |
|--------|------|--------|-------------|
| `ecle_worker_messages_processed_total` | Counter | `worker`, `status` (ok/error/dlq) | Events consumed and processed |
| `ecle_worker_processing_duration_ms` | Histogram | `worker` | Time to process one event |
| `ecle_worker_kafka_lag` | Gauge | `worker`, `topic` | Consumer group lag (messages behind head) |
| `ecle_worker_dlq_messages_total` | Counter | `worker`, `topic` | Messages forwarded to DLQ |
| `ecle_worker_skipped_total` | Counter | `worker`, `reason` (content_hash_match/behavioral_unchanged) | Idempotency skip events |

### Ingestion pipeline metrics

| Metric | Type | Labels | Description |
|--------|------|--------|-------------|
| `ecle_files_indexed_total` | Counter | `tenant_id`, `repo_id`, `fidelity` | Files successfully indexed |
| `ecle_files_failed_total` | Counter | `tenant_id`, `repo_id` | Files that failed parsing/persist |
| `ecle_files_pending_gauge` | Gauge | `tenant_id`, `repo_id` | Files in `parse_status=pending` |
| `ecle_embed_stale_ratio` | Gauge | `tenant_id` | Current stale vector ratio across all collections |
| `ecle_coverage_gap_count` | Gauge | `tenant_id`, `extension` | Global miss count per extension (SYS-ADR-0002) |

### Knowledge quality metrics

| Metric | Type | Labels | Description |
|--------|------|--------|-------------|
| `ecle_staleness_score_avg` | Gauge | `tenant_id`, `repo_id` | Mean `staleness_score` across `is_current=true` files |
| `ecle_confidence_behavioral_avg` | Gauge | `tenant_id`, `repo_id` | Mean `behavioral_accuracy` across current files |
| `ecle_confidence_contextual_avg` | Gauge | `tenant_id`, `repo_id` | Mean `contextual_accuracy` |
| `ecle_cluster_count` | Gauge | `tenant_id`, `repo_id` | Number of active clusters |
| `ecle_singleton_file_count` | Gauge | `tenant_id`, `repo_id` | Files with `cluster_stable_id=null` |
| `ecle_semantic_accuracy_avg` | Gauge | `tenant_id` | Mean `semantic_accuracy` (null excluded) |
| `ecle_unenriched_file_count` | Gauge | `tenant_id`, `repo_id` | Files with `semantic_accuracy=null` |

### Knowledge-graph summary metrics (driven by ECLE 1.0 health screen)

These metrics power the per-repo health dashboard and expose the same aggregates visible in the ECLE 1.0 System Health UI:

| Metric | Type | Labels | Description |
|--------|------|--------|-------------|
| `ecle_repo_code_files_total` | Gauge | `tenant_id`, `repo_id`, `repo_role` | Current code files indexed (`content_type=code`) |
| `ecle_repo_functions_total` | Gauge | `tenant_id`, `repo_id`, `repo_role` | Functions extracted across all code files |
| `ecle_repo_connections_total` | Gauge | `tenant_id`, `repo_id`, `repo_role` | Topology graph edges — call/import/data-flow connections |
| `ecle_repo_db_operations_total` | Gauge | `tenant_id`, `repo_id`, `repo_role` | DB operations extracted (`content_type=data-sql`) |
| `ecle_repo_documents_total` | Gauge | `tenant_id`, `repo_id`, `repo_role` | Documents indexed (`content_type=docs` + `content_type=config`) |
| `ecle_repo_searchable_items_total` | Gauge | `tenant_id`, `repo_id`, `repo_role` | All searchable entities: sum of vectors across all collections for this repo |
| `ecle_repo_ready` | Gauge | `tenant_id`, `repo_id` | 1 = `parse_status=ready`, 0 = otherwise; powers the "Ready" badge |
| `ecle_import_job_duration_seconds` | Histogram | `tenant_id`, `repo_id`, `content_type` | Ingestion job wall-clock duration |
| `ecle_import_job_new_docs_total` | Gauge | `tenant_id`, `repo_id`, `content_type` | Net-new items imported in last job ("78 new" sub-text in job list) |
| `ecle_import_job_empty_total` | Gauge | `tenant_id`, `repo_id`, `content_type` | Empty files skipped in last job ("22 empty" sub-text) |

These MUST be updated transactionally at end of each ingestion job — not lazily. The health dashboard reads these gauges directly; a stale gauge is a health-screen bug.

### Infrastructure metrics (Tier 3 — Prometheus exporters)

| Metric | Source | Description |
|--------|--------|-------------|
| `pg_stat_activity_count` | postgres_exporter | Active DB connections (watch for pgbouncer saturation) |
| `pg_database_size_bytes` | postgres_exporter | DB size growth |
| `kafka_consumer_lag_sum` | kafka_exporter | Aggregate lag across all consumer groups |
| `qdrant_collections_vector_count` | qdrant_exporter | Total vectors (growth monitoring) |
| `qdrant_collection_size_bytes` | qdrant_exporter | Vector store disk usage |

---

## 3. SLO definitions

These are the minimum observable SLOs. Teams deploying ECLE MUST configure Prometheus alerts for the hard SLOs.

| SLO | Hard / Soft | Target | Alert threshold |
|-----|-------------|--------|-----------------|
| MCP query p95 latency | **Hard** | < 1000 ms | Alert if p95 > 1500 ms for 5 min |
| MCP query p99 latency | Hard | < 2000 ms | Alert if p99 > 2000 ms (= timeout) for 2 min |
| Worker Kafka lag (critical topics) | **Hard** | < 10,000 msg | Alert if lag > `KAFKA_LAG_ALERT_THRESHOLD` for 10 min |
| Ingestion success rate | Hard | > 99% | Alert if `files_failed / files_indexed > 0.01` over 30 min |
| Stale vector ratio | Soft | < 10% | Alert if `embed_stale_ratio > 0.15` |
| Mean staleness score | Soft | < 0.1 | Alert if mean staleness > 0.2 for 1 hour |
| DLQ message rate | Hard | 0 | Alert if `dlq_messages_total` increases for any topic |
| Admin API availability | Hard | 99.9% | Alert if `/admin/v1/health` returns non-200 for 2 min |

---

## 4. Distributed tracing

ECLE uses **OpenTelemetry** for trace propagation across the request path. Traces span MCP tool calls into backend operations but do **not** propagate through Kafka (Kafka consumers start new traces, linked by `X-Request-Id` in the event payload).

### Trace structure

```
MCP tool call (root span: ecle_mcp.tool_call)
    │ trace_id = UUID, span_id = UUID
    │ attributes: tenant_id, tool, flow_id, X-Request-Id
    │
    ├── FlowExecutor.run_flow (child span: ecle_flow.execute)
    │       ├── step: enrich (child span: ecle_step.enrich)
    │       ├── step: layer3_ann (child span: ecle_step.layer3_ann)
    │       └── step: layer1_ann (child span: ecle_step.layer1_ann)
    │
    └── GraphQL resolver (child span: ecle_graphql.resolve)
            ├── IStructuredDB.fetchall (child span: ecle_db.query)
            └── IVectorStore.search (child span: ecle_vector.search)
```

Trace exporter: OTLP to Jaeger (Tier 2) or managed APM (Tier 3: Datadog, New Relic, AWS X-Ray). Configured via `OTEL_EXPORTER_OTLP_ENDPOINT`. Tracing is **disabled by default in Tier 1 dev** (`OTEL_SDK_DISABLED=true`).

**Kafka context propagation:**
```json
// Every Kafka event payload MUST include:
{
  "X-Request-Id": "uuid",       // links Kafka consumer trace to original request
  "X-Trace-Id":   "otlp_trace_id",  // for async trace stitching in APM tools
  ...event fields...
}
```

Kafka consumers start a new root span and set `trace_id = X-Trace-Id` from the event payload header. This enables APM tools to correlate `MCP tool call → Kafka event → worker processing` as a single business operation.

---

## 5. Enterprise logging

### 5.1 Log format — mandatory fields

All ECLE components emit **structured JSON logs** to stdout. One JSON object per line (no multi-line log entries — they break log shippers). Log shipping to a central store is the operator's responsibility and MUST be configured before Tier 2/3 goes live.

**Base fields — every log line:**

```json
{
  "timestamp":   "2026-05-07T10:00:00.000Z",   // ISO-8601 UTC — never local time
  "level":       "INFO | WARN | ERROR | FATAL",
  "service":     "ecle-mcp | ecle-admin | ecle-worker-parse_repo | ...",
  "version":     "2.1.0",                        // ECLE release version
  "tenant_id":   "acme",                         // null for system-level events
  "request_id":  "uuid",                         // X-Request-Id; null for async worker events
  "trace_id":    "uuid",                         // OTEL trace_id (null when tracing disabled)
  "message":     "..."
}
```

**Additional fields for MCP / Admin API log lines:**

```json
{
  ...base fields...,
  "tool":        "ecle_find_functions",           // MCP tool name or "admin:{endpoint}"
  "flow_id":     "find_functions_v1",
  "query_ms":    142,
  "status":      "ok | error | timeout"
}
```

**Additional fields for Kafka worker log lines:**

```json
{
  ...base fields...,
  "worker":      "parse_repo",
  "topic":       "ecle.file.source.received",
  "consumer_group": "ecle-parse-repo",
  "repo_id":     "acme/vstcsm",
  "file_id":     "uuid"                          // null for batch-level events
}
```

**Additional fields for ERROR level only:**

```json
{
  ...base fields...,
  "error_code":  "PARSE_FAILED | DB_WRITE_FAILED | VECTOR_UPSERT_FAILED | ...",
  "error_class": "ExtractorError",
  "stack_trace": "...",                          // ERROR only — never on INFO/WARN
  "retryable":   true
}
```

---

### 5.2 Log levels

| Level | When to use | Ops action |
|-------|-------------|------------|
| `INFO` | Normal operations — file indexed, query served, worker heartbeat (every 60 s) | None |
| `WARN` | Degraded-but-functional — staleness caveat served, rate limit hit, DLQ event routed, coverage gap triggered | Review next business day |
| `ERROR` | Failure with recovery — parse failed (file skipped), DB write failed (event nacked), vector upsert failed | Alert; investigate within SLA |
| `FATAL` | Process cannot continue — DB unreachable at startup, Kafka bootstrap failed, config invalid | PagerDuty; immediate response |

Worker heartbeat log (every 60 s): `INFO` with `message="worker_alive"` + current `kafka_lag` for each assigned partition. This provides a live liveness signal without a separate health endpoint.

---

### 5.3 Sensitive field masking (mandatory — OWASP A02)

The following fields MUST NEVER appear in log output. If a code path would log them, the value MUST be replaced with the masked token.

| Field type | Masked token |
|------------|--------------|
| API key or token (`Bearer ...`, `apikey-...`) | `[REDACTED_KEY]` |
| DSN / connection string | `[REDACTED_DSN]` |
| File content or source code text | `[REDACTED_CONTENT]` |
| JWT payload (claims) | `[REDACTED_JWT]` |
| Personally identifiable information (email, name) | `[REDACTED_PII]` |
| Kafka message value when it contains source text | `[REDACTED_PAYLOAD]` |

A log sanitiser middleware MUST be applied to all log emitters at the framework level — not per-callsite. Implementing per-callsite masking is fragile and non-compliant.

CI gate: `eval_log_masking` runs on every PR that touches a log-emitting path. It submits test inputs containing each field type above and asserts masked tokens appear in output, never the raw value.

---

### 5.4 Log sampling — high-volume workers

High-throughput workers (`batch_embed`, `parse_repo`, `document_embedder`) can process thousands of events per minute. Logging every event at INFO would produce log volumes that exceed log shipper capacity and inflate storage costs.

**Sampling rules:**

| Worker | Event type | Log rate |
|--------|-----------|----------|
| `batch_embed` | Successful embed per file | 1-in-`LOG_SAMPLE_RATE` (default: 1-in-100) |
| `parse_repo` | Successful parse per file | 1-in-`LOG_SAMPLE_RATE` |
| `document_embedder` | Successful chunk embed | 1-in-`LOG_SAMPLE_RATE` |
| Any worker | Skip (idempotency/content_hash) | 1-in-`LOG_SAMPLE_RATE` |
| Any worker | ERROR | Always (no sampling) |
| Any worker | WARN | Always (no sampling) |
| Any worker | First event after startup | Always |
| Any worker | DLQ route | Always |
| Any worker | Job start/complete boundary | Always |

`LOG_SAMPLE_RATE=100` is configurable per tier. Default: `1` (no sampling) for Tier 1 dev; `100` for Tier 3 enterprise.

Even sampled events MUST include `"sampled": true` and `"sample_rate": 100` fields so log analysis tooling can reconstruct accurate rates.

---

### 5.5 Log shipping architecture per tier

| Tier | Shipping method | Destination | Retention |
|------|----------------|-------------|----------|
| Tier 1 dev | stdout only | Developer terminal | Session only |
| Tier 2 compose | Fluentd sidecar → file | Local volume (`/logs/ecle/`) | 7 days (log rotation) |
| Tier 3 enterprise | Fluentd/Fluent Bit DaemonSet → | Elasticsearch/OpenSearch **or** managed (Datadog Logs / CloudWatch / Splunk) | 30 days operational; 365 days audit (SYS-ADR-0021) |

**Tier 3 mandatory requirements:**
- Log shipper runs as a DaemonSet, not a sidecar — one per node, shared buffer.
- All logs MUST be indexed by `tenant_id`, `service`, `level`, and `timestamp` for efficient filtering.
- Operational logs (`INFO`) and audit logs (`query_audit_log` events at `INFO`) MUST be routed to separate indices/streams with independent retention policies.
- Log shipper backpressure: if the shipping queue exceeds `LOG_SHIPPER_QUEUE_LIMIT` (default 10,000 lines), the shipper MUST drop `INFO` logs (not `WARN`/`ERROR`/`FATAL`) and emit a counter `ecle_logs_dropped_total{level="INFO"}`.

---

### 5.6 Audit-trail logging

Every authenticated API call (MCP + Admin) MUST produce an audit log line at `INFO` level in addition to being written to `query_audit_log` (SYS-C-0010). This dual-write ensures audit trail survives even if the DB is unavailable.

Audit log lines MUST include:
```json
{
  "timestamp":    "...",
  "level":        "INFO",
  "service":      "ecle-mcp | ecle-admin",
  "audit":        true,                      // marks this as an audit record
  "tenant_id":    "acme",
  "subject":      "apikey:my-key-label",
  "request_id":   "uuid",
  "tool":         "ecle_find_functions",
  "query_ms":     142,
  "result_count": 8,
  "timed_out":    false
}
```

Audit log lines MUST NOT include query text, file content, or vector payloads. Audit log lines are routed to the audit stream and retained for `AUDIT_LOG_RETENTION_DAYS` (SYS-ADR-0021, default 365 days). They are NOT subject to `LOG_SAMPLE_RATE` sampling.

---

## 6. Alerting rules (mandatory for Tier 2/3)

The following Prometheus alerting rules MUST be deployed alongside ECLE at Tier 2/3:

```yaml
# Hard SLOs — page on-call
- alert: ECLEQueryLatencyHigh
  expr: histogram_quantile(0.95, ecle_mcp_request_duration_ms_bucket) > 1500
  for: 5m

- alert: ECLEWorkerLagCritical
  expr: ecle_worker_kafka_lag{topic=~"ecle\\.file\\.(ir_produced|stored|source\\.received)"} > 10000
  for: 10m

- alert: ECLEDLQActivity
  expr: increase(ecle_worker_dlq_messages_total[5m]) > 0
  for: 1m

- alert: ECLEIngestionFailureRate
  expr: rate(ecle_files_failed_total[30m]) / rate(ecle_files_indexed_total[30m]) > 0.01
  for: 30m

# Soft SLOs — notify (no page)
- alert: ECLEStaleVectorRatioHigh
  expr: ecle_embed_stale_ratio > 0.15
  for: 1h

- alert: ECLEBackupAge
  expr: time() - ecle_last_backup_timestamp > 129600   # 36 hours
  for: 5m

- alert: ECLELogShipperDropping
  expr: increase(ecle_logs_dropped_total{level="INFO"}[5m]) > 0
  for: 5m
  # Indicates log shipper queue pressure — review log volume or increase queue limit
```

`ecle_last_backup_timestamp` is a Gauge emitted by the backup Celery Beat task (SYS-ADR-0023) on each successful backup.

---

## 7. Eval gates

### `eval_observability_baseline`
Runs nightly. Tests that all mandatory metrics are emitted and parseable:

1. Trigger one ingestion + one query on the eval corpus.
2. Scrape `GET /metrics` from all component pods.
3. Assert all mandatory metrics in §2 are present with valid values.
4. Assert no metric has `NaN` or `+Inf` as a value.
5. Assert all SLO alert rules in §6 are syntactically valid Prometheus PromQL.
6. Assert `ecle_repo_ready{repo_id="eval-corpus"}` == 1 after ingestion completes.

**Pass criteria:** All mandatory metrics present; all SLO rules valid. Failure blocks release.

### `eval_log_masking`
Runs on every PR that modifies a log-emitting path. Tests that sensitive fields never appear in log output:

1. Submit test inputs containing each sensitive field type from §5.3 (API key, DSN, JWT, file content, PII).
2. Capture structured log output from the affected component.
3. Assert that masked tokens (`[REDACTED_KEY]`, `[REDACTED_DSN]`, etc.) appear in place of raw values.
4. Assert that raw sensitive values do NOT appear anywhere in log output.
5. Assert that `"sampled": true` is present on all sampled INFO log lines.

**Pass criteria:** All 5 assertions pass for all sensitive field types. Failure blocks merge.

---

## 8. Dashboard — reference Grafana dashboard

A reference Grafana dashboard template (`deploy/grafana/ecle-dashboard.json`) ships in the repo. It includes panels for all metrics defined in §2. Operators import this into their Grafana instance and modify as needed.

Dashboard rows:
1. **System health** — `GET /admin/v1/health` status, Kafka lag, DB connections, `ecle_repo_ready` per repo
2. **Per-repo knowledge graph** — `ecle_repo_code_files_total`, `ecle_repo_functions_total`, `ecle_repo_connections_total`, `ecle_repo_db_operations_total`, `ecle_repo_documents_total`, `ecle_repo_searchable_items_total` — mirrors the ECLE 1.0 System Health screen
3. **Query performance** — p50/p95/p99 latency, timeout rate, search depth distribution
4. **Ingestion pipeline** — files indexed/failed/pending, import job duration, worker lag per topic
5. **Knowledge quality** — staleness scores, confidence averages, unenriched files
6. **Coverage** — coverage gap extensions, singleton file counts, cluster counts
7. **Enterprise logging** — `ecle_logs_dropped_total` by level, log shipper queue depth (pulled from Fluentd/Fluent Bit metrics), ERROR log rate by service
8. **Security/Auth** — requests by tenant, rate limit events, DLQ messages, audit log write rate

---

## 13. References

| # | Citation | Relevance |
|---|----------|----------|
| R1 | OpenTelemetry Specification (opentelemetry.io/docs/specs/otel/) — CNCF Incubating project | Industry standard for traces, metrics, logs. ECLE's §2 (OTEL SDK), §5 (distributed tracing), §8 (log format) follow OTEL spec |
| R2 | Sridharan, C. "Distributed Systems Observability", O'Reilly 2018 — The Three Pillars | Defines metrics + logs + traces as the three observability pillars; ECLE implements all three per §2-§8 |
| R3 | Weiss, T. "The RED Method" (grafana.com/blog/2018/08/02/the-red-method/) | Request rate, Error rate, Duration for service-level monitoring; ECLE's Grafana dashboards (§12) follow RED |
| R4 | Beyer, B. et al. "Site Reliability Engineering", O'Reilly 2016 — Chapter 6: Monitoring Distributed Systems | Four golden signals: latency, traffic, errors, saturation. ECLE's metrics (§3-§4) map directly to these signals |
| R5 | W3C Trace Context (w3.org/TR/trace-context/) | W3C standard for distributed trace propagation; validates ECLE's trace_id/span_id correlation requirement |
