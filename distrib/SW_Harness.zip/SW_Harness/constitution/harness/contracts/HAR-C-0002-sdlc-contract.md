﻿# HAR-C-0002 — SDLC Contract

**Scope:** All code changes in `src/`, `tests/`, `specs/`, `constitution/`.
**Enforced by:** Branch protection, CI gates, PR review checklist.
**Status:** Active
**Amended by:** HAR-ADR-0019 §6 (gate checklists), HAR-ADR-0020 §6 (add proof coverage report to G5 gate check), HAR-ADR-0022 (mechanism-fidelity verification: Scenarios, Constraints IR, design.md, typed test tiers)

---

## 1. The lifecycle — no step is skippable

```
Spec → Write failing tests → Implement → Green → Review → Merge → Release
```

**HARD RULE: Spec before code. Tests before implementation. Always.**

No implementation begins without a written spec at `specs/phase-N/SPEC-NNNN-<name>.md`.
Code without a spec is unauthorised code. Reviewer rejects it immediately.

**Phase governance:** Every spec's `Phase: N` header MUST reference a phase defined in
`17-phase-roadmap-contract.md`. Work targeting a future phase (whose entry criteria are
not yet met) is deferred — the orchestrator declares it and parks it. No phase-N+1 work
may begin until phase-N exit criteria pass. See HAR-C-0007 for full rules.

TDD order within a feature branch:
1. Write all test cases listed in `## Tests required` and `## Acceptance criteria` — they all fail (Red).
2. Write the minimum implementation to make them pass (Green).
3. Refactor under green — no behaviour changes, tests stay green.
4. Open PR. CI proves green before review.

---

## 2. Spec format

Every spec MUST contain all of the following sections:

```markdown
# SPEC-NNNN — <title>

**Phase:** N
**Status:** Draft | Approved | Implemented | Superseded
**Implements:** <ADR-NNNN if applicable>
**Depends on:** <SPEC-NNNN, SPEC-NNNN>

## Problem
One paragraph — what gap or requirement this spec addresses.

## Decision
What we are building. Interface-first: define the public API, inputs, outputs,
events emitted, and events consumed BEFORE describing the implementation.

## Interface contract
<function signatures, event payload shapes, DB table changes>

## Scenarios
Named scenarios in GIVEN/WHEN/THEN format describing the exact execution model.
Each scenario covers one logical path. THEN clauses that name a specific callable
MUST name it explicitly and MUST include a negation clause when an alternative exists.

Format:
```
### Scenario: <name>
GIVEN <precondition>
WHEN <trigger>
THEN <callable> is called
AND NOT <alternative_callable> is called
```

THEN clauses that constrain ordering name both callables: `THEN <a> completes before <b> is called`.
THEN clauses that constrain config: `THEN <key> is <value>`.

## Constraints
Machine-readable YAML block. Every mechanism constraint derived from THEN clauses
that names a greppable symbol belongs here. Prose-only constraints belong in Scenarios
and must have a corresponding T-M test.

When no mechanism constraints exist: `_None — this spec prescribes no mechanism-level constraints._`

```yaml
mechanism:
  - must_call: <symbol>           # callable that MUST be used
    must_not_call: <symbol>       # callable that must NOT be used (optional)
  - ordering: [<first>, <second>] # first must execute before second
config:
  - key: <config_key>
    value: <exact_value>
```

## Acceptance criteria
Concrete input/output examples that make the behaviour unambiguous and testable.
At least one example per non-trivial scenario.
Format: Given / Input / Expected output.
Test vectors for deterministic operations (hashes, IDs) committed to `tests/fixtures/`.

## Error handling
How each error condition is classified and reported.

**Every error row MUST include an exact `Body` column** showing the literal JSON
returned to the caller — do not rely on framework defaults (e.g. FastAPI wraps
`HTTPException.detail` in `{"detail": ...}`; if the spec requires `{"error": ...}`,
a custom exception handler is needed and MUST be listed in the Interface contract).

| Error condition | Status | Body | Classification | Event emitted |
|----------------|--------|------|---------------|--------------|
| `<condition>` | 4xx/5xx | `{"error": "<code>"}` | transient / permanent | `<DLQ event or none>` |

## Tests required

### AC tests (outcome)
File: `tests/unit/test_<name>.py` and/or `tests/integration/test_<name>.py`
Tests that verify *what the system produces*. One entry per Acceptance criteria row.
Format: `T<n>: <scenario description>`

### Mechanism tests (T-M)
File: `tests/unit/test_<name>.py`
Tests that verify *which code path executed*. One entry per `mechanism:` Constraints entry.
Format: `T-M<n>: assert <must_call> called; assert <must_not_call> NOT called`
Must use call-site spy/mock (e.g. `mocker.patch`, `jest.spyOn`, `Mockito.verify`).
Required when `## Constraints` has any `mechanism:` entry. Cannot be omitted.

### Contract tests (T-C)
File: `tests/unit/test_<name>_config.py` or same unit file
Tests that verify *configuration values match spec*. One entry per `config:` Constraints entry.
Format: `T-C<n>: assert <key> == <value>`
Required when `## Constraints` has any `config:` entry. Cannot be omitted.

## Out of scope
Explicitly state what this spec does NOT cover.

## Deviations
Filled in at implementation time. Document every case where the implementation
diverged from this spec, and why. Empty = implementation matches spec exactly.
```

---

## 3. Branch strategy

```
main                     production-ready, always deployable
  └─ phase-{N}/{scope}-{feature}    feature branches
       e.g. phase-1/parser-language-pack-registry
            phase-2/embed-onnx-worker
```

Rules:
- Branch from `main` only.
- Branch name MUST include phase number and feature name.
- Keep branches short-lived — target < 1 week.
- Never commit directly to `main` — all changes via PR.

---

## 4. Commit standards

Format: `<type>(<scope>): <description> [Phase N]`

```
feat(parser): add LanguagePackRegistry scan on startup [Phase 1]
fix(events): emit fallback_count in repo.ir_produced payload [Phase 1]
test(parser): add unit tests for DefaultPack fallback path [Phase 1]
refactor(db): extract IStructuredDB interface from SQLiteBackend [Phase 1]
docs(constitution): add SYS-ADR-0002 language pack registry [Phase 1]
```

Types: `feat` | `fix` | `test` | `refactor` | `docs` | `chore` | `perf`

Rules:
- One logical change per commit — atomic, reversible.
- Present tense, imperative mood ("add", not "added" or "adds").
- Reference spec/ADR in the body when the commit implements one.
- **TDD commit order on every feature branch: `test(...)` commit MUST precede the first `feat(...)` commit.** Reviewer checks `git log --oneline` to verify order.
- Pre-commit hooks enforce: `ruff check` + `ruff format` + `pytest` on staged files.

---

## 5. PR rules

- **Max 500 lines changed** (excluding auto-generated files and test fixtures).
- PR description MUST include: what changed, which phase/spec it implements, link to spec doc.
- CI Stage 1 (lint + unit tests) MUST pass before reviewer looks at the PR.
- CI Stage 2 (integration tests) MUST pass before merge.
- No self-merge — at minimum one human review required.

---

## 6. Review checklist (10-point — reviewer applies to every PR)

1. **Spec conformance** — does the implementation match the spec exactly? No undocumented behaviour.
   - Read `## Scenarios` step by step. For each THEN clause, find corresponding code.
   - **Read `<workspace_path>/design.md`** — for each mechanism declaration, verify the declared callable appears in the implementation and the excluded callable does NOT appear in any code path. If `design.md` is absent, this item is FAIL.
2. **Interface contract** — public APIs match the types defined in the spec.
   - Pydantic `Field(description=)` must enumerate the same allowed values as the corresponding `@field_validator`. Reviewer verifies this cross-reference for every Settings field in the diff that has both a `description=` argument and a validator. (HAR-ADR-0011)
3. **Coding standards** — `01-coding-standards.md` checklist passes.
   - YAML operator config files must have correct env var names in inline comments. Reviewer derives the correct variable as `ECLE_` + `UPPER_SNAKE_CASE(field_name)` and spot-checks every comment that references a variable name in any file under `ecle-data/config/`. (HAR-ADR-0011)
4. **Test coverage** — new code ≥ 80% line coverage; critical paths 95%+.
5. **No anti-patterns** — `10-anti-patterns.md` items are absent.
   - A broad `except Exception` block must not suppress errors belonging to a finer-grained sub-check whose partial result has already been appended to a results list. Each failure mode must produce a distinct, accurate error message. (HAR-ADR-0011)
6. **Event contract** — if the code emits or consumes events, payload matches `09-event-pipeline-contract.md`.
7. **No orphan data paths** — if a spec creates a table or writes a schema field, the write path EXISTS and is tested. Schema without writes = bug (learned from SYS-ADR-0001 post-mortem).
   - When any `{migration_dir}/` file is added or modified in the diff, every integration test with a hardcoded migration-head string (e.g., `expected_head`) must be updated to match the new head. Reviewer scans test files for migration-head literals and verifies they match the last file in `{migration_dir}/` lexicographic order. (HAR-ADR-0011)
8. **Acceptance criteria covered** — every example in `## Acceptance criteria` has a corresponding test. No uncovered examples.
   - **T-M coverage** — every `mechanism:` entry in `## Constraints` has a corresponding mechanism test (T-M) using a call-site spy. Outcome-only assertion = FAIL for this item.
   - **T-C coverage** — every `config:` entry in `## Constraints` has a corresponding contract test (T-C) asserting the exact value. Absent = FAIL.
9. **Test traceability header** — every new test file has `# Implements: SPEC-NNNN` in its module docstring or header comment. Reviewer verifies the link is correct.
10. **SAST report** — `@sast` agent runs `bandit` + `pip-audit` at G5 and writes the active workspace's `reviews/sast-report.md`. Reviewer checks the verdict:
    - `FAIL`: pipeline halted — FAIL findings must be resolved before merge. *(Only applicable when `src/` files were changed in this task.)*
    - `WARN`: reviewer adds a PR comment acknowledging each WARN finding by name.
    - `PASS`: no action required.
    **Zero-runtime scope (HAR-ADR-0008 §Opt-5):** For tasks that changed NO files under `src/` (e.g. CONSTITUTION_CHANGE touching only agent/contract/ADR files), the SAST verdict is advisory: WARN does not block merge; FAIL findings are logged for the next runtime-touching task.
    Full policy: HAR-ADR-0005 (base SAST policy) and HAR-ADR-0008 §Opt-5 (zero-runtime scoping exception). Agent file: `.github/agents/sast.agent.md`.

---

## 7. Cross-spec wiring rule (anti-bloat + anti-bug)

When a BUG_FIX or ENHANCEMENT amends a spec (`SPEC-AAAA`) whose behaviour depends on
another spec (`SPEC-BBBB`) — for example, a worker that was merged from two specs, or
a base class used by multiple derived workers — **at least one integration test that
exercises the SPEC-AAAA change through the SPEC-BBBB boundary MUST be included in the
PR**.

This test MUST live in `tests/integration/test_<flow_name>.py`, not in the unit test
for the amended module alone. Its purpose is to prove that the fix does not silently
break the contract at the integration seam.

**Reviewer check at G5:** If the PR touches `{src_dir}/<module>/<file>.py` AND the
spec's `Depends on:` field lists another spec, the reviewer verifies that a wiring
test exists. Absence of a wiring test = "Request changes" (no exceptions).

Additional reviews triggered by:
- **Security review** — new external dependency, new API endpoint, auth changes.
- **Architecture review** — cross-layer changes, schema changes, new event types.
- **SAST review** — mandatory at every G5 run via `@sast` agent (HAR-ADR-0005).

---

## 7. Non-negotiable rules

1. No direct commits to `main`.
2. No merge without passing CI.
3. No merge without code review.
4. No hardcoded values — config or constants, never magic numbers in logic.
5. No secrets in code — `.env` or vault only, never committed.
6. No stale docs — if code changes, the relevant spec and contract update in the same PR or a linked follow-up PR opened before merge.
7. No scope creep — if a task grows beyond the spec, split into a new spec and a new PR.
8. No orphan data paths — schema without writes is a bug.
9. No spec written after implementation — spec MUST pre-date the first commit on the feature branch.
10. No cross-cutting changes without a cross-cutting spec review — if Spec A reads from X and Spec B writes to X, both MUST reference each other. Reviewer verifies the write path exists before approving the read path.
11. No spec marked `Status: Implemented` without `## Deviations` filled in — even if empty (`_None — implementation matches spec exactly._`).
11a. No `## Constraints` entry whose symbol is present in the source file but not in the test suite as a call-site spy assertion — this is the "import-but-not-call" class of bug.
12. No test file without a traceability header — `# Implements: SPEC-NNNN` MUST appear in the module docstring or as a top-of-file comment.
13. No `feat(...)` commit without a prior `test(...)` commit on the same branch — TDD order is enforced at review. Implementation commits that arrive before test commits are rejected.
14. No `## Error handling` row without a literal `Body` column — status code alone is insufficient. The exact JSON response schema must be specified.
15. No `## Interface contract` section that omits `__init__` signatures
16. No first test commit (`test(...)`) on a feature branch without a preceding `design.md` commit in the workspace — the mechanism declaration must pre-date the first test. Coder produces `design.md` at G4 start; it is committed before any `test(...)` commit. — every class whose constructor arguments determine integration points (middleware, services, app factories) MUST list its full `__init__` signature including keyword-only parameters and injected types.

---

## 8. Release gates

Release gates are governed by `17-phase-roadmap-contract.md` exit criteria.

```
Phase completion → ALL exit criteria in HAR-C-0007 §{phase} pass
                 → tag v0.{phase}.0
                 → CHANGES.md updated
                 → All eval suites pass (see 03-testing-contract.md)
                 → All specs in phase marked Status: Implemented
                 → All relevant constitution docs updated
```

The `release-manager` agent verifies all exit criteria before recommending a version tag.
A phase MUST NOT be tagged if any exit criterion is unmet. No exceptions.

**Per-spec release commits (G6 mandatory — Rule 16):**
Before closing a G6 task, `@release-manager` MUST commit all staged and untracked
SPEC-related changes into the repository. All commit messages follow the §4 format:
`<type>(<scope>): <description> [Phase N]`. Core TDD requirement: every `test(...)`
commit MUST be chronologically earlier than its paired `feat(...)` commit.
Full G6 packaging order (docs → test → feat → fix → chore) is defined in
`release-manager.agent.md` §6 and is the authoritative sequence.
`git status --short` MUST return no uncommitted SPEC files at G6 close. Pipeline
workspace artifacts are committed last in a single `chore(pipeline): ...` commit.
Use `git add <specific_files>` — never `git add .` or `git add -A`.

Version scheme: `v0.{phase}.{patch}` for phases 1-5; `v1.0.0` for Phase 6 (enterprise GA).
Patches within a phase (bug fixes, enhancements): `v0.1.1`, `v0.1.2`, etc.

---

## 9. Post-implementation smoke test

After any ingestion or pipeline change, run this sequence and verify non-empty results at each step:

```bash
# 1. Upload a small known repo
POST /upload  test_fixture.zip

# 2. Poll until repo.ir_produced event appears
ecle events --type repo.ir_produced --repo test_fixture

# 3. Verify structured DB populated
ecle stats --repo test_fixture        # files > 0, functions > 0

# 4. Verify vectors exist
ecle search "billing function" --repo test_fixture    # results, not "no index"

# 5. Verify graph populated
ecle impact --file batch_rating.ppc --repo test_fixture    # edges > 0
```

Any step returning empty or erroring = integration gap. Fix before merging.
