﻿# HAR-C-0005 — Deployment Contract

**Scope:** Every Python file in `src/`, every config file, every worker entry point.
**Enforced by:** Code review, `eval_srp_isolation`, integration tests run in Tier 2 (Docker Compose).
**Status:** Active
**Related:** SYS-ADR-0010, SYS-ADR-0028

---

## 1. The three tiers

| Tier | Name | `ECLE_TIER` | Use case |
|------|------|-------------|----------|
| 1 | Single-machine dev | `dev` | Local development; no Docker required |
| 2 | Docker Compose | `compose` | Small team; single-server production |
| 3 | Kubernetes enterprise | `enterprise` | Large org; multi-tenant; air-gapped; HA |

**The same codebase runs in all three tiers. Tier selection is config, not code.**

---

## 2. Core rules — non-negotiable

1. **No tier-specific code branches** — `if settings.ECLE_TIER == "enterprise"` in application code is **banned**. Tier differences are handled entirely by config and backend factory functions.
2. **No direct filesystem calls in worker logic** — all artifact reads/writes go through `IArtifactStore`. Never call `open()`, `Path.read_bytes()`, or `Path.write_bytes()` directly in worker code.
3. **No hardcoded paths** — every path comes from `settings` (Pydantic BaseSettings). No string literals like `"./artifacts/"` in worker code.
4. **Workers MUST be stateless** — no instance variables that persist between task invocations. A worker running as one Celery process in Tier 1 must behave identically when running as 20 K8s pod replicas in Tier 3.
5. **MCP server MUST be stateless** — no session state, no in-memory cache between tool calls. Multiple replicas behind a load balancer must return identical results.

---

## 3. Backend selection by tier

All backend choices are driven by environment variables only. The `get_*()` factory
functions in `{src_dir}/core/backends.py` read these and return the correct implementation.

| Config var | Tier 1 default | Tier 2 default | Tier 3 default |
|-----------|---------------|---------------|---------------|
| `ECLE_DATA_ROOT` | `./ecle-data` | `/app/ecle-data` (volume) | N/A (managed services) |
| `ECLE_LOG_DIR` | `./ecle-logs` | `/app/ecle-logs` (volume) | stdout → Fluentd |
| `ECLE_CONFIG_PATH` | `./ecle-data/config/ecle.yaml` | `/app/ecle-data/config/ecle.yaml` | ConfigMap |
| `ECLE_LOG_CONFIG_PATH` | `./ecle-data/config/logging.yaml` | `/app/ecle-data/config/logging.yaml` | ConfigMap |
| `STRUCTURED_BACKEND` | `postgresql` | `postgresql` | `postgresql` |
| `STRUCTURED_BACKEND_URL` | `postgresql://ecle:ecle@localhost:5432/ecle` | `postgresql://...` | managed DSN via Secret |
| `DATABASE_URL` (worker/API) | same as `STRUCTURED_BACKEND_URL` | same as `STRUCTURED_BACKEND_URL` | pgbouncer DSN (`ecle-pgbouncer-svc:5432`) — **NEVER point directly to PostgreSQL in Tier 3** |
| `VECTOR_BACKEND` | `qdrant` | `qdrant` | `qdrant` |
| `VECTOR_BACKEND_URL` | `http://localhost:6333` | `http://ecle-qdrant:6333` | Qdrant cluster URL |
| `TOPOLOGY_BACKEND` | `neo4j` | `neo4j` | `neo4j` |
| `TOPOLOGY_BACKEND_URL` | `bolt://localhost:7687` | `bolt://ecle-neo4j:7687` | managed Neo4j URL |
| `ARTIFACT_BACKEND` | `local` | `local` | `s3` or `azure` or `nfs` |
| `ARTIFACT_STORE_PATH` | `./ecle-data/repos` | `/app/ecle-data/repos` (volume) | S3 bucket / Azure container |
| `LANGUAGE_PACKS_PATH` | `./ecle-data/language_packs` | `/app/ecle-data/language_packs` | ConfigMap mount |
| `ECLE_MODELS_PATH` | `./ecle-data/models` | `/app/ecle-data/models` | PVC or init-container |
| `REDIS_URL` | not set (not needed) | `redis://ecle-redis:6379/0` | managed Redis URL |

Setting `ECLE_TIER=dev` auto-populates all Tier 1 defaults. Other vars override.

See SYS-ADR-0028 for the full `ecle-data/` and `ecle-logs/` directory layout.

---

## 4. `IArtifactStore` — mandatory for all artifact I/O

Every worker that reads or writes `facts.json` or `chunks.json` artifacts MUST use
`IArtifactStore`, never the filesystem directly.

```python
class IArtifactStore(ABC):
    def write(self, path: str, data: bytes) -> None:
        """Write bytes to the given logical path. Path is relative to the store root."""

    def read(self, path: str) -> bytes:
        """Read bytes from the given logical path. Raises ArtifactNotFoundError if missing."""

    def exists(self, path: str) -> bool:
        """Return True if the artifact at path exists."""

    def delete(self, path: str) -> None:
        """Delete artifact at path. No-op if not found."""
```

Implementations:
- `LocalArtifactStore` — Tier 1 and Tier 2; writes to `ARTIFACT_STORE_PATH` on local/volume filesystem
- `S3ArtifactStore` — Tier 3; uses `boto3`; path maps to S3 key
- `AzureBlobArtifactStore` — Tier 3; uses `azure-storage-blob`; path maps to blob name

Factory: `get_artifact_store()` reads `ARTIFACT_BACKEND` and returns the correct implementation.

**Banned in worker code:**
```python
# BANNED — hardcoded filesystem, breaks Tier 3
Path(artifact_path).write_bytes(json.dumps(facts).encode())
with open(artifact_path, "rb") as f:
    facts = json.load(f)
```

**Correct:**
```python
# CORRECT — works in all tiers
store = get_artifact_store()
store.write(artifact_path, json.dumps(facts).encode())
facts = json.loads(store.read(artifact_path))
```

---

## 5. Worker statelessness rules

A Celery worker is stateless when:
- All state it needs is in the event payload or read from a backend via an interface
- It writes results to a backend via an interface, then emits an event
- It holds no instance variables between `task()` invocations

```python
# CORRECT — stateless worker
@celery_app.task
def persist_facts_task(event: dict) -> None:
    db = get_structured_db()           # fresh from factory each call (or cached at module level — see §6)
    store = get_artifact_store()
    facts = json.loads(store.read(event["artifact_path"]))
    db.upsert_file_facts({...})
    emitter.emit(FILE_STORED, ...)

# BANNED — stateful worker; breaks with multiple replicas
class PersistFactsWorker:
    def __init__(self):
        self._pending_files = []       # shared mutable state across invocations

    def run(self, event):
        self._pending_files.append(event["file_id"])   # RACE CONDITION in Tier 3
```

---

## 6. Backend singleton pattern — correct caching

Backend connections (DB, vector store, artifact store) are expensive to create. They
MUST be cached at module level (not re-created per task call), but MUST NOT carry
mutable per-call state.

```python
# {src_dir}/workers/persist_facts.py — correct singleton pattern
from ecle.core.backends import get_structured_db, get_artifact_store
from ecle.events.emitter import EventEmitter
from ecle.core.config import settings

# Module-level singletons — created once per worker process
_db: IStructuredDB | None = None
_store: IArtifactStore | None = None
_emitter: EventEmitter | None = None

def _get_db() -> IStructuredDB:
    global _db
    if _db is None:
        _db = get_structured_db()
    return _db
```

This pattern is safe: each K8s pod / Docker container is a separate process with its
own module globals. No sharing between replicas.

---

## 7. Config rules per tier

### Tier 1 — `.env` file

```ini
ECLE_TIER=dev
# All other values auto-defaulted. Override as needed.
STRUCTURED_BACKEND_URL=./data/ecle.db
```

### Tier 2 — Docker Compose environment section

```yaml
environment:
  ECLE_TIER: compose
  STRUCTURED_BACKEND: postgresql
  STRUCTURED_BACKEND_URL: postgresql://ecle:secret@ecle-postgres:5432/ecle
  REDIS_URL: redis://ecle-redis:6379/0
  ARTIFACT_BACKEND: local
  ARTIFACT_STORE_PATH: /mnt/artifacts
```

Secrets (`STRUCTURED_BACKEND_URL` password, `REDIS_URL` password) come from
`docker-compose.override.yml` or Docker secrets — never committed to the repo.

### Tier 3 — Kubernetes ConfigMap + Secret

```yaml
# ConfigMap (non-secret)
ECLE_TIER: enterprise
STRUCTURED_BACKEND: postgresql
VECTOR_BACKEND: qdrant
ARTIFACT_BACKEND: s3

# Secret (base64-encoded, never in git)
STRUCTURED_BACKEND_URL: <managed PG DSN>
REDIS_URL: <managed Redis URL>
AWS_S3_BUCKET: ecle-artifacts-prod
AWS_REGION: eu-west-1
```

Workers reference Secrets via `envFrom.secretRef` — never hardcode secret names in code.

---

## 8. What "same code in all tiers" means for testing

| Test type | Tier used | What it validates |
|-----------|-----------|------------------|
| Unit tests | No tier (mocked interfaces) | Logic only; no backend |
| Integration tests (every PR) | Tier 2 (Docker Compose in CI) | Real PostgreSQL + ChromaDB + Redis |
| E2E tests (nightly) | Tier 2 (Docker Compose) | Full pipeline end-to-end |
| Tier 3 smoke test (release) | Tier 3 (K8s staging namespace) | Backend swap + horizontal scaling |

**Integration tests MUST use real Celery** (not `CELERY_TASK_ALWAYS_EAGER=true`) — async
bugs that hide in Tier 1 will surface here.

---

## 9. Review checklist (deployment-specific additions)

When reviewing any worker or MCP tool PR:

- [ ] No direct `open()` / `Path.read_bytes()` / `Path.write_bytes()` in worker logic — uses `IArtifactStore`
- [ ] No hardcoded paths — all paths from `settings`
- [ ] No `if ECLE_TIER == ...` branches in application code
- [ ] Worker function has no mutable instance state between invocations
- [ ] Backend obtained via factory function — not instantiated directly
- [ ] No secrets in code or config files that would be committed to git
- [ ] Worker tested with `CELERY_TASK_ALWAYS_EAGER=false` in at least one integration test
