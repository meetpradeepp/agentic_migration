﻿# HAR-C-0001 — Coding Standards

**Scope:** Every Python file in `src/` and `tests/`.
**Enforced by:** `ruff` (lint + format), `mypy` (types), code review checklist.
**Status:** Active

---

## 1. Principles (in priority order)

1. **SRP** — every module, class, and function has exactly one reason to change.
2. **DRY** — no copy-pasted logic; extract to a shared location on the second usage.
3. **SOLID** — dependency inversion for all backend integrations; open/closed for language packs and event handlers.
4. **KISS** — the simplest solution that satisfies the spec. Complexity must be justified in a comment.
5. **YAGNI** — do not build for hypothetical future requirements. If the spec doesn't require it, don't write it.

---

## 2. File structure

### Every Python file MUST start with

```python
"""
<module_name> — <one-line description of what this module does>.

Implements: <SPEC-NNNN> | <ADR-NNNN>   (reference at least one)
Reads:  <what data sources this module consumes>
Writes: <what data sources this module produces>
"""

from __future__ import annotations

# stdlib
# third-party
# ecle (absolute imports only — no relative imports)
```

Rules:
- `from __future__ import annotations` on **every** file — enables `X | None` on Python 3.11+.
- Module docstring is **mandatory** — minimum one sentence + spec/ADR reference.
- Import order: stdlib → third-party → ecle. Enforced by `ruff` isort.
- No relative imports (`from .foo import bar` is banned). Use `from ecle.module.foo import bar`.

### File naming

```
{src_dir}/<module>/<descriptive_name>.py    snake_case, no abbreviations
tests/unit/test_<module_name>.py           mirrors src/ structure
tests/integration/test_<flow_name>.py      named by the flow being tested
specs/<phase>/SPEC-NNNN-<name>.md          spec doc before implementation
```

---

## 3. Classes

### One class = one responsibility

```python
# CORRECT — focused, injectable, testable
class FactPersistenceService:
    """Writes a parsed facts.json artifact into the Structured Fact DB."""

    def __init__(self, db: IStructuredDB) -> None:
        self._db = db

    def persist(self, artifact_path: Path, file_id: str, repo_id: str) -> None:
        ...

# WRONG — multiple responsibilities, untestable
class FactService:
    def persist_and_embed_and_notify(self, ...): ...
```

Rules:
- **Dependencies injected via constructor** — no `global` state, no module-level singletons.
- **Class docstring mandatory** — one sentence describing the class's single purpose.
- **Public methods have docstrings** — describe *what*, not *how*.
- **Private helpers prefixed `_`** — no docstring required if the name is self-explanatory.
- **No inheritance unless genuinely polymorphic** — prefer composition over inheritance.
- **No class-level mutable state** — class variables must be immutable constants only.

### Backend classes MUST implement the declared interface

```python
class SQLiteStructuredDB:
    """SQLite implementation of IStructuredDB."""

    def insert(self, table: str, row: dict[str, Any]) -> None: ...
    def fetchall(self, sql: str, params: tuple | dict = ()) -> list[Row]: ...
    def close(self) -> None: ...
```

When `PostgreSQLStructuredDB` is added in Phase 4, it implements the same method signatures.
No ABC required in early phases — just match the interface exactly.

---

## 4. Functions

### Type hints on all public functions — no exceptions

```python
# CORRECT
def load_artifact(
    artifact_path: Path,
    file_id: str,
    commit_sha: str = "unknown",
) -> dict[str, Any]:

# WRONG — reviewer rejects
def load_artifact(artifact_path, file_id, commit_sha="unknown"):
```

### Return types

| Use case | Return type |
|---|---|
| Business results (vary per call) | `dict[str, Any]` |
| Validated data shared across modules | Pydantic `BaseModel` |
| Multiple named results | `@dataclass` |
| Nothing meaningful | `None` — never return `{}` or `True` as sentinel |
| Errors | Typed exceptions — never return error codes |

### Function length

- **Soft limit: 30 lines of logic** (excluding docstring and blank lines).
- If a function exceeds 30 lines, split it. Each extracted helper must have a clear name.
- Long functions are the primary driver of maintenance debt — reviewer must flag them.

### No side effects in constructors

```python
# WRONG — connects to DB in __init__
def __init__(self, db_path: str):
    self._conn = sqlite3.connect(db_path)  # side effect

# CORRECT — explicit connect() call
def __init__(self, db_path: str):
    self._db_path = db_path
    self._conn: sqlite3.Connection | None = None

def connect(self) -> None:
    self._conn = sqlite3.connect(self._db_path)
```

---

## 5. Error handling

### Typed, specific exceptions — never bare `except`

```python
# CORRECT
class ArtifactNotFoundError(Exception):
    """Raised when a facts.json artifact path does not exist."""

try:
    facts = json.loads(artifact_path.read_text())
except FileNotFoundError as exc:
    raise ArtifactNotFoundError(f"Artifact missing: {artifact_path}") from exc
except json.JSONDecodeError as exc:
    raise MalformedArtifactError(f"Invalid JSON in {artifact_path}: {exc}") from exc

# WRONG — swallows all errors
try:
    facts = json.loads(artifact_path.read_text())
except:
    return {}
```

Rules:
- **No bare `except:`** — always name the exception type(s).
- **No `except Exception as e: pass`** — if you catch it, handle it or re-raise with context.
- **Always chain with `from exc`** — preserves the original traceback.
- **Never use exceptions for flow control** — exceptions are for unexpected conditions.
- **Custom exception hierarchy** — every module declares its own exception base class.

---

## 6. Configuration — no magic numbers, no hardcoded values

```python
# CORRECT
from ecle.config import settings

batch_size = settings.EMBED_BATCH_SIZE        # from .env / pydantic Settings

# WRONG
for chunk in chunked(items, 128):             # magic number — where did 128 come from?
```

Rules:
- All tunable values come from `ecle.config.Settings` (Pydantic BaseSettings, reads `.env`).
- Constants that are truly fixed (e.g. schema version strings) live in `ecle/constants.py`.
- No secrets in code — environment variables only, never committed.

---

## 7. SQL — parameterised queries only

```python
# CORRECT
cursor.execute(
    "SELECT id FROM file_facts WHERE repo_id = ? AND is_current = 1",
    (repo_id,)
)

# WRONG — SQL injection risk, reviewer rejects immediately
cursor.execute(f"SELECT id FROM file_facts WHERE repo_id = '{repo_id}'")
```

This is a security contract, not a style preference. Violation is a **blocker** in security review.

---

## 8. Logging

```python
import logging
log = logging.getLogger(__name__)

# CORRECT — structured, with context
log.info("file.ir_produced processed", extra={"file_id": file_id, "fidelity": fidelity})
log.warning("used_fallback extractor", extra={"file": str(path), "ext": ext})

# WRONG — unstructured, no context
print("processing file")
log.info(f"processing {file_id}")
```

Rules:
- Use `logging.getLogger(__name__)` — never `print()` in production code.
- Pass structured context via `extra={}` — not in the message string.
- Log levels: `DEBUG` for internal state, `INFO` for pipeline milestones, `WARNING` for degraded paths, `ERROR` for failures that need attention.
- Never log secrets, PII, or raw SQL with user data.

---

## 9. Comments — just enough for a human to follow along

Code is read 10× more than it is written. Comments explain **why**, not **what**.
If the *what* needs explaining, the code is too complex — simplify it first.

### When to comment

```python
# CORRECT — explains a non-obvious decision
# SHA256 here instead of UUID4: must be stable across retries so the
# idempotency key is deterministic from the same inputs (see SYS-ADR-0001).
idempotency_key = hashlib.sha256(f"{event_type}:{entity_id}".encode()).hexdigest()
```

### Inline references are mandatory for non-trivial logic

```python
# CORRECT — future maintainer can trace this to the decision
# Offset committed only after durable write (SYS-C-0006, SYS-ADR-0013 §Offset commit rules).
self._consumer.commit(offsets=[offset], asynchronous=False)

# CORRECT — links to the spec that defines this behaviour
# AC-3: empty artifact_path → raise ArtifactNotFoundError (SPEC-0005 §Error handling)
if not artifact_path.exists():
    raise ArtifactNotFoundError(f"Missing: {artifact_path}")

# CORRECT — explains a bug fix with traceability
# Fix: handle duplicate events gracefully (SPEC-0006 §Deviations DEV-001)
existing = db.fetchone("SELECT id FROM file_facts WHERE file_id = ? AND is_current = 1", (file_id,))
```

Rules:
- **Every non-trivial branch** gets a comment citing the spec AC or contract rule that requires it
- **Every workaround or deviation** references the spec's `## Deviations` entry
- **Every ADR-driven decision** cites the ADR number in a comment (e.g. `# SYS-ADR-0013`)
- **Bug fixes** reference the bug ID or spec deviation (e.g. `# Fix: DEV-001`)
- Comments are for the **human maintainer** who will read this code in 6 months — write for them

---

## 10. Traceability — every line of code has a reason to exist

### Module-level traceability (mandatory)

Every source file starts with:
```python
"""<module> — <one-line description>. Implements: SPEC-NNNN | ADR-NNNN"""
```

Every test file starts with:
```python
"""test_<module> — <description>. Implements: SPEC-NNNN. Tests: <target>"""
```

### Inline traceability (required for non-obvious code)

| What | How to reference |
|---|---|
| Acceptance criteria implementation | `# AC-N: <brief description> (SPEC-NNNN)` |
| Error handling from spec | `# Error: <condition> (SPEC-NNNN §Error handling)` |
| Contract rule enforcement | `# Contract NN §M: <rule summary>` |
| ADR-driven design choice | `# ADR-NNNN: <why this approach>` |
| Bug fix | `# Fix: <what was wrong> (SPEC-NNNN §Deviations DEV-NNN)` |
| Enhancement | `# Enhancement: <what was added> (SPEC-NNNN §Deviations ENH-NNN)` |
| TODO (must reference a spec or issue) | `# TODO(SPEC-NNNN): <what needs doing>` |

**Banned:** Orphan TODOs without a spec/issue reference. `# TODO: fix this later` is rejected at review.

### Why this matters

A human reviewer or maintainer must be able to:
1. Read any function and know which spec/ADR requires it
2. Read any error handler and know which spec error table row it implements
3. Read any complex branch and know which AC or contract rule drives it
4. Trace any bug fix back to its root cause and spec deviation

---

## 11. Project Tooling

### Package manager: uv

```bash
uv sync --extra dev          # Install with dev dependencies
uv run ruff check src/       # Lint
uv run ruff format src/      # Format
uv run mypy {src_dir}/        # Type check
uv run pytest tests/         # Test
```

### Enforced by CI (pre-commit hooks)

| Hook | Contract | What it enforces |
|---|---|---|
| `ruff check` | HAR-C-0001 | Lint, imports, complexity, security, docstrings |
| `ruff format` | HAR-C-0001 | Consistent formatting |
| `mypy --strict` | HAR-C-0001 §4 | Type annotations on all public functions |
| `detect-secrets` | HAR-C-0004 §A11 | No secrets in code |
| `no-commit-to-branch` | HAR-C-0002 §7 | No direct commits to main |
| `consistency-check` | HAR-C-0001 §11 | Cross-ref counts/ranges match actual files |

### Lint safety — `ruff --fix` is restricted

**Rule: `ruff --fix --select TC` is BANNED.** Type-checking import migration (TC rules)
moves runtime imports into `TYPE_CHECKING` blocks. If the import is actually used at
runtime (e.g. `datetime.datetime.now(...)` in a function body), the auto-fix silently
creates a `NameError` that only surfaces at runtime, not at lint time.

Permitted auto-fix scopes:
```bash
ruff check --fix --select E,W      # whitespace / formatting only — safe
ruff format                        # formatting only — safe
ruff check                         # read-only review — always safe
```

Banned:
```bash
ruff --fix                         # too broad — may auto-migrate runtime imports
ruff check --fix --select TC       # type-checking migration — manual review required
ruff check --fix --select ALL      # implicit TC inclusion — banned for same reason
```

When `ruff check` reports a TC violation, fix it **manually**: verify the import is
genuinely annotation-only before moving it into `TYPE_CHECKING`. Add a `# noqa: TC003`
comment with justification if the import must stay at runtime despite the rule.
| `commit-msg-format` | HAR-C-0002 §4 | `<type>(<scope>): <desc> [Phase N]` |
| `pytest` | HAR-C-0003 | Tests pass before commit |

### Configuration

All tool config lives in `pyproject.toml` — single file, no scattered config.


# CORRECT — explains why a guard exists
# DefaultPack sets used_fallback=True; confidence ceiling is 0.5, not the
# pack's declared fidelity. Must be checked before propagating ceiling.
if facts.get("used_fallback"):
    ceiling = 0.5

# CORRECT — explains a non-obvious limit
# ef_search=64 balances recall (~0.97) vs latency (~3ms); higher values
# approach exact search but exceed the 2s FACT hard timeout at 1M vectors.
results = collection.query(vector, top_k=top_k, ef_search=64)
```

```python
# WRONG — restates the code; adds no value; delete it
x = x + 1  # increment x by 1

# WRONG — describes what, not why
if used_fallback:  # check if used_fallback is True
    ceiling = 0.5
```

### Block comments — use sparingly, only for multi-step logic

```python
def _build_neighbourhood_hash(file_id: str, db: IStructuredDB) -> str:
    # Step 1: collect all files within 2 hops in the topology graph.
    # These are the files whose changes can degrade contextual_accuracy
    # for this file (see 05-confidence-contract.md §contextual_accuracy).
    neighbours = db.get_neighbours(file_id, max_hops=2)

    # Step 2: sort deterministically so the hash is stable regardless
    # of the order the topology graph returns edges.
    sorted_pairs = sorted(
        (n.target_file, n.content_hash) for n in neighbours
    )

    return hashlib.sha256(str(sorted_pairs).encode()).hexdigest()
```

### TODO comments — allowed only with a ticket reference

```python
# TODO(ECLE-142): implement content_hash skip check in Phase 2
# (see 13-incremental-ingestion-contract.md §3, parse_repo row)
```

A `TODO` without a ticket reference will be flagged in review. It is not a blocker,
but it MUST be converted to a ticket before the PR merges.

### What is banned

| Banned | Reason |
|--------|--------|
| Commented-out code | Use `git revert` — dead code confuses readers |
| Section dividers (`# ===`) | Code organisation is done by splitting into functions/modules, not decorative lines |
| `# type: ignore` without explanation | Must include a one-line reason immediately after |
| Docstrings on private helpers when the name is self-explanatory | Over-documentation noise |

---

## 10. Testing standards (summary — full detail in `03-testing-contract.md`)

- Every public function has at least one unit test.
- Tests are in `tests/unit/test_<module>.py` — mirroring `src/` exactly.
- Test names: `test_<function>_<scenario>` e.g. `test_persist_raises_on_missing_artifact`.
- No test depends on another test — each test is fully isolated.
- Use `pytest` fixtures for shared setup — never `setUp`/`tearDown` class methods.

---

## 11. Code review checklist (reviewer applies to every PR)

- [ ] Module docstring present with spec/ADR reference
- [ ] `from __future__ import annotations` present
- [ ] All public functions/methods fully type-hinted
- [ ] No bare `except:` or silent swallowing of exceptions
- [ ] No f-string SQL queries
- [ ] No magic numbers (all values from config or constants)
- [ ] No `print()` in production code
- [ ] No global mutable state
- [ ] Class has single clear responsibility
- [ ] Function ≤ 30 lines of logic
- [ ] No copy-paste (DRY — extracted if used twice)
- [ ] No relative imports
- [ ] Test file exists for new module
- [ ] Comments explain *why*, not *what*; no commented-out code; TODOs have ticket refs
