﻿# HAR-C-0003 — Testing Contract

**Scope:** All code in `src/` and `tests/`.
**Enforced by:** CI Stage 1 (unit), CI Stage 2 (integration), nightly eval suite.
**Status:** Active
**Amended by:** HAR-ADR-0020 §1 (add inventory-diff test type for ENUMERATIVE assertions), HAR-ADR-0022 (add T-M mechanism tests and T-C contract tests as mandatory typed categories)

---

## 1. Test pyramid

```
         ┌──────────────┐
         │     E2E      │  10% — full pipeline, docker-compose, nightly only
         └──────────────┘
       ┌──────────────────┐
       │   Integration    │  20% — cross-worker, real SQLite/ChromaDB, every PR
       └──────────────────┘
     ┌──────────────────────┐
     │      Unit Tests      │  70% — single class/function, no I/O, every PR
     └──────────────────────┘
```

---

## 2. Coverage requirements

| Code category | Minimum line coverage | Rationale |
|---|---|---|
| Any new code | 80% | Baseline quality |
| Interface definitions, base schemas | 95% | These are contracts — must be fully specified |
| Grounding verifiers | 100% | Safety-critical — incorrect verification = hallucination passes |
| Event payload validation | 95% | Malformed events cause silent data loss |
| Existing code | No regression | Coverage can only increase, never decrease |

**Per-subtask gate (G4):** After each `implement` subtask completes, the coder MUST run:
```bash
pytest --cov=<new_module_path> --cov-report=term-missing --fail-under=80
```
Sub-80% blocks the subtask. Missing tests must be written in the same subtask before
moving to the next one. This prevents coverage gaps from accumulating and being
discovered only at G5.

---

## 3. Unit test rules

- **Write tests first** — tests for a spec are written before any implementation code. All tests MUST be committed (failing) before the first `feat(...)` commit on the branch (see `02-sdlc-contract.md` §4).
- **Source of truth** — every test case in `## Tests required` (all three categories: AC, T-M, T-C) and every `## Acceptance criteria` example in the spec MUST have a corresponding test function. Untested entries = unfinished implementation.
- **Location:** `tests/unit/test_<module_name>.py` — mirrors `{src_dir}/` exactly.

---

## 3a. Mechanism tests (T-M) — mandatory for every `mechanism:` Constraints entry

Mechanism tests verify **which code path executed**, not just what output was produced.
They are the only test type that catches the "spec said use X, code uses Y, both produce
identical output" class of bug.

- **Trigger:** Required when the spec's `## Constraints` has any `mechanism:` entry.
- **Format:** One T-M test per `must_call` entry.
- **Implementation:** Use a call-site spy or mock to assert the named callable was invoked
  and the excluded callable was NOT invoked. Outcome-only assertions (asserting the return
  value) do NOT satisfy a T-M requirement.
- **Naming:** `test_<function>_uses_<must_call>_not_<must_not_call>`
- **Example:**
  ```python
  def test_write_handler_uses_sync_write_v3_not_v2(mocker):
      """T-M1: PIN sync_write_v3; must_not_call sync_write_v2."""
      spy_v3 = mocker.patch("module.db.sync_write_v3", wraps=db.sync_write_v3)
      spy_v2 = mocker.patch("module.db.sync_write_v2")
      handle_write(payload)
      spy_v3.assert_called_once()
      spy_v2.assert_not_called()
  ```
- **Language note:** The mechanism is language-agnostic. Use the spy/mock facility of
  the project's test framework (pytest-mock, jest.spyOn, Mockito.verify, etc.).

---

## 3b. Contract tests (T-C) — mandatory for every `config:` Constraints entry

Contract tests verify **configuration values match spec**. They catch the class of bug where
the correct callable is used but with wrong configuration (wrong timeout, wrong retry count,
wrong pool size).

- **Trigger:** Required when the spec's `## Constraints` has any `config:` entry.
- **Format:** One T-C test per `config:` entry.
- **Implementation:** Assert the config object field has the exact value stated in the spec.
  Do not assert the outcome of using that config — assert the config value itself.
- **Naming:** `test_<module>_config_<key>_is_<value>`
- **Example:**
  ```python
  def test_writer_config_retry_max_attempts_is_3():
      """T-C1: config retry.max_attempts == 3."""
      config = WriterConfig()
      assert config.retry_max_attempts == 3
  ```

---

## 3c. Static grep rule (enforced by coverage script + CI)

For every `must_not_call` symbol in `## Constraints`, the CI coverage script greps the
source files for that symbol. If the symbol appears in any code path (not just the hot path),
the build fails. This catches the "import-but-not-call" bug that mechanism tests cannot
detect (tests only exercise the path the test invokes, not all code paths).
- **Name format:** `test_<function>_<scenario>` e.g. `test_persist_raises_on_missing_artifact`.
- **Isolation:** No test depends on another. No shared mutable state between tests.
- **No I/O:** Unit tests MUST NOT touch the filesystem, network, or a real DB.
  Use in-memory SQLite (`":memory:"`), `tmp_path` fixtures, and mocked interfaces.
- **Speed:** Each unit test MUST complete in < 100ms.
- **Deterministic:** Same input → same output, always. No random seeds, no timestamps without mocking.

```python
# CORRECT — isolated, no I/O, fast
def test_pack_registry_returns_default_for_unknown_extension(tmp_path):
    registry = LanguagePackRegistry(packs_dir=tmp_path)
    pack = registry.get(".xyz")
    assert pack.manifest["metadata"]["language_id"] == "default"
    assert pack.manifest["fast_extraction"]["fidelity"] == "HEURISTIC"

# WRONG — hits real filesystem, slow, non-deterministic
def test_pack_registry():
    registry = LanguagePackRegistry(packs_dir=Path("language_packs/"))
    assert registry.get(".py") is not None
```

---

## 3a. One canonical test file per source module (anti-bloat rule)

Each source file under `{src_dir}/` MUST map to exactly **one** test file. Splitting
tests for the same module across multiple files (e.g. `test_worker.py`,
`test_worker_infrastructure.py`, `test_worker_base.py` all testing `workers/base.py`)
is banned — it causes:
- Duplicate fixture setup and mock boilerplate
- Invisible coverage gaps (each file shows partial coverage; gaps hide between them)
- 3× the test-maintenance burden when the source module changes

**Rule:** `tests/unit/test_<module_name>.py` is the single authoritative file for
`{src_dir}/<module>/<name>.py`. When a spec extends a module, tests are added to the
existing `test_<module_name>.py`, not to a new file.

**Exceptions (must be listed in the spec's `## Tests required` section):**
- Integration tests for a flow live in `tests/integration/test_<flow_name>.py`
  (named by the flow, not the module) — this is the only permitted split.
- A dedicated `test_<module_name>_hooks.py` is allowed **only** when the hook engine
  for that module has its own spec (`Implements: SPEC-NNNN`) — the spec must be cited
  in the file's module docstring.

**Reviewer enforcement:** At G5, the reviewer checks that no PR adds a second unit
test file for a module that already has one. New test file = block unless the spec
explicitly authorises it with a reason.

---

## 4. Integration test rules

- **Location:** `tests/integration/test_<flow_name>.py` — named by the flow being tested.
- Use real SQLite (`:memory:` or temp file), real ChromaDB (temp dir), real Celery workers (eager mode).
- Docker Compose services (Neo4j, PostgreSQL) available in CI Stage 2.
- Must cover the full event chain for the flow being tested, not just one worker.
- Each integration test MUST leave no side effects (clean up DB/files in teardown).

---

## 5. Test properties by component type

| Property | Deterministic workers (parse, persist, embed) | Event-driven flows |
|---|---|---|
| **Deterministic** | Required — same input → same output | Required — same events → same final state |
| **Idempotent** | Required — processing the same event twice = same DB state | Required |
| **Fast** | < 100ms per unit test | < 5s per integration test |
| **Isolated** | No external service | Uses real backends in Docker |

---

## 6. Eval suites — hard CI gates

These are **not regular tests**. They are behavioural contracts.
Failure means the system is fundamentally broken. A failing eval blocks release.

| Eval | What it tests | Pass criteria | CI stage |
|---|---|---|---|
| `eval_fallback_coverage` | DefaultPack fires for unknown extensions | `used_fallback=true`, fidelity=HEURISTIC in event | Every PR |
| `eval_idempotent_ingest` | Processing same event twice = same DB state | Row counts identical; no duplicates | Every PR |
| `eval_fidelity_ceiling` | HEURISTIC fidelity propagates to confidence ceiling | `confidence_ceiling ≤ 0.6` on HEURISTIC results | Every PR |
| `eval_grounding_coverage` | All query results carry complete lineage chains | 0 `lineage.incomplete` events on nightly corpus | Nightly |
| `eval_staleness_honesty` | No stale answers served as fresh | `knowledge_current_as_of` always present | Nightly |
| `eval_event_chain_complete` | All events in a full ingest chain are emitted | All expected event types appear in log | Every PR |
| `eval_srp_isolation` | No worker touches another worker's domain | Checked via event payload inspection, not direct calls | Every PR |
| `eval_schema_conformance` | All `facts.json` artifacts conform to base schema | JSON Schema validation pass rate = 100% | Every PR |

---

## 7. Performance benchmarks — enforced in CI

| Operation | Target | Gate |
|---|---|---|
| `pack.sanitize()` per file | < 10ms | CI fails if exceeded on reference corpus |
| `tree_sitter.Parser().parse()` per file | < 10ms | CI fails if exceeded |
| `pack.fast_extractor.extract()` per file | < 50ms | CI fails if exceeded |
| Structured DB insert (full file row set) | < 100ms | CI fails if exceeded |
| ANN search (Layer 1, top-10) | < 50ms | CI fails if exceeded |
| GraphQL query (structured, simple) | < 200ms | CI fails if exceeded |
| Regression tolerance | < 10% degradation from baseline | Alert + block if exceeded |

---

## 8. Fixture strategy

```
Development:    run tests against real backends (local Docker)
CI Stage 1:     in-memory SQLite + ChromaDB temp dir — no Docker needed
CI Stage 2:     Docker Compose (PostgreSQL, Neo4j, Qdrant)
Nightly:        full E2E with live data fixtures
```

---

## 9. What to test (by layer)

Start from the spec, not from the implementation. For each component:
1. Copy every item from `## Tests required` into the test file as a `def test_...` stub (all failing).
2. Copy every item from `## Acceptance criteria` into the test file as a parameterised or named test.
3. Then write implementation until all pass.

| Layer | What to unit-test | What to integration-test |
|---|---|---|
| Language pack | `sanitize()`, `extract()` on known fixtures; fidelity field; fallback fires | Full parse_repo worker run on fixture repo |
| persist_facts | DB rows written correctly; idempotency; partial failure handling | file.ir_produced → file.stored event chain |
| build_graph | Neo4j MERGE calls; edge types; idempotency | file.ir_produced → graph.updated chain |
| chunk_file | Chunk boundaries; token budget respected; artifact written | file.stored → file.chunked chain |
| batch_embed | Vector shape; slim payload; Layer 1/2 correctness | file.chunked → file.embedded chain |
| GraphQL query | Routing decision (structured vs vector vs graph) | End-to-end query returning FACT envelope |
| MCP tools | Tool response shape; FACT envelope present | Full tool call → grounded response |
