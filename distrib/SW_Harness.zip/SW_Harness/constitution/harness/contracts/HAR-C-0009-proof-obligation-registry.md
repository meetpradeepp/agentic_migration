﻿# HAR-C-0009 — Proof Obligation Registry Contract

**Scope:** All constitution contracts under `constitution/system/contracts/` and `constitution/harness/contracts/`; all harness scripts under `constitution/harness/scripts/`; all registry files under `constitution/harness/registries/`.
**Enforced by:** `check_rule_classification.py` (CI gate), `run_proof_dispatcher.py` (G4/G5), `report_coverage.py` (G6).
**Status:** Active
**Implements:** HAR-ADR-0020
**Related:** HAR-C-0002 §6 (G5 gate check), HAR-C-0003 §1 (ENUMERATIVE test type), SYS-C-0010, SYS-C-0006

---

## 1. Purpose

This contract defines the **Proof Obligation Registry** — the harness subsystem that
makes every contract rule's verification status explicit, machine-readable, and
auditable. Every rule in every constitution contract must either have a registered proof
mechanism or carry an explicit `UNVERIFIED` or `HUMAN_REVIEW` status.

**Core principle:** Citation is not verification. A spec that cites SYS-C-0010 is not
compliant with SYS-C-0010 unless a registered proof mechanism has confirmed every
assertion in SYS-C-0010 is reflected in the artifacts. This contract closes the gap.

---

## 2. Five Contract Classes

Every assertion extracted from any constitution contract belongs to exactly one class:

| Class | Definition | Primary proof family |
|---|---|---|
| `ENUMERATIVE` | Closed inventories: columns, fields, event payload keys, config keys, exported names, required indexes | Inventory diff against artifact (alembic DDL, schema YAML, config file) |
| `STRUCTURAL` | Architecture rules: no worker-to-worker calls, Kafka-only communication, single table ownership, no global mutable state | Static analysis / AST pattern match / import graph |
| `BEHAVIORAL` | Runtime invariants: idempotency, retry-safety, fault tolerance, ordering guarantees | Property tests / mutation tests / scenario tests |
| `QUALITY` | Measurable thresholds: line coverage ≥80%, P95 latency <1s, DB insert <100ms | Benchmark / pytest-cov / observability assertions |
| `SEMANTIC` | Correctness of computed outputs: find table owners, compute blast radius, resolve cross-repo links | Golden dataset eval corpus / reference outputs |

A compound rule that requires two classes MUST be decomposed into two atomic assertions
before being registered. One assertion = one class = one proof strategy.

---

## 3. Three Registries

### 3.1 Proof Strategies Registry

**File:** `constitution/harness/registries/proof-strategies.yaml`

Defines the closed enumeration of reusable proof strategy definitions. No proof strategy
may be referenced in an assertions file unless it appears here. Schema per entry:

```yaml
- id: PS-NNNN            # PS-0001 through PS-0012
  name: "<short name>"
  class: ENUMERATIVE | STRUCTURAL | BEHAVIORAL | QUALITY | SEMANTIC
  description: "<one sentence>"
  payload_schema:        # fields required in assertion proof_payload
    - field_name: "<name>"
      type: "<str|list|dict>"
      required: true|false
      description: "<purpose>"
  executor_script: "constitution/harness/scripts/<script>.py"
```

**Initial strategies at bootstrap:**

| ID | Name | Class | Executor |
|---|---|---|---|
| `PS-0001` | Inventory Diff | ENUMERATIVE | `check_contract_fidelity.py` |
| `PS-0002` | AST Pattern Match | STRUCTURAL | `check_consistency.py` |
| `PS-0003` | Spec Presence Check | STRUCTURAL | `check_spec_frontmatter.py` |
| `PS-0004` | AC Test Coverage | STRUCTURAL | `check_spec_test_coverage.py` |
| `PS-0005` | Phase Gate Check | QUALITY | `check_phase_gate.py` |
| `PS-0006` | Eval Suite Ref | BEHAVIORAL | _(stub — populated when eval harness matures)_ |
| `PS-0007` | Human Review | — _(marker; no class — `HUMAN_REVIEW` is a proof status, not a contract class; `class` field omitted for this entry)_ | _(no executor — reviewed at G2/G5)_ |
| `PS-0008`–`PS-0012` | Reserved | — | _(stub — allocated as QUALITY and SEMANTIC strategies mature)_ |

### 3.2 Evidence Providers Registry

**File:** `constitution/harness/registries/evidence-providers.yaml`

Maps each VM.N verification mechanism to its executor script and invocation signature.
Schema per entry:

```yaml
- vm_id: VM.N
  description: "<what this check proves>"
  script_path: "constitution/harness/scripts/<script>.py"
  invocation: "python {script_path} <args>"
  proof_strategy_ids:    # which PS-NNNN strategies this provider executes
    - PS-NNNN
```

**Registered evidence providers:**

| VM ID | Description | Script | Proof Strategies |
|---|---|---|---|
| VM.1 | AC→test stub coverage | `check_spec_test_coverage.py` | PS-0004 |
| VM.2 | T-ID→test stub coverage | `check_spec_test_coverage.py` | PS-0004 |
| VM.3 | Phase gate exit criteria | `check_phase_gate.py` | PS-0005 |
| VM.4 | Pipeline metrics | `pipeline_metrics.py` | _(informational)_ |
| VM.5 | Contract fidelity — ENUMERATIVE inventory diff | `check_contract_fidelity.py` | PS-0001 |

### 3.3 Assertions Registry

**Directory:** `constitution/harness/registries/assertions/`

One YAML file per contract (e.g., `assertions/SYS-C-0010.yaml`). Each file lists the
atomic assertions extracted from that contract. Schema per assertion entry:

```yaml
- assertion_id: <CONTRACT-ID>-A-NNN   # e.g. SYS-C-0010-A-001
  statement: "<exact prose of the atomic rule>"
  contract_type: ENUMERATIVE | STRUCTURAL | BEHAVIORAL | QUALITY | SEMANTIC
  proof_strategy_id: PS-NNNN          # null if proof_status is UNVERIFIED
  proof_status: VERIFIED | PARTIALLY_VERIFIED | HUMAN_REVIEW | UNVERIFIED
  proof_payload:                       # strategy-specific; must match payload_schema of proof_strategy_id
    {}                                 # empty dict when proof_status is UNVERIFIED
  proof_gap: ""                        # required non-empty string when proof_status is PARTIALLY_VERIFIED
```

**Hard rules:**
1. Every assertion must have a `proof_status` — no silent omissions. `check_rule_classification.py` exits 1 if any entry lacks this field.
2. `proof_payload` must satisfy the `payload_schema` of the referenced `proof_strategy_id` when `proof_status` is `VERIFIED` or `PARTIALLY_VERIFIED`.
3. `proof_gap` is mandatory and non-empty when `proof_status` is `PARTIALLY_VERIFIED`.
4. `proof_strategy_id` must be null when `proof_status` is `UNVERIFIED`.
5. `proof_strategy_id` must be `PS-0007` when `proof_status` is `HUMAN_REVIEW`.

---

## 4. Proof Status Enum

| Status | Meaning | CI behaviour |
|---|---|---|
| `VERIFIED` | Active proof mechanism registered and passing | Dispatcher runs; exit 1 on FAIL |
| `PARTIALLY_VERIFIED` | Proof mechanism exists but has a declared gap | Dispatcher runs; `proof_gap` surfaced in coverage report as a known limitation |
| `HUMAN_REVIEW` | Not mechanically provable; reviewed at G2/G5 | No dispatcher invocation; reviewer must cite this assertion in review checklist |
| `UNVERIFIED` | No proof mechanism; aspirational or deferred | Flagged in coverage report; does not block CI |

`HUMAN_REVIEW` and `UNVERIFIED` are first-class statuses — not failures. Their presence
in the coverage report is honest accounting, not a gate blocker.

---

## 5. Dispatcher Protocol

`run_proof_dispatcher.py` runs as part of the G4 and G5 gate checklists for any task
that cites a contract with a registered assertions file.

**Invocation:**
```bash
python constitution/harness/scripts/run_proof_dispatcher.py \
  --contract SYS-C-0010 \
  --artifact {migration_dir}/
```

**Execution order per assertion:**
1. Load assertion entry from `assertions/<contract-id>.yaml`
2. If `proof_status` is `UNVERIFIED` → skip (log as SKIP)
3. If `proof_status` is `HUMAN_REVIEW` → skip (log as HUMAN_REVIEW — requires reviewer attestation)
4. Look up `proof_strategy_id` in `proof-strategies.yaml` → resolve `executor_script`
5. Look up `vm_id` in `evidence-providers.yaml` → resolve `invocation` template
6. Execute: substitute `{script_path}` and `{assertion_id}` and artifact path
7. Collect exit code: 0 = PASS, 1 = FAIL, 2 = ERROR
8. Emit per-assertion result to stdout and to `<workspace_path>/reviews/dispatcher-<date>.json`

**Exit code:** 0 if all VERIFIED/PARTIALLY_VERIFIED assertions PASS; 1 if any FAIL; 2 if any ERROR.

---

## 6. Coverage Report

`report_coverage.py` aggregates all assertion files under `constitution/harness/registries/assertions/`
and emits a coverage matrix. Invoked at G6 and on-demand.

**Required output format:**

```
Proof Obligation Coverage — <YYYY-MM-DD>

ENUMERATIVE:     N verified / M total  (X%)
STRUCTURAL:      N verified / M total  (X%)
BEHAVIORAL:      N verified / M total  (X%)
QUALITY:         N verified / M total  (X%)
SEMANTIC:        N verified / M total  (X%)
HUMAN_REVIEW:    N rules               (always 100% — reviewed by definition)
UNVERIFIED:      N rules               (aspirational / deferred)

Overall verified: N / M (X%)
```

`VERIFIED + PARTIALLY_VERIFIED` counts as verified in the numerator.
`UNVERIFIED` rules are shown in the denominator — they cannot be excluded to inflate the percentage.

---

## 7. CI Gate — check_rule_classification.py

`check_rule_classification.py` runs in CI on every PR that modifies any file under
`constitution/`. It validates:

1. Every assertion entry in every `assertions/*.yaml` file has a non-null `proof_status`
   drawn from the four-value enum.
2. Every `proof_strategy_id` referenced in an assertions file exists in `proof-strategies.yaml`.
3. Every `PARTIALLY_VERIFIED` assertion has a non-empty `proof_gap`.
4. No assertion has both `proof_status: UNVERIFIED` and a non-null `proof_strategy_id`.

**Exit code:** 0 = all checks pass; 1 = any violation found. Violation blocks merge.

---

## 8. Phase 1 Bootstrap — Mandatory Assertions Files

The following four contracts MUST have assertions files created as part of the initial
HAR-ADR-0020 implementation task. All other contracts default to absent (treated as
fully UNVERIFIED until a future task registers their assertions).

| Contract | File | Priority rationale |
|---|---|---|
| `SYS-C-0010` | `assertions/SYS-C-0010.yaml` | First ENUMERATIVE target; closes `function_facts` column gap (the incident trigger) |
| `SYS-C-0006` | `assertions/SYS-C-0006.yaml` | Event pipeline ENUMERATIVE assertions; high-value, directly testable with PS-0001 |
| `HAR-C-0002` | `assertions/HAR-C-0002.yaml` | SDLC process rules; establishes STRUCTURAL and HUMAN_REVIEW pattern |
| `HAR-C-0003` | `assertions/HAR-C-0003.yaml` | Testing contract; establishes first QUALITY class entries |

---

## 9. Contract Authoring Rules for New Assertions

When a new constitution contract is written or an existing one is amended:

1. The author MUST identify every enumerable rule in the contract.
2. For each rule, extract an atomic assertion and add it to `assertions/<contract-id>.yaml`.
3. Assign `contract_type` from the five-class taxonomy.
4. Assign `proof_status`: if a PS-NNNN strategy can prove it, assign `VERIFIED` or `PARTIALLY_VERIFIED`; if not, assign `HUMAN_REVIEW` or `UNVERIFIED`.
5. A PR that adds a contract rule without a corresponding assertions entry MUST include the corresponding assertions entry in the same commit. `check_rule_classification.py` validates existing YAML entries but does not parse contract Markdown to detect new rules — enforcement of this step is by code review at G2.
6. Rule: if you cannot assign a `contract_type`, the rule is too vague to be a contract assertion — rewrite it or defer it as `UNVERIFIED` with a note in `proof_gap`.

---

## 10. Amendment Index

| Amendment | Changes |
|---|---|
| _(initial)_ | HAR-ADR-0020 — establishes this contract |
