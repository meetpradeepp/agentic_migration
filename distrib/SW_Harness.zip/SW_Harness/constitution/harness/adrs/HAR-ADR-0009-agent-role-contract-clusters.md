﻿## HAR-ADR-0009: Agent-Role Contract Cluster Loading

**Status:** Accepted
**Date:** 2026-05-21
**Deciders:** Lead Engineer, Architecture Review
**Supersedes:** —
**Superseded by:** —
**Amends:** HAR-ADR-0002 (agent token optimisation — extends digest-first tier with role-scoped loading)
**Amended by:** —
**FACT impact:**
- Fast: `neutral` — no runtime path affected; agent context load is a development-time concern
- Accurate: `improves` — agents load only contracts relevant to their role, reducing noise and irrelevant-rule violations
- Complete: `neutral` — validator and spec-reviewer still load full contracts; no compliance gap
- Trustworthy: `improves` — cluster manifest is the single source of truth for which contracts govern each role; drift between role and loaded rules is now detectable

---

### Context

HAR-ADR-0002 introduced the digest-first tier: agents load `.github/memory/constitution-digest.md`
(a compact digest of all 21 contracts) instead of full contract text. This saved ~60% tokens
compared to full-contract loading. However, all agents still load the same 3000+-line mega-digest
regardless of role. A coder only needs contracts 01, 02, 03, 09, 10, 15, and 18; loading
contracts 12 (Embedding), 19 (CPG tier), 20 (Semantic Rule Engine), and 21 (Ontology) adds
irrelevant noise with zero benefit. Additionally, `generate_micro_index.py` already produces
individual per-contract digest files in `.github/memory/contract-digests/` — 21 files covering
exactly one contract each — but no agent currently loads from them. The infrastructure exists;
it is simply not wired. Two further quality gaps motivate this ADR: (1) the spec-writer's FACT
checklist item requires only "even one sentence" of FACT impact, which consistently fails to
prevent incomplete FACT envelope definitions that cause G5 failures; and (2) the adr-writer's
post-ADR actions do not invoke `generate_micro_index.py`, so individual contract digests may
be stale after an ADR amends a contract.

---

### Decision

We will replace mega-digest loading with role-scoped contract cluster loading. Each agent will
load only the contract digest files that are relevant to its role, as defined in a canonical
cluster manifest at `.github/memory/agent-clusters.md`. Validator and spec-reviewer are
exempt and continue loading full contract text as the constitution's safety net. As part of
this change, we will also tighten the spec-writer FACT checklist rule and add
`generate_micro_index.py` invocation to the adr-writer post-ADR actions.

**Mechanism:**

- `.github/memory/agent-clusters.md` is the **single source of truth** for cluster membership.
  It lists, for each agent, the exact digest files to load from `.github/memory/contract-digests/`.
- Agents replace `Read .github/memory/constitution-digest.md` in their context-loading sections
  with `Read your cluster digest files as listed in .github/memory/agent-clusters.md`.
- The mega-digest (`.github/memory/constitution-digest.md`) is **not deprecated** — it remains
  the target of manual adr-writer updates and serves as a fallback for ad-hoc lookups, but is
  no longer the primary agent load path.
- `generate_micro_index.py` is added to adr-writer post-ADR mandatory actions (step 6), ensuring
  individual contract digests stay in sync with the mega-digest after each ADR amendment.
- The spec-writer FACT checklist item is strengthened: the spec must include a minimum FACT
  envelope sketch (fast/accurate/complete/trustworthy keys with at least one bullet each).

**Cluster assignments:**

| Cluster | Contract digest files | Agents |
|---------|----------------------|--------|
| `baseline` | 01, 02, 09, 10 | (shared minimum — included in every cluster below) |
| `authoring` | baseline + 03, 04, 05, 06, 07, 08, 11, 15, 17 | spec-writer, spec-patcher, adr-writer |
| `implementation` | baseline + 03, 15, 18 | coder, tester, refactor |
| `planning` | baseline + 03, 17 | planner |
| `review` | baseline + 03, 15, 18 | code-reviewer |
| `release` | baseline + 17 | release-manager |
| `governance` | ALL 21 full contracts (unchanged) | validator, spec-reviewer |

Phase 2–4 domain contracts (SYS-C entries covering domain-specific features such as
embeddings, incremental ingestion, deployment, graph layers, and ontology enrichment)
are not needed by coder, planner, or release-manager in Phase 1 work and are omitted
from those clusters. Spec-writer and adr-writer include
contracts 04–08, 11 because they write specs that span all phases and must verify FACT,
confidence, grounding, staleness, language pack, and MCP conformance.

---

### Consequences

**Positive:**

- Token reduction: coder/planner/tester load ~7 × 20-line digests (~140 lines) vs 3000+ line mega-digest — approximately 95% reduction for contract context.
- Agents are guided by rules relevant to their role; irrelevant Phase 4 contracts cannot cause false positives or confusion.
- `agent-clusters.md` makes cluster membership explicit and auditable.
- Stale individual digest detection is now wired (adr-writer step 6 + freshness gate).
- FACT checklist tightening prevents incomplete envelope specs reaching the coder.

**Negative / Trade-offs:**

- Agents must be kept in sync with `agent-clusters.md` when new contracts are added. Failure to update the manifest silently excludes a new contract from an agent's context.
- If a cluster is mis-specified (e.g. a relevant contract is excluded), the agent enforces weaker rules. Validator (full-contract) remains the backstop.
- The mega-digest and individual digests are now maintained by two separate paths (manual adr-writer update vs. script). If `generate_micro_index.py` is not run after an ADR, individual digests will diverge from the mega-digest.

**Neutral / Operational notes:**

- `scripts/check_digest_freshness.py` should be verified or extended to assert that each `contract-digests/*.md` file is consistent with its source contract.
- When a new contract is added to the constitution, the cluster manifest must be updated as part of the ADR that creates the contract.
- Discovery agent and orchestrator do not have domain-specific contract clusters; they use the mega-digest for broad orientation. This is intentional.

---

### Alternatives Considered

| Alternative | Why Rejected |
|-------------|-------------|
| Keep mega-digest for all agents | No functional improvement; known token waste continues; irrelevant contracts remain in agent context indefinitely |
| Per-agent full contract loading (no digests) | Highest accuracy but highest token cost; defeats HAR-ADR-0002; impractical for 11 agents × 21 contracts |
| Dynamic cluster selection by task type at runtime | Adds orchestrator complexity with marginal benefit; the role-to-cluster mapping is stable enough to be static |
| Deprecate mega-digest immediately | Too disruptive; adr-writer still needs it as the manual-update target; ad-hoc queries need a single-file reference |

---

### Compliance

- Contract: `constitution/harness/contracts/HAR-C-0002-sdlc-contract.md` (spec process conformance)
- Contract: `constitution/system/contracts/SYS-C-0001-fact-contract.md` (FACT envelope completeness enforced at spec authoring)
- Cluster manifest: `.github/memory/agent-clusters.md`
- Freshness gate: `scripts/check_digest_freshness.py`
- Eval: `eval_agent_context_load` (verify no agent loads mega-digest directly after this ADR)
