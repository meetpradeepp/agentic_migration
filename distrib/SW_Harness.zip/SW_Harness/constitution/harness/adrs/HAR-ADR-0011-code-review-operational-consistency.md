﻿## HAR-ADR-0011: Code Review Operational Consistency Checks

**Status:** Accepted
**Date:** 2026-05-30
**Deciders:** Lead Engineer, Architecture Review
**Supersedes:** —
**Superseded by:** —
**Amends:** HAR-C-0002 §6 (adds 4 sub-bullets to the 10-point review checklist); `.github/agents/code-reviewer.agent.md` (mirrors the same sub-bullets in the detailed 9-point checklist)
**Amended by:** —
**FACT impact:**
- Fast: `neutral` — no runtime impact; all new checks are review-time only
- Accurate: `improves` — catches `Field(description=)` / validator mismatches and YAML env var comment errors before they mislead operators in production
- Complete: `improves` — migration head drift allows integration tests to silently pass on stale state; the new check closes that gap
- Trustworthy: `improves` — removes a class of defects (stale docs, misleading error messages, wrong env var names) that erode operator trust in config documentation and tooling

---

### Context

{project_name}'s code review gate (G5) applies a 10-point checklist defined in HAR-C-0002 §6
and detailed in `.github/agents/code-reviewer.agent.md`. During Phase 1 and Phase 2
development, four categories of defects reached post-merge review that a more precisely
specified checklist would have caught at review time:

**Category 1 — Pydantic Field description vs validator mismatch**
`{src_dir}/config.py` `batch_processing_mode` had `Field(description="processing mode:
auto | standard | deep ...")` while the valid values enforced by the field validator were
`auto | adaptive | batch_per_file | batch_per_project`.
The description was operator-visible documentation for the wrong set of values. No
checklist item asked the reviewer to cross-check `Field(description=)` against the
validator's `allowed_modes`.

**Category 2 — YAML operator config env var comment drift**
`{config_dir}/tool.yaml` had inline comments citing env var names that omitted the
`_SERVER_` segment (e.g., `{PROJECT_PREFIX}_TOOL_READY_TIMEOUT` instead of the correct
`{PROJECT_PREFIX}_TOOL_SERVER_READY_TIMEOUT`). No checklist item required the reviewer to
derive `{PROJECT_PREFIX}_` + `UPPER_SNAKE_CASE(field_name)` and verify every comment.

**Category 3 — Migration head drift in integration tests**
When migration `NNNN_new_migration_name` was added, the integration test
`tests/integration/test_migrations.py::expected_head` remained hardcoded at
`"MMMM_previous_migration_head"`. The test passed because the migration chain was
not exercised end-to-end in CI at the time of review. No checklist item required
the reviewer to scan integration tests for hardcoded migration-head strings when a
new `{migration_dir}/` file appeared in the diff.

**Category 4 — Broad except scope swallowing sub-check errors**
`scripts/validate_config.py` wrapped a sub-check (migration state query) inside a broad
`except Exception` block that also guarded the connection check. A fresh database
(where `alembic_version` does not yet exist) caused an `UndefinedTable` error that was
caught as a connection failure, masking a successful connection and emitting a misleading
"cannot connect" message. No checklist item required the reviewer to verify that broad
exception handlers do not suppress errors belonging to a finer-grained sub-check whose
partial result has already been written.

The root cause is not reviewer carelessness. The checklist sub-bullets did not specify
these cross-reference verifications. A reviewer following the list exactly could miss all
four without violating any current rule.

---

### Decision

Add 4 sub-bullets to the HAR-C-0002 §6 10-point review checklist and mirror them
verbatim in the detailed `.github/agents/code-reviewer.agent.md` 9-point checklist.
The number of top-level checklist points remains 10. Sub-bullets are placed under
the most semantically appropriate existing point.

**Sub-bullet 1 — placed under Check 2 (Interface Contract):**
> Pydantic `Field(description=)` must enumerate the same allowed values as the
> corresponding `@field_validator`. Reviewer verifies this cross-reference for every
> Settings field that has both a `description=` argument and a validator in the diff.

**Sub-bullet 2 — placed under Check 3 (Coding Standards):**
> YAML operator config files must have correct env var names in inline comments.
> Reviewer derives the correct variable as `{PROJECT_PREFIX}_` + `UPPER_SNAKE_CASE(field_name)`
> for each `Settings` field and spot-checks every comment that references a variable
> name in any file under `{config_dir}/`.

**Sub-bullet 3 — placed under Check 5 (No Anti-Patterns):**
> A broad `except Exception` block must not suppress errors that belong to a
> finer-grained sub-check whose partial result has already been appended to a results
> list. Each failure mode must produce a distinct, accurate error message.

**Sub-bullet 4 — placed under Check 7 (No Orphan Data Paths):**
> When any `{migration_dir}/` file is added or modified in the diff, every integration
> test with a hardcoded migration-head string (e.g., `expected_head`) must be updated
> to match the new head. Reviewer scans test files for migration-head literals and
> verifies they match the last file in `{migration_dir}/` lexicographic order.

---

### Consequences

**Positive:**

- Reviewers have explicit, actionable prompts for four recurring defect classes.
- The checks are self-contained: each one names the exact derivation rule or file
  location the reviewer must inspect — no judgment required.
- Migration head drift is now caught at G5 before merge rather than discovered by
  operators running integration tests against a fresh database.

**Negative / Trade-offs:**

- Marginal increase in review time — each sub-bullet adds one targeted cross-reference
  lookup. Estimated < 2 minutes total across all four checks for a typical PR.

**Neutral / Operational notes:**

- The sub-bullets apply to all PR types (NEW_FEATURE, BUG_FIX, ENHANCEMENT,
  CONSTITUTION_CHANGE touching runtime code). For CONSTITUTION_CHANGE tasks that
  touch only agent/contract/ADR files and no `src/` or `{config_dir}/` files, checks 1,
  2, and 3 are N/A; check 4 is N/A unless a migration file appears in the diff.

---

### Alternatives Considered

| Alternative | Why Rejected |
|---|---|
| Post-deploy linting script for each rule | Shifts detection to after merge; the point of G5 is to catch these before they ship |
| New top-level checklist point (11th item) | The four checks are sub-specifications of existing points — adding a top-level point inflates the headline number without adding semantic clarity |
| Add contract-level validation scripts | Scripts help but cannot replace reviewer judgment on prose descriptions (`Field(description=)`) and comment text; scripts are complementary, not a substitute for the explicit review prompt |

---

### Compliance

*These constitution files must be amended as part of this ADR's implementation.*

- `constitution/harness/contracts/HAR-C-0002-sdlc-contract.md` §6 — add 4 sub-bullets to checklist points 2, 3, 5, and 7
- `.github/agents/code-reviewer.agent.md` — mirror the same 4 sub-bullets under the corresponding checks in the detailed 9-point checklist

### Amendment Index

| Date | Amended by | Change |
|---|---|---|
| — | — | — |
