﻿## HAR-ADR-0010: Workspace Data Optimization — Subtask Inlining, ADR Synopsis, Review Log

**Status:** Proposed
**Date:** 2026-05-21
**Deciders:** Lead Engineer, Architecture Review
**Supersedes:** —
**Superseded by:** —
**Amends:** HAR-ADR-0008 (adds inline subtask object to `task-state.json`, changing the agent read protocol at G4), HAR-ADR-0003 (adds two new files to the workspace layout: `adrs/SYNOPSIS.md` and `reviews/review-log.md`)
**Amended by:** —
**FACT impact:**
- Fast: `improves` — coder per-subtask context load drops ~50% (plan.json eliminated from default read path; full ADR text replaced by synopsis); no runtime path affected
- Accurate: `neutral` — synopsis is derived verbatim from the Decision and Compliance sections of each ADR; no content is approximated or summarised by AI; full ADR remains available on escalation
- Complete: `neutral` — no information is deleted; full plan.json and full ADR files remain in the workspace and are accessible on escalation
- Trustworthy: `improves` — review-log provides a durable one-line-per-gate audit trail visible to any agent at O(1) cost; no gate outcome is now invisible without opening full review reports

---

### Context

HAR-ADR-0008 reduced agent startup cost by splitting `state.json` into a slim index and
per-workspace `task-state.json`. However, per-subtask context load at G4 remains high.
A profiled SPEC-0020 workspace shows ~146 KB loaded by the coder per subtask: `spec.md`
(68 KB), `plan.json` (28 KB), ADR files in `workspace/adrs/` (47 KB), and `task-state.json`
(2.3 KB). Of this, `plan.json` is loaded solely to extract the active subtask object
(one of 16 entries) — the other 15 subtask entries are noise. The full ADR file is loaded
for implementation pattern guidance, but the coder only needs the Decision paragraph and
Compliance section (~15 lines out of ~300+). Reviews accumulate across gates (SPEC-0020:
83 KB in 4 files) with no lightweight summary — agents seeking orientation must either load
all reviews or none. Three targeted changes address these waste patterns without adding
coordination complexity or risking information loss.

---

### Decision

We will apply three workspace data optimisations that are implemented entirely by the
orchestrator at gate boundaries. Agents read new lightweight artifacts first and escalate
to full files only on demand.

**Optimisation 1 — Active subtask inlining (`task-state.json`)**

When the orchestrator advances `task-state.json` to the next subtask (after each G4
subtask approval), it writes the **complete subtask object** from `plan.json` inline into
`task-state.json` under the `active_subtask` key, replacing the ID string.

```json
// Before (HAR-ADR-0008 pattern)
{ "active_subtask": "SPEC-0020-T11" }

// After (HAR-ADR-0010 pattern)
{
  "active_subtask": {
    "id": "SPEC-0020-T11",
    "title": "Implement DataProcessor.process_batch()",
    "type": "implement",
    "description": "...",
    "files": ["{src_dir}/workers/example_worker/data_processor.py"],
    "spec_exports": { "classes": ["DataProcessor"], "constants": [] },
    "depends_on": ["SPEC-0020-T10"],
    "estimated_lines": 120,
    "status": "in-progress"
  }
}
```

The coder reads `task-state.json` and has everything it needs for the current subtask.
`plan.json` is no longer opened by default; it is escalated to only for cross-subtask
context (understanding dependencies, reviewing previous subtask outputs).

The orchestrator also sets `active_subtask` at G3 close (first subtask inlined when
the plan is approved) so the coder picks up cleanly at G4 start.

**Optimisation 2 — ADR synopsis (`workspace/adrs/SYNOPSIS.md`)**

At G1, after the orchestrator copies ADR files into `workspace/<spec_id>/adrs/`, it
immediately generates `workspace/<spec_id>/adrs/SYNOPSIS.md` by extracting the
**Decision paragraph** and **Compliance section** from each copied ADR file.

Format:
```markdown
# ADR Synopsis — <workspace>/<spec_id>

## ADR-NNNN: <Title>
**Decision:** <verbatim first sentence of ### Decision section>
**Compliance:**
- Contract: <verbatim list>
- Eval: <verbatim list>

---
```

Agents read `SYNOPSIS.md` first. They escalate to the full ADR file only when
implementation pattern details, consequences, or alternatives are needed. The synopsis
is extracted mechanically from the ADR source — no AI summarisation; content is verbatim.

**Optimisation 3 — Review log (`workspace/reviews/review-log.md`)**

At each gate that produces a review (G2, G5), the orchestrator appends a single line
to `workspace/<spec_id>/reviews/review-log.md` immediately after the review report is
saved. Format:

```
<gate> | <date> | <PASS|FAIL> | <agent> | <one-sentence summary of key finding or "clean">
```

Example:
```
G2     | 2026-05-20 | PASS | spec-reviewer | 12 violations fixed across 4 passes; final 14/14 clean
G5     | 2026-05-20 | FAIL | code-reviewer | 3 blockers: FACT envelope incomplete, table name drift, TDD order
G5     | 2026-05-21 | PASS | code-reviewer | blockers resolved; SAST WARN acknowledged
```

Agents load `review-log.md` for orientation. They escalate to full review files only
when validator compliance checks or exact finding text is needed.

---

### Consequences

**Positive:**

- Coder per-subtask context load: ~146 KB → ~72 KB (~51% reduction). Eliminated: plan.json
  (28 KB default load), full ADR text (47 KB → ~1 KB synopsis). Remaining dominant cost:
  spec.md (68 KB, genuinely needed; not optimised in this ADR).
- ADR synopsis extraction is a mechanical read of two named sections — no LLM involvement,
  no drift risk. The orchestrator verifies section headers exist before writing.
- Review log gives any agent instant orientation on gate history without loading 83+ KB of
  review files.
- No backward-incompatible schema change: `active_subtask` ID-string is still the starting
  state; it is upgraded to an object by the orchestrator at G3 close. Existing workspaces
  without inlined objects continue to work — agents fall back to opening plan.json when
  `active_subtask` is a string (detection: `typeof active_subtask === "string"`).

**Negative / Trade-offs:**

- `task-state.json` grows slightly when a subtask has a large `description` field (~2–4 KB
  per subtask inline vs 2.3 KB total previously). Still negligible vs 28 KB plan.json load.
- Orchestrator has three new G-boundary write duties. If the orchestrator session ends
  mid-gate, the synopsis or inline subtask may not be written. Fallback: agents detect
  missing optimised artifacts and load full files (graceful degradation).
- Synopsis extraction requires the orchestrator to parse ADR section headers reliably.
  If an ADR uses non-standard formatting, the synopsis may be incomplete. Mitigation:
  orchestrator verifies `### Decision` and `### Compliance` headers exist; logs a warning
  if absent rather than failing silently.

**Neutral / Operational notes:**

- Existing workspace directories without `SYNOPSIS.md` or `review-log.md` are valid;
  agents treat absent files as "escalate to full." No migration required.
- `plan.json` is not deleted or moved — it remains the authoritative subtask catalogue
  for the planner, validator (V4), and cross-subtask dependency resolution.
- `spec.md` is not addressed by this ADR. Spec window extraction (loading only relevant
  sections per subtask) is deferred — the added coordination complexity is not justified
  until specs routinely exceed 100 KB.

---

### Alternatives Considered

| Alternative | Why Rejected |
|-------------|-------------|
| Spec windowing (extract per-subtask relevant sections from spec.md) | Adds coordination complexity (section→subtask mapping); spec.md is genuinely needed in full by planner and code-reviewer; deferred until spec size is a recurring pain point |
| Compress completed subtasks out of plan.json | plan.json is written once by planner and referenced by validator (V4); mutating it during G4 creates version confusion; inlining into task-state.json is simpler and achieves the same per-subtask load reduction |
| Store synopsis in-memory only (not written to disk) | Eliminates the reuse benefit across sessions; cross-session continuity requires persistence |
| Full plan.json load but windowed JSON parse (read only active subtask by ID) | Requires agents to implement selective JSON parsing — adds tooling complexity with marginal gain over full file read; inlining is cleaner |

---

### Compliance

- Contract: `constitution/harness/contracts/HAR-C-0002-sdlc-contract.md` (pipeline artifacts and workspace protocol)
- Workspace layout: `.github/pipeline/workspace/<spec_id>/adrs/SYNOPSIS.md` (new file)
- Workspace layout: `.github/pipeline/workspace/<spec_id>/reviews/review-log.md` (new file)
- `task-state.json` schema: `active_subtask` field type changes from `string` to `object` at G3 close
- Graceful degradation: agents detect missing optimised artifacts and fall back to full files
