# HAR-ADR-0021: Project-Level System Contracts (SYS-C) Are Not Part of the Harness

| Field       | Value                                                           |
|-------------|-----------------------------------------------------------------|
| **ID**      | HAR-ADR-0021                                                    |
| **Status**  | Accepted                                                        |
| **Date**    | 2025-07-01                                                      |
| **Deciders**| Harness maintainers                                             |

---

## Context

SW_Harness ships a set of **HAR-C contracts** that govern the harness's own internal behaviour
(gate sequencing, spec structure, number registry, ADR format, etc.). These contracts are
generic and apply to any project that adopts the harness.

However, real projects also need **system-level contracts** (SYS-C) that capture domain-specific
interface obligations — e.g., "every event published to the queue must carry a correlation-id",
"every REST endpoint must validate authentication before processing". These are not reusable
across projects; they are artefacts of the product built on top of the harness.

During the extraction of SW_Harness from its originating project, several SYS-C contract files
(e.g., `SYS-C-0006.yaml`, `SYS-C-0010.yaml`) were intentionally **not carried over** to this
repository. Copying them would couple the harness to a specific product's domain rules.

---

## Decision

**SYS-C contracts are project-level artefacts and must not live in SW_Harness.**

Each project that adopts SW_Harness is responsible for creating its own SYS-C contracts using
the `@adr-writer` agent (or equivalent) via the harness pipeline.

SW_Harness does not ship:
- SYS-C contract markdown files
- SYS-C assertion YAML files (e.g., `assertions/SYS-C-NNNN.yaml`)
- Pre-populated SYS-C registry entries

SW_Harness does ship:
- The **proof-dispatcher** and **contract-fidelity checker** scripts that can evaluate any
  SYS-C contract a project defines, once wired up.
- The `HAR-C-0002.yaml` and `HAR-C-0003.yaml` assertion fixtures (harness-internal only).
- Documentation (this ADR) explaining the pattern and how to create SYS-C contracts.

---

## Pattern — How a Project Creates SYS-C Contracts

1. Run a discovery session (`@discovery-grill`) to surface cross-cutting constraints.
2. Raise a SPEC or IDEA in the harness pipeline with `category: system-contract`.
3. At G1 (Spec), the `@spec-writer` captures the contract in a `SYS-C-NNNN.md` file under
   `constitution/<project>/contracts/`.
4. At G3 (Plan), the `@planner` adds an assertion YAML task to
   `constitution/<project>/registries/assertions/SYS-C-NNNN.yaml`.
5. The `run_proof_dispatcher.py` script evaluates the assertion against codebase evidence.

---

## Consequences

- Projects adopting SW_Harness get a **clean harness** with no product-specific contracts
  baked in — no domain coupling on day one.
- The harness pipeline itself is what creates SYS-C contracts; they emerge from real discovery
  work, not from copy-paste templates.
- The absence of SYS-C files in SW_Harness is intentional and governed by this ADR. Do not
  add product-level assertion files to this repository.
- If a cross-project pattern emerges that should be a HAR-C (harness-level) contract, raise
  an IDEA-H entry in `ideas-backlog.md` and let it go through the harness pipeline.

---

## Related

- HAR-C-0002 — Spec structure contract (harness-internal)
- HAR-C-0003 — ADR format contract (harness-internal)
- IDEA-H-001 — G0.5 Pre-Spec Landscape Gate (captured, not yet implemented)
- IDEA-H-002 — G0.8 Architect Gate (captured, not yet implemented)
