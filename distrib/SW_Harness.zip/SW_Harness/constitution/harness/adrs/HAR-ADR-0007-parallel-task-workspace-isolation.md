﻿# HAR-ADR-0007: Parallel Task Workspace Isolation

**Status:** Accepted
**Date:** 2026-05-17
**Deciders:** Lead Engineer, Architecture Review
**Supersedes:** —
**Superseded by:** —
**Amends:** HAR-ADR-0003 (pipeline workspace layout — replaces the single `workspace/current/` slot with spec-scoped `workspace/SPEC-NNNN/` directories); HAR-C-0002 (SDLC — state.json field names `active_streams`→`active_tasks`, `stream_id`→`task_id`; workspace artifact paths updated throughout)
**Amended by:** HAR-ADR-0008 (split pipeline state into slim index + per-workspace task-state.json; extends workspace artifact layout)
**FACT impact:**
- Fast: `improves` — spec-scoped workspaces eliminate the risk of stale artifacts from a prior task being read by agents working on a different task; no cross-contamination means fewer re-reads and debug cycles
- Accurate: `improves` — each task's spec, plan, ADRs, and reviews are isolated in their own directory; agents cannot accidentally pick up a previous task's spec.md when `workspace/current/` was not cleared
- Complete: `neutral` — workspace isolation does not affect which tasks are executed, only where their artifacts live
- Trustworthy: `improves` — audit trail is permanent: `workspace/SPEC-0002/` persists after G6, providing a complete record of the spec, plan, and reviews that governed the implementation; `workspace/current/` was overwritten at every G0, destroying prior-task evidence

---

## Context

HAR-ADR-0003 established a single pipeline workspace at `.github/pipeline/workspace/current/`
to hold in-flight artifacts for the active task (spec, plan, ADR copies, reviews, subtasks).
This design has two structural problems that became visible as the project scaled past 8 tasks:

**Problem 1 — Single slot collision.** When a new task's G0 runs, the orchestrator creates
`workspace/current/` and copies the new spec and ADRs into it. Any artifacts left from the
previous task (plan.json, reviews, subtask state) are either silently overwritten or persist
alongside unrelated new task artifacts. Forensic analysis of streams 1–8 confirmed that the
`code-review-implemented-specs.md` file (covering SPEC-0008/0009/0010) and the
`v5-release-compliance.md` (for a prior task) still exist in `workspace/current/reviews/`
alongside SPEC-0002 artifacts — different tasks' outputs are co-mingled in a single directory.

**Problem 2 — "stream" terminology collision with Kafka.** The field names `active_streams`
and `stream_id` in `state.json` use "stream" in the SDLC sense (a pipeline task). Kafka
topics and consumer groups also use the word "stream". This creates ambiguity in agent
instructions, documentation, and code reviews where both concepts appear.

**Trigger.** This ADR was scheduled for after task-8 (SPEC-0002) reached G6. That condition
was met on 2026-05-17 (`check_phase_gate.py --phase 1` returning exit 0).

---

## Decision

### 1. Spec-scoped workspace directories

Each pipeline task gets its own workspace directory named after its primary spec:

```
.github/pipeline/workspace/
  SPEC-0002/          ← task-8 workspace (persists after G6)
    spec.md
    plan.json
    adrs/
    reviews/
    subtasks/
  SPEC-0013/          ← task-6 workspace
  SPEC-0014-0015/     ← task-7 workspace (multi-spec task uses hyphen-joined IDs)
  HAR-ADR-0004/           ← CONSTITUTION_CHANGE task that produced HAR-ADR-0004 (uses ADR-NNNN)
  HAR-ADR-0005/           ← CONSTITUTION_CHANGE task that produced HAR-ADR-0005
```

Rules:
- **Single-spec task:** `workspace/SPEC-NNNN/`
- **Multi-spec task:** `workspace/SPEC-NNNN-MMMM/` (primary spec first, numerically ascending)
- **Constitution-change task that produces an ADR:** `workspace/ADR-NNNN/` where NNNN is the ADR number
- **Constitution-change task with neither spec nor ADR:** `workspace/task-N/` where N is the task number (rare fallback)
- Workspace directories are **never deleted** after G6 — they are the permanent audit trail
- `workspace/current/` is **removed** from all agent instructions; no symlink or alias is created

### 2. `workspace_path` field in state.json

Each task entry in `state.json` gains a `workspace_path` field recording the actual path:

```json
{
  "task_id": "task-8",
  "workspace_path": ".github/pipeline/workspace/SPEC-0002/",
  ...
}
```

Agents resolve the active workspace by reading `state.json`, finding the task whose
`current_gate` is not `CLOSED`, and reading `workspace_path`. The orchestrator records
`workspace_path` at G0 when the workspace directory is created.

### 3. Rename `stream` → `task` in state.json

| Old field | New field | Reason |
|-----------|-----------|--------|
| `active_streams` | `active_tasks` | "stream" collides with Kafka terminology |
| `stream_id` | `task_id` | same |
| Value `"stream-N"` | Value `"task-N"` | consistent with field rename |

No other files use these field names at runtime (they are only read by `pipeline_metrics.py`
and orchestrator instructions). `pipeline_metrics.py` already handles both field names
(forward-compatible as of 2026-05-17).

### 4. Workspace resolution protocol for agents

Agents that previously read from `workspace/current/` now:

1. Read `.github/pipeline/state.json`
2. Find the task entry where `current_gate != "CLOSED"` (the active task)
3. Read `workspace_path` from that entry
4. Access all workspace artifacts relative to that path

The orchestrator communicates the resolved path explicitly in its handoff instructions
so downstream agents do not need to re-read state.json.

---

## Consequences

### Positive
- Past workspaces serve as a permanent, self-contained record of the spec + plan + reviews that governed each implementation — full audit trail
- No stale artifact cross-contamination between tasks
- Pipeline task terminology no longer collides with message-broker or stream-processing concepts in the codebase and documentation; workspace paths use spec IDs rather than generic "stream" labels
- Parallel tasks (future capability) can each have their own workspace without conflict

### Negative
- Agents must read state.json to resolve the workspace path instead of hardcoding `workspace/current/`; slightly more work at session start (mitigated by the orchestrator pre-communicating the path)
- Existing `workspace/current/` content is orphaned — it should be migrated to `workspace/SPEC-0002/` as part of this ADR's implementation (one-time migration)

### Migration (one-time)
Rename `.github/pipeline/workspace/current/` to `.github/pipeline/workspace/SPEC-0002/`
to preserve the existing SPEC-0002 G4 artifacts under the new naming scheme.

---

## Rejected Alternatives

**Keep `workspace/current/` with a clear-on-G6 step.** The orchestrator already clears it
at G6 per HAR-ADR-0003, but forensic review showed this step was skipped on prior task batches.
Relying on a manual clear step is the root cause of the contamination.
A name that encodes the spec ID cannot be accidentally shared across tasks.

**Use symlinks: `workspace/current/` → `workspace/SPEC-NNNN/`.** Symlinks on Windows
require elevated privileges or Developer Mode. Not portable.
