# HAR-ADR-0022: Mechanism-Fidelity Verification — Spec IR, Typed Test Tiers, and design.md

| Field       | Value                                                           |
|-------------|-----------------------------------------------------------------|
| **ID**      | HAR-ADR-0022                                                    |
| **Status**  | Accepted                                                        |
| **Date**    | 2026-06-09                                                      |
| **Deciders**| Harness maintainers                                             |
| **Amends**  | HAR-C-0002 §2, HAR-C-0003 §3; agent files: coder, validator, spec-writer, tester, code-reviewer |

---

## Context

A production audit on an adopting project revealed a structural gap in the harness pipeline: a
spec prescribed a specific API variant ("use v3 synchronous write"), the coder silently used a
different variant, and every downstream gate passed. Root cause analysis confirmed the gap is not
accidental — it is architectural.

Every verification step in the harness operates on **observable structure**:
- Test outcome assertions verify *what the system produced*, not *how it produced it*
- Validator V2.18 checks symbol names match — not which internal path ran
- Code-reviewer item #1 checks that prose Behaviour steps have corresponding code — not which API variant that code uses
- Acceptance criteria pass with any implementation that produces the correct output

This is the **mechanism-fidelity gap**: a whole category of spec constraints (which method to call,
which API variant, execution ordering, config values) is invisible to every automated gate.

The gap exists at three drift windows:
1. **Pre-code drift** — coder misinterprets spec before writing the first test
2. **Test-time drift** — code diverges from spec; outcome tests still pass because both variants produce identical output in test environments
3. **Runtime drift** — production behaviour diverges from both spec and tests (config override, feature flag, environment difference)

An expanded audit mapped six categories of mechanism-invisible constraints:
- Execution variant (which API/path runs)
- Ordering / sequencing
- Scope / boundary (transaction atomicity, read-write split)
- Behavioral contract (retry policy, timeout, idempotency key)
- Safety / correctness (error propagation, locking strategy)
- Observability (metric emission, trace propagation)

None of these are caught by outcome assertions or structural name-matching.

---

## Decision

Introduce four coordinated changes that close the mechanism-fidelity gap without adding new gates
or new agents. All changes operate at the **spec layer** (Markdown + YAML) and the **evidence
layer** (test IDs, symbol names, OTel spans), making them language-agnostic by construction.

### Change 1 — `## Scenarios` replaces `## Behaviour` in spec format

`## Behaviour` prose steps are replaced with named scenarios in GIVEN/WHEN/THEN format. This is
not a cosmetic change — THEN clauses that reference a specific callable **must name the callable
explicitly**. This converts mechanism constraints from interpretable prose into extractable
structured assertions.

Rules for THEN clauses:
- A THEN that names a specific callable must include a negation clause (`AND <alternative> is NOT called`) when an alternative exists
- A THEN that constrains ordering must name both callables in sequence
- A THEN that constrains a config value must name the key and exact value

The GIVEN/WHEN/THEN format is borrowed from BDD but is NOT tied to any specific framework.
Scenarios are authored as Markdown — no external tooling required.

### Change 2 — `## Constraints` YAML block as the Spec IR

A new mandatory section `## Constraints` is added to the spec format. It is a machine-readable
YAML block that explicitly captures the mechanism constraints derived from the THEN clauses in
`## Scenarios`. This is the **Spec Intermediate Representation (IR)** — a typed, structured
form of the spec's mechanism requirements.

Three constraint types:
```yaml
## Constraints
```yaml
mechanism:
  - must_call: <symbol>            # callable that MUST be used
    must_not_call: <symbol>        # callable that must NOT be used (optional)
  - ordering: [<first>, <second>]  # first must execute before second
config:
  - key: <config_key>
    value: <exact_value>
```
```

Rules:
- Every entry must be a greppable symbol (function name, class name, config key) — not prose
- Prose constraints that cannot be expressed as a symbol belong in `## Scenarios` THEN clauses
  and must have a corresponding mechanism test (T-M) in `## Tests required`
- When `## Constraints` is empty, write `_None — this spec prescribes no mechanism-level constraints._`
- `spec-reviewer` verifies every THEN clause naming a callable has a corresponding `## Constraints` entry

### Change 3 — `## Tests required` gains three typed subsections

The existing free-form list is replaced with three explicit categories:

```
### AC tests (outcome)       — verify what the system produces
### Mechanism tests (T-M)    — verify which code path executed (call-site assertions)
### Contract tests (T-C)     — verify configuration values match spec
```

Rules:
- Every `mechanism:` entry in `## Constraints` requires a corresponding T-M entry
- Every `config:` entry in `## Constraints` requires a corresponding T-C entry
- T-M test format: `T-Mnn: assert <must_call> called; assert <must_not_call> NOT called`
- T-C test format: `T-Cnn: assert <key> == <value>`
- The coverage script checks T-M and T-C entries independently of AC entries

### Change 4 — `design.md` as pre-code declaration artifact

Before writing the first test, the coder must produce a `design.md` file in the workspace
(`<workspace_path>/design.md`). This file declares which specific callables, APIs, and config
values will be used to satisfy the spec's mechanism constraints.

`design.md` format:
```markdown
# Design — SPEC-NNNN

## Mechanism declarations
- <constraint-id>: will use `<symbol>` — `<excluded_symbol>` explicitly excluded
  Reason: <one sentence why>

## Config declarations
- <key>: value is `<value>` as required by spec
```

Rules:
- One declaration per `## Constraints` entry
- The coder cannot begin writing tests until `design.md` is committed
- Validator V2 checks `design.md` exists and is non-empty at G4 close
- Code-reviewer item #1 compares implementation against `design.md` declarations, not just spec prose
- If a declaration in `design.md` differs from `## Constraints`, it must be documented in `## Deviations`

---

## Consequences

**Positive:**
- Mechanism constraints are now machine-readable (Constraints YAML) — parseable by scripts
- The coverage script can deterministically verify T-M and T-C tests exist for every constraint
- Static grep can detect banned symbols anywhere in source, catching the "import v3, call v2" class of bug
- `design.md` converts passive spec reading into a binding pre-code declaration
- Code-reviewer has a typed artifact to check against, not prose
- The entire stack is language-agnostic — Constraints YAML is strings, THEN clauses are text, OTel spans are JSON
- No new gates, no new agents — existing machinery gains typed inputs

**Negative / trade-offs:**
- Spec authoring cost increases slightly: spec-writer must now produce `## Scenarios` + `## Constraints` YAML + typed `## Tests required`
- Not all constraints are expressible as greppable symbols — behavioral and temporal constraints (atomicity, latency, concurrency safety) remain in the AC/test layer, not in `## Constraints`
- `design.md` adds one artifact per spec to the pipeline workspace

**What remains non-deterministic (by design):**
- Behavioral semantics ("operation must be atomic") — requires a test that proves rollback; cannot be grepped
- Temporal guarantees ("must complete within 30ms") — requires a performance test; runtime measurement
- Concurrency safety ("thread-safe under N workers") — requires a load test; non-deterministic in unit scope

These belong to the eval suites tier (HAR-C-0003 §6), not to the `## Constraints` IR.

---

## Runtime Drift Detection (Phase 2 — deferred)

The `## Constraints` YAML is designed to serve as input to a runtime drift checker that
compares OpenTelemetry spans against constraint entries. This is deferred to a later
enhancement. The Constraints YAML format is designed for this extension: `must_call` entries
map directly to span function names; `ordering` entries map to span sequence checks.

---

## Files Amended by this Decision

| File | Change |
|---|---|
| `constitution/harness/contracts/HAR-C-0002-sdlc-contract.md` | §2: replace `## Behaviour` with `## Scenarios`; add `## Constraints`; type `## Tests required` |
| `constitution/harness/contracts/HAR-C-0003-testing-contract.md` | Add T-M and T-C test category rules |
| `.github/agents/spec-writer.agent.md` | Add `## Scenarios` format rules and `## Constraints` YAML authoring rules |
| `.github/agents/coder.agent.md` | Add design.md pre-flight step before first test commit |
| `.github/agents/validator.agent.md` | Add V2.20 (T-M coverage), V2.21 (T-C coverage), V2.22 (design.md exists); extend VS/V1 for new sections |
| `.github/agents/tester.agent.md` | Add T-M and T-C test writing rules |
| `.github/agents/code-reviewer.agent.md` | Extend item #1 to compare implementation against design.md declarations |
| `constitution/harness/scripts/check_spec_test_coverage.py` | Parse `## Constraints` YAML; verify T-M/T-C stubs; static grep for `must_not_call` symbols |
