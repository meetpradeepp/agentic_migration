﻿## HAR-ADR-0014: Worker Test Infrastructure — WorkerTestHarness and Integration Fixture Library

**Status:** Accepted
**Date:** 2026-06-01
**Deciders:** Lead Engineer
**Supersedes:** —
**Superseded by:** —
**Amends:** —
**Amended by:** —
**FACT impact:**
- Fast: `neutral` — no runtime path affected; test infrastructure is a dev-time concern only
- Accurate: `improves` — standardised mock factories eliminate class of defect where hand-rolled mocks silently accept misspelled field names or wrong argument order
- Complete: `neutral` — test coverage targets unchanged; only the cost of reaching them decreases
- Trustworthy: `improves` — shared harness ensures every worker test validates the same dependency contract surface, closing the gap between worker implementations

---

### Context

A post-Phase-2 measurement across 11 implementation plans showed that worker unit test
subtasks require 100–150 lines of mock boilerplate per test file. The boilerplate is
structurally identical across all workers: mock message-broker consumer, mock message-broker producer, mock
`IDataStore`, mock `{ProjectName}Settings`, and (for Phase 3 workers) mock graph-DB driver and vector-store
client. This boilerplate is manually copy-pasted into each new worker test file, contributing
to a measured 3× test-writing effort overhead relative to the test logic itself.

Three concrete problems follow from the copy-paste pattern:

1. **Divergence over time.** The mock contracts drift from the real interface. When
   `IDataStore` gains a new method, some test files are not updated because no single
   source of truth exists for "what a well-formed IDataStore mock looks like."

2. **Mock safety gap.** `MagicMock()` instances accept any attribute lookup. A mock
   `{ProjectName}Settings` passes `.BROKER_POLL_TIMEOUT_MS` silently even though the real setting is
   named `broker_poll_timeout_ms` (camel vs snake). This root cause produced HAR-C-0004 §A18.

3. **Integration test friction.** Integration tests require live Docker services (e.g.,
   relational store, message broker, graph store). No standardised fixture library exists;
   each test file duplicates service startup, teardown, and topic/table seeding. This causes
   integration subtasks to block on Docker availability and adds 30–50 lines of fixture
   boilerplate per integration test file.

---

### Decision

We will introduce a **`WorkerTestHarness`** base class and an **integration fixture library**
in the test infrastructure.

**1 — `tests/harness/worker_test_harness.py` (unit test base)**

```
class WorkerTestHarness:
    """Base class for all worker unit tests.

    Provides:
    - make_consumer()       → pre-configured mock BrokerConsumer
    - make_producer()       → pre-configured mock BrokerProducer
    - make_db()             → {ProjectName}Settings-seeded IDataStore mock (not MagicMock)
    - make_settings(**kw)   → real {ProjectName}Settings(**kw) (not MagicMock)
    - make_graph_driver()   → mock graph-DB driver with session context manager (optional, Phase 3+)
    - make_vector_client()  → mock vector-store client with pre-wired search/upsert (optional, Phase 3+)
    - assert_produced(topic, payload_type)
    - assert_no_production()
    """
```

Rules:
- All `make_*` methods return **typed** objects — no raw `MagicMock` return types.
- `make_settings` always returns a real `{ProjectName}Settings` instance (HAR-C-0004 §A18 enforcement).
- `make_db` returns a `MagicMock(spec=IDataStore)` (spec= constraint prevents silent field drift).
- New worker implementations MUST inherit `WorkerTestHarness` in their unit test class. The
  code-reviewer blocks at G5 any worker unit test file that does not inherit from it.

**2 — `tests/harness/integration_fixtures.py` (integration test fixtures)**

```
@pytest.fixture(scope="session")
def db_service() -> Generator[DbFixture, None, None]: ...

@pytest.fixture(scope="session")
def broker_service() -> Generator[BrokerFixture, None, None]: ...

@pytest.fixture(scope="session")
def graph_service() -> Generator[GraphFixture, None, None]: ...
```

Rules:
- All fixtures are `scope="session"` — services start once per test run, not per test file.
- Each fixture exposes `.connection_string`, `.broker_url`, `.graph_url` for injection.
- Fixtures are **skip-on-unavailable**: if Docker is not running, integration tests are
  skipped with `pytest.skip("service unavailable")` rather than failing. This prevents
  integration tests from blocking CI when Docker is absent.
- Fixture seeding helpers: `db_service.seed_table(table, rows)`, `broker_service.seed_topic(topic, messages)`.

**3 — Adoption timeline**

- The `WorkerTestHarness` class is implemented as the first subtask of the next worker spec
  that enters G4. It does not require a retroactive rewrite of existing worker test files
  (too disruptive mid-phase); it is used for all new worker implementations from this ADR
  onward.
- The integration fixture library is implemented alongside `WorkerTestHarness`.
- Code-reviewer adds a G5 gate check: worker unit test files written after this ADR MUST
  inherit `WorkerTestHarness`. Pre-ADR files are grandfathered.

---

### Consequences

**Positive:**

- Worker test boilerplate reduced from ~120 lines to ~20 lines per new worker test file.
- Mock contract drift eliminated: `MagicMock(spec=IDataStore)` raises `AttributeError`
  for non-existent methods.
- Integration test fixture duplication eliminated; Docker services start once per session.
- `{ProjectName}Settings` mock safety gap (HAR-C-0004 §A18 root cause) structurally prevented.

**Negative / Trade-offs:**

- `WorkerTestHarness` is a new test dependency; it must be kept up to date when
  `IDataStore`, `{ProjectName}Settings`, or message-broker event structures change.
- Grandfathering existing test files means the benefit accrues only on new workers.
  Full retroactive adoption is a separate refactor task.

**Neutral / Operational notes:**

- `tests/harness/` is not a pytest test file; it is a support library. Pytest must be
  configured to exclude it from test discovery (`testpaths` in `pyproject.toml`).
- The integration fixtures depend on `docker` being available on the test host.
  Local development environments without Docker continue to run unit tests only.

---

### Alternatives Considered

| Alternative | Why Rejected |
|-------------|-------------|
| Per-worker `conftest.py` fixtures | Does not eliminate boilerplate duplication; still requires copy-paste per worker |
| pytest-mock plugin | Provides `mocker` fixture but not typed mock factories; does not enforce `spec=` constraints |
| Retroactive rewrite of all existing worker tests | Too disruptive mid-phase; risk of introducing regressions across 400+ existing tests |

---

### Compliance

- Contract: `constitution/harness/contracts/HAR-C-0003-testing-contract.md` §2 (80% coverage rule still applies; `WorkerTestHarness` makes reaching it cheaper)
- Contract: `constitution/harness/contracts/HAR-C-0004-anti-patterns.md` §A18 (MagicMock for Settings banned — `WorkerTestHarness.make_settings()` is the enforcement mechanism)
- Eval: no eval suite change required — unit and integration test targets are unchanged
