﻿# HAR-ADR-0008: Split Pipeline State into Slim Index + Per-Workspace Task State

**Status:** Accepted
**Date:** 2026-05-17
**Deciders:** Lead Engineer, Architecture Review
**Supersedes:** —
**Superseded by:** —
**Amends:** HAR-ADR-0007 (adds `task-state.json` to the per-workspace artifact layout; changes agent read protocol from single `state.json` read to two-step index + workspace read), HAR-ADR-0005 (Opt-5 — zero-runtime SAST scoping exception: FAIL verdict is advisory, not blocking, for tasks that change no files under `src/`)
**Amended by:** HAR-ADR-0010 (active subtask field in `task-state.json` changes from ID string to inline object at G3 close; agents read inline object directly, eliminating plan.json from default G4 load path), HAR-ADR-0012 (replaces direct state.json read/write with pipeline_db.py backed by state.db; state.json retained as generated read-only export snapshot only)
**FACT impact:**
- Fast: `improves` — agent startup context cost drops from O(all-tasks) to O(1); only the active task's state is loaded, regardless of how many closed tasks exist in project history
- Accurate: `neutral` — no state content changes; same fields, different file locations; correctness is preserved
- Complete: `improves` — all historical task state is preserved in per-workspace `task-state.json` files; nothing is deleted; `pipeline_metrics.py` traverses `workspace/*/task-state.json` for full reporting
- Trustworthy: `improves` — `task-state.json` has a single writer per task (the orchestrator session owning that workspace); `state.json` index is append-only for `closed_task_index[]`, eliminating concurrent-write contention on the shared file

---

### Context

`.github/pipeline/state.json` (established by HAR-ADR-0007) is a monolithic file containing
full state for every pipeline task ever created, including closed tasks. At 9 tasks it
already reaches 23 KB. Every agent reads the entire file at startup solely to extract
`workspace_path` — three fields from one active task entry. As the project progresses
through Phases 1–6, the file will exceed 100 KB, consuming significant context budget
on every agent invocation. Closed-task data (`completed_artifacts`, `gate_history`)
is never needed again by agents once a task reaches `CLOSED`; it is only consumed by
`pipeline_metrics.py` for historical reporting. The monolithic layout couples all-task
history to every agent's startup read path, creating a cost that grows unboundedly with
project age.

---

### Decision

We will split `state.json` into two artifact types: a slim index file at
`.github/pipeline/state.json` and a full per-workspace `task-state.json` file inside
each `workspace/<spec_id>/` directory.

**Slim index — `.github/pipeline/state.json`:**
- Contains `active_tasks[]`: minimal fields only — `task_id`, `workspace_path`,
  `current_gate`, `work_type`, `created_at`, `description`
- Contains `closed_task_index[]`: tombstone records — `task_id`, `workspace_path`,
  `description`, `work_type`, `current_gate`, `closed_at` (6 fields; `description`, `work_type`,
  `current_gate` carried as read-only metadata so orchestrator can search closed tasks without
  loading `task-state.json`)
- Stays under 2 KB regardless of project age or number of closed tasks

**Per-workspace task state — `.github/pipeline/workspace/<spec_id>/task-state.json`:**
- Contains the full task entry: `current_work`, `active_subtask`, `spec_files`,
  `plan_file`, `completed_artifacts`, `pending_artifacts`, `gate_history`
- Created by the orchestrator at G0 alongside `spec.md`
- Updated in place by the orchestrator throughout the task lifecycle
- Persists permanently after G6 as part of the workspace audit trail

**Agent read protocol (replaces the single `state.json` read from HAR-ADR-0007 §4):**
1. Read `.github/pipeline/state.json` (index, always tiny) → locate the active task
   entry → extract `workspace_path`
2. Read `<workspace_path>/task-state.json` → full state for this task only

**Reporting read protocol:**
- `pipeline_metrics.py` traverses `workspace/*/task-state.json` to aggregate metrics
  across all tasks; it no longer reads `state.json` for task detail fields

---

### Consequences

**Positive:**
- `state.json` context cost becomes constant (< 2 KB) regardless of project history — eliminates the unbounded growth problem
- `task-state.json` is collocated with `spec.md`, `plan.json`, `reviews/`, and `subtasks/` — all task artifacts reside in one directory, simplifying forensic review
- Single writer per `task-state.json` eliminates concurrent-write risk on the full-state file
- `closed_task_index[]` in the slim index provides just enough metadata for orchestrator to locate a closed workspace without loading its full state

**Negative / Trade-offs:**
- Agents now perform two reads at startup instead of one (acceptable: both files are small and targeted; the orchestrator may pre-communicate `workspace_path` to eliminate the second read for downstream agents)
- `pipeline_metrics.py` requires a traversal update to read `workspace/*/task-state.json` instead of the monolithic `state.json`
- Existing `state.json` must be migrated: active-task detail fields moved to their respective `task-state.json` files, leaving only the index fields in `state.json`

**Neutral / Operational notes:**
- The `workspace_path` field in `state.json` (established by HAR-ADR-0007) is preserved unchanged in both the slim index and `task-state.json` — no downstream field renames required
- The orchestrator creates `task-state.json` at G0 alongside the workspace directory; no new gate or approval step is introduced
- Constitution digest and orchestrator instructions must be updated to document the two-step read protocol

---

### Alternatives Considered

| Alternative | Why Rejected |
|-------------|-------------|
| Truncate `state.json` on task close (remove closed-task detail, keep a tombstone) | Destroys historical state that `pipeline_metrics.py` needs; one-way data loss is unacceptable under the FACT trustworthy pillar |
| Compress / summarise closed tasks in place within `state.json` | Requires a summarisation step at G6; adds complexity and risks lossy summarisation; per-workspace files already provide the canonical record |
| Keep monolithic `state.json` but set a hard cap (e.g. last 10 tasks only) | Cap is arbitrary; cap enforcement logic adds failure modes; old workspace directories would be orphaned with no index entry |
| Introduce a separate SQLite database for task state | Overkill for a pipeline control file; adds a binary dependency to the `.github/` tooling layer; JSON files are human-readable and auditable without tooling |

---

### Compliance

- Contract: `constitution/harness/contracts/HAR-C-0002-sdlc-contract.md` — agent gate protocol and workspace artifact layout
- Contract: `constitution/system/contracts/SYS-C-0001-fact-contract.md` — Fast pillar: agent response latency must not grow with project age
- Schema: `constitution/schemas/pipeline-state-schema.json` (if present; update to reflect split structure)
- ADR: `constitution/harness/adrs/HAR-ADR-0007-parallel-task-workspace-isolation.md` — amended by this ADR (workspace artifact layout extended with `task-state.json`)
