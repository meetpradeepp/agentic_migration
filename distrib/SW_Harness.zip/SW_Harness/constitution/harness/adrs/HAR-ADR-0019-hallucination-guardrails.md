﻿## HAR-ADR-0019: Hallucination Guardrails for SDLC Gates

**Status:** Accepted
**Date:** 2026-06-01
**Deciders:** Lead Engineer
**Supersedes:** —
**Superseded by:** —
**Amends:** HAR-C-0002 §6 (gate checklists), shared-rules.md (agent protocol rules)
**Amended by:** —
**FACT impact:**
- Fast: `improves` — mechanical pre-checks at G1 and G5 short-circuit the expensive agent chain before it runs on hallucinated artifacts; saves 2–4 agent invocations per caught case
- Accurate: `improves` — citation integrity, module import proof, and context attestation close the class of "plausible but fabricated" agent outputs that pass per-gate reviews but fail at runtime
- Complete: `neutral` — no change to what the pipeline produces; only improves detection of incorrect artifacts
- Trustworthy: `improves` — every gate claim about ADR citations, module paths, and tool invocations becomes mechanically verifiable rather than AI-attested

---

### Context

{project_name}'s SDLC pipeline relies on AI agents (Copilot) to produce specs, plans, code,
and reviews at every gate. These agents can generate **hallucinated content**: factually
incorrect artifacts that are syntactically plausible and pass superficial review.

The hallucination risk materialises in five confirmed failure patterns, each of which
cleared at least one gate review before being caught downstream:

1. **Hallucinated ADR citations** — an agent writes `Implements: HAR-ADR-0099` (a number
   that does not exist). The `Implements:` field is checked by V1/F4 for file existence,
   but F4 runs only after the spec-writer has completed; the SYNOPSIS.md generation step
   (which copies the ADR's `### Decision` and `### Compliance` sections) would silently
   fail or produce an empty entry, and no prior step blocks on this.

2. **Hallucinated module paths** — the coder generates `from {project_module}.nonexistent.module import
   SomeClass`. Unit tests pass because `SomeClass` is mocked at the test boundary. The
   import error surfaces only at runtime or integration testing. No G5 Step 0 check
   currently validates that new module paths are importable before the expensive review
   agent chain runs.

3. **Stale SAST evidence** — the code-reviewer cites a SAST report from a previous gate
   session ("SAST ran — no critical findings"). The existing SAST-fresh-invocation rule
   (HAR-ADR-0005) requires fresh invocation but provides no mechanical verification that
   the report file was written in the current session. A stale report file silently satisfies
   the rule.

4. **Silent proceed on missing context** — an agent is instructed to load
   `<workspace_path>/adrs/SYNOPSIS.md` but the file is absent (e.g., orchestrator skipped
   the SYNOPSIS generation step due to an incomplete G1 run). The agent proceeds with
   assumed or training-data knowledge about the ADR rather than halting and reporting the
   gap. The resulting spec or plan appears correct but is grounded in hallucinated ADR content.

5. **Hallucinated module references in plans** — the planner lists
   `pattern_scan.existing_modules: ["{src_dir}/workers/nonexistent_worker.py"]`. V4 validates
   the plan structure but does not verify that listed existing modules are real files. A
   planner that hallucinates a module path produces a plan that references a non-existent
   pattern, causing the coder to either import it (runtime error) or ignore it (missed reuse
   opportunity).

These five patterns share a root cause: **agent outputs are validated for structural
correctness but not for referential integrity**. The existing gates trust that cited ADRs,
module paths, and tool invocations are real. No mechanical check closes the gap between
"structurally valid" and "factually grounded."

The five fixes introduced by this ADR are all mechanical (zero LLM cost) or protocol-only,
and are consistent with the Step 0 pre-gate philosophy established for G5 (HAR-ADR-0008 §Opt-1).

---

### Decision

We will add **five targeted hallucination guardrails** across three pipeline gates. No
existing gate is removed or weakened. No new agent is introduced. No approval gate is added.

---

**Guardrail 1 — G1: SYNOPSIS.md Completeness Block (orchestrator)**

After the orchestrator generates `<workspace_path>/adrs/SYNOPSIS.md` at G1, and before
invoking V1, the orchestrator MUST verify:

a. The count of entries in SYNOPSIS.md equals the count of `Implements: HAR-ADR-NNNN` (or
   `SYS-ADR-NNNN`) references in the spec header.
b. Each entry in SYNOPSIS.md contains a non-empty `**Decision:**` paragraph and a non-empty
   `**Compliance:**` section.

**If either condition fails:** BLOCK — do not invoke V1. Log the specific missing entry or
empty field. The orchestrator requests the spec-writer to correct the `Implements:` citation
(if the ADR does not exist) or the adr-writer to fix the ADR structure (if the ADR exists but
lacks the mandatory sections).

This check takes < 1 second (file read + string search) and catches hallucinated ADR numbers
before V1 burns tokens on a doomed validation pass.

---

**Guardrail 2 — G5 Step 0: Module Import Proof**

Add as the fifth check in the G5 Step 0 pre-mechanical gate (after the existing four: ruff,
TDD order, coverage, MagicMock):

For each new module path created in G4, resolve `spec_exports` from `plan.json` and run:
```
python -c "from {project_module}.<module_path> import <exported_class>"
```
where `<module_path>` and `<exported_class>` come from the `spec_exports` field of the
subtask's entry in `plan.json`.

**If any import raises `ImportError` or `ModuleNotFoundError`:** return to `@coder`
immediately. Do not invoke Steps 1–4 (SAST, code-reviewer, tester, validator). Log the
failing import command verbatim.

**Scope:** Only new modules created in this G4 pass (files that did not exist before G4 began).
Existing modules are assumed importable; if they are broken, `ruff check` will catch it first.

---

**Guardrail 3 — G5 Step 0: SAST Report Timestamp Verification**

Add as the sixth check in the G5 Step 0 pre-mechanical gate:

Verify that `<workspace_path>/reviews/sast-report.md` (or `sast-<date>.md`) has a file
modification time (`mtime`) that falls within the current gate session window. The session
window is defined as: no earlier than the `updated_at` timestamp of the most recent
`current_gate = "G5"` entry in `task-state.json`.

**If the report file is absent or its mtime predates the session window:** treat SAST as "not
run" — return to Step 1 (invoke `@sast` fresh). Do not allow code-reviewer to proceed with
stale SAST evidence.

**If no `sast-report.md` exists at all:** treat as "not run" regardless of session window.

---

**Guardrail 4 — shared-rules: Context Load Attestation Protocol (new §19)**

All agents that are instructed to load specific workspace or constitution files MUST follow
this protocol:

a. **On successful load:** Log `[LOADED] <relative-path> (<size> bytes)` as the first line
   of the response preamble, before any analysis content. One line per file loaded.
b. **On missing file:** Immediately halt and respond with:
   `CONTEXT_INCOMPLETE: <relative-path> — required file not found. Reporting to orchestrator.`
   Do not proceed with assumed, inferred, or training-data content as a substitute.
c. **Session-persistent files (§18):** Files that are session-persistent (e.g., `spec.md`,
   `SYNOPSIS.md`, `HAR-C-0008`) require attestation only on their FIRST load in a session.
   On subsequent subtasks in the same G4 session, the agent may log
   `[SESSION-CACHED] <relative-path>` instead of re-loading. No re-attestation required.

**Scope:** Applies to all agents. Validators and spec-reviewers (which load full contracts)
attest to each contract file loaded. Orchestrator attests to workspace artifacts it opens.

**What attestation is NOT:** Attestation is a preamble log line, not a verbal claim embedded
in analysis prose. The validator (V3) fast-path rule (§18) is unaffected — `file:line`
citations in PASS items remain the evidence standard for review completeness.

---

**Guardrail 5 — V4: Pattern Scan File Existence Check**

Add to the V4 Plan Compliance Scan checklist (after V4.10 from HAR-ADR-0013):

**V4.11 — Pattern scan module existence:**
For each path listed in `plan.json → pattern_scan.existing_modules`, verify the file exists
at that path under `{src_dir}/` using a filesystem check (`os.path.exists` equivalent).

**FAIL condition:** Any listed path that does not exist in `{src_dir}/` is a planner
hallucination. Report: `V4.11 FAIL: pattern_scan path '{src_dir}/X/Y.py' does not exist`.
The planner must correct the plan before G4 begins.

**PASS condition (trivially):** If `pattern_scan.existing_modules` is an empty list (new spec
with no adjacent modules), V4.11 PASS automatically.

---

### Consequences

**Positive:**

- All five guardrails are pre-checks or protocol additions — zero new agent invocations on
  the happy path.
- Guardrails 1 and 2 extend the Step 0 short-circuit philosophy: problems are caught before
  the expensive agent chain runs, not after.
- Guardrail 4 (context attestation) makes session-persistence (§18) explicit: the first load
  is logged, subsequent subtasks log `[SESSION-CACHED]`. This turns an implicit LLM context
  assumption into a verifiable audit trail.
- Guardrail 3 closes a compliance gap in HAR-ADR-0005: the SAST-fresh rule now has a
  mechanical enforcement mechanism (file mtime) rather than relying on reviewer attestation.

**Negative / Trade-offs:**

- Guardrail 4 adds ~20 tokens of attestation overhead per agent session start (3–5 `[LOADED]`
  lines). This is negligible relative to spec/plan/review content.
- Guardrail 2 requires that `spec_exports` is correctly populated in `plan.json`. If a plan
  predates HAR-ADR-0018 (plan templates, spec_exports binding — §15), it will not have
  `spec_exports` and the import check cannot run. For pre-0018 plans: skip Guardrail 2 and
  note `[SKIP: no spec_exports in plan]` in the G5 Step 0 output.

**Neutral / Operational notes:**

- Guardrail 1 is orchestrator-internal; it does not require agent instruction changes.
- Guardrails 2 and 3 extend the G5 Step 0 section in `orchestrator.agent.md`.
- Guardrail 4 is a new §19 in `shared-rules.md`; all agents load `shared-rules.md` as part
  of their context-loading protocol (HAR-ADR-0002).
- Guardrail 5 adds V4.11 to `validator.agent.md`; no other V-scan is affected.

---

### Alternatives Considered

| Alternative | Why Rejected |
|---|---|
| Full hallucination scoring (automated confidence metric per agent output) | Requires LLM at validation time — violates core principle (no LLM in runtime). Guardrails are deterministic. |
| Citation resolver script (scan spec for all NNNN references, verify files) | Could be added as a VM.5 script; deferred — Guardrail 1 covers the highest-risk path (Implements: citations) at the lowest cost. VM.5 can be added in a later enhancement. |
| Re-running agents with explicit "did you load X?" prompts | Adds agent invocations to the happy path. Rejected in favour of protocol attestation (Guardrail 4) which adds zero invocations. |
| Making SAST timestamp check a G5 Step 1 (agent) check | Step 1 invokes `@sast`. Mtime check is a 1ms file stat that belongs in Step 0 (orchestrator-only). Moved to Step 0. |
| Requiring V4.11 only for ENHANCEMENT tasks | All work types use `pattern_scan`; narrowing the check introduces a class of escapes. Apply uniformly; trivially skipped when `existing_modules` is empty. |

---

### Compliance

- Contract: `constitution/harness/contracts/HAR-C-0002-sdlc-pipeline.md` §6 (gate checklists — G1, G5 Step 0, V4)
- Contract: `constitution/harness/contracts/HAR-C-0002-sdlc-pipeline.md` §1 (spec before code — Guardrail 1 enforces this earlier)
- Memory: `.github/memory/shared-rules.md` §19 (Context Load Attestation — added by this ADR)
- Agent: `.github/agents/orchestrator.agent.md` (G1 gate check, G5 Step 0 checks 5 and 6)
- Agent: `.github/agents/validator.agent.md` (V4.11 — pattern scan module existence)
- Related: `HAR-ADR-0005` (SAST toolchain — Guardrail 3 closes the SAST freshness enforcement gap)
- Related: `HAR-ADR-0008` (G5 Step 0 pre-mechanical gate — Guardrails 2 and 3 extend this)
- Related: `HAR-ADR-0013` (V4 cross-module checks — Guardrail 5 adds V4.11 to the same checklist)
- Related: `HAR-ADR-0018` (spec_exports binding — Guardrail 2 depends on spec_exports being present)
- Eval: No new eval suite required — guardrails are deterministic checks with binary PASS/FAIL outcomes
