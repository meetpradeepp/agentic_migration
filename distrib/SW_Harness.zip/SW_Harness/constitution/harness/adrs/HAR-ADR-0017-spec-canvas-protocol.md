﻿## HAR-ADR-0017: Spec Canvas Protocol — Orchestrator Pre-fills Deterministic Spec Fields at G1

**Status:** Accepted
**Date:** 2026-06-01
**Deciders:** Lead Engineer
**Supersedes:** —
**Superseded by:** —
**Amends:** HAR-C-0002 §2 (spec creation workflow at G1)
**Amended by:** —
**FACT impact:**
- Fast: `improves` — spec-writer invocations begin from a pre-validated skeleton; deterministic fields are never reconstructed from scratch; revision cycles for structural violations drop
- Accurate: `neutral` — novel spec content (problem statement, ACs, data model, events) is still written entirely by the spec-writer; no reduction in content quality
- Complete: `neutral` — spec coverage is unchanged; only the creation workflow changes
- Trustworthy: `improves` — SPEC-NNNN assignment, phase tagging, contract references, and section headings are sourced deterministically from the constitution rather than recalled from memory

---

### Context

Spec creation at G1 requires the spec-writer to:
1. Look up the next SPEC-NNNN number (next-number skill).
2. Set the phase, date, status, and frontmatter fields correctly.
3. Identify and list the relevant contracts from the ADRs the spec implements.
4. Emit all 10 mandatory HAR-C-0002 §2 section headings in the exact order.
5. Verify that the spec ID in the filename matches the frontmatter `id:` field.

Steps 1–5 are **deterministic** — they can be computed entirely from the pipeline state
(`state.json`, the next-number skill, and the referenced ADRs) before the spec-writer
is invoked. Yet the spec-writer performs these steps on every invocation, consuming tokens
on reconstructing fields that the orchestrator already knows.

When the spec-writer gets these fields wrong (wrong SPEC number, missing section heading,
wrong phase), the V1 scan fails and the spec is returned for structural fixes — a round-trip
that costs 1–2 extra conversation turns and resolves no content question.

In a sample of 10 completed FULL tasks, 6 required at least one V1 round-trip for structural
violations (missing section, wrong status value, frontmatter field order). All 6 were
structural, not content, failures.

---

### Decision

We will introduce a **Spec Canvas** — a pre-populated spec skeleton that the orchestrator
writes to `<workspace_path>/spec-canvas.md` at the start of G1, before invoking the
spec-writer.

**Canvas content (orchestrator fills all of this):**

```markdown
---
id: SPEC-NNNN
title: <placeholder — spec-writer fills>
status: Draft
phase: N
created: YYYY-MM-DD
implements:
  - <ADR-XXXX from G0 triage ADR list>
  - …
relevant_contracts:
  - <contract file path — derived from ADR implements: fields>
  - …
---

## 1. Problem Statement
<!-- spec-writer fills -->

## 2. Solution Overview
<!-- spec-writer fills -->

## 3. Detailed Design
<!-- spec-writer fills -->

## 4. Acceptance Criteria
<!-- spec-writer fills: AC-01, AC-02, … -->

## 5. Data Model
<!-- spec-writer fills -->

## 6. Events
<!-- spec-writer fills -->

## 7. Test Strategy
<!-- spec-writer fills: T-01, T-02, … -->

## 8. Open Questions
<!-- spec-writer fills or writes "None." -->

## 9. Dependencies
<!-- spec-writer fills -->

## 10. Deviations
_To be filled at implementation time._
```

**Derivation rules for orchestrator:**
- `id`: from next-number skill output at G0.
- `phase`: from `phase-status.md` current phase.
- `created`: current date.
- `implements`: ADRs identified in G0 triage.
- `relevant_contracts`: for each ADR in `implements`, read its `### Compliance` section and
  extract referenced contracts. Deduplicate.

**Spec-writer instruction (already in `spec-writer.agent.md`):**
The spec-writer reads `<workspace_path>/spec-canvas.md` as its starting document. It fills in
the content sections only. It MUST NOT change the `id`, `phase`, `status`, `created`,
`implements`, or `relevant_contracts` fields — these are locked by the orchestrator. If the
spec-writer believes a canvas field is wrong, it flags the discrepancy in a comment but does
not change the field; the orchestrator resolves the discrepancy before the spec proceeds.

**Scope:**
- Applies to NEW_FEATURE and SPEC_REWRITE work types.
- For BUG_FIX and ENHANCEMENT, `@spec-patcher` operates on an existing spec; no canvas needed.
- The canvas file (`spec-canvas.md`) lives only in the workspace. The final spec is written
  to `specs/phase-N/SPEC-NNNN-<name>.md`. The canvas is not committed.

---

### Consequences

**Positive:**

- Structural V1 failures (wrong SPEC number, missing section heading, wrong phase) are
  eliminated because the skeleton is already valid before the spec-writer runs.
- Spec-writer token cost reduced by ~15–20% per invocation (no deterministic reconstruction).
- Contract references are sourced from ADR compliance sections, not recalled from memory,
  reducing the likelihood of missing a relevant contract.

**Negative / Trade-offs:**

- The orchestrator gains a pre-G1 action (canvas generation). This adds one tool call per
  NEW_FEATURE task.
- If the canvas derivation rules produce a wrong contract reference (e.g., an ADR
  `Compliance` section is stale), the error propagates into the spec. Mitigated by: V1 scan
  still checks contract references, and spec-reviewer checks at G2.

**Neutral / Operational notes:**

- The canvas does not replace the spec-writer; it is a structured input to the spec-writer,
  not a substitute for spec-writing judgment.
- `spec-canvas.md` is a workspace artifact, not a committed file. It is never part of the
  git history.

---

### Alternatives Considered

| Alternative | Why Rejected |
|-------------|-------------|
| Have the spec-writer load next-number skill | Spec-writer already does this; the overhead is in the spec-writer having to execute the skill, not in the skill itself. Canvas pre-fills the output. |
| Spec template in `.github/memory/` | Static templates cannot include the dynamic SPEC-NNNN, phase, date, or contract references; they reduce to the same manual fill step |
| Let V1 catch structural errors (status quo) | Status quo produces 6/10 unnecessary round-trips; the canvas eliminates the error class at source |

---

### Compliance

- Contract: `constitution/harness/contracts/HAR-C-0002-sdlc-contract.md` §2 — G1 spec creation workflow extended by this ADR; canvas generation is a pre-G1 orchestrator action
- Orchestrator agent: `orchestrator.agent.md` updated to document canvas generation at G1 start
- Spec-writer agent: `spec-writer.agent.md` updated to read `spec-canvas.md` as starting document
