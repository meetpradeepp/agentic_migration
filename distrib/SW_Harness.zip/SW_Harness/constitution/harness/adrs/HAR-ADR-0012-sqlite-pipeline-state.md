﻿## HAR-ADR-0012: SQLite-Backed Pipeline State

**Status:** Accepted
**Date:** 2026-05-30
**Deciders:** Lead Engineer, Architecture Review
**Supersedes:** —
**Superseded by:** —
**Amends:** HAR-ADR-0008 (replaces direct JSON read/write of `state.json` with `pipeline_db.py` helper backed by `state.db`; retains `state.json` as a generated read-only export snapshot only)
**Amended by:** —
**FACT impact:**
- Fast: `neutral` — read latency is unchanged for agents; `pipeline_db.py` reads are O(1) by primary key and are faster than a full JSON parse; write path adds an exclusive lock acquire that is negligible at < 50 concurrent sessions
- Accurate: `improves` — WAL-mode exclusive write transactions eliminate the last-writer-wins race condition; two concurrent agent sessions can no longer silently corrupt the task index
- Complete: `neutral` — no state content changes; same fields, same task lifecycle; all historical closed-task entries are preserved in `closed_task_index`
- Trustworthy: `improves` — SQLite write-ahead log provides atomic, durable writes; `state.json` remains as a human-readable audit export regenerated after every commit; `state.db` is the authoritative record

---

### Context

`state.json` (established by HAR-ADR-0007, split into slim-index format by HAR-ADR-0008)
is a plain JSON file written by the orchestrator at every gate transition. It has no
write-locking mechanism. As the project expands to support multiple concurrent VS Code chat
sessions working on independent tasks, a last-writer-wins race condition becomes structurally
inevitable: two orchestrator sessions can read the file, each mutate their own copy in
memory, and one silently overwrites the other's gate transition. This produces corrupted
`active_tasks[]` entries with stale `current_gate` values or missing task entries entirely —
both of which are invisible at write time and are discovered only when a downstream agent
fails to locate its task. `scripts/next_number.py` already demonstrated the correct
pattern for this class of problem: SQLite with `BEGIN EXCLUSIVE` transactions on a local
`.db` file provides deterministic, process-safe serialisation with zero daemon or network
dependency. That pattern — proven in production across hundreds of `SPEC`/`ADR`/`Contract`
number claims — is the model `state.db` follows.

---

### Decision

We will replace direct `state.json` read/write with a thin Python helper module,
`.github/pipeline/pipeline_db.py`, backed by a SQLite database at `.github/pipeline/state.db`
running in WAL mode.

**Storage location:**
- `state.db` lives alongside `state.json` at `.github/pipeline/`
- WAL mode (`PRAGMA journal_mode=WAL`) is set on first open; it persists for the lifetime of the file

**Schema — two tables mirroring the current `state.json` structure:**

```sql
CREATE TABLE IF NOT EXISTS active_tasks (
    task_id       TEXT PRIMARY KEY,
    workspace_path TEXT NOT NULL,
    description   TEXT NOT NULL,
    current_gate  TEXT NOT NULL,
    work_type     TEXT NOT NULL,
    created_at    TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS closed_task_index (
    task_id       TEXT PRIMARY KEY,
    workspace_path TEXT NOT NULL,
    description   TEXT NOT NULL,
    current_gate  TEXT NOT NULL,
    work_type     TEXT NOT NULL,
    closed_at     TEXT NOT NULL
);
```

**Locking protocol:**
- All writes use `BEGIN EXCLUSIVE` transactions — no implicit commit
- Reads do NOT require an exclusive lock (WAL readers are non-blocking)
- The helper serialises access within a single process; OS-level locking handles cross-process safety

**Public helper API (`.github/pipeline/pipeline_db.py`):**

| Function | Used by | Effect |
|---|---|---|
| `get_active_tasks() → list[dict]` | orchestrator | SELECT * FROM active_tasks |
| `add_task(task_id, workspace_path, description, current_gate, work_type, created_at)` | orchestrator | INSERT INTO active_tasks; regenerate state.json |
| `update_gate(task_id, new_gate)` | orchestrator | UPDATE active_tasks SET current_gate; regenerate state.json |
| `close_task(task_id, closed_at)` | orchestrator, release-manager | Move active → closed; regenerate state.json |

Every write function calls `_regenerate_state_json()` as its final step.

**`state.json` snapshot (retained, read-only export):**
- Retained at `.github/pipeline/state.json` for human readability and git diff audit
- Carries `"_GENERATED": true` and `"_source": "state.db"` headers
- Regenerated deterministically after every write via `_regenerate_state_json()` inside `pipeline_db.py`
- **Never edited directly** — any direct edit is silently overwritten on the next write
- Format remains identical to the HAR-ADR-0008 slim-index structure so existing git history is readable

**One-time migration:**
- `python .github/pipeline/pipeline_db.py --migrate` reads the current `state.json` and seeds `state.db`
- Idempotent: re-running on an already-migrated DB is a no-op (INSERT OR IGNORE)
- Existing workspace directories (`workspace/SPEC-NNNN/`) are unchanged — this migration only affects the index

**Scope boundary — what is NOT affected:**
- `task-state.json` (workspace-scoped): remains a JSON file; single-writer-by-design (one orchestrator session per task); no locking needed
- `number-registry.db` (from `next_number.py`): a separate SQLite DB for ID allocation; governed by its own logic; HAR-ADR-0012 does not affect it

**A6 anti-pattern exception:**
HAR-C-0004 A6 bans `sqlite3.connect` in business logic. `pipeline_db.py` is **harness-only
infrastructure** — it governs agent coordination, not {project_name} runtime product logic. The
A6 rule targets code under `{src_dir}/`; `pipeline_db.py` lives under `.github/pipeline/`
and is never imported by product code. This use is explicitly permitted.

---

### Consequences

**Positive:**
- Concurrent agent sessions can no longer corrupt the task index — exclusive write locks serialise all mutations
- WAL mode allows simultaneous readers without blocking writes, preserving the fast read path
- `state.json` is retained as a human-readable, git-diffable export with zero cost — it is regenerated deterministically
- Migration is a single command; no agent protocol changes needed beyond substituting `pipeline_db.py` calls for direct JSON reads
- The pattern is already proven: `next_number.py` uses identical SQLite + `BEGIN EXCLUSIVE` semantics without incident

**Negative / Trade-offs:**
- `state.db` is a binary file — it is not human-readable in isolation; `state.json` mitigates this for audit purposes
- Any agent or script that bypasses `pipeline_db.py` and edits `state.json` directly will have its changes silently overwritten on the next write; this is by design but requires clear documentation
- Adding `state.db` to `.gitignore` would break cross-machine portability; it MUST be committed to the repository alongside `state.json`

**Neutral / Operational notes:**
- `state.db` is committed to git; WAL mode produces a `-wal` and `-shm` sidecar during active writes; these should be added to `.gitignore` (they are ephemeral and never needed across machines)
- `pipeline_db.py --migrate` should be run once after merging this ADR; subsequent runs are safe no-ops
- All references to "read `state.json`" in agent `.md` files are replaced with "call `pipeline_db.py get_active_tasks()`"; references in `orchestrator.agent.md` and `release-manager.agent.md` are updated as part of this ADR's implementation

---

### Alternatives Considered

| Alternative | Why Rejected |
|-------------|-------------|
| File locking on `state.json` (e.g. `fcntl.flock` or a `.lock` sidecar file) | Cross-platform unreliable (Windows does not honour `fcntl`); stale lock files on crash require manual cleanup; SQLite's WAL mechanism is safer and already proven in this codebase |
| Centralised state daemon (HTTP or socket) | Adds a long-running process dependency to harness infrastructure; daemon crashes require recovery; violates the zero-daemon principle of the `.github/` tooling layer |
| PostgreSQL / shared database for pipeline state | Gross overengineering for a file that tracks ≤ 50 concurrent tasks; requires a running Postgres instance just to read the active gate; SQLite is self-contained and sufficient |
| Keep plain JSON + process-level mutex (threading.Lock) | Ineffective: each VS Code chat session is a separate OS process; in-process locks do not protect against inter-process races |
| Abandon concurrent sessions, enforce single-writer by convention | Convention enforcement is not machine-verifiable; silent corruption is worse than the cure; explicit locking is the correct solution |

---

### Compliance

**Agent protocol changes:**

- `orchestrator.agent.md` — reads active tasks via `pipeline_db.py get_active_tasks()`; writes new tasks via `pipeline_db.py add_task()`; advances gate via `pipeline_db.py update_gate()`; closes task via `pipeline_db.py close_task()`
- `release-manager.agent.md` — closes tasks via `pipeline_db.py close_task()`; does NOT regenerate `state.json` manually (regeneration is automatic inside `close_task()`)
- All other agents (`spec-writer`, `spec-patcher`, `adr-writer`, `planner`, `coder`, `tester`, `refactor`, `validator`, `code-reviewer`) — read `workspace_path` from `task-state.json` (workspace-scoped, already loaded); do NOT read `state.json` or `state.db` directly

**Contract references:**

- Contract: `constitution/harness/contracts/HAR-C-0002-sdlc-contract.md` — agent gate protocol; orchestrator write obligations
- Contract: `constitution/harness/contracts/HAR-C-0004-anti-patterns.md` — A6 anti-pattern (sqlite3.connect in business logic); `pipeline_db.py` is harness infrastructure, not business logic — the A6 ban does not apply
- Contract: `constitution/system/contracts/SYS-C-0001-fact-contract.md` — Trustworthy pillar: pipeline state must be durable and free of silent corruption

**Git hygiene:**

- `state.db` — committed to git (canonical pipeline state)
- `state.db-wal`, `state.db-shm` — added to `.gitignore` (WAL mode ephemeral sidecars)

---

### Amendment Index

| Date | Amended by | Change |
|---|---|---|
| — | — | — |
