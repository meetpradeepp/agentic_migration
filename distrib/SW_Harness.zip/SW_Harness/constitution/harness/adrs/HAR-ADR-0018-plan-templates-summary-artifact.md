﻿## HAR-ADR-0018: Plan Templates and Summary Artifact — Planner Efficiency at G3

**Status:** Accepted
**Date:** 2026-06-01
**Deciders:** Lead Engineer
**Supersedes:** —
**Superseded by:** —
**Amends:** HAR-C-0002 §3 (plan creation at G3) and §6 (code review TDD order verification)
**Amended by:** —
**FACT impact:**
- Fast: `improves` — planner token cost reduced ~30% for recurring worker specs via pre-built templates; code-reviewer plan-reading cost reduced ~96% via 2KB summary instead of 64KB plan
- Accurate: `neutral` — plan content and TDD order checking accuracy unchanged; only the format of the TDD evidence changes
- Complete: `neutral` — all subtask planning requirements unchanged
- Trustworthy: `improves` — plan-summary.json provides a tamper-evident TDD order record that is faster to verify than scanning the full plan for commit type sequencing

---

### Context

Two distinct inefficiencies were measured at G3 and G5:

**Problem 1 — Planner re-creates identical subtask structures for every worker spec.**

Phase-3 worker specs consistently produce plans with the same structural pattern:
- 3–5 subtasks: unit tests for data/utility classes (atomic pairs)
- 3–5 subtasks: unit tests for the worker class itself (atomic pairs)
- 1–2 subtasks: integration tests
- 1 subtask: migration/schema (if applicable)

The planner writes these structures from scratch for each new worker spec, consulting the
spec to determine module names and subtask counts. The structural decision (which types of
subtasks to create, in what order, with what dependencies) is fully determined by the
worker pattern; only the content (class names, file paths, test IDs) varies per spec.

Across Phase 3's worker specs (SPEC-0024, SPEC-0025, and anticipated SPEC-0026 through
SPEC-0029), the planner reconstructs this identical structure 4–6 times.

**Problem 2 — Code-reviewer loads the full plan.json (up to 64KB) to verify TDD order.**

The code-reviewer's TDD order check requires knowing: for each `feat(...)` commit, was
there a preceding `test(...)` commit for the same component? The plan already encodes this
dependency (each implementation subtask has a `depends_on` pointing to its test subtask).

However, the code-reviewer accesses this by loading the full `plan.json`, which also contains
the complete subtask descriptions, file lists, estimated line counts, and spec_exports
structures for all 20+ subtasks. This is 64KB of context for a check that needs ~2KB.

---

### Decision

We will introduce two artifacts: **plan templates** and **plan-summary.json**.

---

**1 — Plan Templates (`.github/memory/plan-templates/`)**

Phase-specific plan templates live in `.github/memory/plan-templates/`. Each template is a
JSON skeleton with parametrised subtask structures. The planner reads the appropriate
template and substitutes values from the spec.

```
.github/memory/plan-templates/
  phase-3-worker.json       ← standard worker (consumer → processor → emitter)
  phase-3-mcp-tool.json     ← MCP query tool (query class → result class → tool class)
  phase-1-migration.json    ← schema migration + migration test subtask pair
```

Template structure (phase-3-worker.json excerpt):
```json
{
  "template_id": "phase-3-worker",
  "description": "Standard Phase 3 message-broker worker: data classes → utility modules → worker class → integration",
  "subtask_patterns": [
    {
      "pattern": "data_class_pair",
      "type_test": "unit_test",
      "type_impl": "implementation",
      "atomic_approval": true,
      "estimated_test_lines": 30,
      "estimated_impl_lines": 40
    },
    {
      "pattern": "worker_class_pair",
      "type_test": "unit_test",
      "type_impl": "implementation",
      "atomic_approval": true,
      "estimated_test_lines": 60,
      "estimated_impl_lines": 80
    },
    {
      "pattern": "integration_test",
      "type": "integration_test",
      "atomic_approval": false,
      "estimated_lines": 150
    }
  ]
}
```

**Planner instruction:** The planner reads `<workspace_path>/spec.md` to determine which
template applies (single worker → `phase-3-worker`; MCP tool → `phase-3-mcp-tool`). It
instantiates the template, filling in module names, class names, file paths, test IDs, and
spec export names from the spec. It does NOT skip the spec analysis step — the template
provides structure, the planner provides content.

When no template matches, the planner falls back to full from-scratch planning.

---

**2 — Plan Summary Artifact (`<workspace_path>/plan-summary.json`)**

The orchestrator generates `plan-summary.json` at G3 close (after `plan.json` is approved),
by extracting TDD-order-critical fields only:

```json
{
  "spec_id": "SPEC-NNNN",
  "generated_at": "YYYY-MM-DDThh:mm:ssZ",
  "subtask_count": 23,
  "tdd_pairs": [
    {
      "test_subtask_id": "SPEC-NNNN-T01",
      "impl_subtask_id": "SPEC-NNNN-T02",
      "component": "ClusterStabilizer",
      "atomic_approval": true
    },
    ...
  ],
  "integration_subtasks": ["SPEC-NNNN-T23"],
  "spec_exports": {
    "SPEC-NNNN-T02": ["ClusterStabilizer", "TOPOLOGY_STABILIZER_MIN_DELTA"],
    ...
  }
}
```

**Code-reviewer instruction:** At G5, the code-reviewer reads `plan-summary.json` for TDD
order verification instead of `plan.json`. The reviewer confirms that for every `tdd_pairs`
entry, the `test_subtask_id` commit precedes the `impl_subtask_id` commit in `git log`. The
full `plan.json` is available in the workspace for any reviewer who needs additional subtask
context, but the TDD order check does not require it.

**Generation rule:** The orchestrator generates `plan-summary.json` by reading `plan.json`
once at G3 close and extracting the fields above. No agent is invoked for this step; it is a
deterministic extraction by the orchestrator.

---

### Consequences

**Positive:**

- Planner token cost for Phase-3 worker specs reduced by ~30% (template provides structural
  skeleton; planner fills content only).
- Code-reviewer plan-loading cost reduced from 64KB to ~2KB per G5 invocation (~96%).
- `atomic_approval` flags from HAR-ADR-0015 are pre-populated in the template,
  ensuring new plans get correct default values.
- `spec_exports` in the summary gives the code-reviewer a fast check surface for export
  name drift without loading the full plan.

**Negative / Trade-offs:**

- Plan templates require maintenance: when the standard worker pattern evolves (e.g., a new
  mandatory subtask type is added in Phase 4), the template must be updated.
- `plan-summary.json` is derived from `plan.json`; if `plan.json` is amended mid-G4, the
  summary must be regenerated. The orchestrator regenerates it whenever `plan.json` changes.

**Neutral / Operational notes:**

- Templates are advisory, not mandatory. The planner may deviate from a template when the
  spec requires a different structure, documenting the deviation in the plan's top-level
  `"template_deviation"` field.
- `plan-summary.json` does not replace `plan.json`. The full plan remains the authoritative
  source for subtask execution. The summary is a derived read-optimised view.
- Template files are committed to `.github/memory/plan-templates/` as part of this ADR's
  release commit.

---

### Alternatives Considered

| Alternative | Why Rejected |
|-------------|-------------|
| Store plan.json in a compressed format | Code-reviewer still loads the full decompressed content; problem is context budget, not storage |
| Have code-reviewer only check git log (skip plan.json entirely) | git log does not encode which test subtask is paired with which impl subtask; pairing context is essential for TDD order verification |
| Per-phase copilot-instructions snippets | Copilot instructions are per-agent config, not structured data; subtask patterns need to be machine-readable for the planner to instantiate them |

---

### Compliance

- Contract: `constitution/harness/contracts/HAR-C-0002-sdlc-contract.md` §3 — G3 plan creation workflow extended by this ADR; plan-summary.json is a mandatory G3 output
- Contract: `constitution/harness/contracts/HAR-C-0002-sdlc-contract.md` §6 — G5 code review TDD order check now uses plan-summary.json as primary evidence
- Plan template files: `.github/memory/plan-templates/phase-3-worker.json`, `.github/memory/plan-templates/phase-3-mcp-tool.json`, `.github/memory/plan-templates/phase-1-migration.json` (committed with this ADR)
- `plan-summary.json` schema is informally defined by the JSON structure above; a formal JSON Schema will be added in the next schema maintenance task
