﻿## HAR-ADR-0015: TDD-Unit Atomic Approval — Paired Subtask Advancement in G4

**Status:** Accepted
**Date:** 2026-06-01
**Deciders:** Lead Engineer
**Supersedes:** —
**Superseded by:** —
**Amends:** HAR-C-0002 §1 (G4 approval cadence)
**Amended by:** —
**FACT impact:**
- Fast: `improves` — approval gate count drops from ~2.78× to ~1.2× per completed subtask; session velocity increases
- Accurate: `neutral` — TDD Red→Green proof is still required before the joint approval; no quality reduction
- Complete: `neutral` — all subtasks still complete; pairing reduces ceremony, not coverage
- Trustworthy: `improves` — fewer stop/restart cycles reduce the probability of context drift between test and implementation commits

---

### Context

A measurement across 11 implementation plans (103 gate approvals / 37 completed subtasks)
showed a 2.78× approval overhead: the orchestrator stops for user approval after the test
commit (Red) and again after the implementation commit (Green). For a 23-subtask plan, this
produces 46 mandatory approval stops for the test+implementation subtask pairs alone.

The approval protocol was designed to ensure the user sees both the failing test (proof of
Red) and the passing implementation (proof of Green). In practice, for straightforward unit
subtasks — a single function, a small data class, a constant definition — presenting both
together at Green is equally informative and halves the approval cost.

The overhead is most pronounced for **trivial unit subtasks**: those with ≤50 implementation
lines, ≤30 test lines, and no inter-subtask dependencies. Integration test subtasks, subtasks
that introduce a new public interface, and subtasks with `blocked_on` dependencies retain the
original two-approval protocol because the user needs to review the Red test before approving
the implementation direction.

---

### Decision

We will introduce **TDD-Unit Atomic Approval** for qualifying subtasks in FULL mode.

**Qualifying conditions (all must be true):**
1. Subtask type is `unit_test` + `implementation` paired (back-to-back in plan, with the test
   subtask immediately preceding the implementation subtask for the same component).
2. The subtask has no `blocked_on` cross-spec dependency.
3. The subtask does not introduce a new public interface (no new class, exported function, or
   constant on the module's public surface that other specs depend on).
4. The orchestrator has set `"atomic_approval": true` based on explicit user consent at G3 close.

**Protocol for qualifying pairs:**
1. `@coder` writes the test commit (`test(...)`). Tests fail (Red). **No approval stop.**
2. `@coder` writes the implementation commit (`feat(...)`). Tests pass (Green).
3. **Single approval stop** — orchestrator presents both commits together. User approves once.
4. Gate advances to the next subtask pair.

**Non-qualifying subtasks retain the original two-stop protocol:**
- Integration test subtasks (Docker-dependent)
- Subtasks introducing a new public interface
- Subtasks with `blocked_on` non-null
- Subtasks where the orchestrator has not set `"atomic_approval": true`
- Any subtask in PATCH or HOTFIX mode (those modes already have reduced approval stops)

**Orchestrator responsibility (G3 close):**
After the user approves the plan, the orchestrator asks: *"Do you want atomic approval for
qualifying unit test+impl pairs? One approval stop per pair instead of two."*
- If **yes**: orchestrator identifies all back-to-back test+impl pairs with no `blocked_on`
  and no new cross-spec public interface, sets `"atomic_approval": true` on both subtasks in
  `plan.json`, and regenerates `plan-summary.json`.
- If **no**: all pairs remain `"atomic_approval": false`. No further action.
Line count is irrelevant — a 300-line single-responsibility pair is equally safe as a 30-line one.

**Planner responsibility:**
The planner sets `"atomic_approval": false` on all subtasks by default. The orchestrator
overrides qualifying pairs to `true` at G3 close based on user consent.

**Coder responsibility:**
When `atomic_approval` is `true`, the coder does not stop after the test commit. It proceeds
directly to the implementation commit. If the implementation fails to make the tests pass on
the first attempt, the coder presents the failing state and requests a single approval to
debug. The two-stop protocol resumes for that subtask only.

---

### Consequences

**Positive:**

- Approval overhead drops from ~2.78× to ~1.2× per completed subtask for a typical
  Phase-3 plan (where ~70% of subtasks qualify as trivial pairs).
- Session velocity improves; large plans (20+ subtasks) no longer require 40+ micro-approvals.
- TDD discipline is fully preserved: the Red→Green proof still exists in the commit history.

**Negative / Trade-offs:**

- User sees the failing test only in the combined presentation, not as a standalone approval
  point. For rare cases where the test design is wrong, the user must catch this at Green.
- The planner adds complexity by evaluating `atomic_approval` per pair; incorrect
  classification (marking a complex subtask as trivial) passes overhead to the user.

**Amended (2026-06-06):** Line-count condition removed. Planner heuristic replaced by
explicit orchestrator G3-close user prompt. Qualifying conditions reduced from 5 to 4.
Rationale: line count is a poor proxy — size does not determine whether seeing the Red gate
adds value; single-responsibility and no-interface constraints do. User consent is the
authoritative gate.

**Neutral / Operational notes:**

- `atomic_approval` is a plan metadata field only; it does not change the commit format or
  the git history structure. TDD order (test before feat) remains mandatory and verifiable.
- PATCH mode is unaffected: PATCH already auto-advances through all subtasks with a single
  stop after all subtasks complete.

---

### Alternatives Considered

| Alternative | Why Rejected |
|-------------|-------------|
| Auto-advance ALL subtasks (no approval until end of G4) | Removes the user's ability to redirect implementation mid-G4; risks large rework if early subtasks go wrong |
| Approval only at phase boundary (e.g., after all unit subtasks, before integration) | Coarser than needed; user still wants to see implementation pass before integration begins |
| Remove G4 approval entirely | Violates constitution hard rule: "Silence is never approval" (HAR-C-0002) |

---

### Compliance

- Contract: `constitution/harness/contracts/HAR-C-0002-sdlc-contract.md` §1 — G4 approval cadence amended by this ADR; qualifying pairs now use atomic approval
- The `plan.json` schema is extended with an optional `"atomic_approval": boolean` field per subtask (default `false`)
- Validator V4 check: `atomic_approval: true` requires conditions 1–3 to be met (no line-count check)
