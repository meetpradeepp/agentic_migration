﻿## HAR-ADR-0016: Tiered Validator Protocol — V-LITE and V-FULL Scan Tiers

**Status:** Accepted
**Date:** 2026-06-01
**Deciders:** Lead Engineer
**Supersedes:** —
**Superseded by:** —
**Amends:** HAR-ADR-0002 §1 (memory loading protocol for validator)
**Amended by:** —
**FACT impact:**
- Fast: `improves` — validator token cost reduced by ~60% per FULL task; V-LITE scans complete without loading the 44KB mega-digest
- Accurate: `neutral` — V-FULL still loads the full mega-digest for V2 (the only scan that requires cross-contract reasoning); no reduction in detection capability
- Complete: `neutral` — all 5 V-scan types still run; only the loading cost changes
- Trustworthy: `improves` — lighter scans are more likely to be run consistently; heavy scans remain authoritative for the one gate (G4→G5) where code correctness must be verified against exact contract text

---

### Context

The validator agent currently loads `constitution-digest.md` (44KB) at the start of every
V-scan invocation. In a typical FULL task, the validator is invoked 6–8 times:

- V1 after G1 (spec compliance)
- V3 after G2 (review completeness — first time)
- V4 after G3 (plan compliance)
- V2 after G4 (code compliance — per-batch)
- V3 after G5 (review completeness — second time)
- V5 after G6 (release compliance)

At 44KB × 6–8 invocations, the mega-digest accounts for ~264–352KB of context loading per
task purely for the validator, before any workspace artifacts are read.

An analysis of what each V-scan actually requires shows that **only V2 needs cross-contract
reasoning**. V2 checks that new code conforms to contracts across module boundaries — it
genuinely needs the full contract text to cite specific clauses. V1, V3, V4, and V5 are
structural and citation-based checks:

- **V1** — Is the spec file present, correctly formatted, in the right location, and do its
  AC identifiers follow the spec schema? These are structural checks against the workspace.
- **V3** — Does the reviewer's report contain `file:line` citations per PASS item? This is a
  format check against the review report, not a cross-contract check.
- **V4** — Does the plan follow TDD order, SRP, and ≤300 lines per subtask? These are plan
  structure checks.
- **V5** — Is the spec `Status: Implemented`, is `## Deviations` filled, and is a CHANGES.md
  entry present? These are artifact presence checks.

None of V1, V3, V4, V5 requires knowledge of contract clause wording. Loading the mega-digest
for these is a token expense that provides no detection benefit.

---

### Decision

We will define two validator tiers and route each V-scan to the appropriate tier.

**V-LITE tier (V1, V3, V4, V5):**
- Does NOT load `constitution-digest.md`.
- Loads only: workspace artifacts directly relevant to the check (spec file for V1, review
  report for V3, plan file for V4, spec + CHANGES.md + git log for V5).
- Escalation path: if a V-LITE check surfaces an anomaly that cannot be resolved without
  contract text (e.g., a spec section heading that does not match any known contract section),
  the validator loads the mega-digest for that check only and cites the exact clause.
- V3 fast-path: if every PASS item in the review report has ≥1 `file:line` citation,
  V3.1 passes immediately without any further context loading.

**V-FULL tier (V2):**
- Loads `constitution-digest.md` as its first action.
- Proceeds with the full 9-point code compliance scan (cross-contract reasoning required).
- V2 is the enforcement safety net; it must never be V-LITE.

**Routing table:**

| Scan | Gate | Tier | Mega-digest loaded? |
|------|------|------|---------------------|
| V1 | G1→G2 | V-LITE | Only on escalation |
| V3 | G2→G3 | V-LITE | Only if citations absent |
| V4 | G3→G4 | V-LITE | Only on escalation |
| V2 | G4→G5 | V-FULL | Always |
| V3 | G5 (review completeness) | V-LITE | Only if citations absent |
| V5 | G6 | V-LITE | Only on escalation |

**Validator agent update (already applied to `validator.agent.md`):**
The routing table above is the canonical reference. The validator reads the scan type from
the orchestrator's invocation instruction and selects the tier automatically.

---

### Consequences

**Positive:**

- Mega-digest loading drops from 6–8× per FULL task to 1× (V2 only) in the typical case.
- V-LITE scans are faster to invoke and less likely to be skipped due to context budget pressure.
- V-FULL retains full detection capability for the critical G4→G5 gate.

**Negative / Trade-offs:**

- V-LITE escalation path requires the validator to decide mid-scan whether to load additional
  context. If this decision is wrong (escalation missed), a V-LITE PASS could be false.
  Mitigated by: V2 (V-FULL) runs immediately after G4 and cross-checks any structural
  violations that V1/V3/V4 might have missed.
- V3 fast-path requires reviewers to include `file:line` citations on every PASS item. This
  is already a HAR-C-0002 §6 requirement; this ADR makes it a validator-enforced gate.

**Neutral / Operational notes:**

- The mega-digest continues to be the authoritative reference for validator, spec-reviewer,
  and orchestrator during G0 triage. This ADR only affects the validator's V1/V3/V4/V5 scans.
- The `agent-clusters.md` file already assigns validator to the `governance` cluster (all 21
  full contracts). This ADR does not change the cluster assignment; it adds a within-validator
  routing rule that defers the mega-digest load to V2 only.

---

### Alternatives Considered

| Alternative | Why Rejected |
|-------------|-------------|
| Keep mega-digest loading for all V-scans | Status quo; ~60% token waste on V1/V3/V4/V5 with no detection benefit |
| Remove mega-digest from validator entirely | V2 code compliance genuinely requires cross-contract reasoning; removing it would lower V2 detection accuracy |
| Per-contract micro-digest for each V-scan | Adds 21 individual file reads per scan; higher overhead than the mega-digest load it replaces |

---

### Compliance

- Contract: `constitution/harness/contracts/HAR-ADR-0002-memory-token-optimization.md` — tiered loading protocol is an extension of the digest-first rule in §1
- Validator agent: `validator.agent.md` already updated per this ADR's routing table (see V3 fast-path note and V5 no-mega-digest note applied in the 2026-06-01 agent instruction pass)
- The V-FULL gate for V2 is non-negotiable; no future ADR may demote V2 to V-LITE without replacing it with an equivalent cross-contract check
