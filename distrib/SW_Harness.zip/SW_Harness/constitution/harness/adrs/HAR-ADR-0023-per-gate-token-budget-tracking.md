# HAR-ADR-0023: Per-Gate Token Budget Tracking

| Field       | Value                                                          |
|-------------|----------------------------------------------------------------|
| **ID**      | HAR-ADR-0023                                                   |
| **Status**  | Accepted                                                       |
| **Date**    | 2026-06-09                                                     |
| **Deciders**| Harness maintainers                                            |
| **Supersedes** | —                                                           |
| **Superseded by** | —                                                        |
| **Amends**  | HAR-C-0002 §5 (observability at gate level)                    |
| **FACT impact:**||
| Fast | `neutral` — gate-log writes are append-only; negligible overhead |
| Accurate | `neutral` — token estimates do not affect pipeline correctness |
| Complete | `improves` — token visibility enables informed depth tuning |
| Trustworthy | `improves` — cost transparency supports governance and audit |

---

## Context

Teams using the harness have no visibility into the token cost of individual pipeline gates. Without per-gate data, it is impossible to know which spec types, gate depths, or agent combinations drive token consumption. Optimization decisions are made blindly, and budget overruns cannot be attributed to specific gates or tasks.

The `pipeline_metrics.py` script already has the reader side of this feature — `TaskTokenReport`, `TokenEntry`, and the `--tokens` flag are implemented. What is missing is the writer side: no agent or orchestrator step appends data to `gate-log.json`, so the reader has nothing to process.

Adding per-gate logging directly in agent instruction files is impractical because agents are LLMs that cannot measure their own token consumption exactly. The orchestrator is already the central coordinator of all gate transitions and is the natural place to perform the gate-close append.

---

## Decision

We will make the orchestrator responsible for appending one token-usage entry to `<workspace_path>/gate-log.json` at the close of every gate (G1–G6), when `hooks.yaml → token_budget_tracking: enabled`.

Mechanism:
- Entry format (JSON Lines — one object per line, no wrapping array):
  `{"gate": "GN", "agent": "<primary-agent>", "tokens_in": N, "tokens_out": M, "timestamp": "ISO-8601"}`
- `tokens_in` — estimated: total characters of all context loaded this gate ÷ 4
- `tokens_out` — estimated: total characters of agent response ÷ 4
- The file is created on first write; if the workspace does not yet exist, the write is skipped silently
- The toggle `token_budget_tracking` in `hooks.yaml` controls activation; absent or `disabled` means no writes
- Reporting: `python constitution/harness/scripts/pipeline_metrics.py --tokens`

---

### Consequences

**Positive:**
- Token cost becomes visible at the task and gate level without external tooling
- Teams can identify expensive spec types, tune hook depth, and justify gate skipping decisions with data
- The existing `pipeline_metrics.py --tokens` implementation is fully activated

**Negative / Trade-offs:**
- Token counts are estimates (chars ÷ 4), not exact values from the model API; actual consumption may differ by ±20%
- The orchestrator file grows by ~30 lines

**Neutral / Operational notes:**
- `gate-log.json` is workspace-local and committed as part of the permanent audit trail (HAR-ADR-0007)
- Feature is `disabled` by default in `hooks.yaml`; teams opt in explicitly

---

### Alternatives Considered

| Alternative | Why Rejected |
|-------------|--------------|
| Each agent appends its own token entry | Agents are LLMs with no reliable access to their own token counts; distributes the concern across 6+ agent files with no consistency guarantee |
| External token tracking via API callbacks | Requires infrastructure outside the harness (model API wrappers, webhooks); violates the no-external-tooling principle for harness mechanics |

---

### Compliance

- Contract: `constitution/harness/contracts/HAR-C-0002-sdlc-contract.md` §5
- Agent file: `.github/agents/orchestrator.agent.md` (Token Budget Tracking section)
- Script: `constitution/harness/scripts/pipeline_metrics.py` (reader already implemented)
- Config: `.github/hooks/hooks.yaml` (`token_budget_tracking` key)
