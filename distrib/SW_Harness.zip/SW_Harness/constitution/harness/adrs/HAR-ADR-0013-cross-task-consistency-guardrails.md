﻿## HAR-ADR-0013: Cross-Task Consistency Guardrails for Planner and Validator

**Status:** Accepted
**Date:** 2026-05-30
**Deciders:** Lead Engineer
**Supersedes:** —
**Superseded by:** —
**Amends:** —
**Amended by:** —
**FACT impact:**
- Fast: `neutral` — adds a pre-planning scan step; negligible token cost (one directory listing per planning invocation); no runtime path affected
- Accurate: `improves` — duplicate lifecycle guards, mismatched datetime formats, and interface drift are detected before code is written rather than discovered post-implementation
- Complete: `improves` — planner now surfaces shared-utility extraction opportunities; cross-module drift in V4 catches incomplete plans before G4 begins
- Trustworthy: `improves` — deterministic structural checks (base class ancestry, pattern duplication count) close the gap between per-task G5 reviews and codebase-wide architectural consistency

---

### Context

A post-implementation audit of Phases 1 and 2 revealed a recurring class of defect that the
existing pipeline does not prevent: **cross-task drift**. The drift emerges because:

1. **G5 is task-scoped by design.** The code reviewer sees only files changed in the current
   G4 pass. When four MCP tools are each implemented in separate subtasks, the reviewer sees
   one tool at a time. The identical `ThreadPoolExecutor(max_workers=1)` timeout pattern in
   all four is invisible to any single-task review.

2. **The planner has no cross-module awareness.** The planner decomposes one spec into subtasks
   without scanning adjacent modules for existing patterns. When implementing worker 3 and
   worker 4, the planner creates identical lifecycle guard subtasks for each without noting that
   worker 1 and worker 2 already carry the same guard, and that the guard belongs in
   `WorkerBase.run()`.

3. **G-1 Discovery is optional.** Architectural topology risks (dual WorkerBase, interface
   incompleteness) surface at G-1 only when the user explicitly requests discovery. For clear
   spec requests, the pipeline skips G-1 and goes straight to G0, leaving architectural
   conflicts undetected until implementation is complete.

The concrete defects produced by this gap (from the Phase 1/2 audit):
- Dual `WorkerBase` implementations (`base.py` vs `worker_base.py`) with incompatible contracts
- 19 `# type: ignore[attr-defined]` suppressions in `persist_facts/worker.py` against methods
  absent from `IDataStore`
- Identical 4-line lifecycle guard duplicated in 4 worker `process()` methods
- Inconsistent ISO-8601 datetime serialisation across 6 call sites
- `ThreadPoolExecutor` timeout wrapper copy-pasted verbatim across 4 MCP tool files
- `tenant_id`, `X_Request_Id`, `X_Trace_Id` redeclared individually in 10+ event payload classes

All of these cleared per-task G5 reviews because they were correct *within each task*.

---

### Decision

We will add **three targeted enforcement rules** to the harness pipeline. No existing gate is
removed or weakened. No spec format changes. No new agent is introduced.

**Rule 1 — Planner mandatory cross-module pattern scan (added to `planner.agent.md`)**

Before generating subtasks, the planner MUST:
a. List every existing `{src_dir}/` module file the spec touches, extends, or parallels.
b. For each new class or function the spec introduces, check whether an existing adjacent
   module already provides a structurally identical pattern (base class, error guard, wrapper,
   field declaration).
c. If a pattern would be duplicated: add a **T-0 extract subtask** (type: `"refactor"`) as the
   first subtask in the plan — it extracts the shared helper before any feature subtask uses it.
d. If a shared utility already exists: reference it explicitly in each implementation subtask's
   description (do not duplicate; import and use).
e. Record the scan findings in a top-level `"pattern_scan"` object in the plan JSON.

**Rule 2 — Validator V4 cross-module checks (added to `validator.agent.md`)**

Two new checks added to the V4 Plan Compliance Scan:

- **V4.9 — Worker base class uniqueness:** If the spec touches any worker module, verify the
  plan does not create a second `WorkerBase`-like class. Acceptable: extending the existing
  `WorkerBase`. Not acceptable: creating a parallel base class with overlapping lifecycle or
  message-routing responsibilities.
- **V4.10 — Pattern duplication gate:** If the plan contains ≥2 implementation subtasks that
  would produce structurally identical code blocks (timeout wrappers, error guards, payload field
  declarations), verify that a T-0 extract subtask precedes them OR that the plan's
  `pattern_scan.existing_utility` field names the shared utility to import.

**Rule 3 — G-1 mandatory for multi-module specs (added to `orchestrator.agent.md`)**

G-1 Discovery is no longer optional for every spec. The orchestrator MUST trigger G-1 when
G0 classification shows the spec modifies ≥2 distinct existing source modules in `{src_dir}/`
(files that already exist — not files the spec creates from scratch). The discovery agent
scans those modules before G1 begins, identifying shared patterns to extract and architectural
risks to document in the ADR.

The user may waive G-1 for multi-module specs with an explicit written reason ("waive G-1:
reason"). The waiver is recorded in `task-state.json` under `g1_waiver`. Without a waiver, G1
cannot begin until G-1 completes.

---

### Consequences

**Positive:**

- Duplicate patterns caught at plan time rather than at post-implementation audit time.
- Interface drift (methods called but not in interface) surfaced by cross-module scan before
  the coder writes suppressed `type: ignore` calls.
- Architectural topology conflicts (dual base classes) caught at G-1 before spec is written.
- No new agents required; no spec format changes; no gate added.

**Negative / Trade-offs:**

- Planning invocations gain one directory scan step; negligible token cost for all realistic
  plan sizes (< 20 subtasks).
- Multi-module specs gain a mandatory G-1 pass; adds 1–2 conversation turns before G1.
- Planner must be able to read adjacent module files; increases planner context window usage
  by ~2–5 KB per planning invocation for typical specs.

**Neutral / Operational notes:**

- The `pattern_scan` field in plan JSON is advisory metadata; it does not change subtask
  execution order unless a T-0 subtask is inserted.
- Existing plans in closed workspaces are not retroactively updated; the rule applies to new
  planning invocations only.
- The G-1 waiver mechanism ensures the guardrail does not block solo or trivial multi-module
  changes (e.g., import addition across 2 files).

---

### Alternatives Considered

| Alternative | Why Rejected |
|-------------|-------------|
| Add a full-codebase DRY linter to CI | Too broad and noisy; structural similarity detection across arbitrary Python files produces false positives; token-prohibitive as a pre-commit check |
| Add a "cross-task reviewer" agent that scans all prior G5 reviews | Requires maintaining a review index; high token cost; pattern detection is AI-judgment-dependent, not deterministic |
| Require spec to enumerate all methods called on injected interfaces | Correct in principle; adds significant spec-writing burden for every enhancement; addressed instead by V4.9 catching interface drift at plan time |
| Add G-1 as mandatory for ALL specs | Over-broad; single-module NEW_FEATURE specs with no parallel patterns in adjacent modules gain nothing from mandatory discovery |

---

### Compliance

- **Rule 1** enforced by: `planner.agent.md` §Before You Plan, step 7; validator V4.10
- **Rule 2** enforced by: `validator.agent.md` V4.9, V4.10 checks in V4 Plan Compliance Scan
- **Rule 3** enforced by: `orchestrator.agent.md` §G-1 Triggered by; `task-state.json` `g1_waiver` field
- **Audit trail:** `plan.json` `pattern_scan` field documents what the planner found per invocation
