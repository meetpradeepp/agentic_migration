﻿# HAR-ADR-0003: Pipeline Workspace for Agent Artifacts

**Status:** Accepted
**Date:** 2026-05-08
**Deciders:** Lead Engineer, Architecture Review
**Supersedes:** —
**Superseded by:** —
**Amended by:** HAR-ADR-0010 (adds two new files to workspace layout: `adrs/SYNOPSIS.md` generated at G1; `reviews/review-log.md` appended at each review gate)
**FACT impact:**
- Fast: `improves` — agents read/write to well-known paths instead of searching the workspace or passing file contents inline
- Accurate: `improves` — single workspace eliminates stale artifact references between agents
- Complete: `neutral` — no change to what artifacts are produced
- Trustworthy: `improves` — every artifact lives at a predictable path; audit trail is filesystem-native

---

### Context

The {project_name} agent pipeline passes artifacts between 12 agents across 7 gates.
Currently, the orchestrator describes file paths in prose and agents must search
for relevant specs, plans, and review reports. This creates three problems:

1. **File discovery overhead.** Every agent scans `specs/`, `.github/pipeline/plans/`,
   and constitution directories to find the files it needs. This burns tokens and
   introduces search ambiguity.

2. **No workspace for in-flight artifacts.** Review reports, validation reports, and
   gate approval records have no designated location. They are emitted inline and
   lost after the conversation turn.

3. **ADR consumption gap.** Specs reference ADRs via `Implements: ADR-NNNN`, but no
   agent (except adr-writer) is instructed to read ADRs during implementation. The
   architectural decisions that drove the spec are invisible to the coder and reviewer.

---

### Decision

We will establish a structured **pipeline workspace** at `.github/pipeline/` where
all in-flight artifacts are written to and read from well-known paths. Agents will
read and write to these paths directly — no file passing, no searching.

```
.github/pipeline/
  state.json                              ← current pipeline state (exists)
  plans/SPEC-NNNN-plan.json              ← implementation plans (exists)
  workspace/                              ← NEW: in-flight work area
    current/                              ← symlink-like: points to active SPEC work
      spec.md                             ← copy/link to the active spec
      plan.json                           ← copy/link to the active plan
      adrs/                               ← ADRs referenced by the spec
      reviews/                            ← review and validation reports
        spec-review.md                    ← spec-reviewer output
        plan-validation.md                ← validator V4 output
        code-review.md                    ← code-reviewer output
        validation-v1.md                  ← validator V1 output
        validation-v2.md                  ← validator V2 output
        validation-v3.md                  ← validator V3 output
        validation-v5.md                  ← validator V5 output
      subtasks/                           ← per-subtask working state
        SPEC-NNNN-T01/                    ← subtask work area
          status.json                     ← completion status, files created/modified
          test-report.md                  ← tester output for this subtask
```

**Lifecycle:**
1. Orchestrator creates `workspace/current/` at G0 and populates `spec.md` at G1
2. Orchestrator copies referenced ADRs into `workspace/current/adrs/` at G1
3. Each agent reads from and writes to its designated path
4. At G6 (release), workspace is archived and cleared

**Naming conventions (canonical):**
- Plan file: `.github/pipeline/plans/SPEC-NNNN-plan.json`
- Active spec pointer/copy: `.github/pipeline/workspace/current/spec.md`
- Active plan pointer/copy: `.github/pipeline/workspace/current/plan.json`
- Active ADR copy: `.github/pipeline/workspace/current/adrs/ADR-NNNN-<name>.md`
- Review reports: `.github/pipeline/workspace/current/reviews/<review-type>.md`
- Subtask folder: `.github/pipeline/workspace/current/subtasks/SPEC-NNNN-TNN/`
- Subtask status: `.github/pipeline/workspace/current/subtasks/SPEC-NNNN-TNN/status.json`

**Normalization rule:** If a non-canonical file name is found (for example `plan-SPEC-NNNN.json`), it must be normalized to canonical form before gate advancement.

**ADR consumption rule:** The spec-writer MUST populate `Implements: ADR-NNNN`. At G1,
the orchestrator copies those ADRs into `workspace/current/adrs/`. The coder, planner,
and code-reviewer MUST read these ADRs before starting their work.

---

### Consequences

**Positive:**

- Zero-search artifact access — every agent knows exactly where to find its inputs
- ADRs are now consumed during implementation, not just referenced
- Review reports persist as files — auditable, diffable, referenceable
- Subtask status is filesystem-native — no inline JSON updates
- Workspace is self-cleaning at release gate

**Negative / Trade-offs:**

- Workspace setup adds a step to G0 (mitigated: orchestrator handles it automatically)
- Duplicate copies of spec and ADRs in workspace (mitigated: workspace is ephemeral)

**Neutral / Operational notes:**

- `.github/pipeline/workspace/` is gitignored — it's working state, not committed
- Plans still live at `.github/pipeline/plans/` for permanence
- Specs still live at `specs/phase-N/` as the source of truth

---

### Alternatives Considered

| Alternative | Why Rejected |
|-------------|-------------|
| Git worktrees per agent | Overkill — agents don't need separate branches; they share one working state |
| Passing file contents in orchestrator prompts | Wastes tokens; duplicates content that agents can read themselves |
| Database-backed artifact store | Over-engineered for development tooling; filesystem is simpler and auditable |

---

### Compliance

- Contract: `constitution/harness/contracts/HAR-C-0002-sdlc-contract.md` — ADR before architectural change
- No schema changes
- No eval suite impact
