﻿# HAR-ADR-0001: SYS / HAR Two-Plane Constitution Taxonomy

**Status:** Accepted
**Date:** 2026-05-30
**Deciders:** Lead Engineer, Architecture Review
**Supersedes:** —
**Superseded by:** —
**Amends:** constitution/README.md (directory structure); `next_number.py` (new counter types); all existing ADR and contract identifiers (full rename)
**Amended by:** —
**FACT impact:** None — purely a governance and organisation change. No runtime behaviour changes.

---

## Context

As of Phase 3 start, the {project_name} constitution holds 59 ADRs and 21 contracts in a single flat
namespace. All artifacts share the same identifier scheme (`ADR-NNNN`, `Contract NN`) regardless
of whether they describe the {project_name} system's runtime behaviour or the harness used to build any
project. This creates three compounding problems:

1. **Readability:** `HAR-ADR-0002` (how agents load context) and `SYS-ADR-0001` (event-driven pipeline)
   look identical at a glance. Their plane — system vs harness — is invisible in the identifier.

2. **Portability:** The harness (SDLC pipeline, agents, coding standards, CI tooling) is intended
   to be reusable across projects (see IDEA-0019). Extracting it requires knowing which artifacts
   belong to the harness vs the system. Currently that boundary is implicit.

3. **Agent efficiency:** Agents load digests to conserve context. A system agent (e.g. spec-writer
   for a system feature) should load only system ADRs. A harness agent (e.g. orchestrator) should
   load only harness ADRs. The flat namespace forces agents to either load everything or maintain
   manual exclusion lists.

The two-plane model was validated through G-1 discovery on 2026-05-30 and confirmed to require
only mechanical file renames + text substitution — no behavioural change to any system component.

---

## Decision

Adopt a **two-plane constitution taxonomy** with the following identifier scheme:

| Artifact type | Identifier | Plane | Directory |
|---|---|---|---|
| System ADR | `SYS-ADR-NNNN` | System | `constitution/system/adrs/` |
| Harness ADR | `HAR-ADR-NNNN` | Harness | `constitution/harness/adrs/` |
| System Contract | `SYS-C-NNNN` | System | `constitution/system/contracts/` |
| Harness Contract | `HAR-C-NNNN` | Harness | `constitution/harness/contracts/` |
| Feature spec | `SPEC-NNNN` | — (always system) | `specs/phase-N/` (unchanged) |
| Idea | `IDEA-NNNN` | — (cross-cutting) | `.github/memory/ideas-backlog.md` (unchanged) |

**Padding:** 4 digits for all types (`NNNN`). Each plane's counter resets to 0001.

**Plane definitions:**
- **System (SYS):** Any ADR or contract that governs what the {project_name} system does at runtime —
  its architecture, data models, algorithms, interfaces, security, and operational behaviour.
  System artifacts are project-specific and do not transfer to other adopting projects.
- **Harness (HAR):** Any ADR or contract that governs how *any* project using this harness
  is built, tested, reviewed, and released — coding standards, SDLC process, CI tooling,
  agent pipeline, anti-patterns, deployment rules, phase gate templates.
  Harness artifacts are project-agnostic and ship with the reusable harness (see IDEA-0019).

**Existing artifacts (59 ADRs + 21 contracts):** All renamed and moved in a single atomic
migration commit. See `## Classification Table` below for the definitive old→new mapping.

**New artifacts (Phase 3+):** All new ADRs and contracts receive identifiers under the new
scheme from day one. The `next_number.py` script is updated with four new counter types:
`sys-adr`, `har-adr`, `sys-c`, `har-c`.

---

## Classification Table

> SW_Harness ships **no SYS-ADR or SYS-C entries** — those are project-level artefacts
> created by each adopting project through its own pipeline (see HAR-ADR-0021).

### Harness ADRs → HAR-ADR-NNNN (21 in SW_Harness)

| New ID | Old ID | Title |
|---|---|---|
| HAR-ADR-0001 | — | sys-har-two-plane-taxonomy *(this document)* |
| HAR-ADR-0002 | ADR-0029 | agent-token-optimization |
| HAR-ADR-0003 | ADR-0030 | pipeline-workspace |
| HAR-ADR-0004 | ADR-0035 | phase-as-product-milestone |
| HAR-ADR-0005 | ADR-0036 | sast-toolchain |
| HAR-ADR-0006 | ADR-0037 | deterministic-variable-naming-enforcement |
| HAR-ADR-0007 | ADR-0048 | parallel-task-workspace-isolation |
| HAR-ADR-0008 | ADR-0049 | split-pipeline-state |
| HAR-ADR-0009 | ADR-0055 | agent-role-contract-clusters |
| HAR-ADR-0010 | ADR-0056 | workspace-data-optimization |
| HAR-ADR-0011 | ADR-0059 | code-review-operational-consistency |
| HAR-ADR-0012 | — | sqlite-pipeline-state |
| HAR-ADR-0013 | — | cross-task-consistency-guardrails |
| HAR-ADR-0014 | — | worker-test-infrastructure |
| HAR-ADR-0015 | — | tdd-unit-atomic-approval |
| HAR-ADR-0016 | — | tiered-validator-protocol |
| HAR-ADR-0017 | — | spec-canvas-protocol |
| HAR-ADR-0018 | — | plan-templates-summary-artifact |
| HAR-ADR-0019 | — | hallucination-guardrails |
| HAR-ADR-0020 | — | proof-obligation-registry |
| HAR-ADR-0021 | — | project-level-sys-c-contracts-excluded |

### Harness Contracts → HAR-C-NNNN (9 in SW_Harness)

| New ID | Old | Title |
|---|---|---|
| HAR-C-0001 | Contract 01 | coding-standards |
| HAR-C-0002 | Contract 02 | sdlc-contract |
| HAR-C-0003 | Contract 03 | testing-contract |
| HAR-C-0004 | Contract 10 | anti-patterns |
| HAR-C-0005 | Contract 14 | deployment-contract |
| HAR-C-0006 | Contract 16 | observability-contract |
| HAR-C-0007 | Contract 17 | phase-roadmap-contract |
| HAR-C-0008 | Contract 18 | implementation-guidelines |
| HAR-C-0009 | — | (added post-extraction — see next_number.py) |

---

## Consequences

**Positive:**
- Every identifier is self-describing — plane is visible at a glance.
- The harness boundary is formally encoded and auditable.
- Agent context loading can be scoped by directory: system agents load `system/`, harness agents load `harness/`.
- Enables IDEA-0019 (extract harness to own repo) without further reclassification work.

**Negative / Migration cost:**
- One-time migration: 81 file renames + ~6,081 text reference substitutions across codebase.
- All agent memory digests and agent instruction files updated in the same commit.
- `next_number.py` gains four new counter types.
- Pre-existing cross-references in external documents (outside this repo) will be stale — documented in Deviations.

**Neutralised risks:**
- No ambiguity between old and new identifiers: `SYS-ADR-` and `HAR-ADR-` prefixes are globally unique strings not present anywhere in the existing codebase before this migration.
- The migration is atomic (single commit) — no partial state is ever committed.

---

## Compliance

- The migration script (`scripts/fix_taxonomy_references.py`) performs all renames and substitutions deterministically from the classification table above.
- `next_number.py` updated with `sys-adr`, `har-adr`, `sys-c`, `har-c` counter types seeded from the post-migration file counts.
- `constitution-digest.md` updated to reflect new identifiers and directory layout.
- All agent files and memory artifacts updated in the same commit.

---

## Deviations

- D-001: External documents or chat logs referencing old identifiers (e.g. `ADR-0001`, `Contract 09`) will not be updated — they predate this migration. Any cross-reference check against the old scheme should be treated as a lookup via the classification table above.
