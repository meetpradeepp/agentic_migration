﻿## HAR-ADR-0005: SAST Toolchain and Security Agent

**Status:** Accepted
**Date:** 2026-05-12
**Deciders:** Lead Engineer, Architecture Review
**Supersedes:** —
**Superseded by:** —
**Amended by:** HAR-ADR-0008 (Opt-5 — zero-runtime SAST scoping exception: FAIL verdict is advisory, not blocking, for tasks that change no files under `src/`)
**FACT impact:**
- Fast: `degrades` — bandit + pip-audit add ~30 s to CI; degradation is bounded and acceptable given the security guarantee
- Accurate: `improves` — deterministic tool output eliminates LLM hallucination risk from security signal
- Complete: `improves` — catches supply-chain CVEs and AST-level runtime patterns (subprocess misuse, weak crypto) that ruff/mypy cannot see
- Trustworthy: `improves` — structured SAST report written to pipeline workspace creates an auditable security trail per release

---

### Context

{project_name} is a deterministic code intelligence engine with no runtime LLM. Deterministic,
repeatable security enforcement is therefore required at every gate — probabilistic or
judgment-based tooling is architecturally inconsistent with the platform's guarantees.

HAR-C-0001 §7 already bans f-string SQL and mandates parameterised queries; HAR-C-0001
§9 bans secrets in code; HAR-C-0004 bans bare `except:`. These rules are enforced
today by ruff and mypy. However, ruff and mypy are linters, not SAST tools: they operate
on coding style and type correctness, not on security-relevant AST patterns such as
`subprocess(shell=True)`, weak cryptographic primitives, or unsafe deserialisation.
No existing gate covers dependency-level CVE vulnerabilities (supply-chain risk).

The G5 gate currently runs `@code-reviewer` and `@tester`. Neither role is equipped or
tasked to scan for the class of findings described above. A gap therefore exists between
what the constitution promises (FACT, SYS-C-0001) and what CI actually verifies before
a release tag is applied.

`bandit` is a Python-native, pip-installable SAST tool that performs deterministic AST
analysis and emits structured JSON with severity (HIGH / MEDIUM / LOW) and confidence
(HIGH / MEDIUM / LOW) per finding. `pip-audit` is a pip-installable dependency scanner
that resolves installed packages against the OSV and PyPI Advisory Database and emits
deterministic JSON with CVE IDs and fix availability. Both tools require no external
services, no LLM, and no license complexity beyond pip installation.

---

### Decision

We will add a deterministic SAST stage to the {project_name} CI pipeline using `bandit`
(Python AST-level security analysis) and `pip-audit` (dependency CVE scanning), and
introduce a `@sast` agent that executes both tools at gate G5 and produces a structured
PASS / WARN / FAIL report consumed by the orchestrator.

**Agent file:** `.github/agents/sast.agent.md`

**Execution steps (in order):**

1. Run `bandit -r src/ -f json -o sast-bandit.json`
2. Run `pip-audit --format json -o sast-pip-audit.json`
3. Parse both JSON outputs and apply the severity policy table below
4. Tally HIGH-severity findings that meet the FAIL threshold
5. Write structured report to `.github/pipeline/workspace/current/reviews/sast-report.md`
6. Return a single verdict — `PASS`, `WARN`, or `FAIL` — to the orchestrator

**Severity policy:**

| Tool | Finding | Pipeline action |
|------|---------|----------------|
| bandit | HIGH severity + HIGH confidence | `FAIL` — blocks G5 |
| bandit | MEDIUM severity OR MEDIUM confidence | `WARN` — reviewer must acknowledge in PR |
| bandit | LOW severity, any confidence | Informational — logged only |
| pip-audit | CVE with known fix available | `FAIL` — blocks G5 |
| pip-audit | CVE with no fix yet | `WARN` |

**Verdict rules:**

- `FAIL` if any FAIL-threshold finding exists → orchestrator halts at G5
- `WARN` if no FAIL findings but WARN findings exist → orchestrator proceeds with
  mandatory reviewer acknowledgement recorded in the PR
- `PASS` if no FAIL and no WARN findings

The `@sast` agent does NOT apply LLM judgment to any finding. Classification is
determined solely by the tool-reported severity and confidence values against the
policy table above.

---

### Consequences

**Positive:**

- Supply-chain CVEs caught before a release tag is applied
- AST-level security anti-patterns (subprocess shell injection, weak crypto, hardcoded
  credentials) caught deterministically, reinforcing HAR-C-0001 §7 and §9 at tool level
- Structured `sast-report.md` in pipeline workspace provides auditable evidence per
  release that security scanning was performed and passed
- No external service dependency — both tools run offline from pip

**Negative / Trade-offs:**

- ~30 s added to every G5 run; this is bounded and predictable, unlike LLM-based review
- bandit can produce false positives on intentional low-risk patterns (e.g. MD5 used for
  non-security hashing); these will surface as WARNs and require reviewer acknowledgement,
  adding minor friction
- `pip-audit` results depend on the accuracy and freshness of OSV/PyPI advisory data;
  a CVE announced after a release tag will not appear retroactively

**Neutral / Operational notes:**

- Both `bandit` and `pip-audit` must be added to `pyproject.toml` dev dependencies
- `sast-bandit.json` and `sast-pip-audit.json` are ephemeral CI artefacts; they are
  captured in the pipeline workspace for the duration of a G5 run and referenced by
  `sast-report.md`
- The `eval_sast_clean` CI gate (see Compliance) asserts that the {project_name} source tree
  itself passes the severity policy on every commit

---

### Alternatives Considered

| Alternative | Why Rejected |
|-------------|-------------|
| LLM-based security reviewer | Probabilistic — can miss findings or hallucinate false positives; architecturally inconsistent with {project_name}'s no-runtime-LLM guarantee (SYS-C-0001) |
| semgrep only | Introduces a non-Python binary dependency and licence complexity (Semgrep Pro); bandit is pip-installable, BSD-licensed, and covers the same Python AST surface |
| ruff + mypy only (status quo) | Does not cover CVEs (supply-chain risk) or runtime security patterns such as subprocess shell injection and unsafe deserialisation; the gap is structural, not addressable by tuning existing linters |

---

### Compliance

- Contract: `constitution/harness/contracts/HAR-C-0001-coding-standards.md` §7 (parameterised queries — bandit B608 enforces at tool level)
- Contract: `constitution/harness/contracts/HAR-C-0001-coding-standards.md` §9 (no secrets in code — bandit B105/B106/B107 covers hardcoded password patterns)
- Contract: `constitution/harness/contracts/HAR-C-0002-sdlc-contract.md` §6 (9-point review checklist — SAST report feeds review point 5 "No anti-patterns")
- Contract: `constitution/harness/contracts/HAR-C-0003-testing-contract.md` (eval suites — `eval_sast_clean` added as CI gate)
- Eval: `eval_sast_clean`
