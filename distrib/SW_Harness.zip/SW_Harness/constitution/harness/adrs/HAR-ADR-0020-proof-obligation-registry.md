﻿## HAR-ADR-0020: Proof Obligation Registry

**Status:** Accepted
**Date:** 2026-06-04
**Deciders:** Lead Engineer
**Supersedes:** —
**Superseded by:** —
**Amends:** HAR-C-0002 §6 (add proof coverage report to G5 gate check), HAR-C-0003 §1 (add inventory-diff test type for ENUMERATIVE assertions)
**Amended by:** —
**FACT impact:**
- Fast: `neutral` — dispatcher adds ~1 s to gate checks; pre-mechanical checks short-circuit expensive agent chains faster on first-caught violations
- Accurate: `improves` — ENUMERATIVE assertions are now diffed deterministically against alembic DDL and event schemas; no agent judgment required for column/field completeness
- Complete: `improves` — coverage matrix makes explicitly visible what is and is not verified; eliminates false confidence from the silent "cited = verified" assumption
- Trustworthy: `improves` — every gate claim about contract compliance is backed by either a passing mechanical check or an explicit HUMAN_REVIEW or UNVERIFIED tag; fake confidence is replaced by legible, auditable gaps

---

### Context

The SYS-C-0010 incident (June 2026) revealed that the `function_facts` Alembic migration
in `0001_phase1_schema.py` was missing the `line_start`, `line_end`, `col_start`, and
`col_end` columns mandated by SYS-C-0010 §2. This gap went undetected through three gate
reviews because the harness verifies that specs _cite_ contracts but not that the cited
contracts' specific enumerations are actually reflected in downstream artifacts. No
mechanical check existed to diff SYS-C-0010's column inventory against the alembic DDL,
and all three verification layers — spec, tests, and migration — were authored against the
spec rather than the contract itself.

The root cause is architectural: assertions existed in contracts; proof mechanisms did not.
The harness assumed that citation implied verification. The broader implication is that the
current harness is strong on governance (process order) and traceability (reference
presence) but has no fidelity layer (content alignment). The ENUMERATIVE class of
contract rule — columns, fields, event payload keys, config keys, exported names — is
wholly unguarded; any mismatch between a contract's inventory and its artifact is invisible
until a runtime failure surfaces it.

Extending mechanical proof to all 21 contracts at once would be a months-long migration
project. A targeted bootstrap that covers the highest-risk contracts, establishes the
architectural skeleton, and makes the remaining gaps _explicitly_ visible is both faster
and safer than either doing nothing or attempting full coverage immediately.

---

### Decision

We will introduce a **Proof Obligation Registry** as a new harness subsystem consisting
of three YAML registries, a five-class contract taxonomy, a four-state proof status enum,
a dispatcher script, a coverage reporter, and a CI gate — with Phase 1 bootstrap scoped
to four contracts.

---

**1. Five contract classes**

Every assertion in every constitution contract belongs to exactly one of the following
classes. The class determines which proof strategy family applies:

| Class | Definition | Proof family |
|---|---|---|
| `ENUMERATIVE` | Columns, fields, events, endpoints, exports, config keys — closed inventories where completeness is verifiable by deterministic diff | Inventory diff against artifact (alembic DDL, event schema YAML, config schema) |
| `STRUCTURAL` | Architecture rules: no worker-to-worker calls, message-broker-only inter-worker communication, single ownership per DB table | Static analysis / AST / import graph scan |
| `BEHAVIORAL` | Idempotency, retry-safety, fault tolerance, ordering invariants | Property tests / mutation tests / scenario tests |
| `QUALITY` | Performance bounds, line coverage thresholds, P95 latency budgets | Benchmark runs / metrics collection |
| `SEMANTIC` | Correctness of computed outputs — find table owners, compute blast radius, resolve cross-repo links | Golden dataset eval corpus |

---

**2. Three registries**

**a. Proof Strategies registry** — `constitution/harness/registries/proof-strategies.yaml`

A closed enumeration of reusable proof strategy definitions. Each entry has the fields:
`id` (PS-0001…PS-0012), `name`, `description`, `payload_schema`, and `executor_script`.
No proof strategy may be used in an assertions file unless it appears in this registry.
The registry is authoritative; executor scripts must be listed here before being invoked
by the dispatcher.

Initial strategies at bootstrap:
- `PS-0001` — Inventory Diff (ENUMERATIVE): diffs a declared column/field list against
  actual alembic DDL or event schema; the first strategy to be implemented.
- `PS-0002` through `PS-0012` — reserved for STRUCTURAL, BEHAVIORAL, QUALITY, and
  SEMANTIC strategies; placeholder stubs at bootstrap, populated as each class matures.

**b. Evidence Providers registry** — `constitution/harness/registries/evidence-providers.yaml`

Maps each VM.N check (VM.1 through VM.5, extensible) to its executor script path and
invocation signature. Each entry has the fields: `vm_id`, `description`, `script_path`,
and `invocation`. This registry is the single source of truth for which script provides
evidence for each VM check; the dispatcher reads it to resolve the executor for a given
proof strategy.

**c. Assertions registry** — `constitution/harness/registries/assertions/<contract-id>.yaml`

One YAML file per contract (e.g., `assertions/SYS-C-0010.yaml`). Each file lists the
atomic assertions extracted from that contract. Every assertion entry has the following
mandatory fields:

```yaml
- assertion_id: <CONTRACT-ID>-A-NNN
  statement: "<exact prose of the rule from the contract>"
  contract_type: ENUMERATIVE | STRUCTURAL | BEHAVIORAL | QUALITY | SEMANTIC
  proof_strategy_id: PS-NNNN | null
  proof_status: VERIFIED | PARTIALLY_VERIFIED | HUMAN_REVIEW | UNVERIFIED
  proof_payload: {}   # strategy-specific; required when proof_status != UNVERIFIED
  proof_gap: ""       # required (non-empty) when proof_status == PARTIALLY_VERIFIED
```

---

**3. Proof status enum**

| Status | Meaning |
|---|---|
| `VERIFIED` | An active proof mechanism is registered for this assertion and is passing in CI |
| `PARTIALLY_VERIFIED` | A proof mechanism exists but has a declared gap; the `proof_gap` field must describe the uncovered portion |
| `HUMAN_REVIEW` | The rule is not mechanically provable in the current harness; it is reviewed at gate G2/G5 by `@spec-reviewer` / `@code-reviewer`; this is not a failure — it is an honest declaration |
| `UNVERIFIED` | No proof mechanism exists yet; the rule is aspirational or deferred; explicitly flagged in the coverage report |

---

**4. Atomic Rule Principle (SRP for contract assertions)**

A single contract statement that requires two distinct proof mechanisms MUST be split
into two separate assertions in the assertions registry. One assertion = one
`contract_type` = one `proof_strategy_id` = one verifiable claim. Compound assertions
that would need two strategies to be fully proven MUST be decomposed before being
registered; the original contract prose may be quoted verbatim in both children.

---

**5. VM.5 — Contract Fidelity Check (closes the SYS-C-0010 failure class)**

A new verification mechanism VM.5 is established:

`constitution/harness/scripts/check_contract_fidelity.py`

- Proof strategy: PS-0001 (Inventory Diff)
- Contract class covered: ENUMERATIVE
- Operation: Given an assertion's `proof_payload` that lists required column names (for
  DB table assertions) or required field names (for event schema assertions), the script
  diffs the declared inventory against the actual artifact — alembic DDL for DB columns,
  event schema YAML for event payload fields — and exits 1 on any missing item.
- VM.5 directly closes the SYS-C-0010 failure class: the `function_facts` column
  inventory in SYS-C-0010 §2 will be the first assertion registered with PS-0001, and
  VM.5 will run at every gate where SYS-C-0010 is cited.

VM.5 is added to the Evidence Providers registry as:
```yaml
vm_id: VM.5
description: Contract Fidelity — ENUMERATIVE inventory diff against artifact
script_path: constitution/harness/scripts/check_contract_fidelity.py
invocation: "python {script_path} --assertion {assertion_id} --artifact {artifact_path}"
```

---

**6. Dispatcher and coverage scripts**

`run_proof_dispatcher.py` — reads the assertions YAML for a specified contract, resolves
the proof strategy for each assertion from the Proof Strategies registry, looks up the
executor from the Evidence Providers registry, invokes the executor, and collects
PASS / FAIL / SKIP per assertion. Invoked at G4 and G5 for contracts that have registered
assertions.

`report_coverage.py` — aggregates dispatcher results across all assertion files under
`constitution/harness/registries/assertions/`, emits a coverage matrix broken down by
contract class (ENUMERATIVE / STRUCTURAL / BEHAVIORAL / QUALITY / SEMANTIC) and by
proof status, and reports the ratio of VERIFIED + PARTIALLY_VERIFIED assertions to total
assertions. Invoked at G6 and on-demand.

`check_rule_classification.py` — CI gate script. Validates that every assertion in every
registered assertions file has a non-null `proof_status` drawn from the four-value enum,
and that no assertion is silently unclassified. Exit code 1 if any assertion lacks a
valid `proof_status`. This replaces the implicit assumption that an unregistered rule is
automatically compliant.

---

**7. Phase 1 bootstrap scope**

To avoid a 21-contract migration project while delivering the first honest coverage
report, only four contracts are bootstrapped with assertions files at Phase 1:

| Contract | Rationale |
|---|---|
| `SYS-C-0010` | First ENUMERATIVE proof target; closes the incident that motivated this ADR |
| `SYS-C-0006` | Event pipeline contract; ENUMERATIVE event-type and payload-field assertions are high-value and directly testable with PS-0001 |
| `HAR-C-0002` | SDLC contract; key STRUCTURAL and HUMAN_REVIEW assertions; establishes the HUMAN_REVIEW pattern for process rules |
| `HAR-C-0003` | Testing contract; coverage thresholds are QUALITY assertions; establishes the first QUALITY class entry |

All remaining contracts start with an empty assertions file or no file at all. Their
absence from the coverage report is itself signal: they are UNVERIFIED by declaration,
not by omission. Future tasks register assertions for additional contracts one class at
a time.

---

### Consequences

**Positive:**
- The SYS-C-0010 failure class (missing columns in alembic DDL undetected by gate review)
  is mechanically closed by VM.5 for all current and future ENUMERATIVE assertions.
- Every gap in the harness's proof coverage is now explicitly visible in the coverage
  matrix rather than hidden behind the "cited = verified" assumption.
- `HUMAN_REVIEW` and `UNVERIFIED` are first-class, honest statuses — not failures — which
  removes the incentive to over-claim verification.
- The Atomic Rule Principle forces contract authors to decompose vague compound rules,
  improving contract clarity as a side effect.
- The dispatcher and coverage scripts are zero-LLM, deterministic, and runnable locally
  or in CI without any AI agent involvement.

**Negative / Trade-offs:**
- Bootstrapping assertions YAML for even four contracts requires careful decomposition of
  contract prose into atomic claims; this is a non-trivial authoring effort.
- The dispatcher adds a CI step (~1 s per contract) at G4 and G5; pipelines with many
  registered assertions will see cumulative overhead over time.
- `HUMAN_REVIEW` assertions depend on human discipline at G2/G5; they cannot be
  mechanically enforced and remain vulnerable to reviewer fatigue.
- The assertions registry is a second representation of contract rules; it must be kept
  in sync with the Markdown contracts when contracts are amended.

**Neutral / Operational notes:**
- Contracts remain Markdown prose. No DSL or compiler is introduced.
- Registries are YAML files read by Python scripts; no new database or service is needed.
- The proof obligation metadata lives in the assertions registry files, not embedded in
  the Markdown contracts — contracts remain human-readable without tooling.
- `HAR-C-0009` will be written as a separate harness contract to define the registry
  schemas, dispatcher protocol, proof status enum, and CI gate rules introduced here.
  This ADR is the authoritative architectural decision; HAR-C-0009 is its operational
  specification.

---

### Alternatives Considered

| Alternative | Why Rejected |
|---|---|
| Embed proof metadata in contract Markdown (YAML front-matter or inline annotations) | Couples proof metadata to contract prose; makes contracts harder to read; changes to proof strategy require editing the contract file; rejected in favour of the separate assertions registry |
| Use a DSL or custom compiler for contracts | Significant toolchain investment; agents cannot easily read or generate a custom language; breaks the "contracts are Markdown" invariant that all agents rely on; no meaningful gain over structured YAML |
| Full migration of all 21 contracts at bootstrap | Months of assertion-authoring work with no intermediate value delivered; risks analysis paralysis and stale assertions; the phased bootstrap with explicit UNVERIFIED tagging delivers honest coverage incrementally |
| Rely solely on agent-based review at G2/G5 for ENUMERATIVE rules | Proved insufficient — the SYS-C-0010 incident cleared three agent gate reviews; mechanical diff is necessary for the ENUMERATIVE class |
| Add an inventory diff check only for SYS-C-0010 without a registry layer | Solves one incident without closing the class; the next missing-column incident in a different table would require another one-off script; the registry layer generalises the solution to all ENUMERATIVE assertions |

---

### Compliance

- Contract: `constitution/harness/contracts/HAR-C-0009-proof-obligation-registry.md` _(created; defines registry schemas, dispatcher protocol, and CI gate rules)_
- Contract: `constitution/harness/contracts/HAR-C-0002-sdlc-contract.md` §6 _(amended: add proof coverage report to G5 gate check)_
- Contract: `constitution/harness/contracts/HAR-C-0003-testing-contract.md` §1 _(amended: add inventory-diff test type for ENUMERATIVE assertions)_
- Contract: `constitution/system/contracts/SYS-C-0010-db-schema-contract.md` _(first ENUMERATIVE bootstrap target; SYS-C-0010.yaml assertions file closes the `function_facts` column gap)_
- Contract: `constitution/system/contracts/SYS-C-0006-event-pipeline-contract.md` _(second ENUMERATIVE bootstrap target)_
- Script: `constitution/harness/scripts/check_contract_fidelity.py` _(VM.5 — ENUMERATIVE inventory diff; exit 1 on missing item)_
- Script: `constitution/harness/scripts/run_proof_dispatcher.py` _(invokes registered evidence provider per assertion; invoked at G4/G5)_
- Script: `constitution/harness/scripts/report_coverage.py` _(aggregates VERIFIED/PARTIALLY_VERIFIED/HUMAN_REVIEW/UNVERIFIED across all assertion files; invoked at G6)_
- Script: `constitution/harness/scripts/check_rule_classification.py` _(CI gate: every assertion must have a valid proof_status; exit 1 on unclassified)_
- Registry: `constitution/harness/registries/proof-strategies.yaml` _(PS-0001…PS-0012 closed enumeration)_
- Registry: `constitution/harness/registries/evidence-providers.yaml` _(VM.1…VM.5+ executor map)_
- Registry: `constitution/harness/registries/assertions/<contract-id>.yaml` _(one file per bootstrapped contract)_

---

## Deviations

Two functional corrections were applied during G5 code review:

1. **`_extract_event_types` column scope** (`check_contract_fidelity.py`): Initial implementation matched only backtick-quoted identifiers in the first Markdown table column. VM.5 exit-1 failure for `SYS-C-0006-A-002` revealed that message-broker topic names (`{project_prefix}.*`) appear in the second column without backticks. Fix: extended the parser to scan all table cells for backtick-quoted lowercase dotted identifiers. All 11 Phase 1 topic names now extract correctly; VM.5 exits 0 for both SYS-C-0006 assertions.

2. **`report_coverage.py` output format** (`report_coverage.py`): Initial implementation emitted a Markdown table. HAR-C-0009 §6 specifies a plain-text line-per-class format (`ENUMERATIVE: N verified / M total (X%)`). Fix: replaced `_format_markdown()` with `_format_plain_text()` producing the normative output. Test T13-005 updated to assert plain-text format and absence of Markdown table headers.

Both deviations were caught and resolved within the G5 gate. No interface changes; no spec amendments required.
