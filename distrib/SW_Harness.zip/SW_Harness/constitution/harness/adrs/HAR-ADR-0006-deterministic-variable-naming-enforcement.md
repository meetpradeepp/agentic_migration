﻿## HAR-ADR-0006: Deterministic Variable Naming Enforcement Gate

**Status:** Proposed
**Date:** 2026-05-14
**Deciders:** Lead Engineer, Architecture Review
**Supersedes:** -
**Superseded by:** -
**FACT impact:**
- Fast: `neutral` - naming lint runs in CI Stage 1 with low overhead relative to existing lint checks.
- Accurate: `improves` - descriptive symbol names reduce interpretation ambiguity and review misreads.
- Complete: `improves` - deterministic scope + exception rules enforce readability consistently across modules.
- Trustworthy: `improves` - machine-readable lint findings produce auditable, repeatable CI decisions without human or LLM judgment.

---

### Context

{project_name} requires deterministic quality gates and forbids runtime LLM dependence for correctness guarantees. Code review feedback shows recurring churn from one-letter or ambiguous variable names in business logic, increasing review latency and defect risk. HAR-C-0001 defines coding standards and HAR-C-0008 already recommends naming clarity, but current enforcement is advisory rather than a deterministic CI blocker. HAR-C-0002 requires CI Stage 1 lint gates before review; therefore naming clarity must be enforceable in that stage with objective, measurable rules. The policy must preserve legitimate short identifiers used in tiny loop counters, math-only notation, and intentional unpack throwaways to avoid noisy false positives. This decision introduces a deterministic naming rule and standardized failure payload so pipeline and local tooling behave identically.

---

### Decision

We will add a deterministic CI Stage 1 lint policy that rejects one-letter or ambiguous business variable names in non-trivial scopes, with a fixed exception list and machine-readable failure output.

- Rule ID: `HAR-NAMING-001` (non-trivial scope business variable naming).
- Rejected names:
  - Any one-letter identifier used as a business/state/dependency variable in non-trivial scope.
  - Ambiguous short names from the fixed denylist: `tmp`, `val`, `obj`, `res`, `ret`, `data`, `item`, `thing`, `x1`, `y1`.
- Non-trivial scope definition (deterministic; any one condition is sufficient):
  - Function or method has 10 or more logical code lines (blank lines and comments excluded), or
  - Function or method declares 3 or more local variables excluding parameters, or
  - Scope contains at least one branch/flow construct (`if`, `elif`, `match`, `try`, `for`, `while`, `with`), or
  - Scope performs at least one external boundary operation (database call, file/artifact I/O, network/message-broker operation).
- Deterministic exception list (allowed):
  - Tiny loop indices: `i`, `j`, `k` only when the loop body is 3 or fewer logical lines and the index is not used after the loop.
  - Math-only notation: `x`, `y`, `z`, `n`, `m` only when values are numeric and used solely inside explicit formula/math contexts.
  - Unpack throwaways: `_` (and repeated `_` in separate unpack sites) for intentionally ignored values.
  - Generator/comprehension local index variables equivalent to tiny loop indices under the same body-size rule.
- Enforcement points:
  - CI Stage 1 lint gate MUST fail on any `HAR-NAMING-001` violation.
  - Local developer workflow and pre-commit MUST run the same rule/configuration as CI Stage 1.
  - Lint output MUST be machine-readable JSON with one record per finding containing: `path`, `line`, `column`, `symbol`, `rule_id`, `reason`, `scope_kind`, `scope_metrics`.
- Determinism guardrail:
  - Rule evaluation uses AST/token metrics only; no probabilistic models, heuristics requiring external services, or LLM inference.

---

### Consequences

**Positive:**

- Naming quality becomes an objective merge gate instead of reviewer preference drift.
- Review cycles shorten because business intent is encoded in variable names by default.
- CI and local parity reduces "passes locally, fails in pipeline" friction.
- Structured findings support pipeline reporting and future trend analysis.

**Negative / Trade-offs:**

- Initial adoption may surface many legacy findings and temporarily increase PR friction.
- Some contextually acceptable short names may be flagged until explicit exceptions are encoded.
- Teams must tune habitual coding patterns to satisfy deterministic naming constraints.

**Neutral / Operational notes:**

- Rollout/migration is staged to minimize false-positive noise:
  - Phase A (baseline): run `HAR-NAMING-001` in report-only mode on existing code and capture suppression candidates.
  - Phase B (changed-lines enforcement): fail only on violations in modified lines/files.
  - Phase C (full enforcement): fail on all violations after baseline debt is reduced to agreed threshold.
- Suppressions, where absolutely necessary, must be explicit, line-scoped, and justified in code review.
- Rule and exception set changes require constitution-aligned review to preserve deterministic behavior.

---

### Alternatives Considered

| Alternative | Why Rejected |
|-------------|-------------|
| Reviewer-only naming guidance | Non-deterministic and inconsistent across reviewers; violates objective gate intent in HAR-C-0002. |
| LLM-based readability scoring | Probabilistic output and model drift conflict with {project_name}'s deterministic/no-LLM runtime principles. |
| Blanket ban on all one-letter identifiers | Overly rigid; creates false positives in legitimate loop/math/unpack contexts and harms developer ergonomics. |

---

### Compliance

- Contract: `constitution/harness/contracts/HAR-C-0001-coding-standards.md` (coding standards become enforceable via deterministic naming lint)
- Contract: `constitution/harness/contracts/HAR-C-0002-sdlc-contract.md` (CI Stage 1 lint gate enforcement and review readiness)
- Contract: `constitution/harness/contracts/HAR-C-0008-implementation-guidelines.md` (naming clarity pattern elevated from guidance to enforced rule)
- ADR: `constitution/harness/adrs/HAR-ADR-0002-agent-token-optimization.md` (compact, deterministic lint output aligns with token-efficient agent workflows)
- ADR: `constitution/harness/adrs/HAR-ADR-0003-pipeline-workspace.md` (lint report artifact recorded in pipeline workspace for gate evidence)
- ADR: `constitution/harness/adrs/HAR-ADR-0005-sast-toolchain.md` (reuses deterministic gate and machine-readable report pattern)
- Schema: `constitution/schemas/` (no persistent data schema change; lint finding JSON schema introduced in implementation spec)
- Eval: `eval_naming_gate_deterministic`, `eval_naming_gate_changed_lines`, `eval_lint_report_schema`
