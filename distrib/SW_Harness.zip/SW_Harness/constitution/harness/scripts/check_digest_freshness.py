﻿"""
Digest freshness governance script for {project_name}.

The update chain for contract digests is two-step:

  1. Source contract edited
       → manually update `.github/memory/constitution-digest.md`
  2. constitution-digest.md updated
       → run `python scripts/generate_micro_index.py`
       → per-contract digest files under `.github/memory/contract-digests/` are regenerated

This script enforces both steps:
  Check 1 — every source contract has a matching per-contract digest file.
  Check 2 — no source contract is newer than constitution-digest.md
             (catches: contract edited but constitution-digest.md not updated).
  Check 3 — no source contract is newer than its per-contract digest
             (catches: generate_micro_index.py not run after editing constitution-digest.md).
  Check 4 — micro-index.md row counts match actual contract + ADR file counts.
  Check 5 (--strict) — each per-contract digest covers the same ## sections as the source.

Implements: HAR-ADR-0009 — Token-Efficient Validation (governance check D4.2).

Usage:
    python scripts/check_digest_freshness.py           # run checks 1-4
    python scripts/check_digest_freshness.py --strict  # also run check 5

Exit codes:
    0  All digests are present and up to date.
    1  One or more digests are missing or stale.
    2  Script error (bad args, file not found, parse failure).
"""

from __future__ import annotations

import argparse
import re
import sys
from pathlib import Path

# WORKSPACE_ROOT removed — use load_config() from harness_config instead

# Contracts live under two subdirectories (split layout).
CONTRACTS_DIRS = [
    WORKSPACE_ROOT / "constitution" / "harness" / "contracts",
    WORKSPACE_ROOT / "constitution" / "system" / "contracts",
]
# ADRs live under two subdirectories (split layout).
ADRS_DIRS = [
    WORKSPACE_ROOT / "constitution" / "harness" / "adrs",
    WORKSPACE_ROOT / "constitution" / "system" / "adrs",
]

CONSTITUTION_DIGEST_FILE = WORKSPACE_ROOT / ".github" / "memory" / "constitution-digest.md"
DIGEST_DIR = WORKSPACE_ROOT / ".github" / "memory" / "contract-digests"
MICRO_INDEX_FILE = WORKSPACE_ROOT / ".github" / "memory" / "micro-index.md"

# Matches filenames like HAR-C-0002-sdlc-contract.md or SYS-C-0001-fact-contract.md
_CONTRACT_ID_PATTERN = re.compile(r"^((?:HAR|SYS)-C-\d{4})", re.IGNORECASE)


def _contract_id_to_digest_name(contract_id: str) -> str:
    """Map e.g. 'HAR-C-0002' → 'contract-har-c-0002-digest.md'."""
    return f"contract-{contract_id.lower()}-digest.md"


def _list_contract_files() -> list[tuple[str, Path]]:
    """Return [(contract_id, path)] for every contract file, sorted by ID."""
    contracts: list[tuple[str, Path]] = []
    for contracts_dir in CONTRACTS_DIRS:
        if not contracts_dir.exists():
            continue
        for contract_file in contracts_dir.glob("*.md"):
            match = _CONTRACT_ID_PATTERN.match(contract_file.name)
            if match:
                contracts.append((match.group(1).upper(), contract_file))
    return sorted(contracts, key=lambda pair: pair[0])


def _list_adr_files() -> list[Path]:
    """Return all ADR files across both ADR directories."""
    adrs: list[Path] = []
    for adrs_dir in ADRS_DIRS:
        if adrs_dir.exists():
            adrs.extend(adrs_dir.glob("*.md"))
    return adrs


def _check_digest_coverage(
    contracts: list[tuple[str, Path]],
) -> list[str]:
    """
    Check 1: every contract file has a matching per-contract digest file.
    Returns list of error messages.
    """
    errors: list[str] = []

    if not DIGEST_DIR.exists():
        errors.append(
            f"MISSING_DIR  {DIGEST_DIR.relative_to(WORKSPACE_ROOT)} — "
            f"contract-digests/ directory does not exist; "
            f"run 'python scripts/generate_micro_index.py' to create it."
        )
        return errors

    for contract_id, _contract_path in contracts:
        digest_path = DIGEST_DIR / _contract_id_to_digest_name(contract_id)
        if not digest_path.exists():
            errors.append(
                f"MISSING  {digest_path.relative_to(WORKSPACE_ROOT)} — "
                f"no digest for {contract_id}; "
                f"update .github/memory/constitution-digest.md then run "
                f"'python scripts/generate_micro_index.py'."
            )

    return errors


def _check_constitution_digest_staleness(
    contracts: list[tuple[str, Path]],
) -> list[str]:
    """
    Check 2: no source contract is newer than constitution-digest.md.
    If a contract is newer, constitution-digest.md needs a manual update.
    Returns list of error messages.
    """
    errors: list[str] = []

    if not CONSTITUTION_DIGEST_FILE.exists():
        errors.append(
            f"MISSING  {CONSTITUTION_DIGEST_FILE.relative_to(WORKSPACE_ROOT)} — "
            f"constitution-digest.md not found."
        )
        return errors

    digest_mtime = CONSTITUTION_DIGEST_FILE.stat().st_mtime

    for contract_id, contract_path in contracts:
        if contract_path.stat().st_mtime > digest_mtime:
            errors.append(
                f"STALE_DIGEST  {contract_path.relative_to(WORKSPACE_ROOT)} is newer than "
                f"constitution-digest.md — manually update the '{contract_id}' section in "
                f".github/memory/constitution-digest.md, then run "
                f"'python scripts/generate_micro_index.py'."
            )

    return errors


def _check_per_contract_digest_staleness(
    contracts: list[tuple[str, Path]],
) -> list[str]:
    """
    Check 3: no source contract is newer than its per-contract digest file.
    If the per-contract digest is stale but constitution-digest.md is fresh,
    generate_micro_index.py just needs to be run.
    Returns list of error messages.
    """
    errors: list[str] = []

    if not DIGEST_DIR.exists():
        return errors  # already reported in check_digest_coverage

    constitution_digest_mtime = (
        CONSTITUTION_DIGEST_FILE.stat().st_mtime if CONSTITUTION_DIGEST_FILE.exists() else 0.0
    )

    for contract_id, contract_path in contracts:
        digest_path = DIGEST_DIR / _contract_id_to_digest_name(contract_id)
        if not digest_path.exists():
            continue  # already reported in check_digest_coverage

        digest_mtime = digest_path.stat().st_mtime
        contract_mtime = contract_path.stat().st_mtime

        if contract_mtime > digest_mtime:
            if contract_mtime > constitution_digest_mtime:
                # constitution-digest.md also stale — already reported in Check 2
                continue
            # constitution-digest.md is fresh; just need to run generate_micro_index.py
            errors.append(
                f"STALE_MICRO  {digest_path.relative_to(WORKSPACE_ROOT)} — "
                f"constitution-digest.md was updated but generate_micro_index.py has not been run; "
                f"run 'python scripts/generate_micro_index.py' to refresh."
            )

    return errors


def _check_micro_index_row_counts(
    contracts: list[tuple[str, Path]],
    adr_files: list[Path],
) -> list[str]:
    """
    Check 4: micro-index.md row counts match actual contract + ADR file counts.
    Returns list of error messages.
    """
    errors: list[str] = []

    if not MICRO_INDEX_FILE.exists():
        errors.append(
            f"MISSING  {MICRO_INDEX_FILE.relative_to(WORKSPACE_ROOT)} — "
            f"micro-index.md not found; run 'python scripts/generate_micro_index.py' to create it."
        )
        return errors

    actual_contract_count = len(contracts)
    content = MICRO_INDEX_FILE.read_text(encoding="utf-8")

    # Count contract rows: lines matching "| HAR-C-NNNN |" or "| SYS-C-NNNN |"
    contract_rows = len(
        re.findall(r"^\|\s*(?:HAR|SYS)-C-\d{4}\s*\|", content, re.MULTILINE | re.IGNORECASE)
    )
    # Count ADR rows: lines matching "| HAR-ADR-NNNN |" or "| SYS-ADR-NNNN |"
    adr_rows = len(
        re.findall(r"^\|\s*(?:HAR|SYS)-ADR-\d{4}\s*\|", content, re.MULTILINE | re.IGNORECASE)
    )

    if contract_rows != actual_contract_count:
        errors.append(
            f"ROW_COUNT  micro-index.md has {contract_rows} contract rows, "
            f"expected {actual_contract_count}; "
            f"run 'python scripts/generate_micro_index.py' to refresh."
        )
    if adr_rows == 0 and adr_files:
        errors.append(
            f"ROW_COUNT  micro-index.md has no ADR rows but {len(adr_files)} ADR files exist; "
            f"run 'python scripts/generate_micro_index.py' to refresh."
        )
    # ADR table in micro-index is intentionally curated (key ADRs only), not exhaustive.
    # The check above only validates that at least some ADR rows are present.

    return errors


def _check_section_headers(
    contracts: list[tuple[str, Path]],
) -> list[str]:
    """
    Check 5 (--strict): each per-contract digest covers the same ## sections as the source.
    Returns list of error messages.
    """
    errors: list[str] = []

    for contract_id, contract_path in contracts:
        digest_path = DIGEST_DIR / _contract_id_to_digest_name(contract_id)
        if not digest_path.exists():
            continue  # already reported in check_digest_coverage

        contract_headers = set(
            re.findall(r"^##\s+(.+)$", contract_path.read_text(encoding="utf-8"), re.MULTILINE)
        )
        digest_headers = set(
            re.findall(r"^##\s+(.+)$", digest_path.read_text(encoding="utf-8"), re.MULTILINE)
        )

        missing_in_digest = contract_headers - digest_headers
        if missing_in_digest:
            errors.append(
                f"HEADERS  {_contract_id_to_digest_name(contract_id)} is missing sections: "
                + ", ".join(sorted(f'"{h}"' for h in missing_in_digest))
                + " — update .github/memory/constitution-digest.md then re-run "
                "'python scripts/generate_micro_index.py'."
            )

    return errors


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Check contract digest freshness and micro-index row counts (HAR-ADR-0009)."
    )
    parser.add_argument(
        "--strict",
        action="store_true",
        help="Also validate that per-contract digests cover all source ## sections (Check 5).",
    )
    args = parser.parse_args()

    try:
        contracts = _list_contract_files()
        adr_files = _list_adr_files()
    except Exception as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        sys.exit(2)

    if not contracts:
        print(
            "No contract files found under constitution/harness/contracts/ "
            "or constitution/system/contracts/."
        )
        sys.exit(0)

    all_errors: list[str] = []
    all_errors.extend(_check_digest_coverage(contracts))
    all_errors.extend(_check_constitution_digest_staleness(contracts))
    all_errors.extend(_check_per_contract_digest_staleness(contracts))
    all_errors.extend(_check_micro_index_row_counts(contracts, adr_files))
    if args.strict:
        all_errors.extend(_check_section_headers(contracts))

    if all_errors:
        mode_note = " (strict)" if args.strict else ""
        print(
            f"check_digest_freshness{mode_note}: {len(all_errors)} issue(s) found "
            f"across {len(contracts)} contract(s).\n"
        )
        for error_message in all_errors:
            print(f"  {error_message}")
        sys.exit(1)
    else:
        mode_note = " (strict)" if args.strict else ""
        print(
            f"check_digest_freshness{mode_note}: OK — {len(contracts)} contract digest(s) "
            f"are present and up to date."
        )
        sys.exit(0)


if __name__ == "__main__":
    main()
