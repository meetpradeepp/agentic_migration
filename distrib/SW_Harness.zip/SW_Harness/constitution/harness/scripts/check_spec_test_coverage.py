﻿"""
check_spec_test_coverage.py — Mechanical spec-to-test AC coverage checker.

Implements: HAR-C-0003 §1, HAR-C-0002 §6 (point 8 — acceptance criteria covered).

PURPOSE
-------
This script is the **independent, executable evidence** that closes the AI-attestation
gap identified in the {project_name} process audit. The validator agent can only attest
probabilistically that tests cover acceptance criteria. This script verifies it
mechanically by parsing both the spec and the test file and cross-referencing them.

WHAT IT CHECKS
--------------
For each spec file (or the one spec given via --spec):

  1. Extracts every AC-N ID from the ``## Acceptance criteria`` table.
  2. Extracts every T-N ID from the ``## Tests required`` section.
  3. Scans every test file declared in ``## Tests required`` for:
       - The ``# Implements: SPEC-NNNN`` traceability header.
       - A test function name containing the AC/T ID in a comment or stub.
  4. Reports any AC or T item with no corresponding test stub in the declared file.

EXIT CODES
----------
  0  All acceptance criteria and test IDs have matching stubs. Gate passes.
  1  One or more ACs or test IDs are uncovered. Gate fails.
  2  Script error (file not found, parse failure, bad arguments).

USAGE
-----
  # Check a single spec
  python scripts/check_spec_test_coverage.py --spec {specs_dir}/SPEC-0014-fact-find-table-owners.md

  # Check all specs in a phase
  python scripts/check_spec_test_coverage.py --phase 1

  # Check all specs (all phases)
  python scripts/check_spec_test_coverage.py --all

  # Emit JSON report (for CI artifact upload)
  python scripts/check_spec_test_coverage.py --phase 1 --json

CI INTEGRATION
--------------
Add to CI Stage 1 (unit tests job), after pytest:

  python scripts/check_spec_test_coverage.py --phase 1
"""

from __future__ import annotations

import argparse
import json
import re
import sys
from dataclasses import dataclass, field
from pathlib import Path

# WORKSPACE_ROOT removed — use load_config() from harness_config instead
# SPECS_DIR — resolved via HarnessConfig.specs_dir
TESTS_DIR = WORKSPACE_ROOT / "tests"

# ---------------------------------------------------------------------------
# Patterns
# ---------------------------------------------------------------------------

# Acceptance criteria table row: | AC-N | Given | Input | Expected |
_AC_ID_PATTERN = re.compile(r"\|\s*(AC-\d+)\s*\|")

# Tests required section: T-N or T-NN
_TEST_ID_PATTERN = re.compile(r"\b(T-?\d+)\b")

# Tests required file declaration: handles subdirs like tests/unit/mcp/test_foo.py
_TEST_FILE_PATH_PATTERN = re.compile(r"(tests/(?:unit|integration|eval)/(?:\w+/)*test_\w+\.py)")

# Spec header: SPEC-NNNN
_SPEC_ID_PATTERN = re.compile(r"^#\s+(SPEC-\d+)", re.MULTILINE)

# Implements header in test file
_IMPLEMENTS_HEADER_PATTERN = re.compile(r"#\s+Implements:\s+(SPEC-\d+(?:,\s*SPEC-\d+)*)")

# AC or T reference in a test function name or inline comment
_AC_IN_TEST_PATTERN = re.compile(r"\b(AC-\d+|T-?\d+|T-M\d+|T-C\d+)\b")

# T-M and T-C IDs in Tests required section
_T_M_ID_PATTERN = re.compile(r"\b(T-M\d+)\b")
_T_C_ID_PATTERN = re.compile(r"\b(T-C\d+)\b")

# Section headers
_SECTION_PATTERN = re.compile(r"^##\s+(.+)$", re.MULTILINE)


# ---------------------------------------------------------------------------
# Data types
# ---------------------------------------------------------------------------


@dataclass
class ConstraintEntry:
    entry_type: str        # "mechanism" | "config"
    must_call: str = ""
    must_not_call: str = ""
    ordering: list[str] = field(default_factory=list)
    config_key: str = ""
    config_value: str = ""


@dataclass
class CoverageGap:
    spec_id: str
    gap_type: str  # "AC" | "T" | "HEADER" | "FILE_MISSING"
    item_id: str  # "AC-3" | "T7" | "SPEC-0014" | path
    test_file: str
    message: str


@dataclass
class SpecCoverageReport:
    spec_id: str
    spec_file: str
    ac_ids: list[str] = field(default_factory=list)
    test_ids: list[str] = field(default_factory=list)
    tm_ids: list[str] = field(default_factory=list)   # T-M entries from Tests required
    tc_ids: list[str] = field(default_factory=list)   # T-C entries from Tests required
    constraints: list[ConstraintEntry] = field(default_factory=list)
    declared_test_files: list[str] = field(default_factory=list)
    gaps: list[CoverageGap] = field(default_factory=list)

    @property
    def passed(self) -> bool:
        return len(self.gaps) == 0


# ---------------------------------------------------------------------------
# Spec parsing
# ---------------------------------------------------------------------------


def _extract_section(spec_text: str, section_title: str) -> str:
    """Return text between ## <section_title> and the next ## heading."""
    section_pattern = re.compile(
        rf"^##\s+{re.escape(section_title)}\s*$(.+?)(?=^##\s|\Z)",
        re.MULTILINE | re.DOTALL | re.IGNORECASE,
    )
    match = section_pattern.search(spec_text)
    return match.group(1) if match else ""


def parse_spec(spec_file: Path) -> SpecCoverageReport:
    """Parse a spec file and return a coverage report scaffold (no gaps yet)."""
    spec_text = spec_file.read_text(encoding="utf-8")

    spec_id_match = _SPEC_ID_PATTERN.search(spec_text)
    spec_id = spec_id_match.group(1) if spec_id_match else spec_file.stem.upper()

    report = SpecCoverageReport(
        spec_id=spec_id,
        spec_file=str(spec_file.relative_to(WORKSPACE_ROOT)),
    )

    # Extract AC IDs from Acceptance criteria section
    ac_section = _extract_section(spec_text, "Acceptance criteria")
    report.ac_ids = _AC_ID_PATTERN.findall(ac_section)

    # Extract T-IDs, T-M IDs, T-C IDs and file paths from Tests required section
    tests_section = _extract_section(spec_text, "Tests required")
    report.test_ids = list(
        dict.fromkeys(_TEST_ID_PATTERN.findall(tests_section))
    )  # deduplicated, ordered
    report.tm_ids = list(dict.fromkeys(_T_M_ID_PATTERN.findall(tests_section)))
    report.tc_ids = list(dict.fromkeys(_T_C_ID_PATTERN.findall(tests_section)))
    report.declared_test_files = list(dict.fromkeys(_TEST_FILE_PATH_PATTERN.findall(tests_section)))

    # Parse ## Constraints YAML block (HAR-ADR-0022)
    report.constraints = _parse_constraints(spec_text)

    return report


def _parse_constraints(spec_text: str) -> list[ConstraintEntry]:
    """Parse the ## Constraints YAML block from a spec. Returns empty list if absent or empty."""
    import yaml  # local import — only needed when Constraints section exists

    constraints_section = _extract_section(spec_text, "Constraints")
    if not constraints_section.strip():
        return []

    # Extract the fenced YAML block (```yaml ... ```)
    yaml_fence = re.search(r"```ya?ml\s*\n(.+?)```", constraints_section, re.DOTALL)
    if not yaml_fence:
        return []

    try:
        data = yaml.safe_load(yaml_fence.group(1))
    except yaml.YAMLError:
        return []  # malformed YAML — validator will catch structural issues

    if not isinstance(data, dict):
        return []

    entries: list[ConstraintEntry] = []

    for mech in data.get("mechanism") or []:
        if not isinstance(mech, dict):
            continue
        if "ordering" in mech:
            entries.append(ConstraintEntry(
                entry_type="mechanism",
                ordering=mech["ordering"] if isinstance(mech["ordering"], list) else [],
            ))
        else:
            entries.append(ConstraintEntry(
                entry_type="mechanism",
                must_call=str(mech.get("must_call", "")),
                must_not_call=str(mech.get("must_not_call", "")),
            ))

    for cfg in data.get("config") or []:
        if not isinstance(cfg, dict):
            continue
        entries.append(ConstraintEntry(
            entry_type="config",
            config_key=str(cfg.get("key", "")),
            config_value=str(cfg.get("value", "")),
        ))

    return entries


# ---------------------------------------------------------------------------
# Test file scanning
# ---------------------------------------------------------------------------


def _collect_covered_items(test_file_abs: Path, spec_id: str) -> tuple[set[str], bool]:
    """
    Return (set of AC/T IDs found in the test file, implements_header_present).

    Scans for: inline ``# AC-N`` / ``# T-N`` comments, test function name patterns
    like ``test_ac3_`` or ``test_t7_``, and the ``# Implements: SPEC-NNNN`` header.
    """
    if not test_file_abs.exists():
        return set(), False

    test_text = test_file_abs.read_text(encoding="utf-8")

    implements_match = _IMPLEMENTS_HEADER_PATTERN.search(test_text)
    implements_present = False
    if implements_match:
        declared_specs = [s.strip() for s in implements_match.group(1).split(",")]
        implements_present = spec_id in declared_specs

    covered: set[str] = set()
    for raw_id in _AC_IN_TEST_PATTERN.findall(test_text):
        # Normalize: "T7" and "T-7" both mean the same thing
        normalized = raw_id.replace("T-", "T").upper()
        covered.add(normalized)
        # Also store the original for AC- IDs
        covered.add(raw_id.upper())

    return covered, implements_present


def _normalize_test_id(raw_id: str) -> str:
    """Normalize T-7 / T7 / t7 to a canonical uppercase form for comparison."""
    return raw_id.upper().replace("T-", "T")


# ---------------------------------------------------------------------------
# Coverage check
# ---------------------------------------------------------------------------


def check_spec_coverage(spec_file: Path) -> SpecCoverageReport:
    """Run coverage check for one spec. Returns a SpecCoverageReport with gaps populated."""
    report = parse_spec(spec_file)

    if not report.declared_test_files:
        # Spec has no tests required section — warn but do not fail (some specs are pure interface specs)
        if report.ac_ids:
            report.gaps.append(
                CoverageGap(
                    spec_id=report.spec_id,
                    gap_type="FILE_MISSING",
                    item_id="(none declared)",
                    test_file="",
                    message=(
                        f"{report.spec_id} has {len(report.ac_ids)} AC(s) but no test files "
                        f"declared in '## Tests required'. Add file paths."
                    ),
                )
            )
        return report

    # Collect all covered items across all declared test files
    all_covered: set[str] = set()
    for relative_test_path in report.declared_test_files:
        test_file_abs = WORKSPACE_ROOT / relative_test_path

        if not test_file_abs.exists():
            report.gaps.append(
                CoverageGap(
                    spec_id=report.spec_id,
                    gap_type="FILE_MISSING",
                    item_id=relative_test_path,
                    test_file=relative_test_path,
                    message=f"Declared test file does not exist: {relative_test_path}",
                )
            )
            continue

        covered_items, implements_present = _collect_covered_items(test_file_abs, report.spec_id)
        all_covered.update(covered_items)

        if not implements_present:
            report.gaps.append(
                CoverageGap(
                    spec_id=report.spec_id,
                    gap_type="HEADER",
                    item_id=report.spec_id,
                    test_file=relative_test_path,
                    message=(
                        f"Missing '# Implements: {report.spec_id}' traceability header "
                        f"in {relative_test_path} (HAR-C-0002 §7, shared-rules §3)"
                    ),
                )
            )

    # Check AC coverage
    for ac_id in report.ac_ids:
        if ac_id.upper() not in all_covered:
            report.gaps.append(
                CoverageGap(
                    spec_id=report.spec_id,
                    gap_type="AC",
                    item_id=ac_id,
                    test_file=", ".join(report.declared_test_files),
                    message=(
                        f"{ac_id} has no test stub in declared test file(s). "
                        f"Add a function containing '# {ac_id}' or referencing it in the test body."
                    ),
                )
            )

    # Check T-ID coverage (declared test IDs vs. found in test files)
    for raw_test_id in report.test_ids:
        normalized = _normalize_test_id(raw_test_id)
        if normalized not in all_covered and raw_test_id.upper() not in all_covered:
            report.gaps.append(
                CoverageGap(
                    spec_id=report.spec_id,
                    gap_type="T",
                    item_id=raw_test_id,
                    test_file=", ".join(report.declared_test_files),
                    message=(
                        f"{raw_test_id} is listed in '## Tests required' but no matching "
                        f"test function or comment found. Add stub or inline reference."
                    ),
                )
            )

    # Check T-M coverage — one T-M entry per mechanism: Constraints entry (HAR-ADR-0022)
    mechanism_entries = [c for c in report.constraints if c.entry_type == "mechanism" and c.must_call]
    if mechanism_entries and not report.tm_ids:
        report.gaps.append(
            CoverageGap(
                spec_id=report.spec_id,
                gap_type="T-M",
                item_id="(all mechanism constraints)",
                test_file=", ".join(report.declared_test_files),
                message=(
                    f"{report.spec_id} has {len(mechanism_entries)} mechanism Constraints "
                    f"entries but no T-M tests in '## Tests required'. "
                    f"Add 'T-M<n>: ...' rows to the Mechanism tests subsection."
                ),
            )
        )
    elif len(mechanism_entries) > len(report.tm_ids):
        report.gaps.append(
            CoverageGap(
                spec_id=report.spec_id,
                gap_type="T-M",
                item_id="(under-covered)",
                test_file=", ".join(report.declared_test_files),
                message=(
                    f"{report.spec_id} has {len(mechanism_entries)} mechanism Constraints entries "
                    f"but only {len(report.tm_ids)} T-M test(s) declared. Each mechanism entry needs one T-M test."
                ),
            )
        )

    # Check T-C coverage — one T-C entry per config: Constraints entry (HAR-ADR-0022)
    config_entries = [c for c in report.constraints if c.entry_type == "config"]
    if config_entries and not report.tc_ids:
        report.gaps.append(
            CoverageGap(
                spec_id=report.spec_id,
                gap_type="T-C",
                item_id="(all config constraints)",
                test_file=", ".join(report.declared_test_files),
                message=(
                    f"{report.spec_id} has {len(config_entries)} config Constraints "
                    f"entries but no T-C tests in '## Tests required'. "
                    f"Add 'T-C<n>: ...' rows to the Contract tests subsection."
                ),
            )
        )
    elif len(config_entries) > len(report.tc_ids):
        report.gaps.append(
            CoverageGap(
                spec_id=report.spec_id,
                gap_type="T-C",
                item_id="(under-covered)",
                test_file=", ".join(report.declared_test_files),
                message=(
                    f"{report.spec_id} has {len(config_entries)} config Constraints entries "
                    f"but only {len(report.tc_ids)} T-C test(s) declared. Each config entry needs one T-C test."
                ),
            )
        )

    # Static grep: must_not_call symbols must not appear anywhere in source files (HAR-ADR-0022)
    _check_must_not_call(report)

    return report


def _check_must_not_call(report: SpecCoverageReport) -> None:
    """Static grep: if must_not_call symbol exists anywhere in src/, flag as a gap."""
    excluded_symbols = [
        c.must_not_call
        for c in report.constraints
        if c.entry_type == "mechanism" and c.must_not_call
    ]
    if not excluded_symbols:
        return

    # Determine source root: try common conventions
    src_candidates = [WORKSPACE_ROOT / "src", WORKSPACE_ROOT / "lib", WORKSPACE_ROOT]
    src_root = next((p for p in src_candidates if p.is_dir()), WORKSPACE_ROOT)

    for symbol in excluded_symbols:
        for source_file in src_root.rglob("*.py"):
            # Skip test files — the spy import of the excluded symbol in a T-M test is expected
            if "test_" in source_file.name or source_file.parts[-2] in ("tests", "test"):
                continue
            try:
                content = source_file.read_text(encoding="utf-8", errors="ignore")
            except OSError:
                continue
            if symbol in content:
                report.gaps.append(
                    CoverageGap(
                        spec_id=report.spec_id,
                        gap_type="STATIC_GREP",
                        item_id=symbol,
                        test_file=str(source_file.relative_to(WORKSPACE_ROOT)),
                        message=(
                            f"must_not_call symbol '{symbol}' found in "
                            f"{source_file.relative_to(WORKSPACE_ROOT)}. "
                            f"This symbol must not appear in any non-test source file "
                            f"(import-but-not-call class of bug — HAR-ADR-0022)."
                        ),
                    )
                )


# ---------------------------------------------------------------------------
# Multi-spec entry points
# ---------------------------------------------------------------------------


def collect_spec_files(phase: int | None, all_phases: bool) -> list[Path]:
    """Return sorted list of spec Path objects matching the requested scope."""
    if all_phases:
        return sorted(SPECS_DIR.rglob("SPEC-*.md"))
    if phase is not None:
        phase_dir = SPECS_DIR / f"phase-{phase}"
        if not phase_dir.exists():
            print(
                f"ERROR  No specs directory found for phase {phase}: {phase_dir}", file=sys.stderr
            )
            sys.exit(2)
        return sorted(phase_dir.glob("SPEC-*.md"))
    return []


# ---------------------------------------------------------------------------
# Output helpers
# ---------------------------------------------------------------------------


def _print_text_report(reports: list[SpecCoverageReport]) -> None:
    total_specs = len(reports)
    passed_count = sum(1 for report in reports if report.passed)
    failed_count = total_specs - passed_count

    for report in reports:
        status_label = "PASS" if report.passed else "FAIL"
        ac_count = len(report.ac_ids)
        test_id_count = len(report.test_ids)
        tm_count = len(report.tm_ids)
        tc_count = len(report.tc_ids)
        constraint_count = len(report.constraints)
        gap_count = len(report.gaps)
        print(
            f"{status_label}  {report.spec_id}  "
            f"({ac_count} AC(s), {test_id_count} T-ID(s), {tm_count} T-M, {tc_count} T-C, "
            f"{constraint_count} constraint(s), {gap_count} gap(s))  "
            f"{report.spec_file}"
        )
        for gap in report.gaps:
            print(f"       GAP [{gap.gap_type}] {gap.item_id}: {gap.message}")

    print()
    print(f"Specs checked: {total_specs}  Passed: {passed_count}  Failed: {failed_count}")


def _print_json_report(reports: list[SpecCoverageReport]) -> None:
    output = {
        "summary": {
            "total": len(reports),
            "passed": sum(1 for r in reports if r.passed),
            "failed": sum(1 for r in reports if not r.passed),
        },
        "specs": [
            {
                "spec_id": report.spec_id,
                "spec_file": report.spec_file,
                "passed": report.passed,
                "ac_ids": report.ac_ids,
                "test_ids": report.test_ids,
                "declared_test_files": report.declared_test_files,
                "gaps": [
                    {
                        "gap_type": gap.gap_type,
                        "item_id": gap.item_id,
                        "test_file": gap.test_file,
                        "message": gap.message,
                    }
                    for gap in report.gaps
                ],
                "constraints": [
                    {
                        "entry_type": c.entry_type,
                        "must_call": c.must_call,
                        "must_not_call": c.must_not_call,
                        "ordering": c.ordering,
                        "config_key": c.config_key,
                        "config_value": c.config_value,
                    }
                    for c in report.constraints
                ],
            }
            for report in reports
        ],
    }
    print(json.dumps(output, indent=2))


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Mechanical spec-to-test AC coverage checker for {project_name}."
    )
    scope_group = parser.add_mutually_exclusive_group(required=True)
    scope_group.add_argument(
        "--spec",
        metavar="PATH",
        help="Path to a single spec file (relative or absolute).",
    )
    scope_group.add_argument(
        "--phase",
        type=int,
        metavar="N",
        help="Check all specs in specs/phase-N/.",
    )
    scope_group.add_argument(
        "--all",
        action="store_true",
        help="Check all specs across all phases.",
    )
    parser.add_argument(
        "--json",
        action="store_true",
        help="Emit JSON report to stdout instead of human-readable text.",
    )
    args = parser.parse_args()

    reports: list[SpecCoverageReport] = []

    if args.spec:
        spec_path = Path(args.spec)
        if not spec_path.is_absolute():
            spec_path = WORKSPACE_ROOT / spec_path
        if not spec_path.exists():
            print(f"ERROR  Spec file not found: {spec_path}", file=sys.stderr)
            sys.exit(2)
        reports.append(check_spec_coverage(spec_path))

    elif args.phase is not None:
        spec_files = collect_spec_files(phase=args.phase, all_phases=False)
        if not spec_files:
            print(f"WARN   No spec files found in specs/phase-{args.phase}/")
            sys.exit(0)
        for spec_file in spec_files:
            reports.append(check_spec_coverage(spec_file))

    else:  # --all
        spec_files = collect_spec_files(phase=None, all_phases=True)
        for spec_file in spec_files:
            reports.append(check_spec_coverage(spec_file))

    if args.json:
        _print_json_report(reports)
    else:
        _print_text_report(reports)

    any_failed = any(not report.passed for report in reports)
    sys.exit(1 if any_failed else 0)


if __name__ == "__main__":
    main()
