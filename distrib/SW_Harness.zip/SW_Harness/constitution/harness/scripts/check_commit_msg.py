﻿"""
check_commit_msg — Validates commit message format per HAR-C-0002 §4.

Implements: HAR-C-0002 §4
Reads:  .git/COMMIT_EDITMSG (commit message file)
Writes: stdout (error messages)

Format: <type>(<scope>): <description> [Phase N]
Types:  feat | fix | test | refactor | docs | chore | perf
"""

from __future__ import annotations

import re
import sys
from pathlib import Path

# HAR-C-0002 §4: commit message pattern
COMMIT_PATTERN = re.compile(
    r"^(feat|fix|test|refactor|docs|chore|perf)"  # type
    r"\([a-z][a-z0-9_-]*\)"  # (scope)
    r": "  # separator
    r".{3,72}"  # description (3-72 chars)
    r" \[Phase [1-6]\]$"  # [Phase N]
)

# Allow merge commits and version tags
SKIP_PATTERNS = [
    re.compile(r"^Merge "),
    re.compile(r"^Revert "),
    re.compile(r"^v\d+\.\d+\.\d+"),
]


def validate_commit_message(msg: str) -> str | None:
    """Return error message if invalid, None if valid."""
    first_line = msg.strip().split("\n")[0]

    for skip in SKIP_PATTERNS:
        if skip.match(first_line):
            return None

    if not COMMIT_PATTERN.match(first_line):
        return (
            f"❌ Commit message does not match HAR-C-0002 §4 format.\n"
            f"   Got:      {first_line!r}\n"
            f"   Expected: <type>(<scope>): <description> [Phase N]\n"
            f"   Types:    feat | fix | test | refactor | docs | chore | perf\n"
            f"   Example:  feat(kafka): implement WorkerBase consumer loop [Phase 1]"
        )

    return None


def main() -> int:
    """Entry point for pre-commit hook."""
    commit_msg_file = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(".git/COMMIT_EDITMSG")

    if not commit_msg_file.exists():
        return 0

    msg = commit_msg_file.read_text(encoding="utf-8")
    error = validate_commit_message(msg)

    if error:
        return 1

    return 0


if __name__ == "__main__":
    sys.exit(main())
