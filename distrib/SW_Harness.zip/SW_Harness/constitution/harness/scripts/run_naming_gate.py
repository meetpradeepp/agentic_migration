﻿"""run_naming_gate — CLI entrypoint for the ECLE001 deterministic naming gate.

Implements: SPEC-0011
Reads:  Python source files under target paths
Writes: JSON report to --report path (parent dirs auto-created)

Exit codes:
  0 — no ECLE001 findings
  1 — one or more ECLE001 findings exist
  2 — error (unreadable file, syntax error in checked file, bad arguments, internal error)

Usage:
  uv run python scripts/run_naming_gate.py --mode ci --report <path> [--paths <f1> <f2> ...]
  uv run python scripts/run_naming_gate.py --mode local --report <path> [--paths <f1> <f2> ...]

When --paths is omitted, the script discovers all Python files under the repository root,
excluding virtualenv, build, dist, and cache directories.
"""

from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path
from typing import Literal

# Allow running from repo root without installing the package.
# TODO: replace with load_config() from harness_config to get the repo root.
# _REPO_ROOT = cfg.repo_root
_REPO_ROOT = Path(__file__).resolve().parents[3]  # fallback until harness_config wired
if str(_REPO_ROOT / "src") not in sys.path:
    sys.path.insert(0, str(_REPO_ROOT / "src"))

# Import your project's naming checker module here.
# Sample (adapt to your project's naming checker location):
#   from {src_dir}.linting.naming_checker import RULE_ID_001_ERROR, NamingChecker, NamingFinding

# ---------------------------------------------------------------------------
# Configuration — loaded from env vars with spec-defined defaults (SPEC-0011)
# ---------------------------------------------------------------------------

_DEFAULT_NON_TRIVIAL_LOGICAL_LINES = int(
    os.environ.get("NAMING_GATE_NON_TRIVIAL_LOGICAL_LINES", "10")
)
_DEFAULT_NON_TRIVIAL_LOCAL_VARIABLES = int(
    os.environ.get("NAMING_GATE_NON_TRIVIAL_LOCAL_VARIABLES", "3")
)
_DEFAULT_AMBIGUOUS_DENYLIST = tuple(
    os.environ.get(
        "NAMING_GATE_AMBIGUOUS_DENYLIST",
        "tmp,val,obj,res,ret,data,item,thing,x1,y1",
    ).split(",")
)
_DEFAULT_ALLOWLIST = tuple(os.environ.get("NAMING_GATE_ALLOWLIST", "i,j,k,x,y,z,n,m,_").split(","))

_EXCLUDE_DIR_NAMES: frozenset[str] = frozenset(
    {
        ".venv",
        "venv",
        "__pycache__",
        ".git",
        "build",
        "dist",
        ".mypy_cache",
        ".ruff_cache",
        ".pytest_cache",
        "node_modules",
        ".tox",
        "*.egg-info",
    }
)

_VALID_MODES: frozenset[str] = frozenset({"ci", "local"})


# ---------------------------------------------------------------------------
# Argument parsing
# ---------------------------------------------------------------------------


def parse_args(argv: list[str]) -> argparse.Namespace:
    """Parse CLI arguments and validate mode. Exits 2 on invalid input."""
    parser = argparse.ArgumentParser(
        prog="run_naming_gate",
        description="ECLE001 deterministic naming gate for Python source files.",
    )
    parser.add_argument(
        "--mode",
        required=True,
        help="Execution context: 'ci' (Stage 1 CI) or 'local' (pre-commit / developer).",
    )
    parser.add_argument(
        "--report",
        required=True,
        help="Output path for the JSON findings report. Parent directories are created if missing.",
    )
    parser.add_argument(
        "--paths",
        nargs="*",
        default=None,
        help="Explicit list of Python file paths to check. Defaults to auto-discovery.",
    )
    parsed = parser.parse_args(argv)

    if parsed.mode not in _VALID_MODES:
        parser.print_usage(sys.stderr)
        sys.exit(2)

    return parsed


# ---------------------------------------------------------------------------
# File discovery
# ---------------------------------------------------------------------------


def _discover_python_files(root: Path) -> list[str]:
    """Walk *root* and return all .py files, skipping excluded directories."""
    discovered: list[str] = []
    for dirpath, dirnames, filenames in os.walk(root):
        # Prune excluded directories in-place (os.walk respects this)
        dirnames[:] = [
            directory
            for directory in dirnames
            if directory not in _EXCLUDE_DIR_NAMES and not directory.endswith(".egg-info")
        ]
        for filename in filenames:
            if filename.endswith(".py"):
                discovered.append(str(Path(dirpath) / filename))
    return sorted(discovered)


# ---------------------------------------------------------------------------
# Report writer
# ---------------------------------------------------------------------------


def write_report(*, report_path: str, findings: list[NamingFinding]) -> None:
    """Serialise *findings* to JSON at *report_path*; creates parent dirs if needed."""
    output_path = Path(report_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)

    payload = [
        {
            "path": finding.path,
            "line": finding.line,
            "column": finding.column,
            "symbol": finding.symbol,
            "reason": finding.reason,
            "rule_id": finding.rule_id,
            "scope_kind": finding.scope_kind,
            "scope_metrics": {
                "logical_lines": finding.scope_metrics.logical_lines,
                "local_variable_count": finding.scope_metrics.local_variable_count,
                "has_control_flow": finding.scope_metrics.has_control_flow,
                "has_boundary_call": finding.scope_metrics.has_boundary_call,
            },
        }
        for finding in sorted(findings, key=lambda f: (f.path, f.line, f.column, f.symbol))
    ]
    output_path.write_text(json.dumps(payload, indent=2, sort_keys=False), encoding="utf-8")


# ---------------------------------------------------------------------------
# Core runner
# ---------------------------------------------------------------------------


def run_checker(
    *,
    mode: Literal["ci", "local"],
    target_paths: list[str],
    report_path: str,
) -> int:
    """Run NamingChecker over *target_paths*, write report, and return exit code."""
    checker = NamingChecker(
        non_trivial_logical_lines=_DEFAULT_NON_TRIVIAL_LOGICAL_LINES,
        non_trivial_local_variables=_DEFAULT_NON_TRIVIAL_LOCAL_VARIABLES,
        ambiguous_denylist=_DEFAULT_AMBIGUOUS_DENYLIST,
        allowlist=_DEFAULT_ALLOWLIST,
    )

    findings = checker.check_paths(target_paths)

    error_findings = [f for f in findings if f.rule_id == RULE_ID_ECLE001_ERROR]
    has_unreadable = any(f.symbol == "<unreadable>" for f in error_findings)

    try:
        write_report(report_path=report_path, findings=findings)
    except OSError:
        # Retry once (spec Error row 3) — parent mkdir is done inside write_report,
        # so a second call should succeed; if not, propagate.
        try:
            write_report(report_path=report_path, findings=findings)
        except OSError:
            return 2

    if has_unreadable:
        return 2

    # ECLE001-PARSE (syntax error) and ECLE001-ERROR (internal exception) → exit 2
    error_rule_ids = frozenset({RULE_ID_ECLE001_ERROR, "ECLE001-PARSE"})
    has_parse_or_internal_error = any(f.rule_id in error_rule_ids for f in findings)
    if has_parse_or_internal_error:
        return 2

    # ECLE001 naming violations → exit 1
    violation_findings = [f for f in findings if f.rule_id not in error_rule_ids]
    if violation_findings:
        return 1
    return 0


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------


def main(argv: list[str] | None = None) -> int:
    """Parse arguments, run checker, return exit code."""
    if argv is None:
        argv = sys.argv[1:]

    parsed = parse_args(argv)

    target_paths = parsed.paths or _discover_python_files(_REPO_ROOT)

    return run_checker(
        mode=parsed.mode,
        target_paths=target_paths,
        report_path=parsed.report,
    )


if __name__ == "__main__":
    sys.exit(main())
