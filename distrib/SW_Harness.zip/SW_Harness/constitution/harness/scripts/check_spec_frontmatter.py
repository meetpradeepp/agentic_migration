﻿"""
Spec frontmatter governance script for {project_name}.

Verifies that all spec files have a valid `relevant_contracts:` YAML frontmatter
key, and that each listed contract number corresponds to an existing contract file.

Implements: HAR-ADR-0009 — Token-Efficient Validation (governance check D4.1).

Usage:
    python scripts/check_spec_frontmatter.py                    # check all phases
    python scripts/check_spec_frontmatter.py --phase 2          # specific phase only
    python scripts/check_spec_frontmatter.py --spec <file>      # single spec file
    python scripts/check_spec_frontmatter.py --ears-lint        # warn on ACs lacking EARS keyword
    python scripts/check_spec_frontmatter.py --ears-lint --spec <file>   # single spec EARS check

Exit codes:
    0  All spec files have valid relevant_contracts: frontmatter (and EARS lint if requested).
    1  One or more specs are missing or have invalid frontmatter.
    2  Script error (bad args, file not found, parse failure).

EARS lint (--ears-lint) issues WARN (not ERROR) and does not change the exit code.
"""

from __future__ import annotations

import argparse
import re
import sys
from pathlib import Path

# WORKSPACE_ROOT removed — use load_config() from harness_config instead
# SPECS_DIR — resolved via HarnessConfig.specs_dir
# Two-plane taxonomy dirs (HAR-ADR-0001): contracts split into system/ and harness/ planes
SYS_CONTRACTS_DIR = WORKSPACE_ROOT / "constitution" / "system" / "contracts"
HAR_CONTRACTS_DIR = WORKSPACE_ROOT / "constitution" / "harness" / "contracts"
# Legacy path kept as fallback only (now empty after HAR-ADR-0001 restructure)
CONTRACTS_DIR = WORKSPACE_ROOT / "constitution" / "contracts"

# Pattern to match YAML frontmatter block at the start of a file
_FRONTMATTER_BLOCK = re.compile(r"^---\s*\n(.*?)\n---", re.DOTALL)
# Pattern to extract the relevant_contracts value (list or inline)
_RC_KEY = re.compile(r"relevant_contracts\s*:\s*(\[.*?\]|\S.*?)$", re.MULTILINE)
# Extracts individual contract numbers from the value (legacy two-digit format)
_CONTRACT_NUM = re.compile(r'"?(\d+)"?')
# Extracts two-plane contract IDs (HAR-ADR-0001 format: HAR-C-NNNN / SYS-C-NNNN)
_CONTRACT_ID_NEW = re.compile(r"((?:HAR|SYS)-C-\d{4})")


def _build_contract_number_map() -> set[str]:
    """Return set of valid contract identifiers for frontmatter validation.

    Post-HAR-ADR-0001: contracts moved to two-plane taxonomy (SYS-C-NNNN / HAR-C-NNNN).
    Accepts both legacy two-digit format ("01"..."21") and new two-plane IDs
    ("HAR-C-0001"..."SYS-C-0013") so that both old and new-format specs validate correctly.
    """
    sys_contracts = list(SYS_CONTRACTS_DIR.glob("SYS-C-*.md")) if SYS_CONTRACTS_DIR.exists() else []
    har_contracts = list(HAR_CONTRACTS_DIR.glob("HAR-C-*.md")) if HAR_CONTRACTS_DIR.exists() else []
    valid: set[str] = set()
    if sys_contracts or har_contracts:
        # Legacy two-digit numbers always valid (old specs)
        valid.update({f"{n:02d}" for n in range(1, 22)})
        # New-format IDs also valid (HAR-ADR-0001 two-plane taxonomy)
        for contract_file in sys_contracts:
            match = re.match(r"(SYS-C-\d{4})-", contract_file.name)
            if match:
                valid.add(match.group(1))
        for contract_file in har_contracts:
            match = re.match(r"(HAR-C-\d{4})-", contract_file.name)
            if match:
                valid.add(match.group(1))
        return valid
    # Legacy fallback: scan old contracts/ directory (now empty after HAR-ADR-0001)
    contract_nums: set[str] = set()
    for contract_file in CONTRACTS_DIR.glob("*.md"):
        match = re.match(r"^(\d+)-", contract_file.name)
        if match:
            contract_nums.add(match.group(1).zfill(2))
    return contract_nums


def _parse_relevant_contracts(spec_path: Path) -> list[str] | None:
    """
    Return the list of contract numbers from the spec's YAML frontmatter.
    Returns None if the frontmatter block is absent or `relevant_contracts:` is missing.
    Returns an empty list if the key is present but empty.
    """
    try:
        content = spec_path.read_text(encoding="utf-8")
    except OSError as exc:
        print(f"ERROR: cannot read {spec_path}: {exc}", file=sys.stderr)
        sys.exit(2)

    block_match = _FRONTMATTER_BLOCK.match(content)
    if not block_match:
        return None  # no frontmatter at all

    frontmatter_text = block_match.group(1)
    rc_match = _RC_KEY.search(frontmatter_text)
    if not rc_match:
        return None  # frontmatter present but no relevant_contracts key

    raw_value = rc_match.group(1).strip()
    # Detect new-format IDs (HAR-C-NNNN / SYS-C-NNNN) before falling back to legacy digits.
    # New format is used by specs written after the HAR-ADR-0001 taxonomy restructure.
    new_ids = _CONTRACT_ID_NEW.findall(raw_value)
    if new_ids:
        return new_ids
    # Legacy two-digit format fallback
    contract_nums = _CONTRACT_NUM.findall(raw_value)
    return [num.zfill(2) for num in contract_nums]


def _collect_spec_files(target: str | None, phase: int | None) -> list[Path]:
    """Return spec files matching the requested scope."""
    if target is not None:
        spec_path = Path(target)
        if not spec_path.is_absolute():
            spec_path = WORKSPACE_ROOT / spec_path
        if not spec_path.exists():
            print(f"ERROR: spec file not found: {spec_path}", file=sys.stderr)
            sys.exit(2)
        return [spec_path]

    if phase is not None:
        phase_dir = SPECS_DIR / f"phase-{phase}"
        if not phase_dir.exists():
            print(f"ERROR: phase directory not found: {phase_dir}", file=sys.stderr)
            sys.exit(2)
        return sorted(phase_dir.glob("SPEC-*.md"))

    # All phases
    all_specs: list[Path] = []
    for phase_dir in sorted(SPECS_DIR.iterdir()):
        if phase_dir.is_dir() and phase_dir.name.startswith("phase-"):
            all_specs.extend(sorted(phase_dir.glob("SPEC-*.md")))
    return all_specs


# EARS keywords — WHEN, WHILE, IF/THEN, WHERE, or no keyword (ubiquitous).
# ACs in event-driven or state-sensitive specs are expected to use one of these forms.
_EARS_KEYWORDS = re.compile(r"\b(WHEN|WHILE|IF|THEN|WHERE)\b", re.IGNORECASE)

# Pattern to detect AC table rows: lines starting with | AC-<digits> | or | ID |
_AC_ROW = re.compile(r"^\|\s*(AC-\d+|ID)\s*\|(.+)", re.MULTILINE)

# Section header patterns that suggest event-driven or state-sensitive specs
_EVENT_DRIVEN_SIGNALS = re.compile(
    r"kafka|event|emit|consume|subscribe|state machine|state transition",
    re.IGNORECASE,
)


def ears_lint(spec_files: list[Path]) -> list[str]:
    """Warn (not error) when AC rows in event-driven specs lack EARS keywords.

    Returns a list of WARN messages. Does not affect exit code.
    EARS adoption is gradual — existing specs are not retroactively required to conform.
    """
    warnings: list[str] = []

    for spec_path in spec_files:
        try:
            content = spec_path.read_text(encoding="utf-8")
        except OSError as exc:
            warnings.append(f"WARN  {spec_path}: cannot read file — {exc}")
            continue

        # Only lint specs that appear to be event-driven or state-sensitive
        if not _EVENT_DRIVEN_SIGNALS.search(content):
            continue

        rel = spec_path.relative_to(WORKSPACE_ROOT) if WORKSPACE_ROOT in spec_path.parents else spec_path

        # Find AC table rows (skip the header row where the second column is 'Given')
        ac_rows = _AC_ROW.findall(content)
        for row_id, row_rest in ac_rows:
            if row_id.strip().upper() == "ID":
                continue  # header row
            if not _EARS_KEYWORDS.search(row_rest):
                warnings.append(
                    f"WARN  {rel} — {row_id.strip()} has no EARS keyword "
                    f"(WHEN / WHILE / IF / WHERE); consider structuring the Expected cell "
                    f"with an EARS template (--ears-lint, IDEA-H-007)"
                )

    return warnings


def check_frontmatter(spec_files: list[Path], known_contracts: set[str]) -> list[str]:
    """
    Validate each spec file and return a list of error messages.
    Empty list means all specs pass.
    """
    errors: list[str] = []

    for spec_path in spec_files:
        rel = spec_path.relative_to(WORKSPACE_ROOT)
        contracts = _parse_relevant_contracts(spec_path)

        if contracts is None:
            errors.append(
                f"MISSING  {rel} — no `relevant_contracts:` YAML frontmatter "
                f"(HAR-ADR-0009: add '---\\nrelevant_contracts: [01, 02, ...]\\n---' before the title)"
            )
            continue

        if not contracts:
            errors.append(
                f"EMPTY    {rel} — `relevant_contracts:` list is empty; "
                f"must contain at least Contracts 01 and 02"
            )
            continue

        # Validate each referenced contract number exists
        for contract_num in contracts:
            if contract_num not in known_contracts:
                errors.append(
                    f"INVALID  {rel} — `relevant_contracts:` references Contract {contract_num} "
                    f"which has no matching file in constitution/contracts/"
                )

    return errors


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Check spec files for relevant_contracts: YAML frontmatter (HAR-ADR-0009)."
    )
    target_group = parser.add_mutually_exclusive_group()
    target_group.add_argument("--spec", metavar="FILE", help="Path to a single spec file to check")
    target_group.add_argument(
        "--phase", type=int, metavar="N", help="Check all specs in the given phase folder"
    )
    parser.add_argument(
        "--ears-lint",
        action="store_true",
        default=False,
        help=(
            "Warn (not error) when AC rows in event-driven specs lack EARS structured keywords. "
            "EARS adoption is gradual — does not change exit code. (IDEA-H-007)"
        ),
    )
    args = parser.parse_args()

    try:
        known_contracts = _build_contract_number_map()
        spec_files = _collect_spec_files(args.spec, args.phase)
    except Exception as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        sys.exit(2)

    if not spec_files:
        print("No spec files found for the given scope.")
        sys.exit(0)

    errors = check_frontmatter(spec_files, known_contracts)

    # EARS lint — warnings only, does not affect exit code
    if args.ears_lint:
        ears_warnings = ears_lint(spec_files)
        if ears_warnings:
            print(f"ears-lint: {len(ears_warnings)} advisory warning(s):\n")
            for warn_message in ears_warnings:
                print(f"  {warn_message}")
            print()

    if errors:
        print(
            f"check_spec_frontmatter: {len(errors)} issue(s) found in {len(spec_files)} spec(s).\n"
        )
        for error_message in errors:
            print(f"  {error_message}")
        sys.exit(1)
    else:
        print(
            f"check_spec_frontmatter: OK — {len(spec_files)} spec(s) have valid "
            f"relevant_contracts: frontmatter."
        )
        sys.exit(0)


if __name__ == "__main__":
    main()
