"""
harness_config.py — Configuration loader for SW_Harness scripts.

Reads harness.config.yaml from the repository root and exposes a
HarnessConfig dataclass. All harness scripts import this module
instead of hardcoding path constants.

USAGE
-----
    from harness_config import load_config

    cfg = load_config()               # auto-discovers repo root
    cfg = load_config("/path/to/harness.config.yaml")  # explicit path

PATH RESOLUTION
---------------
When no explicit path is given, the loader walks up from this script's
location until it finds harness.config.yaml or reaches the filesystem
root. This makes it robust to the script being called from any working
directory.

OVERRIDE
--------
All scripts accept a --config <path> CLI flag. They pass the resolved
path to load_config() so the harness can be run against any project
configuration without changing working directories.
"""

from __future__ import annotations

import argparse
import sys
from dataclasses import dataclass, field
from pathlib import Path

try:
    import yaml
except ImportError:  # pragma: no cover
    print("ERROR  PyYAML is not installed. Run: pip install pyyaml", file=sys.stderr)
    sys.exit(2)


# ---------------------------------------------------------------------------
# Data type
# ---------------------------------------------------------------------------


@dataclass
class HarnessConfig:
    """All paths resolved to absolute Path objects."""

    repo_root: Path
    project_name: str
    src_dir: Path
    specs_dir: Path
    tests_dir: Path
    state_file_path: Path
    pipeline_workspace_dir: Path
    plans_dir: Path
    number_registry_db: Path
    constitution_dir: Path

    # Derived convenience paths (not in config file — computed)
    memory_dir: Path = field(init=False)
    agents_dir: Path = field(init=False)
    hooks_file: Path = field(init=False)

    def __post_init__(self) -> None:
        self.memory_dir = self.repo_root / ".github" / "memory"
        self.agents_dir = self.repo_root / ".github" / "agents"
        self.hooks_file = self.repo_root / ".github" / "hooks" / "hooks.yaml"


# ---------------------------------------------------------------------------
# Loader
# ---------------------------------------------------------------------------


def _find_config(start: Path) -> Path:
    """Walk up the directory tree to find harness.config.yaml."""
    current = start.resolve()
    for _ in range(20):  # guard against infinite loop at filesystem root
        candidate = current / "harness.config.yaml"
        if candidate.exists():
            return candidate
        parent = current.parent
        if parent == current:
            break
        current = parent
    raise FileNotFoundError(
        "harness.config.yaml not found. "
        "Ensure you are running from within a project that uses SW_Harness, "
        "or pass --config <path> to point to the config file explicitly."
    )


def load_config(config_path: str | Path | None = None) -> HarnessConfig:
    """
    Load and validate harness.config.yaml.

    Parameters
    ----------
    config_path:
        Explicit path to harness.config.yaml. When None, the loader
        searches upward from the calling script's directory.

    Returns
    -------
    HarnessConfig with all paths resolved to absolute Path objects.
    """
    if config_path is None:
        config_file = _find_config(Path(__file__).parent)
    else:
        config_file = Path(config_path).resolve()
        if not config_file.exists():
            print(f"ERROR  Config file not found: {config_file}", file=sys.stderr)
            sys.exit(2)

    raw = yaml.safe_load(config_file.read_text(encoding="utf-8"))
    if not isinstance(raw, dict):
        print(f"ERROR  {config_file} is not a valid YAML mapping.", file=sys.stderr)
        sys.exit(2)

    root = config_file.parent

    def _resolve(key: str, default: str | None = None) -> Path:
        value = raw.get(key, default)
        if value is None:
            print(f"ERROR  Missing required key '{key}' in {config_file}", file=sys.stderr)
            sys.exit(2)
        return (root / value).resolve()

    return HarnessConfig(
        repo_root=root,
        project_name=raw.get("project_name", "this project"),
        src_dir=_resolve("src_dir", "src"),
        specs_dir=_resolve("specs_dir", "specs"),
        tests_dir=_resolve("tests_dir", "tests"),
        state_file_path=_resolve("state_file_path", ".github/pipeline/state.json"),
        pipeline_workspace_dir=_resolve("pipeline_workspace_dir", ".github/pipeline/workspace"),
        plans_dir=_resolve("plans_dir", ".github/pipeline/plans"),
        number_registry_db=_resolve("number_registry_db", ".github/pipeline/number-registry.db"),
        constitution_dir=_resolve("constitution_dir", "constitution/harness"),
    )


# ---------------------------------------------------------------------------
# CLI argument helper — every script uses this to accept --config
# ---------------------------------------------------------------------------


def add_config_arg(parser: argparse.ArgumentParser) -> argparse.ArgumentParser:
    """
    Add a --config argument to any script's ArgumentParser.

    Call this before parser.parse_args(), then pass args.config to
    load_config() to get a HarnessConfig.

    Example
    -------
        parser = argparse.ArgumentParser()
        add_config_arg(parser)
        args = parser.parse_args()
        cfg = load_config(args.config)
    """
    parser.add_argument(
        "--config",
        metavar="PATH",
        default=None,
        help="Path to harness.config.yaml (default: auto-discover from repo root)",
    )
    return parser
