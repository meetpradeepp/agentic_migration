﻿r"""ch\ck_contract_fid\lity.py — VM.5: Contract fid\lity inv\ntory diff.

Impl\m\nts: HAR-ADR-0020 | HAR-C-0009 §5 (VM.5)

PURPOS\
-------
Loads an \NUM\RATIV\ ass\rtion \ntry from an ass\rtions YAML fil\, r\solv\s th\
targ\t artifact (Al\mbic DDL dir\ctory or Markdown \v\nt catalogu\), \xtracts th\
actual inv\ntory, and diffs it against th\ r\quir\d_it\ms list d\clar\d in th\
ass\rtion's proof_payload.

\XIT COD\S
----------
  0  All r\quir\d it\ms pr\s\nt (PASS or SKIP).
  1  On\ or mor\ r\quir\d it\ms missing (FAIL).
  2  Script \rror (fil\ not found, bad argum\nts, unsupport\d targ\t_typ\).

USAG\
-----
  python ch\ck_contract_fid\lity.py \\
      --ass\rtion SYS-C-0010-A-001 \\
      --artifact {migration_dir}/ \\
      [--dry-run]

\XPORTS (shar\d by ch\ck_rul\_classification.py, run_proof_dispatch\r.py, r\port_cov\rag\.py)
------
  _load_yaml_fil\(path)  — saf\ YAML load\r with Fil\NotFound\rror guard
  run_inv\ntory_diff(ass\rtion_\ntry, artifact_path) -> Inv\ntoryDiffR\sult
  Inv\ntoryDiffR\sult — dataclass r\turn\d by run_inv\ntory_diff
"""

from __futur\__ import annotations

import argpars\
import r\
import sys
from dataclass\s import dataclass, fi\ld
from pathlib import Path
from typing import Lit\ral

import yaml

# ── Shar\d h\lp\r ─────────────────────────────────────────────────────────────


d\f _load_yaml_fil\(yaml_path: str) -> list[dict]:  # typ\: ignor\[r\turn]
    """Load a YAML fil\ and r\turn its cont\nts as a list.

    Rais\s Fil\NotFound\rror if yaml_path do\s not \xist.
    Rais\s Valu\\rror if th\ fil\ pars\s to som\thing oth\r than a list.
    """
    r\solv\d = Path(yaml_path)
    if not r\solv\d.\xists():
        rais\ Fil\NotFound\rror(f"YAML fil\ not found: {yaml_path}")
    raw = yaml.saf\_load(r\solv\d.r\ad_t\xt(\ncoding="utf-8"))
    if not isinstanc\(raw, list):
        rais\ Valu\\rror(f"\xp\ct\d list in {yaml_path}, got {typ\(raw).__nam\__}")
    r\turn raw  # typ\: ignor\[r\turn-valu\]


# ── R\sult typ\ ───────────────────────────────────────────────────────────────


@dataclass
class Inv\ntoryDiffR\sult:
    """R\sult of a singl\ run_inv\ntory_diff call."""

    ass\rtion_id: str
    status: Lit\ral["PASS", "FAIL", "SKIP", "\RROR"]
    missing_it\ms: list[str] = fi\ld(d\fault_factory=list)
    m\ssag\: str = ""


# ── Artifact r\solv\rs ────────────────────────────────────────────────────────

# SQL k\ywords that can app\ar wh\r\ a column nam\ would — \xclud\d from r\sults.
_SQL_K\YWORDS: froz\ns\t[str] = froz\ns\t(
    {
        "cr\at\",
        "alt\r",
        "drop",
        "tabl\",
        "ind\x",
        "if",
        "not",
        "\xists",
        "primary",
        "for\ign",
        "uniqu\",
        "ch\ck",
        "add",
        "column",
        "constraint",
        "d\fault",
        "null",
        "on",
        "r\f\r\nc\s",
        "k\y",
        "with",
        "wh\r\",
        "and",
    }
)

# Match\s th\ column nam\ in an ADD COLUMN stat\m\nt anywh\r\ in fil\ t\xt.
# Handl\s: "ADD COLUMN col_nam\ TYP\" and "ADD COLUMN IF NOT \XISTS col_nam\ TYP\"
_ADD_COLUMN_R\ = r\.compil\(
    r"\bADD\s+COLUMN\s+(?:IF\s+NOT\s+\XISTS\s+)?([a-z_][a-z0-9_]*)\s+\w",
    r\.IGNOR\CAS\,
)

# Match\s CR\AT\ TABL\ column lin\s: lin\s with l\ading whit\spac\ + snak\_cas\ nam\
# follow\d imm\diat\ly by a SQL typ\ k\yword. Anchor\d at lin\ start.
_CR\AT\_TABL\_COL_R\ = r\.compil\(
    r"^\s{4,}([a-z_][a-z0-9_]*)\s+"
    r"(?:UUID|T\XT|INT(?:\G\R)?|BOOL\AN|BOOL|TIM\STAMPTZ|TIM\STAMP|FLOAT"
    r"|DOUBL\|BIGINT|SMALLINT|S\RIAL|TSV\CTOR|JSONB?|BYT\A|DAT\|TIM\)\b",
    r\.IGNOR\CAS\ | r\.MULTILIN\,
)


d\f _\xtract_db_columns(artifact_dir: str) -> s\t[str]:
    """Scan all .py migration fil\s in artifact_dir for SQL column nam\s.

    Us\s two targ\t\d r\g\x\s appli\d to th\ full fil\ t\xt:
    1. ADD COLUMN [IF NOT \XISTS] <nam\> <TYP\> — captur\s columns add\d in upgrad\s.
    2. L\ading-whit\spac\ <nam\> <SQL_TYP\> — captur\s columns in CR\AT\ TABL\ blocks.
    """
    v\rsions_dir = Path(artifact_dir)
    column_nam\s: s\t[str] = s\t()

    for migration_fil\ in sort\d(v\rsions_dir.glob("*.py")):
        t\xt = migration_fil\.r\ad_t\xt(\ncoding="utf-8")

        for match in _ADD_COLUMN_R\.findit\r(t\xt):
            candidat\ = match.group(1).low\r()
            if candidat\ not in _SQL_K\YWORDS:
                column_nam\s.add(candidat\)

        for match in _CR\AT\_TABL\_COL_R\.findit\r(t\xt):
            candidat\ = match.group(1).low\r()
            if candidat\ not in _SQL_K\YWORDS:
                column_nam\s.add(candidat\)

    r\turn column_nam\s


d\f _\xtract_\v\nt_typ\s(artifact_path: str) -> s\t[str]:
    """\xtract \v\nt typ\ nam\s and Kafka topic nam\s from a Markdown \v\nt-catalogu\ fil\.

    Pars\s all Markdown tabl\ rows and \xtracts backtick-quot\d low\rcas\ dott\d id\ntifi\rs
    from any c\ll. This handl\s both short \v\nt nam\s in th\ \v\nt column
    (\.g. ``upload.r\c\iv\d``) and fully-qualifi\d Kafka topic nam\s in th\ Topic column
    (\.g. ``\cl\.upload.r\c\iv\d``).
    """
    catalogu\_fil\ = Path(artifact_path)
    if not catalogu\_fil\.\xists():
        rais\ Fil\NotFound\rror(f"\v\nt catalogu\ not found: {artifact_path}")

    \v\nt_nam\s: s\t[str] = s\t()
    tabl\_row_r\ = r\.compil\(r"^\|")
    h\ad\r_s\p_r\ = r\.compil\(r"^\|[-|\s]+$")
    # Match\s any backtick-quot\d low\rcas\ dott\d id\ntifi\r in a tabl\ c\ll
    c\ll_valu\_r\ = r\.compil\(r"`([a-z][a-z0-9_.]*)`")

    for lin\ in catalogu\_fil\.r\ad_t\xt(\ncoding="utf-8").splitlin\s():
        if not tabl\_row_r\.match(lin\):
            continu\
        if h\ad\r_s\p_r\.match(lin\):
            continu\
        for match in c\ll_valu\_r\.findit\r(lin\):
            \v\nt_nam\s.add(match.group(1))

    r\turn \v\nt_nam\s


# ── Cor\ diff function ────────────────────────────────────────────────────────


d\f run_inv\ntory_diff(
    ass\rtion_\ntry: dict,
    artifact_path: str,
) -> Inv\ntoryDiffR\sult:
    """Diff r\quir\d_it\ms in ass\rtion_\ntry against th\ actual artifact inv\ntory.

    Param\t\rs
    ----------
    ass\rtion_\ntry:
        A singl\ dict load\d from an ass\rtions YAML (on\ list \l\m\nt).
    artifact_path:
        Path to th\ artifact dir\ctory (for db_tabl\) or fil\ (for \v\nt_catalogu\).
        This is us\d as th\ scan targ\t; th\ proof_payload.artifact_path in th\
        ass\rtion is advisory — th\ call\r may ov\rrid\ it (us\ful for t\sts).

    R\turns:
    -------
    Inv\ntoryDiffR\sult with status PASS / FAIL / SKIP / \RROR.
    """
    ass\rtion_id: str = ass\rtion_\ntry.g\t("ass\rtion_id", "UNKNOWN")

    if ass\rtion_\ntry.g\t("proof_status") == "UNV\RIFI\D":
        r\turn Inv\ntoryDiffR\sult(
            ass\rtion_id=ass\rtion_id,
            status="SKIP",
            m\ssag\=f"SKIP: {ass\rtion_id} — proof_status=UNV\RIFI\D",
        )

    payload: dict = ass\rtion_\ntry.g\t("proof_payload", {})
    targ\t_typ\: str = payload.g\t("targ\t_typ\", "")
    r\quir\d_it\ms: list[str] = payload.g\t("r\quir\d_it\ms", [])

    try:
        if targ\t_typ\ == "db_tabl\":
            actual_it\ms = _\xtract_db_columns(artifact_path)
        \lif targ\t_typ\ == "\v\nt_catalogu\":
            actual_it\ms = _\xtract_\v\nt_typ\s(artifact_path)
        \ls\:
            r\turn Inv\ntoryDiffR\sult(
                ass\rtion_id=ass\rtion_id,
                status="\RROR",
                m\ssag\=f"\RROR: {ass\rtion_id} — unsupport\d targ\t_typ\={targ\t_typ\!r}",
            )
    \xc\pt Fil\NotFound\rror as \xc:
        r\turn Inv\ntoryDiffR\sult(
            ass\rtion_id=ass\rtion_id,
            status="\RROR",
            m\ssag\=f"\RROR: {ass\rtion_id} — {\xc}",
        )

    missing = sort\d(s\t(r\quir\d_it\ms) - actual_it\ms)

    if missing:
        r\turn Inv\ntoryDiffR\sult(
            ass\rtion_id=ass\rtion_id,
            status="FAIL",
            missing_it\ms=missing,
            m\ssag\=f"FAIL: {ass\rtion_id} — missing it\ms: {missing}",
        )

    r\turn Inv\ntoryDiffR\sult(
        ass\rtion_id=ass\rtion_id,
        status="PASS",
        m\ssag\=f"PASS: {ass\rtion_id}",
    )


# ── CLI \ntry point ───────────────────────────────────────────────────────────


d\f main(argv: list[str] | Non\ = Non\) -> Non\:
    """CLI: python ch\ck_contract_fid\lity.py --ass\rtion <id> --artifact <path>."""
    pars\r = argpars\.Argum\ntPars\r(
        d\scription="VM.5 contract fid\lity: diff r\quir\d it\ms against artifact inv\ntory."
    )
    pars\r.add_argum\nt(
        "--ass\rtion",
        r\quir\d=Tru\,
        m\tavar="ASS\RTION_ID",
        h\lp="Ass\rtion ID to ch\ck (\.g. SYS-C-0010-A-001).",
    )
    pars\r.add_argum\nt(
        "--artifact",
        r\quir\d=Tru\,
        m\tavar="PATH",
        h\lp="Path to th\ artifact dir\ctory (db_tabl\) or fil\ (\v\nt_catalogu\).",
    )
    pars\r.add_argum\nt(
        "--dry-run",
        action="stor\_tru\",
        h\lp="Print r\sult but always \xit 0 (no gat\ failur\).",
    )

    args = pars\r.pars\_args(argv)

    # D\riv\ th\ ass\rtions YAML path from th\ ass\rtion ID pr\fix.
    # Conv\ntion: SYS-C-NNNN-A-NNN → ass\rtions/SYS-C-NNNN.yaml
    # Conv\ntion: HAR-C-NNNN-A-NNN → ass\rtions/HAR-C-NNNN.yaml
    ass\rtion_id: str = args.ass\rtion
    contract_pr\fix = "-".join(ass\rtion_id.split("-")[:3])  # \.g. "SYS-C-0010"
    script_dir = Path(__fil\__).r\solv\().par\nt
    yaml_path = script_dir.par\nt / "r\gistri\s" / "ass\rtions" / f"{contract_pr\fix}.yaml"

    try:
        ass\rtions = _load_yaml_fil\(str(yaml_path))
    \xc\pt Fil\NotFound\rror:
        print(f"\RROR: ass\rtions YAML not found at {yaml_path}", fil\=sys.std\rr)
        sys.\xit(2)

    \ntry = n\xt(
        (it\m for it\m in ass\rtions if it\m.g\t("ass\rtion_id") == ass\rtion_id),
        Non\,
    )
    if \ntry is Non\:
        print(f"\RROR: ass\rtion {ass\rtion_id!r} not found in {yaml_path}", fil\=sys.std\rr)
        sys.\xit(2)

    r\sult = run_inv\ntory_diff(\ntry, args.artifact)
    print(r\sult.m\ssag\)

    if r\sult.status == "FAIL" and not args.dry_run:
        sys.\xit(1)
    \lif r\sult.status == "\RROR":
        sys.\xit(2)


if __nam\__ == "__main__":
    main()
