﻿r"""check_rule_classification.py — CI gate: assertions schema validator.

Implements: HAR-ADR-0020 | HAR-C-0009 §7

PURPOSE
-------
Validates all assertion YAML files under constitution/harness/registries/assertions/
against the four classification rules defined in HAR-C-0009 §7:

  R1  proof_status must be one of: VERIFIED | PARTIALLY_VERIFIED | HUMAN_REVIEW | UNVERIFIED
  R2  proof_strategy_id (when non-null) must reference a known entry in proof-strategies.yaml
  R3  PARTIALLY_VERIFIED entries must have a non-empty proof_gap
  R4  UNVERIFIED entries must have proof_strategy_id = null (or absent)

EXIT CODES
----------
  0  No violations found.
  1  One or more rule violations found — reported to stdout.
  2  Script error (file not found, bad YAML).

USAGE
-----
  python check_rule_classification.py
  python check_rule_classification.py --assertions-dir path/to/assertions/
  python check_rule_classification.py --strategies-file path/to/proof-strategies.yaml
"""

from __future__ import annotations

import argparse
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Literal

# _load_yaml_file is the shared helper defined in check_contract_fidelity.py (T08).
# Insert the scripts directory so both modules are importable side-by-side.
_SCRIPTS_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(_SCRIPTS_DIR))

from check_contract_fidelity import _load_yaml_file

# ── Constants ─────────────────────────────────────────────────────────────────

VALID_PROOF_STATUSES: frozenset[str] = frozenset(
    {"VERIFIED", "PARTIALLY_VERIFIED", "HUMAN_REVIEW", "UNVERIFIED"}
)


# ── Result type ───────────────────────────────────────────────────────────────


@dataclass
class ClassificationViolation:
    """A single rule violation found in an assertions YAML file."""

    file: str
    assertion_id: str
    rule: Literal["R1", "R2", "R3", "R4"]
    message: str


# ── Core validator ────────────────────────────────────────────────────────────


def validate_assertions_files(
    assertions_dir: str,
    strategies_file: str,
) -> list[ClassificationViolation]:
    """Validate all assertion YAML files against classification rules R1-R4.

    Parameters
    ----------
    assertions_dir:
        Directory containing *.yaml assertion files (e.g. registries/assertions/).
    strategies_file:
        Path to proof-strategies.yaml (defines known proof strategy IDs).

    Returns:
    -------
    List of ClassificationViolation objects. Empty list means all rules pass.
    """
    violations: list[ClassificationViolation] = []

    # Load known strategy IDs from proof-strategies.yaml
    strategies = _load_yaml_file(strategies_file)
    known_strategy_ids: frozenset[str] = frozenset(
        entry["id"] for entry in strategies if "id" in entry
    )

    assertions_path = Path(assertions_dir)
    for yaml_file in sorted(assertions_path.glob("*.yaml")):
        try:
            entries = _load_yaml_file(str(yaml_file))
        except (FileNotFoundError, ValueError):
            continue  # malformed files are skipped; callers see stdout error if needed

        for entry in entries:
            if not isinstance(entry, dict):
                continue
            assertion_id: str = entry.get("assertion_id", "<unknown>")
            proof_status = entry.get("proof_status")
            strategy_id = entry.get("proof_strategy_id")
            proof_gap = entry.get("proof_gap", "")

            # R1: proof_status must be a recognised value
            if proof_status not in VALID_PROOF_STATUSES:
                violations.append(
                    ClassificationViolation(
                        file=yaml_file.name,
                        assertion_id=assertion_id,
                        rule="R1",
                        message=(
                            f"proof_status={proof_status!r} is not one of "
                            f"{sorted(VALID_PROOF_STATUSES)}"
                        ),
                    )
                )

            # R2: strategy_id (when present) must be in proof-strategies.yaml
            if strategy_id is not None and strategy_id not in known_strategy_ids:
                violations.append(
                    ClassificationViolation(
                        file=yaml_file.name,
                        assertion_id=assertion_id,
                        rule="R2",
                        message=(
                            f"proof_strategy_id={strategy_id!r} not found in proof-strategies.yaml"
                        ),
                    )
                )

            # R3: PARTIALLY_VERIFIED entries must document why they are not fully verified
            if proof_status == "PARTIALLY_VERIFIED" and not proof_gap:
                violations.append(
                    ClassificationViolation(
                        file=yaml_file.name,
                        assertion_id=assertion_id,
                        rule="R3",
                        message=(
                            "proof_status=PARTIALLY_VERIFIED but proof_gap is empty; "
                            "must explain what coverage gap remains"
                        ),
                    )
                )

            # R4: UNVERIFIED entries must not name a strategy (no automated proof possible)
            if proof_status == "UNVERIFIED" and strategy_id is not None:
                violations.append(
                    ClassificationViolation(
                        file=yaml_file.name,
                        assertion_id=assertion_id,
                        rule="R4",
                        message=(
                            f"proof_status=UNVERIFIED but proof_strategy_id={strategy_id!r} "
                            f"is set; UNVERIFIED entries must have null proof_strategy_id"
                        ),
                    )
                )

    return violations


# ── CLI entry point ───────────────────────────────────────────────────────────


def main(argv: list[str] | None = None) -> None:
    """CLI: python check_rule_classification.py [--assertions-dir DIR] [--strategies-file FILE]."""
    script_dir = Path(__file__).resolve().parent
    default_assertions_dir = str(script_dir.parent / "registries" / "assertions")
    default_strategies_file = str(script_dir.parent / "registries" / "proof-strategies.yaml")

    parser = argparse.ArgumentParser(
        description="CI gate: validate assertion YAML files against classification rules R1-R4."
    )
    parser.add_argument(
        "--assertions-dir",
        default=default_assertions_dir,
        metavar="DIR",
        help=f"Assertions directory (default: {default_assertions_dir})",
    )
    parser.add_argument(
        "--strategies-file",
        default=default_strategies_file,
        metavar="FILE",
        help=f"proof-strategies.yaml path (default: {default_strategies_file})",
    )

    args = parser.parse_args(argv)

    try:
        violations = validate_assertions_files(
            assertions_dir=args.assertions_dir,
            strategies_file=args.strategies_file,
        )
    except FileNotFoundError as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        sys.exit(2)

    for violation in violations:
        print(f"{violation.file}:{violation.assertion_id}:{violation.rule}: {violation.message}")

    if violations:
        sys.exit(1)


if __name__ == "__main__":
    main()
