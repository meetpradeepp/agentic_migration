﻿"""
Phase gate enforcement script for {project_name}.

Implements: HAR-C-0007 §0 — "No phase-N+1 implementation until phase-N exit criteria pass."

Usage:
    python scripts/check_phase_gate.py --phase 1
    python scripts/check_phase_gate.py --phase 1 --strict   # fails on any Not Started spec

Exit codes:
    0  All exit criteria met (or phase already released — tag exists).
    1  One or more criteria not met (details printed to stdout).
    2  Script error (bad args, file not found, parse failure).
"""

from __future__ import annotations

import argparse
import re
import subprocess
import sys
from pathlib import Path

# WORKSPACE_ROOT removed — use load_config() from harness_config instead
# SPECS_DIR — resolved via HarnessConfig.specs_dir
# PHASE_STATUS_FILE — resolved via HarnessConfig.memory_dir / 'phase-status.md'

# Map phase number → folder name and version tag
PHASE_CONFIG: dict[int, dict[str, str]] = {
    1: {"folder": "phase-1", "version_tag": "v0.1.0"},
    2: {"folder": "phase-2", "version_tag": "v0.2.0"},
    3: {"folder": "phase-3", "version_tag": "v0.3.0"},
    4: {"folder": "phase-4", "version_tag": "v0.4.0"},
    5: {"folder": "phase-5", "version_tag": "v0.5.0"},
    6: {"folder": "phase-6", "version_tag": "v1.0.0"},
}


def check_git_tag_exists(version_tag: str) -> bool:
    """Return True if the annotated/lightweight tag already exists in the repository."""
    try:
        result = subprocess.run(
            ["git", "tag", "--list", version_tag],
            capture_output=True,
            text=True,
            cwd=WORKSPACE_ROOT,
            check=False,
        )
        return result.returncode == 0 and version_tag in result.stdout.strip()
    except FileNotFoundError:
        return False  # git not on PATH


def get_git_tag_commit(version_tag: str) -> str:
    """Return the short commit hash the tag resolves to, or '' on failure."""
    try:
        result = subprocess.run(
            ["git", "rev-list", "-n", "1", "--abbrev-commit", version_tag],
            capture_output=True,
            text=True,
            cwd=WORKSPACE_ROOT,
            check=False,
        )
        return result.stdout.strip() if result.returncode == 0 else ""
    except FileNotFoundError:
        return ""


def read_spec_statuses(phase_number: int) -> dict[str, str]:
    """Return {spec_id: status} for all spec files in the phase folder."""
    phase_config = PHASE_CONFIG.get(phase_number)
    if phase_config is None:
        sys.exit(2)

    phase_dir = SPECS_DIR / phase_config["folder"]
    if not phase_dir.exists():
        return {}

    spec_statuses: dict[str, str] = {}
    status_inline_pattern = re.compile(r"^\*\*Status:\*\*\s+(.+)$", re.MULTILINE)
    status_table_pattern = re.compile(r"^\|\s+\*\*Status\*\*\s+\|\s+(.+?)\s+\|", re.MULTILINE)
    status_frontmatter_pattern = re.compile(r"^status:\s+(.+)$", re.MULTILINE)
    spec_id_pattern = re.compile(r"^# (SPEC-\d+)", re.MULTILINE)

    for spec_file in sorted(phase_dir.glob("SPEC-*.md")):
        spec_text = spec_file.read_text(encoding="utf-8")
        spec_id_match = spec_id_pattern.search(spec_text)
        status_match = (
            status_inline_pattern.search(spec_text)
            or status_table_pattern.search(spec_text)
            or status_frontmatter_pattern.search(spec_text)
        )

        spec_id = spec_id_match.group(1) if spec_id_match else spec_file.stem.upper()
        raw_status = status_match.group(1).strip() if status_match else "Unknown"

        spec_statuses[spec_id] = raw_status

    return spec_statuses


def check_no_later_phase_implemented(phase_number: int) -> list[str]:
    """Return violations: phase-N+1+ specs already Implemented before phase-N exits."""
    violations: list[str] = []
    for later_phase_number in range(phase_number + 1, max(PHASE_CONFIG) + 1):
        phase_config = PHASE_CONFIG.get(later_phase_number)
        if phase_config is None:
            continue
        later_dir = SPECS_DIR / phase_config["folder"]
        if not later_dir.exists():
            continue
        for spec_file in sorted(later_dir.glob("SPEC-*.md")):
            spec_text = spec_file.read_text(encoding="utf-8")
            if re.search(r"^\*\*Status:\*\*\s+Implemented", spec_text, re.MULTILINE):
                violations.append(
                    f"  VIOLATION: {spec_file.relative_to(WORKSPACE_ROOT)} is Implemented "
                    f"but Phase {phase_number} has not exited."
                )
    return violations


def main() -> None:
    parser = argparse.ArgumentParser(description="{project_name} phase gate checker.")
    parser.add_argument("--phase", type=int, required=True, help="Phase number to check (1-6).")
    parser.add_argument(
        "--strict",
        action="store_true",
        help="Also fail if any phase spec is in 'Not Started' state (not just non-Implemented).",
    )
    args = parser.parse_args()

    phase_number: int = args.phase
    failures: list[str] = []
    warnings: list[str] = []

    if phase_number not in PHASE_CONFIG:
        print(f"ERROR  Unknown phase: {phase_number}. Valid: {sorted(PHASE_CONFIG)}")
        sys.exit(2)

    version_tag = PHASE_CONFIG[phase_number]["version_tag"]
    tag_already_released = check_git_tag_exists(version_tag)
    tag_commit = get_git_tag_commit(version_tag) if tag_already_released else ""

    if tag_already_released:
        print(
            f"INFO   Phase {phase_number} was already released as {version_tag}"
            + (f" (commit {tag_commit})" if tag_commit else "")
            + "."
        )

    # 1. Check all specs in the target phase
    spec_statuses = read_spec_statuses(phase_number)
    if not spec_statuses:
        phase_folder = PHASE_CONFIG[phase_number]["folder"]
        warnings.append(f"No spec files found in specs/{phase_folder}/ \u2014 phase not started.")
    else:
        for spec_id, status in spec_statuses.items():
            is_implemented = status.lower().startswith("implemented")
            if tag_already_released:
                # Phase is already released — report spec state as info only.
                state_icon = "[OK]" if is_implemented else "[!!]"
                print(f"  {state_icon} {spec_id}: {status}")
            elif not is_implemented:
                failures.append(
                    f"  NOT IMPLEMENTED: {spec_id} (Status: {status})"
                    f" \u2014 Phase {phase_number} cannot exit."
                )
                if args.strict and "not started" in status.lower():
                    failures.append(f"    [strict] {spec_id} has not been started.")

    # 2. Check for forward phase violations (phase-N+1 specs already Implemented).
    # When the tag already exists the phase is definitionally closed — all forward
    # violations are historical.  When the tag does not exist and the current phase is
    # fully Implemented, demote to WARN (out-of-order work already done; not actionable).
    forward_violations = check_no_later_phase_implemented(phase_number)
    all_current_implemented = not any("NOT IMPLEMENTED" in f for f in failures)
    if forward_violations:
        if tag_already_released or all_current_implemented:
            for fv in forward_violations:
                warnings.append(
                    fv.replace("  VIOLATION:", "forward-phase work pre-dated exit (historical):")
                )
        else:
            failures.extend(forward_violations)

    # 3. Summary
    if warnings:
        for warning_message in warnings:
            print(f"WARN  {warning_message}")

    if failures:
        print(f"\nPhase {phase_number} gate FAILED — {len(failures)} issue(s):\n")
        for failure_message in failures:
            print(f"FAIL  {failure_message}")
        sys.exit(1)
    else:
        spec_count = len(spec_statuses)
        if tag_already_released:
            print(
                f"Phase {phase_number} gate CLOSED — {spec_count} spec(s) Implemented, "
                f"released as {version_tag}" + (f" @ {tag_commit}" if tag_commit else "") + "."
            )
        else:
            print(
                f"Phase {phase_number} gate PASSED — {spec_count} spec(s) all Implemented. "
                f"Ready for {version_tag}."
            )
            print(
                f"\n  Suggested tag:\n"
                f'    git tag -a {version_tag} -m "Phase {phase_number} complete"'
            )
        sys.exit(0)


if __name__ == "__main__":
    main()
