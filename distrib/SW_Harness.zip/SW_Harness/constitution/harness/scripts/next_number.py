﻿"""
next_number — Thread-safe sequence number dispenser for {project_name} pipeline.

Returns the next available number for SPEC, ADR, or Contract identifiers.
Uses SQLite exclusive transactions to prevent duplicate assignments across
parallel chat sessions or processes working on the same repository.

On first run (or --seed), scans the filesystem to initialise counters from
the current highest existing numbers — no manual seeding needed.

Usage:
    python scripts/next_number.py --type spec               # claim + print next SPEC number
    python scripts/next_number.py --type adr                # claim + print next ADR number
    python scripts/next_number.py --type contract           # claim + print next Contract number
    python scripts/next_number.py --type spec --peek        # peek without claiming
    python scripts/next_number.py --seed                    # re-seed all counters from filesystem
    python scripts/next_number.py --status                  # show current claimed values

Output format (claim / peek):
    SPEC-0022
    SYS-ADR-0049
    HAR-ADR-0012
    SYS-C-0013
    HAR-C-0008

Exit codes:
    0  Success.
    1  Unknown type or usage error.
    2  Filesystem seed scan failed.
"""

from __future__ import annotations

import argparse
import re
import sqlite3
import sys
from pathlib import Path

# ---------------------------------------------------------------------------
# Paths — resolved via harness_config (HAR-ADR-0002 genericization)
# ---------------------------------------------------------------------------
# Import load_config from the sibling harness_config module.
# sys.path is extended so this works regardless of the caller's working directory.
sys.path.insert(0, str(Path(__file__).parent))
from harness_config import load_config as _load_harness_config  # noqa: E402

_cfg = _load_harness_config()

REGISTRY_DB: Path = _cfg.number_registry_db

# Two-plane taxonomy paths (HAR-ADR-0001 — SYS/HAR restructure)
# SYS-level dirs may not exist in a harness-only repo; scan returns 0 safely.
SYS_ADRS_DIR: Path = _cfg.repo_root / "constitution" / "system" / "adrs"
HAR_ADRS_DIR: Path = _cfg.constitution_dir / "adrs"
SYS_CONTRACTS_DIR: Path = _cfg.repo_root / "constitution" / "system" / "contracts"
HAR_CONTRACTS_DIR: Path = _cfg.constitution_dir / "contracts"

# Supported counter types → (filesystem_dir, filename_regex, zero_pad_width)
_COUNTER_CONFIG: dict[str, tuple[Path, re.Pattern[str], int]] = {
    "spec": (
        _cfg.specs_dir,
        re.compile(r"SPEC-(\d{4})-", re.IGNORECASE),
        4,
    ),
    "sys-adr": (
        SYS_ADRS_DIR,
        re.compile(r"SYS-ADR-(\d{4})-", re.IGNORECASE),
        4,
    ),
    "har-adr": (
        HAR_ADRS_DIR,
        re.compile(r"HAR-ADR-(\d{4})-", re.IGNORECASE),
        4,
    ),
    "sys-contract": (
        SYS_CONTRACTS_DIR,
        re.compile(r"SYS-C-(\d{4})-", re.IGNORECASE),
        4,
    ),
    "har-contract": (
        HAR_CONTRACTS_DIR,
        re.compile(r"HAR-C-(\d{4})-", re.IGNORECASE),
        4,
    ),
}

# ---------------------------------------------------------------------------
# DB bootstrap
# ---------------------------------------------------------------------------


def _open_db() -> sqlite3.Connection:
    """Open (or create) the registry DB and ensure the counters table exists."""
    REGISTRY_DB.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(REGISTRY_DB), timeout=15, check_same_thread=False)
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS counters (
            type        TEXT PRIMARY KEY,
            claimed     INTEGER NOT NULL,
            seeded_from TEXT,
            updated_at  TEXT DEFAULT (datetime('now'))
        )
        """
    )
    conn.commit()
    return conn


# ---------------------------------------------------------------------------
# Filesystem seed scan
# ---------------------------------------------------------------------------


def _scan_max_from_filesystem(counter_type: str) -> int:
    """Scan the relevant directory and return the highest number found."""
    search_dir, pattern, _ = _COUNTER_CONFIG[counter_type]
    max_found = 0

    if not search_dir.exists():
        return max_found

    for fs_path in search_dir.rglob("*.md"):
        match = pattern.search(fs_path.name)
        if match:
            candidate = int(match.group(1))
            max_found = max(candidate, max_found)

    return max_found


def seed_counters(conn: sqlite3.Connection, force: bool = False) -> dict[str, int]:
    """
    Seed all counters from filesystem scan.

    If force=False, only seeds counter types that have no existing row.
    If force=True, overwrites all counters with the filesystem scan result.
    Returns a dict of {type: seeded_value}.
    """
    results: dict[str, int] = {}

    for counter_type in _COUNTER_CONFIG:
        with conn:
            conn.execute("BEGIN EXCLUSIVE")
            existing = conn.execute(
                "SELECT claimed FROM counters WHERE type = ?", (counter_type,)
            ).fetchone()

            if existing is not None and not force:
                results[counter_type] = existing[0]
                continue

            scanned_max = _scan_max_from_filesystem(counter_type)
            conn.execute(
                """
                INSERT INTO counters (type, claimed, seeded_from, updated_at)
                VALUES (?, ?, 'filesystem_scan', datetime('now'))
                ON CONFLICT(type) DO UPDATE SET
                    claimed     = excluded.claimed,
                    seeded_from = excluded.seeded_from,
                    updated_at  = excluded.updated_at
                """,
                (counter_type, scanned_max),
            )
            results[counter_type] = scanned_max

    return results


# ---------------------------------------------------------------------------
# Core operations
# ---------------------------------------------------------------------------


def claim_next(conn: sqlite3.Connection, counter_type: str) -> int:
    """
    Atomically increment the counter and return the claimed value.

    Uses an EXCLUSIVE transaction so no two concurrent callers can claim
    the same number, even across separate processes on Windows.
    """
    if counter_type not in _COUNTER_CONFIG:
        raise ValueError(
            f"Unknown counter type: {counter_type!r}. Choose from: {list(_COUNTER_CONFIG)}"
        )

    # Auto-seed if no row exists yet
    existing = conn.execute(
        "SELECT claimed FROM counters WHERE type = ?", (counter_type,)
    ).fetchone()
    if existing is None:
        seed_counters(conn, force=False)

    with conn:
        conn.execute("BEGIN EXCLUSIVE")
        row = conn.execute(
            "SELECT claimed FROM counters WHERE type = ?", (counter_type,)
        ).fetchone()
        current = row[0] if row else 0
        next_val = current + 1
        conn.execute(
            """
            UPDATE counters
            SET claimed = ?, updated_at = datetime('now')
            WHERE type = ?
            """,
            (next_val, counter_type),
        )
    return next_val


def peek_next(conn: sqlite3.Connection, counter_type: str) -> int:
    """Return what the next claimed number would be, without claiming it."""
    if counter_type not in _COUNTER_CONFIG:
        raise ValueError(f"Unknown counter type: {counter_type!r}.")

    existing = conn.execute(
        "SELECT claimed FROM counters WHERE type = ?", (counter_type,)
    ).fetchone()
    if existing is None:
        seed_counters(conn, force=False)
        existing = conn.execute(
            "SELECT claimed FROM counters WHERE type = ?", (counter_type,)
        ).fetchone()

    current = existing[0] if existing else 0
    return current + 1


# ---------------------------------------------------------------------------
# Formatting
# ---------------------------------------------------------------------------


def format_number(counter_type: str, number: int) -> str:
    """Return the formatted identifier string, e.g. SPEC-0022, SYS-ADR-0049, HAR-ADR-0012."""
    _, _, pad_width = _COUNTER_CONFIG[counter_type]
    padded = str(number).zfill(pad_width)
    prefixes = {
        "spec": "SPEC",
        "sys-adr": "SYS-ADR",
        "har-adr": "HAR-ADR",
        "sys-contract": "SYS-C",
        "har-contract": "HAR-C",
    }
    return f"{prefixes[counter_type]}-{padded}"


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Thread-safe {project_name} pipeline number dispenser.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument(
        "--type",
        choices=list(_COUNTER_CONFIG),
        help="Counter type to claim or peek.",
    )
    parser.add_argument(
        "--peek",
        action="store_true",
        help="Show next number without claiming it.",
    )
    parser.add_argument(
        "--seed",
        action="store_true",
        help="Re-seed all counters from filesystem scan (overwrites current values).",
    )
    parser.add_argument(
        "--status",
        action="store_true",
        help="Show the current claimed values for all counters.",
    )
    return parser


def main(argv: list[str] | None = None) -> int:
    parser = _build_parser()
    args = parser.parse_args(argv)

    conn = _open_db()

    if args.seed:
        seeded = seed_counters(conn, force=True)
        for counter_type, value in seeded.items():
            print(f"Seeded  {format_number(counter_type, value)}  (next will be +1)")
        return 0

    if args.status:
        # Seed any missing rows first
        seed_counters(conn, force=False)
        rows = conn.execute(
            "SELECT type, claimed, updated_at FROM counters ORDER BY type"
        ).fetchall()
        print("Counter status (last claimed / next available):")
        for counter_type, claimed, updated_at in rows:
            next_val = format_number(counter_type, claimed + 1)
            last_val = format_number(counter_type, claimed)
            print(
                f"  {counter_type:<10}  last claimed: {last_val}  →  next: {next_val}  (as of {updated_at})"
            )
        return 0

    if not args.type:
        parser.error("--type is required unless using --seed or --status")

    try:
        if args.peek:
            number = peek_next(conn, args.type)
            label = "(peek — not claimed)"
        else:
            number = claim_next(conn, args.type)
            label = "(claimed)"

        formatted = format_number(args.type, number)
        print(f"{formatted}  {label}")
        return 0

    except ValueError as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
