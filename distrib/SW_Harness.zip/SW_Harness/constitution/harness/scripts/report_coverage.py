﻿r"""report_coverage.py — Proof obligation coverage matrix generator.

Implements: HAR-ADR-0020 | HAR-C-0009 §6

PURPOSE
-------
Reads all assertion YAML files under constitution/harness/registries/assertions/,
groups them by contract_type, and prints a plain-text coverage report to stdout.

OUTPUT FORMAT (HAR-C-0009 §6)
------------------------------
  Proof Obligation Coverage -- <date>

  ENUMERATIVE:     N verified / M total  (X%)
  STRUCTURAL:      N verified / M total  (X%)
  BEHAVIORAL:      N verified / M total  (X%)
  QUALITY:         N verified / M total  (X%)
  SEMANTIC:        N verified / M total  (X%)
  HUMAN_REVIEW:    N rules               (always 100% -- reviewed by definition)
  UNVERIFIED:      N rules               (aspirational / deferred)

  Overall verified: N / M (X%)

EXIT CODE
---------
  Always 0 -- this is an informational report, never a gate.

USAGE
-----
  python report_coverage.py
  python report_coverage.py --assertions-dir path/to/assertions/
"""

from __future__ import annotations

import argparse
import sys
from dataclasses import dataclass
from datetime import date
from pathlib import Path

_SCRIPTS_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(_SCRIPTS_DIR))

from check_contract_fidelity import _load_yaml_file

# ── Contract class constants ──────────────────────────────────────────────────

CONTRACT_CLASSES = ("ENUMERATIVE", "STRUCTURAL", "BEHAVIORAL", "QUALITY", "SEMANTIC")


# ── Result types ──────────────────────────────────────────────────────────────


@dataclass
class CoverageRow:
    """Coverage numbers for a single contract class."""

    class_name: str
    verified: int
    total: int
    pct: float


@dataclass
class CoverageMatrix:
    """Full coverage matrix across all contract classes."""

    report_date: str
    rows: list[CoverageRow]
    human_review_count: int
    unverified_count: int
    overall_verified: int
    overall_total: int


# ── Coverage computation ──────────────────────────────────────────────────────


def generate_coverage_report(assertions_dir: str) -> CoverageMatrix:
    """Read all assertion YAML files and compute coverage by contract_type.

    Parameters
    ----------
    assertions_dir:
        Path to the directory containing *.yaml assertion files.

    Returns:
    -------
    CoverageMatrix with one CoverageRow per recognised contract class.
    """
    # Counters per class: {class_name: [verified_count, total_count]}
    class_counters: dict[str, list[int]] = {cls: [0, 0] for cls in CONTRACT_CLASSES}
    human_review_count = 0
    unverified_count = 0

    assertions_path = Path(assertions_dir)
    for yaml_file in sorted(assertions_path.glob("*.yaml")):
        try:
            entries = _load_yaml_file(str(yaml_file))
        except (FileNotFoundError, ValueError):
            continue

        for entry in entries:
            if not isinstance(entry, dict):
                continue
            proof_status: str = entry.get("proof_status", "UNVERIFIED")
            contract_type: str | None = entry.get("contract_type")

            # HUMAN_REVIEW entries are tallied separately; never in class rows
            if proof_status == "HUMAN_REVIEW":
                human_review_count += 1
                continue

            # UNVERIFIED entries are tooling-debt placeholders (deferred proofs).
            # They are excluded from class denominators so they cannot dilute the
            # verified percentage of active assertions.  Tracked in unverified_count.
            if proof_status == "UNVERIFIED":
                unverified_count += 1
                continue

            if contract_type not in class_counters:
                continue

            class_counters[contract_type][1] += 1  # total
            if proof_status in {"VERIFIED", "PARTIALLY_VERIFIED"}:
                class_counters[contract_type][0] += 1  # verified

    rows: list[CoverageRow] = []
    overall_verified = 0
    overall_total = 0

    for class_name in CONTRACT_CLASSES:
        verified_count, total_count = class_counters[class_name]
        pct = (verified_count / total_count * 100.0) if total_count > 0 else 0.0
        rows.append(
            CoverageRow(
                class_name=class_name,
                verified=verified_count,
                total=total_count,
                pct=round(pct, 1),
            )
        )
        overall_verified += verified_count
        overall_total += total_count

    return CoverageMatrix(
        report_date=date.today().isoformat(),
        rows=rows,
        human_review_count=human_review_count,
        unverified_count=unverified_count,
        overall_verified=overall_verified,
        overall_total=overall_total,
    )


def _safe_load_entries(yaml_file: Path) -> list:
    """Load YAML entries from a file, returning empty list on error."""
    try:
        return _load_yaml_file(str(yaml_file))
    except (FileNotFoundError, ValueError):
        return []


# ── Plain-text formatter ──────────────────────────────────────────────────────


def _format_plain_text(matrix: CoverageMatrix) -> str:
    """Format a CoverageMatrix as plain text per HAR-C-0009 §6."""
    lines: list[str] = [
        f"Proof Obligation Coverage -- {matrix.report_date}",
        "",
    ]

    for row in matrix.rows:
        if row.total == 0:
            lines.append(f"{row.class_name + ':':<17}0 verified / 0 total  (0.0%)")
        else:
            lines.append(
                f"{row.class_name + ':':<17}{row.verified} verified / {row.total} total"
                f"  ({row.pct}%)"
            )

    lines.append(
        f"{'HUMAN_REVIEW:':<17}{matrix.human_review_count} rules"
        "               (always 100% -- reviewed by definition)"
    )
    lines.append(
        f"{'UNVERIFIED:':<17}{matrix.unverified_count} rules"
        "               (aspirational / deferred)"
    )
    lines.append("")

    overall_pct = (
        round(matrix.overall_verified / matrix.overall_total * 100.0, 1)
        if matrix.overall_total > 0
        else 0.0
    )
    lines.append(
        f"Overall verified: {matrix.overall_verified} / {matrix.overall_total} ({overall_pct}%)"
    )

    return "\n".join(lines)


# ── CLI entry point ───────────────────────────────────────────────────────────


def main(argv: list[str] | None = None) -> None:
    """CLI: python report_coverage.py [--assertions-dir DIR]."""
    script_dir = Path(__file__).resolve().parent
    default_assertions_dir = str(script_dir.parent / "registries" / "assertions")

    parser = argparse.ArgumentParser(
        description="Print proof obligation coverage matrix (informational, always exits 0)."
    )
    parser.add_argument(
        "--assertions-dir",
        default=default_assertions_dir,
        metavar="DIR",
        help=f"Assertions directory (default: {default_assertions_dir})",
    )

    args = parser.parse_args(argv)

    matrix = generate_coverage_report(assertions_dir=args.assertions_dir)
    print(_format_plain_text(matrix))


if __name__ == "__main__":
    main()
