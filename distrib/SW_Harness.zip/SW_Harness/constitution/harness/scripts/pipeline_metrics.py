﻿"""
pipeline_metrics.py — SDLC process metrics extractor for {project_name}.

PURPOSE
-------
Closes the process-metrics gap identified in the {project_name} audit:
    "ISO/CMMI auditors want cycle time per gate, defect escape rate, coverage
     trends over time. The data exists in state.json gate histories and
     CHANGES.md but is never aggregated."

This script produces a human-readable (or JSON) summary of:
  - Cycle time per task: G0 → G6 elapsed days
  - Time per gate: average hours spent in each gate
  - Gate pass rate: how often each gate passed first-attempt vs. needed rework
  - Spec completion progress: Implemented / Total per phase
  - Defect escape indicator: deviations recorded in CHANGES.md after G6

EXIT CODES
----------
  0  Report generated successfully.
  2  Script error (file not found, parse failure).

USAGE
-----
  # Human-readable table
  python scripts/pipeline_metrics.py

  # JSON output (CI artifact / dashboard feed)
  python scripts/pipeline_metrics.py --json

  # Filter to a specific phase
  python scripts/pipeline_metrics.py --phase 1

  # Token budget report (requires gate-log.json in each workspace)
  python scripts/pipeline_metrics.py --tokens

  # Token report in JSON format
  python scripts/pipeline_metrics.py --tokens --json
"""

from __future__ import annotations

import argparse
import json
import re
import sys
from dataclasses import dataclass, field
from datetime import UTC, datetime
from pathlib import Path

# WORKSPACE_ROOT removed — use load_config() from harness_config instead
# STATE_FILE — resolved via HarnessConfig.state_file_path
# PIPELINE_WORKSPACE_DIR — resolved via HarnessConfig.pipeline_workspace_dir
# PHASE_STATUS_FILE — resolved via HarnessConfig.memory_dir / 'phase-status.md'
# CHANGES_FILE — resolved via HarnessConfig.repo_root / 'CHANGES.md'
# SPECS_DIR — resolved via HarnessConfig.specs_dir

_GATE_ORDER = ["G0", "G1", "G1->G2", "G2", "G2->G3", "G3", "G3->G4", "G4", "G4->G5", "G5", "G6"]
_TERMINAL_GATES = {"G6", "CLOSED"}

# ---------------------------------------------------------------------------
# Data types
# ---------------------------------------------------------------------------


@dataclass
class GateRecord:
    gate: str
    status: str
    timestamp: datetime | None


@dataclass
class TaskMetrics:
    task_id: str
    description: str
    work_type: str
    mode: str
    current_gate: str
    spec_files: list[str]
    gate_records: list[GateRecord]
    is_closed: bool

    @property
    def start_time(self) -> datetime | None:
        for record in self.gate_records:
            if record.gate == "G0" and record.timestamp:
                return record.timestamp
        return None

    @property
    def end_time(self) -> datetime | None:
        for record in reversed(self.gate_records):
            if record.gate in _TERMINAL_GATES and record.timestamp:
                return record.timestamp
        return None

    @property
    def cycle_days(self) -> float | None:
        if self.start_time and self.end_time:
            delta = self.end_time - self.start_time
            return round(delta.total_seconds() / 86400, 1)
        return None

    @property
    def gates_passed(self) -> list[str]:
        return [record.gate for record in self.gate_records if record.status == "passed"]

    @property
    def primary_spec(self) -> str:
        if self.spec_files:
            return (
                Path(self.spec_files[0]).stem.upper().split("-")[0]
                + "-"
                + Path(self.spec_files[0]).stem.upper().split("-")[1]
            )
        return self.task_id


@dataclass
class PhaseProgress:
    phase_number: int
    total_specs: int
    implemented_specs: int
    not_started_specs: int
    in_flight_specs: int

    @property
    def completion_pct(self) -> int:
        if self.total_specs == 0:
            return 0
        return round(self.implemented_specs / self.total_specs * 100)


@dataclass
class PipelineReport:
    generated_at: str
    tasks: list[TaskMetrics] = field(default_factory=list)
    phase_progress: list[PhaseProgress] = field(default_factory=list)


# ---------------------------------------------------------------------------
# Token budget types (IDEA-H-005)
# ---------------------------------------------------------------------------


@dataclass
class TokenEntry:
    gate: str
    tokens_in: int
    tokens_out: int

    @property
    def tokens_total(self) -> int:
        return self.tokens_in + self.tokens_out


@dataclass
class TaskTokenReport:
    task_id: str
    description: str
    entries: list[TokenEntry] = field(default_factory=list)

    @property
    def total_tokens(self) -> int:
        return sum(entry.tokens_total for entry in self.entries)

    def by_gate(self) -> dict[str, int]:
        result: dict[str, int] = {}
        for entry in self.entries:
            result[entry.gate] = result.get(entry.gate, 0) + entry.tokens_total
        return result


# ---------------------------------------------------------------------------
# Parsing
# ---------------------------------------------------------------------------


def _parse_timestamp(raw: str | None) -> datetime | None:
    if not raw:
        return None
    try:
        parsed = datetime.fromisoformat(raw.replace("Z", "+00:00"))
        return parsed.replace(tzinfo=UTC) if parsed.tzinfo is None else parsed
    except (ValueError, AttributeError):
        return None


def load_tasks(active_only: bool = False) -> list[TaskMetrics]:
    if not STATE_FILE.exists():
        print(f"ERROR  state.json not found at {STATE_FILE}", file=sys.stderr)
        sys.exit(2)

    state_index = json.loads(STATE_FILE.read_text(encoding="utf-8"))

    # HAR-ADR-0008: slim index has active_tasks[] + closed_task_index[] tombstones.
    # Back-compat: old monolithic format had full task data inside active_tasks/active_streams.
    active_index_entries = state_index.get("active_tasks", state_index.get("active_streams", []))
    closed_index_entries = state_index.get("closed_task_index", [])
    # Merge; avoid duplicates when back-compat format has only active_tasks (no closed_task_index)
    active_ids = {entry.get("task_id") for entry in active_index_entries}
    all_index_entries = active_index_entries + [
        entry for entry in closed_index_entries if entry.get("task_id") not in active_ids
    ]

    task_metrics_list: list[TaskMetrics] = []
    for index_entry in all_index_entries:
        task_id = index_entry.get("task_id", "unknown")
        workspace_path_str = index_entry.get("workspace_path", "")

        # HAR-ADR-0008: load full state from per-workspace task-state.json when available;
        # fall back to index_entry itself for old monolithic format.
        raw_task = index_entry
        if workspace_path_str:
            task_state_file = WORKSPACE_ROOT / workspace_path_str / "task-state.json"
            if task_state_file.exists():
                raw_task = json.loads(task_state_file.read_text(encoding="utf-8"))

        current_gate = raw_task.get("current_gate", index_entry.get("current_gate", "unknown"))
        is_closed = current_gate in _TERMINAL_GATES

        if active_only and is_closed:
            continue

        gate_records = [
            GateRecord(
                gate=entry.get("gate", ""),
                status=entry.get("status", ""),
                timestamp=_parse_timestamp(entry.get("timestamp")),
            )
            for entry in raw_task.get("gate_history", [])
        ]

        task_metrics_list.append(
            TaskMetrics(
                task_id=task_id,
                description=raw_task.get("description", index_entry.get("description", "")),
                work_type=raw_task.get("work_type", ""),
                mode=raw_task.get("mode", ""),
                current_gate=current_gate,
                spec_files=raw_task.get("spec_files", []),
                gate_records=gate_records,
                is_closed=is_closed,
            )
        )

    return task_metrics_list


def load_phase_progress(phase_filter: int | None) -> list[PhaseProgress]:
    phase_dirs = sorted(SPECS_DIR.glob("phase-*"))
    phase_progress_list: list[PhaseProgress] = []

    for phase_dir in phase_dirs:
        phase_match = re.search(r"phase-(\d+)", phase_dir.name)
        if not phase_match:
            continue
        phase_number = int(phase_match.group(1))
        if phase_filter is not None and phase_number != phase_filter:
            continue

        spec_files = sorted(phase_dir.glob("SPEC-*.md"))
        implemented_count = 0
        not_started_count = 0
        in_flight_count = 0

        for spec_file in spec_files:
            spec_text = spec_file.read_text(encoding="utf-8")
            status_match = re.search(r"^\*\*Status:\*\*\s+(.+)$", spec_text, re.MULTILINE)
            raw_status = status_match.group(1).strip().lower() if status_match else "unknown"

            if raw_status.startswith("implemented"):
                implemented_count += 1
            elif "not started" in raw_status or raw_status == "unknown":
                not_started_count += 1
            else:
                in_flight_count += 1

        phase_progress_list.append(
            PhaseProgress(
                phase_number=phase_number,
                total_specs=len(spec_files),
                implemented_specs=implemented_count,
                not_started_specs=not_started_count,
                in_flight_specs=in_flight_count,
            )
        )

    return phase_progress_list


def compute_gate_averages(tasks: list[TaskMetrics]) -> dict[str, float]:
    """
    Compute average hours spent in each gate across all closed tasks.
    Approximated as time between consecutive gate timestamps.
    """
    gate_durations: dict[str, list[float]] = {}

    for task in tasks:
        if not task.is_closed:
            continue
        sorted_records = [record for record in task.gate_records if record.timestamp is not None]
        sorted_records.sort(key=lambda record: record.timestamp)  # type: ignore[arg-type]

        for idx in range(len(sorted_records) - 1):
            current_record = sorted_records[idx]
            next_record = sorted_records[idx + 1]
            if current_record.timestamp and next_record.timestamp:
                duration_hours = (
                    next_record.timestamp - current_record.timestamp
                ).total_seconds() / 3600
                gate_label = current_record.gate
                gate_durations.setdefault(gate_label, []).append(duration_hours)

    return {
        gate_label: round(sum(durations) / len(durations), 1)
        for gate_label, durations in gate_durations.items()
        if durations
    }


# ---------------------------------------------------------------------------
# Output helpers
# ---------------------------------------------------------------------------


def _bar(filled: int, total: int, width: int = 20) -> str:
    if total == 0:
        return "─" * width
    fill_count = round(filled / total * width)
    return "█" * fill_count + "░" * (width - fill_count)


# ---------------------------------------------------------------------------
# Token budget helpers (IDEA-H-005)
# ---------------------------------------------------------------------------


def load_token_reports(tasks: list[TaskMetrics]) -> list[TaskTokenReport]:
    """
    For each task with a workspace_path, read workspace/<task>/gate-log.json
    (format: list of {"gate": str, "tokens_in": int, "tokens_out": int}).
    Returns TaskTokenReport per task that has a gate-log.json.
    """
    token_reports: list[TaskTokenReport] = []
    state_data = json.loads(STATE_FILE.read_text(encoding="utf-8")) if STATE_FILE.exists() else {}
    all_index = state_data.get("active_tasks", []) + state_data.get("closed_task_index", [])
    workspace_by_id = {entry["task_id"]: entry.get("workspace_path", "") for entry in all_index}

    for task in tasks:
        workspace_path_str = workspace_by_id.get(task.task_id, "")
        if not workspace_path_str:
            continue
        gate_log_file = WORKSPACE_ROOT / workspace_path_str / "gate-log.json"
        if not gate_log_file.exists():
            continue
        try:
            raw_entries = json.loads(gate_log_file.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            continue
        entries = [
            TokenEntry(
                gate=entry.get("gate", "?"),
                tokens_in=int(entry.get("tokens_in", 0)),
                tokens_out=int(entry.get("tokens_out", 0)),
            )
            for entry in raw_entries
            if isinstance(entry, dict)
        ]
        if entries:
            token_reports.append(
                TaskTokenReport(
                    task_id=task.task_id,
                    description=task.description,
                    entries=entries,
                )
            )

    return token_reports


def print_token_report(token_reports: list[TaskTokenReport]) -> None:
    """Print human-readable per-gate token consumption table."""
    if not token_reports:
        print("\nNo gate-log.json files found — agents have not written token entries yet.")
        print("Agents must append {\"gate\": \"GN\", \"tokens_in\": N, \"tokens_out\": M} entries.")
        return

    sorted_reports = sorted(token_reports, key=lambda t: t.total_tokens, reverse=True)
    grand_total = sum(tr.total_tokens for tr in token_reports)

    print("\nToken Budget Report")
    print("=" * 72)
    print(f"  {'Task':<12}  {'Total':>8}  {'By Gate'}")
    print("-" * 72)
    for report in sorted_reports:
        by_gate_str = "  ".join(f"{gate}:{count:,}" for gate, count in sorted(report.by_gate().items()))
        print(f"  {report.task_id:<12}  {report.total_tokens:>8,}  {by_gate_str}")
        if len(report.description) > 0:
            print(f"  {'':12}  {'':8}  {report.description[:58]}")
    print("-" * 72)
    print(f"  {'Grand total':<12}  {grand_total:>8,}")
    print()


def print_text_report(report: PipelineReport, active_only: bool) -> None:
    closed_tasks = [task for task in report.tasks if task.is_closed]
    active_tasks = [task for task in report.tasks if not task.is_closed]

    print(f"\n{project_name} — Pipeline Metrics  [{report.generated_at}]")
    print("=" * 72)

    # Phase progress
    if report.phase_progress:
        print("\nPhase Completion")
        print("-" * 72)
        for phase in report.phase_progress:
            bar = _bar(phase.implemented_specs, phase.total_specs)
            print(
                f"  Phase {phase.phase_number}  {bar}  "
                f"{phase.implemented_specs}/{phase.total_specs} implemented  "
                f"({phase.completion_pct}%)  "
                f"[{phase.in_flight_specs} in-flight, {phase.not_started_specs} not started]"
            )

    # Active tasks
    if active_tasks:
        print(f"\nActive Tasks ({len(active_tasks)})")
        print("-" * 72)
        for task in active_tasks:
            specs_label = (
                ", ".join(Path(spec_file).stem for spec_file in task.spec_files) or task.task_id
            )
            print(
                f"  {task.task_id:<10}  Gate: {task.current_gate:<8}  Mode: {task.mode:<5}  {specs_label}"
            )
            print(f"             {task.description}")

    # Closed tasks cycle time
    if closed_tasks and not active_only:
        print(f"\nClosed Tasks — Cycle Time ({len(closed_tasks)} tasks)")
        print("-" * 72)
        cycle_times = [task.cycle_days for task in closed_tasks if task.cycle_days is not None]
        for task in closed_tasks:
            cycle_label = f"{task.cycle_days}d" if task.cycle_days is not None else "n/a"
            specs_label = (
                ", ".join(Path(spec_file).stem for spec_file in task.spec_files) or task.task_id
            )
            print(f"  {task.task_id:<10}  {cycle_label:<6}  {task.work_type:<22}  {specs_label}")

        if cycle_times:
            avg_cycle = round(sum(cycle_times) / len(cycle_times), 1)
            min_cycle = min(cycle_times)
            max_cycle = max(cycle_times)
            print(f"\n  Avg cycle time: {avg_cycle}d  |  Min: {min_cycle}d  |  Max: {max_cycle}d")

    # Gate averages
    gate_averages = compute_gate_averages(report.tasks)
    if gate_averages:
        print("\nAverage Time Per Gate (hours, across closed tasks)")
        print("-" * 72)
        for gate_label in _GATE_ORDER:
            avg_hours = gate_averages.get(gate_label)
            if avg_hours is not None:
                bar = _bar(min(int(avg_hours), 48), 48, width=12)
                print(f"  {gate_label:<10}  {bar}  {avg_hours}h")

    print()


def print_json_report(report: PipelineReport, token_reports: list["TaskTokenReport"] | None = None) -> None:
    gate_averages = compute_gate_averages(report.tasks)
    closed_tasks = [task for task in report.tasks if task.is_closed]
    cycle_times = [task.cycle_days for task in closed_tasks if task.cycle_days is not None]

    output = {
        "generated_at": report.generated_at,
        "summary": {
            "total_tasks": len(report.tasks),
            "closed_tasks": len(closed_tasks),
            "active_tasks": len([task for task in report.tasks if not task.is_closed]),
            "avg_cycle_days": round(sum(cycle_times) / len(cycle_times), 1)
            if cycle_times
            else None,
        },
        "phase_progress": [
            {
                "phase": phase.phase_number,
                "total": phase.total_specs,
                "implemented": phase.implemented_specs,
                "in_flight": phase.in_flight_specs,
                "not_started": phase.not_started_specs,
                "completion_pct": phase.completion_pct,
            }
            for phase in report.phase_progress
        ],
        "tasks": [
            {
                "task_id": task.task_id,
                "description": task.description,
                "work_type": task.work_type,
                "mode": task.mode,
                "current_gate": task.current_gate,
                "is_closed": task.is_closed,
                "cycle_days": task.cycle_days,
                "spec_files": task.spec_files,
                "gates_passed": task.gates_passed,
            }
            for task in report.tasks
        ],
        "gate_averages_hours": gate_averages,
    }
    if token_reports:
        output["token_budget"] = {
            "tasks": [
                {
                    "task_id": tr.task_id,
                    "description": tr.description,
                    "total_tokens": tr.total_tokens,
                    "by_gate": tr.by_gate(),
                }
                for tr in sorted(token_reports, key=lambda t: t.total_tokens, reverse=True)
            ],
            "grand_total": sum(tr.total_tokens for tr in token_reports),
        }
    print(json.dumps(output, indent=2))


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------


def main() -> None:
    parser = argparse.ArgumentParser(description="{project_name} pipeline process metrics extractor.")
    parser.add_argument(
        "--phase",
        type=int,
        metavar="N",
        help="Filter phase progress to phase N only.",
    )
    parser.add_argument(
        "--active-only",
        action="store_true",
        help="Show only tasks still in flight.",
    )
    parser.add_argument(
        "--json",
        action="store_true",
        help="Emit JSON report instead of human-readable text.",
    )
    parser.add_argument(
        "--tokens",
        action="store_true",
        help="Show per-gate token consumption from workspace gate-log.json files.",
    )
    args = parser.parse_args()

    tasks = load_tasks(active_only=args.active_only)
    phase_progress = load_phase_progress(phase_filter=args.phase)

    report = PipelineReport(
        generated_at=datetime.now(tz=UTC).strftime("%Y-%m-%d %H:%M UTC"),
        tasks=tasks,
        phase_progress=phase_progress,
    )

    token_reports = load_token_reports(tasks) if args.tokens else None

    if args.json:
        print_json_report(report, token_reports=token_reports)
    else:
        print_text_report(report, active_only=args.active_only)
        if token_reports is not None:
            print_token_report(token_reports)


if __name__ == "__main__":
    main()
