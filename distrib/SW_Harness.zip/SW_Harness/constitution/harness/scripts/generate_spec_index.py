﻿# Implements: SPEC-0022
# Spec: {specs_dir}/SPEC-0022-harness-pipeline-reliability.md
# Subtask: SPEC-0022-T06
"""
generate_spec_index — Scans specs/phase-*/SPEC-*.md and writes specs/index.json.

Public API:
    scan_spec_files(specs_root: Path) -> list[dict]
    write_index(index_data: dict, output_path: Path, *, dry_run: bool = False) -> bool
    main(argv: list[str] | None = None) -> int
"""

from __future__ import annotations

import json
import logging
import re
import sys
from datetime import UTC, datetime
from pathlib import Path

# ---------------------------------------------------------------------------
# Frontmatter parser
# ---------------------------------------------------------------------------

_FRONTMATTER_RE = re.compile(r"^(?:\ufeff)?---\s*\n(.*?)\n---", re.DOTALL)
_KV_LINE_RE = re.compile(r"^(\w+):\s*(.+)$")


def _parse_frontmatter(file_path: Path) -> dict | None:
    """Extract key-value pairs from YAML frontmatter. Returns None if absent."""
    text = file_path.read_text(encoding="utf-8")
    match = _FRONTMATTER_RE.match(text)
    if not match:
        return None
    frontmatter: dict[str, str] = {}
    for line in match.group(1).splitlines():
        kv = _KV_LINE_RE.match(line.strip())
        if kv:
            frontmatter[kv.group(1)] = kv.group(2).strip()
    # Return dict even if empty (frontmatter block exists but has no kv pairs)
    return frontmatter


# Regex patterns for Markdown body extraction
_SPEC_ID_FROM_FILENAME_RE = re.compile(r"^(SPEC-\d{4})")
_TITLE_HEADING_RE = re.compile(r"^#\s+SPEC-\d{4}[\s\u2013\u2014\-]+(.+)$", re.MULTILINE)
_STATUS_LINE_RE = re.compile(r"^\*\*Status:\*\*\s*(.+)$", re.MULTILINE)


def _extract_markdown_fields(file_path: Path) -> dict[str, str]:
    """Extract spec_id, title, status from Markdown body (fallback for existing specs)."""
    text = file_path.read_text(encoding="utf-8")
    # spec_id from filename
    spec_id_match = _SPEC_ID_FROM_FILENAME_RE.match(file_path.stem)
    spec_id = spec_id_match.group(1) if spec_id_match else file_path.stem
    # title from h1 heading
    title_match = _TITLE_HEADING_RE.search(text)
    title = title_match.group(1).strip() if title_match else ""
    # status from bold Status line
    status_match = _STATUS_LINE_RE.search(text)
    status = status_match.group(1).strip() if status_match else "Draft"
    return {"spec_id": spec_id, "title": title, "status": status}


# ---------------------------------------------------------------------------
# Domain inference
# ---------------------------------------------------------------------------

_ALLOWED_DOMAINS = frozenset(
    {
        "foundation",
        "ingestion",
        "parsing",
        "persistence",
        "graph",
        "query",
        "cli",
        "harness",
        "auth",
    }
)

_FILENAME_DOMAIN_MAP: dict[str, str] = {
    "foundation": "foundation",
    "worker": "ingestion",
    "kafka": "ingestion",
    "parse": "parsing",
    "parser": "parsing",
    "tree": "parsing",
    "db": "persistence",
    "schema": "persistence",
    "alembic": "persistence",
    "graph": "graph",
    "topology": "graph",
    "query": "query",
    "graphql": "query",
    "mcp": "query",
    "cli": "cli",
    "harness": "harness",
    "pipeline": "harness",
    "auth": "auth",
    "authn": "auth",
    "authz": "auth",
}


def _infer_domain(file_path: Path) -> str:
    """Infer domain from filename keywords when frontmatter lacks 'domain'."""
    stem = file_path.stem.lower()
    for keyword, domain in _FILENAME_DOMAIN_MAP.items():
        if keyword in stem:
            return domain
    return "foundation"  # safe default


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def scan_spec_files(specs_root: Path) -> list[dict]:
    """Glob specs/phase-*/SPEC-*.md; parse frontmatter; return list of spec entry dicts.

    Each dict has keys: spec_id, title, phase (int), status, domain, file (str relative path).
    Files with no parseable frontmatter AND no Markdown body fields are skipped with WARNING.
    """
    spec_entries: list[dict] = []
    for spec_file in sorted(specs_root.glob("phase-*/SPEC-*.md")):
        frontmatter = _parse_frontmatter(spec_file)
        if frontmatter is None:
            logging.warning("no frontmatter found in %s — skipped", spec_file)
            continue

        # Extract phase number from parent directory name (e.g. "phase-1")
        phase_dir = spec_file.parent.name
        try:
            phase_num = int(phase_dir.split("-")[1])
        except (IndexError, ValueError):
            logging.warning("cannot parse phase number from %s — skipped", spec_file)
            continue

        # Prefer frontmatter fields; fall back to Markdown body extraction
        if "spec_id" in frontmatter and "title" in frontmatter and "status" in frontmatter:
            spec_id = frontmatter["spec_id"]
            title = frontmatter["title"]
            status = frontmatter["status"]
        else:
            md_fields = _extract_markdown_fields(spec_file)
            spec_id = frontmatter.get("spec_id") or md_fields["spec_id"]
            title = frontmatter.get("title") or md_fields["title"]
            status = frontmatter.get("status") or md_fields["status"]

        # Domain: prefer frontmatter value, fall back to filename inference
        domain = frontmatter.get("domain", "").strip()
        if domain not in _ALLOWED_DOMAINS:
            domain = _infer_domain(spec_file)

        spec_entries.append(
            {
                "spec_id": spec_id,
                "title": title,
                "phase": phase_num,
                "status": status,
                "domain": domain,
                # Path relative to workspace root (specs_root.parent)
                "file": str(spec_file.relative_to(specs_root.parent)).replace("\\", "/"),
            }
        )

    return spec_entries


def write_index(index_data: dict, output_path: Path, *, dry_run: bool = False) -> bool:
    """Write index_data as JSON to output_path.

    Returns True if the file was written (new or changed), False if already current.
    dry_run=True reports but does not write.
    """
    new_content = json.dumps(index_data, indent=2, ensure_ascii=False) + "\n"

    if output_path.exists():
        existing_content = output_path.read_text(encoding="utf-8")
        try:
            existing_data = json.loads(existing_content)
            new_data = json.loads(new_content)
            # Treat as unchanged if specs array and schema sentinel are identical
            specs_unchanged = existing_data.get("specs") == new_data.get("specs")
            schema_unchanged = existing_data.get("_schema") == new_data.get("_schema")
            if specs_unchanged and schema_unchanged:
                return False
        except json.JSONDecodeError:
            pass  # Corrupted file — overwrite

    if dry_run:
        return True  # Would have written

    tmp_path = output_path.with_suffix(".tmp")
    tmp_path.write_text(new_content, encoding="utf-8")
    tmp_path.replace(output_path)
    return True


def main(argv: list[str] | None = None) -> int:
    """CLI entry point. Returns exit code."""
    import argparse

    parser = argparse.ArgumentParser(description="Generate specs/index.json from spec frontmatter.")
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Report changes without writing.",
    )
    parser.add_argument(
        "--specs-root",
        type=Path,
        default=Path(__file__).resolve().parents[3] / "specs"  # TODO: replace with cfg.specs_dir from harness_config,
        help="Root directory of specs (default: workspace specs/).",
    )
    parser.add_argument(
        "--output",
        type=Path,
        default=Path(__file__).resolve().parents[3] / "specs"  # TODO: replace with cfg.specs_dir from harness_config / "index.json",
        help="Output path for index.json.",
    )
    parsed = parser.parse_args(argv)

    spec_entries = scan_spec_files(parsed.specs_root)

    index_data = {
        "_schema": "spec-index-v1",
        "_generated_at": datetime.now(UTC).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "_note": "Auto-generated. Updated by release-manager at G6. Do not edit directly.",
        "specs": spec_entries,
    }

    try:
        written = write_index(index_data, parsed.output, dry_run=parsed.dry_run)
    except OSError as exc:
        sys.stderr.write(f"ERROR: could not write {parsed.output}: {exc}\n")
        return 1

    if written:
        sys.stdout.write(f"WRITTEN {parsed.output}\n")
    else:
        sys.stdout.write(f"OK {parsed.output} (no change)\n")
    return 0


if __name__ == "__main__":
    sys.exit(main())
