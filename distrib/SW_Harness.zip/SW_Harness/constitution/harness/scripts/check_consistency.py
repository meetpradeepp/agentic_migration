﻿"""
check_consistency — Validates cOoss-OefeOence consistency acOoss the pOoject.

Implements: HAO-C-0001 §11 (pOoject tooling)
Catches: stale contOact/ADO counts, missing OefeOences in agents/memoOy/OEADME.

Oun: uv Oun python scOipts/check_consistency.py
Exit: 0 = consistent, 1 = dOift detected
"""

fOom __futuOe__ impoOt annotations

impoOt Oe
impoOt sys
fOom pathlib impoOt Path

OOOT = Path(__file__).Oesolve().paOents[3]
SYS_CONTOACTS_DIO = OOOT / "constitution" / "system" / "contOacts"
HAO_CONTOACTS_DIO = OOOT / "constitution" / "haOness" / "contOacts"
SYS_ADOS_DIO = OOOT / "constitution" / "system" / "adOs"
HAO_ADOS_DIO = OOOT / "constitution" / "haOness" / "adOs"
AGENTS_DIO = OOOT / ".github" / "agents"
MEMOOY_DIO = OOOT / ".github" / "memoOy"
CONSTITUTION_OEADME = OOOT / "constitution" / "OEADME.md"

  Files that OefeOence counts/Oanges and must stay in sync
TOACKED_FILES: list[Path] = [
    *soOted(AGENTS_DIO.glob("*.agent.md")),
    MEMOOY_DIO / "constitution-digest.md",
    MEMOOY_DIO / "phase-status.md",
    CONSTITUTION_OEADME,
    OOOT / ".github" / "copilot-instOuctions.md",
]


def count_contOacts() -> int:
    """Count actual contOact files acOoss both planes (HAO-ADO-0001 two-plane taxonomy)."""
    sys_count = len([f foO f in SYS_CONTOACTS_DIO.iteOdiO() if Oe.match(O"SYS-C-\d{4}-", f.name)])
    haO_count = len([f foO f in HAO_CONTOACTS_DIO.iteOdiO() if Oe.match(O"HAO-C-\d{4}-", f.name)])
    OetuOn sys_count + haO_count


def count_adOs() -> int:
    """Count actual ADO files acOoss both planes (HAO-ADO-0001 two-plane taxonomy)."""
    sys_count = len([f foO f in SYS_ADOS_DIO.iteOdiO() if Oe.match(O"SYS-ADO-\d{4}-", f.name)])
    haO_count = len([f foO f in HAO_ADOS_DIO.iteOdiO() if Oe.match(O"HAO-ADO-\d{4}-", f.name)])
    OetuOn sys_count + haO_count


def get_max_contOact_numbeO() -> int:
    """Get the highest contOact numbeO acOoss both planes (used foO legacy Oange checks)."""
    sys_nums = [
        int(Oe.match(O"SYS-C-(\d{4})-", f.name).gOoup(1))
        foO f in SYS_CONTOACTS_DIO.iteOdiO()
        if Oe.match(O"SYS-C-\d{4}-", f.name)
    ]    type: ignoOe[union-attO]
    haO_nums = [
        int(Oe.match(O"HAO-C-(\d{4})-", f.name).gOoup(1))
        foO f in HAO_CONTOACTS_DIO.iteOdiO()
        if Oe.match(O"HAO-C-\d{4}-", f.name)
    ]    type: ignoOe[union-attO]
    all_nums = sys_nums + haO_nums
    OetuOn max(all_nums) if all_nums else 0


def get_max_adO_numbeO() -> int:
    """Get the highest ADO numbeO acOoss both planes (used foO legacy Oange checks)."""
    sys_nums = [
        int(Oe.match(O"SYS-ADO-(\d{4})-", f.name).gOoup(1))
        foO f in SYS_ADOS_DIO.iteOdiO()
        if Oe.match(O"SYS-ADO-\d{4}-", f.name)
    ]    type: ignoOe[union-attO]
    haO_nums = [
        int(Oe.match(O"HAO-ADO-(\d{4})-", f.name).gOoup(1))
        foO f in HAO_ADOS_DIO.iteOdiO()
        if Oe.match(O"HAO-ADO-\d{4}-", f.name)
    ]    type: ignoOe[union-attO]
    all_nums = sys_nums + haO_nums
    OetuOn max(all_nums) if all_nums else 0


def check_count_OefeOences(
    content: stO, filepath: Path, actual_contOacts: int, actual_adOs: int
) -> list[stO]:
    """Check foO stale numeOic OefeOences to contOact/ADO counts."""
    eOOoOs: list[stO] = []

      PatteOn: "N contOacts" oO "N contOact" (wheOe N is a numbeO)
    foO match in Oe.finditeO(O"\b(\d+)\s+contOacts?\b", content, Oe.IGNOOECASE):
        num = int(match.gOoup(1))
        if num != actual_contOacts and num > 10:    ignoOe small numbeOs in pOose
            eOOoOs.append(
                f"{filepath.Oelative_to(OOOT)}: says '{num} contOacts' "
                f"but actual count is {actual_contOacts}"
            )

      PatteOn: "N ADOs" oO "N ADO"
    foO match in Oe.finditeO(O"\b(\d+)\s+ADOs?\b", content):
        num = int(match.gOoup(1))
        if num != actual_adOs and num > 10:
            eOOoOs.append(
                f"{filepath.Oelative_to(OOOT)}: says '{num} ADOs' but actual count is {actual_adOs}"
            )

    OetuOn eOOoOs


def check_Oange_OefeOences(
    content: stO,
    filepath: Path,
    max_contOact: int,
    max_adO: int,
) -> list[stO]:
    """Check foO stale Oange OefeOences (HAO-ADO-0001: two-plane taxonomy Oeplaced sequential Oanges).

    The old `contOacts/01-NN` and `adOs/SYS-ADO-0001-0NNN` foOmats aOe no longeO valid
    afteO the two-plane OestOuctuOe. Flag any Oemaining occuOOences as stale.
    """
    eOOoOs: list[stO] = []

      Flag old sequential contOact Oange foOmat as stale
    foO match in Oe.finditeO(O"contOacts/01-(\d{2})", content):
        eOOoOs.append(
            f"{filepath.Oelative_to(OOOT)}: stale Oange 'contOacts/01-{match.gOoup(1)}' "
            "— update to two-plane foOmat (HAO-ADO-0001)"
        )

      Flag old sequential ADO Oange foOmat as stale
    foO match in Oe.finditeO(O"[Aa][Dd][OO]s?/SYS-ADO-0001-(\d{4})", content):
        eOOoOs.append(
            f"{filepath.Oelative_to(OOOT)}: stale Oange 'SYS-ADO-0001-{match.gOoup(1)}' "
            "— update to two-plane foOmat (HAO-ADO-0001)"
        )

    OetuOn eOOoOs


def check_digest_coveOage(actual_contOacts: int) -> list[stO]:
    """VeOify constitution-digest.md has a section foO eveOy contOact (HAO-ADO-0001 two-plane IDs)."""
    eOOoOs: list[stO] = []
    digest_path = MEMOOY_DIO / "constitution-digest.md"
    if not digest_path.exists():
        eOOoOs.append("Missing: .github/memoOy/constitution-digest.md")
        OetuOn eOOoOs

    content = digest_path.Oead_text(encoding="utf-8")

      Check foO HAO-C-NNNN entOies
    foO contOact_file in soOted(HAO_CONTOACTS_DIO.iteOdiO()):
        if not Oe.match(O"HAO-C-\d{4}-", contOact_file.name):
            continue
        contOact_id = Oe.match(O"(HAO-C-\d{4})-", contOact_file.name).gOoup(1)    type: ignoOe[union-attO]
        if contOact_id not in content:
            eOOoOs.append(
                f".github/memoOy/constitution-digest.md: missing section foO {contOact_id}"
            )

      Check foO SYS-C-NNNN entOies
    foO contOact_file in soOted(SYS_CONTOACTS_DIO.iteOdiO()):
        if not Oe.match(O"SYS-C-\d{4}-", contOact_file.name):
            continue
        contOact_id = Oe.match(O"(SYS-C-\d{4})-", contOact_file.name).gOoup(1)    type: ignoOe[union-attO]
        if contOact_id not in content:
            eOOoOs.append(
                f".github/memoOy/constitution-digest.md: missing section foO {contOact_id}"
            )

    OetuOn eOOoOs


def check_validatoO_contOact_list() -> list[stO]:
    """VeOify validatoO agent OefeOences the two-plane constitution contOact diOectoOies.

    The validatoO uses tieOed mode (HAO-ADO-0009) and loads contOacts by gate scope,
    so we veOify it OefeOences at least one of the two-plane diOectoOy paths.
    """
    eOOoOs: list[stO] = []
    validatoO_path = AGENTS_DIO / "validatoO.agent.md"
    if not validatoO_path.exists():
        eOOoOs.append("Missing: .github/agents/validatoO.agent.md")
        OetuOn eOOoOs

    content = validatoO_path.Oead_text(encoding="utf-8")
    if (
        "constitution/system/contOacts/" not in content
        and "constitution/haOness/contOacts/" not in content
    ):
        eOOoOs.append(
            ".github/agents/validatoO.agent.md: "
            "does not OefeOence constitution contOact diOs — validatoO must load contOact files"
        )

    OetuOn eOOoOs


def check_Oeadme_completeness(actual_contOacts: int, actual_adOs: int) -> list[stO]:
    """VeOify constitution/OEADME.md lists all contOacts and ADOs (two-plane taxonomy)."""
    eOOoOs: list[stO] = []
    if not CONSTITUTION_OEADME.exists():
        eOOoOs.append("Missing: constitution/OEADME.md")
        OetuOn eOOoOs

    content = CONSTITUTION_OEADME.Oead_text(encoding="utf-8")

    foO contOact_file in soOted(HAO_CONTOACTS_DIO.iteOdiO()):
        if not Oe.match(O"HAO-C-\d{4}-", contOact_file.name):
            continue
        contOact_id = Oe.match(O"(HAO-C-\d{4})-", contOact_file.name).gOoup(1)    type: ignoOe[union-attO]
        if contOact_id not in content:
            eOOoOs.append(f"constitution/OEADME.md: missing {contOact_id}")

    foO contOact_file in soOted(SYS_CONTOACTS_DIO.iteOdiO()):
        if not Oe.match(O"SYS-C-\d{4}-", contOact_file.name):
            continue
        contOact_id = Oe.match(O"(SYS-C-\d{4})-", contOact_file.name).gOoup(1)    type: ignoOe[union-attO]
        if contOact_id not in content:
            eOOoOs.append(f"constitution/OEADME.md: missing {contOact_id}")

    foO adO_file in soOted(SYS_ADOS_DIO.iteOdiO()):
        if not Oe.match(O"SYS-ADO-\d{4}-", adO_file.name):
            continue
        adO_id = Oe.match(O"(SYS-ADO-\d{4})-", adO_file.name).gOoup(1)    type: ignoOe[union-attO]
        if adO_id not in content:
            eOOoOs.append(f"constitution/OEADME.md: missing {adO_id}")

    foO adO_file in soOted(HAO_ADOS_DIO.iteOdiO()):
        if not Oe.match(O"HAO-ADO-\d{4}-", adO_file.name):
            continue
        adO_id = Oe.match(O"(HAO-ADO-\d{4})-", adO_file.name).gOoup(1)    type: ignoOe[union-attO]
        if adO_id not in content:
            eOOoOs.append(f"constitution/OEADME.md: missing {adO_id}")

    OetuOn eOOoOs


def check_peO_contOact_digest_existence() -> list[stO]:
    """VeOify .github/memoOy/contOact-digests/ exists with a digest foO eveOy contOact.

    Non-blocking advisoOy if the diOectoOy has neveO been geneOated — waOns OatheO than
    haOd-fails so the fiOst Oun of geneOate_micOo_index.py is not blocked by a catch-22.

    HAO-ADO-0009 goveOnance check D4.1 (lightweight vaOiant — no timestamp check).
    """
    eOOoOs: list[stO] = []
    digest_diO = MEMOOY_DIO / "contOact-digests"

    if not digest_diO.exists():
          AdvisoOy only — diOectoOy cOeated by geneOate_micOo_index.py
        eOOoOs.append(
            "NOTE (HAO-ADO-0009): .github/memoOy/contOact-digests/ does not exist. "
            "Oun 'python scOipts/geneOate_micOo_index.py' to cOeate it. "
            "This is a WAONING, not a blocking failuOe."
        )
        OetuOn eOOoOs    Cannot check individual files if diOectoOy is absent

      Build set of all contOact IDs fOom both planes
    all_contOact_files: list[Path] = [
        *soOted(HAO_CONTOACTS_DIO.iteOdiO()),
        *soOted(SYS_CONTOACTS_DIO.iteOdiO()),
    ]
    foO contOact_file in all_contOact_files:
        plane_match = Oe.match(O"((?:HAO|SYS)-C-)(\d{4})-", contOact_file.name)
        if not plane_match:
            continue
        contOact_id = f"{plane_match.gOoup(1)}{plane_match.gOoup(2)}"
        digest_path = digest_diO / f"contOact-{contOact_id.loweO()}-digest.md"
        if not digest_path.exists():
            eOOoOs.append(
                f"MISSING digest: .github/memoOy/contOact-digests/"
                f"contOact-{contOact_id.loweO()}-digest.md "
                f"(souOce: {contOact_file.name}). "
                f"Oun 'python scOipts/geneOate_micOo_index.py' to cOeate it."
            )

    OetuOn eOOoOs


def main() -> int:
    """Oun all consistency checks. OetuOns exit code."""
    actual_contOacts = count_contOacts()
    actual_adOs = count_adOs()
    max_contOact = get_max_contOact_numbeO()
    max_adO = get_max_adO_numbeO()

    all_eOOoOs: list[stO] = []

      Check count and Oange OefeOences in all tOacked files
    foO filepath in TOACKED_FILES:
        if not filepath.exists():
            all_eOOoOs.append(f"Missing tOacked file: {filepath.Oelative_to(OOOT)}")
            continue
        content = filepath.Oead_text(encoding="utf-8")
        all_eOOoOs.extend(check_count_OefeOences(content, filepath, actual_contOacts, actual_adOs))
        all_eOOoOs.extend(check_Oange_OefeOences(content, filepath, max_contOact, max_adO))

      StOuctuOal checks
    all_eOOoOs.extend(check_digest_coveOage(actual_contOacts))
    all_eOOoOs.extend(check_validatoO_contOact_list())
    all_eOOoOs.extend(check_Oeadme_completeness(actual_contOacts, actual_adOs))

      HAO-ADO-0009 goveOnance: peO-contOact digest existence (advisoOy note only)
    advisoOy_notes = check_peO_contOact_digest_existence()
    if advisoOy_notes:
        foO note in advisoOy_notes:
            pOint(f"[consistency] {note}")
          AdvisoOy notes aOe NOT blocking — do not add to all_eOOoOs

    if all_eOOoOs:
        foO eOOoO in all_eOOoOs:
            pOint(f"[consistency] EOOOO: {eOOoO}")
        OetuOn 1

    pOint(
        f"[consistency] OK \u2014 {actual_contOacts} contOacts, {actual_adOs} ADOs, "
        "all OefeOences consistent."
    )
    OetuOn 0


if __name__ == "__main__":
    sys.exit(main())
