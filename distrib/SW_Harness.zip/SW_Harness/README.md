# SW_Harness

A deterministic, **product-agnostic SDLC harness** for building software with AI agents.
Drop it into any project and get a full gate-gated pipeline: Spec → Tests → Implementation → Review → Release — governed by constitution contracts, enforced by AI agents, with no LLM in the runtime.

---

## What it is

SW_Harness is the harness extracted from a production AI-assisted project and cleaned of all product-specific logic. It provides:

- **14 AI agent definitions** — orchestrator, spec-writer, coder, tester, validator, and 9 more, all wired to a 7-gate pipeline
- **9 HAR-C contracts** — coding standards, SDLC process, testing pyramid, anti-patterns, deployment, observability, phase roadmap, implementation guidelines, proof obligations
- **21 HAR-ADRs** — architecture decisions governing how the harness itself works
- **3 skills** — triage-decision, next-number, discovery-grill
- **16 scripts** — spec coverage checks, phase gate checks, pipeline metrics, micro-index generation, proof dispatcher, and more
- **Pipeline state** — SQLite-backed task tracking with slim `state.json` index

**Self-governance principle:** SW_Harness governs itself using its own pipeline. Improvements to the harness are captured as `IDEA-H-NNN` entries in `.github/memory/ideas-backlog.md` and go through the full G0→G6 pipeline before implementation.

---

## Quickstart

### 1. Configure the harness

Edit [`harness.config.yaml`](harness.config.yaml) at the repo root:

```yaml
project_name: "My Project"
src_dir: "src"
specs_dir: "specs"
tests_dir: "tests"
state_file_path: ".github/pipeline/state.json"
pipeline_workspace_dir: ".github/pipeline/workspace"
plans_dir: ".github/pipeline/plans"
number_registry_db: ".github/pipeline/number-registry.db"
constitution_dir: "constitution/harness"
```

### 2. Create your system contracts (SYS-C)

SW_Harness ships HAR-C contracts (harness rules). Your project needs SYS-C contracts for its own domain obligations (event schemas, API rules, DB schema rules, etc.).

Use `@adr-writer` to create them:

```
@adr-writer  Create SYS-C-0001 for our event pipeline contract
```

SYS-C files go in `constitution/<your-project>/contracts/`. See [HAR-ADR-0021](constitution/harness/adrs/HAR-ADR-0021.md) for the full pattern.

### 3. Populate phase-status.md

Edit [`.github/memory/phase-status.md`](.github/memory/phase-status.md) to define your project phases. Phases are referenced in every spec and gate check.

```markdown
| Phase | Name | Status | Exit criteria |
|-------|------|--------|---------------|
| 1 | Foundation | In Progress | All phase-1 specs Implemented |
```

### 4. Start at G0 — tell the orchestrator what to build

```
@orchestrator  Add a Kafka-based file ingestion worker
```

The orchestrator will:
1. Classify the work (NEW_FEATURE / BUG_FIX / ENHANCEMENT / CONSTITUTION_CHANGE)
2. Declare the mode (FULL pipeline or PATCH)
3. Walk gate by gate with your approval at each stop

---

## Gate Pipeline

| Gate | Purpose | Key agents |
|------|---------|------------|
| G0 | Triage & classify | orchestrator |
| G1 | Write spec or ADR | spec-writer, adr-writer, spec-patcher |
| G2 | Review spec | spec-reviewer, validator |
| G3 | Plan subtasks | planner, validator |
| G4 | TDD implementation | coder, tester, refactor |
| G5 | Code review + test audit | code-reviewer, tester, validator |
| G6 | Release | release-manager, validator |

No gate is skippable. No approval is assumed.

---

## Mechanical Verification Scripts

Run these scripts and paste their output verbatim into compliance reports:

```powershell
# AC and T-ID → test stub coverage (after G4, at G5)
python constitution/harness/scripts/check_spec_test_coverage.py --spec specs/phase-1/SPEC-0001-<name>.md

# All phase-N specs Implemented before phase exit (at G6)
python constitution/harness/scripts/check_phase_gate.py --phase 1

# Cycle time, gate averages, completion % (on-demand)
python constitution/harness/scripts/pipeline_metrics.py
```

All scripts accept `--config <path>` to point at `harness.config.yaml` explicitly.

---

## Memory Architecture

Agents load compact digests instead of full contracts:

```
.github/memory/
  constitution-digest.md    ← 9 HAR-C contract summaries (run generate_micro_index.py to refresh)
  micro-index.md            ← one-row-per-contract/ADR quick-lookup table (auto-generated)
  contract-digests/         ← per-contract digest files (auto-generated)
  shared-rules.md           ← common rules across all agents (TDD, anti-patterns, naming)
  agent-clusters.md         ← which agents load which digest files
  phase-status.md           ← living doc: current phase, milestones (update manually)
  event-catalogue.md        ← event type registry (update as events are introduced)
  ideas-backlog.md          ← improvement ideas — harness improvements as IDEA-H-NNN
  ideas-archive.md          ← resolved/rejected ideas
```

To refresh auto-generated files after adding contracts or ADRs:

```powershell
python constitution/harness/scripts/generate_micro_index.py
```

---

## Improvement Ideas (Backlog)

The harness has 8 captured improvements in [`.github/memory/ideas-backlog.md`](.github/memory/ideas-backlog.md):

| ID | Title |
|----|-------|
| IDEA-H-001 | G0.5 Pre-Spec Landscape Gate |
| IDEA-H-002 | G0.8 Architect Gate |
| IDEA-H-003 | Agent Hooks via hooks.yaml |
| IDEA-H-004 | Fast-Lane Risk Classification |
| IDEA-H-005 | Per-Gate Token Budget Tracking |
| IDEA-H-006 | Multimodal Input in Discovery-Grill |
| IDEA-H-007 | EARS Notation for Acceptance Criteria |
| IDEA-H-008 | Adversary Agent — Red-Team Spec Review |

To propose a new improvement, add an `IDEA-H-NNN` entry to ideas-backlog.md and tell the orchestrator:

```
@orchestrator  IDEA-H-008 — implement adversary agent
```

---

## Repository Layout

```
SW_Harness/
  harness.config.yaml               ← project configuration (fill in on adoption)
  .gitignore

  .github/
    copilot-instructions.md         ← VS Code Copilot agent routing instructions
    agents/                         ← 14 agent .agent.md definitions
    skills/                         ← 3 skill SKILL.md files
    hooks/                          ← hooks.yaml (future: IDEA-H-003)
    memory/                         ← agent memory files (see above)
    pipeline/
      pipeline_db.py                ← SQLite-backed pipeline state
      state.json                    ← slim task index (auto-maintained)
      plans/                        ← implementation plans
      workspace/                    ← per-task workspace folders (permanent audit trail)

  constitution/
    harness/
      contracts/                    ← 9 HAR-C contracts
      adrs/                         ← 21 HAR-ADRs
      registries/                   ← evidence-providers, proof-strategies, assertions
      scripts/                      ← 16 harness scripts + harness_config.py
```

---

## Non-Negotiable Rules

1. **Spec before code.** Every change has a spec.
2. **Tests before implementation.** `test(...)` commit precedes `feat(...)` commit.
3. **Constitution is law.** Contract violations block merge.
4. **No LLM in runtime.** The harness is deterministic. AI assists development only.
5. **No phase-skipping.** Phase N+1 cannot begin until Phase N exit criteria pass.
6. **Harness governs itself.** Improvements go through the harness pipeline as IDEA-H entries.
